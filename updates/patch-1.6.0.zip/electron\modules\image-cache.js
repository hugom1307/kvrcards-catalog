const path = require('path');
const fs = require('fs');
const http = require('http');
const https = require('https');

let localImageDir = '';
let imageServerPort = 0;
let imageHttpServer = null;
let isDownloading = false;

// Obtener la ruta de almacenamiento de imágenes en userData
function getLocalImageCacheDir(app) {
  if (localImageDir) return localImageDir;
  const userDir = app.getPath('userData');
  localImageDir = path.join(userDir, 'data', 'image-cache');
  if (!fs.existsSync(localImageDir)) {
    try {
      fs.mkdirSync(localImageDir, { recursive: true });
    } catch (e) {
      console.error('[IMAGE-CACHE] Error creando directorio de caché:', e);
    }
  }
  return localImageDir;
}

// Iniciar servidor local HTTP en loopback (127.0.0.1)
function startLocalImageServer(cacheDir) {
  if (imageHttpServer) return;

  const mimeTypes = {
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
  };

  imageHttpServer = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    try {
      const rawUrl = req.url.split('?')[0];
      const relPath = decodeURIComponent(rawUrl.replace(/^\/+/, ''));
      const safePath = path.normalize(relPath).replace(/^(\.\.[\/\\])+/, '');
      const filePath = path.join(cacheDir, safePath);

      if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
        const ext = path.extname(filePath).toLowerCase();
        res.setHeader('Content-Type', mimeTypes[ext] || 'application/octet-stream');
        res.setHeader('Cache-Control', 'public, max-age=31536000');
        const stream = fs.createReadStream(filePath);
        stream.on('error', () => {
          if (!res.headersSent) {
            res.statusCode = 500;
            res.end('Error reading file');
          }
        });
        stream.pipe(res);
      } else {
        res.statusCode = 404;
        res.end('Not found');
      }
    } catch (err) {
      res.statusCode = 500;
      res.end('Server error');
    }
  });

  imageHttpServer.listen(0, '127.0.0.1', () => {
    imageServerPort = imageHttpServer.address().port;
    console.log(`[IMAGE-CACHE] Servidor local de imágenes activo en http://127.0.0.1:${imageServerPort}`);
  });

  imageHttpServer.on('error', (err) => {
    console.error('[IMAGE-CACHE] Error en servidor local de imágenes:', err);
  });
}

// Configurar interceptor webRequest de Electron
function setupWebRequestInterceptor(session, cacheDir) {
  if (!session || !session.defaultSession) return;

  session.defaultSession.webRequest.onBeforeRequest(
    {
      urls: [
        '*://raw.githubusercontent.com/*',
        '*://hugom1307.github.io/kvrcards-catalog/*'
      ]
    },
    (details, callback) => {
      try {
        const match = details.url.match(/kvrcards-catalog(?:\/main)?\/image\/(.+)$/i);
        if (match && imageServerPort > 0) {
          const imgSubPath = decodeURIComponent(match[1].split('?')[0]);
          const safeSubPath = path.normalize(imgSubPath).replace(/^(\.\.[\/\\])+/, '');
          const localFile = path.join(cacheDir, safeSubPath);

          if (fs.existsSync(localFile)) {
            const stat = fs.statSync(localFile);
            if (stat.isFile() && stat.size > 0) {
              const localUrl = `http://127.0.0.1:${imageServerPort}/${encodeURI(safeSubPath).replace(/#/g, '%23')}`;
              return callback({ redirectURL: localUrl });
            }
          }
        }

        // Si no está en caché local pero apunta a raw.githubusercontent.com,
        // redirigir al CDN de GitHub Pages para evitar rate limits 429
        const newUrl = details.url.replace(
          /^https?:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/main\/(.*)$/i,
          'https://$1.github.io/$2/$3'
        );
        if (newUrl !== details.url) {
          return callback({ redirectURL: newUrl });
        }
      } catch (err) {
        // En caso de excepción, continuar normalmente
      }

      callback({});
    }
  );
}

// Descargar un único archivo con soporte para redirección y reintentos
function downloadFile(url, destPath, retries = 2) {
  return new Promise((resolve, reject) => {
    const attempt = (remainingRetries) => {
      const tempPath = destPath + '.tmp';
      const proto = url.startsWith('https:') ? https : http;

      const req = proto.get(url, { headers: { 'User-Agent': 'KVRCards-App' } }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          return downloadFile(res.headers.location, destPath, remainingRetries).then(resolve).catch(reject);
        }

        if (res.statusCode !== 200) {
          res.resume();
          if (remainingRetries > 0) {
            setTimeout(() => attempt(remainingRetries - 1), 500);
          } else {
            reject(new Error(`HTTP ${res.statusCode}`));
          }
          return;
        }

        try {
          fs.mkdirSync(path.dirname(destPath), { recursive: true });
        } catch {}

        const fileStream = fs.createWriteStream(tempPath);
        res.pipe(fileStream);

        fileStream.on('finish', () => {
          fileStream.close(() => {
            try {
              if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
              fs.renameSync(tempPath, destPath);
              resolve();
            } catch (renameErr) {
              reject(renameErr);
            }
          });
        });

        fileStream.on('error', (err) => {
          try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch {}
          if (remainingRetries > 0) {
            setTimeout(() => attempt(remainingRetries - 1), 500);
          } else {
            reject(err);
          }
        });
      });

      req.on('error', (err) => {
        try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch {}
        if (remainingRetries > 0) {
          setTimeout(() => attempt(remainingRetries - 1), 500);
        } else {
          reject(err);
        }
      });

      req.setTimeout(20000, () => {
        req.destroy(new Error('Timeout'));
      });
    };

    attempt(retries);
  });
}

// Descargar una imagen intentando primero raw y luego GitHub Pages CDN
async function downloadCardImage(relPath, destPath) {
  const rawUrl = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${encodeURI(relPath)}`;
  const cdnUrl = `https://hugom1307.github.io/kvrcards-catalog/image/${encodeURI(relPath)}`;

  try {
    await downloadFile(rawUrl, destPath);
  } catch (rawErr) {
    // Si falla raw, intentar GitHub Pages CDN
    await downloadFile(cdnUrl, destPath);
  }
}

// Obtener el manifiesto de imágenes (prioriza bundled/CDN estático para evitar 429 de GitHub API)
async function fetchImageManifest(app) {
  const userDir = app.getPath('userData');
  const cacheManifestPath = path.join(userDir, 'data', 'catalog-cache', 'image-manifest.json');

  // 1. Prioridad: Manifiesto empaquetado en game-data (local, 0 latencia, 0 peticiones de red)
  const candidatePaths = [
    path.join(__dirname, '..', 'game-data', 'image-manifest.json'),
    path.join(__dirname, '..', '..', 'game-data', 'image-manifest.json'),
    path.join(process.cwd(), 'game-data', 'image-manifest.json')
  ];

  for (const p of candidatePaths) {
    try {
      if (fs.existsSync(p)) {
        const bundled = JSON.parse(fs.readFileSync(p, 'utf-8'));
        if (Array.isArray(bundled) && bundled.length > 0) return bundled;
      }
    } catch {}
  }

  // 2. Fallback: Caché previamente guardada en userData
  try {
    if (fs.existsSync(cacheManifestPath)) {
      const cached = JSON.parse(fs.readFileSync(cacheManifestPath, 'utf-8'));
      if (Array.isArray(cached) && cached.length > 0) return cached;
    }
  } catch {}

  // 3. Descargar manifiesto estático de CDN sin rate limits
  const manifestUrls = [
    'https://hugom1307.github.io/kvrcards-catalog/image-manifest.json',
    'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image-manifest.json'
  ];

  for (const mUrl of manifestUrls) {
    try {
      const list = await new Promise((resolve, reject) => {
        const proto = mUrl.startsWith('https:') ? https : http;
        proto.get(mUrl, { headers: { 'User-Agent': 'KVRCards-App' } }, (res) => {
          if (res.statusCode !== 200) {
            res.resume();
            return reject(new Error(`HTTP ${res.statusCode}`));
          }
          let d = '';
          res.on('data', chunk => d += chunk);
          res.on('end', () => {
            try {
              const json = JSON.parse(d);
              if (Array.isArray(json) && json.length > 0) resolve(json);
              else reject(new Error('Invalid manifest'));
            } catch (err) {
              reject(err);
            }
          });
        }).on('error', reject);
      });

      if (Array.isArray(list) && list.length > 0) {
        try {
          fs.mkdirSync(path.dirname(cacheManifestPath), { recursive: true });
          fs.writeFileSync(cacheManifestPath, JSON.stringify(list, null, 2), 'utf-8');
        } catch {}
        return list;
      }
    } catch {}
  }

  return [];
}

// Analizar el estado actual de la caché local comparado con el manifiesto
async function checkImageCache(app) {
  const cacheDir = getLocalImageCacheDir(app);
  const manifest = await fetchImageManifest(app);

  let downloadedCount = 0;
  let downloadedBytes = 0;
  let missingCount = 0;
  let missingBytes = 0;
  let totalBytes = 0;
  const missingFiles = [];

  for (const item of manifest) {
    totalBytes += (item.size || 0);
    const localFile = path.join(cacheDir, item.path);

    let exists = false;
    let size = 0;

    try {
      if (fs.existsSync(localFile)) {
        const st = fs.statSync(localFile);
        if (st.isFile() && st.size > 0) {
          exists = true;
          size = st.size;
        }
      }
    } catch {}

    if (exists) {
      downloadedCount++;
      downloadedBytes += size;
    } else {
      missingCount++;
      missingBytes += (item.size || 0);
      missingFiles.push(item);
    }
  }

  return {
    ok: true,
    totalFiles: manifest.length,
    downloadedCount,
    downloadedBytes,
    missingCount,
    missingBytes,
    totalBytes,
    isComplete: missingCount === 0 && manifest.length > 0,
    missingFiles
  };
}

// Descarga en paralelo con un pool de concurrencia
async function startImageCacheDownload(app, event) {
  if (isDownloading) {
    return { ok: false, error: 'Ya hay una descarga en curso.' };
  }

  isDownloading = true;
  const cacheDir = getLocalImageCacheDir(app);

  try {
    const status = await checkImageCache(app);
    const missing = status.missingFiles || [];

    if (missing.length === 0) {
      isDownloading = false;
      if (event && event.sender) {
        event.sender.send('catalog:imageCacheComplete', {
          success: true,
          downloadedCount: 0,
          totalFiles: status.totalFiles,
          alreadyComplete: true
        });
      }
      return { ok: true, alreadyComplete: true };
    }

    const totalToDownload = missing.length;
    const totalBytesToDownload = status.missingBytes;
    let completedCount = 0;
    let completedBytes = 0;
    let errorCount = 0;
    let lastProgressEmit = 0;

    const emitProgress = (currentFile) => {
      const now = Date.now();
      // Emitir como máximo cada 80ms o en el último archivo
      if (now - lastProgressEmit < 80 && completedCount < totalToDownload) return;
      lastProgressEmit = now;

      const percent = totalBytesToDownload > 0
        ? Math.min(100, (completedBytes / totalBytesToDownload) * 100)
        : Math.min(100, (completedCount / totalToDownload) * 100);

      if (event && event.sender) {
        try {
          event.sender.send('catalog:imageCacheProgress', {
            fileIndex: completedCount,
            totalFiles: totalToDownload,
            downloadedBytes: completedBytes,
            totalBytes: totalBytesToDownload,
            percent,
            currentFile: currentFile || ''
          });
        } catch {}
      }
    };

    // Pool de descarga con concurrencia 6
    const CONCURRENCY = 6;
    let queueIndex = 0;

    const worker = async () => {
      while (queueIndex < missing.length) {
        const item = missing[queueIndex++];
        const destPath = path.join(cacheDir, item.path);

        try {
          await downloadCardImage(item.path, destPath);
          completedCount++;
          completedBytes += (item.size || 0);
        } catch (err) {
          console.error(`[IMAGE-CACHE] Error descargando ${item.path}:`, err.message);
          errorCount++;
          // Aún así sumamos bytes/contador para que la barra no se quede congelada
          completedCount++;
          completedBytes += (item.size || 0);
        }

        emitProgress(path.basename(item.path));
      }
    };

    const workers = [];
    for (let i = 0; i < CONCURRENCY; i++) {
      workers.push(worker());
    }
    await Promise.all(workers);

    // Progreso final al 100%
    if (event && event.sender) {
      try {
        event.sender.send('catalog:imageCacheProgress', {
          fileIndex: totalToDownload,
          totalFiles: totalToDownload,
          downloadedBytes: totalBytesToDownload,
          totalBytes: totalBytesToDownload,
          percent: 100,
          currentFile: 'Completado'
        });

        event.sender.send('catalog:imageCacheComplete', {
          success: true,
          downloadedCount: completedCount - errorCount,
          totalFiles: status.totalFiles,
          errorCount
        });
      } catch {}
    }

    isDownloading = false;
    return { ok: true, downloadedCount: completedCount - errorCount };
  } catch (err) {
    isDownloading = false;
    console.error('[IMAGE-CACHE] Error general en descarga:', err);
    if (event && event.sender) {
      try {
        event.sender.send('catalog:imageCacheComplete', {
          success: false,
          error: err.message
        });
      } catch {}
    }
    return { ok: false, error: err.message };
  }
}

// Inicialización del módulo
function initImageCache({ app, session, ipcMain }) {
  const cacheDir = getLocalImageCacheDir(app);
  startLocalImageServer(cacheDir);
  setupWebRequestInterceptor(session, cacheDir);

  if (ipcMain) {
    ipcMain.handle('catalog:checkImageCache', async () => {
      return await checkImageCache(app);
    });

    ipcMain.handle('catalog:startImageCacheDownload', async (event) => {
      return await startImageCacheDownload(app, event);
    });
  }

  console.log('[IMAGE-CACHE] Módulo inicializado con éxito. Directorio:', cacheDir);
}

function cleanup() {
  if (imageHttpServer) {
    try {
      imageHttpServer.close();
      console.log('[IMAGE-CACHE] Servidor local cerrado.');
    } catch {}
  }
}

module.exports = {
  initImageCache,
  getLocalImageCacheDir,
  checkImageCache,
  startImageCacheDownload,
  cleanup
};
