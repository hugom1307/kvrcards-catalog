// ==================== SISTEMA DE ENTRENADORES Y BATALLA IA ====================

/**
 * Parser de JSON tolerante a errores de sintaxis comunes (comas finales, comentarios, espacios, BOM)
 */
function safeParseJson(rawText) {
  if (typeof rawText !== 'string') return rawText;
  try {
    return JSON.parse(rawText);
  } catch (initialErr) {
    try {
      let cleaned = rawText.replace(/^\uFEFF/, '');
      // 1. Quitar comentarios // y /* ... */
      cleaned = cleaned.replace(/\/\*[\s\S]*?\*\/|([^\\:]|^)\/\/.*$/gm, '$1');
      // 2. Quitar comas finales recursivamente antes de ] o }
      let prev;
      do {
        prev = cleaned;
        cleaned = cleaned.replace(/,\s*([\]}])/g, '$1');
        cleaned = cleaned.replace(/,\s*,/g, ',');
      } while (cleaned !== prev);
      return JSON.parse(cleaned);
    } catch (cleanErr) {
      console.error('[SAFE-JSON-PARSE] Error parseando JSON tras sanitizar:', cleanErr.message);
      throw initialErr;
    }
  }
}

// Entrenadores por defecto de respaldo (fallback sincronizado con el formato del catálogo remoto)
const DEFAULT_OFFLINE_TRAINERS = [
  { 
    id: 'doman_kurimonzoso',
    nombre: 'Doman Kurimonzoso', 
    titulo: 'Estratega de la Niebla',
    imagen: 'https://hugom1307.github.io/kvrcards-catalog/image/botsoffline/doman.png',
    dificultades: ['principiante', 'amateur'],
    fondo: 'https://hugom1307.github.io/kvrcards-catalog/image/fondos/fondo_ronan_hatake.png',
    song: null,
    intervaloMedias: [76, 85],
    cartasObligatorias: ['doman_kurimonzoso', 'kai_senju_icono'],
    cartasProhibidas: ['kiri_uzumaki_icono'],
    poderes: 'aleatorio'
  },
  { 
    id: 'zion_hatake', 
    nombre: 'Zion Hatake', 
    titulo: 'Maestro del Rayo',
    imagen: 'https://hugom1307.github.io/kvrcards-catalog/image/botsoffline/zion.png',
    dificultades: ['amateur', 'experimentado'],
    fondo: 'https://hugom1307.github.io/kvrcards-catalog/image/fondos/fondo_ronan_hatake.png',
    song: null,
    intervaloMedias: [79, 84],
    cartasObligatorias: ['zion_hatake', 'kinan_hatake_icono', 'betocs_hatake_icono'],
    cartasProhibidas: [],
    poderes: 'aleatorio'
  },
  { 
    id: 'tan_uzumaki', 
    nombre: 'Tan Uzumaki', 
    titulo: 'Heredero Carmesí',
    imagen: 'https://hugom1307.github.io/kvrcards-catalog/image/botsoffline/tan.png',
    dificultades: ['profesional'],
    fondo: null,
    song: null,
    intervaloMedias: [73, 87],
    cartasObligatorias: ['tan_uzumaki', 'manuel_hyuga_icono'],
    cartasProhibidas: ['kiri_uzumaki_icono'],
    poderes: 'aleatorio'
  },
  {
    id: 'shinobi_inmortal',
    nombre: 'Inmortal Shinobi',
    titulo: 'Deidad de las Sombras',
    imagen: 'https://api.dicebear.com/7.x/avataaars/svg?seed=inmo-legend',
    dificultades: ['dios-antiguo', 'inmo'],
    fondo: 'https://hugom1307.github.io/kvrcards-catalog/assets/backgrounds/inmo_arena.jpg',
    song: null,
    intervaloMedias: [90, 99],
    cartasObligatorias: ['kaguya_otsutsuki'],
    cartasProhibidas: [],
    poderes: 'aleatorio'
  }
];

window.DEFAULT_OFFLINE_TRAINERS = DEFAULT_OFFLINE_TRAINERS;
window.allTrainersCache = null;

/**
 * Carga remota directa de trainers.json desde GitHub con parser tolerante a fallos
 */
async function fetchRemoteTrainersDirectly(forceRefresh = false) {
  if (!forceRefresh && Array.isArray(window.allTrainersCache) && window.allTrainersCache.length > 0 && window.trainersLoadedFromRemote) {
    return window.allTrainersCache;
  }

  const urls = [
    `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/trainers.json?t=${Date.now()}`,
    `https://hugom1307.github.io/kvrcards-catalog/trainers.json?t=${Date.now()}`
  ];

  for (const url of urls) {
    try {
      const res = await fetch(url, { cache: 'no-store' });
      if (res.ok) {
        const text = await res.text();
        const json = safeParseJson(text);
        const list = Array.isArray(json) 
          ? json 
          : (Array.isArray(json?.trainers) ? json.trainers : (Array.isArray(json?.entrenadores) ? json.entrenadores : []));
        if (list.length > 0) {
          console.log(`[TRAINERS] ✅ ${list.length} entrenadores cargados exitosamente desde remoto (${url})`);
          window.allTrainersCache = list;
          window.trainersLoadedFromRemote = true;
          return list;
        }
      }
    } catch (e) {
      console.warn('[TRAINERS] Error parseando/cargando trainers.json desde', url, e.message);
    }
  }

  // Fallback IPC de Electron
  if (window.kvrcards && typeof window.kvrcards.getAllTrainers === 'function') {
    try {
      const ipcTrainers = await window.kvrcards.getAllTrainers();
      const arr = Array.isArray(ipcTrainers) 
        ? ipcTrainers 
        : (Array.isArray(ipcTrainers?.trainers) ? ipcTrainers.trainers : (Array.isArray(ipcTrainers?.entrenadores) ? ipcTrainers.entrenadores : []));
      if (arr.length > 0) {
        console.log(`[TRAINERS] Entrenadores cargados vía IPC (${arr.length})`);
        window.allTrainersCache = arr;
        window.trainersLoadedFromRemote = true;
        return arr;
      }
    } catch (err) {
      console.warn('[TRAINERS] Error al consultar getAllTrainers por IPC:', err);
    }
  }

  console.warn('[TRAINERS] No se pudo cargar remoto ni IPC, usando fallback temporal');
  return DEFAULT_OFFLINE_TRAINERS;
}

window.fetchRemoteTrainersDirectly = fetchRemoteTrainersDirectly;

// Precalentar caché de entrenadores en segundo plano
setTimeout(() => {
  fetchRemoteTrainersDirectly(true).catch(() => {});
}, 500);

/**
 * Algoritmo inteligente de coincidencia de cartas (soporta IDs, nombres, variantes de icono y tolerancia)
 */
function cardMatchesQuery(card, query) {
  if (!card || !query) return false;
  const qClean = String(query).toLowerCase().trim();
  const id = String(card.id || '').toLowerCase().trim();
  const name = String(card.name || card.nombre || '').toLowerCase().trim();

  // 1. Coincidencia exacta directa de ID o Nombre
  if (id === qClean || name === qClean) return true;

  // 2. Normalización sin espacios, guiones ni caracteres especiales
  const norm = s => s.replace(/[^a-z0-9]/g, '');
  const qNorm = norm(qClean);
  const idNorm = norm(id);
  const nameNorm = norm(name);
  if (idNorm === qNorm || nameNorm === qNorm) return true;

  // 3. Normalizar sufijos (_icono, _iconoprime, _iconosuperprime, _prime, _superprime)
  const stripSuffix = s => s.replace(/(iconosuperprime|iconoprime|icono|prime|superprime|notrait)$/g, '');
  const qBase = stripSuffix(qNorm);
  const idBase = stripSuffix(idNorm);

  if (qBase && idBase) {
    if (qBase === idBase) return true;
    if (idNorm.startsWith(qBase) || qNorm.startsWith(idBase)) return true;
  }

  // 4. Tolerancia vocal para variantes menores (ej. domankurimonzoso vs domankurimunzoso)
  const qVowels = qBase.replace(/[aeiou]/g, '*');
  const idVowels = idBase.replace(/[aeiou]/g, '*');
  if (qVowels.length > 8 && qVowels === idVowels) return true;

  return false;
}

/**
 * Obtener catálogo maestro de todas las cartas disponibles en el juego
 */
async function getAllAvailableCardsPool() {
  if (Array.isArray(window.allCardsCache) && window.allCardsCache.length > 0) {
    return window.allCardsCache;
  }

  if (window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
    try {
      const res = await window.kvrcards.getAllCards();
      const list = Array.isArray(res) ? res : (Array.isArray(res?.cards) ? res.cards : []);
      if (list.length > 0) {
        window.allCardsCache = list;
        return list;
      }
    } catch (e) {
      console.warn('[BATTLE-AI] Error con getAllCards IPC:', e);
    }
  }

  // Fetch directo desde GitHub si no estaba en caché
  try {
    const res = await fetch('https://hugom1307.github.io/kvrcards-catalog/cards.json?t=' + Date.now());
    if (res.ok) {
      const list = await res.json();
      if (Array.isArray(list) && list.length > 0) {
        window.allCardsCache = list;
        return list;
      }
    }
  } catch (e) {}

  if (Array.isArray(window.teamBuilderCards) && window.teamBuilderCards.length > 0) {
    const map = new Map();
    window.teamBuilderCards.forEach(c => {
      if (c && c.id && !map.has(c.id)) map.set(c.id, c);
    });
    return Array.from(map.values());
  }

  return [];
}

/**
 * Selecciona un entrenador acorde a la dificultad solicitada
 */
function selectTrainerForDifficulty(difficulty, trainersList) {
  const targetDiff = String(difficulty || 'principiante').toLowerCase().trim();
  const list = Array.isArray(trainersList) && trainersList.length > 0 ? trainersList : DEFAULT_OFFLINE_TRAINERS;

  const eligible = list.filter(t => {
    if (!t) return false;
    const diffs = t.dificultades || t.dificultad || t.difficulties || t.difficulty;
    if (!diffs) return true; // Si no especifica dificultad, puede salir en cualquiera
    if (Array.isArray(diffs)) {
      return diffs.some(d => {
        const norm = String(d).toLowerCase().trim();
        return norm === targetDiff || norm === 'todas' || norm === 'all' || norm === '*';
      });
    } else if (typeof diffs === 'string') {
      const norm = diffs.toLowerCase().trim();
      return norm === targetDiff || norm === 'todas' || norm === 'all' || norm === '*';
    }
    return false;
  });

  if (eligible.length > 0) {
    const chosen = eligible[Math.floor(Math.random() * eligible.length)];
    console.log(`[TRAINERS] 🎯 Entrenador seleccionado para '${targetDiff}':`, chosen.nombre || chosen.name);
    return chosen;
  }

  console.warn(`[TRAINERS] No se encontró entrenador configurado para dificultad '${targetDiff}'. Generando perfil estándar.`);
  const defaultProfiles = {
    'principiante': { nombre: 'Novato', titulo: '(Principiante)', seed: 'rookie', intervaloMedias: [60, 75] },
    'amateur': { nombre: 'Bot Amateur', titulo: '(Amateur)', seed: 'challenger', intervaloMedias: [70, 80] },
    'experimentado': { nombre: 'Veterano', titulo: '(Experimentado)', seed: 'veteran', intervaloMedias: [78, 85] },
    'profesional': { nombre: 'Maestro', titulo: '(Profesional)', seed: 'master', intervaloMedias: [83, 90] },
    'dios-antiguo': { nombre: 'Leyenda', titulo: '(Dios Antiguo)', seed: 'legend', intervaloMedias: [88, 95] },
    'inmo': { nombre: 'INMO', titulo: '(INMO)', seed: 'inmo', intervaloMedias: [92, 99] }
  };

  const profile = defaultProfiles[targetDiff] || { nombre: 'Oponente', titulo: '(IA)', seed: 'opponent', intervaloMedias: [70, 85] };
  return {
    id: `fallback_${targetDiff}`,
    nombre: profile.nombre,
    titulo: profile.titulo,
    imagen: `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile.seed}`,
    dificultades: [targetDiff],
    intervaloMedias: profile.intervaloMedias,
    cartasObligatorias: [],
    cartasProhibidas: []
  };
}

/**
 * Resuelve la lista de poderes del entrenador rival (manual o aleatorio).
 * Admite:
 * - "aleatorio" o "random" (elige 3 poderes aleatorios distintos de la lista disponible)
 * - ["aleatorio"] o ["random"]
 * - ["reserva", "aleatorio", "aleatorio"] (mezcla de específicos y aleatorios)
 * - Array manual de poderes: ["reserva", "powerup", "nerf"], ["anulo", "intercambio"], etc.
 * - String manual: "reserva, powerup, anulo"
 * - null / undefined / omitido: por defecto ['reserva', 'powerup', 'nerf']
 */
function resolveTrainerPowers(rawPowers) {
  const ALL_POWERS = ['reserva', 'powerup', 'nerf', 'anulo', 'intercambio'];

  const getRandomPowers = (count = 3) => {
    const safeCount = Math.min(ALL_POWERS.length, Math.max(1, parseInt(count, 10) || 3));
    const shuffled = [...ALL_POWERS].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, safeCount);
  };

  const normalize = (p) => {
    if (!p) return null;
    const s = String(p).toLowerCase().trim();
    if (['swap', 'reserva', 'reserve_card', 'reserve'].includes(s)) return 'reserva';
    if (['powerup', 'power_up', 'buff'].includes(s)) return 'powerup';
    if (['nerf', 'debuff'].includes(s)) return 'nerf';
    if (['anulo', 'anular', 'cancel'].includes(s)) return 'anulo';
    if (['intercambio', 'exchange', 'swap_cards'].includes(s)) return 'intercambio';
    return s;
  };

  const isRandomKeyword = (val) => {
    if (!val) return false;
    const s = String(val).toLowerCase().trim();
    return s === 'aleatorio' || s === 'random' || /^aleatorio\(\d+\)$/.test(s) || /^random\(\d+\)$/.test(s);
  };

  // Si no se proporcionó nada (omitido, null, undefined, vacío), por defecto es ALEATORIO (3 poderes aleatorios)
  if (rawPowers === null || rawPowers === undefined || rawPowers === '') {
    return getRandomPowers(3);
  }

  // Si es un string
  if (typeof rawPowers === 'string') {
    const s = rawPowers.toLowerCase().trim();
    if (isRandomKeyword(s)) {
      const match = s.match(/(?:aleatorio|random)\((\d+)\)/);
      const count = match ? match[1] : 3;
      return getRandomPowers(count);
    }
    // Si viene separado por comas: "reserva, anulo, nerf"
    if (s.includes(',')) {
      return resolveTrainerPowers(s.split(',').map(x => x.trim()));
    }
    const norm = normalize(s);
    return norm ? [norm] : getRandomPowers(3);
  }

  // Si es un array
  if (Array.isArray(rawPowers)) {
    if (rawPowers.length === 0) {
      return getRandomPowers(3);
    }

    // Si es un array con un único elemento "aleatorio"
    if (rawPowers.length === 1 && isRandomKeyword(rawPowers[0])) {
      const s = String(rawPowers[0]).toLowerCase().trim();
      const match = s.match(/(?:aleatorio|random)\((\d+)\)/);
      const count = match ? match[1] : 3;
      return getRandomPowers(count);
    }

    const result = [];
    const used = new Set();

    // 1. Primero añadir los poderes fijos manuales
    for (const item of rawPowers) {
      if (!isRandomKeyword(item)) {
        const norm = normalize(item);
        if (norm && !used.has(norm)) {
          result.push(norm);
          used.add(norm);
        }
      }
    }

    // 2. Rellenar los slots que pidieron "aleatorio"
    const unusedPool = ALL_POWERS.filter(p => !used.has(p)).sort(() => Math.random() - 0.5);
    for (const item of rawPowers) {
      if (isRandomKeyword(item)) {
        if (unusedPool.length > 0) {
          const picked = unusedPool.pop();
          result.push(picked);
          used.add(picked);
        }
      }
    }

    return result.length > 0 ? result : getRandomPowers(3);
  }

  return getRandomPowers(3);
}

/**
 * Construye el equipo del entrenador respetando cartas obligatorias, prohibidas e intervalo de medias
 */
function buildTrainerDeck(trainer, allCardsPool) {
  const isEvoCard = c => {
    const q = String(c.calidad || c.quality || c.calidadId || '').trim().toLowerCase();
    return q === 'evo';
  };

  // Base limpia de cartas del catálogo (sin evoluciones directas como base)
  const basePool = (Array.isArray(allCardsPool) ? allCardsPool : []).filter(c => c && c.id && !isEvoCard(c));

  // 1. Configuración de cartas prohibidas
  const rawForbidden = trainer.cartasProhibidas || trainer.excludedCards || trainer.cartasNunca || trainer.mustExclude || [];
  const forbiddenList = (Array.isArray(rawForbidden) ? rawForbidden : [rawForbidden])
    .map(x => String(x || '').trim())
    .filter(Boolean);

  const isForbidden = card => {
    if (!card) return true;
    return forbiddenList.some(f => cardMatchesQuery(card, f));
  };

  // 2. Configuración de intervalo de medias
  // Si solo hay un número (ej. [85], 85, o {min: 85}), se interpreta como mínimo y no tiene máximo (Infinity)
  let minMedia = -Infinity;
  let maxMedia = Infinity;
  const rawInterval = trainer.intervaloMedias !== undefined 
    ? trainer.intervaloMedias 
    : (trainer.mediaRange !== undefined ? trainer.mediaRange : trainer.rangoMedias);

  if (Array.isArray(rawInterval)) {
    if (rawInterval.length === 1 || (rawInterval.length >= 2 && (rawInterval[1] === null || rawInterval[1] === undefined || rawInterval[1] === ''))) {
      const parsedMin = Number(rawInterval[0]);
      minMedia = isNaN(parsedMin) ? -Infinity : parsedMin;
      maxMedia = Infinity;
    } else if (rawInterval.length >= 2) {
      const parsedMin = Number(rawInterval[0]);
      const parsedMax = Number(rawInterval[1]);
      minMedia = isNaN(parsedMin) ? -Infinity : parsedMin;
      maxMedia = isNaN(parsedMax) ? Infinity : parsedMax;
    }
  } else if (typeof rawInterval === 'number') {
    minMedia = Number(rawInterval);
    maxMedia = Infinity;
  } else if (typeof rawInterval === 'string') {
    const trimmed = rawInterval.trim();
    if (trimmed.includes('-') || trimmed.includes(',')) {
      const parts = trimmed.split(/[-,\/]/).map(p => p.trim()).filter(Boolean);
      if (parts.length === 1) {
        const parsedMin = Number(parts[0]);
        minMedia = isNaN(parsedMin) ? -Infinity : parsedMin;
        maxMedia = Infinity;
      } else if (parts.length >= 2) {
        const parsedMin = Number(parts[0]);
        const parsedMax = Number(parts[1]);
        minMedia = isNaN(parsedMin) ? -Infinity : parsedMin;
        maxMedia = isNaN(parsedMax) ? Infinity : parsedMax;
      }
    } else {
      const parsedNum = Number(trimmed.replace(/[+]/g, ''));
      if (!isNaN(parsedNum)) {
        minMedia = parsedNum;
        maxMedia = Infinity;
      }
    }
  } else if (rawInterval && typeof rawInterval === 'object') {
    if (rawInterval.min !== undefined) {
      const parsedMin = Number(rawInterval.min);
      minMedia = isNaN(parsedMin) ? -Infinity : parsedMin;
    }
    if (rawInterval.max !== undefined) {
      const parsedMax = Number(rawInterval.max);
      maxMedia = isNaN(parsedMax) ? Infinity : parsedMax;
    }
  } else {
    if (trainer.minMedia !== undefined) {
      const parsedMin = Number(trainer.minMedia);
      minMedia = isNaN(parsedMin) ? -Infinity : parsedMin;
    }
    if (trainer.maxMedia !== undefined) {
      const parsedMax = Number(trainer.maxMedia);
      maxMedia = isNaN(parsedMax) ? Infinity : parsedMax;
    }
  }

  // Corregir si se colocaron al revés accidentalmente
  if (Number.isFinite(minMedia) && Number.isFinite(maxMedia) && minMedia > maxMedia) {
    const temp = minMedia;
    minMedia = maxMedia;
    maxMedia = temp;
  }

  const maxDisplay = maxMedia === Infinity ? '∞ (sin máximo)' : maxMedia;
  console.log(`[TRAINER-DECK] Entrenador: ${trainer.nombre || trainer.name}. Intervalo medias: [${minMedia}, ${maxDisplay}]. Prohibidas: ${forbiddenList.length}`);

  const pickedCards = [];
  const pickedIds = new Set();

  const cleanCard = (c) => ({
    ...c,
    uniqueId: undefined,
    instanceId: undefined,
    hasTrait: false,
    opponentTraitId: null
  });

  // 3. Añadir cartas obligatorias (SIEMPRE se incluyen en el equipo si existen y no están prohibidas)
  const rawMandatory = trainer.cartasObligatorias || trainer.guaranteedCards || trainer.cartasSiempre || trainer.mustInclude || [];
  const mandatoryList = (Array.isArray(rawMandatory) ? rawMandatory : [rawMandatory])
    .map(x => String(x || '').trim())
    .filter(Boolean);

  for (const mQuery of mandatoryList) {
    if (pickedCards.length >= 8) break;
    const matches = basePool.filter(c => cardMatchesQuery(c, mQuery) && !isForbidden(c) && !pickedIds.has(c.id));
    if (matches.length > 0) {
      // Priorizar coincidencia exacta de ID si la hay, sino la primera
      const exact = matches.find(c => String(c.id).toLowerCase() === mQuery.toLowerCase()) || matches[0];
      pickedCards.push(cleanCard(exact));
      pickedIds.add(exact.id);
      console.log(`[TRAINER-DECK] ✅ Carta obligatoria incluida: ${exact.name || exact.nombre} (ID: ${exact.id}, Media: ${exact.media})`);
    } else {
      console.warn(`[TRAINER-DECK] ⚠️ Carta obligatoria '${mQuery}' no encontrada en el catálogo o está prohibida.`);
    }
  }

  // 4. Filtrar candidatas para los puestos restantes que cumplan ESTRICTAMENTE el intervalo de medias
  const candidatePool = basePool.filter(c => {
    if (pickedIds.has(c.id)) return false;
    if (isForbidden(c)) return false;
    const m = Number(c.media || c.overall || 0);
    return m >= minMedia && (maxMedia === Infinity ? true : m <= maxMedia);
  });

  console.log(`[TRAINER-DECK] Candidatas disponibles en rango [${minMedia}, ${maxDisplay}]: ${candidatePool.length}`);

  // Barajar candidatas aleatoriamente
  const shuffledCandidates = [...candidatePool].sort(() => Math.random() - 0.5);

  while (pickedCards.length < 8 && shuffledCandidates.length > 0) {
    const choice = shuffledCandidates.pop();
    pickedCards.push(cleanCard(choice));
    pickedIds.add(choice.id);
  }

  // 5. Fallback de contingencia: solo si el intervalo no tiene suficientes cartas para completar 8
  if (pickedCards.length < 8) {
    console.warn(`[TRAINER-DECK] Rango [${minMedia}, ${maxDisplay}] insuficiente para 8 cartas. Rellenando con cartas más próximas.`);
    const targetMid = (Number.isFinite(minMedia) && Number.isFinite(maxMedia)) 
      ? (minMedia + maxMedia) / 2 
      : (Number.isFinite(minMedia) ? minMedia : (Number.isFinite(maxMedia) ? maxMedia : 80));

    const remainingPool = basePool
      .filter(c => !pickedIds.has(c.id) && !isForbidden(c))
      .sort((a, b) => {
        const diffA = Math.abs(Number(a.media || 0) - targetMid);
        const diffB = Math.abs(Number(b.media || 0) - targetMid);
        return diffA - diffB;
      });

    while (pickedCards.length < 8 && remainingPool.length > 0) {
      const choice = remainingPool.shift();
      pickedCards.push(cleanCard(choice));
      pickedIds.add(choice.id);
    }
  }

  const activeTeam = pickedCards.slice(0, 7);
  const reserveCard = pickedCards[7] || null;

  const mediasSummary = pickedCards.map(c => Number(c.media || 0));
  console.log(`[TRAINER-DECK] ✅ Mazo generado (${pickedCards.length} cartas):`, mediasSummary.join(', '));

  return { activeTeam, reserveCard };
}

/**
 * Calcula el intervalo de media [minMedia, maxMedia] para un piso dado del Modo Infinito:
 * - Piso 1: [60, 66]
 * - Cada 2 niveles (3, 5, 7, 9...): max +2
 * - Mini-boss (5, 15, 25...): min +4
 * - Boss (10, 20, 30...): min +4
 * - Pisos 21 a 50: escalado progresivo suave hasta alcanzar exactamente [86, 92] en piso 50.
 * - Pisos > 50: sin límite superior [min, Infinity], empezando en 86 y sumando +1 cada 5 pisos.
 */
function getInfiniteFloorMediaInterval(floorNumber) {
  const floor = Math.max(1, parseInt(floorNumber, 10) || 1);

  if (floor <= 20) {
    let min = 60;
    let max = 66;
    for (let f = 1; f <= floor; f++) {
      if (f > 1 && f % 2 === 1) max += 2;
      if (f > 1 && f % 5 === 0) min += 4;
    }
    return { min, max };
  }

  if (floor <= 50) {
    const p = floor - 20; // 1 a 30
    const min = 76 + Math.floor((p + 2) / 3);
    let max;
    if (p <= 4) max = 85;
    else if (p <= 8) max = 86;
    else if (p <= 12) max = 87;
    else if (p <= 16) max = 88;
    else if (p <= 20) max = 89;
    else if (p <= 24) max = 90;
    else if (p <= 27) max = 91;
    else max = 92;

    return { min, max };
  }

  // Piso 51+: sin límite superior, mínimo aumenta +1 cada 5 pisos (86 en 51-55, 87 en 56-60, etc.)
  const extraSteps = Math.floor((floor - 51) / 5);
  const min = Math.min(95, 86 + extraSteps);
  return { min, max: Infinity };
}

window.getInfiniteFloorMediaInterval = getInfiniteFloorMediaInterval;

/**
 * Función principal para generar el equipo oponente
 */
async function generateOpponentTeam() {
  console.log('[BATTLE] Generando equipo oponente para dificultad:', window.battleState.difficulty);

  const infiniteContext = window.__infiniteBattleContext && window.__infiniteBattleContext.active
    ? window.__infiniteBattleContext
    : null;

  let opponentTeamBase = [];
  let opponentReserveBase = null;

  if (infiniteContext) {
    // ==================== MODO INFINITO: INTERVALOS DE MEDIA POR PISO ====================
    const floor = Math.max(1, parseInt(infiniteContext.floor, 10) || 1);
    const interval = getInfiniteFloorMediaInterval(floor);
    const minMedia = interval.min;
    const maxMedia = interval.max;

    console.log(`[INFINITE-BATTLE] Piso ${floor} -> Intervalo de Media del Rival: [${minMedia}, ${maxMedia === Infinity ? '∞' : maxMedia}]`);

    const baseCards = (Array.isArray(window.teamBuilderCards) ? window.teamBuilderCards : [])
      .filter(c => !c.hasTrait)
      .map(c => ({
        ...c,
        uniqueId: undefined,
        instanceId: undefined
      }));

    // Pool único de cartas sin duplicados por id
    const uniquePool = [...baseCards].filter((card, index, arr) => arr.findIndex(c => c.id === card.id) === index);

    // Filtrar candidatos estrictamente en el intervalo [minMedia, maxMedia]
    let candidates = uniquePool.filter(c => {
      const m = Number(c.media || 0);
      return m >= minMedia && (maxMedia === Infinity ? true : m <= maxMedia);
    });

    // Si hay menos de 8 candidatos únicos (ej. pisos muy altos o catálogo filtrado),
    // ampliar progresivamente hacia abajo para asegurar cartas sin romper el juego
    let searchMin = minMedia;
    while (candidates.length < 8 && searchMin > 45) {
      searchMin -= 1;
      candidates = uniquePool.filter(c => {
        const m = Number(c.media || 0);
        return m >= searchMin && (maxMedia === Infinity ? true : m <= maxMedia);
      });
    }

    // Barajar aleatoriamente los candidatos dentro del intervalo
    const candidatePool = [...candidates].sort(() => Math.random() - 0.5);
    const picked = [];

    // Seleccionar 8 cartas aleatorias únicas dentro del rango
    for (let i = 0; i < candidatePool.length && picked.length < 8; i++) {
      picked.push({ ...candidatePool[i] });
    }

    // Fallback de seguridad si el catálogo total tuviera menos de 8 cartas
    if (picked.length < 8) {
      const fallbackPool = [...uniquePool].sort(() => Math.random() - 0.5);
      for (const card of fallbackPool) {
        if (picked.length >= 8) break;
        if (!picked.some(p => p.id === card.id)) {
          picked.push({ ...card });
        }
      }
      while (picked.length < 8 && picked.length > 0) {
        picked.push({ ...picked[picked.length % picked.length] });
      }
    }

    opponentTeamBase = picked.slice(0, 7);
    opponentReserveBase = picked[7] || null;

    const avg = picked.reduce((sum, card) => sum + Number(card.media || 0), 0) / Math.max(1, picked.length);
    console.log(`[INFINITE-BATTLE] Rival generado para Piso ${floor} (${picked.length} cartas): Rango [${minMedia}, ${maxMedia === Infinity ? '∞' : maxMedia}], Media real: ${avg.toFixed(2)}`);
    console.log('[INFINITE-BATTLE] Cartas del rival:', picked.map(c => `${c.name} (${c.media})`).join(', '));

    window.battleState.opponentName = infiniteContext.trainerName || `Entrenador Piso ${infiniteContext.floor || 1}`;
    window.battleState.opponentTitle = `(Piso ${infiniteContext.floor || 1})`;
    window.battleState.opponentAvatar = infiniteContext.trainerImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=infinite-${infiniteContext.floor || 1}`;
    window.battleState.opponentBackground = null;
    window.battleState.opponentSong = infiniteContext.battleSong || infiniteContext.opponentSong || null;
    window.battleState.selectedTrainer = null;

    // Asignar traits al rival en Modo Infinito (solo piso >= 50 puede tener legendarios y miticos)
    const rawInfiniteTraits = Array.isArray(availableTraits) && availableTraits.length > 0
      ? availableTraits
      : (Array.isArray(window.battleState.availableTraits) ? window.battleState.availableTraits : []);
    const infiniteTraitsList = floor >= 50
      ? rawInfiniteTraits
      : rawInfiniteTraits.filter(t => t && t.rarity !== 'legendary' && t.rarity !== 'mythic');

    window.battleState.opponentTeam = opponentTeamBase.map(card => {
      if (Math.random() < 0.3 && infiniteTraitsList.length > 0) {
        const randomTrait = infiniteTraitsList[Math.floor(Math.random() * infiniteTraitsList.length)];
        return {
          ...card,
          uniqueId: `infinite_bot_trait_${Date.now()}_${Math.random()}`,
          opponentTraitId: randomTrait.id,
          hasTrait: true
        };
      }
      return { ...card, hasTrait: false, opponentTraitId: null };
    });

    if (opponentReserveBase) {
      if (Math.random() < 0.3 && infiniteTraitsList.length > 0) {
        const randomTrait = infiniteTraitsList[Math.floor(Math.random() * infiniteTraitsList.length)];
        window.battleState.opponentReserveCard = {
          ...opponentReserveBase,
          uniqueId: `infinite_bot_trait_${Date.now()}_${Math.random()}`,
          opponentTraitId: randomTrait.id,
          hasTrait: true
        };
      } else {
        window.battleState.opponentReserveCard = { ...opponentReserveBase, hasTrait: false, opponentTraitId: null };
      }
    } else {
      window.battleState.opponentReserveCard = null;
    }
  } else {
    // ==================== MODO OFFLINE CLÁSICO (SISTEMA DE ENTRENADORES DINÁMICO) ====================
    const currentDiff = window.battleState.difficulty || window.selectedDifficulty || 'principiante';
    
    // Cargar entrenadores y catálogo de cartas (forzar refresh si aún no se había cargado de remoto)
    const [trainersList, allCardsPool] = await Promise.all([
      fetchRemoteTrainersDirectly(!window.trainersLoadedFromRemote),
      getAllAvailableCardsPool()
    ]);

    // Seleccionar entrenador para la dificultad
    const selectedTrainer = selectTrainerForDifficulty(currentDiff, trainersList);
    window.battleState.selectedTrainer = selectedTrainer;

    // Configurar identidad del rival y fondo personalizado
    window.battleState.opponentName = selectedTrainer.nombre || selectedTrainer.name || getOpponentName(currentDiff);
    window.battleState.opponentTitle = selectedTrainer.titulo || selectedTrainer.title || getOpponentTitle(currentDiff);
    window.battleState.opponentAvatar = selectedTrainer.imagen || selectedTrainer.avatar || selectedTrainer.image || getOpponentAvatar(currentDiff);
    window.battleState.opponentBackground = selectedTrainer.fondo || selectedTrainer.fondoBatalla || selectedTrainer.battleBackground || selectedTrainer.background || null;

    // Canción / música de batalla personalizada del entrenador (opcional en trainers.json)
    const rawSong = selectedTrainer.song || selectedTrainer.cancion || selectedTrainer.musica || selectedTrainer.battleSong || selectedTrainer.battleMusic || null;
    window.battleState.opponentSong = (typeof rawSong === 'string' && rawSong.trim()) ? rawSong.trim() : null;

    // Configurar poderes personalizados del entrenador (manual o aleatorio en trainers.json)
    const rawTrainerPowers = selectedTrainer.poderes || selectedTrainer.powers;
    window.battleState.opponentPowers = resolveTrainerPowers(rawTrainerPowers);

    console.log('[BATTLE] 🎭 Entrenador configurado:', {
      nombre: window.battleState.opponentName,
      titulo: window.battleState.opponentTitle,
      avatar: window.battleState.opponentAvatar,
      fondo: window.battleState.opponentBackground,
      cancion: window.battleState.opponentSong,
      poderes: window.battleState.opponentPowers
    });

    // Construir mazo según especificaciones del entrenador
    const deckResult = buildTrainerDeck(selectedTrainer, allCardsPool);
    opponentTeamBase = deckResult.activeTeam;
    opponentReserveBase = deckResult.reserveCard;

    // Asignar traits aleatorios a algunas cartas del oponente (30% de probabilidad)
    // REGLA: Los bots offline NUNCA pueden recibir traits legendarios ni miticos
    const traitsList = (Array.isArray(availableTraits) && availableTraits.length > 0
      ? availableTraits
      : (Array.isArray(window.battleState.availableTraits) ? window.battleState.availableTraits : []))
      .filter(t => t && t.rarity !== 'legendary' && t.rarity !== 'mythic');

    window.battleState.opponentTeam = opponentTeamBase.map(card => {
      if (Math.random() < 0.3 && traitsList.length > 0) {
        const randomTrait = traitsList[Math.floor(Math.random() * traitsList.length)];
        return {
          ...card,
          uniqueId: `opponent_trait_${Date.now()}_${Math.random()}`,
          opponentTraitId: randomTrait.id,
          hasTrait: true
        };
      }
      return card;
    });

    if (opponentReserveBase && Math.random() < 0.3 && traitsList.length > 0) {
      const randomTrait = traitsList[Math.floor(Math.random() * traitsList.length)];
      window.battleState.opponentReserveCard = {
        ...opponentReserveBase,
        uniqueId: `opponent_trait_${Date.now()}_${Math.random()}`,
        opponentTraitId: randomTrait.id,
        hasTrait: true
      };
    } else {
      window.battleState.opponentReserveCard = opponentReserveBase;
    }
  }

  console.log('[BATTLE] Oponente final preparado:', window.battleState.opponentName);

  // Calcular buffeos del oponente (SOLO procedencia, NO owner para bots)
  const opponentBuffsData = calculateBattleBuffs(window.battleState.opponentTeam);
  window.battleState.opponentBuffs = {
    buffs: opponentBuffsData.buffs.filter(buff => !buff.isOwnerBuff),
    byProcedencia: opponentBuffsData.byProcedencia,
    byOwner: {}
  };
}

// Obtener nombre del oponente según dificultad
function getOpponentName(difficulty) {
  if (window.__infiniteBattleContext?.active && window.__infiniteBattleContext?.trainerName) {
    return window.__infiniteBattleContext.trainerName;
  }

  if (window.battleState?.opponentName) {
    return window.battleState.opponentName;
  }

  const names = {
    'principiante': 'Novato',
    'amateur': 'Bot Amateur',
    'experimentado': 'Veterano',
    'profesional': 'Maestro',
    'dios-antiguo': 'Leyenda',
    'inmo': 'INMO'
  };
  return names[difficulty] || 'Oponente';
}

// Obtener título/nivel del oponente
function getOpponentTitle(difficulty) {
  if (window.__infiniteBattleContext?.active) {
    const floor = window.__infiniteBattleContext.floor || 1;
    return `(Piso ${floor})`;
  }

  if (window.battleState?.opponentTitle) {
    return window.battleState.opponentTitle;
  }

  const titles = {
    'principiante': '(Principiante)',
    'amateur': '(Amateur)',
    'experimentado': '(Experimentado)',
    'profesional': '(Profesional)',
    'dios-antiguo': '(Dios Antiguo)',
    'inmo': '(INMO)'
  };
  return titles[difficulty] || '(IA)';
}

// Obtener avatar del oponente según dificultad
function getOpponentAvatar(difficulty) {
  if (window.__infiniteBattleContext?.active && window.__infiniteBattleContext?.trainerImage) {
    return window.__infiniteBattleContext.trainerImage;
  }

  if (window.battleState?.opponentAvatar) {
    return window.battleState.opponentAvatar;
  }

  const seeds = {
    'principiante': 'rookie',
    'amateur': 'challenger',
    'experimentado': 'veteran',
    'profesional': 'master',
    'dios-antiguo': 'legend',
    'inmo': 'inmo'
  };
  return `https://api.dicebear.com/7.x/avataaars/svg?seed=${seeds[difficulty] || 'opponent'}`;
}

// Obtener fondo de batalla personalizado del oponente
function getOpponentBackground() {
  return window.battleState?.opponentBackground || null;
}

window.generateOpponentTeam = generateOpponentTeam;
window.getOpponentName = getOpponentName;
window.getOpponentTitle = getOpponentTitle;
window.getOpponentAvatar = getOpponentAvatar;
window.getOpponentBackground = getOpponentBackground;
window.resolveTrainerPowers = resolveTrainerPowers;



// ==================== NUEVO SISTEMA DE JUGABILIDAD ====================

// Iniciar la ruleta para decidir quién empieza
