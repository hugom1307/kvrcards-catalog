// ============================================
// SISTEMA DE PLUSHIES Y FAMILIARES KVR
// ============================================

(function () {
  'use strict';

  var plushiesCatalog = [];
  var plushiesCatalogMap = new Map();
  var evoPlushiesCatalog = [];
  var userPlushies = {};
  var isCatalogLoading = false;

  // Catálogo base de respaldo
  var DEFAULT_PLUSHIES_FALLBACK = [
    {
      id: 'inpu',
      nombre: 'Inpu',
      descripcion: 'Tatsu de Jenue. Familiar exclusivo para Jenue.',
      foto: './assets/plushies/inpu.png',
      ownerId: ['jenue_cota', 'jenue_icono', 'jenue_bogai', 'jenue'],
      universal: false,
      buff: [
        { stat1: 10 },
        { stat2: 5 }
      ]
    },
    {
      id: 'omni_plushie',
      nombre: 'Omni Plushie',
      descripcion: 'Familiar universal compatible con cualquier carta del juego, con mecánicas de desgaste y durabilidad por uso.',
      foto: './assets/plushies/omni_phase1.png',
      universal: true,
      totalPartidas: 16,
      fases: [
        {
          fase: 1,
          rangoUso: '100%-75%',
          partidas: 4,
          imagen: './assets/plushies/omni_phase1.png',
          buffs: { stat1: 15, stat2: 10 }
        },
        {
          fase: 2,
          rangoUso: '75%-50%',
          partidas: 4,
          imagen: './assets/plushies/omni_phase2.png',
          buffs: { stat1: 10, stat2: 5 }
        },
        {
          fase: 3,
          rangoUso: '50%-25%',
          partidas: 4,
          imagen: './assets/plushies/omni_phase3.png',
          buffs: { stat1: 5, stat2: 0 }
        },
        {
          fase: 4,
          rangoUso: '25%-0%',
          partidas: 4,
          imagen: './assets/plushies/omni_phase4.png',
          buffs: { stat1: -10, stat2: -5 },
          vendible: true,
          precioVentaCoins: 1000
        }
      ]
    }
  ];

  var DEFAULT_EVO_PLUSHIES_FALLBACK = [
    {
      id: 'plushie_inpu',
      name: 'Plushie: Inpu',
      description: 'Tatsu de Jenue. Familiar exclusivo para Jenue.',
      plushieId: 'inpu',
      cardIds: ['jenue_bogai'],
      targetCardName: 'Jenue Bogai',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/inpuplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'inpu',
        name: 'Inpu',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/inpuplushie.png'
      }
    },
    {
      id: 'plushie_tsukiro',
      name: 'Plushie: Tsukiro',
      description: 'Vive en tu propia mente. Familiar exclusivo para Fuutaro.',
      plushieId: 'tsukiro',
      cardIds: ['raiden_fuutaro'],
      targetCardName: 'Raiden Fuutaro',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/fuutaroplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'tsukiro',
        name: 'Tsukiro',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/fuutaroplushie.png'
      }
    },
    {
      id: 'plushie_lilia',
      name: 'Plushie: Lilia',
      description: 'Una niña inofensiva. Familiar exclusivo para Ken.',
      plushieId: 'lilia',
      cardIds: ['ken_inazuma'],
      targetCardName: 'Ken Inazuma',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/kenplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'lilia',
        name: 'Lilia',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/kenplushie.png'
      }
    },
    {
      id: 'plushie_yuri',
      name: 'Plushie: Yuri',
      description: 'Un amor accidentado. Familiar exclusivo para Kenji.',
      plushieId: 'yuri',
      cardIds: ['kenji_ikari'],
      targetCardName: 'Kenji Ikari',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/kenjiplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'yuri',
        name: 'Yuri',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/kenjiplushie.png'
      }
    },
    {
      id: 'plushie_nagare',
      name: 'Plushie: Nagare',
      description: 'El hermano que nadie querría tener. Familiar exclusivo para Mikori.',
      plushieId: 'nagare',
      cardIds: ['mikori_fukasa'],
      targetCardName: 'Mikori Fukasa',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/mikoriplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'nagare',
        name: 'Nagare',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/mikoriplushie.png'
      }
    },
    {
      id: 'plushie_jimmy',
      name: 'Plushie: Jimmy',
      description: 'El mejor perro de la historia. Familiar exclusivo para Sekitan.',
      plushieId: 'jimmy',
      cardIds: ['sekitan'],
      targetCardName: 'Sekitan',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/sekitanplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'jimmy',
        name: 'Jimmy',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/sekitanplushie.png'
      }
    },
    {
      id: 'plushie_ransu',
      name: 'Plushie: Ransu',
      description: '\'Hermano, ahora verás a través de mis ojos\'. Familiar exclusivo para Ronan.',
      plushieId: 'ransu',
      cardIds: ['ronan_hatake'],
      targetCardName: 'Ronan Hatake',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/ronanplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'ransu',
        name: 'Ransu',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/ronanplushie.png'
      }
    },
    {
      id: 'plushie_haji',
      name: 'Plushie: Haji',
      description: 'El maestro del cual heredamos la voluntad del fuego. Familiar exclusivo para Sukui.',
      plushieId: 'haji',
      cardIds: ['sukui_uzumaki'],
      targetCardName: 'Sukui Uzumaki',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/sukuiplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'haji',
        name: 'Haji',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/sukuiplushie.png'
      }
    },
    {
      id: 'plushie_mascaras',
      name: 'Plushie: Las 3 máscaras',
      description: 'Una técnica que representa los sentimientos más profundos. Familiar exclusivo para Taka.',
      plushieId: 'mascaras',
      cardIds: ['taka_uzumaki'],
      targetCardName: 'Taka Uzumaki',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/takaplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'mascaras',
        name: 'Las 3 máscaras',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/takaplushie.png'
      }
    },
    {
      id: 'plushie_toshiro',
      name: 'Plushie: Toshiro',
      description: 'Nada como un buen compañero de trabajo. Familiar exclusivo para Vivar.',
      plushieId: 'toshiro',
      cardIds: ['vivar'],
      targetCardName: 'Vivar',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/vivarplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'toshiro',
        name: 'Toshiro',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/vivarplushie.png'
      }
    },
    {
      id: 'plushie_ryuki',
      name: 'Plushie: Ryuki',
      description: '\'Padre, ¿dónde has estado?\'. Familiar exclusivo para Aya.',
      plushieId: 'ryuki',
      cardIds: ['aya'],
      targetCardName: 'Aya',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/ayaplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'ryuki',
        name: 'Ryuki',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/ayaplushie.png'
      }
    },
    {
      id: 'plushie_kyo',
      name: 'Plushie: Kyo',
      description: 'Nada como una hydra para que te enseñe a pelear. Familiar exclusivo para Mamoru.',
      plushieId: 'kyo',
      cardIds: ['mamoru'],
      targetCardName: 'Mamoru',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/mamoruplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'kyo',
        name: 'Kyo',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/mamoruplushie.png'
      }
    },
    {
      id: 'plushie_kai',
      name: 'Plushie: Kai',
      description: 'De kazekage a kazekage. Familiar exclusivo para Kurai.',
      plushieId: 'kai',
      cardIds: ['kurai_tenro'],
      targetCardName: 'Kurai Tenro',
      imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/kuraiplushie.png',
      requirements: {
        prestigeLevel: 5,
        duplicateCopies: 2,
        items: [{ id: 'plush_coin', name: 'Plush Coin', amount: 1 }]
      },
      reward: {
        type: 'plushie',
        plushieId: 'kai',
        name: 'Kai',
        imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/plushies/kuraiplushie.png'
      }
    }
  ];

  // 1. Cargar catálogo de plushies
  async function loadPlushiesCatalog(force) {
    if (force === void 0) force = false;
    if (!force && plushiesCatalog.length > 0) return plushiesCatalog;
    if (isCatalogLoading) return plushiesCatalog;
    isCatalogLoading = true;

    try {
      var raw = null;

      // 1) Intentar SIEMPRE primero desde GitHub remoto (con cache busting)
      var remoteUrls = [
        'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/plushies.json',
        'https://hugom1307.github.io/kvrcards-catalog/plushies.json'
      ];
      for (var i = 0; i < remoteUrls.length; i++) {
        try {
          var rRes = await fetch(remoteUrls[i] + '?t=' + Date.now());
          if (rRes.ok) {
            var rText = await rRes.text();
            var rClean = rText.replace(/,\s*([\]}])/g, function (m, p) { return p; });
            var rJson = JSON.parse(rClean);
            var rList = rJson.plushies || rJson;
            if (Array.isArray(rList) && rList.length > 0) {
              raw = rList;
              console.log('[PLUSHIES] Catálogo cargado directamente desde GitHub remoto:', remoteUrls[i], raw.length);
              break;
            }
          }
        } catch (fErr) {}
      }

      // 2) Si falla, pedir a Electron (que a su vez consulta remoto)
      if ((!Array.isArray(raw) || raw.length === 0) && window.kvrcards && typeof window.kvrcards.getPlushiesCatalog === 'function') {
        try {
          raw = await window.kvrcards.getPlushiesCatalog();
        } catch (e) {
          console.warn('[PLUSHIES] Error al pedir catálogo a Electron:', e);
        }
      }

      // 3) Si no hay red ni respuesta remota, usar catálogo integrado
      if (Array.isArray(raw) && raw.length > 0) {
        plushiesCatalog = raw;
      } else {
        plushiesCatalog = DEFAULT_PLUSHIES_FALLBACK;
      }

      plushiesCatalogMap.clear();
      plushiesCatalog.forEach(function (p) {
        if (p && p.id) plushiesCatalogMap.set(p.id, p);
      });
    } catch (err) {
      console.warn('[PLUSHIES] Fallback catálogo default usado:', err);
      plushiesCatalog = DEFAULT_PLUSHIES_FALLBACK;
    } finally {
      isCatalogLoading = false;
    }
    return plushiesCatalog;
  }

  // 2. Cargar catálogo de Evo-Plushies
  async function loadEvoPlushiesCatalog(force) {
    if (force === void 0) force = false;
    if (!force && evoPlushiesCatalog.length > 0) return evoPlushiesCatalog;

    try {
      var raw = null;

      // 1) Intentar SIEMPRE primero desde GitHub remoto (con cache busting)
      var remoteUrls = [
        'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/evo_plushies.json',
        'https://hugom1307.github.io/kvrcards-catalog/evo_plushies.json'
      ];
      for (var i = 0; i < remoteUrls.length; i++) {
        try {
          var rRes = await fetch(remoteUrls[i] + '?t=' + Date.now());
          if (rRes.ok) {
            var rText = await rRes.text();
            var rClean = rText.replace(/,\s*([\]}])/g, function (m, p) { return p; });
            var rJson = JSON.parse(rClean);
            var rList = rJson.evoPlushies || rJson;
            if (Array.isArray(rList) && rList.length > 0) {
              raw = rList;
              console.log('[EVO-PLUSHIES] Catálogo cargado directamente desde GitHub remoto:', remoteUrls[i], raw.length);
              break;
            }
          }
        } catch (fErr) {}
      }

      // 2) Si falla, pedir a Electron
      if ((!Array.isArray(raw) || raw.length === 0) && window.kvrcards && typeof window.kvrcards.getEvoPlushiesCatalog === 'function') {
        try {
          raw = await window.kvrcards.getEvoPlushiesCatalog();
        } catch (e) {
          console.warn('[EVO-PLUSHIES] Error al pedir catálogo a Electron:', e);
        }
      }

      if (Array.isArray(raw) && raw.length > 0) {
        evoPlushiesCatalog = raw;
      } else {
        evoPlushiesCatalog = DEFAULT_EVO_PLUSHIES_FALLBACK;
      }
    } catch (err) {
      evoPlushiesCatalog = DEFAULT_EVO_PLUSHIES_FALLBACK;
    }
    return evoPlushiesCatalog;
  }

  // 3. Obtener Plushies del usuario
  async function getUserPlushies(force) {
    if (force === void 0) force = false;
    try {
      if (window.kvrcards && typeof window.kvrcards.getPlushiesInventory === 'function') {
        var res = await window.kvrcards.getPlushiesInventory();
        if (res && res.ok && res.plushies) {
          userPlushies = res.plushies;
          return userPlushies;
        }
      }
      var inv = (typeof window.userInventoryCache !== 'undefined' && window.userInventoryCache)
        ? window.userInventoryCache
        : ((window.kvrcards && typeof window.kvrcards.getInventory === 'function') ? await window.kvrcards.getInventory() : null);
      if (inv && inv.plushies) {
        userPlushies = inv.plushies;
      }
    } catch (e) {
      console.warn('[PLUSHIES] Error obteniendo plushies de usuario:', e);
    }
    return userPlushies || {};
  }

  function getPlushieDef(plushieId) {
    if (!plushieId) return null;
    if (plushiesCatalogMap.has(plushieId)) {
      return plushiesCatalogMap.get(plushieId);
    }
    return plushiesCatalog.find(function (p) { return p.id === plushieId; }) || null;
  }

  // 4. Comprobar compatibilidad con carta (flexible idéntico a prestigios compartidos)
  function isCardCompatibleWithPlushie(cardOrId, plushieDef) {
    if (!plushieDef) return false;
    if (plushieDef.universal) return true;

    var ownerIds = plushieDef.ownerId;
    if (!ownerIds) return false;
    if (!Array.isArray(ownerIds)) ownerIds = [ownerIds];

    var cardCharKey = '';
    if (typeof window.getPrestigeCharacterKey === 'function') {
      cardCharKey = window.getPrestigeCharacterKey(cardOrId);
    } else {
      var idStr = typeof cardOrId === 'string' ? cardOrId : (cardOrId?.id || '');
      cardCharKey = idStr.toLowerCase().replace(/_(?:cota\d*|icono|oro|plata|bronce|evo\d*)$/i, '').trim();
    }

    var cardRawId = (typeof cardOrId === 'string' ? cardOrId : (cardOrId?.id || '')).toLowerCase().trim();

    for (var i = 0; i < ownerIds.length; i++) {
      var ownerRaw = String(ownerIds[i]).toLowerCase().trim();
      if (ownerRaw === cardRawId) return true;

      var ownerCharKey = '';
      if (typeof window.getPrestigeCharacterKey === 'function') {
        ownerCharKey = window.getPrestigeCharacterKey(ownerRaw);
      } else {
        ownerCharKey = ownerRaw.replace(/_(?:cota\d*|icono|oro|plata|bronce|evo\d*)$/i, '').trim();
      }

      if (ownerCharKey && cardCharKey && ownerCharKey === cardCharKey) {
        return true;
      }
    }
    return false;
  }

  // 5. Calcular durabilidad y fase de Omni Plushie
  function calculateOmniPlushieState(matchesPlayed) {
    var played = Math.max(0, Number(matchesPlayed) || 0);
    var durability = Math.max(0, Math.round(((16 - played) / 16) * 100));
    var phase = 1;
    if (played >= 12) phase = 4;
    else if (played >= 8) phase = 3;
    else if (played >= 4) phase = 2;
    return {
      matchesPlayed: played,
      durability: durability,
      phase: phase,
      isBroken: played >= 16
    };
  }

  // 6. Obtener imagen actual de un plushie (manejando fases si es Omni)
  function getPlushieImage(plushieDef, instance) {
    if (!plushieDef) return './assets/plushies/inpu.png';
    if (plushieDef.id === 'omni_plushie' || plushieDef.universal) {
      var state = calculateOmniPlushieState(instance?.matchesPlayed || 0);
      var faseObj = plushieDef.fases && plushieDef.fases.find(function (f) { return f.fase === state.phase; });
      if (faseObj && faseObj.imagen) return faseObj.imagen;
      if (state.phase === 4) return './assets/plushies/omni_phase4.png';
      if (state.phase === 3) return './assets/plushies/omni_phase3.png';
      if (state.phase === 2) return './assets/plushies/omni_phase2.png';
      return './assets/plushies/omni_phase1.png';
    }
    return plushieDef.foto || './assets/plushies/inpu.png';
  }

  var STAT_KEYS_ORDER = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];

  // Normalizar objeto de buffs para soportar indistintamente las 7 stats del juego:
  // ninjutsu, taijutsu, resistencia, velocidad, defensa, fisico y media
  function normalizeBuffObject(obj) {
    var emptyBuffs = {
      ninjutsu: 0,
      taijutsu: 0,
      resistencia: 0,
      velocidad: 0,
      defensa: 0,
      fisico: 0,
      media: 0,
      stat1: 0,
      stat2: 0,
      stat3: 0,
      stat4: 0,
      stat5: 0,
      stat6: 0
    };
    if (!obj || typeof obj !== 'object') return emptyBuffs;

    var raw = {};
    if (Array.isArray(obj)) {
      obj.forEach(function (b) {
        if (b && typeof b === 'object') Object.assign(raw, b);
      });
    } else {
      raw = Object.assign({}, obj);
    }

    var result = {
      ninjutsu: 0,
      taijutsu: 0,
      resistencia: 0,
      velocidad: 0,
      defensa: 0,
      fisico: 0,
      media: undefined
    };

    var explicitMedia = undefined;
    var nonZeroStats = [];

    for (var k in raw) {
      if (!Object.prototype.hasOwnProperty.call(raw, k)) continue;
      var v = Number(raw[k]);
      if (isNaN(v)) continue;
      var keyLower = String(k).toLowerCase().trim();

      if (keyLower === 'ninjutsu' || keyLower === 'nin' || keyLower === 'stat1') {
        result.ninjutsu = v;
        if (v !== 0) nonZeroStats.push(v);
      } else if (keyLower === 'taijutsu' || keyLower === 'tai' || keyLower === 'stat2') {
        result.taijutsu = v;
        if (v !== 0) nonZeroStats.push(v);
      } else if (keyLower === 'resistencia' || keyLower === 'res' || keyLower === 'stat3') {
        result.resistencia = v;
        if (v !== 0) nonZeroStats.push(v);
      } else if (keyLower === 'velocidad' || keyLower === 'vel' || keyLower === 'stat4') {
        result.velocidad = v;
        if (v !== 0) nonZeroStats.push(v);
      } else if (keyLower === 'defensa' || keyLower === 'def' || keyLower === 'stat5') {
        result.defensa = v;
        if (v !== 0) nonZeroStats.push(v);
      } else if (keyLower === 'fisico' || keyLower === 'físico' || keyLower === 'fis' || keyLower === 'stat6') {
        result.fisico = v;
        if (v !== 0) nonZeroStats.push(v);
      } else if (keyLower === 'media' || keyLower === 'avg' || keyLower === 'average' || keyLower === 'stat7') {
        explicitMedia = v;
      }
    }

    // Media: si se especificó explícitamente se respeta; si no, promedio de las stats que tengan valor
    if (explicitMedia !== undefined) {
      result.media = explicitMedia;
    } else if (nonZeroStats.length > 0) {
      var sum = nonZeroStats.reduce(function (a, b) { return a + b; }, 0);
      result.media = Math.round(sum / nonZeroStats.length);
    } else {
      result.media = 0;
    }

    // Mapear aliases stat1..stat6 por retrocompatibilidad completa
    result.stat1 = result.ninjutsu;
    result.stat2 = result.taijutsu;
    result.stat3 = result.resistencia;
    result.stat4 = result.velocidad;
    result.stat5 = result.defensa;
    result.stat6 = result.fisico;

    return result;
  }

  // 7. Obtener buffs activos de un peluche
  function getPlushieBuffs(instance) {
    var defBuffs = { ninjutsu: 0, taijutsu: 0, resistencia: 0, velocidad: 0, defensa: 0, fisico: 0, media: 0, stat1: 0, stat2: 0, stat3: 0, stat4: 0, stat5: 0, stat6: 0 };
    if (!instance) return defBuffs;
    var def = getPlushieDef(instance.plushieId);
    if (!def) return defBuffs;

    if (def.id === 'omni_plushie' || def.universal) {
      var state = calculateOmniPlushieState(instance.matchesPlayed || 0);
      var faseObj = def.fases && def.fases.find(function (f) { return f.fase === state.phase; });
      return normalizeBuffObject((faseObj && faseObj.buffs) ? faseObj.buffs : {});
    }

    return normalizeBuffObject(def.buff || def.buffs || def.stats || {});
  }

  // 8. Buscar si una carta tiene un plushie equipado
  function getEquippedPlushieForCard(cardId) {
    if (!cardId) return null;
    var normId = String(cardId).toLowerCase().trim();
    var baseNormId = normId.replace(/_notrait.*$/, '');

    var plushiesSource = (userPlushies && Object.keys(userPlushies).length > 0)
      ? userPlushies
      : (window.userInventory?.plushies || window.userInventoryCache?.plushies || {});

    for (var instId in plushiesSource) {
      var inst = plushiesSource[instId];
      if (inst && inst.equippedCardId) {
        var eqNorm = String(inst.equippedCardId).toLowerCase().trim();
        var eqBase = eqNorm.replace(/_notrait.*$/, '');
        if (eqNorm === normId || eqBase === baseNormId || eqNorm === baseNormId || eqBase === normId) {
          return inst;
        }
      }
    }
    return null;
  }

  // 9. Aplicar badge visual y glow a un contenedor de carta
  function applyPlushieVisuals(cardEl, cardId) {
    if (!cardEl) return;
    if (cardEl.tagName === 'IMG' && cardEl.parentNode) {
      cardEl = cardEl.parentNode;
    }
    if (!cardId) {
      var existingBadge = cardEl.querySelector ? cardEl.querySelector('.card-plushie-badge') : null;
      if (existingBadge) existingBadge.remove();
      cardEl.classList.remove('card-plushie-glow');
      return;
    }
    var inst = getEquippedPlushieForCard(cardId);
    var existingBadge = cardEl.querySelector ? cardEl.querySelector('.card-plushie-badge') : null;
    if (!inst) {
      if (existingBadge) existingBadge.remove();
      cardEl.classList.remove('card-plushie-glow');
      return;
    }

    cardEl.style.position = 'relative';
    cardEl.classList.add('card-plushie-glow');
    var def = getPlushieDef(inst.plushieId) || {};
    var imgSrc = getPlushieImage(def, inst);

    if (existingBadge) {
      var img = existingBadge.querySelector('img');
      if (img) img.src = imgSrc;
    } else {
      var badge = document.createElement('div');
      badge.className = 'card-plushie-badge';
      badge.title = 'Plushie equipado: ' + (inst.name || def.nombre || 'Plushie');
      badge.innerHTML = '<img src="' + imgSrc + '" alt="Plushie" onerror="this.src=\'./assets/plushies/inpu.png\'" />';
      cardEl.appendChild(badge);
    }
  }

  // 9b. Determinar si los plushies están activos en la batalla actual
  function isPlushiesEnabledInBattle() {
    // 1) Si es batalla online: se rige por el interruptor / botón ya implementado
    var isOnline = !!(window.battleState?.isOnline || window.battleState?.isOnlineBattle || (window.onlineState && window.onlineState.inBattle));
    if (isOnline) {
      return window.onlineBattlePlushiesEnabled !== false;
    }

    // EXCEPCIÓN EXCLUSIVA: Activar plushies exclusivamente para el evento mini 'evento_kazegakure' y sus 3 batallas, o cualquier batalla con plushiesEnabled: true
    var diff = String(window.selectedDifficulty || window.battleState?.difficulty || '').toLowerCase().trim();
    var curBattle = window.currentEventBattle || window.battleState?.currentEventBattle || null;
    var curBattleId = String(curBattle?.id || curBattle?.battleId || window.currentEventBattleId || '').toLowerCase().trim();
    var curEventId = String(curBattle?.eventId || window.currentEventId || window.battleState?.currentEventId || '').toLowerCase().trim();

    var bObj = (typeof window.getEventBattleById === 'function') ? window.getEventBattleById(curBattleId || diff) : null;
    var evObj = (typeof window.getEventForBattle === 'function') ? window.getEventForBattle(curBattleId || diff || curEventId) : null;

    var isKazegakureBattle = (
      diff === 'kazegakure_1' || diff === 'kazegakure_2' || diff === 'kazegakure_3' ||
      curBattleId === 'kazegakure_1' || curBattleId === 'kazegakure_2' || curBattleId === 'kazegakure_3' ||
      diff.startsWith('kazegakure') ||
      curBattleId.startsWith('kazegakure') ||
      curEventId === 'evento_kazegakure' ||
      curEventId.includes('kazegakure') ||
      curBattle?.plushiesEnabled === true ||
      curBattle?.allowPlushies === true ||
      bObj?.plushiesEnabled === true ||
      bObj?.allowPlushies === true ||
      evObj?.plushiesEnabled === true ||
      evObj?.allowPlushies === true ||
      evObj?.id === 'evento_kazegakure'
    );

    if (isKazegakureBattle) {
      return true;
    }

    // 2) Si es cualquier otro evento (event battle o evento especial): DESACTIVADO por defecto
    var isEvent = !!(
      window.isEventBattle ||
      window.isSpecialEventBattle ||
      window.currentEventBattle ||
      window.currentSpecialEventLevel ||
      window.currentSpecialEventWorld ||
      (typeof window.selectedDifficulty === 'string' && (window.selectedDifficulty.toLowerCase().startsWith('evento_') || window.selectedDifficulty.toLowerCase().startsWith('escalon_') || window.selectedDifficulty.toLowerCase().startsWith('torneohaseo_') || window.selectedDifficulty.toLowerCase().startsWith('chuunin_') || window.selectedDifficulty.toLowerCase().startsWith('elemental_'))) ||
      window.battleState?.isEventBattle
    );
    if (isEvent) {
      return false;
    }

    // 3) Modo infinito y batallas offline normales (las 6 dificultades): ACTIVADO por defecto
    return true;
  }

  // 9c. Formatear descripción de buffeos en el formato exacto requerido: "(Nombre del plushie): Aumenta X"
  function formatPlushieBuffDescription(instance) {
    if (!instance) return '';
    var def = getPlushieDef(instance.plushieId);
    var plushieName = instance.name || def?.nombre || 'Plushie';

    var statDisplayNames = {
      media: 'Media',
      ninjutsu: 'Ninjutsu',
      taijutsu: 'Taijutsu',
      resistencia: 'Resistencia',
      velocidad: 'Velocidad',
      defensa: 'Defensa',
      fisico: 'Físico',
      físico: 'Físico',
      stat1: 'Ninjutsu',
      stat2: 'Taijutsu',
      stat3: 'Resistencia',
      stat4: 'Velocidad',
      stat5: 'Defensa',
      stat6: 'Físico',
      stat7: 'Media'
    };

    var rawBuffSource = null;
    if (def) {
      if (def.id === 'omni_plushie' || def.universal) {
        var state = calculateOmniPlushieState(instance.matchesPlayed || 0);
        var faseObj = def.fases && def.fases.find(function (f) { return f.fase === state.phase; });
        rawBuffSource = (faseObj && faseObj.buffs) ? faseObj.buffs : {};
      } else {
        rawBuffSource = def.buff || def.buffs || def.stats || {};
      }
    }

    var parts = [];

    if (Array.isArray(rawBuffSource)) {
      // Formato array respetando el orden exacto del JSON
      rawBuffSource.forEach(function (item) {
        if (!item || typeof item !== 'object') return;
        for (var k in item) {
          if (!Object.prototype.hasOwnProperty.call(item, k)) continue;
          var val = Number(item[k]);
          if (isNaN(val) || val === 0) continue;
          var kLower = String(k).toLowerCase().trim();
          var name = statDisplayNames[kLower] || (k.charAt(0).toUpperCase() + k.slice(1));
          var sign = val > 0 ? ('+' + val) : String(val);
          parts.push(sign + ' de ' + name);
        }
      });
    } else if (rawBuffSource && typeof rawBuffSource === 'object') {
      // Formato objeto respetando Object.entries
      for (var k in rawBuffSource) {
        if (!Object.prototype.hasOwnProperty.call(rawBuffSource, k)) continue;
        var val = Number(rawBuffSource[k]);
        if (isNaN(val) || val === 0) continue;
        var kLower = String(k).toLowerCase().trim();
        var name = statDisplayNames[kLower] || (k.charAt(0).toUpperCase() + k.slice(1));
        var sign = val > 0 ? ('+' + val) : String(val);
        parts.push(sign + ' de ' + name);
      }
    }

    if (parts.length === 0) {
      return plushieName + ': Sin aumentos activos';
    }

    return plushieName + ': Aumenta ' + parts.join(', ');
  }

  // 10. Renderizar la colección de Plushies en "Mi Colección"
  async function renderPlushiesCollection(container) {
    if (!container) {
      container = window.activeCollectionContainer || document.getElementById('collection-cards');
    }
    if (!container) return;

    container.innerHTML = '<div style="color:#cbd5e1;text-align:center;padding:40px;font-size:16px;font-weight:600;">Cargando Plushies...</div>';

    await Promise.all([
      loadPlushiesCatalog(),
      getUserPlushies(true)
    ]);

    var allCards = [];
    try {
      if (window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
        allCards = await window.kvrcards.getAllCards();
      }
    } catch (e) {}
    var cardMap = new Map((allCards || []).map(function (c) { return [c.id, c]; }));

    container.innerHTML = '';
    var instances = Object.values(userPlushies || {});

    // Filtro de búsqueda si hay texto en el input
    var searchInput = document.getElementById('collection-search');
    var query = searchInput ? searchInput.value.trim().toLowerCase() : '';
    if (query) {
      instances = instances.filter(function (inst) {
        var def = getPlushieDef(inst.plushieId);
        var name = (inst.name || def?.nombre || '').toLowerCase();
        return name.includes(query);
      });
    }

    if (instances.length === 0) {
      container.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; color: #94a3b8;">
          <div style="font-size: 54px; margin-bottom: 15px;">🧸</div>
          <h3 style="color: #f8fafc; font-size: 20px; margin-bottom: 10px;">No tienes Plushies en tu colección</h3>
          <p style="font-size: 14px; max-width: 500px; margin: 0 auto; line-height: 1.6;">
            Consigue peluches forjándolos en el sub-apartado de <strong>Evo-Plushies</strong> (en Evoluciones) o mediante códigos y misiones especiales.
          </p>
        </div>
      `;
      return;
    }

    var grid = document.createElement('div');
    grid.className = 'plushies-collection-grid';

    instances.forEach(function (inst) {
      var def = getPlushieDef(inst.plushieId) || { nombre: inst.name || 'Plushie', descripcion: '' };
      var imgSrc = getPlushieImage(def, inst);
      var isOmni = (def.id === 'omni_plushie' || def.universal);
      var omniState = isOmni ? calculateOmniPlushieState(inst.matchesPlayed) : null;

      var cardDiv = document.createElement('div');
      cardDiv.className = 'plushie-item-card' + (inst.equippedCardId ? ' is-equipped' : '');
      cardDiv.setAttribute('data-instance-id', inst.instanceId || '');

      var equippedCard = inst.equippedCardId ? cardMap.get(inst.equippedCardId) : null;
      var equippedName = equippedCard ? (equippedCard.name || equippedCard.nombre) : (inst.equippedCardId || null);

      var durabilityHtml = '';
      if (isOmni && omniState) {
        var barColor = omniState.phase === 1 ? '#22c55e' : (omniState.phase === 2 ? '#eab308' : (omniState.phase === 3 ? '#f97316' : '#ef4444'));
        durabilityHtml = `
          <div class="plushie-durability-preview" title="${omniState.durability}% (${omniState.matchesPlayed}/16 partidas)">
            <div class="plushie-durability-bar">
              <div class="plushie-durability-fill" style="width: ${omniState.durability}%; background: ${barColor};"></div>
            </div>
          </div>
        `;
      }

      cardDiv.innerHTML = `
        <div class="plushie-card-inner">
          <div class="plushie-card-image-box">
            <img src="${imgSrc}" alt="${escapeHtml(def.nombre)}" class="plushie-card-image" onerror="this.src='./assets/plushies/inpu.png'" />
            <span class="plushie-status-pill ${inst.equippedCardId ? 'equipped' : 'unequipped'}">
              ${inst.equippedCardId ? '🧸 Equipado' : 'Sin equipar'}
            </span>
            ${durabilityHtml}
          </div>
          <div class="plushie-card-name-wrapper">
            <span class="plushie-card-name">${escapeHtml(inst.name || def.nombre)}</span>
            <span class="plushie-card-subname">
              ${inst.equippedCardId ? `Equipado: ${escapeHtml(equippedName || 'Carta')}` : (def.universal ? '🌟 Omni Plushie' : '🧸 Familiar')}
            </span>
          </div>
        </div>
      `;

      // Al hacer clic en el cuadrito, se abre el modal de detalle con mini inventario
      cardDiv.addEventListener('click', function () {
        openPlushieDetailModal(inst, def, cardMap, container);
      });

      grid.appendChild(cardDiv);
    });

    container.appendChild(grid);
  }

  // 11. Modal para equipar peluche con filtro de cartas compatibles
  async function openPlushieEquipModal(instance, def, cardMap, parentContainer) {
    await openPlushieDetailModal(instance, def, cardMap, parentContainer, true);
  }

  // 12. Modal Lightbox de detalle de Plushie con Mini Inventario de Cartas
  async function openPlushieDetailModal(instance, def, cardMap, parentContainer, autoOpenMiniInv) {
    var modal = document.getElementById('plushie-detail-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'plushie-detail-modal';
      modal.className = 'plushie-modal-overlay';
      document.body.appendChild(modal);
    }

    if (!cardMap) {
      var allCards = [];
      try {
        if (window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
          allCards = await window.kvrcards.getAllCards();
        }
      } catch (e) {}
      cardMap = new Map((allCards || []).map(function (c) { return [c.id, c]; }));
    }

    var isOmni = (def.id === 'omni_plushie' || def.universal);
    var omniState = isOmni ? calculateOmniPlushieState(instance.matchesPlayed) : null;
    var imgSrc = getPlushieImage(def, instance);

    var buffs = getPlushieBuffs(instance);
    var displayItems = [];
    STAT_KEYS_ORDER.forEach(function (sKey) {
      if (buffs[sKey] !== undefined && Number(buffs[sKey]) !== 0) {
        displayItems.push({ label: sKey.toUpperCase(), value: Number(buffs[sKey]) });
      }
    });
    if (buffs.media !== undefined && Number(buffs.media) !== 0) {
      displayItems.push({ label: 'MEDIA', value: Number(buffs.media) });
    }

    var buffsListHtml = displayItems.map(function (item) {
      var sign = item.value >= 0 ? '+' : '';
      var color = item.value >= 0 ? '#4ade80' : '#ef4444';
      return `<span class="plushie-buff-chip" style="color:${color};">${item.label}: ${sign}${item.value}</span>`;
    }).join('');

    var omniDetailsHtml = '';
    if (isOmni && omniState) {
      var barColor = omniState.phase === 1 ? '#22c55e' : (omniState.phase === 2 ? '#eab308' : (omniState.phase === 3 ? '#f97316' : '#ef4444'));
      omniDetailsHtml = `
        <div class="omni-status-box" style="margin: 12px 0; background: rgba(0,0,0,0.3); padding: 12px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.1);">
          <div style="display:flex; justify-content:space-between; font-size:13px; margin-bottom:6px;">
            <span style="font-weight:700; color:#f8fafc;">Durabilidad:</span>
            <span style="font-weight:800; color:${barColor};">${omniState.durability}% (Fase ${omniState.phase}/4)</span>
          </div>
          <div class="plushie-durability-bar" style="height: 10px; background: #1e293b; border-radius: 5px; overflow: hidden;">
            <div style="height: 100%; width: ${omniState.durability}%; background: ${barColor}; transition: width 0.3s ease;"></div>
          </div>
          <div style="display:flex; justify-content:space-between; font-size:11px; color:#94a3b8; margin-top:6px;">
            <span>Partidas jugadas: <strong>${omniState.matchesPlayed} / 16</strong></span>
            <span>Rango: ${omniState.phase === 1 ? '100%-75%' : omniState.phase === 2 ? '75%-50%' : omniState.phase === 3 ? '50%-25%' : '25%-0%'}</span>
          </div>
        </div>
      `;
    }

    var sellButtonHtml = '';
    if (isOmni && omniState && omniState.isBroken) {
      sellButtonHtml = `
        <div style="margin: 10px 0; text-align: center;">
          <button id="btn-sell-broken-plushie" class="action-btn" style="background: linear-gradient(135deg, #fbbf24 0%, #d97706 100%); color: #000; font-weight: 800; border: 2px solid #f59e0b; padding: 8px 16px; border-radius: 8px; cursor: pointer;">
            🪙 Vender Peluche Roto (+1.000 Coins)
          </button>
        </div>
      `;
    }

    var equippedCard = instance.equippedCardId ? cardMap.get(instance.equippedCardId) : null;
    var equippedCardName = equippedCard ? (equippedCard.name || equippedCard.nombre) : (instance.equippedCardId || null);
    var equippedCardImg = equippedCard ? (equippedCard.imageUrl || `./cards/${equippedCard.id}.png`) : './icon-especiales.png';

    var equipStatusBannerHtml = '';
    if (instance.equippedCardId) {
      equipStatusBannerHtml = `
        <div class="plushie-equipped-banner">
          <div class="equipped-card-preview">
            <img src="${equippedCardImg}" alt="${escapeHtml(equippedCardName || 'Carta')}" onerror="this.src='./icon-especiales.png'" />
          </div>
          <div class="equipped-card-details">
            <div class="equipped-tag">✅ Equipado a:</div>
            <div class="equipped-title">${escapeHtml(equippedCardName || 'Carta')}</div>
          </div>
          <div class="equipped-actions-group">
            <button class="plushie-mini-action-btn btn-unequip-now">Desequipar</button>
            <button class="plushie-mini-action-btn btn-toggle-mini-inv">Cambiar</button>
          </div>
        </div>
      `;
    } else {
      equipStatusBannerHtml = `
        <div class="plushie-unequipped-banner">
          <span class="unequipped-text">Sin equipar</span>
          <button class="plushie-mini-action-btn primary btn-toggle-mini-inv">✨ Equipar a una Carta</button>
        </div>
      `;
    }

    var showMiniInvInitially = autoOpenMiniInv || !instance.equippedCardId;

    modal.innerHTML = `
      <div class="plushie-modal-box">
        <button class="plushie-modal-close" id="plushie-modal-close-btn">&times;</button>
        
        <div class="plushie-modal-top">
          <div class="plushie-modal-avatar-box">
            <img src="${imgSrc}" alt="${escapeHtml(def.nombre)}" class="plushie-modal-avatar" onerror="this.src='./assets/plushies/inpu.png'" />
          </div>
          <h2 class="plushie-modal-title">${escapeHtml(instance.name || def.nombre)}</h2>
          <div class="plushie-modal-subtitle">${def.universal ? '🌟 Omni Plushie Universal' : '🧸 Familiar Exclusivo'}</div>
        </div>

        <div class="plushie-modal-desc-box">
          <div class="plushie-section-heading">Descripción</div>
          <p class="plushie-modal-desc-text">${escapeHtml(def.descripcion || 'Sin descripción disponible.')}</p>
        </div>

        ${omniDetailsHtml}
        ${sellButtonHtml}

        <div class="plushie-modal-buffs-box">
          <div class="plushie-section-heading">Efectos & Buffs Activos</div>
          <div class="plushie-buffs-chips-container">${buffsListHtml || '<span style="color:#64748b; font-size:12px;">Sin buffs activos</span>'}</div>
        </div>

        <!-- Sección de Equipamiento y Mini-Inventario de Cartas -->
        <div class="plushie-equip-section">
          ${equipStatusBannerHtml}

          <div class="plushie-mini-inventory-wrap" id="plushie-mini-inv-container" style="${showMiniInvInitially ? 'display:block;' : 'display:none;'}">
            <div class="plushie-section-heading" style="margin-top:14px; margin-bottom:8px;">
              Mini Inventario: Cartas Compatibles
            </div>
            <div class="plushie-compatible-cards-grid" id="plushie-compatible-grid">
              <div style="color:#94a3b8; font-size:12px; padding:15px; text-align:center;">Cargando cartas compatibles...</div>
            </div>
          </div>
        </div>
      </div>
    `;

    function closePlushieModal() {
      modal.classList.remove('active');
      modal.style.setProperty('display', 'none', 'important');
      if (modal.parentNode) {
        modal.parentNode.removeChild(modal);
      }
      document.removeEventListener('keydown', onEscKey);
    }

    function onEscKey(e) {
      if (e.key === 'Escape') closePlushieModal();
    }
    document.addEventListener('keydown', onEscKey);

    modal.classList.add('active');
    modal.style.setProperty('display', 'flex', 'important');

    // Cerrar modal
    var closeBtn = modal.querySelector('#plushie-modal-close-btn');
    if (closeBtn) {
      closeBtn.onclick = function (e) {
        if (e) { e.preventDefault(); e.stopPropagation(); }
        closePlushieModal();
      };
    }
    modal.onclick = function (e) {
      if (e.target === modal) {
        e.preventDefault();
        closePlushieModal();
      }
    };

    // Toggle mini inventario
    var toggleInvBtn = modal.querySelector('.btn-toggle-mini-inv');
    var miniInvContainer = modal.querySelector('#plushie-mini-inv-container');
    if (toggleInvBtn && miniInvContainer) {
      toggleInvBtn.addEventListener('click', function () {
        if (miniInvContainer.style.display === 'none') {
          miniInvContainer.style.display = 'block';
          toggleInvBtn.textContent = 'Ocultar Cartas';
        } else {
          miniInvContainer.style.display = 'none';
          toggleInvBtn.textContent = instance.equippedCardId ? 'Cambiar' : '✨ Equipar a una Carta';
        }
      });
    }

    // Botón desequipar
    var unequipBtn = modal.querySelector('.btn-unequip-now');
    if (unequipBtn) {
      unequipBtn.addEventListener('click', async function () {
        unequipBtn.disabled = true;
        unequipBtn.textContent = '...';
        try {
          await unequipPlushie(instance.instanceId);
          closePlushieModal();
          await renderPlushiesCollection(parentContainer);
          if (typeof window.renderCollection === 'function') {
            try { window.renderCollection(); } catch (_) {}
          }
        } catch (err) {
          alert('Error al desequipar: ' + (err.message || err));
          unequipBtn.disabled = false;
          unequipBtn.textContent = 'Desequipar';
        }
      });
    }

    // Vender Omni Plushie roto
    var sellBtn = modal.querySelector('#btn-sell-broken-plushie');
    if (sellBtn) {
      sellBtn.addEventListener('click', async function () {
        if (!confirm('¿Deseas vender este Omni Plushie roto por 1.000 Coins? El peluche desaparecerá de tu inventario.')) return;
        sellBtn.disabled = true;
        sellBtn.textContent = 'Vendiendo...';
        try {
          var res = await sellBrokenPlushie(instance.instanceId);
          alert('¡Peluche vendido con éxito! +1.000 Coins recibidas.');
          closePlushieModal();
          if (typeof window.renderWallet === 'function') window.renderWallet();
          await renderPlushiesCollection(parentContainer);
          if (typeof window.renderCollection === 'function') {
            try { window.renderCollection(); } catch (_) {}
          }
        } catch (err) {
          alert('Error al vender: ' + (err.message || err));
          sellBtn.disabled = false;
        }
      });
    }

    // Cargar mini-inventario de cartas compatibles
    var gridEl = modal.querySelector('#plushie-compatible-grid');
    if (gridEl) {
      try {
        var inv = null;
        if (window.kvrcards && typeof window.kvrcards.getInventory === 'function') {
          inv = await window.kvrcards.getInventory();
        }
        var ownedCounts = (inv && inv.cards) ? inv.cards : {};

        var compatibleOwned = [];
        for (var cardId in ownedCounts) {
          if ((ownedCounts[cardId] || 0) > 0) {
            var cardObj = cardMap.get(cardId) || { id: cardId, name: cardId };
            if (isCardCompatibleWithPlushie(cardObj, def)) {
              compatibleOwned.push(cardObj);
            }
          }
        }

        if (compatibleOwned.length === 0) {
          gridEl.innerHTML = `
            <div style="grid-column: 1 / -1; text-align: center; padding: 20px 10px; color: #94a3b8;">
              <p style="font-size: 13px; color: #f8fafc; font-weight: 600;">No tienes ninguna carta compatible en tu inventario.</p>
              <p style="font-size: 11px; margin-top: 4px; color: #cbd5e1;">
                Requiere: <strong>${Array.isArray(def.ownerId) ? def.ownerId.join(', ') : (def.ownerId || 'Carta exclusiva')}</strong>.
              </p>
            </div>
          `;
        } else {
          gridEl.innerHTML = '';
          compatibleOwned.forEach(function (card) {
            var tile = document.createElement('div');
            tile.className = 'plushie-select-card-tile' + (instance.equippedCardId === card.id ? ' is-current-equipped' : '');
            var cImgUrl = card.imageUrl || `./cards/${card.id}.png`;
            var currEquipped = getEquippedPlushieForCard(card.id);
            var isThisOne = (instance.equippedCardId === card.id);

            tile.innerHTML = `
              <div class="select-card-img-wrap">
                <img src="${cImgUrl}" alt="${escapeHtml(card.name)}" onerror="this.src='./icon-especiales.png'" />
                ${currEquipped ? `<span class="already-has-plushie-badge" title="Ya tiene peluche equipado">🧸</span>` : ''}
              </div>
              <div class="select-card-name">${escapeHtml(card.name)}</div>
              <button class="select-card-btn ${isThisOne ? 'equipped' : ''}">${isThisOne ? 'Equipado' : (currEquipped ? 'Reemplazar' : 'Asignar')}</button>
            `;

            if (!isThisOne) {
              tile.onclick = async function () {
                tile.style.pointerEvents = 'none';
                tile.style.opacity = '0.6';
                try {
                  await equipPlushie(instance.instanceId, card.id);
                  closePlushieModal();
                  await renderPlushiesCollection(parentContainer);
                  if (typeof window.renderCollection === 'function') {
                    try { window.renderCollection(); } catch (_) {}
                  }
                } catch (err) {
                  alert('Error al equipar: ' + (err.message || err));
                  tile.style.pointerEvents = 'auto';
                  tile.style.opacity = '1';
                }
              };
            }

            gridEl.appendChild(tile);
          });
        }
      } catch (gridErr) {
        gridEl.innerHTML = '<div style="color:#ef4444;font-size:12px;padding:15px;text-align:center;">Error al cargar cartas compatibles.</div>';
      }
    }
  }

  // 12b. Obtener XP acumulada de prestigio del personaje (mínimo 10.000 XP para Prestigio 5)
  function getCharacterPrestigeXp(cardId) {
    var xp = 0;
    if (!cardId) return 0;
    try {
      if (typeof window.getPrestigeProgressEntry === 'function') {
        var entry = window.getPrestigeProgressEntry(cardId, false);
        if (entry) {
          xp = (Number(entry.battleXp) || 0) + (Number(entry.missionXp) || 0);
        }
      }
      if (typeof window.loadPrestigeProgressStore === 'function') {
        var store = window.loadPrestigeProgressStore() || {};
        var normId = (typeof window.normalizePrestigeCardId === 'function') ? window.normalizePrestigeCardId(cardId) : String(cardId).toLowerCase().trim();
        var charKey = (typeof window.getPrestigeCharacterKey === 'function') ? window.getPrestigeCharacterKey(normId) : normId;
        for (var sKey in store) {
          var sChar = (typeof window.getPrestigeCharacterKey === 'function') ? window.getPrestigeCharacterKey(sKey) : sKey;
          if (sChar && sChar === charKey) {
            var se = store[sKey];
            var sXp = (Number(se.battleXp) || 0) + (Number(se.missionXp) || 0);
            if (sXp > xp) xp = sXp;
          }
        }
      }
      if (typeof window.getInventoryPrestigeData === 'function') {
        var pData = window.getInventoryPrestigeData(0, undefined, cardId);
        if (pData && Number(pData.xp) > xp) {
          xp = Number(pData.xp);
        }
      }
    } catch (e) {
      console.warn('[PLUSHIES] Error calculando XP de prestigio para:', cardId, e);
    }
    return xp;
  }

  // 12c. Normalización de texto y estado de búsqueda en Evo-Plushies
  var currentEvoPlushieSearch = '';
  function normalizePlushieSearch(text) {
    if (!text) return '';
    return String(text)
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .trim();
  }

  // 13. Renderizar sub-apartado Evo-Plushies dentro de Evoluciones
  async function renderEvoPlushies(container) {
    if (!container) {
      container = document.getElementById('evolutions-plushies');
    }
    if (!container) return;

    container.innerHTML = '<div style="color:#cbd5e1;text-align:center;padding:40px;font-size:16px;font-weight:600;">Cargando Evo-Plushies...</div>';

    await Promise.all([
      loadEvoPlushiesCatalog(),
      loadPlushiesCatalog(),
      getUserPlushies(true)
    ]);

    var [inv, allCards] = await Promise.all([
      (window.kvrcards && typeof window.kvrcards.getInventory === 'function') ? window.kvrcards.getInventory() : { cards: {}, items: {} },
      (window.kvrcards && typeof window.kvrcards.getAllCards === 'function') ? window.kvrcards.getAllCards() : []
    ]);

    var ownedCards = (inv && inv.cards) ? inv.cards : {};
    var ownedItems = (inv && inv.items) ? inv.items : {};
    var cardMap = new Map((allCards || []).map(function (c) { return [c.id, c]; }));

    container.innerHTML = '';

    if (evoPlushiesCatalog.length === 0) {
      container.innerHTML = '<p class="info-message">No hay forjas de Evo-Plushies disponibles en este momento.</p>';
      return;
    }

    // Contenedor de la barra de búsqueda y estadísticas
    var searchContainer = document.createElement('div');
    searchContainer.className = 'evo-plushies-search-container';
    searchContainer.innerHTML = `
      <div class="evo-plushies-search-box">
        <span class="evo-plushies-search-icon">🔍</span>
        <input 
          type="text" 
          id="evo-plushies-search-input" 
          class="evo-plushies-search-input" 
          placeholder="Buscar por plushie o carta equipable..." 
          value="${escapeHtml(currentEvoPlushieSearch)}"
          autocomplete="off"
          spellcheck="false"
        />
        <button type="button" id="evo-plushies-search-clear" class="evo-plushies-search-clear" title="Limpiar búsqueda" style="${currentEvoPlushieSearch ? 'display:inline-flex;' : 'display:none;'}">✕</button>
      </div>
      <div class="evo-plushies-search-stats" id="evo-plushies-search-stats">
        Mostrando <span id="evo-plushies-visible-count">${evoPlushiesCatalog.length}</span> de ${evoPlushiesCatalog.length} Evo-Plushies
      </div>
    `;
    container.appendChild(searchContainer);

    // Contenedor de mensaje cuando no hay resultados
    var noResultsEl = document.createElement('div');
    noResultsEl.id = 'evo-plushies-no-results';
    noResultsEl.className = 'evo-plushies-no-results';
    noResultsEl.style.display = 'none';
    noResultsEl.innerHTML = `
      <div class="evo-no-results-icon">🧸</div>
      <div class="evo-no-results-title">No se encontraron Evo-Plushies</div>
      <div class="evo-no-results-desc">No hay ningún plushie ni carta equipable que coincida con "<span id="evo-plushies-no-results-term"></span>".</div>
    `;
    container.appendChild(noResultsEl);

    evoPlushiesCatalog.forEach(function (evo) {
      // Buscar carta compatible en inventario que cumpla o se acerque a los requisitos
      var compatibleCardIds = Array.isArray(evo.cardIds) ? evo.cardIds : [evo.cardId || ''];
      
      // Buscar la carta con mayor prestigio o copias entre las compatibles
      var matchedCard = null;
      var highestXp = 0;
      var hasDuplicate = false;

      for (var i = 0; i < compatibleCardIds.length; i++) {
        var cId = compatibleCardIds[i];
        if (!cId) continue;
        var copies = ownedCards[cId] || 0;
        var cObj = cardMap.get(cId) || { id: cId, name: evo.targetCardName || cId };
        var cXp = getCharacterPrestigeXp(cId);

        if (cXp > highestXp) highestXp = cXp;

        if (copies > 0 && !matchedCard) {
          matchedCard = cObj;
        }
        if (cXp >= 10000) {
          if (copies >= 2) {
            matchedCard = cObj;
          } else if (!matchedCard || (ownedCards[matchedCard.id] || 0) < 2) {
            matchedCard = cObj;
          }
        }
        if (copies >= 2) {
          hasDuplicate = true;
          if (!matchedCard || cXp >= 10000) {
            matchedCard = cObj;
          }
        }
      }

      if (!matchedCard && compatibleCardIds.length > 0) {
        matchedCard = cardMap.get(compatibleCardIds[0]) || { id: compatibleCardIds[0], name: evo.targetCardName || 'Carta' };
      }

      var hasPrestige5 = (highestXp >= 10000);
      var currentCopies = matchedCard ? (ownedCards[matchedCard.id] || 0) : 0;
      var duplicateOk = currentCopies >= 2;
      var plushCoinsCount = (ownedItems['plush_coin'] || 0) + (ownedItems['plushie_coin'] || 0);
      var plushCoinOk = plushCoinsCount >= 1;
      var canCraft = hasPrestige5 && duplicateOk && plushCoinOk;

      var cardEl = document.createElement('div');
      cardEl.className = 'evolution-card evo-plushie-card' + (canCraft ? ' can-evolve' : '');

      var sourceImgUrl = matchedCard ? (matchedCard.imageUrl || `./cards/${matchedCard.id}.png`) : './icon-especiales.png';
      var plushieDef = getPlushieDef(evo.plushieId) || {};
      var plushieImgUrl = plushieDef.foto || evo.imageUrl || './assets/plushies/inpu.png';
      var plushieDisplayName = evo.reward?.name || plushieDef.nombre || 'Inpu';

      // Palabras clave para la búsqueda concurrente por nombre de plushie y carta equipable
      var searchTerms = [
        plushieDisplayName,
        evo.plushieId,
        plushieDef.nombre,
        evo.name,
        evo.targetCardName,
        matchedCard ? matchedCard.name : '',
        matchedCard ? matchedCard.id : ''
      ];
      compatibleCardIds.forEach(function (cid) {
        if (!cid) return;
        searchTerms.push(cid);
        var co = cardMap.get(cid);
        if (co) {
          if (co.name) searchTerms.push(co.name);
          if (co.nombre) searchTerms.push(co.nombre);
        }
      });
      if (plushieDef && plushieDef.ownerId) {
        var ownerIds = Array.isArray(plushieDef.ownerId) ? plushieDef.ownerId : [plushieDef.ownerId];
        ownerIds.forEach(function (oid) {
          if (!oid) return;
          searchTerms.push(oid);
          var co = cardMap.get(oid);
          if (co) {
            if (co.name) searchTerms.push(co.name);
            if (co.nombre) searchTerms.push(co.nombre);
          }
        });
      }
      cardEl.dataset.searchKeywords = normalizePlushieSearch(searchTerms.filter(Boolean).join(' '));

      cardEl.innerHTML = `
        <!-- Esquinas decorativas doradas estilo art deco -->
        <div class="evo-corner-deco top-left"></div>
        <div class="evo-corner-deco top-right"></div>
        <div class="evo-corner-deco bottom-left"></div>
        <div class="evo-corner-deco bottom-right"></div>

        <!-- Título principal con gran importancia -->
        <div class="evo-plushie-title-badge">
          <span class="evo-plushie-title-text">Plushie: ${escapeHtml(plushieDisplayName)}</span>
        </div>

        <!-- Escenario central: Carta grande + Flecha dorada 3D + Peluche en Portal -->
        <div class="evo-plushie-stage">
          <!-- Carta base grande -->
          <div class="evo-stage-card-wrap">
            <div class="evo-stage-card">
              <img src="${sourceImgUrl}" alt="${escapeHtml(matchedCard?.name || 'Carta')}" class="evo-stage-card-img" onerror="this.src='./icon-especiales.png'" />
            </div>
          </div>

          <!-- Flecha dorada 3D -->
          <div class="evo-stage-arrow">
            <svg viewBox="0 0 70 42" width="70" height="42" fill="none" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <linearGradient id="evoGoldArrowGrad_${evo.id || 'plush'}" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stop-color="#ca8a04" stop-opacity="0.2"/>
                  <stop offset="35%" stop-color="#eab308"/>
                  <stop offset="70%" stop-color="#fef08a"/>
                  <stop offset="100%" stop-color="#f59e0b"/>
                </linearGradient>
                <filter id="evoArrowGlow_${evo.id || 'plush'}">
                  <feDropShadow dx="0" dy="0" stdDeviation="5" flood-color="#facc15" flood-opacity="0.7"/>
                </filter>
              </defs>
              <path d="M0 15 H38 V4 L70 21 L38 38 V27 H0 Z" fill="url(#evoGoldArrowGrad_${evo.id || 'plush'})" filter="url(#evoArrowGlow_${evo.id || 'plush'})"/>
            </svg>
          </div>

          <!-- Peluche resultante grande en Portal Circular -->
          <div class="evo-stage-plushie-wrap">
            <div class="evo-stage-portal">
              <img src="${plushieImgUrl}" alt="${escapeHtml(plushieDisplayName)}" class="evo-stage-plushie-img" onerror="this.src='./assets/plushies/inpu.png'" />
            </div>
            <div class="evo-stage-nameplate">
              ${escapeHtml(plushieDisplayName)}
            </div>
          </div>
        </div>

        <!-- Panel de Requisitos de Forja -->
        <div class="evo-plushie-reqs-panel">
          <div class="evo-reqs-panel-header">REQUISITOS DE FORJA</div>
          
          <div class="evo-reqs-list">
            <!-- Fila 1: Prestigio 5 -->
            <div class="evo-req-row">
              <span class="evo-req-left-text">Prestigio 5 (Nivel Máximo)</span>
              <div class="evo-req-right-col">
                ${hasPrestige5
                  ? `<span class="evo-status-text ok"><span class="tick-symbol">&#10004;</span> Completado</span>`
                  : `<span class="evo-status-text fail"><span class="cross-symbol">&#10006;</span> Incompleto</span>`
                }
              </div>
            </div>

            <!-- Fila 2: Copia Extra -->
            <div class="evo-req-row">
              <span class="evo-req-left-text">1 Copia Extra (Se consume)</span>
              <div class="evo-req-right-col">
                ${duplicateOk
                  ? `<span class="evo-status-pill ok"><span class="tick-symbol">&#10004;</span> ${currentCopies}/2 copias</span>`
                  : `<span class="evo-status-pill fail"><span class="cross-symbol">&#10006;</span> ${currentCopies}/2 copias</span>`
                }
              </div>
            </div>

            <!-- Fila 3: Plush Coin -->
            <div class="evo-req-row">
              <span class="evo-req-left-text">1 Plush Coin (Se consume)</span>
              <div class="evo-req-right-col">
                ${plushCoinOk
                  ? `<span class="evo-status-pill ok"><span class="tick-symbol">&#10004;</span> 1/1</span>`
                  : `<span class="evo-status-pill fail"><span class="cross-symbol">&#10006;</span> ${plushCoinsCount}/1</span>`
                }
              </div>
            </div>
          </div>
        </div>

        <!-- Botón centrado -->
        <div class="evo-btn-center-wrap">
          <button class="evo-plushie-gold-btn btn-forge-plushie" ${!canCraft ? 'disabled' : ''}>
            ${canCraft ? 'Forjar Plushie' : 'Requisitos No Cumplidos'}
          </button>
        </div>
      `;

      var craftBtn = cardEl.querySelector('.btn-forge-plushie');
      if (craftBtn && canCraft) {
        craftBtn.addEventListener('click', async function () {
          if (!confirm(`¿Confirmas forjar a ${evo.reward?.name || 'Inpu'}? Se consumirá 1 copia extra de la carta, 1 Plush Coin y se reiniciará el prestigio del personaje a 0 XP permitiéndote rehacer sus misiones.`)) return;
          craftBtn.disabled = true;
          craftBtn.textContent = 'Forjando...';
          try {
            var craftResult = await craftEvoPlushie(evo.id, matchedCard.id, evo.plushieId);
            if (craftResult && craftResult.ok) {
              // Actualizar caches globales de inventario en el cliente
              if (craftResult.items && typeof craftResult.items === 'object') {
                if (window.userInventory && typeof window.userInventory === 'object') {
                  window.userInventory.items = { ...craftResult.items };
                }
                if (window.userInventoryCache && typeof window.userInventoryCache === 'object') {
                  window.userInventoryCache.items = { ...craftResult.items };
                }
              }
              if (craftResult.cards && typeof craftResult.cards === 'object') {
                if (window.userInventory && typeof window.userInventory === 'object') {
                  window.userInventory.cards = { ...craftResult.cards };
                }
                if (window.userInventoryCache && typeof window.userInventoryCache === 'object') {
                  window.userInventoryCache.cards = { ...craftResult.cards };
                }
              }
              if (craftResult.plushies && typeof craftResult.plushies === 'object') {
                if (window.userInventory && typeof window.userInventory === 'object') {
                  window.userInventory.plushies = { ...craftResult.plushies };
                }
                if (window.userInventoryCache && typeof window.userInventoryCache === 'object') {
                  window.userInventoryCache.plushies = { ...craftResult.plushies };
                }
              }

              // Reiniciar prestigio del personaje a 0 XP y reiniciar misiones manteniendo las recompensas de nivel ya reclamadas
              try {
                if (typeof window.resetPrestigeForPlushieCraft === 'function') {
                  await window.resetPrestigeForPlushieCraft(matchedCard.id, evo.cardIds || []);
                }
              } catch (resetErr) {
                console.warn('[PLUSHIES] Error al reiniciar prestigio tras forjar:', resetErr);
              }

              // Animación de reclamo unificada
              try {
                if (typeof window.showRewardsClaimHUD === 'function') {
                  window.showRewardsClaimHUD([{
                    type: 'plushie',
                    plushieId: evo.plushieId || 'inpu',
                    name: evo.reward?.name || plushieDef.nombre || 'Inpu',
                    cleanName: evo.reward?.name || plushieDef.nombre || 'Inpu',
                    imageUrl: plushieImgUrl
                  }], '¡PLUSHIE FORJADO CON ÉXITO!');
                } else {
                  alert(`¡Has forjado a ${evo.reward?.name || 'tu nuevo familiar'}!`);
                }
              } catch (hudErr) {
                console.warn('[PLUSHIES] Error mostrando HUD de recompensas:', hudErr);
                alert(`¡Has forjado a ${evo.reward?.name || 'tu nuevo familiar'}!`);
              }

              // Refrescar monedero y colecciones si están en memoria
              if (typeof window.renderWallet === 'function') {
                window.renderWallet().catch(function () {});
              }
              if (typeof window.renderCollection === 'function') {
                try { window.renderCollection(); } catch (_) {}
              }
              if (typeof window.renderItemsCollection === 'function') {
                try { window.renderItemsCollection(); } catch (_) {}
              }

              // Refrescar vista de evo-plushies
              await renderEvoPlushies(container);
            } else {
              var errMsg = (craftResult && craftResult.error) ? craftResult.error : 'No se pudo forjar el peluche';
              alert('Error al forjar peluche: ' + errMsg);
              craftBtn.disabled = false;
              craftBtn.textContent = 'Forjar Plushie';
            }
          } catch (err) {
            console.error('[PLUSHIES] Error al forjar peluche:', err);
            alert('Error al forjar peluche: ' + (err.message || err));
            craftBtn.disabled = false;
            craftBtn.textContent = 'Forjar Plushie';
          }
        });
      }

      container.appendChild(cardEl);
    });

    // Función para aplicar el filtrado dinámico a las tarjetas de Evo-Plushies
    function applyFilter(query) {
      currentEvoPlushieSearch = (typeof query === 'string') ? query : '';
      var norm = normalizePlushieSearch(currentEvoPlushieSearch);
      var cards = container.querySelectorAll('.evo-plushie-card');
      var visible = 0;

      cards.forEach(function (card) {
        var kw = card.dataset.searchKeywords || '';
        var match = !norm || kw.indexOf(norm) !== -1;
        card.style.display = match ? '' : 'none';
        if (match) visible++;
      });

      var clearBtn = searchContainer.querySelector('#evo-plushies-search-clear');
      if (clearBtn) {
        clearBtn.style.display = currentEvoPlushieSearch ? 'inline-flex' : 'none';
      }

      var countEl = searchContainer.querySelector('#evo-plushies-visible-count');
      if (countEl) {
        countEl.textContent = visible;
      }

      if (noResultsEl) {
        if (visible === 0 && cards.length > 0) {
          noResultsEl.style.display = 'flex';
          var termSpan = noResultsEl.querySelector('#evo-plushies-no-results-term');
          if (termSpan) termSpan.textContent = currentEvoPlushieSearch;
        } else {
          noResultsEl.style.display = 'none';
        }
      }
    }

    var searchInput = searchContainer.querySelector('#evo-plushies-search-input');
    var clearBtn = searchContainer.querySelector('#evo-plushies-search-clear');

    if (searchInput) {
      searchInput.addEventListener('input', function () {
        applyFilter(searchInput.value);
      });
      searchInput.addEventListener('keyup', function (e) {
        if (e.key === 'Escape') {
          searchInput.value = '';
          applyFilter('');
        }
      });
    }

    if (clearBtn) {
      clearBtn.addEventListener('click', function () {
        if (searchInput) {
          searchInput.value = '';
          searchInput.focus();
        }
        applyFilter('');
      });
    }

    // Aplicar filtro si ya había un término activo o para sincronizar contadores
    applyFilter(currentEvoPlushieSearch);
  }

  // 14. IPC y llamadas al servidor
  async function equipPlushie(instanceId, cardId) {
    var res = null;
    if (window.kvrcards && typeof window.kvrcards.equipPlushie === 'function') {
      res = await window.kvrcards.equipPlushie(instanceId, cardId);
    } else {
      var user = getActiveUsername();
      var fRes = await fetch('/api/plushies/equip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: user, instanceId: instanceId, cardId: cardId })
      });
      res = await fRes.json();
    }
    if (res && res.plushies) {
      userPlushies = res.plushies;
      if (window.userInventory) window.userInventory.plushies = { ...res.plushies };
      if (window.userInventoryCache) window.userInventoryCache.plushies = { ...res.plushies };
    }
    return res;
  }

  async function unequipPlushie(instanceId) {
    var res = null;
    if (window.kvrcards && typeof window.kvrcards.unequipPlushie === 'function') {
      res = await window.kvrcards.unequipPlushie(instanceId);
    } else {
      var user = getActiveUsername();
      var fRes = await fetch('/api/plushies/unequip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: user, instanceId: instanceId })
      });
      res = await fRes.json();
    }
    if (res && res.plushies) {
      userPlushies = res.plushies;
      if (window.userInventory) window.userInventory.plushies = { ...res.plushies };
      if (window.userInventoryCache) window.userInventoryCache.plushies = { ...res.plushies };
    }
    return res;
  }

  async function craftEvoPlushie(evoPlushieId, cardId, plushieId) {
    if (window.kvrcards && typeof window.kvrcards.craftEvoPlushie === 'function') {
      return await window.kvrcards.craftEvoPlushie(evoPlushieId, cardId, plushieId);
    }
    var user = getActiveUsername();
    var res = await fetch('/api/plushies/craft', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: user, evoPlushieId: evoPlushieId, cardId: cardId, plushieId: plushieId })
    });
    return await res.json();
  }

  async function sellBrokenPlushie(instanceId) {
    if (window.kvrcards && typeof window.kvrcards.sellBrokenPlushie === 'function') {
      return await window.kvrcards.sellBrokenPlushie(instanceId);
    }
    var user = getActiveUsername();
    var res = await fetch('/api/plushies/sell-broken', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: user, instanceId: instanceId })
    });
    return await res.json();
  }

  function findEquippedOmniPlushiesForTeam(teamCards) {
    var plushiesSource = (userPlushies && Object.keys(userPlushies).length > 0)
      ? userPlushies
      : (window.userInventory?.plushies || window.userInventoryCache?.plushies || {});

    var cardIds = new Set();
    function addCard(c) {
      if (!c) return;
      if (typeof c === 'string') {
        var str = c.toLowerCase().trim();
        cardIds.add(str);
        cardIds.add(str.replace(/_notrait.*$/, ''));
      } else if (typeof c === 'object') {
        var id = c.id || c.cardId || c.uniqueId || c.card_id;
        if (id) {
          var strId = String(id).toLowerCase().trim();
          cardIds.add(strId);
          cardIds.add(strId.replace(/_notrait.*$/, ''));
        }
      }
    }

    if (Array.isArray(teamCards)) teamCards.forEach(addCard);
    if (window.battleState) {
      if (Array.isArray(window.battleState.playerTeam)) window.battleState.playerTeam.forEach(addCard);
      if (window.battleState.playerReserveCard) addCard(window.battleState.playerReserveCard);
      if (Array.isArray(window.battleState.playerUsedCards)) window.battleState.playerUsedCards.forEach(addCard);
      if (window.battleState.playerCurrentCard) addCard(window.battleState.playerCurrentCard);
      if (Array.isArray(window.battleState.usedPlushiesInBattle)) {
        window.battleState.usedPlushiesInBattle.forEach(function(p) {
          if (p && (p.instanceId || p.id)) omniInstanceIds.add(p.instanceId || p.id);
        });
      }
    }
    if (Array.isArray(window.selectedTeam)) window.selectedTeam.forEach(addCard);
    if (window.selectedReserveCard) addCard(window.selectedReserveCard);

    var omniInstanceIds = new Set();

    for (var instId in plushiesSource) {
      var inst = plushiesSource[instId];
      if (!inst) continue;
      var isOmni = (
        inst.plushieId === 'omni_plushie' ||
        inst.plushieId === 'omni' ||
        (typeof inst.plushieId === 'string' && inst.plushieId.toLowerCase().includes('omni')) ||
        (typeof inst.name === 'string' && inst.name.toLowerCase().includes('omni')) ||
        Boolean(inst.universal)
      );
      if (!isOmni) continue;

      if (inst.equippedCardId) {
        var eqNorm = String(inst.equippedCardId).toLowerCase().trim();
        var eqBase = eqNorm.replace(/_notrait.*$/, '');
        if (cardIds.has(eqNorm) || cardIds.has(eqBase)) {
          omniInstanceIds.add(inst.instanceId || instId);
        }
      }
    }

    if (window.battleState?.playerEquippedPlushie) {
      var p = window.battleState.playerEquippedPlushie;
      var isP_Omni = (
        p.plushieId === 'omni_plushie' ||
        p.plushieId === 'omni' ||
        (typeof p.plushieId === 'string' && p.plushieId.toLowerCase().includes('omni')) ||
        (typeof p.name === 'string' && p.name.toLowerCase().includes('omni')) ||
        Boolean(p.universal)
      );
      if (isP_Omni && (p.instanceId || p.id)) {
        omniInstanceIds.add(p.instanceId || p.id);
      }
    }

    return Array.from(omniInstanceIds);
  }

  async function recordTeamOmniPlushiesMatch(teamCards) {
    try {
      var ids = findEquippedOmniPlushiesForTeam(teamCards);
      if (ids && ids.length > 0) {
        console.log('[PLUSHIES] Registrando desgaste de Omni Plushies para IDs:', ids);
        return await recordPlushieMatch(ids);
      }
    } catch (err) {
      console.warn('[PLUSHIES] Error registrando desgaste de Omni Plushies:', err);
    }
    return null;
  }

  async function recordPlushieMatch(instanceIdsOrId) {
    if (!instanceIdsOrId) return;
    var ids = Array.isArray(instanceIdsOrId) ? instanceIdsOrId : [instanceIdsOrId];
    if (ids.length === 0) return;

    try {
      var res = null;
      if (window.kvrcards && typeof window.kvrcards.recordPlushieMatch === 'function') {
        res = await window.kvrcards.recordPlushieMatch(ids);
      } else {
        var user = getActiveUsername();
        var fetchRes = await fetch('/api/plushies/record-match', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: user, instanceIds: ids })
        });
        res = await fetchRes.json();
      }

      if (res && res.plushies) {
        userPlushies = res.plushies;
        if (window.userInventory) window.userInventory.plushies = res.plushies;
        if (window.userInventoryCache) window.userInventoryCache.plushies = res.plushies;
      } else {
        // Fallback local directo en memoria
        for (var i = 0; i < ids.length; i++) {
          var targetId = ids[i];
          var inst = userPlushies ? userPlushies[targetId] : null;
          if (!inst && userPlushies) {
            for (var k in userPlushies) {
              if (userPlushies[k]?.instanceId === targetId || userPlushies[k]?.id === targetId) {
                inst = userPlushies[k];
                break;
              }
            }
          }
          if (inst) {
            inst.matchesPlayed = (Number(inst.matchesPlayed) || 0) + 1;
            inst.durability = Math.max(0, Math.round(((16 - inst.matchesPlayed) / 16) * 100));
            inst.currentPhase = inst.matchesPlayed < 4 ? 1 : (inst.matchesPlayed < 8 ? 2 : (inst.matchesPlayed < 12 ? 3 : 4));
          }
        }
      }
      return res;
    } catch (e) {
      console.warn('[PLUSHIES] Error en recordPlushieMatch:', e);
    }
  }

  function getActiveUsername() {
    try {
      if (typeof currentUsername === 'string' && currentUsername.trim()) return currentUsername.trim();
      if (typeof currentUser === 'string' && currentUser.trim()) return currentUser.trim();
      if (window.userProfile && window.userProfile.username) return window.userProfile.username;
      var raw = localStorage.getItem('kvr_user') || localStorage.getItem('kvr_username');
      if (raw) {
        if (raw.startsWith('{')) {
          var p = JSON.parse(raw);
          if (p && p.username) return p.username;
        }
        return raw;
      }
    } catch (e) {}
    return 'default';
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Exportar al ámbito global de la aplicación
  window.kvrcardsPlushies = {
    loadPlushiesCatalog: loadPlushiesCatalog,
    loadEvoPlushiesCatalog: loadEvoPlushiesCatalog,
    getUserPlushies: getUserPlushies,
    getPlushieDef: getPlushieDef,
    isCardCompatibleWithPlushie: isCardCompatibleWithPlushie,
    getEquippedPlushieForCard: getEquippedPlushieForCard,
    applyPlushieVisuals: applyPlushieVisuals,
    renderPlushiesCollection: renderPlushiesCollection,
    renderEvoPlushies: renderEvoPlushies,
    equipPlushie: equipPlushie,
    unequipPlushie: unequipPlushie,
    craftEvoPlushie: craftEvoPlushie,
    sellBrokenPlushie: sellBrokenPlushie,
    recordPlushieMatch: recordPlushieMatch,
    recordTeamOmniPlushiesMatch: recordTeamOmniPlushiesMatch,
    findEquippedOmniPlushiesForTeam: findEquippedOmniPlushiesForTeam,
    getPlushieBuffs: getPlushieBuffs,
    getPlushieBuffDescription: formatPlushieBuffDescription,
    isPlushiesEnabledInBattle: isPlushiesEnabledInBattle,
    getPlushieImage: getPlushieImage,
    calculateOmniPlushieState: calculateOmniPlushieState
  };

  window.renderPlushiesCollection = renderPlushiesCollection;
  window.renderEvoPlushies = renderEvoPlushies;
  window.getEquippedPlushieForCard = getEquippedPlushieForCard;
  window.applyPlushieVisuals = applyPlushieVisuals;
  window.getPlushieDef = getPlushieDef;
  window.getPlushieBuffDescription = formatPlushieBuffDescription;
  window.isPlushiesEnabledInBattle = isPlushiesEnabledInBattle;
  window.getPlushieBuffs = getPlushieBuffs;
  window.recordTeamOmniPlushiesMatch = recordTeamOmniPlushiesMatch;

})();
