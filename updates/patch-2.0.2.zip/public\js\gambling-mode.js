/**
 * ============================================================================
 * GAMBLING MODE - MODO DE JUEGO EXCLUSIVO PARA EVENTOS ESPECIALES
 * ============================================================================
 * 
 * Reglas del Modo:
 * 1. Ruleta animada en vivo antes de cada turno cuando las dos cartas del turno están en juego.
 * 2. Modificadores:
 *    - "AUMENTO" (Verde): Sube la estadística de AMBOS combatientes entre un 1% y 10%.
 *    - "NERFEO" (Rojo): Reduce la estadística SOLO del JUGADOR entre un 1% y 20%.
 *    - "BLOQUEO" (Gris): Bloquea la estadística para esa ronda (ninguno puede elegirla).
 *      * Restricción: En la última ronda de combate, BLOQUEO no puede aparecer.
 * 3. Ruleta de Stats de 8 sectores:
 *    - 6 estadísticas principales: Ninjutsu, Taijutsu, Resistencia, Velocidad, Defensa, Físico.
 *    - Media
 *    - Todas (si sale Bloqueo, se elige de las 7 individuales, no 'todas').
 * 4. Sin traits para el jugador:
 *    - Las cartas del jugador funcionan con normalidad pero sin la foto del trait ni su efecto.
 *    - El bot rival sí puede poseer traits y funcionan normalmente.
 * 5. Duración: 1 turno (la ronda actual). Al pasar de ronda, se limpia el modificador.
 */

(function () {
  'use strict';

  // 8 Sectores de estadísticas con colores vivos e iconos
  const STAT_SECTORS = [
    { id: 'ninjutsu', name: 'Ninjutsu', icon: '🌀', color: '#7c3aed', accent: '#a78bfa' },
    { id: 'taijutsu', name: 'Taijutsu', icon: '👊', color: '#ea580c', accent: '#fb923c' },
    { id: 'resistencia', name: 'Resistencia', icon: '🛡️', color: '#0891b2', accent: '#38bdf8' },
    { id: 'velocidad', name: 'Velocidad', icon: '⚡', color: '#ca8a04', accent: '#fde047' },
    { id: 'defensa', name: 'Defensa', icon: '🏰', color: '#2563eb', accent: '#60a5fa' },
    { id: 'fisico', name: 'Físico', icon: '💥', color: '#dc2626', accent: '#f87171' },
    { id: 'media', name: 'Media', icon: '📊', color: '#059669', accent: '#34d399' },
    { id: 'todas', name: 'Todas', icon: '⭐', color: '#db2777', accent: '#f472b6' }
  ];

  const STAT_NAME_MAP = {
    ninjutsu: 'Ninjutsu',
    taijutsu: 'Taijutsu',
    resistencia: 'Resistencia',
    velocidad: 'Velocidad',
    defensa: 'Defensa',
    fisico: 'Físico',
    media: 'Media',
    todas: 'Todas las Stats'
  };

  // Estado activo del Gambling Mode para el combate
  let currentRoundModifier = null;
  let activeOverlayEl = null;
  let animationInProgress = false;

  /**
   * Determina si estamos en la última ronda del combate
   */
  function isLastBattleRound() {
    if (!window.battleState) return false;
    const teamLen = window.battleState.playerTeam ? window.battleState.playerTeam.length : 7;
    const usedCards = Array.isArray(window.battleState.playerUsedCards) ? window.battleState.playerUsedCards.length : 0;
    const usedStats = Array.isArray(window.battleState.playerUsedStats) ? window.battleState.playerUsedStats.length : 0;
    return (usedCards >= teamLen - 1) || (usedStats >= teamLen - 1);
  }

  /**
   * Reproduce efecto sonoro de forma segura
   */
  function safePlaySFX(sfxKey) {
    try {
      if (typeof window.playSFX === 'function') {
        window.playSFX(sfxKey);
      }
    } catch (e) {
      // Ignorar errores de audio
    }
  }

  /**
   * Dibuja la ruleta de 8 sectores en el Canvas
   */
  function drawWheel(canvas, currentRotationAngle) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    const cx = width / 2;
    const cy = height / 2;
    const radius = cx - 18;

    ctx.clearRect(0, 0, width, height);

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(currentRotationAngle);

    const numSectors = STAT_SECTORS.length;
    const sliceAngle = (2 * Math.PI) / numSectors;

    for (let i = 0; i < numSectors; i++) {
      const sector = STAT_SECTORS[i];
      const startAngle = i * sliceAngle;
      const endAngle = startAngle + sliceAngle;

      // Fondo de la porción con degradado radial
      const grad = ctx.createRadialGradient(0, 0, 30, 0, 0, radius);
      grad.addColorStop(0, '#1e293b');
      grad.addColorStop(0.35, sector.color);
      grad.addColorStop(1, '#0f172a');

      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();

      // Borde del sector
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.25)';
      ctx.lineWidth = 3;
      ctx.stroke();

      // Pequeñas luces doradas en el arco exterior
      const midAngle = startAngle + sliceAngle / 2;
      const bulbX = Math.cos(midAngle) * (radius - 10);
      const bulbY = Math.sin(midAngle) * (radius - 10);
      ctx.beginPath();
      ctx.arc(bulbX, bulbY, 5, 0, 2 * Math.PI);
      ctx.fillStyle = '#fde047';
      ctx.shadowColor = '#f59e0b';
      ctx.shadowBlur = 8;
      ctx.fill();
      ctx.shadowBlur = 0;

      // Icono y Texto orientados radialmente
      ctx.save();
      ctx.rotate(midAngle);
      ctx.textAlign = 'right';
      ctx.textBaseline = 'middle';

      // Icono
      ctx.font = 'bold 28px sans-serif';
      ctx.fillText(sector.icon, radius - 30, 0);

      // Etiqueta
      ctx.font = 'bold 20px "Cinzel", "Arial Black", sans-serif';
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = '#000000';
      ctx.shadowBlur = 6;
      ctx.fillText(sector.name.toUpperCase(), radius - 68, 0);
      ctx.shadowBlur = 0;

      ctx.restore();
    }

    // Borde exterior dorado
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, 2 * Math.PI);
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 10;
    ctx.shadowColor = 'rgba(245, 158, 11, 0.7)';
    ctx.shadowBlur = 15;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Aro interior de refuerzo
    ctx.beginPath();
    ctx.arc(0, 0, radius - 6, 0, 2 * Math.PI);
    ctx.strokeStyle = '#fde047';
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.restore();
  }

  /**
   * Crea el HTML del overlay e inyecta al DOM
   */
  function createGamblingOverlay(playerCard, opponentCard) {
    // Remover overlay previo si quedó alguno
    const existing = document.getElementById('gambling-mode-overlay');
    if (existing) existing.remove();

    const playerName = playerCard ? (playerCard.name || playerCard.nombre || 'Tu Carta') : 'Tu Carta';
    const opponentName = opponentCard ? (opponentCard.name || opponentCard.nombre || 'Rival') : 'Rival';

    const overlay = document.createElement('div');
    overlay.className = 'gambling-mode-overlay';
    overlay.id = 'gambling-mode-overlay';

    overlay.innerHTML = `
      <div class="gambling-mode-container">
        <div class="gambling-header">
          <div class="gambling-badge">⚡ COMBATE DE EVENTO ESPECIAL ⚡</div>
          <h1 class="gambling-title">GAMBLING MODE</h1>
          <p class="gambling-subtitle">La ruleta de la suerte determinará los modificadores de este turno</p>
        </div>

        <div class="gambling-cards-duel-preview">
          <div class="gambling-card-pill player">
            <span>TU CARTA:</span> <strong>${escapeHtml(playerName)}</strong>
          </div>
          <div class="gambling-vs-text">VS</div>
          <div class="gambling-card-pill opponent">
            <span>RIVAL:</span> <strong>${escapeHtml(opponentName)}</strong>
          </div>
        </div>

        <div class="gambling-main-row">
          <!-- Columna 1: Modificador Box -->
          <div class="gambling-mod-col">
            <div class="gambling-section-label">Modificador</div>
            <div class="gambling-modifier-box" id="gambling-modifier-box">???</div>
          </div>

          <!-- Columna 2: Ruleta 8 Stats -->
          <div class="gambling-wheel-col">
            <div class="gambling-section-label">Estadística</div>
            <div class="gambling-wheel-wrapper">
              <canvas class="gambling-wheel-canvas" id="gambling-wheel-canvas" width="540" height="540"></canvas>
              <div class="gambling-wheel-pointer" id="gambling-wheel-pointer"></div>
              <div class="gambling-wheel-center-cap">🎰</div>
            </div>
          </div>

          <!-- Columna 3: Mini-Ruleta de Porcentaje -->
          <div class="gambling-percent-col">
            <div class="gambling-section-label">Porcentaje / Efecto</div>
            <div class="gambling-percent-box" id="gambling-percent-box">
              <span id="gambling-percent-val">--%</span>
              <span class="gambling-percent-sublabel" id="gambling-percent-sublabel">Esperando...</span>
            </div>
          </div>
        </div>

        <!-- Banner de Resultado Final -->
        <div class="gambling-result-banner" id="gambling-result-banner"></div>

        <button type="button" class="gambling-continue-btn" id="gambling-continue-btn" style="display: none;">
          ¡A LUCHAR!
        </button>
      </div>
    `;

    document.body.appendChild(overlay);
    activeOverlayEl = overlay;
    return overlay;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  /**
   * Ejecuta la secuencia completa de Gambling Mode
   */
  async function triggerGamblingRoulette() {
    if (animationInProgress) return;
    animationInProgress = true;

    return new Promise((resolve) => {
      try {
        const playerCard = window.battleState?.playerCurrentCard;
        const opponentCard = window.battleState?.opponentCurrentCard;

        const overlay = createGamblingOverlay(playerCard, opponentCard);
        const canvas = document.getElementById('gambling-wheel-canvas');
        const modifierBox = document.getElementById('gambling-modifier-box');
        const percentBox = document.getElementById('gambling-percent-box');
        const percentVal = document.getElementById('gambling-percent-val');
        const percentSub = document.getElementById('gambling-percent-sublabel');
        const resultBanner = document.getElementById('gambling-result-banner');
        const continueBtn = document.getElementById('gambling-continue-btn');
        const pointer = document.getElementById('gambling-wheel-pointer');

        // 1. Determinar el modificador que saldrá
        const isLastRound = isLastBattleRound();
        const availableMods = isLastRound ? ['AUMENTO', 'NERFEO'] : ['AUMENTO', 'NERFEO', 'BLOQUEO'];
        const chosenModType = availableMods[Math.floor(Math.random() * availableMods.length)];

        // 2. Determinar la estadística afectada
        let chosenSectorIndex;
        if (chosenModType === 'BLOQUEO') {
          // Bloqueo NO puede ser 'todas' (índice 7)
          // Además preferimos una stat que el jugador aún no haya gastado
          const selectableIndices = [0, 1, 2, 3, 4, 5, 6].filter(idx => {
            const statId = STAT_SECTORS[idx].id;
            return !window.battleState?.playerUsedStats?.includes(statId);
          });
          if (selectableIndices.length > 0) {
            chosenSectorIndex = selectableIndices[Math.floor(Math.random() * selectableIndices.length)];
          } else {
            chosenSectorIndex = Math.floor(Math.random() * 7); // 0 a 6
          }
        } else {
          // Aumento y Nerfeo pueden salir en cualquiera de los 8 sectores
          chosenSectorIndex = Math.floor(Math.random() * 8);
        }
        const chosenSector = STAT_SECTORS[chosenSectorIndex];

        // 3. Determinar el porcentaje
        let chosenPercentage = 0;
        if (chosenModType === 'AUMENTO') {
          // 1% al 10%
          chosenPercentage = Math.floor(Math.random() * 10) + 1;
        } else if (chosenModType === 'NERFEO') {
          // 1% al 20%
          chosenPercentage = Math.floor(Math.random() * 20) + 1;
        }

        // Renderizado inicial de la ruleta estática a 0 radianes
        let currentWheelAngle = 0;
        drawWheel(canvas, currentWheelAngle);

        safePlaySFX('roulette');

        // ========================================================
        // FASE 1: GIRO CONJUNTO DEL MODIFICADOR Y LA RULETA DE STATS
        // ========================================================
        let modRollTimer = null;
        const modCycleOptions = ['AUMENTO', 'NERFEO', 'BLOQUEO'];
        let cycleIdx = 0;

        modRollTimer = setInterval(() => {
          cycleIdx = (cycleIdx + 1) % modCycleOptions.length;
          const opt = modCycleOptions[cycleIdx];
          modifierBox.textContent = opt;
          modifierBox.className = 'gambling-modifier-box';
          if (opt === 'AUMENTO') modifierBox.classList.add('aumento');
          else if (opt === 'NERFEO') modifierBox.classList.add('nerfeo');
          else if (opt === 'BLOQUEO') modifierBox.classList.add('bloqueo');
        }, 90);

        // Giro de la Ruleta (Canvas con física de deceleración)
        const numSectors = STAT_SECTORS.length;
        const sliceAngle = (2 * Math.PI) / numSectors;
        // Queremos que el centro del sector quede exactamente arriba (-Math.PI/2)
        const fullSpins = 4 + Math.floor(Math.random() * 3); // 4 a 6 vueltas completas
        const sectorCenterAngle = (chosenSectorIndex + 0.5) * sliceAngle;
        const targetWheelAngle = (3 * Math.PI / 2) - sectorCenterAngle + (fullSpins * 2 * Math.PI);

        const wheelDurationMs = 3200;
        const wheelStartTime = performance.now();

        let lastTickSector = -1;

        function animateWheel(now) {
          const elapsed = now - wheelStartTime;
          const t = Math.min(1, elapsed / wheelDurationMs);
          // Easing cubic-out para frenada ultra suave
          const ease = 1 - Math.pow(1 - t, 3.2);

          currentWheelAngle = targetWheelAngle * ease;
          drawWheel(canvas, currentWheelAngle);

          // Tick de puntero en cada cruce de sector
          const effectiveTopAngle = (-currentWheelAngle - Math.PI / 2) % (2 * Math.PI);
          const positiveAngle = (effectiveTopAngle + 2 * Math.PI) % (2 * Math.PI);
          const currentSectorIdx = Math.floor(positiveAngle / sliceAngle);

          if (currentSectorIdx !== lastTickSector) {
            lastTickSector = currentSectorIdx;
            if (pointer) {
              pointer.style.transform = 'translateX(-50%) rotate(-12deg)';
              setTimeout(() => {
                if (pointer) pointer.style.transform = 'translateX(-50%) rotate(0deg)';
              }, 40);
            }
            if (t < 0.9) {
              safePlaySFX('cardSelect');
            }
          }

          if (t < 1 && animationInProgress) {
            requestAnimationFrame(animateWheel);
          } else {
            // Fin del giro de la ruleta
            currentWheelAngle = targetWheelAngle;
            drawWheel(canvas, currentWheelAngle);
            if (pointer) pointer.style.transform = 'translateX(-50%) rotate(0deg)';
          }
        }

        requestAnimationFrame(animateWheel);

        // ========================================================
        // FASE 2: DETENCIÓN DEL MODIFICADOR (a los ~1.6 segundos)
        // ========================================================
        setTimeout(() => {
          if (!animationInProgress) return;
          clearInterval(modRollTimer);
          modifierBox.textContent = chosenModType;
          modifierBox.className = 'gambling-modifier-box ' + chosenModType.toLowerCase();
          safePlaySFX('cardSelect');

          // Efecto de pulso e impacto
          modifierBox.style.transform = 'scale(1.12)';
          setTimeout(() => {
            if (modifierBox) modifierBox.style.transform = '';
          }, 180);
        }, 1600);

        // ========================================================
        // FASE 3: DETENCIÓN DE LA RULETA Y ROLLO DEL PORCENTAJE (a los ~3.3 segundos)
        // ========================================================
        setTimeout(() => {
          if (!animationInProgress) return;

          safePlaySFX('cardSelect');

          // Iniciar Mini Ruleta de Porcentaje
          if (chosenModType === 'BLOQUEO') {
            percentBox.className = 'gambling-percent-box locked-state';
            percentVal.textContent = '🔒 NO DISPONIBLE';
            percentVal.style.fontSize = '1.35rem';
            percentVal.style.color = '#cbd5e1';
            percentSub.textContent = 'ESTADÍSTICA BLOQUEADA';
            triggerPhaseResult();
          } else {
            // Aumento o Nerfeo -> Ruleta de porcentaje
            const maxVal = (chosenModType === 'AUMENTO') ? 10 : 20;
            const prefix = (chosenModType === 'AUMENTO') ? '+' : '-';
            percentBox.className = 'gambling-percent-box';
            percentSub.textContent = (chosenModType === 'AUMENTO') ? 'AMBOS JUGADORES' : 'SOLO TU CARTA';

            let countRolls = 0;
            const rollInterval = setInterval(() => {
              countRolls++;
              const fakeVal = Math.floor(Math.random() * maxVal) + 1;
              percentVal.textContent = `${prefix}${fakeVal}%`;
              percentVal.style.fontSize = '2.2rem';
              percentVal.style.color = (chosenModType === 'AUMENTO') ? '#4ade80' : '#f87171';
              safePlaySFX('cardSelect');

              if (countRolls > 14) {
                clearInterval(rollInterval);
                percentVal.textContent = `${prefix}${chosenPercentage}%`;
                percentVal.style.transform = 'scale(1.15)';
                setTimeout(() => {
                  if (percentVal) percentVal.style.transform = '';
                }, 180);
                triggerPhaseResult();
              }
            }, 60);
          }
        }, 3350);

        // ========================================================
        // FASE 4: MOSTRAR RESULTADO FINAL Y BOTÓN
        // ========================================================
        function triggerPhaseResult() {
          setTimeout(() => {
            if (!animationInProgress) return;

            safePlaySFX('packImpact');

            // Guardar el modificador en el estado del combate
            currentRoundModifier = {
              type: chosenModType,
              stat: chosenSector.id,
              statName: chosenSector.name,
              percentage: chosenPercentage,
              appliedTo: (chosenModType === 'AUMENTO') ? 'both' : ((chosenModType === 'NERFEO') ? 'player' : 'both')
            };

            if (window.battleState) {
              window.battleState.gamblingModifier = currentRoundModifier;
              if (chosenModType === 'BLOQUEO') {
                window.battleState.gamblingBlockedStat = chosenSector.id;
              } else {
                window.battleState.gamblingBlockedStat = null;
              }
            }

            // Construir texto del banner
            let bannerHTML = '';
            if (chosenModType === 'AUMENTO') {
              resultBanner.className = 'gambling-result-banner aumento show';
              bannerHTML = `
                <div>¡AUMENTO DE <strong>${chosenSector.name.toUpperCase()}</strong>: +${chosenPercentage}%!</div>
                <div style="font-size: 0.9rem; font-weight: 600; margin-top: 4px; opacity: 0.9;">
                  Potencia las estadísticas de AMBOS combatientes este turno.
                </div>
              `;
            } else if (chosenModType === 'NERFEO') {
              resultBanner.className = 'gambling-result-banner nerfeo show';
              bannerHTML = `
                <div>¡NERFEO DE <strong>${chosenSector.name.toUpperCase()}</strong>: -${chosenPercentage}%!</div>
                <div style="font-size: 0.9rem; font-weight: 600; margin-top: 4px; opacity: 0.9;">
                  Afecta ÚNICAMENTE a tu carta en este turno.
                </div>
              `;
            } else {
              resultBanner.className = 'gambling-result-banner bloqueo show';
              bannerHTML = `
                <div>¡BLOQUEO: <strong>${chosenSector.name.toUpperCase()}</strong> NO SE PUEDE ELEGIR!</div>
                <div style="font-size: 0.9rem; font-weight: 600; margin-top: 4px; opacity: 0.9;">
                  Ningún combatiente puede seleccionar esta estadística durante esta ronda.
                </div>
              `;
            }

            resultBanner.innerHTML = bannerHTML;
            if (continueBtn) {
              continueBtn.style.display = 'inline-block';
            }

            // Auto-cerrar después de 2.6 segundos si el usuario no pulsa el botón
            const autoCloseTimer = setTimeout(() => {
              finishAndClose();
            }, 2600);

            if (continueBtn) {
              continueBtn.onclick = () => {
                clearTimeout(autoCloseTimer);
                finishAndClose();
              };
            }
          }, 400);
        }

        // ========================================================
        // FASE 5: CIERRE Y LIMPIEZA DEL OVERLAY
        // ========================================================
        function finishAndClose() {
          if (!activeOverlayEl) {
            resolve(currentRoundModifier);
            return;
          }

          activeOverlayEl.style.transition = 'opacity 0.25s ease-out, transform 0.25s ease-out';
          activeOverlayEl.style.opacity = '0';
          activeOverlayEl.style.transform = 'scale(0.97)';

          setTimeout(() => {
            if (activeOverlayEl) {
              activeOverlayEl.remove();
              activeOverlayEl = null;
            }
            animationInProgress = false;
            resolve(currentRoundModifier);
          }, 250);
        }

      } catch (err) {
        console.error('[GAMBLING-MODE] Error durante la ruleta:', err);
        animationInProgress = false;
        if (activeOverlayEl) {
          activeOverlayEl.remove();
          activeOverlayEl = null;
        }
        resolve(null);
      }
    });
  }

  /**
   * Cierra inmediatamente el overlay si el combate es cancelado
   */
  function closeOverlay() {
    animationInProgress = false;
    if (activeOverlayEl) {
      activeOverlayEl.remove();
      activeOverlayEl = null;
    }
  }

  /**
   * Limpia el modificador de la ronda anterior (llamado en nextRound)
   */
  function clearRoundModifier() {
    currentRoundModifier = null;
    if (window.battleState) {
      window.battleState.gamblingModifier = null;
      window.battleState.gamblingBlockedStat = null;
      window.battleState.gamblingRolledForRound = false;
    }
  }

  /**
   * Calcula el delta numérico sobre una estadística dada por efecto de Gambling Mode
   * 
   * @param {string} side - 'player' | 'opponent'
   * @param {object} card - Carta en combate
   * @param {string} statType - 'ninjutsu' | 'taijutsu' | ... | 'media'
   * @param {number} baseValue - Valor base de la estadística
   * @returns {number} Delta numérico a sumar a la estadística
   */
  function getCardStatDelta(side, card, statType, baseValue) {
    if (!window.isSpecialEventBattle) return 0;
    if (!currentRoundModifier || !Number.isFinite(baseValue) || baseValue <= 0) return 0;

    const mod = currentRoundModifier;
    const normStat = String(statType || '').toLowerCase();
    const targetStat = String(mod.stat || '').toLowerCase();

    // Comprobar si la estadística coincide (o si es 'todas')
    const statMatches = (targetStat === 'todas') || (targetStat === normStat);
    if (!statMatches) return 0;

    // 1. AUMENTO: Aplica a AMBOS (jugador y bot)
    if (mod.type === 'AUMENTO') {
      const pct = Number(mod.percentage) || 0;
      if (pct <= 0) return 0;
      const delta = Math.round(baseValue * (pct / 100));
      return Math.max(1, delta);
    }

    // 2. NERFEO: Aplica ÚNICAMENTE al jugador
    if (mod.type === 'NERFEO') {
      if (side !== 'player') return 0; // El bot rival no recibe nerfeo
      const pct = Number(mod.percentage) || 0;
      if (pct <= 0) return 0;
      const delta = Math.round(baseValue * (pct / 100));
      return -Math.max(1, delta);
    }

    // 3. BLOQUEO: No altera el número, solo impide la selección
    return 0;
  }

  /**
   * Comprueba si una estadística está bloqueada por Gambling Mode en esta ronda
   */
  function isStatBlocked(statType) {
    if (!window.isSpecialEventBattle) return false;
    if (!currentRoundModifier || currentRoundModifier.type !== 'BLOQUEO') return false;
    const target = String(currentRoundModifier.stat || '').toLowerCase();
    const query = String(statType || '').toLowerCase();
    return target === query;
  }

  /**
   * Devuelve el modificador actual si existe
   */
  function getActiveModifier() {
    return currentRoundModifier;
  }

  // ==========================================================================
  // EXPOSICIÓN GLOBAL
  // ==========================================================================
  window.GamblingMode = {
    triggerGamblingRoulette,
    closeOverlay,
    clearRoundModifier,
    getCardStatDelta,
    isStatBlocked,
    getActiveModifier,
    STAT_SECTORS,
    STAT_NAME_MAP
  };

  console.log('[GAMBLING-MODE] Módulo Gambling Mode cargado e inicializado correctamente.');
})();
