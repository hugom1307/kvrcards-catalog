async function startBattleRoulette() {
  // Si estamos en un estado de combate activo pero quedaron flags residuales del combate anterior, limpiarlos
  if (window.battleState && !window.battleState.isAbandoned) {
    window.__battleEnded = false;
    window.__battleCancelled = false;
  }

  if (window.battleState?.isAbandoned) {
    console.log('[BATTLE] startBattleRoulette abortado: combate abandonado');
    return;
  }
  console.log('[BATTLE] Iniciando ruleta...');
  
  // Cortar música de introbatalla inmediatamente al comenzar la ruleta
  if (typeof stopBattleIntroMusic === 'function') {
    stopBattleIntroMusic();
  } else if (typeof window.stopBattleIntroMusic === 'function') {
    window.stopBattleIntroMusic();
  }
  if (typeof stopBackgroundMusic === 'function') {
    stopBackgroundMusic();
  }

  // Asegurar que las stats y cartas usadas comiencen 100% limpias al inicio del combate
  if (!window.battleState.currentRound || window.battleState.currentRound <= 1) {
    window.battleState.playerUsedStats = [];
    window.battleState.opponentUsedStats = [];
    window.battleState.selectedStat = null;
    window.battleState.opponentSelectedStat = null;
    window.battleState.annulledStat = null;
    window.battleState.playerUsedCards = [];
    window.battleState.opponentUsedCards = [];

    // Limpiar DOM de botones de stats
    document.querySelectorAll('.battle-stat-btn, .battle-stat-display').forEach(el => {
      el.classList.remove('used', 'highlighted', 'annulled', 'disabled', 'selected', 'nerfed');
      el.disabled = false;
      el.style.opacity = '';
      el.style.borderColor = '';
      el.style.background = '';
      el.style.boxShadow = '';
      const label = el.querySelector('.stat-label');
      if (label) {
        label.innerHTML = label.innerHTML.replace(/\(BLOQUEADO\)\s*/g, '').replace(/\u{1F512}\s*/gu, '');
      }
    });
  }
  
  // Guardar la carta inicial que el jugador eligió en la animación
  let initialPlayerCard = window.battleState.playerCurrentCard;
  let initialOpponentCard = window.battleState.opponentCurrentCard;
  
  console.log('[BATTLE] Cartas guardadas antes de ruleta:');
  console.log('[BATTLE] - Jugador:', initialPlayerCard?.nombre || initialPlayerCard?.name);
  console.log('[BATTLE] - Oponente:', initialOpponentCard?.nombre || initialOpponentCard?.name);
  
  // Obtener avatar del jugador
  const playerUsername = (typeof getEffectiveOnlineUsername === 'function') 
    ? getEffectiveOnlineUsername() 
    : (localStorage.getItem('username') || localStorage.getItem('kvrUsername') || 'Jugador');
  let playerAvatar = (typeof userAvatar === 'string' && userAvatar.startsWith('data:image'))
    ? userAvatar
    : (localStorage.getItem('kvrAvatar_' + playerUsername) || '');
  try {
    if (isElectron && (!playerAvatar || !playerAvatar.startsWith('data:image'))) {
      const userResult = await window.kvrcards.getUserProfile();
      if (userResult?.ok && userResult?.profile) {
        playerAvatar = userResult.profile.profileImage || playerAvatar;
      } else if (userResult?.profileImage) {
        playerAvatar = userResult.profileImage;
      }
    }
  } catch (error) {
    console.error('[BATTLE] Error obteniendo avatar:', error);
  }
  
  // Obtener avatar del oponente (online o IA)
  const opponentUsername = (window.battleState?.opponentName && window.battleState.opponentName !== 'Jugador')
    ? window.battleState.opponentName
    : (window.onlineState?.opponentData?.username || 'opponent');
  let opponentAvatar = '';
  if (window.battleState.isOnline) {
    opponentAvatar = window.onlineState.opponentData?.profileImage || window.onlineState.opponentData?.avatar || '';
  } else {
    opponentAvatar = getOpponentAvatar(window.battleState.difficulty);
  }
  
  // Mostrar ruleta
  const roulette = document.getElementById('battle-roulette');
  const rouletteWheel = document.getElementById('roulette-wheel');
  const battleScreen = document.getElementById('battle-screen');
  const playerRouletteEl = document.getElementById('roulette-player-avatar');
  if (playerRouletteEl) {
    if (typeof window.applyAvatarToElement === 'function') {
      window.applyAvatarToElement(playerRouletteEl, playerAvatar, playerUsername);
    } else {
      playerRouletteEl.src = playerAvatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(playerUsername)}`;
    }
  }
  const oppRouletteEl = document.getElementById('roulette-opponent-avatar');
  if (oppRouletteEl) {
    if (typeof window.applyAvatarToElement === 'function') {
      window.applyAvatarToElement(oppRouletteEl, opponentAvatar, opponentUsername);
    } else {
      oppRouletteEl.src = opponentAvatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(opponentUsername)}`;
    }
  }

  // Decidir quién empieza basándose en el servidor (sincronizado) o localmente
  let playerStarts;
  if (window.battleState.isOnline && window.battleState.firstPlayer !== undefined) {
    // Usar decisión del servidor
    playerStarts = window.battleState.firstPlayer;
  } else {
    // Modo offline: decidir localmente
    playerStarts = Math.random() < 0.5;
  }
  
  window.battleState.currentTurn = playerStarts ? 'player' : 'opponent';
  window.battleState.roundWinner = window.battleState.currentTurn;
  
  // 1. Resetear rotación y resultado previo
  rouletteWheel.style.transition = 'none';
  rouletteWheel.style.transform = 'rotate(0deg)';
  const prevResult = document.getElementById('roulette-result');
  if (prevResult) prevResult.textContent = '';
  
  // 2. Mostrar la ruleta y desenfocar tablero
  if (battleScreen) battleScreen.classList.add('blurred');
  roulette.style.display = 'flex';
  
  // 3. Forzar reflujo sincrónico en la rueda
  void rouletteWheel.offsetWidth;

  // 4. Esperar dos requestAnimationFrame para asegurar que el navegador ha pintado el estado base (0deg)
  await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));

  if (window.battleState?.isAbandoned) {
    abortRouletteCleanup();
    return;
  }
  
  // 5. Reproducir sonido de ruleta
  playSFX('roulette');
  
  // Calcular rotación final para que la flecha apunte al ganador
  // IMPORTANTE: Al girar en sentido horario, la mitad izquierda (jugador) pasa por arriba PRIMERO
  const baseRotations = 1440; // 4 vueltas completas
  let finalAngle;
  
  if (playerStarts) {
    // Jugador gana: necesita girar 90° para que la mitad izquierda quede arriba
    finalAngle = baseRotations + 90 + (Math.random() * 40 - 20); // ±20° de variación
  } else {
    // Oponente gana: necesita girar 270° para que la mitad derecha quede arriba
    finalAngle = baseRotations + 270 + (Math.random() * 40 - 20);
  }
  
  // Aplicar transición y rotación: Ahora garantizado que siempre anima fluidamente
  rouletteWheel.style.transition = 'transform 5s cubic-bezier(0.25, 0.1, 0.25, 1)';
  rouletteWheel.style.transform = `rotate(${finalAngle}deg)`;
  
  const abortRouletteCleanup = () => {
    console.log('[BATTLE] Ruleta abortada: limpiando elementos visuales...');
    if (roulette) roulette.style.display = 'none';
    if (battleScreen) {
      battleScreen.classList.remove('blurred');
      battleScreen.style.pointerEvents = '';
    }
    if (rouletteWheel) {
      rouletteWheel.style.transition = 'none';
      rouletteWheel.style.transform = 'rotate(0deg)';
    }
    const res = document.getElementById('roulette-result');
    if (res) res.textContent = '';
  };

  // Esperar animación (5 segundos de giro)
  await (typeof window.battleSleep === 'function' ? window.battleSleep(5000) : new Promise(resolve => setTimeout(resolve, 5000)));
  if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) {
    abortRouletteCleanup();
    return;
  }
  
  // Mostrar resultado
  const isInfiniteBattle = !!(window.__infiniteBattleContext && window.__infiniteBattleContext.active);
  const activeMod = isInfiniteBattle ? (window.battleState?.infiniteModifier || window.__infiniteBattleContext?.modifier) : null;
  const isReservado = isInfiniteBattle && activeMod?.id === 'reservado';

  const resultText = playerStarts ? '¡TÚ EMPIEZAS!' : '¡EL OPONENTE EMPIEZA!';
  document.getElementById('roulette-result').textContent = resultText;
  
  if (isReservado && !playerStarts) {
    // Si la ruleta dio inicio al oponente, el modificador Reservado anula y reemplaza el turno
    await (typeof window.battleSleep === 'function' ? window.battleSleep(1200) : new Promise(resolve => setTimeout(resolve, 1200)));
    if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) {
      abortRouletteCleanup();
      return;
    }
    document.getElementById('roulette-result').textContent = 'RESERVADO: ¡EMPIEZAS TÚ!';
    if (typeof playSFX === 'function') playSFX('cardSelect');
    await (typeof window.battleSleep === 'function' ? window.battleSleep(1500) : new Promise(resolve => setTimeout(resolve, 1500)));
    if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) {
      abortRouletteCleanup();
      return;
    }
  } else {
    // Esperar 2 segundos adicionales para que se vea bien el ganador
    await (typeof window.battleSleep === 'function' ? window.battleSleep(2000) : new Promise(resolve => setTimeout(resolve, 2000)));
    if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) {
      abortRouletteCleanup();
      return;
    }
  }
  
  // Ocultar ruleta y resetear
  roulette.style.display = 'none';
  if (battleScreen) battleScreen.classList.remove('blurred');
  rouletteWheel.style.transition = 'none';
  rouletteWheel.style.transform = 'rotate(0deg)';

  // Si el modificador Reservado está activo, el jugador siempre empieza
  if (isReservado) {
    window.battleState.currentTurn = 'player';
    window.battleState.roundWinner = 'player';
    console.log('[BATTLE] Modificador Reservado activo: El jugador siempre actúa primero');
  }
  
  // Cambiar a música de batalla (personalizada por entrenador o por defecto)
  console.log('[BATTLE] Cambiando a música de batalla');
  if (typeof musicEnabled !== 'undefined' ? musicEnabled : true) {
    const isCustomAllowed = typeof window.isCustomBattleMusicEnabled === 'function'
      ? window.isCustomBattleMusicEnabled()
      : (localStorage.getItem('customBattleMusicEnabled') !== 'false');

    let customSong = null;
    if (isCustomAllowed && !window.battleState?.isOnline) {
      if (window.battleState?.opponentSong) {
        customSong = window.battleState.opponentSong;
      } else if (window.__infiniteBattleContext?.active && (window.__infiniteBattleContext?.battleSong || window.__infiniteBattleContext?.opponentSong)) {
        customSong = window.__infiniteBattleContext.battleSong || window.__infiniteBattleContext.opponentSong;
      }
    }

    const defaultBattleTrack = localStorage.getItem('battleMusicTrack') || (typeof BATTLE_TRACK !== 'undefined' ? BATTLE_TRACK : 'music/battlesong.mp3');
    const battleTrack = customSong || defaultBattleTrack;
    window.__battleTrackActive = true;
    
    if (customSong) {
      window.__isCustomBattleTrack = true;
      console.log('[BATTLE] Reproduciendo música de batalla personalizada (offline/infinito):', customSong);
    } else {
      window.__isCustomBattleTrack = false;
      console.log('[BATTLE] Reproduciendo música de batalla estándar del jugador:', battleTrack);
    }

    if (typeof playBackgroundMusic === 'function') {
      playBackgroundMusic(battleTrack);
    } else if (typeof window.playBackgroundMusic === 'function') {
      window.playBackgroundMusic(battleTrack);
    }
  }
  
  if (window.battleState?.isAbandoned) {
    console.log('[BATTLE] Ruleta abortada: combate abandonado.');
    abortRouletteCleanup();
    return;
  }

  // Fallback seguro si por cualquier motivo no estaban asignadas
  if (!initialPlayerCard && Array.isArray(window.battleState.playerTeam) && window.battleState.playerTeam.length > 0) {
    initialPlayerCard = window.battleState.playerTeam[0];
  }
  if (!initialOpponentCard && Array.isArray(window.battleState.opponentTeam) && window.battleState.opponentTeam.length > 0) {
    initialOpponentCard = window.battleState.opponentTeam[0];
  }

  // Restaurar las cartas iniciales que eligieron en la animación
  window.battleState.playerCurrentCard = initialPlayerCard;
  window.battleState.opponentCurrentCard = initialOpponentCard;
  
  console.log('[BATTLE] Cartas restauradas después de ruleta:');
  console.log('[BATTLE] - Jugador:', initialPlayerCard?.nombre || initialPlayerCard?.name);
  console.log('[BATTLE] - Oponente:', initialOpponentCard?.nombre || initialOpponentCard?.name);
  
  // Marcar las cartas como usadas con identificador flexible (uniqueId, instanceId, id o cardId)
  const getCardMatchKey = (c) => c ? String(c.uniqueId || c.instanceId || c.id || c.cardId || '') : '';
  const plKey = getCardMatchKey(initialPlayerCard);
  const opKey = getCardMatchKey(initialOpponentCard);

  const playerCardIndex = (Array.isArray(window.battleState.playerTeam) && plKey)
    ? window.battleState.playerTeam.findIndex(c => getCardMatchKey(c) === plKey)
    : -1;
  const opponentCardIndex = (Array.isArray(window.battleState.opponentTeam) && opKey)
    ? window.battleState.opponentTeam.findIndex(c => getCardMatchKey(c) === opKey)
    : -1;
  
  console.log('[BATTLE] Índices de cartas resueltos:', playerCardIndex, opponentCardIndex);
  
  if (playerCardIndex !== -1 && !window.battleState.playerUsedCards.includes(playerCardIndex)) {
    window.battleState.playerUsedCards.push(playerCardIndex);
  }
  if (opponentCardIndex !== -1 && !window.battleState.opponentUsedCards.includes(opponentCardIndex)) {
    if (!window.battleState?.is7v1Mode) {
      window.battleState.opponentUsedCards.push(opponentCardIndex);
    }
  }
  
  try {
    // Cambiar fase a selección de stats (ya tienen sus cartas)
    window.battleState.gamePhase = 'stat-selection';
    window.battleState.canChangeCard = false; // No pueden cambiar esta primera carta
    
    console.log('[BATTLE] Llamando a updateBattleCards...');
    updateBattleCards();
    console.log('[BATTLE] updateBattleCards ejecutado correctamente');
    
    console.log('[BATTLE] Llamando a enableStatSelection...');
    if (typeof enableStatSelection === 'function') {
      enableStatSelection();
    } else if (typeof window.enableStatSelection === 'function') {
      window.enableStatSelection();
    }
    console.log('[BATTLE] enableStatSelection ejecutado correctamente');
  } catch (error) {
    console.error('[BATTLE] ERROR activando fase de selección:', error);
  } finally {
    // Garantizar al 100% que la ruleta quede cerrada y el tablero totalmente interactivo
    if (roulette) roulette.style.display = 'none';
    if (battleScreen) {
      battleScreen.classList.remove('blurred');
      battleScreen.style.pointerEvents = '';
    }
    window.battleState.gamePhase = 'stat-selection';
    window.battleState.canChangeCard = false;
  }
  
  console.log('[BATTLE] Turno inicial:', window.battleState.currentTurn, 'con cartas ya elegidas');
  console.log('[BATTLE] VERSION CON ANIMACION ACTUALIZADA - v2.0');
}

// Limpiar cartas y mostrar espacios vacíos
function clearBattleCards() {
  const playerCardDisplay = document.querySelector('.battle-side-player .battle-card-display');
  const opponentCardDisplay = document.querySelector('.battle-side-opponent .battle-card-display');
  
  if (playerCardDisplay) {
    playerCardDisplay.classList.add('empty');
    const plTrait = playerCardDisplay.querySelector('.card-trait-icon');
    if (plTrait) plTrait.remove();
    if (typeof window.applyPlushieVisuals === 'function') {
      window.applyPlushieVisuals(playerCardDisplay, null);
    }
  }
  const is7v1 = Boolean(window.battleState?.is7v1Mode);
  if (opponentCardDisplay && !is7v1) {
    opponentCardDisplay.classList.add('empty');
    const opTrait = opponentCardDisplay.querySelector('.card-trait-icon');
    if (opTrait) opTrait.remove();
  }
  
  const playerCardImg = document.getElementById('battle-player-card');
  const opponentCardImg = document.getElementById('battle-opponent-card');
  
  if (playerCardImg) playerCardImg.style.display = 'none';
  if (opponentCardImg && !is7v1) opponentCardImg.style.display = 'none';
}

// Renderizar sidebar con el equipo del jugador
function renderTeamSidebar() {
  const container = document.getElementById('battle-team-cards');
  container.innerHTML = '';
  
  // Solo mostrar las 7 cartas principales (no la carta de reserva en index 7)
  const mainCards = window.battleState.playerTeam.slice(0, 7);
  mainCards.forEach((card, index) => {
    const cardDiv = document.createElement('div');
    cardDiv.className = 'battle-team-card';
    if (window.battleState.playerUsedCards.includes(index)) {
      cardDiv.classList.add('used');
    }
    
    const img = document.createElement('img');
    img.src = card.imageUrl || card.imagen || card.image || '';
    img.alt = card.name || card.nombre || 'Carta';
    
    cardDiv.appendChild(img);
    
    // Añadir icono de trait si existe
    const cardKey = card.uniqueId || card.id;
    const traitsMap = (typeof cardTraitsMap !== 'undefined') ? cardTraitsMap : (window.cardTraitsMap || window.battleState?.cardTraitsMap || {});
    const traitId = (typeof getCardActiveTraitId === 'function')
      ? getCardActiveTraitId(card, 'player')
      : ((traitsMap && traitsMap[cardKey]) || card.traitId);
    const traitList = (typeof availableTraits !== 'undefined' && Array.isArray(availableTraits)) ? availableTraits : (window.availableTraits || window.battleState?.availableTraits || []);
    const trait = traitId ? ((typeof window.getTraitById === 'function') ? window.getTraitById(traitId) : traitList.find(t => t.id === traitId)) : null;
    if (trait) {
      const traitIcon = document.createElement('div');
      traitIcon.className = 'card-trait-icon';
      const traitImg = document.createElement('img');
      traitImg.src = trait.imageUrl || trait.image || trait.icon || './trait.png';
      traitImg.alt = trait.name || trait.id;
      traitImg.title = trait.name || trait.id;
      traitImg.onerror = function() { this.src = './trait.png'; };
      traitIcon.appendChild(traitImg);
      cardDiv.appendChild(traitIcon);
    }

    // Aplicar badge visual de plushie si tiene uno equipado y el modo lo permite
    const isPlushiesEnabled = (typeof window.isPlushiesEnabledInBattle === 'function')
      ? window.isPlushiesEnabledInBattle()
      : true;
    if (isPlushiesEnabled && typeof window.applyPlushieVisuals === 'function') {
      window.applyPlushieVisuals(cardDiv, card.id || card.uniqueId);
    }
    
    // Click para seleccionar carta (solo si no está usada y puede cambiar)
    if (!window.battleState.playerUsedCards.includes(index) && window.battleState.canChangeCard) {
      cardDiv.addEventListener('click', () => selectPlayerCard(index));
    }
    
    container.appendChild(cardDiv);
  });
}

// Jugador selecciona una carta
function selectPlayerCard(cardIndex) {
  if (!window.battleState.canChangeCard) {
    console.log('[BATTLE] No puedes cambiar de carta en este momento');
    return;
  }
  
  if (window.battleState.gamePhase !== 'card-selection') {
    console.log('[BATTLE] No es momento de seleccionar carta');
    return;
  }
  
  const isOnlineBattle = window.battleState.isOnline || (window.onlineState && window.onlineState.inBattle);
  const is7v1 = Boolean(window.battleState?.is7v1Mode || window.is7v1Mode);
  const isInfiniteBattle = !!(window.__infiniteBattleContext && window.__infiniteBattleContext.active);
  const activeMod = isInfiniteBattle ? (window.battleState?.infiniteModifier || window.__infiniteBattleContext?.modifier) : null;
  const isReservadoRound = isInfiniteBattle && activeMod?.id === 'reservado';
  
  // BLOQUEAR si es turno del oponente y aún no ha colocado su carta (SOLO offline y no 7v1)
  if (!isOnlineBattle && !is7v1) {
    if (window.battleState.currentTurn === 'opponent' && !window.battleState.opponentCurrentCard) {
      console.log('[BATTLE] Debes esperar a que el oponente coloque su carta primero');
      return;
    }
    
    if (window.battleState.currentTurn !== 'player' && !window.battleState.waitingForCardSelection) {
      console.log('[BATTLE] No es tu turno para elegir carta');
      return;
    }
  }
  
  console.log('[BATTLE] Jugador selecciona carta:', cardIndex);
  
  // Reproducir efecto de sonido de selección de carta
  playSFX('cardSelect');
  
  window.battleState.playerCurrentCard = window.battleState.playerTeam[cardIndex];
  window.battleState.playerUsedCards.push(cardIndex);
  window.battleState.canChangeCard = false; // Bloquear cambio hasta próxima ronda
  
  // Ocultar sidebar después de elegir
  const sidebar = document.getElementById('battle-team-sidebar');
  if (sidebar) {
    sidebar.style.display = 'none';
  }
  renderTeamSidebar();

  // Actualizar cartas visualmente en el campo
  if (typeof updateBattleCards === 'function') {
    updateBattleCards();
  }

  // Marcar carta activa en el sidebar
  const cards = document.querySelectorAll('.battle-team-card');
  cards.forEach(c => c.classList.remove('active'));
  if (cards[cardIndex]) {
    cards[cardIndex].classList.add('active');
  }

  // En 7v1 el rival mantiene siempre su carta única; pasamos inmediatamente a elegir stat
  if (is7v1) {
    window.battleState.waitingForCardSelection = false;
    window.battleState.gamePhase = 'stat-selection';
    if (typeof enableStatSelection === 'function') {
      enableStatSelection();
    } else if (typeof window.enableStatSelection === 'function') {
      window.enableStatSelection();
    }
    return;
  }
  
  // Si el oponente ya colocó su carta, pasar a selección de stats
  if (window.battleState.opponentCurrentCard) {
    window.battleState.gamePhase = 'stat-selection';
    if (typeof enableStatSelection === 'function') {
      enableStatSelection();
    } else if (typeof window.enableStatSelection === 'function') {
      window.enableStatSelection();
    }
  } else {
    // Si el jugador eligió primero, esperar a que el oponente elija su carta
    window.battleState.waitingForCardSelection = false;
    if (typeof opponentSelectsCard === 'function') {
      opponentSelectsCard();
    } else if (typeof window.opponentSelectsCard === 'function') {
      window.opponentSelectsCard();
    }
  }
  
  console.log('[BATTLE] Carta seleccionada. Fase:', window.battleState.gamePhase, 'Turno:', window.battleState.currentTurn);
}

// Finalizar batalla

// Auxiliary functions for IA Estratégica Combinatoria 7v7 Alternativo
function selectOptimalCardAlternativeMode(availableIndices) {
  const opponentTeam = window.battleState.opponentTeam;
  const playerTeam = window.battleState.playerTeam;
  const playerUsedCards = window.battleState.playerUsedCards || [];
  
  const availablePlayerCards = [];
  for (let i = 0; i < playerTeam.length; i++) {
    if (!playerUsedCards.includes(i)) {
      availablePlayerCards.push(playerTeam[i]);
    }
  }
  
  const playerCard = window.battleState.playerCurrentCard;
  
  // Si el jugador ya eligió su carta
  if (playerCard) {
    let bestCardIndex = availableIndices[0];
    let bestScore = -Infinity;
    
    for (const idx of availableIndices) {
      const opCard = opponentTeam[idx];
      const score = evaluateCardMatchup(opCard, playerCard);
      if (score > bestScore) {
        bestScore = score;
        bestCardIndex = idx;
      }
    }
    return bestCardIndex;
  } else {
    // Si la IA elige primero, evalúa su carta contra el promedio esperado contra todas las del jugador
    let bestCardIndex = availableIndices[0];
    let bestScore = -Infinity;
    
    for (const idx of availableIndices) {
      const opCard = opponentTeam[idx];
      let totalScore = 0;
      
      if (availablePlayerCards.length > 0) {
        for (const pCard of availablePlayerCards) {
          totalScore += evaluateCardMatchup(opCard, pCard);
        }
        const avgScore = totalScore / availablePlayerCards.length;
        if (avgScore > bestScore) {
          bestScore = avgScore;
          bestCardIndex = idx;
        }
      }
    }
    return bestCardIndex;
  }
}

function evaluateCardMatchup(opCard, playerCard) {
  const availableStats = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
    .filter(s => !window.battleState.opponentUsedStats.includes(s));
  
  if (availableStats.length === 0) return 0;
  
  const isOpponentTurnToSelectStat = window.battleState.currentTurn === 'opponent';
  
  if (isOpponentTurnToSelectStat) {
    // La IA elegirá la stat que maximice la diferencia de puntos a su favor
    let maxDiff = -Infinity;
    for (const stat of availableStats) {
      const opVal = getStatValue(opCard, stat, 'opponent');
      const plVal = getStatValue(playerCard, stat, 'player');
      const diff = opVal - plVal;
      if (diff > maxDiff) {
        maxDiff = diff;
      }
    }
    return maxDiff;
  } else {
    // Si es el turno del jugador de elegir stat, asumimos que elegirá de sus stats disponibles la que minimice nuestra ganancia
    const playerAvailableStats = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
      .filter(s => !window.battleState.playerUsedStats.includes(s));
      
    if (playerAvailableStats.length === 0) return 0;
    
    let minDiff = Infinity;
    for (const stat of playerAvailableStats) {
      const opVal = getStatValue(opCard, stat, 'opponent');
      const plVal = getStatValue(playerCard, stat, 'player');
      const diff = opVal - plVal;
      if (diff < minDiff) {
        minDiff = diff;
      }
    }
    return minDiff;
  }
}

// Asegurar exposición global de funciones críticas
window.startBattleRoulette = startBattleRoulette;
