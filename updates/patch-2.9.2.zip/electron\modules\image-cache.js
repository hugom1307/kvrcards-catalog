const path = require('path');
const fs = require('fs');
const http = require('http');
const https = require('https');

let localImageDir = '';
let imageServerPort = 0;
let imageHttpServer = null;
let isDownloading = false;

const isImgFile = (p) => typeof p === 'string' && /\.(png|jpe?g|webp|gif|svg|ico)$/i.test(p);

// Obtener la ruta de almacenamiento de imágenes en userData
function getLocalImageCacheDir(app) {
  if (localImageDir) return localImageDir;
  const userDir = app.getPath('userData');
  localImageDir = path.join(userDir, 'data', 'image-cache');
  if (!fs.existsSync(localImageDir)) {
    try {
      fs.mkdirSync(localImageDir, { recursive: true });
    } catch (e) {
      console.error('[IMAGE-CACHE] Error creando directorio de caché:', e);
    }
  }
  return localImageDir;
}

// Iniciar servidor local HTTP en loopback (127.0.0.1)
function startLocalImageServer(cacheDir) {
  if (imageHttpServer) return;

  const mimeTypes = {
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon'
  };

  imageHttpServer = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    try {
      const rawUrl = req.url.split('?')[0];
      const relPath = decodeURIComponent(rawUrl.replace(/^\/+/, ''));
      const safePath = path.normalize(relPath).replace(/^(\.\.[\/\\])+/, '');
      const filePath = path.join(cacheDir, safePath);

      if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
        const ext = path.extname(filePath).toLowerCase();
        res.setHeader('Content-Type', mimeTypes[ext] || 'application/octet-stream');
        res.setHeader('Cache-Control', 'public, max-age=31536000');
        const stream = fs.createReadStream(filePath);
        stream.on('error', () => {
          if (!res.headersSent) {
            res.statusCode = 500;
            res.end('Error reading file');
          }
        });
        stream.pipe(res);
      } else {
        res.statusCode = 404;
        res.end('Not found');
      }
    } catch (err) {
      res.statusCode = 500;
      res.end('Server error');
    }
  });

  imageHttpServer.listen(0, '127.0.0.1', () => {
    imageServerPort = imageHttpServer.address().port;
    console.log(`[IMAGE-CACHE] Servidor local de imágenes activo en http://127.0.0.1:${imageServerPort}`);
  });

  imageHttpServer.on('error', (err) => {
    console.error('[IMAGE-CACHE] Error en servidor local de imágenes:', err);
  });
}

// Configurar interceptor webRequest de Electron para servir desde caché local
function setupWebRequestInterceptor(session, cacheDir) {
  if (!session || !session.defaultSession) return;

  session.defaultSession.webRequest.onBeforeRequest(
    {
      urls: [
        '*://raw.githubusercontent.com/*',
        '*://hugom1307.github.io/kvrcards-catalog/*'
      ]
    },
    (details, callback) => {
      try {
        const matchImage = details.url.match(/kvrcards-catalog(?:\/main)?\/image\/(.+)$/i);
        const matchCalidad = details.url.match(/kvrcards-catalog(?:\/main)?\/calidades\/(.+)$/i);

        if (imageServerPort > 0) {
          if (matchImage) {
            const imgSubPath = decodeURIComponent(matchImage[1].split('?')[0]);
            const safeSubPath = path.normalize(imgSubPath).replace(/^(\.\.[\/\\])+/, '');
            const localFile = path.join(cacheDir, safeSubPath);

            if (fs.existsSync(localFile)) {
              const stat = fs.statSync(localFile);
              if (stat.isFile() && stat.size > 0) {
                const localUrl = `http://127.0.0.1:${imageServerPort}/${encodeURI(safeSubPath).replace(/#/g, '%23')}`;
                return callback({ redirectURL: localUrl });
              }
            }
          } else if (matchCalidad) {
            const calSubPath = decodeURIComponent(matchCalidad[1].split('?')[0]);
            const safeSubPath = path.normalize(calSubPath).replace(/^(\.\.[\/\\])+/, '');
            const localFile = path.join(cacheDir, 'calidades', safeSubPath);

            if (fs.existsSync(localFile)) {
              const stat = fs.statSync(localFile);
              if (stat.isFile() && stat.size > 0) {
                const localUrl = `http://127.0.0.1:${imageServerPort}/calidades/${encodeURI(safeSubPath).replace(/#/g, '%23')}`;
                return callback({ redirectURL: localUrl });
              }
            }
          }
        }

        // Si no está en caché local pero apunta a raw.githubusercontent.com,
        // redirigir al CDN de GitHub Pages para evitar rate limits 429
        const newUrl = details.url.replace(
          /^https?:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/main\/(.*)$/i,
          'https://$1.github.io/$2/$3'
        );
        if (newUrl !== details.url) {
          return callback({ redirectURL: newUrl });
        }
      } catch (err) {}

      callback({});
    }
  );
}

// Descargar un único archivo con soporte para redirección y reintentos
function downloadFile(url, destPath, retries = 2) {
  return new Promise((resolve, reject) => {
    const attempt = (remainingRetries) => {
      const tempPath = destPath + '.tmp';
      const proto = url.startsWith('https:') ? https : http;

      const req = proto.get(url, { headers: { 'User-Agent': 'KVRCards-App' } }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          return downloadFile(res.headers.location, destPath, remainingRetries).then(resolve).catch(reject);
        }

        if (res.statusCode !== 200) {
          res.resume();
          if (remainingRetries > 0) {
            setTimeout(() => attempt(remainingRetries - 1), 500);
          } else {
            reject(new Error(`HTTP ${res.statusCode}`));
          }
          return;
        }

        try {
          fs.mkdirSync(path.dirname(destPath), { recursive: true });
        } catch {}

        const fileStream = fs.createWriteStream(tempPath);
        res.pipe(fileStream);

        fileStream.on('finish', () => {
          fileStream.close(() => {
            try {
              if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
              fs.renameSync(tempPath, destPath);
              resolve();
            } catch (renameErr) {
              reject(renameErr);
            }
          });
        });

        fileStream.on('error', (err) => {
          try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch {}
          if (remainingRetries > 0) {
            setTimeout(() => attempt(remainingRetries - 1), 500);
          } else {
            reject(err);
          }
        });
      });

      req.on('error', (err) => {
        try { if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath); } catch {}
        if (remainingRetries > 0) {
          setTimeout(() => attempt(remainingRetries - 1), 500);
        } else {
          reject(err);
        }
      });

      req.setTimeout(20000, () => {
        req.destroy(new Error('Timeout'));
      });
    };

    attempt(retries);
  });
}

// Descargar un recurso de catálogo (soporta calidades/ e image/)
async function downloadResourceFile(item, destPath) {
  const rel = item.remotePath || (item.category === 'calidades' || item.path.startsWith('calidades/')
    ? (item.path.startsWith('calidades/') ? item.path : `calidades/${item.path}`)
    : `image/${item.path.replace(/^image\//, '')}`);

  const rawUrl = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/${encodeURI(rel)}`;
  const cdnUrl = `https://hugom1307.github.io/kvrcards-catalog/${encodeURI(rel)}`;

  try {
    await downloadFile(rawUrl, destPath);
  } catch (rawErr) {
    await downloadFile(cdnUrl, destPath);
  }
}

// Helper para solicitar JSON por HTTP/HTTPS con timeout
function fetchJson(url, timeoutMs = 8000) {
  return new Promise((resolve, reject) => {
    const proto = url.startsWith('https:') ? https : http;
    const req = proto.get(url, { headers: { 'User-Agent': 'KVRCards-App' } }, (res) => {
      if (res.statusCode < 200 || res.statusCode >= 300) {
        res.resume();
        return reject(new Error(`HTTP ${res.statusCode}`));
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(e);
        }
      });
    });
    req.on('error', reject);
    req.setTimeout(timeoutMs, () => req.destroy(new Error('Timeout')));
  });
}

// Obtener el manifiesto de imágenes y calidades actualizado desde GitHub
async function fetchImageManifest(app, forceRefresh = false) {
  const userDir = app.getPath('userData');
  const cacheManifestPath = path.join(userDir, 'data', 'catalog-cache', 'image-manifest-live.json');
  const legacyCacheManifestPath = path.join(userDir, 'data', 'catalog-cache', 'image-manifest.json');

  // 1. MÉTODO PRINCIPAL: Consultar GitHub Git Trees API en tiempo real
  // Refleja de inmediato cualquier nueva carta, sobre o calidad subida al repositorio
  try {
    const treeUrl = `https://api.github.com/repos/hugom1307/kvrcards-catalog/git/trees/main?recursive=1&t=${Date.now()}`;
    const treeData = await fetchJson(treeUrl, 9000);
    if (treeData && Array.isArray(treeData.tree)) {
      const liveList = [];
      for (const item of treeData.tree) {
        if (item.type !== 'blob') continue;
        if (!isImgFile(item.path)) continue;

        if (item.path.startsWith('image/')) {
          const subPath = item.path.slice('image/'.length);
          liveList.push({
            path: subPath,
            size: item.size || 0,
            category: 'image',
            remotePath: item.path
          });
        } else if (item.path.startsWith('calidades/')) {
          liveList.push({
            path: item.path,
            size: item.size || 0,
            category: 'calidades',
            remotePath: item.path
          });
        }
      }

      if (liveList.length > 0) {
        console.log(`[IMAGE-CACHE] ✅ Manifiesto en vivo cargado desde GitHub Git Tree: ${liveList.length} recursos (${liveList.filter(x => x.category === 'calidades').length} calidades)`);
        try {
          fs.mkdirSync(path.dirname(cacheManifestPath), { recursive: true });
          fs.writeFileSync(cacheManifestPath, JSON.stringify(liveList, null, 2), 'utf-8');
        } catch {}
        return liveList;
      }
    }
  } catch (treeErr) {
    console.warn('[IMAGE-CACHE] No se pudo obtener Git Tree de GitHub API (posible rate limit o red):', treeErr.message);
  }

  // 2. MÉTODO SECUNDARIO: image-manifest.json + calidades.json + cards.json desde GitHub Raw / CDN
  try {
    const ts = Date.now();
    const manifestUrls = [
      `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image-manifest.json?t=${ts}`,
      `https://hugom1307.github.io/kvrcards-catalog/image-manifest.json?t=${ts}`
    ];

    let baseList = null;
    for (const mUrl of manifestUrls) {
      try {
        const json = await fetchJson(mUrl, 6000);
        if (Array.isArray(json) && json.length > 0) {
          baseList = json.filter(x => isImgFile(x.path)).map(x => ({
            path: x.path.replace(/^image\//, ''),
            size: x.size || 0,
            category: 'image',
            remotePath: `image/${x.path.replace(/^image\//, '')}`
          }));
          break;
        }
      } catch {}
    }

    if (!baseList) baseList = [];

    // Agregar calidades desde calidades.json remoto
    try {
      const calidadesUrl = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/calidades.json?t=${ts}`;
      const calidadesJson = await fetchJson(calidadesUrl, 5000);
      const qList = Array.isArray(calidadesJson) ? calidadesJson : (calidadesJson?.qualities || calidadesJson?.calidades || []);
      for (const q of qList) {
        const qId = q.id || q.name;
        if (!qId) continue;
        const calPath = `calidades/${qId.toLowerCase().trim()}.png`;
        if (!baseList.some(x => x.path === calPath)) {
          baseList.push({
            path: calPath,
            size: 1500000,
            category: 'calidades',
            remotePath: calPath
          });
        }
      }
    } catch (e) {
      console.warn('[IMAGE-CACHE] No se pudieron cargar calidades.json remotas:', e.message);
    }

    // Agregar cartas desde cards.json remoto si alguna no estuviese en el manifiesto
    try {
      const cardsUrl = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/cards.json?t=${ts}`;
      const cardsJson = await fetchJson(cardsUrl, 6000);
      if (Array.isArray(cardsJson)) {
        for (const c of cardsJson) {
          const imgUrl = c.imageUrl || c.image || c.imagen;
          if (typeof imgUrl === 'string' && imgUrl.includes('/image/')) {
            const match = imgUrl.match(/kvrcards-catalog(?:\/main)?\/image\/(.+)$/i);
            if (match) {
              const cardRel = decodeURIComponent(match[1].split('?')[0]);
              if (!baseList.some(x => x.path === cardRel)) {
                baseList.push({
                  path: cardRel,
                  size: 1200000,
                  category: 'image',
                  remotePath: `image/${cardRel}`
                });
              }
            }
          }
        }
      }
    } catch {}

    if (baseList.length > 0) {
      console.log(`[IMAGE-CACHE] ✅ Manifiesto sintetizado desde catálogo remoto: ${baseList.length} recursos`);
      try {
        fs.mkdirSync(path.dirname(cacheManifestPath), { recursive: true });
        fs.writeFileSync(cacheManifestPath, JSON.stringify(baseList, null, 2), 'utf-8');
      } catch {}
      return baseList;
    }
  } catch (secErr) {
    console.warn('[IMAGE-CACHE] Error en método secundario de manifiesto:', secErr.message);
  }

  // 3. FALLBACK DE DISCO: Caché previa guardada en userData (modo offline)
  for (const cPath of [cacheManifestPath, legacyCacheManifestPath]) {
    try {
      if (fs.existsSync(cPath)) {
        const cached = JSON.parse(fs.readFileSync(cPath, 'utf-8'));
        if (Array.isArray(cached) && cached.length > 0) {
          console.log(`[IMAGE-CACHE] Usando manifiesto local guardado en caché: ${cached.length} recursos`);
          return cached;
        }
      }
    } catch {}
  }

  // 4. FALLBACK FINAL: Manifiesto empaquetado en game-data
  const candidatePaths = [
    path.join(__dirname, '..', 'game-data', 'image-manifest.json'),
    path.join(__dirname, '..', '..', 'game-data', 'image-manifest.json'),
    path.join(process.cwd(), 'game-data', 'image-manifest.json')
  ];

  for (const p of candidatePaths) {
    try {
      if (fs.existsSync(p)) {
        const bundled = JSON.parse(fs.readFileSync(p, 'utf-8'));
        if (Array.isArray(bundled) && bundled.length > 0) {
          console.log(`[IMAGE-CACHE] Usando manifiesto bundled como respaldo: ${bundled.length} recursos`);
          return bundled.map(x => ({
            ...x,
            category: x.path.startsWith('calidades/') ? 'calidades' : 'image',
            remotePath: x.path.startsWith('calidades/') ? x.path : `image/${x.path.replace(/^image\//, '')}`
          }));
        }
      }
    } catch {}
  }

  return [];
}

// Analizar el estado actual de la caché local comparado con el manifiesto
async function checkImageCache(app, forceRefresh = false) {
  const cacheDir = getLocalImageCacheDir(app);
  const manifest = await fetchImageManifest(app, forceRefresh);

  let downloadedCount = 0;
  let downloadedBytes = 0;
  let missingCount = 0;
  let missingBytes = 0;
  let totalBytes = 0;
  const missingFiles = [];

  for (const item of manifest) {
    totalBytes += (item.size || 0);
    const localFile = path.join(cacheDir, item.path);

    let exists = false;
    let size = 0;

    try {
      if (fs.existsSync(localFile)) {
        const st = fs.statSync(localFile);
        if (st.isFile() && st.size > 0) {
          exists = true;
          size = st.size;
        }
      }
    } catch {}

    if (exists) {
      downloadedCount++;
      downloadedBytes += size;
    } else {
      missingCount++;
      missingBytes += (item.size || 0);
      missingFiles.push(item);
    }
  }

  return {
    ok: true,
    totalFiles: manifest.length,
    downloadedCount,
    downloadedBytes,
    missingCount,
    missingBytes,
    totalBytes,
    isComplete: missingCount === 0 && manifest.length > 0,
    missingFiles
  };
}

// Descarga en paralelo con un pool de concurrencia
async function startImageCacheDownload(app, event, forceRefresh = false) {
  if (isDownloading) {
    return { ok: false, error: 'Ya hay una descarga en curso.' };
  }

  isDownloading = true;
  const cacheDir = getLocalImageCacheDir(app);

  try {
    const status = await checkImageCache(app, forceRefresh);
    const missing = status.missingFiles || [];

    if (missing.length === 0) {
      isDownloading = false;
      if (event && event.sender) {
        event.sender.send('catalog:imageCacheComplete', {
          success: true,
          downloadedCount: 0,
          totalFiles: status.totalFiles,
          alreadyComplete: true
        });
      }
      return { ok: true, alreadyComplete: true };
    }

    const totalToDownload = missing.length;
    const totalBytesToDownload = status.missingBytes;
    let completedCount = 0;
    let completedBytes = 0;
    let errorCount = 0;
    let lastProgressEmit = 0;

    const emitProgress = (currentFile) => {
      const now = Date.now();
      if (now - lastProgressEmit < 80 && completedCount < totalToDownload) return;
      lastProgressEmit = now;

      const percent = totalBytesToDownload > 0
        ? Math.min(100, (completedBytes / totalBytesToDownload) * 100)
        : Math.min(100, (completedCount / totalToDownload) * 100);

      if (event && event.sender) {
        try {
          event.sender.send('catalog:imageCacheProgress', {
            fileIndex: completedCount,
            totalFiles: totalToDownload,
            downloadedBytes: completedBytes,
            totalBytes: totalBytesToDownload,
            percent,
            currentFile: currentFile || ''
          });
        } catch {}
      }
    };

    // Pool de descarga con concurrencia 6
    const CONCURRENCY = 6;
    let queueIndex = 0;

    const worker = async () => {
      while (queueIndex < missing.length) {
        const item = missing[queueIndex++];
        const destPath = path.join(cacheDir, item.path);

        try {
          await downloadResourceFile(item, destPath);
          completedCount++;
          completedBytes += (item.size || 0);
        } catch (err) {
          console.error(`[IMAGE-CACHE] Error descargando ${item.path}:`, err.message);
          errorCount++;
          completedCount++;
          completedBytes += (item.size || 0);
        }

        emitProgress(path.basename(item.path));
      }
    };

    const workers = [];
    for (let i = 0; i < CONCURRENCY; i++) {
      workers.push(worker());
    }
    await Promise.all(workers);

    // Progreso final al 100%
    if (event && event.sender) {
      try {
        event.sender.send('catalog:imageCacheProgress', {
          fileIndex: totalToDownload,
          totalFiles: totalToDownload,
          downloadedBytes: totalBytesToDownload,
          totalBytes: totalBytesToDownload,
          percent: 100,
          currentFile: 'Completado'
        });

        event.sender.send('catalog:imageCacheComplete', {
          success: true,
          downloadedCount: completedCount - errorCount,
          totalFiles: status.totalFiles,
          errorCount
        });
      } catch {}
    }

    isDownloading = false;
    return { ok: true, downloadedCount: completedCount - errorCount };
  } catch (err) {
    isDownloading = false;
    console.error('[IMAGE-CACHE] Error general en descarga:', err);
    if (event && event.sender) {
      try {
        event.sender.send('catalog:imageCacheComplete', {
          success: false,
          error: err.message
        });
      } catch {}
    }
    return { ok: false, error: err.message };
  }
}

// Inicialización del módulo
function initImageCache({ app, session, ipcMain }) {
  const cacheDir = getLocalImageCacheDir(app);
  startLocalImageServer(cacheDir);
  setupWebRequestInterceptor(session, cacheDir);

  if (ipcMain) {
    ipcMain.handle('catalog:checkImageCache', async (_event, forceRefresh) => {
      return await checkImageCache(app, Boolean(forceRefresh));
    });

    ipcMain.handle('catalog:startImageCacheDownload', async (event, forceRefresh) => {
      return await startImageCacheDownload(app, event, Boolean(forceRefresh));
    });
  }

  console.log('[IMAGE-CACHE] Módulo inicializado con éxito. Directorio:', cacheDir);
}

function cleanup() {
  if (imageHttpServer) {
    try {
      imageHttpServer.close();
      console.log('[IMAGE-CACHE] Servidor local cerrado.');
    } catch {}
  }
}

module.exports = {
  initImageCache,
  getLocalImageCacheDir,
  checkImageCache,
  startImageCacheDownload,
  cleanup,
  fetchImageManifest
};
