// ==================== FUNCIONES DE MODO DEBUG ====================

// Declaracion de seguridad por si traits.js no ha terminado de cargar
if (typeof window.renderTraitsPanel === 'undefined') {
  window.renderTraitsPanel = async function() {};
}

// Sincronizar inventario con R2 después de modificaciones
async function syncInventoryToR2() {
  if (!window.kvrcards) return;
  try {
    const inv = await window.kvrcards.getInventory();
    if (!inv.ok) return;
    
    // El sistema ya sincroniza automáticamente cuando se modifica el inventario local
    // Solo necesitamos forzar una actualización
    if (typeof renderCollection === 'function') await renderCollection();
    if (typeof renderOwnedPacks === 'function') await renderOwnedPacks();
    if (typeof renderWallet === 'function') await renderWallet();
    if (typeof window.renderTraitsPanel === 'function') {
      await window.renderTraitsPanel();
    } else if (typeof renderTraitsPanel === 'function') {
      await renderTraitsPanel();
    }
    if (typeof renderItemsCollection === 'function') {
      await renderItemsCollection();
    }
    
    console.log('[DEBUG] Inventario sincronizado con R2');
  } catch (e) {
    console.error('[DEBUG] Error sincronizando con R2:', e);
  }
}

// Añadir carta
async function debugAddCard(cardId, quantity = 1, skipConfirm = false) {
  if (!skipConfirm && !confirm(`¿Añadir ${quantity} carta(s) "${cardId}"?`)) return;
  
  try {
    for (let i = 0; i < quantity; i++) {
      const result = await window.kvrcards.addCard(cardId);
      if (result.error) {
        if (!skipConfirm) {
          alert(`❌ Error en carta ${i + 1}/${quantity}: ${result.error}`);
        }
        return;
      }
    }
    
    if (!skipConfirm) {
      await renderCollection();
      alert(`✅ ${quantity} carta(s) "${cardId}" añadida(s) correctamente`);
    }
  } catch (e) {
    console.error('[DEBUG] Error añadiendo carta:', e);
    if (!skipConfirm) {
      alert('❌ Error: ' + e.message);
    }
  }
}

// Eliminar carta
async function debugRemoveCard(cardId, quantity = 1) {
  if (!confirm(`¿Eliminar ${quantity} unidad(es) de la carta "${cardId}"?`)) return;
  
  try {
    const inv = await window.kvrcards.getInventory();
    if (!inv.ok || !inv.cards[cardId] || inv.cards[cardId] < quantity) {
      alert(`⚠️ No tienes suficientes cartas. Tienes: ${inv.cards[cardId] || 0}, intentas eliminar: ${quantity}`);
      return;
    }
    
    for (let i = 0; i < quantity; i++) {
      const result = await window.kvrcards.sellCard(cardId);
      if (result.error) {
        alert(`❌ Error en carta ${i + 1}/${quantity}: ${result.error}`);
        return;
      }
    }
    
    await renderCollection();
    await renderWallet();
    alert(`✅ ${quantity} carta(s) "${cardId}" eliminada(s) correctamente`);
  } catch (e) {
    console.error('[DEBUG] Error eliminando carta:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Añadir sobres
async function debugAddPack(packId, quantity) {
  if (!confirm(`¿Añadir ${quantity} sobre(s) "${packId}"?`)) return;
  
  try {
    const result = await window.kvrcards.addInventoryPack(packId, quantity);
    if (result.error) {
      alert('❌ Error: ' + result.error);
      return;
    }
    
    await renderOwnedPacks();
    alert(`✅ ${quantity} sobre(s) "${packId}" añadido(s) correctamente`);
  } catch (e) {
    console.error('[DEBUG] Error añadiendo sobre:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Eliminar sobres
async function debugRemovePack(packId, quantity) {
  if (!confirm(`¿Eliminar ${quantity} sobre(s) "${packId}"?`)) return;
  
  try {
    const inv = await window.kvrcards.getInventory();
    if (!inv.ok || !inv.packs[packId] || inv.packs[packId] <= 0) {
      alert('⚠️ No tienes este sobre en tu inventario');
      return;
    }
    
    // Eliminar sobres uno por uno
    for (let i = 0; i < quantity; i++) {
      const currentCount = inv.packs[packId] || 0;
      if (currentCount <= 0) break;
      
      const result = await window.kvrcards.deletePack(packId);
      if (result.error) {
        alert(`❌ Error eliminando sobre ${i + 1}/${quantity}: ` + result.error);
        break;
      }
    }
    
    await renderOwnedPacks();
    alert(`✅ Sobres "${packId}" eliminados correctamente`);
  } catch (e) {
    console.error('[DEBUG] Error eliminando sobre:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Modificar Coins
async function debugModifyCoins(amount) {
  if (!confirm(`¿${amount >= 0 ? 'Añadir' : 'Quitar'} ${Math.abs(amount)} coins?`)) return;
  
  try {
    if (amount > 0) {
      const result = await window.kvrcards.addCoins(amount);
      if (result.error) {
        alert('❌ Error: ' + result.error);
        return;
      }
    } else if (amount < 0) {
      const wallet = await window.kvrcards.getWallet();
      const newAmount = Math.max(0, (wallet.coins || 0) + amount);
      const diff = (wallet.coins || 0) - newAmount;
      if (diff > 0) {
        // No hay API directa para quitar, así que usamos compra de sobres (hack temporal)
        alert('⚠️ No se pueden quitar monedas directamente. Usa el sistema de compras.');
        return;
      }
    }
    
    await renderWallet();
    alert(`✅ ${amount >= 0 ? 'Añadidos' : 'Quitados'} ${Math.abs(amount)} coins`);
  } catch (e) {
    console.error('[DEBUG] Error modificando coins:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Modificar KVR
async function debugModifyKVR(amount) {
  if (!confirm(`¿${amount >= 0 ? 'Añadir' : 'Quitar'} ${Math.abs(amount)} KVR?`)) return;
  
  try {
    if (amount > 0) {
      const result = await window.kvrcards.addKvR(amount);
      if (result.error) {
        alert('❌ Error: ' + result.error);
        return;
      }
    } else if (amount < 0) {
      alert('⚠️ No se pueden quitar KVR directamente. Usa el sistema de compras.');
      return;
    }
    
    await renderWallet();
    alert(`✅ ${amount >= 0 ? 'Añadidos' : 'Quitados'} ${Math.abs(amount)} KVR`);
  } catch (e) {
    console.error('[DEBUG] Error modificando KVR:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Modificar Traits
async function debugModifyTraits(amount) {
  if (!confirm(`¿${amount >= 0 ? 'Añadir' : 'Quitar'} ${Math.abs(amount)} Traits?`)) return;
  
  try {
    // Usamos una llamada IPC personalizada para debug de traits
    // Como no existe addTraits en la API pública, usaremos una llamada directa si es posible
    // O implementaremos un método temporal en el backend
    
    const result = await window.kvrcards.debugModifyTraits(amount);
    
    if (result.error) {
      alert('❌ Error: ' + result.error);
      return;
    }
    
    if (typeof renderWallet === 'function') await renderWallet();
    // Actualizar también el panel de traits si está abierto
    const traitsPanelEl = document.getElementById('traits-panel');
    if (traitsPanelEl && traitsPanelEl.style.display === 'block') {
      if (typeof window.renderTraitsPanel === 'function') {
        await window.renderTraitsPanel();
      } else if (typeof renderTraitsPanel === 'function') {
        await renderTraitsPanel();
      }
    }
    
    alert(`✅ ${amount >= 0 ? 'Añadidos' : 'Quitados'} ${Math.abs(amount)} Traits`);
  } catch (e) {
    console.error('[DEBUG] Error modificando Traits:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Modificar Infinite Coins
async function debugModifyInfiniteCoins(amount) {
  if (!confirm(`¿${amount >= 0 ? 'Añadir' : 'Quitar'} ${Math.abs(amount)} Infinite Coins?`)) return;
  
  try {
    const current = Number(localStorage.getItem('INFINITE_CURRENCY_COINS') || '0') || 0;
    let wallet = {};
    if (window.kvrcards && typeof window.kvrcards.getWallet === 'function') {
      wallet = await window.kvrcards.getWallet() || {};
    }
    const currentWallet = Number(wallet['infinite-coins']) || current;
    const newAmount = Math.max(0, currentWallet + amount);

    localStorage.setItem('INFINITE_CURRENCY_COINS', String(newAmount));

    if (window.kvrcards && typeof window.kvrcards.walletUpdateInfiniteCurrencies === 'function') {
      await window.kvrcards.walletUpdateInfiniteCurrencies({ 'infinite-coins': newAmount });
    }
    
    await renderWallet();
    alert(`✅ ${amount >= 0 ? 'Añadidos' : 'Quitados'} ${Math.abs(amount)} Infinite Coins (Total: ${newAmount})`);
  } catch (e) {
    console.error('[DEBUG] Error modificando Infinite Coins:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Modificar Infinite Cardpoints
async function debugModifyInfiniteCardpoints(amount) {
  if (!confirm(`¿${amount >= 0 ? 'Añadir' : 'Quitar'} ${Math.abs(amount)} Infinite Cardpoints?`)) return;
  
  try {
    const current = Number(localStorage.getItem('INFINITE_CURRENCY_CARDPOINTS') || '0') || 0;
    let wallet = {};
    if (window.kvrcards && typeof window.kvrcards.getWallet === 'function') {
      wallet = await window.kvrcards.getWallet() || {};
    }
    const currentWallet = Number(wallet['infinite-cardpoints']) || current;
    const newAmount = Math.max(0, currentWallet + amount);

    localStorage.setItem('INFINITE_CURRENCY_CARDPOINTS', String(newAmount));

    if (window.kvrcards && typeof window.kvrcards.walletUpdateInfiniteCurrencies === 'function') {
      await window.kvrcards.walletUpdateInfiniteCurrencies({ 'infinite-cardpoints': newAmount });
    }
    
    await renderWallet();
    alert(`✅ ${amount >= 0 ? 'Añadidos' : 'Quitados'} ${Math.abs(amount)} Infinite Cardpoints (Total: ${newAmount})`);
  } catch (e) {
    console.error('[DEBUG] Error modificando Infinite Cardpoints:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Resetear misiones
async function debugResetMissions() {
  if (!confirm('⚠️ ¿Resetear TODAS las misiones? Se perderá el progreso y recompensas reclamadas.')) return;
  
  try {
    // Resetear en localStorage
    localStorage.removeItem('kvr_user_missions');
    userMissions = {};
    
    // Sincronizar con servidor
    const result = await window.kvrcards.saveMissionsState({});
    if (result.error) {
      alert('❌ Error sincronizando: ' + result.error);
      return;
    }
    
    // Recargar estado desde servidor y renderizar
    await loadUserMissionsState();
    await renderMissions();
    alert('✅ Misiones reseteadas correctamente');
  } catch (e) {
    console.error('[DEBUG] Error reseteando misiones:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Completar todas las misiones
async function debugCompleteMissions() {
  if (!confirm('¿Completar TODAS las misiones disponibles?')) return;
  
  try {
    await loadMissions();
    availableMissions.forEach(mission => {
      if (!userMissions[mission.id]) {
        userMissions[mission.id] = {};
      }
      userMissions[mission.id].completed = true;
      userMissions[mission.id].progress = mission.requirements?.value || 1;
    });
    
    // Guardar en localStorage
    localStorage.setItem('kvr_user_missions', JSON.stringify(userMissions));
    
    // Sincronizar con servidor
    const result = await window.kvrcards.saveMissionsState(userMissions);
    if (result.error) {
      alert('❌ Error sincronizando: ' + result.error);
      return;
    }
    
    // Recargar estado desde servidor y renderizar
    await loadUserMissionsState();
    await renderMissions();
    alert('✅ Todas las misiones completadas (no reclamadas)');
  } catch (e) {
    console.error('[DEBUG] Error completando misiones:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Resetear kizunas
async function debugResetKizunas() {
  if (!confirm('⚠️ ¿Resetear TODOS los kizunas? Se perderá el progreso y recompensas reclamadas.')) return;
  
  try {
    localStorage.removeItem('kvr_user_kizunas');
    userKizunas = {};
    await renderKizunas();
    alert('✅ Kizunas reseteados correctamente');
  } catch (e) {
    console.error('[DEBUG] Error reseteando kizunas:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Completar todos los kizunas
async function debugCompleteKizunas() {
  if (!confirm('¿Completar TODOS los kizunas? (Añadir todas las cartas necesarias)')) return;
  
  try {
    await loadKizunas();
    
    // Añadir todas las cartas de todos los kizunas usando addCard
    for (const kizuna of availableKizunas) {
      for (const cardId of kizuna.cardIds) {
        const result = await window.kvrcards.addCard(cardId);
        if (result.error) {
          console.error(`Error añadiendo carta ${cardId}:`, result.error);
        }
      }
    }
    
    await syncInventoryToR2();
    await renderKizunas();
    alert('✅ Todos los kizunas completados (cartas añadidas)');
  } catch (e) {
    console.error('[DEBUG] Error completando kizunas:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Resetear títulos
async function debugResetTitles() {
  if (!confirm('⚠️ ¿Resetear todos los títulos? Solo quedarás con "Novato".')) return;
  
  try {
    if (userProfile) {
      userProfile.unlockedTitles = ['novato'];
      userProfile.title = 'Novato';
      userProfile.currentTitle = 'Novato';
      saveUserProfile();
      updateProfileDisplay();
      alert('✅ Títulos reseteados correctamente');
    }
  } catch (e) {
    console.error('[DEBUG] Error reseteando títulos:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Desbloquear todos los títulos
async function debugUnlockAllTitles() {
  if (!confirm('¿Desbloquear TODOS los títulos disponibles?')) return;
  
  try {
    await loadTitles();
    if (userProfile && availableTitles && availableTitles.length > 0) {
      userProfile.unlockedTitles = availableTitles.map(t => t.id);
      saveUserProfile();
      updateProfileDisplay();
      alert(`✅ ${availableTitles.length} títulos desbloqueados correctamente`);
    } else {
      alert('⚠️ No se pudieron cargar los títulos');
    }
  } catch (e) {
    console.error('[DEBUG] Error desbloqueando títulos:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Reset total
// ==================== DEBUG: PODERES ====================

// Añadir poder
async function debugAddPower(powerId, isPermanent, uses = 1) {
  const powerName = availablePowers.find(p => p.id === powerId)?.name || powerId;
  const typeText = isPermanent ? 'permanente' : `${uses} uso(s)`;
  
  if (!confirm(`¿Añadir poder "${powerName}" (${typeText})?`)) return;
  
  try {
    if (isPermanent) {
      // Añadir como permanente (solo una vez)
      const result = await window.kvrcards.addPower(powerId);
      if (result.error) {
        alert('❌ Error: ' + result.error);
        return;
      }
      if (result.alreadyOwned) {
        alert('⚠️ Ya tienes este poder permanente');
        return;
      }
    } else {
      // Añadir usos consumibles
      for (let i = 0; i < uses; i++) {
        const result = await window.kvrcards.addPower(powerId);
        if (result.error) {
          alert(`❌ Error en uso ${i + 1}/${uses}: ${result.error}`);
          return;
        }
      }
    }
    
    // Recargar inventario de poderes
    await loadPowers();
    alert(`✅ Poder "${powerName}" añadido correctamente`);
  } catch (e) {
    console.error('[DEBUG] Error añadiendo poder:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Eliminar poder
async function debugRemovePower(powerId) {
  const powerName = availablePowers.find(p => p.id === powerId)?.name || powerId;
  
  if (!confirm(`¿Eliminar TODOS los usos del poder "${powerName}"?`)) return;
  
  try {
    const inv = await window.kvrcards.getPowersInventory();
    if (!inv.ok || !inv.powers[powerId]) {
      alert('⚠️ No tienes este poder en tu inventario');
      return;
    }
    
    const powerData = inv.powers[powerId];
    const isPermanent = powerData.permanent === true;
    const uses = powerData.uses || 0;
    
    if (isPermanent) {
      // Eliminar permanente (solo existe una vez, pero usamos el mismo IPC)
      const result = await window.kvrcards.usePower(powerId);
      if (result.error) {
        alert('❌ Error: ' + result.error);
        return;
      }
    } else {
      // Eliminar todos los usos consumibles
      for (let i = 0; i < uses; i++) {
        const result = await window.kvrcards.usePower(powerId);
        if (result.error && !result.error.includes('No tienes')) {
          alert(`❌ Error eliminando uso ${i + 1}/${uses}: ${result.error}`);
          break;
        }
      }
    }
    
    // Recargar inventario de poderes
    await loadPowers();
    alert(`✅ Poder "${powerName}" eliminado correctamente`);
  } catch (e) {
    console.error('[DEBUG] Error eliminando poder:', e);
    alert('❌ Error: ' + e.message);
  }
}

async function debugAdjustPrestigeXP(cardId, amount) {
  const normalizedId = normalizePrestigeCardId(cardId);
  const delta = Number(amount) || 0;
  if (!normalizedId || delta === 0) return;

  const store = loadPrestigeProgressStore();
  const current = store[normalizedId] && typeof store[normalizedId] === 'object'
    ? store[normalizedId]
    : { battlesPlayed: 0, battlesWon: 0, battleXp: 0, missionXp: 0 };

  current.battlesPlayed = Math.max(0, Number(current.battlesPlayed) || 0);
  current.battlesWon = Math.max(0, Number(current.battlesWon) || 0);
  current.missionXp = Math.max(0, Number(current.missionXp) || 0);
  current.battleXp = Math.max(0, (Number(current.battleXp) || 0) + Math.floor(delta));
  current.updatedAt = Date.now();

  store[normalizedId] = current;
  savePrestigeProgressStore(store);

  await renderCollection();
}

async function debugResetAllPrestige() {
  if (!confirm('⚠️ ¿Resetear todos los prestigios a 0 XP?')) return;
  savePrestigeProgressStore({});
  await renderCollection();
  alert('✅ Todos los prestigios fueron reseteados a 0');
}

async function debugCompleteAllPrestige() {
  if (!confirm('¿Completar todos los prestigios de tus cartas actuales?')) return;

  const inv = await window.kvrcards.getInventory();
  if (!inv?.ok) {
    alert('❌ No se pudo leer inventario');
    return;
  }

  const cardIds = Object.entries(inv.cards || {})
    .filter(([, count]) => Number(count) > 0)
    .map(([id]) => String(id));

  const cfg = await getPrestigeConfig();
  const store = loadPrestigeProgressStore();

  cardIds.forEach((cardId) => {
    const profile = resolvePrestigeProfile(cfg, { id: cardId });
    const thresholds = getPrestigeThresholds(profile?.levels || []);
    const maxRequiredXp = thresholds.length > 0 ? Math.max(...thresholds) : PRESTIGE_XP_THRESHOLDS[PRESTIGE_XP_THRESHOLDS.length - 1];

    store[cardId] = {
      battlesPlayed: 999,
      battlesWon: 999,
      battleXp: Math.max(0, Number(maxRequiredXp) || 0),
      missionXp: 0,
      updatedAt: Date.now()
    };
  });

  savePrestigeProgressStore(store);
  await renderCollection();
  alert(`✅ Prestigio completado para ${cardIds.length} carta(s)`);
}

// ==================== FIN DEBUG PODERES ====================

async function debugResetAll() {
  if (!confirm('⚠️⚠️⚠️ ATENCIÓN: Esto reseteará TODO el progreso (misiones, kizunas, títulos).\n\n¿Estás COMPLETAMENTE seguro?')) return;
  if (!confirm('❌ ÚLTIMA CONFIRMACIÓN: Se perderá TODO el progreso de coleccionables. ¿Continuar?')) return;
  
  try {
    // Resetear misiones
    localStorage.removeItem('kvr_user_missions');
    userMissions = {};
    
    // Resetear kizunas
    localStorage.removeItem('kvr_user_kizunas');
    userKizunas = {};
    
    // Resetear títulos
    if (userProfile) {
      userProfile.unlockedTitles = ['novato'];
      userProfile.title = 'Novato';
      userProfile.currentTitle = 'Novato';
      saveUserProfile();
    }
    
    // Resetear evoluciones
    try {
      if (typeof userEvolutions !== 'undefined') {
        for (const k of Object.keys(userEvolutions)) delete userEvolutions[k];
      }
      if (window.userEvolutions) {
        for (const k of Object.keys(window.userEvolutions)) delete window.userEvolutions[k];
      }
      localStorage.removeItem('kvr_user_evolutions_v2');
      if (window.kvrcards?.saveEvolutionState) {
        await window.kvrcards.saveEvolutionState({});
      }
      if (typeof renderEvolutions === 'function') {
        await renderEvolutions();
      }
    } catch (evoErr) {
      console.warn('[DEBUG] Error reseteando evoluciones en reset total:', evoErr);
    }
    
    // Refrescar UI
    await renderMissions();
    await renderKizunas();
    updateProfileDisplay();
    
    alert('✅ TODO reseteado correctamente');
  } catch (e) {
    console.error('[DEBUG] Error en reset total:', e);
    alert('❌ Error: ' + e.message);
  }
}

// ==================== DEBUG: EVOLUCIONES ====================

async function debugEnsureEvolutionsLoaded() {
  if (typeof loadEvolutions === 'function') {
    const list = (typeof availableEvolutions !== 'undefined' ? availableEvolutions : (window.availableEvolutions || []));
    if (!list || list.length === 0) {
      await loadEvolutions();
    }
  }
  if (typeof loadUserEvolutionsState === 'function') {
    await loadUserEvolutionsState();
  }
  return {
    evolutions: (typeof availableEvolutions !== 'undefined' ? availableEvolutions : (window.availableEvolutions || [])),
    state: (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}))
  };
}

async function debugAutoStartEvolution(evolution, silent = false) {
  const state = (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}));
  const evoState = state[evolution.id];
  if (evoState && evoState.started && !evoState.claimedAt) {
    return evoState;
  }

  let cardId = null;
  let cardOption = null;

  if (Array.isArray(evolution.cardOptions) && evolution.cardOptions.length > 0) {
    cardOption = evolution.cardOptions[0];
    cardId = cardOption.cardFrom;
  } else if (Array.isArray(evolution.cardFrom) && evolution.cardFrom.length > 0) {
    cardId = evolution.cardFrom[0];
  } else {
    cardId = evolution.cardFrom;
  }

  if (!cardId) {
    throw new Error(`No se pudo determinar la carta base para "${evolution.name || evolution.id}"`);
  }

  // Asegurar que la carta base esté en el inventario
  try {
    if (window.kvrcards?.getInventory) {
      const inv = await window.kvrcards.getInventory();
      if (!inv?.cards || !inv.cards[cardId] || inv.cards[cardId] <= 0) {
        await window.kvrcards.addCard(cardId);
      }
    }
  } catch (err) {
    console.warn('[DEBUG] Error asegurando carta base:', err);
  }

  const startFn = (typeof startEvolution === 'function') ? startEvolution : window.startEvolution;
  if (startFn) {
    startFn(evolution, cardId, cardOption, silent);
  }

  return (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}))[evolution.id];
}

async function debugCompleteEvolutionMissions(evolutionId) {
  const { evolutions, state } = await debugEnsureEvolutionsLoaded();
  const evoId = evolutionId || document.getElementById('debug-evolution-select')?.value;
  const evolution = evolutions.find(e => e.id === evoId);
  if (!evolution) {
    alert('❌ Selecciona una evolución válida.');
    return;
  }

  let progress = state[evolution.id];
  if (!progress || !progress.started || progress.claimedAt) {
    const startIt = confirm(`La evolución "${evolution.name}" no está iniciada. ¿Deseas iniciarla automáticamente?`);
    if (!startIt) return;
    progress = await debugAutoStartEvolution(evolution, true);
  }

  if (!progress || !progress.started) {
    alert('❌ No se pudo iniciar la evolución.');
    return;
  }

  const phasesFn = (typeof getEvolutionPhases === 'function') ? getEvolutionPhases : window.getEvolutionPhases;
  const phases = phasesFn ? phasesFn(evolution, progress) : [];
  const currentPhaseIndex = Math.max(0, (progress.currentPhase || 1) - 1);
  const currentPhaseData = phases[currentPhaseIndex] || phases[0] || {};
  const missions = currentPhaseData.missions || [];

  if (!progress.missionsCompleted) progress.missionsCompleted = {};
  if (!progress.missionsProgress) progress.missionsProgress = {};

  missions.forEach(mission => {
    progress.missionsCompleted[mission.id] = true;
    const targetValue = mission.target || 
      (Array.isArray(mission.requirements) ? mission.requirements[0]?.amount : null) || 
      (Array.isArray(mission.requirement) ? mission.requirement[0]?.amount : null) || 
      mission.requirement?.amount || 1;
    progress.missionsProgress[mission.id] = {
      current: targetValue,
      target: targetValue,
      completed: true
    };
  });

  const saveFn = (typeof saveUserEvolutionsState === 'function') ? saveUserEvolutionsState : window.saveUserEvolutionsState;
  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (saveFn) await saveFn();
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  alert(`🎯 ¡Misiones de la Fase ${progress.currentPhase}/${progress.totalPhases || phases.length} completadas al 100%! Ya puedes reclamar o avanzar la fase.`);
}

async function debugAdvanceEvolutionPhase(evolutionId, silent = false) {
  const { evolutions, state } = await debugEnsureEvolutionsLoaded();
  const evoId = evolutionId || document.getElementById('debug-evolution-select')?.value;
  const evolution = evolutions.find(e => e.id === evoId);
  if (!evolution) {
    if (!silent) alert('❌ Selecciona una evolución válida.');
    return;
  }

  let progress = state[evolution.id];
  if (!progress || !progress.started || progress.claimedAt) {
    progress = await debugAutoStartEvolution(evolution, true);
  }

  if (!progress || !progress.started) {
    if (!silent) alert('❌ No se pudo iniciar la evolución.');
    return;
  }

  const phasesFn = (typeof getEvolutionPhases === 'function') ? getEvolutionPhases : window.getEvolutionPhases;
  const phases = phasesFn ? phasesFn(evolution, progress) : [];
  const currentPhaseIndex = Math.max(0, (progress.currentPhase || 1) - 1);
  const currentPhaseData = phases[currentPhaseIndex] || phases[0] || {};
  const missions = currentPhaseData.missions || [];

  if (!progress.missionsCompleted) progress.missionsCompleted = {};
  if (!progress.missionsProgress) progress.missionsProgress = {};

  missions.forEach(mission => {
    progress.missionsCompleted[mission.id] = true;
    const targetValue = mission.target || 
      (Array.isArray(mission.requirements) ? mission.requirements[0]?.amount : null) || 
      (Array.isArray(mission.requirement) ? mission.requirement[0]?.amount : null) || 
      mission.requirement?.amount || 1;
    progress.missionsProgress[mission.id] = {
      current: targetValue,
      target: targetValue,
      completed: true
    };
  });

  // Asegurar que la carta activa esté en el inventario para que el intercambio no falle
  if (progress.cardId && window.kvrcards?.getInventory) {
    try {
      const inv = await window.kvrcards.getInventory();
      if (!inv?.cards || !inv.cards[progress.cardId] || inv.cards[progress.cardId] <= 0) {
        await window.kvrcards.addCard(progress.cardId);
      }
    } catch (err) {
      console.warn('[DEBUG] Error asegurando carta en inventario:', err);
    }
  }

  const prevPhaseNum = progress.currentPhase || 1;
  const isFinalPhase = prevPhaseNum >= (progress.totalPhases || phases.length);

  const claimFn = (typeof claimEvolution === 'function') ? claimEvolution : window.claimEvolution;
  if (claimFn) {
    await claimFn(evolution, progress, silent);
  }

  const saveFn = (typeof saveUserEvolutionsState === 'function') ? saveUserEvolutionsState : window.saveUserEvolutionsState;
  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (saveFn) await saveFn();
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  if (!silent) {
    if (isFinalPhase) {
      alert(`🎉 ¡Evolución "${evolution.name}" completada al 100%!`);
    } else {
      alert(`⏩ ¡Fase ${prevPhaseNum} superada! La evolución avanza a la Fase ${prevPhaseNum + 1}.`);
    }
  }
}

async function debugCompleteFullEvolution(evolutionId) {
  const { evolutions } = await debugEnsureEvolutionsLoaded();
  const evoId = evolutionId || document.getElementById('debug-evolution-select')?.value;
  const evolution = evolutions.find(e => e.id === evoId);
  if (!evolution) {
    alert('❌ Selecciona una evolución válida.');
    return;
  }

  if (!confirm(`¿Completar TODAS las fases de la evolución "${evolution.name}"?`)) return;

  let progress = (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}))[evolution.id];
  if (!progress || !progress.started || progress.claimedAt) {
    progress = await debugAutoStartEvolution(evolution, true);
  }

  let iterations = 0;
  while (iterations < 20) {
    iterations++;
    progress = (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}))[evolution.id];
    if (!progress || !progress.started || progress.claimedAt) break;

    const phasesFn = (typeof getEvolutionPhases === 'function') ? getEvolutionPhases : window.getEvolutionPhases;
    const phases = phasesFn ? phasesFn(evolution, progress) : [];
    const isFinalPhase = (progress.currentPhase || 1) >= (progress.totalPhases || phases.length);

    await debugAdvanceEvolutionPhase(evolution.id, true);

    if (isFinalPhase) break;
  }

  const saveFn = (typeof saveUserEvolutionsState === 'function') ? saveUserEvolutionsState : window.saveUserEvolutionsState;
  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (saveFn) await saveFn();
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  alert(`🌟 ¡Evolución "${evolution.name}" completada al 100%! Todas las cartas y fases han sido otorgadas.`);
}

async function debugResetEvolution(evolutionId) {
  const { evolutions, state } = await debugEnsureEvolutionsLoaded();
  const evoId = evolutionId || document.getElementById('debug-evolution-select')?.value;
  const evolution = evolutions.find(e => e.id === evoId);
  if (!evolution) {
    alert('❌ Selecciona una evolución válida.');
    return;
  }

  if (!confirm(`¿Resetear el progreso de la evolución "${evolution.name}"?`)) return;

  delete state[evolution.id];
  if (typeof userEvolutions !== 'undefined') delete userEvolutions[evolution.id];
  if (window.userEvolutions) delete window.userEvolutions[evolution.id];

  const saveFn = (typeof saveUserEvolutionsState === 'function') ? saveUserEvolutionsState : window.saveUserEvolutionsState;
  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (saveFn) await saveFn();
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  alert(`🔄 Evolución "${evolution.name}" reseteada correctamente.`);
}

async function debugCompleteAllActiveEvolutionPhases() {
  const { evolutions, state } = await debugEnsureEvolutionsLoaded();
  const activeEvos = evolutions.filter(e => state[e.id]?.started && !state[e.id]?.claimedAt);

  if (activeEvos.length === 0) {
    alert('⚠️ No hay ninguna evolución activa actualmente.');
    return;
  }

  if (!confirm(`¿Avanzar una fase en las ${activeEvos.length} evolución(es) activa(s)?`)) return;

  for (const evo of activeEvos) {
    await debugAdvanceEvolutionPhase(evo.id, true);
  }

  const saveFn = (typeof saveUserEvolutionsState === 'function') ? saveUserEvolutionsState : window.saveUserEvolutionsState;
  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (saveFn) await saveFn();
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  alert(`✅ Fase avanzada con éxito en ${activeEvos.length} evolución(es) activa(s).`);
}

async function debugCompleteAllEvolutions() {
  const { evolutions } = await debugEnsureEvolutionsLoaded();
  if (!evolutions || evolutions.length === 0) {
    alert('⚠️ No hay evoluciones disponibles.');
    return;
  }

  if (!confirm(`⚠️ ¿Completar al 100% TODAS las evoluciones (${evolutions.length}) del juego?`)) return;

  for (const evo of evolutions) {
    let progress = (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}))[evo.id];
    if (!progress || !progress.started || progress.claimedAt) {
      progress = await debugAutoStartEvolution(evo, true);
    }

    let iterations = 0;
    while (iterations < 20) {
      iterations++;
      progress = (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}))[evo.id];
      if (!progress || !progress.started || progress.claimedAt) break;

      const phasesFn = (typeof getEvolutionPhases === 'function') ? getEvolutionPhases : window.getEvolutionPhases;
      const phases = phasesFn ? phasesFn(evo, progress) : [];
      const isFinalPhase = (progress.currentPhase || 1) >= (progress.totalPhases || phases.length);

      await debugAdvanceEvolutionPhase(evo.id, true);
      if (isFinalPhase) break;
    }
  }

  const saveFn = (typeof saveUserEvolutionsState === 'function') ? saveUserEvolutionsState : window.saveUserEvolutionsState;
  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (saveFn) await saveFn();
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  alert(`🏆 ¡Todas las evoluciones (${evolutions.length}) han sido completadas al 100%!`);
}

async function debugResetAllEvolutions() {
  if (!confirm('⚠️ ¿Resetear el estado de TODAS las evoluciones? Se borrará todo el progreso de evoluciones.')) return;

  if (typeof userEvolutions !== 'undefined') {
    for (const key of Object.keys(userEvolutions)) delete userEvolutions[key];
  }
  if (window.userEvolutions) {
    for (const key of Object.keys(window.userEvolutions)) delete window.userEvolutions[key];
  }

  if (window.kvrcards?.saveEvolutionState) {
    await window.kvrcards.saveEvolutionState({});
  }
  localStorage.removeItem('kvr_user_evolutions_v2');

  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  alert('🔄 Todas las evoluciones han sido reseteadas correctamente.');
}

async function populateDebugEvolutionsSelect() {
  const select = document.getElementById('debug-evolution-select');
  if (!select) return;

  const { evolutions, state } = await debugEnsureEvolutionsLoaded();
  const currentVal = select.value;

  select.innerHTML = '';
  if (!evolutions || evolutions.length === 0) {
    select.innerHTML = '<option value="">No hay evoluciones disponibles</option>';
    updateDebugEvolutionInfo();
    return;
  }

  evolutions.forEach(evo => {
    const opt = document.createElement('option');
    opt.value = evo.id;
    const p = state[evo.id];
    let tag = '⚪ No iniciada';
    if (p?.claimedAt) {
      tag = '✅ Completada';
    } else if (p?.started) {
      tag = `⚡ Activa (Fase ${p.currentPhase || 1}/${p.totalPhases || '?'})`;
    }
    opt.textContent = `${evo.name || evo.id} [${tag}]`;
    select.appendChild(opt);
  });

  if (currentVal && Array.from(select.options).some(o => o.value === currentVal)) {
    select.value = currentVal;
  }

  updateDebugEvolutionInfo();
}

function updateDebugEvolutionInfo() {
  const select = document.getElementById('debug-evolution-select');
  const infoBox = document.getElementById('debug-evolution-info');
  if (!select || !infoBox) return;

  const evoId = select.value;
  const evos = (typeof availableEvolutions !== 'undefined' ? availableEvolutions : (window.availableEvolutions || []));
  const evo = evos.find(e => e.id === evoId);
  const state = (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}));

  if (!evo) {
    infoBox.innerHTML = '<em>Selecciona una evolución para ver su estado</em>';
    return;
  }

  const p = state[evo.id];
  let statusBadge = '<span style="color:#9ca3af; font-weight:bold;">⚪ No iniciada</span>';
  if (p?.claimedAt) {
    statusBadge = '<span style="color:#10b981; font-weight:bold;">✅ Completada</span>';
  } else if (p?.started) {
    statusBadge = `<span style="color:#eab308; font-weight:bold;">⚡ Activa (Fase ${p.currentPhase || 1} de ${p.totalPhases || '?'})</span>`;
  }

  const phasesFn = (typeof getEvolutionPhases === 'function') ? getEvolutionPhases : window.getEvolutionPhases;
  const phases = phasesFn ? phasesFn(evo, p || {}) : [];
  const currentPhaseIndex = Math.max(0, (p?.currentPhase || 1) - 1);
  const currentPhase = phases[currentPhaseIndex] || phases[0] || {};
  const missions = currentPhase.missions || [];

  let missionsHtml = '';
  if (p?.started && missions.length > 0) {
    missionsHtml = '<div style="margin-top:6px; font-size:12px; color:#cbd5e1;"><strong>Misiones de esta fase:</strong><ul style="margin:4px 0 0 16px; padding:0;">';
    missions.forEach(m => {
      const isDone = p.missionsCompleted?.[m.id];
      const prog = p.missionsProgress?.[m.id]?.current || 0;
      const target = p.missionsProgress?.[m.id]?.target || m.target || 1;
      missionsHtml += `<li>${isDone ? '✅' : '⏳'} ${m.name || m.description || m.id}: ${prog}/${target} ${isDone ? '(Completada)' : ''}</li>`;
    });
    missionsHtml += '</ul></div>';
  }

  infoBox.innerHTML = `
    <div><strong>Evolución:</strong> ${evo.name || evo.id} <span style="font-size:11px; color:#aaa;">(${evo.id})</span></div>
    <div><strong>Estado:</strong> ${statusBadge} ${p?.completionsCount ? `| Completada ${p.completionsCount} vez/veces` : ''}</div>
    ${p?.started ? `
      <div><strong>Carta actual:</strong> <code style="background:#0f172a; padding:1px 4px; border-radius:3px;">${p.cardId || '-'}</code> &nbsp;➔&nbsp; <strong>Objetivo de fase:</strong> <code style="background:#0f172a; padding:1px 4px; border-radius:3px;">${p.targetCardTo || '-'}</code></div>
      <div><strong>Fase actual:</strong> ${currentPhase.name || `Fase ${currentPhaseIndex + 1}`} (${currentPhaseIndex + 1}/${phases.length})</div>
      ${missionsHtml}
    ` : `
      <div style="font-size:12px; color:#888;">Fases totales: ${phases.length} | Carta(s) base: ${Array.isArray(evo.cardFrom) ? evo.cardFrom.join(', ') : (evo.cardFrom || 'Opciones múltiples')}</div>
    `}
  `;
}

// Exponer funciones debug en window
window.debugCompleteEvolutionMissions = debugCompleteEvolutionMissions;
window.debugAdvanceEvolutionPhase = debugAdvanceEvolutionPhase;
window.debugCompleteFullEvolution = debugCompleteFullEvolution;
window.debugResetEvolution = debugResetEvolution;
window.debugCompleteAllActiveEvolutionPhases = debugCompleteAllActiveEvolutionPhases;
window.debugCompleteAllEvolutions = debugCompleteAllEvolutions;
window.debugResetAllEvolutions = debugResetAllEvolutions;
window.populateDebugEvolutionsSelect = populateDebugEvolutionsSelect;
window.updateDebugEvolutionInfo = updateDebugEvolutionInfo;

// ==================== DEBUG: GESTION DE TRAITS ====================
let selectedDebugTraitCard = null;
let debugTraitsInitialized = false;

function showDebugTraitStatus(message, isSuccess = true) {
  const statusEl = document.getElementById('debug-trait-status');
  if (!statusEl) return;
  statusEl.style.display = 'block';
  statusEl.style.background = isSuccess ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)';
  statusEl.style.border = isSuccess ? '1px solid #10b981' : '1px solid #ef4444';
  statusEl.style.color = isSuccess ? '#34d399' : '#f87171';
  statusEl.textContent = message;
  setTimeout(() => {
    if (statusEl) statusEl.style.display = 'none';
  }, 4500);
}

async function populateDebugTraitsSelect() {
  const select = document.getElementById('debug-trait-select');
  if (!select) return;

  // Cargar lista de traits disponibles si esta vacia
  if (!window.availableTraits || window.availableTraits.length === 0) {
    if (window.kvrcards && typeof window.kvrcards.getAllTraits === 'function') {
      try {
        const loaded = await window.kvrcards.getAllTraits();
        window.availableTraits = Array.isArray(loaded) ? loaded : (Array.isArray(loaded?.traits) ? loaded.traits : []);
      } catch (err) {
        console.warn('[DEBUG TRAITS] Error cargando traits desde IPC:', err);
      }
    }
    if ((!window.availableTraits || window.availableTraits.length === 0) && typeof fetchFallbackTraits === 'function') {
      window.availableTraits = await fetchFallbackTraits();
    }
  }

  const traits = window.availableTraits || [];
  select.innerHTML = '';

  if (traits.length === 0) {
    select.innerHTML = '<option value="">No hay traits disponibles</option>';
    updateDebugTraitDetail();
    return;
  }

  // Ordenar por rareza: Common, Rare, Epic, Legendary, Mythic
  const rarityOrder = { 'common': 1, 'rare': 2, 'epic': 3, 'legendary': 4, 'mythic': 5 };
  const sortedTraits = [...traits].sort((a, b) => {
    const rA = rarityOrder[String(a.rarity || '').toLowerCase()] || 99;
    const rB = rarityOrder[String(b.rarity || '').toLowerCase()] || 99;
    if (rA !== rB) return rA - rB;
    return String(a.name || a.id).localeCompare(String(b.name || b.id));
  });

  sortedTraits.forEach(trait => {
    const opt = document.createElement('option');
    opt.value = trait.id;
    const rarityLabel = (trait.rarity || 'Normal').toUpperCase();
    opt.textContent = `[${rarityLabel}] ${trait.name || trait.id}`;
    select.appendChild(opt);
  });

  updateDebugTraitDetail();
}

function updateDebugTraitDetail() {
  const select = document.getElementById('debug-trait-select');
  const imgEl = document.getElementById('debug-trait-detail-img');
  const nameEl = document.getElementById('debug-trait-detail-name');
  const descEl = document.getElementById('debug-trait-detail-desc');
  if (!select || !nameEl || !descEl) return;

  const traitId = select.value;
  const trait = (window.availableTraits || []).find(t => t.id === traitId);

  if (!trait) {
    if (imgEl) imgEl.style.display = 'none';
    nameEl.textContent = '-';
    descEl.textContent = 'Selecciona un trait para ver detalles';
    return;
  }

  if (imgEl) {
    if (trait.imageUrl) {
      imgEl.src = trait.imageUrl;
      imgEl.style.display = 'block';
    } else {
      imgEl.style.display = 'none';
    }
  }

  const rarityText = trait.rarity ? ` (${trait.rarity.toUpperCase()})` : '';
  nameEl.textContent = (trait.name || trait.id) + rarityText;
  descEl.textContent = trait.description || 'Sin descripcion adicional';
}

async function updateDebugTraitCardInfo() {
  const nameEl = document.getElementById('debug-trait-card-name');
  const idEl = document.getElementById('debug-trait-card-id');
  const invEl = document.getElementById('debug-trait-card-inventory');
  const currentTraitEl = document.getElementById('debug-trait-card-current');
  const previewImg = document.getElementById('debug-trait-card-preview-img');
  const placeholder = document.getElementById('debug-trait-card-preview-placeholder');

  if (!selectedDebugTraitCard) {
    if (nameEl) nameEl.textContent = 'Selecciona una carta arriba';
    if (idEl) idEl.textContent = '-';
    if (invEl) invEl.textContent = 'Copias en inventario: 0';
    if (currentTraitEl) currentTraitEl.textContent = 'Trait actual: Ninguno';
    if (previewImg) previewImg.style.display = 'none';
    if (placeholder) placeholder.style.display = 'block';
    return;
  }

  const card = selectedDebugTraitCard;
  if (nameEl) nameEl.textContent = card.name || card.id;
  if (idEl) idEl.textContent = `ID: ${card.id}`;

  if (previewImg) {
    const imgSrc = card.imageUrl || card.image || card.imagen || '';
    if (imgSrc) {
      previewImg.src = imgSrc;
      previewImg.style.display = 'block';
      if (placeholder) placeholder.style.display = 'none';
    } else {
      previewImg.style.display = 'none';
      if (placeholder) placeholder.style.display = 'block';
    }
  }

  // Comprobar inventario y traits asignados
  let count = 0;
  let currentTraitId = null;
  let currentInstanceId = null;

  try {
    if (window.kvrcards && typeof window.kvrcards.getInventory === 'function') {
      const inv = await window.kvrcards.getInventory();
      if (inv && inv.ok) {
        count = inv.cards?.[card.id] || 0;
        const traitsMap = inv.cardTraits || {};

        const traitsForCard = [];
        for (const [instId, data] of Object.entries(traitsMap)) {
          const cid = typeof data === 'object' && data ? data.cardId : instId;
          if (cid === card.id) {
            const tid = typeof data === 'object' && data ? data.traitId : data;
            traitsForCard.push({ instanceId: instId, traitId: tid });
            if (!currentTraitId) {
              currentTraitId = tid;
              currentInstanceId = instId;
            }
          }
        }
        const traitCopiesCount = Math.min(traitsForCard.length, count);
        const normalCopiesCount = Math.max(0, count - traitCopiesCount);
        if (invEl) {
          if (traitCopiesCount > 0) {
            invEl.textContent = `Copias en inventario: ${count} (${traitCopiesCount} con trait, ${normalCopiesCount} normales)`;
          } else {
            invEl.textContent = `Copias en inventario: ${count}`;
          }
        }
      }
    }
  } catch (err) {
    console.warn('[DEBUG TRAITS] Error consultando inventario de carta:', err);
  }

  selectedDebugTraitCard.instanceId = currentInstanceId;
  selectedDebugTraitCard.currentTraitId = currentTraitId;

  if (currentTraitEl) {
    if (currentTraitId) {
      const traitObj = (window.availableTraits || []).find(t => t.id === currentTraitId);
      const traitName = traitObj ? traitObj.name : currentTraitId;
      const traitRarity = traitObj && traitObj.rarity ? ` [${traitObj.rarity.toUpperCase()}]` : '';
      currentTraitEl.textContent = `Trait actual (1 copia): ${traitName}${traitRarity}`;
      currentTraitEl.style.color = '#34d399';
    } else {
      currentTraitEl.textContent = 'Trait actual: Ninguno';
      currentTraitEl.style.color = '#eab308';
    }
  }
}

async function debugApplyTraitToCard() {
  if (!selectedDebugTraitCard) {
    alert('Busca y selecciona una carta primero.');
    return;
  }

  const select = document.getElementById('debug-trait-select');
  const traitId = select?.value;
  if (!traitId) {
    alert('Selecciona un trait de la lista.');
    return;
  }

  const cardId = selectedDebugTraitCard.id;
  const instanceId = selectedDebugTraitCard.instanceId;

  const traitObj = (window.availableTraits || []).find(t => t.id === traitId);
  const traitName = traitObj ? traitObj.name : traitId;

  try {
    let result = null;
    if (window.kvrcards && typeof window.kvrcards.debugAssignTrait === 'function') {
      result = await window.kvrcards.debugAssignTrait(cardId, traitId, instanceId);
    } else if (window.kvrcards && typeof window.kvrcards.assignTrait === 'function') {
      result = await window.kvrcards.assignTrait(instanceId || cardId, traitId, !instanceId);
    }

    if (result && result.error) {
      alert('Error asignando trait: ' + result.error);
      return;
    }

    // Recargar inventario completo
    if (window.kvrcards && typeof window.kvrcards.getInventory === 'function') {
      const inv = await window.kvrcards.getInventory();
      if (inv && inv.ok) {
        if (typeof cardTraitsMap !== 'undefined') cardTraitsMap = inv.cardTraits || {};
        if (typeof userInv !== 'undefined') userInv = inv;
      }
    }

    if (typeof renderCollection === 'function') await renderCollection();
    if (typeof window.renderTraitsPanel === 'function') {
      await window.renderTraitsPanel();
    } else if (typeof renderTraitsPanel === 'function') {
      await renderTraitsPanel();
    }

    await updateDebugTraitCardInfo();
    showDebugTraitStatus(`Trait "${traitName}" asignado con exito a ${selectedDebugTraitCard.name || cardId}`);
  } catch (err) {
    console.error('[DEBUG TRAITS] Error asignando trait:', err);
    alert('Error al asignar trait: ' + err.message);
  }
}

async function debugRemoveTraitFromCard() {
  if (!selectedDebugTraitCard) {
    alert('Busca y selecciona una carta primero.');
    return;
  }

  const cardId = selectedDebugTraitCard.id;
  const instanceId = selectedDebugTraitCard.instanceId;

  if (!selectedDebugTraitCard.currentTraitId && !instanceId) {
    alert('Esta carta no tiene ningun trait asignado.');
    return;
  }

  if (!confirm(`Deseas quitar el trait de la carta "${selectedDebugTraitCard.name || cardId}"?`)) {
    return;
  }

  try {
    let result = null;
    if (window.kvrcards && typeof window.kvrcards.debugRemoveTrait === 'function') {
      result = await window.kvrcards.debugRemoveTrait(cardId, instanceId);
    }

    if (result && result.error) {
      alert('Error quitando trait: ' + result.error);
      return;
    }

    // Recargar inventario
    if (window.kvrcards && typeof window.kvrcards.getInventory === 'function') {
      const inv = await window.kvrcards.getInventory();
      if (inv && inv.ok) {
        if (typeof cardTraitsMap !== 'undefined') cardTraitsMap = inv.cardTraits || {};
        if (typeof userInv !== 'undefined') userInv = inv;
      }
    }

    if (typeof renderCollection === 'function') await renderCollection();
    if (typeof window.renderTraitsPanel === 'function') {
      await window.renderTraitsPanel();
    } else if (typeof renderTraitsPanel === 'function') {
      await renderTraitsPanel();
    }

    await updateDebugTraitCardInfo();
    showDebugTraitStatus(`Trait eliminado con exito de ${selectedDebugTraitCard.name || cardId}`);
  } catch (err) {
    console.error('[DEBUG TRAITS] Error quitando trait:', err);
    alert('Error al quitar trait: ' + err.message);
  }
}

// Forzar rarezas en tiradas de traits (ruleta)
function getForcedTraitRarities() {
  try {
    const raw = localStorage.getItem('kvr_debug_forced_trait_rarities');
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) return arr;
    }
  } catch (e) {}
  return [];
}
window.getForcedTraitRarities = getForcedTraitRarities;

function updateForcedTraitRaritiesUI() {
  const forced = getForcedTraitRarities();
  const checkboxes = document.querySelectorAll('.debug-force-trait-rarity');
  checkboxes.forEach(cb => {
    cb.checked = forced.includes(cb.value.toLowerCase().trim());
  });

  const badge = document.getElementById('debug-forced-traits-badge');
  if (badge) {
    if (forced.length > 0) {
      badge.textContent = 'FORZADO: ' + forced.map(r => r.toUpperCase()).join(', ');
      badge.style.background = '#4338ca';
      badge.style.color = '#c7d2fe';
    } else {
      badge.textContent = 'Desactivado (Prob. Normal)';
      badge.style.background = '#374151';
      badge.style.color = '#9ca3af';
    }
  }
}
window.updateForcedTraitRaritiesUI = updateForcedTraitRaritiesUI;

function setForcedTraitRarities(arr) {
  try {
    if (Array.isArray(arr) && arr.length > 0) {
      localStorage.setItem('kvr_debug_forced_trait_rarities', JSON.stringify(arr));
    } else {
      localStorage.removeItem('kvr_debug_forced_trait_rarities');
    }
  } catch (e) {}
  updateForcedTraitRaritiesUI();
}
window.setForcedTraitRarities = setForcedTraitRarities;

async function initDebugTraits() {
  updateForcedTraitRaritiesUI();

  // Escuchar cambios en checkboxes de rareza forzada
  document.querySelectorAll('.debug-force-trait-rarity').forEach(cb => {
    cb.addEventListener('change', () => {
      const selected = [];
      document.querySelectorAll('.debug-force-trait-rarity:checked').forEach(c => {
        selected.push(c.value.toLowerCase().trim());
      });
      setForcedTraitRarities(selected);
      showDebugTraitStatus(selected.length > 0 ? ('Tiradas de rasgos forzadas a: ' + selected.join(', ')) : 'Tiradas de rasgos restablecidas a probabilidades normales');
    });
  });

  document.getElementById('debug-force-trait-all-btn')?.addEventListener('click', () => {
    const all = ['knight', 'mythic', 'legendary', 'epic', 'rare', 'common'];
    setForcedTraitRarities(all);
    showDebugTraitStatus('Todas las calidades activadas para la ruleta');
  });

  document.getElementById('debug-force-trait-clear-btn')?.addEventListener('click', () => {
    setForcedTraitRarities([]);
    showDebugTraitStatus('Forzado de calidades desactivado (Probabilidades normales)');
  });

  await populateDebugTraitsSelect();

  if (debugTraitsInitialized) return;
  debugTraitsInitialized = true;

  const traitSelect = document.getElementById('debug-trait-select');
  traitSelect?.addEventListener('change', updateDebugTraitDetail);

  const searchInput = document.getElementById('debug-trait-card-search');
  const resultsContainer = document.getElementById('debug-trait-card-results');

  searchInput?.addEventListener('input', async () => {
    const text = String(searchInput.value || '').toLowerCase().trim();
    if (!text || text.length < 2) {
      if (resultsContainer) resultsContainer.innerHTML = '';
      return;
    }

    let allCards = [];
    if (window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
      allCards = await window.kvrcards.getAllCards();
    } else if (typeof availableCards !== 'undefined') {
      allCards = availableCards;
    }

    const cardsList = Array.isArray(allCards) ? allCards : (allCards?.cards || []);
    const matches = cardsList.filter(card =>
      String(card.id || '').toLowerCase().includes(text) ||
      String(card.name || card.nombre || '').toLowerCase().includes(text)
    ).slice(0, 8);

    if (resultsContainer) {
      resultsContainer.innerHTML = matches.map(card => `
        <div class="debug-result-item" data-card-id="${card.id}" data-card-name="${card.name || card.nombre || card.id}">
          <img src="${card.imageUrl || card.image || card.imagen || ''}" alt="${card.name || card.id}" style="width: 50px; height: 70px; object-fit: cover;" />
          <div>
            <strong>${card.name || card.nombre || card.id}</strong>
            <small>${card.id}</small>
          </div>
        </div>
      `).join('');
    }
  });

  resultsContainer?.addEventListener('click', async (e) => {
    const item = e.target.closest('.debug-result-item');
    if (!item) return;

    document.querySelectorAll('#debug-trait-card-results .debug-result-item').forEach(i => {
      i.style.border = '1px solid #374151';
      i.style.background = '';
    });

    item.style.border = '2px solid var(--gold)';
    item.style.background = 'rgba(212, 175, 55, 0.1)';

    const cardId = item.dataset.cardId;
    let cardObj = null;

    let allCards = [];
    if (window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
      allCards = await window.kvrcards.getAllCards();
    }
    const list = Array.isArray(allCards) ? allCards : (allCards?.cards || []);
    cardObj = list.find(c => c.id === cardId);

    if (!cardObj) {
      cardObj = { id: cardId, name: item.dataset.cardName };
    }

    selectedDebugTraitCard = cardObj;
    await updateDebugTraitCardInfo();
  });

  const applyBtn = document.getElementById('debug-apply-trait-btn');
  applyBtn?.addEventListener('click', debugApplyTraitToCard);

  const removeBtn = document.getElementById('debug-remove-trait-btn');
  removeBtn?.addEventListener('click', debugRemoveTraitFromCard);
}

window.initDebugTraits = initDebugTraits;
window.populateDebugTraitsSelect = populateDebugTraitsSelect;
window.debugApplyTraitToCard = debugApplyTraitToCard;
window.debugRemoveTraitFromCard = debugRemoveTraitFromCard;

// ==================== GESTIÓN DEBUG: OBJETOS (ITEMS) ====================
let selectedDebugItem = null;
let debugItemsInitialized = false;

const DEBUG_ITEMS_FALLBACK = [
  {
    id: 'sombrero_sospechoso',
    name: 'Sombrero Sospechoso',
    description: 'Este sombrero me suena de algo... ¿Por qué lo guarda Hangaku?',
    calidad: 'Mítico',
    image: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/sombrero_sospechoso.png'
  },
  {
    id: 'deseo',
    name: 'Deseo de Haseo',
    description: 'Canjea tu deseo en la tienda del evento del Torneo de Haseo',
    calidad: 'Raro',
    image: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/deseo.png'
  },
  {
    id: 'alma_del_sol',
    name: 'Alma del Sol',
    description: 'El sol... Parece que si consigo 10 de estas almas obtendré una recompensa legendaria.',
    calidad: 'Legendario',
    image: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Alma_del_Sol.png'
  },
  {
    id: 'capa_baryon_yang',
    name: 'Capa Baryon Yang',
    description: 'La capa baryon del Yang. Si la juntas con la del Ying se desbloqueará algo increíble.',
    calidad: 'Knight',
    image: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Capa_Baryon_Yang.png'
  },
  {
    id: 'capa_baryon_ying',
    name: 'Capa Baryon Ying',
    description: 'La capa baryon del Ying. Si la juntas con la del Yang se desbloqueará algo increíble.',
    calidad: 'Knight',
    image: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Capa_Baryon_Ying.png'
  },
  {
    id: 'octava_puerta',
    name: 'Octava Puerta',
    description: 'El poder de abrir la última puerta. Si juntas 8 puertas internas podrás desbloquear algo increíble.',
    calidad: 'Knight',
    image: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Octava_Puerta.png'
  },
  {
    id: 'pergamino_elemental_agua',
    name: 'Pergamino Elemental de Agua',
    description: 'Un pergamino que contiene el poder elemental del Agua.',
    calidad: 'Épico',
    image: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Pergamino_elemental_agua.png'
  },
  {
    id: 'pergamino_elemental_fuego',
    name: 'Pergamino Elemental de Fuego',
    description: 'Un pergamino que contiene el poder elemental del Fuego.',
    calidad: 'Épico',
    image: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Pergamino_elemental_fuego.png'
  },
  {
    id: 'pergamino_elemental_rayo',
    name: 'Pergamino Elemental de Rayo',
    description: 'Un pergamino que contiene el poder elemental del Rayo.',
    calidad: 'Épico',
    image: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Pergamino_elemental_rayo.png'
  },
  {
    id: 'bankakyo_byakugan',
    name: 'Bankakyo Byakugan',
    description: 'Ojos capaces de ver el flujo de chakra. ¿Qué pasará si lo juntas con el Bankakyo Sharingan?',
    calidad: 'Knight',
    image: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/bankaikio_byakugan.png'
  },
  {
    id: 'puertas_internas',
    name: 'Puertas Internas',
    description: 'Desbloquea el poder de las puertas internas. Si consigues 8, podrás canjear algo especial.',
    calidad: 'Mítico',
    image: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/puertasinternas.png'
  }
];

async function getDebugItemInventoryCount(itemId) {
  if (!itemId) return 0;
  const cleanId = String(itemId).trim();
  if (window.kvrcards && typeof window.kvrcards.getItemsInventory === 'function') {
    try {
      const inv = await window.kvrcards.getItemsInventory();
      if (inv && inv.ok && inv.items && inv.items[cleanId] !== undefined) {
        return Number(inv.items[cleanId]) || 0;
      }
    } catch (e) {}
  }
  try {
    const raw = localStorage.getItem('kvr_user_items') || '{}';
    const parsed = JSON.parse(raw);
    if (parsed[cleanId] !== undefined) return Number(parsed[cleanId]) || 0;
    const lower = cleanId.toLowerCase();
    const foundKey = Object.keys(parsed).find(k => k.toLowerCase() === lower);
    if (foundKey && parsed[foundKey] !== undefined) return Number(parsed[foundKey]) || 0;
  } catch (e) {}
  if (window.userProfile?.items && window.userProfile.items[cleanId] !== undefined) {
    return Number(window.userProfile.items[cleanId]) || 0;
  }
  return 0;
}

async function debugAddItem(itemId, quantity = 1, skipConfirm = false) {
  if (!itemId) {
    alert('Por favor selecciona un objeto primero');
    return;
  }
  const qty = Math.max(1, Number(quantity) || 1);
  if (!skipConfirm && !confirm(`¿Añadir ${qty}x objeto(s) "${itemId}"?`)) return;

  try {
    let success = false;
    if (window.kvrcards && typeof window.kvrcards.addItem === 'function') {
      const res = await window.kvrcards.addItem(itemId, qty);
      if (res && res.ok) success = true;
    }
    try {
      const raw = localStorage.getItem('kvr_user_items') || '{}';
      const parsed = JSON.parse(raw);
      parsed[itemId] = (Number(parsed[itemId]) || 0) + qty;
      localStorage.setItem('kvr_user_items', JSON.stringify(parsed));
      if (!window.userProfile) window.userProfile = {};
      if (!window.userProfile.items) window.userProfile.items = {};
      window.userProfile.items[itemId] = parsed[itemId];
      success = true;
    } catch (e) {}

    await syncInventoryToR2();
    await updateDebugItemInfo();
    if (!skipConfirm) {
      showDebugItemStatus(`✅ Añadido(s) ${qty}x "${itemId}" correctamente`, true);
    }
  } catch (err) {
    console.error('[DEBUG ITEMS] Error añadiendo objeto:', err);
    if (!skipConfirm) {
      showDebugItemStatus(`❌ Error añadiendo objeto: ${err.message}`, false);
    }
  }
}

async function debugRemoveItem(itemId, quantity = 1) {
  if (!itemId) {
    alert('Por favor selecciona un objeto primero');
    return;
  }
  const currentCount = await getDebugItemInventoryCount(itemId);
  if (currentCount <= 0) {
    alert(`⚠️ No posees ningún objeto de "${itemId}" en tu inventario.`);
    return;
  }
  const qtyReq = Math.max(1, Number(quantity) || 1);
  const qtyToRemove = Math.min(qtyReq, currentCount);

  if (!confirm(`¿Eliminar ${qtyToRemove} unidad(es) de "${itemId}"? (Posees: ${currentCount})`)) return;

  try {
    if (window.kvrcards && typeof window.kvrcards.consumeItem === 'function') {
      await window.kvrcards.consumeItem(itemId, qtyToRemove).catch(() => {});
    }
    try {
      const raw = localStorage.getItem('kvr_user_items') || '{}';
      const parsed = JSON.parse(raw);
      const cur = Number(parsed[itemId]) || 0;
      if (cur <= qtyToRemove) {
        delete parsed[itemId];
      } else {
        parsed[itemId] = cur - qtyToRemove;
      }
      localStorage.setItem('kvr_user_items', JSON.stringify(parsed));
      if (window.userProfile?.items) {
        if (cur <= qtyToRemove) delete window.userProfile.items[itemId];
        else window.userProfile.items[itemId] = parsed[itemId];
      }
    } catch (e) {}

    await syncInventoryToR2();
    await updateDebugItemInfo();
    showDebugItemStatus(`✅ Eliminado(s) ${qtyToRemove}x "${itemId}" correctamente`, true);
  } catch (err) {
    console.error('[DEBUG ITEMS] Error eliminando objeto:', err);
    showDebugItemStatus(`❌ Error eliminando objeto: ${err.message}`, false);
  }
}

async function debugAddAllItems() {
  const confirmAdd = confirm('¿Añadir 10 unidades de CADA objeto del catálogo a tu inventario?');
  if (!confirmAdd) return;

  let catalog = [];
  if (typeof window.loadAllItems === 'function') {
    catalog = await window.loadAllItems();
  }
  if (!Array.isArray(catalog) || catalog.length === 0) {
    catalog = DEBUG_ITEMS_FALLBACK;
  }

  const btn = document.getElementById('debug-add-all-items');
  if (btn) {
    btn.disabled = true;
    btn.textContent = 'Añadiendo objetos...';
  }

  try {
    for (const item of catalog) {
      if (item && item.id) {
        await debugAddItem(item.id, 10, true);
      }
    }
    await syncInventoryToR2();
    await updateDebugItemInfo();
    alert('✅ Se han añadido 10 unidades de cada objeto del catálogo con éxito.');
  } catch (e) {
    console.error('[DEBUG ITEMS] Error añadiendo todos los objetos:', e);
    alert('Error al añadir objetos: ' + e.message);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '➕ Añadir Todos los Objetos (x10)';
    }
  }
}

async function debugClearAllItems() {
  const confirmClear = confirm('⚠️ ¿Estás seguro de que deseas vaciar por completo tu inventario de objetos? Esta acción no se puede deshacer.');
  if (!confirmClear) return;

  try {
    let ownedMap = {};
    if (window.kvrcards && typeof window.kvrcards.getItemsInventory === 'function') {
      const inv = await window.kvrcards.getItemsInventory();
      if (inv && inv.ok && inv.items) ownedMap = inv.items;
    }
    for (const id in ownedMap) {
      const count = Number(ownedMap[id]) || 0;
      if (count > 0 && window.kvrcards && typeof window.kvrcards.consumeItem === 'function') {
        await window.kvrcards.consumeItem(id, count).catch(() => {});
      }
    }
    try {
      localStorage.setItem('kvr_user_items', '{}');
      if (window.userProfile) window.userProfile.items = {};
    } catch (e) {}

    await syncInventoryToR2();
    await updateDebugItemInfo();
    showDebugItemStatus('🗑️ Inventario de objetos vaciado por completo', true);
  } catch (e) {
    console.error('[DEBUG ITEMS] Error vaciando objetos:', e);
    showDebugItemStatus('Error al vaciar objetos: ' + e.message, false);
  }
}

async function updateDebugItemInfo() {
  const nameEl = document.getElementById('debug-item-selected-name');
  const idEl = document.getElementById('debug-item-selected-id');
  const invEl = document.getElementById('debug-item-selected-inventory');
  const previewImg = document.getElementById('debug-item-preview-img');
  const placeholder = document.getElementById('debug-item-preview-placeholder');

  if (!selectedDebugItem) {
    if (nameEl) nameEl.textContent = 'Selecciona un objeto arriba';
    if (idEl) idEl.textContent = '-';
    if (invEl) invEl.textContent = 'Posees actualmente: 0';
    if (previewImg) { previewImg.style.display = 'none'; previewImg.src = ''; }
    if (placeholder) placeholder.style.display = 'block';
    return;
  }

  const itemId = selectedDebugItem.id;
  const count = await getDebugItemInventoryCount(itemId);
  const itemName = selectedDebugItem.name || selectedDebugItem.nombre || itemId;
  const itemImg = selectedDebugItem.image || selectedDebugItem.imageUrl || selectedDebugItem.imagen || './assets/default-item.png';
  const quality = selectedDebugItem.calidad || selectedDebugItem.quality || 'Común';

  if (nameEl) nameEl.textContent = `${itemName} (${quality})`;
  if (idEl) idEl.textContent = itemId;
  if (invEl) invEl.textContent = `Posees actualmente: ${count}`;

  if (previewImg) {
    previewImg.src = itemImg;
    previewImg.style.display = 'block';
  }
  if (placeholder) placeholder.style.display = 'none';
}

function showDebugItemStatus(msg, isSuccess = true) {
  const statusEl = document.getElementById('debug-item-status');
  if (!statusEl) return;
  statusEl.textContent = msg;
  statusEl.style.display = 'block';
  statusEl.style.background = isSuccess ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)';
  statusEl.style.border = isSuccess ? '1px solid #10b981' : '1px solid #ef4444';
  statusEl.style.color = isSuccess ? '#6ee7b7' : '#fca5a5';
  setTimeout(() => {
    if (statusEl) statusEl.style.display = 'none';
  }, 4000);
}

function renderDebugItemResults(query) {
  const resultsContainer = document.getElementById('debug-item-results');
  if (!resultsContainer) return;

  let catalog = window.itemCatalog;
  if (!Array.isArray(catalog) || catalog.length === 0) {
    catalog = DEBUG_ITEMS_FALLBACK;
  }

  const q = String(query || '').toLowerCase().trim();
  const matches = catalog.filter(it => {
    if (!q) return true;
    return (
      String(it.id || '').toLowerCase().includes(q) ||
      String(it.name || it.nombre || '').toLowerCase().includes(q) ||
      String(it.description || it.descripcion || '').toLowerCase().includes(q)
    );
  }).slice(0, 12);

  resultsContainer.innerHTML = matches.map(it => {
    const isSelected = selectedDebugItem && selectedDebugItem.id === it.id;
    const borderStyle = isSelected ? 'border: 2px solid var(--gold); background: rgba(212, 175, 55, 0.1);' : '';
    const imgUrl = it.image || it.imageUrl || it.imagen || './assets/default-item.png';
    const quality = it.calidad || it.quality || 'Común';
    return `
      <div class="debug-result-item" data-item-id="${it.id}" data-item-name="${it.name || it.id}" style="${borderStyle}">
        <img src="${imgUrl}" alt="${it.name || it.id}" style="width: 44px; height: 44px; object-fit: contain;" onerror="this.src='./icon-especiales.png'" />
        <div>
          <strong>${it.name || it.nombre || it.id} <span style="font-size: 11px; opacity: 0.8; font-weight: normal;">(${quality})</span></strong>
          <small>${it.id}</small>
        </div>
      </div>
    `;
  }).join('');
}

async function initDebugItems() {
  if (typeof window.loadAllItems === 'function') {
    await window.loadAllItems().catch(() => {});
  }

  renderDebugItemResults('');

  if (debugItemsInitialized) {
    if (selectedDebugItem) updateDebugItemInfo();
    return;
  }
  debugItemsInitialized = true;

  const searchInput = document.getElementById('debug-item-search');
  const resultsContainer = document.getElementById('debug-item-results');

  searchInput?.addEventListener('input', () => {
    const text = String(searchInput.value || '').toLowerCase().trim();
    renderDebugItemResults(text);
  });

  resultsContainer?.addEventListener('click', async (e) => {
    const itemEl = e.target.closest('.debug-result-item');
    if (!itemEl) return;

    document.querySelectorAll('#debug-item-results .debug-result-item').forEach(i => {
      i.style.border = '1px solid #374151';
      i.style.background = '';
    });

    itemEl.style.border = '2px solid var(--gold)';
    itemEl.style.background = 'rgba(212, 175, 55, 0.1)';

    const itemId = itemEl.dataset.itemId;
    let itemObj = (typeof window.findItemInCatalog === 'function') ? window.findItemInCatalog(itemId) : null;
    if (!itemObj) {
      itemObj = { id: itemId, name: itemEl.dataset.itemName };
    }
    selectedDebugItem = itemObj;
    await updateDebugItemInfo();
  });

  document.getElementById('debug-add-item-btn')?.addEventListener('click', async () => {
    if (!selectedDebugItem) {
      alert('Por favor selecciona un objeto primero');
      return;
    }
    const qty = Number(document.getElementById('debug-item-quantity')?.value) || 1;
    await debugAddItem(selectedDebugItem.id, qty);
  });

  document.getElementById('debug-remove-item-btn')?.addEventListener('click', async () => {
    if (!selectedDebugItem) {
      alert('Por favor selecciona un objeto primero');
      return;
    }
    const qty = Number(document.getElementById('debug-item-quantity')?.value) || 1;
    await debugRemoveItem(selectedDebugItem.id, qty);
  });

  document.getElementById('debug-add-all-items')?.addEventListener('click', debugAddAllItems);
  document.getElementById('debug-clear-all-items')?.addEventListener('click', debugClearAllItems);
}

window.initDebugItems = initDebugItems;
window.debugAddItem = debugAddItem;
window.debugRemoveItem = debugRemoveItem;
window.debugAddAllItems = debugAddAllItems;
window.debugClearAllItems = debugClearAllItems;


