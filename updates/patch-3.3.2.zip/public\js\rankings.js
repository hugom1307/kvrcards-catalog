function filterCardSelector(searchText) {
  const selectorGrid = document.getElementById('card-selector-grid');
  if (!selectorGrid) return;
  
  const items = selectorGrid.querySelectorAll('.card-selector-item');
  const search = searchText.toLowerCase();
  
  items.forEach(item => {
    const card = item._cardData;
    
    if (card) {
      const matchesName = card.name?.toLowerCase().includes(search);
      const matchesClub = card.club?.toLowerCase().includes(search);
      const matchesQuality = card.quality?.toLowerCase().includes(search);
      
      if (matchesName || matchesClub || matchesQuality || !search) {
        item.style.display = '';
      } else {
        item.style.display = 'none';
      }
    }
  });
}

// ==================== RANKINGS ====================
let currentRankingPeriod = 'historical'; // 'historical' o 'seasonal' (para infinito)
let currentRankingCategory = 'cards'; // 'cards', 'packs', 'coins', 'infinite'

const INFINITE_RANKINGS_FALLBACK_URL = 'https://kvrcards-server.onrender.com/api/infinite/rankings';

function getCurrentRankingsUsername() {
  try {
    if (typeof currentUser === 'string' && currentUser.trim()) return currentUser.trim();
  } catch {}

  try {
    const savedUsername = localStorage.getItem('kvrUsername') || localStorage.getItem('userId') || '';
    if (savedUsername.trim()) return savedUsername.trim();
  } catch {}

  return '';
}

async function resolveCurrentUsernameForInfiniteRankings() {
  try {
    if (window.kvrcards && typeof window.kvrcards.getProfile === 'function') {
      const profileResult = await window.kvrcards.getProfile();
      const profileUsername = String(profileResult?.profile?.username || '').trim();
      if (profileUsername) return profileUsername;
    }
  } catch (error) {
    console.warn('[RANKINGS] No se pudo resolver el usuario desde el perfil:', error);
  }

  return getCurrentRankingsUsername();
}

async function fetchInfiniteRankingsOverviewWithFallback(limit = 5) {
  const safeLimit = Math.min(50, Math.max(1, Number(limit) || 5));
  const username = await resolveCurrentUsernameForInfiniteRankings();
  console.log('[RANKINGS] Buscando rankings infinito con limit:', safeLimit, 'usuario:', username);

  try {
    if (window.kvrcards && typeof window.kvrcards.getInfiniteRankingsOverview === 'function') {
      const bridgeResult = await window.kvrcards.getInfiniteRankingsOverview(safeLimit);
      if (bridgeResult && bridgeResult.ok) {
        console.log('[RANKINGS] Bridge exitoso');
        return bridgeResult;
      }
    }
  } catch (error) {
    console.warn('[RANKINGS] Bridge falló, intentando fallback:', error?.message);
  }

  // Fallback directo a API remota
  try {
    const url = new URL(INFINITE_RANKINGS_FALLBACK_URL);
    url.searchParams.set('limit', String(safeLimit));
    if (username) url.searchParams.set('username', username);
    url.searchParams.set('t', String(Date.now()));

    console.log('[RANKINGS] Fallback fetch a:', url.toString());
    const response = await fetch(url.toString(), { cache: 'no-store' });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    console.log('[RANKINGS] Fallback respuesta:', data);
    
    if (data && data.ok) {
      return data;
    }
    
    return { 
      ok: false, 
      error: data?.error || 'Respuesta inválida del servidor' 
    };
  } catch (error) {
    console.warn('[RANKINGS] Fallback falló:', error?.message);
    return { 
      ok: false, 
      error: `Fallback falló: ${error?.message || 'Error desconocido'}`
    };
  }
}

function updateRankingsPeriodLabels() {
  const tabsContainer = document.querySelector('.rankings-tabs');
  const seasonalTab = document.querySelector('.rankings-tab[data-period="seasonal"]') || document.querySelector('.rankings-tab[data-period="weekly"]');
  const historicalTab = document.querySelector('.rankings-tab[data-period="historical"]');
  const histBadge = document.getElementById('rankings-historical-badge');

  if (currentRankingCategory === 'infinite') {
    if (tabsContainer) tabsContainer.style.display = 'flex';
    if (histBadge) histBadge.style.display = 'none';
    if (seasonalTab) {
      seasonalTab.setAttribute('data-period', 'seasonal');
      seasonalTab.innerHTML = '<img src="./infinite-cardpoint.png" style="width:16px;height:16px;vertical-align:middle;margin-right:6px;"> Temporada';
      seasonalTab.classList.toggle('active', currentRankingPeriod === 'seasonal' || currentRankingPeriod === 'weekly');
    }
    if (historicalTab) {
      historicalTab.textContent = 'Histórico';
      historicalTab.classList.toggle('active', currentRankingPeriod === 'historical');
    }
  } else {
    if (tabsContainer) tabsContainer.style.display = 'none';
    if (histBadge) histBadge.style.display = 'flex';
    currentRankingPeriod = 'historical';
  }
}

function renderInfiniteRankings(result) {
  const listEl = document.getElementById('rankings-list');
  if (!listEl) return;

  const isEntryAdmin = (entry) => {
    if (!entry) return false;
    if (entry.isAdmin === true || entry.role === 'admin') return true;
    if (window.currentUserIsAdmin) {
      const u = String(entry.username || '').trim().toLowerCase();
      const current = String(currentUser || window.currentUser || localStorage.getItem('kvrUsername') || '').trim().toLowerCase();
      if (u && current && u === current) return true;
    }
    return false;
  };

  const topSeasonal = (Array.isArray(result?.topSeasonal) ? result.topSeasonal : []).filter(e => !isEntryAdmin(e));
  const topHistorical = (Array.isArray(result?.topHistorical) ? result.topHistorical : []).filter(e => !isEntryAdmin(e));
  const season = result?.season && typeof result.season === 'object' ? result.season : {};
  const seasonName = String(season.name || '').trim();
  const isHistoricalView = currentRankingPeriod === 'historical';
  const activeTop = isHistoricalView ? topHistorical : topSeasonal;

  if (!activeTop || activeTop.length === 0) {
    listEl.innerHTML = `
      <div class="rankings-empty">
        <div class="rankings-empty-icon">🏆</div>
        <div class="rankings-empty-text">No hay datos disponibles</div>
        <div class="rankings-empty-subtext">Sé el primero en escalar este ranking</div>
      </div>
    `;
    return;
  }

  const categoryLabel = isHistoricalView ? 'Récord Histórico' : 'Puntuación de Temporada';

  const html = activeTop.map((entry, idx) => {
    const position = Math.max(1, Number(entry?.rank) || (idx + 1));
    const value = (Number(entry?.score) || Number(entry?.seasonalScore) || Number(entry?.historicalScore) || 0).toLocaleString();
    const username = String(entry?.username || 'Jugador');

    let badgeHtml = `<span class="ranking-num-plain">${position}</span>`;
    let posClass = 'rank-regular';
    if (position === 1) {
      posClass = 'rank-gold';
      badgeHtml = `<span class="rank-trophy">👑</span><span class="rank-pos-num">1</span>`;
    } else if (position === 2) {
      posClass = 'rank-silver';
      badgeHtml = `<span class="rank-trophy">🥈</span><span class="rank-pos-num">2</span>`;
    } else if (position === 3) {
      posClass = 'rank-bronze';
      badgeHtml = `<span class="rank-trophy">🥉</span><span class="rank-pos-num">3</span>`;
    }

    return `
      <div class="ranking-item ${posClass} position-${position}" data-username="${username.replace(/"/g, '&quot;')}">
        <div class="ranking-position-badge">${badgeHtml}</div>
        <div class="ranking-user-info">
          <div class="ranking-username">${username}</div>
          <div class="ranking-stat-label">${categoryLabel}</div>
        </div>
        <div class="ranking-stat-box">
          <img src="./infinite-cardpoint.png" class="ranking-icon" alt="Puntos">
          <span class="ranking-stat-value">${value}</span>
        </div>
      </div>
    `;
  }).join('');

  const headerHtml = (seasonName && !isHistoricalView)
    ? `<div class="rankings-season-header"><span class="season-badge">TEMPORADA ACTIVA</span> ${seasonName}</div>`
    : '';

  listEl.innerHTML = headerHtml + html;

  listEl.querySelectorAll('.ranking-item').forEach(item => {
    item.addEventListener('click', () => {
      const u = item.dataset.username;
      if (u) openUserProfile(u);
    });
  });
}

// Cargar y mostrar rankings
async function loadRankings() {
  const listEl = document.getElementById('rankings-list');
  if (!listEl) return;

  console.log(`[RANKINGS] Cargando ${currentRankingPeriod} - ${currentRankingCategory}`);
  listEl.innerHTML = `
    <div class="rankings-loading-box">
      <div class="rankings-spinner"></div>
      <div class="rankings-loading-text">Cargando clasificación...</div>
    </div>
  `;
  
  try {
    let result;
    if (currentRankingCategory === 'infinite') {
      result = await fetchInfiniteRankingsOverviewWithFallback(50);
      if (!result || !result.ok) {
        throw new Error(result?.error || 'Error al cargar rankings de infinito');
      }
      renderInfiniteRankings(result);
      return;
    } else {
      // Historical only for cards, packs, coins
      result = await window.kvrcards.getHistoricalRankings(currentRankingCategory);
    }
    
    if (!result || !result.ok) {
      throw new Error('Error al cargar rankings');
    }
    
    const rankings = result.rankings || [];
    renderRankings(rankings);
  } catch (error) {
    console.error('[RANKINGS] Error:', error);
    listEl.innerHTML = `
      <div class="rankings-empty">
        <div class="rankings-empty-icon">⚠️</div>
        <div class="rankings-empty-text">Error al cargar la clasificación</div>
        <div class="rankings-empty-subtext">Inténtalo de nuevo más tarde</div>
      </div>
    `;
  }
}

// Renderizar lista de rankings
function renderRankings(rankings) {
  const listEl = document.getElementById('rankings-list');
  if (!listEl) return;
  if (currentRankingCategory === 'infinite') return;

  const isUserAdminEntry = (user) => {
    if (!user) return false;
    if (user.isAdmin === true || user.role === 'admin') return true;
    if (window.currentUserIsAdmin) {
      const u = String(user.username || '').trim().toLowerCase();
      const current = String(currentUser || window.currentUser || localStorage.getItem('kvrUsername') || '').trim().toLowerCase();
      if (u && current && u === current) return true;
    }
    return false;
  };

  const filteredRankings = (Array.isArray(rankings) ? rankings : []).filter(u => !isUserAdminEntry(u));

  if (!filteredRankings || filteredRankings.length === 0) {
    listEl.innerHTML = `
      <div class="rankings-empty">
        <div class="rankings-empty-icon">🏆</div>
        <div class="rankings-empty-text">No hay datos disponibles</div>
        <div class="rankings-empty-subtext">Sé el primero en aparecer en la tabla de honor</div>
      </div>
    `;
    return;
  }
  
  let categoryLabel = 'en total';
  let categoryIcon = './icon-oro.png';
  if (currentRankingCategory === 'cards') {
    categoryLabel = 'cartas totales';
    categoryIcon = './icon-oro.png';
  } else if (currentRankingCategory === 'packs') {
    categoryLabel = 'sobres abiertos';
    categoryIcon = './sobre_oro.png';
  } else if (currentRankingCategory === 'coins') {
    categoryLabel = 'monedas totales';
    categoryIcon = './coin.png';
  }
  
  const html = filteredRankings.map((user, index) => {
    const position = index + 1;
    const username = String(user.username || 'Jugador');
    const value = (Number(user.value) || 0).toLocaleString();

    let badgeHtml = `<span class="ranking-num-plain">${position}</span>`;
    let posClass = 'rank-regular';
    if (position === 1) {
      posClass = 'rank-gold';
      badgeHtml = `<span class="rank-trophy">👑</span><span class="rank-pos-num">1</span>`;
    } else if (position === 2) {
      posClass = 'rank-silver';
      badgeHtml = `<span class="rank-trophy">🥈</span><span class="rank-pos-num">2</span>`;
    } else if (position === 3) {
      posClass = 'rank-bronze';
      badgeHtml = `<span class="rank-trophy">🥉</span><span class="rank-pos-num">3</span>`;
    }
    
    return `
      <div class="ranking-item ${posClass} position-${position}" data-username="${username.replace(/"/g, '&quot;')}">
        <div class="ranking-position-badge">${badgeHtml}</div>
        <div class="ranking-user-info">
          <div class="ranking-username">${username}</div>
          <div class="ranking-stat-label">${categoryLabel}</div>
        </div>
        <div class="ranking-stat-box">
          <img src="${categoryIcon}" class="ranking-icon" alt="Icono">
          <span class="ranking-stat-value">${value}</span>
        </div>
      </div>
    `;
  }).join('');
  
  listEl.innerHTML = html;
  
  // Añadir event listeners para abrir perfiles
  listEl.querySelectorAll('.ranking-item').forEach(item => {
    item.addEventListener('click', () => {
      const username = item.dataset.username;
      console.log('[RANKINGS] Click en perfil:', username);
      if (username) openUserProfile(username);
    });
  });
}

// Calcular tiempo hasta el próximo lunes 00:00
function calculateTimeToNextMonday() {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0 = Domingo, 1 = Lunes, etc.
  
  // Calcular próximo lunes
  let daysUntilMonday = (8 - dayOfWeek) % 7;
  if (daysUntilMonday === 0 && (now.getHours() > 0 || now.getMinutes() > 0 || now.getSeconds() > 0)) {
    daysUntilMonday = 7; // Si es lunes pero ya pasó la medianoche, ir al próximo
  }
  
  const nextMonday = new Date(now);
  nextMonday.setDate(now.getDate() + daysUntilMonday);
  nextMonday.setHours(0, 0, 0, 0);
  
  const diff = nextMonday - now;
  
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  
  return { days, hours, minutes, totalMs: diff };
}

// Actualizar contador de reinicio
let resetTimerInterval = null;

function updateResetTimer() {
  const { days, hours, minutes } = calculateTimeToNextMonday();
  
  let text = '';
  if (days > 0) {
    text = `${days}d ${hours}h ${minutes}m`;
  } else if (hours > 0) {
    text = `${hours}h ${minutes}m`;
  } else {
    text = `${minutes}m`;
  }
  
  // Actualizar contador del modal de rankings
  if (resetCountdown) {
    resetCountdown.textContent = text;
  }
}

function startResetTimer() {
  if (resetTimerInterval) clearInterval(resetTimerInterval);
  updateResetTimer();
  resetTimerInterval = setInterval(updateResetTimer, 60000); // Actualizar cada minuto
}

function stopResetTimer() {
  if (resetTimerInterval) {
    clearInterval(resetTimerInterval);
    resetTimerInterval = null;
  }
}

// Abrir perfil de usuario
async function openUserProfile(username) {
  console.log('[PROFILE] Abriendo perfil de:', username);
  
  const modal = document.getElementById('user-profile-modal');
  if (!modal) {
    console.error('[PROFILE] Modal user-profile-modal no encontrado');
    return;
  }

  try {
    let profile = null;
    if (window.kvrcards && typeof window.kvrcards.getUserProfileData === 'function') {
      const result = await window.kvrcards.getUserProfileData(username);
      if (result && result.ok && result.profile) {
        profile = result.profile;
      }
    }
    
    // Fallback remoto si kvrcards falló o estamos en navegador web
    if (!profile) {
      try {
        const res = await fetch(`https://kvrcards-server.onrender.com/api/inventory/${encodeURIComponent(username)}`);
        if (res.ok) {
          const userData = await res.json();
          if (userData) {
            let uniqueCards = 0;
            if (userData.cards) {
              uniqueCards = Object.values(userData.cards).filter(count => count > 0).length;
            }
            profile = {
              username,
              profileImage: userData.profileImage || '',
              currentTitle: userData.currentTitle || '',
              description: userData.description || '',
              unlockedTitles: Array.isArray(userData.unlockedTitles) ? userData.unlockedTitles : ['novato'],
              currentBackground: userData.currentBackground || userData.settings?.currentBackground || 'default',
              unlockedBackgrounds: (Array.isArray(userData.unlockedBackgrounds) && userData.unlockedBackgrounds.length > 0)
                ? userData.unlockedBackgrounds
                : (Array.isArray(userData.settings?.unlockedBackgrounds) ? userData.settings.unlockedBackgrounds : ['default']),
              stats: {
                totalCardsObtained: (userData.stats?.totalCardsObtained || 0),
                totalPacksOpened: (userData.stats?.totalPacksOpened || 0),
                totalCoinsEarned: (userData.stats?.totalCoinsEarned || 0),
                uniqueCards
              },
              weeklyStats: {
                cards: (userData.weeklyStats?.cards || 0),
                packs: (userData.weeklyStats?.packs || 0),
                coins: (userData.weeklyStats?.coins || 0)
              },
              showcaseCards: userData.showcaseCards || []
            };
          }
        }
      } catch (errFallback) {
        console.warn('[PROFILE] Error en fallback de perfil:', errFallback);
      }
    }

    if (!profile) {
      throw new Error('Error al cargar perfil');
    }
    
    // Actualizar datos del modal
    document.getElementById('profile-modal-username').textContent = profile.username;
    
    // Imagen de perfil
    const avatar = document.getElementById('profile-modal-avatar');
    const placeholder = document.getElementById('profile-modal-avatar-placeholder');
    if (profile.profileImage) {
      avatar.src = profile.profileImage;
      avatar.style.display = 'block';
      placeholder.style.display = 'none';
    } else {
      avatar.style.display = 'none';
      placeholder.style.display = 'flex';
    }
    
    // Título actual
    const titleEl = document.getElementById('profile-modal-title');
    if (profile.currentTitle) {
      titleEl.textContent = `"${profile.currentTitle}"`;
      titleEl.style.display = 'block';
      if (typeof window.applyTitleStyle === 'function') {
        window.applyTitleStyle(titleEl, profile.currentTitle);
      }
    } else {
      titleEl.style.display = 'none';
    }

    // Descripción
    const descEl = document.getElementById('profile-modal-description');
    if (descEl) {
      const rawDesc = (profile.description || '').trim();
      if (rawDesc && rawDesc !== 'Sin descripción') {
        descEl.textContent = `"${rawDesc}"`;
        descEl.style.display = 'block';
      } else {
        descEl.textContent = '';
        descEl.style.display = 'none';
      }
    }
    
    // Estadísticas
    document.getElementById('profile-stat-cards').textContent = (profile.stats?.totalCardsObtained || 0).toLocaleString();
    document.getElementById('profile-stat-packs').textContent = (profile.stats?.totalPacksOpened || 0).toLocaleString();
    document.getElementById('profile-stat-coins').textContent = (profile.stats?.totalCoinsEarned || 0).toLocaleString();
    document.getElementById('profile-stat-unique').textContent = (profile.stats?.uniqueCards || 0).toLocaleString();
    
    // Stats semanales
    document.getElementById('profile-weekly-cards').textContent = (profile.weeklyStats?.cards || 0).toLocaleString();
    document.getElementById('profile-weekly-packs').textContent = (profile.weeklyStats?.packs || 0).toLocaleString();
    document.getElementById('profile-weekly-coins').textContent = (profile.weeklyStats?.coins || 0).toLocaleString();
    
    // Showcase de cartas (las 3 cartas destacadas del usuario)
    const showcaseGrid = document.getElementById('profile-showcase-grid');
    if (profile.showcaseCards && profile.showcaseCards.length > 0) {
      showcaseGrid.innerHTML = '';
      
      for (let i = 0; i < 3; i++) {
        const card = profile.showcaseCards[i];
        
        if (card && (card.id || card.image)) {
          const cardDiv = document.createElement('div');
          cardDiv.className = 'profile-showcase-card';
          
          const img = document.createElement('img');
          img.src = card.image || '';
          img.alt = card.name || 'Carta';
          img.loading = 'lazy';
          img.onerror = function() {
            this.style.display = 'none';
          };
          
          const nameDiv = document.createElement('div');
          nameDiv.className = 'profile-showcase-card-name';
          nameDiv.textContent = card.name || 'Sin nombre';
          
          const countDiv = document.createElement('div');
          countDiv.className = 'profile-showcase-card-count';
          countDiv.textContent = `x${card.count || 0}`;
          
          cardDiv.appendChild(img);
          cardDiv.appendChild(nameDiv);
          cardDiv.appendChild(countDiv);
          
          showcaseGrid.appendChild(cardDiv);
        } else {
          const emptySlot = document.createElement('div');
          emptySlot.className = 'profile-showcase-empty-slot';
          emptySlot.innerHTML = `
            <div class="profile-showcase-empty-slot-text">Sin carta</div>
          `;
          showcaseGrid.appendChild(emptySlot);
        }
      }
    } else {
      showcaseGrid.innerHTML = `
        <div class="profile-showcase-empty">
          <div>Este usuario aún no ha configurado sus cartas destacadas</div>
        </div>
      `;
    }
    
    // Cargar catálogo de fondos si no está cargado aún
    if (typeof window.loadBackgrounds === 'function' && (!window.availableBackgrounds || window.availableBackgrounds.length <= 1)) {
      await window.loadBackgrounds().catch(() => {});
    }

    // Aplicar fondo de perfil personalizado en el backdrop (a izquierda y derecha del recuadro azul)
    const bgToApply = profile.currentBackground || 'default';
    if (typeof window.applyProfileBackground === 'function') {
      console.log('[PROFILE] Aplicando fondo de perfil de amigo en el backdrop:', bgToApply, 'para usuario:', username);
      window.applyProfileBackground(modal, bgToApply);
    }

    // Aplicar color personalizado del recuadro si el fondo lo define, o mantener su color original
    const userProfileModalContent = modal.querySelector('.user-profile-content');
    if (userProfileModalContent) {
      userProfileModalContent.classList.remove('has-custom-bg');
      if (typeof window.applyProfileBoxStyle === 'function') {
        window.applyProfileBoxStyle(userProfileModalContent, bgToApply);
      } else {
        userProfileModalContent.style.removeProperty('background');
        userProfileModalContent.style.removeProperty('border-color');
        userProfileModalContent.style.removeProperty('box-shadow');
      }
    }
    
    // Mostrar modal
    modal.classList.add('show');
    
  } catch (error) {
    console.error('[PROFILE] Error al cargar perfil:', error);
    alert('Error al cargar el perfil del usuario');
  }
}
window.openUserProfile = openUserProfile;

// Cerrar perfil de usuario
function closeUserProfile() {
  const modal = document.getElementById('user-profile-modal');
  if (modal) {
    modal.classList.remove('show');
    modal.classList.remove('has-custom-bg');
    modal.classList.remove('has-custom-border');
    modal.style.backgroundImage = '';
    const userProfileModalContent = modal.querySelector('.user-profile-content');
    if (userProfileModalContent) {
      userProfileModalContent.classList.remove('has-custom-bg');
      userProfileModalContent.classList.remove('has-custom-border');
      userProfileModalContent.style.backgroundImage = '';
      if (typeof window.applyProfileBoxStyle === 'function') {
        window.applyProfileBoxStyle(userProfileModalContent, 'default');
      }
    }
  }
}
window.closeUserProfile = closeUserProfile;

// Abrir modal de rankings
function openRankingsModal() {
  const modal = document.getElementById('rankings-modal');
  if (modal) modal.classList.add('show');
  updateRankingsPeriodLabels();
  loadRankings();
}

// Cerrar modal de rankings
function closeRankingsModal() {
  const modal = document.getElementById('rankings-modal');
  if (modal) modal.classList.remove('show');
}

// Cambiar período (semanal/histórico/temporada)
function switchRankingPeriod(period) {
  if (currentRankingCategory === 'infinite') {
    currentRankingPeriod = (period === 'seasonal' || period === 'weekly') ? 'seasonal' : 'historical';
  } else {
    currentRankingPeriod = 'historical';
  }
  updateRankingsPeriodLabels();
  loadRankings();
}

// Cambiar categoría (cards/packs/coins/infinite)
function switchRankingCategory(category) {
  currentRankingCategory = category;
  if (category === 'infinite') {
    currentRankingPeriod = 'seasonal';
  } else {
    currentRankingPeriod = 'historical';
  }
  updateRankingsPeriodLabels();
  
  // Actualizar UI de categorías
  document.querySelectorAll('.rankings-category').forEach(btn => {
    if (btn.dataset.category === category) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });
  
  loadRankings();
}

window.loadRankings = loadRankings;
window.openRankingsModal = openRankingsModal;
window.closeRankingsModal = closeRankingsModal;
window.switchRankingCategory = switchRankingCategory;
window.switchRankingPeriod = switchRankingPeriod;

