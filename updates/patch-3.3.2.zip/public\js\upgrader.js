/**
 * ==================== UPGRADER "MEJORÁMELA" GAME SYSTEM ====================
 * Modern Esports / Casino HUD & Target Media Range Upgrader System.
 * Allows players to sacrifice up to 5 cards from their inventory to win
 * a card within a chosen media interval (e.g. 88 - 90).
 */

(function () {
  // Target Media Ranges (max span of 2 or 3 ratings)
  const TARGET_RANGES = [
    { min: 95, max: 96, label: "95 - 96", tier: "Mítico" },
    { min: 93, max: 94, label: "93 - 94", tier: "Supremo" },
    { min: 91, max: 92, label: "91 - 92", tier: "Leyenda" },
    { min: 88, max: 90, label: "88 - 90", tier: "Élite" },
    { min: 86, max: 87, label: "86 - 87", tier: "Estrella" },
    { min: 84, max: 85, label: "84 - 85", tier: "Avanzado" },
    { min: 81, max: 83, label: "81 - 83", tier: "Veterano" },
    { min: 78, max: 80, label: "78 - 80", tier: "Promesa" },
    { min: 75, max: 77, label: "75 - 77", tier: "Titular" },
    { min: 72, max: 74, label: "72 - 74", tier: "Base" }
  ];

  // Maximum allowed rating difference below the minimum of the range
  const MAX_GAP_DOWN = 6;

  // Allowed reward qualities strictly restricted
  const UPGRADER_ALLOWED_QUALITIES = new Set(['cota', 'oro', 'icono', 'iconoprime', 'iconosuperprime']);

  // State
  let selectedSacrifices = [];
  let selectedTargetRange = TARGET_RANGES[3]; // Default to 88 - 90
  
  // Selector modal state
  let tempSelectedSacrifices = [];
  let activeFilteredList = [];
  let itemsRendered = 24;
  
  let userInventory = null;
  let allCardsCatalog = [];
  let cardMap = new Map();
  let availableTraits = [];
  let cardTraitsMap = {};
  let cardUpgradesMap = {};
  
  // Animation state
  let spinAnimationId = null;
  let currentWheelAngle = 0;
  
  // DOM element caches
  let modalEl = null;
  let selectorModalEl = null;
  let canvasEl = null;
  let ctx = null;

  // Base64 SVGs to prevent browser inline data URI crashes
  const FALLBACK_100x140_BASE64 = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAiIGhlaWdodD0iMTQwIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjMWYyOTM3Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGRvbWluYW50LWJhc2VsaW5lPSJtaWRkbGUiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZpbGw9IiM5Y2EzYWYiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxMCI+S1ZSIENhcmQ8L3RleHQ+PC9zdmc+";
  const FALLBACK_60x84_BASE64 = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MCIgaGVpZ2h0PSI4NCI+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0iIzExMSIvPjwvc3ZnPg==";

  function getCardImageUrl(card, isMicro = false) {
    if (card) {
      const url = card.imageUrl || card.imagen || card.imagen_url || card.image || "";
      if (url) return url;
    }
    return isMicro ? FALLBACK_60x84_BASE64 : FALLBACK_100x140_BASE64;
  }

  function getMinAllowedRating() {
    return (selectedTargetRange ? selectedTargetRange.min : 88) - MAX_GAP_DOWN;
  }

  // ==================== WEB AUDIO SYNTHESIS ENGINE ====================
  let audioCtx = null;
  
  function getAudioContext() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  }

  function playSynthTickSound() {
    try {
      const aCtx = getAudioContext();
      if (!aCtx || aCtx.state === 'suspended') return;
      
      const osc = aCtx.createOscillator();
      const gain = aCtx.createGain();
      
      osc.connect(gain);
      gain.connect(aCtx.destination);
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(160, aCtx.currentTime);
      
      gain.gain.setValueAtTime(0.06, aCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, aCtx.currentTime + 0.04);
      
      osc.start(aCtx.currentTime);
      osc.stop(aCtx.currentTime + 0.04);
    } catch (e) {}
  }

  function playSynthSuccessSound() {
    try {
      const aCtx = getAudioContext();
      if (!aCtx || aCtx.state === 'suspended') return;
      
      const now = aCtx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
      const noteDuration = 0.1;
      
      notes.forEach((freq, index) => {
        const osc = aCtx.createOscillator();
        const gain = aCtx.createGain();
        
        osc.connect(gain);
        gain.connect(aCtx.destination);
        
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + index * noteDuration);
        
        const noteStart = now + index * noteDuration;
        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.14, noteStart + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDuration + 0.08);
        
        osc.start(noteStart);
        osc.stop(noteStart + noteDuration + 0.08);
      });
    } catch (e) {}
  }

  function playSynthFailureSound() {
    try {
      const aCtx = getAudioContext();
      if (!aCtx || aCtx.state === 'suspended') return;
      
      const now = aCtx.currentTime;
      const osc = aCtx.createOscillator();
      const gain = aCtx.createGain();
      const filter = aCtx.createBiquadFilter();
      
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(aCtx.destination);
      
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(260, now);
      osc.frequency.exponentialRampToValueAtTime(70, now + 0.45);
      
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(600, now);
      filter.frequency.exponentialRampToValueAtTime(100, now + 0.45);
      
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
      
      osc.start(now);
      osc.stop(now + 0.45);
    } catch (e) {}
  }

  // Fetch inventory from server or local process
  async function fetchServerInventory() {
    // Si estamos en Electron, leer prioritariamente el inventario local directo
    if (window.kvrcards && typeof window.kvrcards.getInventory === 'function') {
      try {
        const localInv = await window.kvrcards.getInventory();
        if (localInv && localInv.ok) {
          if (!currentUser && localInv.username) {
            currentUser = localInv.username;
          }
          return {
            ok: true,
            cards: localInv.cards || {},
            packs: localInv.packs || {},
            cardTraits: localInv.cardTraits || {},
            cardUpgrades: localInv.cardUpgrades || {},
            wallet: localInv.wallet || { coins: 0, kvr: 0 }
          };
        }
      } catch (ipcErr) {
        console.warn("[UPGRADER] Error al leer inventario local directo:", ipcErr);
      }
    }

    let baseUrl = "";
    if (window.kvrcards && typeof window.kvrcards.getInventoryServerInfo === 'function') {
      try {
        const info = await window.kvrcards.getInventoryServerInfo();
        if (info && info.ok && info.effectiveBaseUrl) {
          baseUrl = info.effectiveBaseUrl.endsWith('/') ? info.effectiveBaseUrl.slice(0, -1) : info.effectiveBaseUrl;
        }
      } catch (e) {
        baseUrl = "https://kvrcards-server.onrender.com";
      }
    } else {
      baseUrl = "https://kvrcards-server.onrender.com";
    }
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 1200);
      const response = await fetch(`${baseUrl}/api/inventory/${currentUser}`, { signal: controller.signal });
      clearTimeout(timeoutId);
      if (response.ok) {
        const data = await response.json();
        return {
          ok: true,
          cards: data.cards || {},
          packs: data.packs || {},
          cardTraits: data.cardTraits || {},
          cardUpgrades: data.cardUpgrades || {},
          wallet: data.wallet || { coins: 0, kvr: 0 }
        };
      }
    } catch (err) {
      console.warn("[UPGRADER] Servidor remoto no accesible, usando fallback local:", err.message);
    }
    
    if (window.currentUserData) {
      return {
        ok: true,
        cards: window.currentUserData.cards || {},
        packs: window.currentUserData.packs || {},
        cardTraits: window.currentUserData.cardTraits || {},
        cardUpgrades: window.currentUserData.cardUpgrades || {},
        wallet: window.currentUserData.wallet || { coins: 0, kvr: 0 }
      };
    }
    
    return { ok: true, cards: {}, packs: {}, cardTraits: {}, cardUpgrades: {}, wallet: { coins: 0, kvr: 0 } };
  }

  // ==================== MODAL LIFECYCLE ====================

  window.openUpgraderModal = async function () {
    if (!currentUser) {
      alert("Debes iniciar sesión para poder usar Mejorámela.");
      return;
    }
    
    getAudioContext();
    
    modalEl = document.getElementById("gambling-upgrader-modal");
    selectorModalEl = document.getElementById("upgrader-selector-modal");
    canvasEl = document.getElementById("upgrader-roulette-canvas");
    if (canvasEl) {
      ctx = canvasEl.getContext("2d");
    }
    
    // Bind lazy scrolling on selector grid
    const grid = document.getElementById("upgrader-selector-grid");
    if (grid && !grid.dataset.scrollListenerSet) {
      grid.dataset.scrollListenerSet = "true";
      grid.addEventListener("scroll", () => {
        if (grid.scrollTop + grid.clientHeight >= grid.scrollHeight - 140) {
          if (itemsRendered < activeFilteredList.length) {
            const nextStart = itemsRendered;
            itemsRendered += 24;
            const nextSlice = activeFilteredList.slice(nextStart, itemsRendered);
            nextSlice.forEach(item => {
              const el = createCardDOMElement(item);
              if (el) grid.appendChild(el);
            });
          }
        }
      });
    }
    
    // Reset state
    selectedSacrifices = [];
    currentWheelAngle = 0;
    
    // Hide standard gambling panel for deep immersion
    const gamblingPanel = document.getElementById("gambling-panel");
    if (gamblingPanel) gamblingPanel.style.display = "none";
    
    // Show Modal
    if (modalEl) {
      modalEl.classList.add("active");
      const existingOverlays = modalEl.querySelectorAll('.upgrader-overlay, .flash-burst');
      existingOverlays.forEach(el => el.remove());
    }
    
    try {
      const [allCards, inv] = await Promise.all([
        window.kvrcards && typeof window.kvrcards.getAllCards === 'function' ? window.kvrcards.getAllCards() : [],
        fetchServerInventory()
      ]);
      
      let normalizedCards = [];
      if (Array.isArray(allCards)) {
        normalizedCards = allCards;
      } else if (allCards && allCards.ok && Array.isArray(allCards.cards)) {
        normalizedCards = allCards.cards;
      } else if (allCards && Array.isArray(allCards.data)) {
        normalizedCards = allCards.data;
      }
      allCardsCatalog = normalizedCards;
      cardMap = new Map(allCardsCatalog.map(c => [c.id, c]));
      userInventory = inv;
      
      cardTraitsMap = inv.cardTraits || {};
      cardUpgradesMap = inv.cardUpgrades || {};
      
      if (window.kvrcards && typeof window.kvrcards.getAllTraits === 'function') {
        availableTraits = await window.kvrcards.getAllTraits().catch(() => []);
      }
      
      // Render Initial State
      renderTargetRangeSelector();
      renderSelectedSacrificesThumbnails();
      updateUpgraderProbabilities();

      if (window.DiscordPresence) {
        window.DiscordPresence.setGambling('Mejoramela');
      }
      
    } catch (err) {
      console.error("[UPGRADER] Error al abrir el modal:", err);
      alert("Error al cargar los datos del Upgrader.");
      closeUpgraderModal();
    }
  };

  window.closeUpgraderModal = function () {
    if (spinAnimationId) {
      cancelAnimationFrame(spinAnimationId);
      spinAnimationId = null;
    }
    
    if (modalEl) {
      modalEl.classList.remove("active");
    }
    
    closeInventorySelector();
    
    const gamblingPanel = document.getElementById("gambling-panel");
    if (gamblingPanel) gamblingPanel.style.display = "flex";

    if (window.DiscordPresence) {
      window.DiscordPresence.setGambling('Seleccion de Juego');
    }
  };

  // Helper para resolver con precisión el cardId base de una carta o instancia
  function resolveBaseCardId(idOrInstanceId) {
    if (!idOrInstanceId) return '';
    if (cardTraitsMap[idOrInstanceId] && cardTraitsMap[idOrInstanceId].cardId) {
      return cardTraitsMap[idOrInstanceId].cardId;
    }
    if (cardUpgradesMap[idOrInstanceId] && cardUpgradesMap[idOrInstanceId].cardId) {
      return cardUpgradesMap[idOrInstanceId].cardId;
    }
    if (cardMap.has(idOrInstanceId)) {
      return idOrInstanceId;
    }
    if (userInventory && userInventory.cards && userInventory.cards[idOrInstanceId] !== undefined) {
      return idOrInstanceId;
    }
    if (window.currentUserData && window.currentUserData.cards && window.currentUserData.cards[idOrInstanceId] !== undefined) {
      return idOrInstanceId;
    }
    if (typeof idOrInstanceId === 'string' && idOrInstanceId.includes('_')) {
      const parts = idOrInstanceId.split('_');
      for (let i = parts.length - 1; i >= 1; i--) {
        const candidate = parts.slice(0, i).join('_');
        if (cardMap.has(candidate)) return candidate;
        if (userInventory && userInventory.cards && userInventory.cards[candidate] !== undefined) return candidate;
        if (window.currentUserData && window.currentUserData.cards && window.currentUserData.cards[candidate] !== undefined) return candidate;
      }
    }
    return idOrInstanceId;
  }

  // Helper to fetch details of a card including upgrades/traits
  function getCardDetail(instanceIdOrCardId) {
    const cardId = resolveBaseCardId(instanceIdOrCardId);
    let bonus = 0;
    let trait = null;
    
    if (cardTraitsMap[instanceIdOrCardId]) {
      const traitId = cardTraitsMap[instanceIdOrCardId].traitId;
      trait = availableTraits.find(t => t.id === traitId);
    }
    
    if (cardUpgradesMap[instanceIdOrCardId]) {
      bonus = Number(cardUpgradesMap[instanceIdOrCardId].mediaBonus) || 0;
    }
    
    const baseCard = cardMap.get(cardId);
    if (!baseCard) return null;
    
    const media = (Number(baseCard.media) || Number(baseCard.mediaVal) || 75) + bonus;
    const name = baseCard.name || baseCard.nombre || "Carta KVR";
    const imageUrl = baseCard.imageUrl || baseCard.imagen || baseCard.imagen_url || baseCard.image || "";
    const quality = baseCard.quality || baseCard.calidad || "oro";
    
    return {
      ...baseCard,
      id: baseCard.id || cardId,
      instanceId: instanceIdOrCardId,
      name: name,
      imageUrl: imageUrl,
      quality: quality,
      media: media,
      bonus: bonus,
      trait: trait
    };
  }

  // ==================== RIGHT PANEL: TARGET RANGE SELECTOR ====================

  function renderTargetRangeSelector() {
    const container = document.getElementById("upgrader-range-selector-grid");
    if (!container) return;
    
    container.innerHTML = "";
    
    TARGET_RANGES.forEach(range => {
      const card = document.createElement("div");
      card.className = "upgrader-range-card";
      if (selectedTargetRange.min === range.min && selectedTargetRange.max === range.max) {
        card.classList.add("selected");
      }
      
      card.innerHTML = `
        <div class="upgrader-range-val">${range.label}</div>
        <div class="upgrader-range-meta">
          <span class="upgrader-range-tier">${range.tier}</span>
        </div>
      `;
      
      card.addEventListener("click", () => {
        getAudioContext();
        selectedTargetRange = range;
        
        container.querySelectorAll(".upgrader-range-card").forEach(c => c.classList.remove("selected"));
        card.classList.add("selected");
        
        // Retirar automáticamente cartas que no alcancen la media mínima del nuevo rango
        const minAllowed = range.min - MAX_GAP_DOWN;
        const validSacrifices = [];
        let removedCount = 0;
        
        selectedSacrifices.forEach(sacId => {
          const sacDetail = getCardDetail(sacId);
          if (sacDetail && (sacDetail.media || 75) >= minAllowed) {
            validSacrifices.push(sacId);
          } else {
            removedCount++;
          }
        });
        
        if (removedCount > 0) {
          selectedSacrifices = validSacrifices;
          renderSelectedSacrificesThumbnails();
          alert(`Se han deseleccionado ${removedCount} carta(s) por no alcanzar la media mínima permitida (${minAllowed}) para el rango ${range.label}.`);
        }
        
        const targetLabel = document.getElementById("upgrader-target-display-label");
        if (targetLabel) targetLabel.textContent = range.label;
        
        updateUpgraderProbabilities();
      });
      
      container.appendChild(card);
    });
    
    const targetLabel = document.getElementById("upgrader-target-display-label");
    if (targetLabel) targetLabel.textContent = selectedTargetRange.label;
  }

  // ==================== LEFT PANEL: SACRIFICE SLOTS ====================

  function renderSelectedSacrificesThumbnails() {
    const grid = document.getElementById("upgrader-sacrifice-thumbnails");
    if (!grid) return;
    
    grid.innerHTML = "";
    const MAX_SACRIFICES = 5;
    
    for (let slotIndex = 0; slotIndex < MAX_SACRIFICES; slotIndex++) {
      if (slotIndex < selectedSacrifices.length) {
        const sacId = selectedSacrifices[slotIndex];
        const cardDetail = getCardDetail(sacId);
        if (!cardDetail) continue;
        
        const div = document.createElement("div");
        div.className = "upgrader-micro-thumbnail";
        
        div.innerHTML = `
          <div class="upgrader-micro-badge" onclick="removeSingleSacrifice(${slotIndex}, event)">&times;</div>
          <img src="${getCardImageUrl(cardDetail, true)}" onerror="this.onerror=null; this.src='${FALLBACK_60x84_BASE64}';">
          <div class="upgrader-micro-name" title="${cardDetail.name}">${cardDetail.name}</div>
          <div class="upgrader-micro-media">Media: ${cardDetail.media}</div>
        `;
        
        grid.appendChild(div);
      } else {
        const emptyDiv = document.createElement("div");
        emptyDiv.className = "upgrader-empty-slot";
        emptyDiv.innerHTML = `
          <div class="slot-num">+</div>
          <div class="slot-label">Ranura ${slotIndex + 1}</div>
        `;
        emptyDiv.onclick = () => openInventorySelector();
        grid.appendChild(emptyDiv);
      }
    }
    
    const countEl = document.getElementById("upgrader-selected-sac-count");
    if (countEl) {
      countEl.textContent = `${selectedSacrifices.length} / 5`;
    }
  }

  window.removeSingleSacrifice = function (index, event) {
    if (event) event.stopPropagation();
    selectedSacrifices.splice(index, 1);
    renderSelectedSacrificesThumbnails();
    updateUpgraderProbabilities();
  };

  // ==================== LARGE INVENTORY SELECTOR MODAL ====================

  window.openInventorySelector = function () {
    getAudioContext();
    
    const minAllowed = getMinAllowedRating();
    const titleEl = document.getElementById("upgrader-selector-title");
    if (titleEl) {
      titleEl.textContent = `Seleccionar Cartas de Sacrificio (Mín. Media ${minAllowed})`;
    }
    
    const searchInput = document.getElementById("upgrader-selector-search");
    if (searchInput) searchInput.value = "";
    
    tempSelectedSacrifices = [...selectedSacrifices];
    
    if (selectorModalEl) {
      selectorModalEl.style.display = "flex";
      renderSelectorGrid();
    }
  };

  window.closeInventorySelector = function () {
    if (selectorModalEl) {
      selectorModalEl.style.display = "none";
    }
  };

  function getSelectableInventoryList() {
    const counts = userInventory && userInventory.ok ? userInventory.cards : {};
    const entries = Object.entries(counts).filter(([id, count]) => count > 0);
    const list = [];
    
    const traitsByCard = {};
    for (const [instanceId, data] of Object.entries(cardTraitsMap)) {
      if (data && data.cardId) {
        if (!traitsByCard[data.cardId]) traitsByCard[data.cardId] = [];
        traitsByCard[data.cardId].push(instanceId);
      } else if (typeof data === 'string') {
        let cardId = instanceId;
        if (instanceId.includes('_')) {
          const parts = instanceId.split('_');
          if (parts.length >= 3 && !isNaN(parts[parts.length - 1]) && !isNaN(parts[parts.length - 2])) {
            cardId = parts.slice(0, -2).join('_');
          }
        }
        if (!traitsByCard[cardId]) traitsByCard[cardId] = [];
        traitsByCard[cardId].push(instanceId);
      }
    }
    
    const upgradesByCard = {};
    for (const [instanceId, data] of Object.entries(cardUpgradesMap)) {
      if (data && data.cardId) {
        if (!upgradesByCard[data.cardId]) upgradesByCard[data.cardId] = [];
        if (!traitsByCard[data.cardId]?.includes(instanceId)) {
          upgradesByCard[data.cardId].push(instanceId);
        }
      }
    }
    
    entries.forEach(([id, count]) => {
      const baseCard = cardMap.get(id);
      if (!baseCard) return;
      
      const traitsForCard = (traitsByCard[id] || []).slice(0, count);
      const upgradesForCard = upgradesByCard[id] || [];
      
      traitsForCard.forEach(instId => {
        list.push({ instanceId: instId, cardId: id, isInstance: true });
      });
      
      upgradesForCard.forEach(instId => {
        list.push({ instanceId: instId, cardId: id, isInstance: true });
      });
      
      const totalInstances = traitsForCard.length + upgradesForCard.length;
      const standardCount = Math.max(0, count - totalInstances);
      
      if (standardCount > 0) {
        list.push({ instanceId: id, cardId: id, isInstance: false, count: standardCount });
      }
    });
    
    return list;
  }

  function createCardDOMElement(item) {
    const cardDetail = getCardDetail(item.instanceId);
    if (!cardDetail) return null;
    
    const minAllowed = getMinAllowedRating();
    const isBelowMin = (cardDetail.media || 75) < minAllowed;
    
    const div = document.createElement("div");
    div.className = "selector-card-item";
    div.setAttribute("data-instance-id", item.instanceId);
    
    const currentlyChosen = tempSelectedSacrifices.filter(sac => sac === item.instanceId).length;
    const isChosen = currentlyChosen > 0;
    
    if (isChosen) div.classList.add("chosen-in-selector");
    if (isBelowMin) div.classList.add("incompatible-sacrifice");
    
    let indicatorText = "";
    if (isChosen) {
      indicatorText = currentlyChosen > 1 ? `x${currentlyChosen}` : "✓";
    }
    
    let displayCount = "";
    if (!item.isInstance && item.count > 1) {
      const availableCount = Math.max(0, item.count - currentlyChosen);
      displayCount = `<div class="selector-card-count">x${availableCount}</div>`;
    }
    
    let badgesMarkup = "";
    if (cardDetail.bonus > 0) {
      badgesMarkup += `<div class="selector-card-badge">+${cardDetail.bonus}</div>`;
    }
    if (cardDetail.trait) {
      badgesMarkup += `<div class="selector-card-badge-trait">${cardDetail.trait.name.slice(0,5)}</div>`;
    }
    
    div.innerHTML = `
      ${badgesMarkup}
      <div class="selector-check-indicator">${indicatorText}</div>
      <img src="${getCardImageUrl(cardDetail)}" onerror="this.onerror=null; this.src='${FALLBACK_100x140_BASE64}';">
      <div class="selector-card-name" title="${cardDetail.name}">${cardDetail.name}</div>
      <div class="selector-card-media">Media: ${cardDetail.media}</div>
      ${displayCount}
    `;
    
    div.addEventListener("click", () => {
      if (isBelowMin) {
        playSynthFailureSound();
        alert(`Media insuficiente: Esta carta (${cardDetail.name}, Media ${cardDetail.media}) está por debajo de la media mínima permitida (${minAllowed}) para el rango ${selectedTargetRange.label}.`);
        return;
      }
      handleSelectorClick(item.instanceId, item.isInstance, item.count);
    });
    
    return div;
  }

  function updateCardDOMNodeDirectly(instanceId, totalCount, isInstance) {
    const div = document.querySelector(`.selector-card-item[data-instance-id="${instanceId}"]`);
    if (!div) return;
    
    const currentlyChosen = tempSelectedSacrifices.filter(sac => sac === instanceId).length;
    const isChosen = currentlyChosen > 0;
    
    if (isChosen) {
      div.classList.add("chosen-in-selector");
    } else {
      div.classList.remove("chosen-in-selector");
    }
    
    const indicator = div.querySelector(".selector-check-indicator");
    if (indicator) {
      indicator.textContent = isChosen ? (currentlyChosen > 1 ? `x${currentlyChosen}` : "✓") : "";
    }
    
    if (!isInstance && totalCount > 1) {
      const countLabel = div.querySelector(".selector-card-count");
      if (countLabel) {
        const availableCount = Math.max(0, totalCount - currentlyChosen);
        countLabel.textContent = `x${availableCount}`;
      }
    }
    
    const chosenBadge = document.getElementById("upgrader-selector-chosen-count");
    if (chosenBadge) {
      chosenBadge.textContent = `${tempSelectedSacrifices.length} / 5`;
    }
  }

  window.renderSelectorGrid = function () {
    const grid = document.getElementById("upgrader-selector-grid");
    if (!grid) return;
    
    grid.innerHTML = "";
    
    const list = getSelectableInventoryList();
    const query = document.getElementById("upgrader-selector-search")?.value.trim().toLowerCase() || "";
    
    activeFilteredList = list.filter(item => {
      const card = cardMap.get(item.cardId);
      return card && card.name.toLowerCase().includes(query);
    });
    
    // Sort descendingly by Media, then alphabetically by Name
    activeFilteredList.sort((a, b) => {
      const cardA = getCardDetail(a.instanceId);
      const cardB = getCardDetail(b.instanceId);
      const mediaA = cardA ? (cardA.media || 0) : 0;
      const mediaB = cardB ? (cardB.media || 0) : 0;
      if (mediaB !== mediaA) return mediaB - mediaA;
      const nameA = cardA ? (cardA.name || "").toLowerCase() : "";
      const nameB = cardB ? (cardB.name || "").toLowerCase() : "";
      return nameA.localeCompare(nameB);
    });
    
    const availCountEl = document.getElementById("upgrader-selector-avail-count");
    if (availCountEl) availCountEl.textContent = activeFilteredList.length;
    
    const chosenCountEl = document.getElementById("upgrader-selector-chosen-count");
    if (chosenCountEl) chosenCountEl.textContent = `${tempSelectedSacrifices.length} / 5`;
    
    if (activeFilteredList.length === 0) {
      grid.innerHTML = '<div style="grid-column: span 5; text-align: center; color: rgba(255,255,255,0.3); padding: 50px 0; font-size: 13px;">No se encontraron cartas en tu inventario.</div>';
      return;
    }
    
    itemsRendered = 24;
    const visibleSlice = activeFilteredList.slice(0, itemsRendered);
    visibleSlice.forEach(item => {
      const el = createCardDOMElement(item);
      if (el) grid.appendChild(el);
    });
  };

  window.filterSelectorInventory = function () {
    renderSelectorGrid();
  };

  function handleSelectorClick(instanceId, isInstance, totalCount) {
    getAudioContext();
    const minAllowed = getMinAllowedRating();
    const cardDetail = getCardDetail(instanceId);
    
    if (cardDetail && (cardDetail.media || 75) < minAllowed) {
      playSynthFailureSound();
      alert(`Media insuficiente: Esta carta (${cardDetail.name}, Media ${cardDetail.media}) está por debajo del mínimo permitido (${minAllowed}) para el rango ${selectedTargetRange.label}.`);
      return;
    }
    
    const currentlyChosen = tempSelectedSacrifices.filter(sac => sac === instanceId).length;
    
    if (currentlyChosen < totalCount) {
      if (tempSelectedSacrifices.length >= 5) {
        playSynthFailureSound();
        alert("Límite alcanzado: Solo puedes sacrificar hasta un máximo de 5 cartas.");
        return;
      }
      tempSelectedSacrifices.push(instanceId);
    } else {
      tempSelectedSacrifices = tempSelectedSacrifices.filter(sac => sac !== instanceId);
    }
    
    updateCardDOMNodeDirectly(instanceId, totalCount, isInstance);
  }

  window.confirmInventorySelection = function () {
    getAudioContext();
    selectedSacrifices = [...tempSelectedSacrifices];
    closeInventorySelector();
    renderSelectedSacrificesThumbnails();
    updateUpgraderProbabilities();
  };

  // ==================== MATHEMATICAL CURVE ALGORITHM ====================

  function getRangeBaseChance(minMedia) {
    if (minMedia >= 95) return 8.5;
    if (minMedia >= 93) return 11;
    if (minMedia >= 91) return 13;
    if (minMedia >= 88) return 15;
    if (minMedia >= 86) return 17;
    if (minMedia >= 84) return 18;
    if (minMedia >= 81) return 19;
    if (minMedia >= 78) return 20;
    return 21;
  }

  function getRangeHardCap(minMedia) {
    if (minMedia >= 95) return 60;
    if (minMedia >= 93) return 68;
    if (minMedia >= 91) return 74;
    if (minMedia >= 88) return 80;
    return 88;
  }

  function updateUpgraderProbabilities() {
    let successChance = 0;
    const minR = selectedTargetRange ? selectedTargetRange.min : 88;
    const baseChance = getRangeBaseChance(minR);
    const hardCap = getRangeHardCap(minR);
    const minAllowed = minR - MAX_GAP_DOWN;
    
    if (selectedSacrifices.length > 0) {
      let sumChance = 0;
      selectedSacrifices.forEach(sacId => {
        const sacDetail = getCardDetail(sacId);
        if (sacDetail) {
          const sacRating = sacDetail.media || 75;
          if (sacRating < minAllowed) return; // Disallowed
          
          let contribution = 0;
          if (sacRating >= minR) {
            const delta = sacRating - minR;
            contribution = baseChance * Math.pow(1.25, delta);
          } else {
            const gap = minR - sacRating;
            contribution = baseChance * Math.pow(0.66, gap);
          }
          sumChance += contribution;
        }
      });
      successChance = Math.min(hardCap, Math.max(0.5, parseFloat(sumChance.toFixed(1))));
    }
    
    const capIndicator = document.getElementById("upgrader-cap-indicator");
    if (capIndicator) {
      capIndicator.textContent = `(Tope: ${hardCap}%)`;
    }
    
    const percentEl = document.getElementById("upgrader-percent-val");
    if (percentEl) percentEl.textContent = `${successChance.toFixed(1)}%`;
    
    const chanceEl = document.getElementById("upgrader-chance-val");
    if (chanceEl) chanceEl.textContent = `${successChance.toFixed(1)}%`;
    
    const startBtn = document.getElementById("upgrader-start-btn");
    if (startBtn) {
      startBtn.disabled = !(selectedSacrifices.length > 0 && successChance > 0);
    }
    
    drawRouletteWheel(successChance, currentWheelAngle);
  }

  // ==================== HIGH-FIDELITY CANVAS RULETA ====================

  function drawRouletteWheel(successChance, rotationAngleRad) {
    if (!canvasEl || !ctx) return;
    
    const width = canvasEl.width;
    const height = canvasEl.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const outerRadius = centerX - 8;
    const innerRadius = 60;
    
    ctx.clearRect(0, 0, width, height);
    
    const successRatio = Math.max(0, Math.min(1, successChance / 100));
    const successAngleRad = successRatio * Math.PI * 2;
    
    const startAngle = rotationAngleRad - Math.PI / 2;
    const dividerAngle = startAngle + successAngleRad;
    const endAngle = startAngle + Math.PI * 2;
    
    // 1. Success Segment
    if (successRatio > 0) {
      ctx.beginPath();
      ctx.arc(centerX, centerY, outerRadius, startAngle, dividerAngle, false);
      ctx.arc(centerX, centerY, innerRadius, dividerAngle, startAngle, true);
      ctx.closePath();
      
      const greenGrad = ctx.createRadialGradient(centerX, centerY, innerRadius, centerX, centerY, outerRadius);
      greenGrad.addColorStop(0, '#10b981');
      greenGrad.addColorStop(0.7, '#059669');
      greenGrad.addColorStop(1, '#047857');
      ctx.fillStyle = greenGrad;
      ctx.fill();
    }
    
    // 2. Failure Segment
    if (successRatio < 1) {
      ctx.beginPath();
      ctx.arc(centerX, centerY, outerRadius, dividerAngle, endAngle, false);
      ctx.arc(centerX, centerY, innerRadius, endAngle, dividerAngle, true);
      ctx.closePath();
      
      const redGrad = ctx.createRadialGradient(centerX, centerY, innerRadius, centerX, centerY, outerRadius);
      redGrad.addColorStop(0, '#2d151a');
      redGrad.addColorStop(0.7, '#1f1013');
      redGrad.addColorStop(1, '#150a0c');
      ctx.fillStyle = redGrad;
      ctx.fill();
    }
    
    // 3. Precision Division Lines and Perimeter Ticks
    const numTicks = 36;
    for (let i = 0; i < numTicks; i++) {
      const tickAngle = (i / numTicks) * Math.PI * 2 + rotationAngleRad;
      const isMajor = i % 3 === 0;
      const tickInner = outerRadius - (isMajor ? 8 : 4);
      
      ctx.beginPath();
      ctx.moveTo(centerX + Math.cos(tickAngle) * tickInner, centerY + Math.sin(tickAngle) * tickInner);
      ctx.lineTo(centerX + Math.cos(tickAngle) * outerRadius, centerY + Math.sin(tickAngle) * outerRadius);
      ctx.lineWidth = isMajor ? 1.5 : 0.8;
      ctx.strokeStyle = isMajor ? "rgba(251, 191, 36, 0.45)" : "rgba(255, 255, 255, 0.15)";
      ctx.stroke();
    }
    
    // 4. Outer Cyber/Gold Rim
    ctx.beginPath();
    ctx.arc(centerX, centerY, outerRadius, 0, Math.PI * 2);
    ctx.lineWidth = 3;
    const borderGrad = ctx.createLinearGradient(0, 0, width, height);
    borderGrad.addColorStop(0, '#ffe082');
    borderGrad.addColorStop(0.5, '#fbbf24');
    borderGrad.addColorStop(1, '#d97706');
    ctx.strokeStyle = borderGrad;
    ctx.stroke();
    
    // 5. Outer subtle glow ring
    ctx.beginPath();
    ctx.arc(centerX, centerY, outerRadius + 2, 0, Math.PI * 2);
    ctx.lineWidth = 1;
    ctx.strokeStyle = "rgba(251, 191, 36, 0.2)";
    ctx.stroke();
  }

  // ==================== ROLL EXECUTION & ANIMATION ====================

  window.startUpgraderRoll = async function () {
    getAudioContext();
    if (selectedSacrifices.length === 0 || !selectedTargetRange) return;
    
    const minAllowed = getMinAllowedRating();
    for (const sacId of selectedSacrifices) {
      const sacDetail = getCardDetail(sacId);
      if (sacDetail && (sacDetail.media || 75) < minAllowed) {
        playSynthFailureSound();
        alert(`Nivel insuficiente: La carta ${sacDetail.name} (Media ${sacDetail.media}) está por debajo de la media mínima permitida (${minAllowed}) para el rango ${selectedTargetRange.label}.`);
        return;
      }
    }
    
    const startBtn = document.getElementById("upgrader-start-btn");
    const closeBtn = modalEl ? modalEl.querySelector(".gambling-modal-close") : null;
    const selectTriggerBtn = modalEl ? modalEl.querySelector(".upgrader-trigger-select-btn") : null;
    
    if (startBtn) startBtn.disabled = true;
    if (closeBtn) closeBtn.style.display = "none";
    if (selectTriggerBtn) selectTriggerBtn.disabled = true;
    
    let rollResult = null;
    try {
      rollResult = await executeLocalRollFallback();
    } catch (err) {
      console.error("[UPGRADER] Error al ejecutar tirada local:", err);
      alert(err.message || "Ocurrió un error al procesar la mejora.");
      if (startBtn) startBtn.disabled = false;
      if (closeBtn) closeBtn.style.display = "block";
      if (selectTriggerBtn) selectTriggerBtn.disabled = false;
      return;
    }
    
    if (rollResult) {
      animateRouletteWheel(rollResult);
    }
  };

  async function executeLocalRollFallback() {
    const minR = selectedTargetRange.min;
    const maxR = selectedTargetRange.max;
    const baseChance = getRangeBaseChance(minR);
    const hardCap = getRangeHardCap(minR);
    const minAllowed = minR - MAX_GAP_DOWN;
    
    // Verificar que el usuario tenga las cartas en su inventario antes de tirar
    const neededCounts = {};
    for (const sacId of selectedSacrifices) {
      const baseId = resolveBaseCardId(sacId);
      neededCounts[baseId] = (neededCounts[baseId] || 0) + 1;
    }
    for (const [cardId, needed] of Object.entries(neededCounts)) {
      const owned = (userInventory && userInventory.cards && userInventory.cards[cardId]) || 
                    (window.currentUserData && window.currentUserData.cards && window.currentUserData.cards[cardId]) || 0;
      if (owned < needed) {
        const detail = getCardDetail(cardId);
        const cardName = (detail && detail.name) || cardId;
        throw new Error(`No posees suficientes copias de ${cardName} (${owned}/${needed})`);
      }
    }

    let sumChance = 0;
    selectedSacrifices.forEach(sacId => {
      const sacDetail = getCardDetail(sacId);
      if (sacDetail) {
        const sacRating = sacDetail.media || 75;
        if (sacRating >= minR) {
          sumChance += baseChance * Math.pow(1.25, sacRating - minR);
        } else if (sacRating >= minAllowed) {
          sumChance += baseChance * Math.pow(0.66, minR - sacRating);
        }
      }
    });
    
    const finalChance = Math.min(hardCap, Math.max(0.5, parseFloat(sumChance.toFixed(1))));
    const roll = Math.random() * 100;
    const isSuccess = roll <= finalChance;
    
    // 1. Preparar payload estructurado y consumir cartas sacrificadas en estado cliente
    const sacrificesPayload = [];
    selectedSacrifices.forEach(sacId => {
      const baseId = resolveBaseCardId(sacId);
      sacrificesPayload.push({ instanceId: sacId, cardId: baseId });

      if (userInventory && userInventory.cards) {
        userInventory.cards[baseId] = Math.max(0, (userInventory.cards[baseId] || 0) - 1);
        if (userInventory.cards[baseId] === 0) delete userInventory.cards[baseId];
      }
      if (window.currentUserData && window.currentUserData.cards) {
        window.currentUserData.cards[baseId] = Math.max(0, (window.currentUserData.cards[baseId] || 0) - 1);
        if (window.currentUserData.cards[baseId] === 0) delete window.currentUserData.cards[baseId];
      }
      if (cardTraitsMap[sacId]) delete cardTraitsMap[sacId];
      if (cardUpgradesMap[sacId]) delete cardUpgradesMap[sacId];
    });
    
    // 2. Determinar recompensa en caso de éxito
    let rewardCard = null;
    if (isSuccess) {
      const candidateCards = allCardsCatalog.filter(c => {
        const m = Number(c.media) || 0;
        const qClean = String(c.quality || c.calidad || '').trim().toLowerCase().replace(/[\s_\-\.]+/g, '');
        return UPGRADER_ALLOWED_QUALITIES.has(qClean) && m >= minR && m <= maxR;
      });
      
      if (candidateCards.length > 0) {
        const distinctMedias = Array.from(new Set(candidateCards.map(c => Number(c.media)))).sort((a, b) => a - b);
        let chosenMedia = distinctMedias[0];
        
        if (distinctMedias.length === 3) {
          const r = Math.random() * 100;
          if (r < 70) chosenMedia = distinctMedias[0];
          else if (r < 92) chosenMedia = distinctMedias[1];
          else chosenMedia = distinctMedias[2];
        } else if (distinctMedias.length === 2) {
          const r = Math.random() * 100;
          if (r < 80) chosenMedia = distinctMedias[0];
          else chosenMedia = distinctMedias[1];
        }
        
        const matchingCards = candidateCards.filter(c => Number(c.media) === chosenMedia);
        const cardObj = matchingCards.length > 0 ? matchingCards[Math.floor(Math.random() * matchingCards.length)] : candidateCards[0];
        
        if (cardObj) {
          rewardCard = {
            id: cardObj.id,
            instanceId: cardObj.id,
            name: cardObj.name || cardObj.nombre || cardObj.id,
            media: Number(cardObj.media) || chosenMedia,
            quality: cardObj.quality || cardObj.calidad || 'oro',
            imageUrl: cardObj.imageUrl || cardObj.imagen || ''
          };
          
          if (userInventory && userInventory.cards) {
            userInventory.cards[cardObj.id] = (userInventory.cards[cardObj.id] || 0) + 1;
          }
          if (window.currentUserData && window.currentUserData.cards) {
            window.currentUserData.cards[cardObj.id] = (window.currentUserData.cards[cardObj.id] || 0) + 1;
          }
        }
      }
    }
    
    // 3. Persistir inventario en Electron y backend de forma segura
    if (window.kvrcards && typeof window.kvrcards.applyUpgraderResult === 'function') {
      try {
        const ipcRes = await window.kvrcards.applyUpgraderResult({
          sacrifices: sacrificesPayload,
          rewardCard: rewardCard
        });
        if (ipcRes && ipcRes.ok) {
          if (ipcRes.cards) {
            if (userInventory) userInventory.cards = ipcRes.cards;
            if (window.currentUserData) window.currentUserData.cards = { ...ipcRes.cards };
          }
          if (ipcRes.cardTraits) cardTraitsMap = ipcRes.cardTraits;
          if (ipcRes.cardUpgrades) cardUpgradesMap = ipcRes.cardUpgrades;
          console.log("[UPGRADER] Inventario sincronizado y guardado con éxito vía Electron.");
        } else if (ipcRes && ipcRes.error) {
          console.warn("[UPGRADER] applyUpgraderResult retornó error:", ipcRes.error);
        }
      } catch (ipcErr) {
        console.warn("[UPGRADER] Error al guardar tirada vía Electron:", ipcErr);
      }
    } else {
      // Fallback para entorno web puro (sin Electron): sincronización directa
      let baseUrl = "";
      if (window.kvrcards && typeof window.kvrcards.getInventoryServerInfo === 'function') {
        try {
          const info = await window.kvrcards.getInventoryServerInfo();
          if (info && info.ok && info.effectiveBaseUrl) {
            baseUrl = info.effectiveBaseUrl.endsWith('/') ? info.effectiveBaseUrl.slice(0, -1) : info.effectiveBaseUrl;
          }
        } catch (e) {}
      }
      if (!baseUrl) baseUrl = "https://kvrcards-server.onrender.com";
      
      try {
        await fetch(`${baseUrl}/api/inventory/${currentUser}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            username: currentUser,
            cards: userInventory ? userInventory.cards : {},
            cardTraits: cardTraitsMap,
            cardUpgrades: cardUpgradesMap,
            wallet: userInventory ? userInventory.wallet : {},
            completedDeliverables: (userInventory && userInventory.completedDeliverables) || (window.currentUserData && window.currentUserData.completedDeliverables) || [],
            deliverableCompletions: (userInventory && userInventory.deliverableCompletions) || {},
            deliverableDailyCompletions: (userInventory && userInventory.deliverableDailyCompletions) || {},
            missions: (window.userMissions && Object.keys(window.userMissions).length > 0) ? window.userMissions : (userInventory ? userInventory.missions : {}),
            kizunas: (typeof userKizunas !== 'undefined' && userKizunas) || (userInventory ? userInventory.kizunas : {}),
            items: (userInventory && userInventory.items) || (window.userProfile && window.userProfile.items) || {},
            plushies: (userInventory && userInventory.plushies) || {},
            forceReplace: false
          })
        });
        console.log("[UPGRADER] Inventario sincronizado en servidor remoto tras tirada.");
      } catch (syncErr) {
        console.warn("[UPGRADER] No se pudo sincronizar de inmediato con el servidor remoto:", syncErr);
      }
    }
    
    return {
      ok: true,
      success: isSuccess,
      roll: parseFloat(roll.toFixed(2)),
      successChance: finalChance,
      targetRange: { min: minR, max: maxR },
      rewardCard: rewardCard
    };
  }

  function animateRouletteWheel(result) {
    const successRatio = (result.successChance || 0) / 100;
    const successArcRad = successRatio * Math.PI * 2;
    
    let stopRelativeRad = 0;
    if (result.success) {
      const padding = Math.min(0.08, successArcRad * 0.1);
      stopRelativeRad = padding + Math.random() * Math.max(0.01, successArcRad - 2 * padding);
    } else {
      const failArcRad = Math.PI * 2 - successArcRad;
      const padding = Math.min(0.08, failArcRad * 0.1);
      stopRelativeRad = successArcRad + padding + Math.random() * Math.max(0.01, failArcRad - 2 * padding);
    }
    
    const baseRotations = (6 + Math.floor(Math.random() * 3)) * Math.PI * 2;
    const targetFinalAngle = baseRotations + (Math.PI * 2 - stopRelativeRad);
    
    const durationMs = 4200;
    const startTime = performance.now();
    let lastTickSegment = -1;
    
    function tick(now) {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / durationMs);
      
      const easeProgress = 1 - Math.pow(1 - progress, 3.2);
      currentWheelAngle = easeProgress * targetFinalAngle;
      
      drawRouletteWheel(result.successChance, currentWheelAngle);
      
      const segmentRad = Math.PI / 18;
      const currentSegment = Math.floor(currentWheelAngle / segmentRad);
      if (currentSegment !== lastTickSegment) {
        lastTickSegment = currentSegment;
        playSynthTickSound();
      }
      
      if (progress < 1) {
        spinAnimationId = requestAnimationFrame(tick);
      } else {
        spinAnimationId = null;
        resolveUpgradeResolution(result);
      }
    }
    
    spinAnimationId = requestAnimationFrame(tick);
  }

  // ==================== RESOLUTION MODAL ====================

  async function resolveUpgradeResolution(result) {
    const burst = document.createElement("div");
    burst.className = "flash-burst animate";
    modalEl.appendChild(burst);
    setTimeout(() => burst.remove(), 700);
    
    if (result.success) {
      playSynthSuccessSound();
    } else {
      playSynthFailureSound();
    }
    
    const overlay = document.createElement("div");
    overlay.className = `upgrader-overlay ${result.success ? 'success' : 'failure'}`;
    
    if (result.success && result.rewardCard) {
      const card = result.rewardCard;
      overlay.innerHTML = `
        <div class="upgrader-overlay-title">¡MEJORA CONSEGUIDA!</div>
        <div class="upgrader-result-subtitle">Has obtenido una nueva carta en el rango ${result.targetRange.min} - ${result.targetRange.max}</div>
        
        <div class="upgraded-card-container-wrapper">
          <div class="sparkle-particles" id="sparkle-layer"></div>
          <div class="upgraded-card-shiny-effect"></div>
          <div class="upgrader-reward-card-display">
            <div class="upgrader-reward-media-badge">${card.media}</div>
            <div class="upgrader-reward-quality-badge">${(card.quality || 'oro').toUpperCase()}</div>
            <img src="${getCardImageUrl(card)}" onerror="this.onerror=null; this.src='${FALLBACK_100x140_BASE64}';">
            <div class="upgrader-reward-card-name">${card.name}</div>
          </div>
        </div>
        
        <div class="upgrader-result-details">
          La carta ha sido transferida directamente a tu inventario. Tus <strong>${selectedSacrifices.length}</strong> cartas de sacrificio han sido consumidas.
        </div>
        
        <button class="upgrader-result-dismiss-btn" onclick="dismissUpgraderResult()">Reclamar Carta</button>
      `;
    } else {
      overlay.innerHTML = `
        <div class="upgrader-overlay-title">MEJORA FALLIDA</div>
        <div class="upgrader-result-subtitle">La ruleta se detuvo en la zona de fallo</div>
        
        <div class="upgrader-fail-icon">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="15" y1="9" x2="9" y2="15"></line>
            <line x1="9" y1="9" x2="15" y2="15"></line>
          </svg>
        </div>
        
        <div class="upgrader-result-details">
          No se ha obtenido ninguna carta. Has perdido permanentemente las cartas de sacrificio apostadas.
        </div>
        
        <button class="upgrader-result-dismiss-btn fail-btn" onclick="dismissUpgraderResult()">Continuar</button>
      `;
    }
    
    modalEl.appendChild(overlay);
    overlay.style.display = "flex";
    
    if (result.success) {
      createSparkleBurst();
    }
    
    try {
      const freshInv = await fetchServerInventory();
      userInventory = freshInv;
      cardTraitsMap = freshInv.cardTraits || {};
      cardUpgradesMap = freshInv.cardUpgrades || {};
    } catch (e) {
      console.warn("[UPGRADER] Error re-fetching fresh inventory:", e);
    }
    
    if (typeof renderCollection === 'function') renderCollection().catch(() => {});
    if (typeof renderWallet === 'function') renderWallet().catch(() => {});
  }

  function createSparkleBurst() {
    const layer = document.getElementById("sparkle-layer");
    if (!layer) return;
    
    const count = 35;
    for (let i = 0; i < count; i++) {
      const p = document.createElement("div");
      p.className = "sparkle-particle";
      
      const angle = Math.random() * Math.PI * 2;
      const velocity = 35 + Math.random() * 110;
      const x = Math.cos(angle) * velocity;
      const y = Math.sin(angle) * velocity;
      const size = 3 + Math.random() * 5;
      
      p.style.setProperty('--x', `${x}px`);
      p.style.setProperty('--y', `${y}px`);
      p.style.setProperty('--s', `${Math.random() * 0.7 + 0.4}`);
      p.style.width = `${size}px`;
      p.style.height = `${size}px`;
      p.style.left = `calc(50% - ${size/2}px)`;
      p.style.top = `calc(50% - ${size/2}px)`;
      
      layer.appendChild(p);
    }
  }

  window.dismissUpgraderResult = function () {
    const overlay = modalEl ? modalEl.querySelector(".upgrader-overlay") : null;
    if (overlay) overlay.remove();
    
    const startBtn = document.getElementById("upgrader-start-btn");
    const closeBtn = modalEl ? modalEl.querySelector(".gambling-modal-close") : null;
    const selectTriggerBtn = modalEl ? modalEl.querySelector(".upgrader-trigger-select-btn") : null;
    
    if (startBtn) startBtn.disabled = false;
    if (closeBtn) closeBtn.style.display = "block";
    if (selectTriggerBtn) selectTriggerBtn.disabled = false;
    
    selectedSacrifices = [];
    renderSelectedSacrificesThumbnails();
    updateUpgraderProbabilities();
  };

  window.resetUpgraderInventoryCache = function () {
    userInventory = null;
    cardTraitsMap = {};
    cardUpgradesMap = {};
    selectedSacrifices = [];
  };

})();
