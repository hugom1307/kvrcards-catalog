(function onlineBattleRoundHandlersModule() {
  'use strict';

  const OnlineBattleRoundHandlers = {
    handleServerSelectStat,
    handleServerRoundResult
  };

  function handleServerSelectStat(data) {
    console.log('[ONLINE-BATTLE] 📊 Servidor solicita seleccion de stat');
    console.log('[ONLINE-BATTLE] showRoulette:', data.showRoulette);
    console.log('[ONLINE-BATTLE] firstPlayer:', data.firstPlayer, 'isYourTurn:', data.isYourTurn);

    window.battleState.playerCurrentCard = data.playerCard;
    window.battleState.opponentCurrentCard = data.opponentCard;

    if (data.isYourTurn) {
      window.battleState.currentTurn = 'player';
      window.battleState.gamePhase = 'stat-selection';
      console.log('[ONLINE-BATTLE] Es MI turno para elegir stat');
    } else {
      window.battleState.currentTurn = 'opponent';
      window.battleState.gamePhase = 'stat-selection';
      console.log('[ONLINE-BATTLE] Es turno del RIVAL para elegir stat, esperando...');
    }

    window.battleState.selectedStat = null;
    window.battleState.opponentSelectedStat = null;
    window.battleState.annulledStat = null;

    console.log('[ONLINE-BATTLE] currentTurn forzado a player (seleccion simultanea online)');
    console.log('[ONLINE-BATTLE] gamePhase forzado a stat-selection');

    var teamBuilder = document.getElementById('team-builder');
    var battleScreen = document.getElementById('battle-screen');
    var intro = document.getElementById('battle-intro');

    if (teamBuilder) teamBuilder.style.display = 'none';
    if (intro) intro.style.display = 'none';
    if (battleScreen) battleScreen.style.display = 'flex';

    setupBattleProfiles();
    if (window.battleState.currentRound === 1 || (!window.battleState.playerUsedStats || window.battleState.playerUsedStats.length === 0)) {
      if (typeof window.cleanAllBattleStatButtonsAndDisplays === 'function') {
        window.cleanAllBattleStatButtonsAndDisplays();
      }
    }
    if (typeof window.setupStatButtons === 'function') {
      window.setupStatButtons();
    } else if (typeof setupStatButtons === 'function') {
      setupStatButtons();
    }

    if (typeof renderBattlePowers === 'function') {
      renderBattlePowers(
        window.battleState.playerPowers || [],
        window.battleState.opponentPowers || []
      ).then(function() {
        if (typeof setupPowerButtons === 'function') {
          setupPowerButtons();
        }
      });
    }

    var scorePlayerEl = document.getElementById('score-player-value');
    var scoreOpponentEl = document.getElementById('score-opponent-value');
    if (scorePlayerEl) scorePlayerEl.textContent = window.battleState.playerScore || '0';
    if (scoreOpponentEl) scoreOpponentEl.textContent = window.battleState.opponentScore || '0';

    updateBattleCards();
    console.log('[ONLINE-BATTLE] Cartas renderizadas en batalla');

    if (data.showRoulette) {
      console.log('[ONLINE-BATTLE] 🎰 Mostrando ruleta...');
      window.battleState.firstPlayer = data.isFirstPlayer;
      console.log('[ONLINE-BATTLE] firstPlayer guardado:', window.battleState.firstPlayer);

      startBattleRoulette().then(function() {
        console.log('[ONLINE-BATTLE] Ruleta finalizada, configurando seleccion de stats');
        window.battleState.gamePhase = 'stat-selection';

        // Limpiar visuales de la ronda anterior e inicializar botones según turno
        if (typeof enableStatSelection === 'function') {
          enableStatSelection();
        }

        if (data.isYourTurn) {
          window.battleState.currentTurn = 'player';
        } else {
          window.battleState.currentTurn = 'opponent';
          var instrEl = document.getElementById('battle-intro-instruction');
          if (instrEl) {
            instrEl.innerHTML = '<h1>⌛ Turno del rival</h1><p>Esperando a que seleccione stat...</p>';
          }
        }
      });
    } else {
      if (typeof enableStatSelection === 'function') {
        enableStatSelection();
      }
    }

    var instruction = document.getElementById('battle-intro-instruction');
    if (instruction && !data.showRoulette) {
      if (data.isYourTurn) {
        instruction.innerHTML = '<h1>\u2694\ufe0f Es tu turno</h1><p>Selecciona una estadistica</p>';
      } else {
        instruction.innerHTML = '<h1>\u231b Turno del rival</h1><p>Espera a que seleccione</p>';
      }
    }
  }

  function handleServerRoundResult(data) {
    console.log('[ONLINE-BATTLE] \ud83c\udfc6 Resultado de ronda:', data);

    document.querySelectorAll('.battle-stat-display.highlighted, .battle-stat-btn.highlighted').forEach(function(el) {
      el.classList.remove('highlighted');
      el.classList.add('highlighted-static');
    });

    if (window.battleState && window.battleState.selectedStat) {
      var playerStatEl = document.querySelector('.battle-side-player .battle-stat-btn[data-stat="' + window.battleState.selectedStat + '"]');
      if (playerStatEl) {
        playerStatEl.classList.add('highlighted-static');
      }
    }

    var isPlayer1 = window.onlineState.isHost;
    var scores = data.scores || data.newScores || { player1: 0, player2: 0 };

    if (window.battleState) {
      if (isPlayer1) {
        window.battleState.playerScore = scores.player1;
        window.battleState.opponentScore = scores.player2;
      } else {
        window.battleState.playerScore = scores.player2;
        window.battleState.opponentScore = scores.player1;
      }

      var myCard = isPlayer1 ? data.card1 : data.card2;
      if (myCard && myCard.cardIndex !== undefined) {
        if (!window.battleState.playerUsedCards.includes(myCard.cardIndex)) {
          window.battleState.playerUsedCards.push(myCard.cardIndex);
        }
      }
      if (myCard && myCard.stat) {
        if (!window.battleState.playerUsedStats.includes(myCard.stat)) {
          window.battleState.playerUsedStats.push(myCard.stat);
        }
      }

      var oppCard = isPlayer1 ? data.card2 : data.card1;
      if (oppCard && oppCard.cardIndex !== undefined) {
        if (!window.battleState.opponentUsedCards.includes(oppCard.cardIndex)) {
          window.battleState.opponentUsedCards.push(oppCard.cardIndex);
        }
      }
      if (oppCard && oppCard.stat) {
        if (!window.battleState.opponentUsedStats.includes(oppCard.stat)) {
          window.battleState.opponentUsedStats.push(oppCard.stat);
        }
      }

      var isDraw = (data.winner === 'draw');
      var playerWon = (data.winner === 'player1' && isPlayer1) || (data.winner === 'player2' && !isPlayer1);
      var localWinner = isDraw ? 'draw' : (playerWon ? 'player' : 'opponent');

      var myCardData = isPlayer1 ? data.card1 : data.card2;
      var oppCardData = isPlayer1 ? data.card2 : data.card1;
      var playerValue = myCardData ? myCardData.value : 0;
      var opponentValue = oppCardData ? oppCardData.value : 0;

      if (data.player1Total !== undefined && data.player2Total !== undefined) {
        window.battleState.wasTie = true;
        window.battleState.playerTotalInTie = isPlayer1 ? data.player1Total : data.player2Total;
        window.battleState.opponentTotalInTie = isPlayer1 ? data.player2Total : data.player1Total;
      }

      var overlay = document.getElementById('round-result-overlay');
      if (overlay) {
        var playerValueEl = document.getElementById('round-result-player-value');
        var opponentValueEl = document.getElementById('round-result-opponent-value');
        if (playerValueEl) playerValueEl.textContent = playerValue;
        if (opponentValueEl) opponentValueEl.textContent = opponentValue;
        overlay.style.display = 'flex';

        var tieOverlay = document.getElementById('tie-total-overlay');
        if (window.battleState.wasTie && tieOverlay) {
          var tiePlayerEl = document.getElementById('tie-total-player-value');
          var tieOpponentEl = document.getElementById('tie-total-opponent-value');
          if (tiePlayerEl) tiePlayerEl.textContent = window.battleState.playerTotalInTie || 0;
          if (tieOpponentEl) tieOpponentEl.textContent = window.battleState.opponentTotalInTie || 0;
          tieOverlay.style.display = 'block';
        }

        var playerCardDisplay = document.querySelector('.battle-side-player .battle-card-display');
        var opponentCardDisplay = document.querySelector('.battle-side-opponent .battle-card-display');
        var playerCardImg = document.getElementById('battle-player-card');
        var opponentCardImg = document.getElementById('battle-opponent-card');

        if (playerCardDisplay) playerCardDisplay.classList.remove('winner');
        if (opponentCardDisplay) opponentCardDisplay.classList.remove('winner');
        if (playerCardImg) playerCardImg.classList.remove('battle-card-winner');
        if (opponentCardImg) opponentCardImg.classList.remove('battle-card-winner');

        if (localWinner === 'player') {
          if (playerCardDisplay) playerCardDisplay.classList.add('winner');
          if (playerCardImg) playerCardImg.classList.add('battle-card-winner');
        } else if (localWinner === 'opponent') {
          if (opponentCardDisplay) opponentCardDisplay.classList.add('winner');
          if (opponentCardImg) opponentCardImg.classList.add('battle-card-winner');
        }

        setTimeout(function() {
          overlay.style.display = 'none';
          if (tieOverlay) tieOverlay.style.display = 'none';
          window.battleState.wasTie = false;

          if (playerCardDisplay) playerCardDisplay.classList.remove('winner');
          if (opponentCardDisplay) opponentCardDisplay.classList.remove('winner');
          if (playerCardImg) playerCardImg.classList.remove('battle-card-winner');
          if (opponentCardImg) opponentCardImg.classList.remove('battle-card-winner');
        }, 4000);
      }
    }

    var scorePlayerEl = document.getElementById('score-player-value');
    var scoreOpponentEl = document.getElementById('score-opponent-value');
    if (scorePlayerEl) scorePlayerEl.textContent = window.battleState.playerScore;
    if (scoreOpponentEl) scoreOpponentEl.textContent = window.battleState.opponentScore;

    if (typeof updateScoreDisplay === 'function') {
      updateScoreDisplay();
    }
  }

  window.OnlineBattleRoundHandlers = OnlineBattleRoundHandlers;
})();
