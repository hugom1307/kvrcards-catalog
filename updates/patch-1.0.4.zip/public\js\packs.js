// ==================== GESTIÓN Y PERSISTENCIA DE CARTAS PENDIENTES DEL SOBRE ====================
function loadPendingPackCards() {
  if (pendingCards && pendingCards.length > 0) {
    return { cards: pendingCards, cardIds: pendingCardIds };
  }
  try {
    const raw = localStorage.getItem('kvr_pending_pack_data');
    if (raw) {
      const data = JSON.parse(raw);
      if (data && Array.isArray(data.cards) && data.cards.length > 0) {
        pendingCards = data.cards;
        pendingCardIds = data.cardIds || data.cards.map(c => c.id);
        return { cards: pendingCards, cardIds: pendingCardIds };
      }
    }
  } catch (e) {
    console.warn('[PACKS] Error loading pending pack data:', e);
  }
  return { cards: [], cardIds: [] };
}

function clearPendingPackCards() {
  pendingCards = [];
  pendingCardIds = [];
  try {
    localStorage.removeItem('kvr_pending_pack_data');
  } catch (e) {}
}

function savePendingPackCards(cards, cardIds) {
  pendingCards = cards || [];
  pendingCardIds = cardIds || [];
  try {
    if (pendingCards.length > 0) {
      localStorage.setItem('kvr_pending_pack_data', JSON.stringify({
        cards: pendingCards,
        cardIds: pendingCardIds,
        timestamp: Date.now()
      }));
    } else {
      localStorage.removeItem('kvr_pending_pack_data');
    }
  } catch (e) {
    console.warn('[PACKS] Error saving pending pack data:', e);
  }
}

function addPendingPackCards(cards, cardIds) {
  loadPendingPackCards();
  const existingCards = Array.isArray(pendingCards) ? pendingCards : [];
  const existingCardIds = Array.isArray(pendingCardIds) ? pendingCardIds : [];

  pendingCards = [...existingCards, ...(cards || [])];
  pendingCardIds = [...existingCardIds, ...(cardIds || (cards || []).map(c => c.id))];

  try {
    if (pendingCards.length > 0) {
      localStorage.setItem('kvr_pending_pack_data', JSON.stringify({
        cards: pendingCards,
        cardIds: pendingCardIds,
        timestamp: Date.now()
      }));
    } else {
      localStorage.removeItem('kvr_pending_pack_data');
    }
  } catch (e) {
    console.warn('[PACKS] Error saving pending pack data:', e);
  }
}

async function renderPendingPackCards(instant = true) {
  const { cards } = loadPendingPackCards();
  const obtainedSection = document.getElementById('obtained-cards-section');
  if (!obtainedSection) return;

  if (!cards || cards.length === 0) {
    obtainedSection.style.display = 'none';
    if (saveAllBtn) saveAllBtn.style.display = 'none';
    if (sellAllBtn) sellAllBtn.style.display = 'none';
    if (cardsDiv) cardsDiv.innerHTML = '';
    return;
  }

  obtainedSection.style.display = 'block';

  let ownedCards = {};
  try {
    const inv = await window.kvrcards.getInventory();
    if (inv && inv.ok && inv.cards) {
      ownedCards = inv.cards;
    }
  } catch (e) {}

  const seenInPack = {};
  cardsDiv.innerHTML = '';

  for (const card of cards) {
    const cardId = card.id;
    const isDuplicate = (Number(ownedCards[cardId]) > 0) || (Number(seenInPack[cardId]) > 0);
    seenInPack[cardId] = (seenInPack[cardId] || 0) + 1;

    const div = document.createElement('div');
    div.className = 'card reveal revealed' + (isDuplicate ? ' card-duplicate' : '');

    const img = document.createElement('img');
    const placeholder = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="280"><rect width="100%" height="100%" fill="#222"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#ccc" font-family="Arial" font-size="18">Carta</text></svg>');
    img.onerror = () => { if (img.src !== placeholder) img.src = placeholder; };
    img.src = (typeof normalizeAssetUrl === 'function' ? normalizeAssetUrl(card.imageUrl) : card.imageUrl) || placeholder;
    img.alt = card.name;
    img.addEventListener('click', () => openLightbox(img.src));
    div.appendChild(img);

    if (isDuplicate) {
      const repTag = document.createElement('div');
      repTag.className = 'card-duplicate-tag';
      repTag.textContent = '(Repetido)';
      div.appendChild(repTag);
    }

    cardsDiv.appendChild(div);
  }

  if (saveAllBtn) saveAllBtn.style.display = 'inline-block';
  if (sellAllBtn) sellAllBtn.style.display = 'inline-block';
}

window.loadPendingPackCards = loadPendingPackCards;
window.renderPendingPackCards = renderPendingPackCards;
window.clearPendingPackCards = clearPendingPackCards;
window.savePendingPackCards = savePendingPackCards;

async function renderOwnedPacks() {
  if (!isElectron) return;
  const [packs, inv] = await Promise.all([
    window.kvrcards.getAllPacks(),
    window.kvrcards.getInventory(),
  ]);
  const counts = inv.ok ? inv.packs : {};
  ownedPacksDiv.innerHTML = '';
  let hasPacks = false;
  for (const pack of packs) {
    const count = counts[pack.id] || 0;
    // Solo mostrar sobres que tengas disponibles (cantidad > 0)
    if (count <= 0) continue;
    hasPacks = true;
    const row = document.createElement('div');
    const label = document.createElement('span');
    // thumbnail con badge de cantidad
    const thumb = document.createElement('div');
    thumb.className = 'pack-thumb';
    const pImg = document.createElement('img');
    pImg.style.width = '120px';
    pImg.style.height = 'auto';
    pImg.style.display = 'block';
    pImg.style.marginBottom = '6px';
    pImg.style.cursor = 'pointer';
    pImg.title = 'Ver detalles del sobre';
    const pPlaceholder = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="120" height="160"><rect width="100%" height="100%" fill="#1f2937"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#9ca3af" font-family="Arial" font-size="12">Sobre</text></svg>');
    pImg.onerror = () => { if (pImg.src !== pPlaceholder) pImg.src = pPlaceholder; };
    pImg.src = (typeof normalizeAssetUrl === 'function' ? normalizeAssetUrl(pack.imageUrl) : pack.imageUrl) || pPlaceholder;
    pImg.addEventListener('click', () => showPackDetails(pack.id));
    thumb.appendChild(pImg);
    if (count > 0) {
      const badge = document.createElement('span');
      badge.className = 'count-badge';
      badge.textContent = String(count);
      thumb.appendChild(badge);
    }
    label.textContent = `${pack.name}`;
    const limits = typeof window.getPackMediaLimits === 'function' ? window.getPackMediaLimits(pack) : { minMedia: pack.minMedia, maxMedia: pack.maxMedia };
    if (limits && (limits.minMedia !== null || limits.maxMedia !== null)) {
      const mediaBadge = document.createElement('span');
      mediaBadge.className = 'pack-media-badge';
      mediaBadge.style.cssText = 'display: inline-block; margin-left: 6px; font-size: 11px; font-weight: 700; color: #fbbf24; background: rgba(251, 191, 36, 0.15); border: 1px solid rgba(251, 191, 36, 0.35); border-radius: 4px; padding: 1px 5px; vertical-align: middle;';
      if (limits.minMedia !== null && limits.maxMedia !== null) {
        mediaBadge.textContent = `${limits.minMedia}-${limits.maxMedia}`;
      } else if (limits.minMedia !== null) {
        mediaBadge.textContent = `+${limits.minMedia}`;
      } else {
        mediaBadge.textContent = `≤${limits.maxMedia}`;
      }
      label.appendChild(mediaBadge);
    }
    const openBtn = document.createElement('button');
    openBtn.textContent = 'Abrir';
    openBtn.disabled = count <= 0;
    openBtn.addEventListener('click', () => openPack(pack.id));
    row.appendChild(thumb);
    row.appendChild(label);
    row.appendChild(openBtn);
    ownedPacksDiv.appendChild(row);
  }

  if (!hasPacks) {
    ownedPacksDiv.innerHTML = `
      <div class="no-packs-message" style="
        background-color: #101336ff; 
        color: #fff; 
        padding: 20px; 
        border-radius: 8px; 
        text-align: center; 
        margin-top: 20px;
        border: 1px solid #333;
        transition: transform 0.2s;
        cursor: default;
      " onmouseover="this.style.transform='scale(1.02)'" onmouseout="this.style.transform='scale(1)'">
        Cuando tengas sobres aparecerán aquí
      </div>
    `;
  }

  // Si hay cartas pendientes de un sobre abierto previamente, mostrarlas siempre
  await renderPendingPackCards(true);

  if (typeof updateGlobalNotificationBadges === 'function') {
    updateGlobalNotificationBadges();
  }
}

function isValidHexColor(value) {
  return typeof value === 'string' && /^#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})$/.test(value.trim());
}

function normalizeHexColor(value) {
  if (!isValidHexColor(value)) return null;
  const hex = value.trim().toLowerCase();
  if (hex.length === 4) {
    return `#${hex[1]}${hex[1]}${hex[2]}${hex[2]}${hex[3]}${hex[3]}`;
  }
  return hex;
}

function hexToRgba(hexColor, alpha) {
  const normalized = normalizeHexColor(hexColor);
  if (!normalized) return `rgba(168, 85, 247, ${alpha})`;
  const r = parseInt(normalized.slice(1, 3), 16);
  const g = parseInt(normalized.slice(3, 5), 16);
  const b = parseInt(normalized.slice(5, 7), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function resolvePackOpeningTheme(pack) {
  const rawGradient =
    pack?.openingGradient ||
    pack?.packOpeningGradient ||
    pack?.animation?.openingGradient ||
    pack?.animation?.packGradient ||
    null;

  let colors = [...DEFAULT_PACK_OPENING_COLORS];

  if (Array.isArray(rawGradient)) {
    const normalized = rawGradient
      .map(normalizeHexColor)
      .filter(Boolean);
    if (normalized.length >= 3) {
      colors = normalized.slice(0, 3);
    } else if (normalized.length === 2) {
      colors = [normalized[0], normalized[1], normalized[1]];
    }
  } else if (rawGradient && typeof rawGradient === 'object') {
    const normalized = [
      normalizeHexColor(rawGradient.start || rawGradient.from),
      normalizeHexColor(rawGradient.mid || rawGradient.middle),
      normalizeHexColor(rawGradient.end || rawGradient.to)
    ].filter(Boolean);
    if (normalized.length >= 3) {
      colors = normalized.slice(0, 3);
    } else if (normalized.length === 2) {
      colors = [normalized[0], normalized[1], normalized[1]];
    }
  }

  return {
    colors,
    gradient: `linear-gradient(135deg, ${colors[0]}, ${colors[1]} 45%, ${colors[2]})`,
    sparkColor: colors[1] || colors[0]
  };
}

function applyPackOpeningTheme(theme) {
  if (!packBody) return;
  const colors = theme?.colors || DEFAULT_PACK_OPENING_COLORS;
  packBody.style.setProperty('--pack-half-gradient', theme?.gradient || `linear-gradient(135deg, ${colors[0]}, ${colors[1]} 45%, ${colors[2]})`);
  packBody.style.setProperty('--pack-half-border', colors[2]);
  packBody.style.setProperty('--pack-opening-outline', hexToRgba(colors[0], 0.38));
  packBody.style.setProperty('--pack-opening-glow', hexToRgba(colors[1], 0.34));
  packBody.style.setProperty('--pack-opening-inner', hexToRgba(colors[2], 0.28));
  packBody.style.setProperty('--pack-opening-sheen', hexToRgba(colors[0], 0.35));
  packBody.style.setProperty('--pack-opening-inset', hexToRgba(colors[1], 0.16));
}

function clearPackOpeningTheme() {
  if (!packBody) return;
  packBody.style.removeProperty('--pack-half-gradient');
  packBody.style.removeProperty('--pack-half-border');
  packBody.style.removeProperty('--pack-opening-outline');
  packBody.style.removeProperty('--pack-opening-glow');
  packBody.style.removeProperty('--pack-opening-inner');
  packBody.style.removeProperty('--pack-opening-sheen');
  packBody.style.removeProperty('--pack-opening-inset');
}

async function openPack(packId) {
  if (!isElectron) return;
  
  // Ocultar sección de cartas obtenidas y botones hasta que la animación termine por completo
  const obtainedSection = document.getElementById('obtained-cards-section');
  if (obtainedSection) obtainedSection.style.display = 'none';
  if (cardsDiv) cardsDiv.innerHTML = '';
  if (saveAllBtn) saveAllBtn.style.display = 'none';
  if (sellAllBtn) sellAllBtn.style.display = 'none';

  const [allPacksForTheme, openResult] = await Promise.all([
    window.kvrcards.getAllPacks().catch(() => []),
    window.kvrcards.openPack(packId)
  ]);
  const packForTheme = Array.isArray(allPacksForTheme)
    ? allPacksForTheme.find(p => p.id === packId)
    : null;
  const packOpeningTheme = resolvePackOpeningTheme(packForTheme);
  const { ok, cards, cardIds, error } = openResult;
  if (!ok) { alert(error || 'Error abriendo pack'); return; }

  // Las estadísticas se incrementan automáticamente en el backend
  console.log('[PACK] Sobre abierto, estadísticas actualizadas en backend');
  
  if (window.DiscordPresence) {
    const packName = packForTheme?.name || 'Tienda';
    window.DiscordPresence.setPacks(packName);
  }
  
  // Notificar al sistema de evoluciones por cada carta obtenida
  if (Array.isArray(cardIds) && typeof window.recordEvolutionCardObtained === 'function') {
    cardIds.forEach(cId => {
      try {
        window.recordEvolutionCardObtained(cId, 1);
      } catch (evoPackErr) {
        console.warn('[EVOLUTIONS] Error notificando carta de sobre:', evoPackErr);
      }
    });
  }

  // Verificar progreso de evoluciones
  if (typeof checkEvolutionMissions === 'function') {
    setTimeout(() => checkEvolutionMissions(true), 500);
  }

  // Acumular cartas y IDs pendientes en memoria y localStorage permanentemente
  addPendingPackCards(cards, cardIds || []);

  // Asegurar que las calidades globales están cargadas para el reveal y animaciones
  if (window.kvrcards && window.kvrcards.getQualities) {
    try {
      const qs = await window.kvrcards.getQualities();
      if (Array.isArray(qs) && qs.length > 0) {
        window.appQualities = qs;
        window.appQualitiesCache = qs;
      }
    } catch {}
  }

  const qualitiesList = window.appQualities || window.appQualitiesCache || [];

  // Función para determinar si una carta activa la animación épica / tocha (Caminante):
  // 1. Carta Oro con media >= 90 (90 incluido)
  // 2. Carta Especial con media >= 87 (87 incluido)
  const checkCardImportant = (card) => {
    if (!card) return false;
    const media = Number(card.media || 0);
    const qRaw = String(card.calidadId || card.calidad || card.quality || '').toLowerCase().trim();
    const cleanQ = qRaw.replace(/[\s\-_]/g, '');
    const qObj = Array.isArray(qualitiesList) ? qualitiesList.find(q => {
      const idClean = String(q.id || '').toLowerCase().replace(/[\s\-_]/g, '');
      const nameClean = String(q.name || '').toLowerCase().replace(/[\s\-_]/g, '');
      return idClean === cleanQ || nameClean === cleanQ || q.id === qRaw || q.name === qRaw;
    }) : null;

    const isSpecial = qObj ? Boolean(qObj.special) : ['icono', 'heroe', 'héroe', 'icono_prime', 'icono_super_prime', 'especial', 'evo'].some(k => qRaw.includes(k));
    const isOro = (qObj?.id === 'oro') ||
                  (String(qObj?.name || '').toLowerCase() === 'oro') ||
                  qRaw.includes('oro') ||
                  qRaw.includes('gold') ||
                  (!isSpecial && !qRaw.includes('bronce') && !qRaw.includes('plata') && !qRaw.includes('bronze') && !qRaw.includes('silver') && media >= 80);

    return (isOro && media >= 90) || (isSpecial && media >= 87);
  };

  // Ordenar cartas: priorizar cartas que activan la animación tocha, y luego por media descendente
  const sorted = [...cards].sort((a, b) => {
    const aImp = checkCardImportant(a) ? 1 : 0;
    const bImp = checkCardImportant(b) ? 1 : 0;
    if (aImp !== bImp) return bImp - aImp;
    return (Number(b.media) || 0) - (Number(a.media) || 0);
  });
  const top = sorted[0] || null;

  const isImportantCard = checkCardImportant(top);
  const qualityTheme = getQualityRevealTheme(top);
  const cardProvenance = String(top?.procedencia || top?.origen || top?.source || '').trim();
  const cardOwner = String(top?.owner || '').trim();

  // Variable para controlar si se debe saltar la animación
  let skipAnimation = false;
  let animationTimeouts = [];
  let animationFinished = false;
  let splitWhooshTimeout = null;
  let activeArcaneHum = null;
  let impactTimeout = null;
  let humStartTimeout = null;
  let riserTimeout = null;
  let humFadeInterval = null;
  let removeContinueListeners = null;
  let resolveSpecialContinue = null;

  const fadeArcaneHumTo = (targetMultiplier = 0.2, durationMs = 520) => {
    const targetVolume = Math.max(0, Math.min(1, sfxVolume * targetMultiplier));
    if (humFadeInterval) {
      clearInterval(humFadeInterval);
      humFadeInterval = null;
    }

    if (!activeArcaneHum) {
      activeArcaneHum = playSFX('packArcaneHum', { volumeMultiplier: targetMultiplier, loop: true });
      return;
    }

    const steps = 10;
    const stepDuration = Math.max(20, Math.floor(durationMs / steps));
    const startVolume = Number(activeArcaneHum.volume) || 0;
    let currentStep = 0;

    humFadeInterval = setInterval(() => {
      currentStep += 1;
      if (!activeArcaneHum) {
        clearInterval(humFadeInterval);
        humFadeInterval = null;
        return;
      }
      const ratio = currentStep / steps;
      activeArcaneHum.volume = startVolume + (targetVolume - startVolume) * ratio;

      if (currentStep >= steps) {
        clearInterval(humFadeInterval);
        humFadeInterval = null;
      }
    }, stepDuration);
  };

  const stopArcaneHum = (fadeMs = 260) => {
    if (humFadeInterval) {
      clearInterval(humFadeInterval);
      humFadeInterval = null;
    }
    if (activeArcaneHum) {
      stopSFX(activeArcaneHum, fadeMs);
      activeArcaneHum = null;
    }
  };

  const waitForSpecialContinue = () => {
    return new Promise((resolve) => {
      if (skipAnimation || animationFinished || !packOverlay) {
        resolve();
        return;
      }

      const continueHandler = () => {
        if (resolveSpecialContinue) {
          resolveSpecialContinue();
        }
      };

      removeContinueListeners = () => {
        packOverlay.removeEventListener('click', continueHandler, true);
        specialRevealContinueHint?.removeEventListener('click', continueHandler, true);
        removeContinueListeners = null;
      };

      resolveSpecialContinue = () => {
        const resolver = resolve;
        resolveSpecialContinue = null;
        removeContinueListeners?.();
        resolver();
      };

      packOverlay.addEventListener('click', continueHandler, true);
      specialRevealContinueHint?.addEventListener('click', continueHandler, true);
    });
  };

  const cleanupPackSFX = () => {
    if (splitWhooshTimeout) {
      clearTimeout(splitWhooshTimeout);
      splitWhooshTimeout = null;
    }
    if (humStartTimeout) {
      clearTimeout(humStartTimeout);
      humStartTimeout = null;
    }
    if (riserTimeout) {
      clearTimeout(riserTimeout);
      riserTimeout = null;
    }
    if (impactTimeout) {
      clearTimeout(impactTimeout);
      impactTimeout = null;
    }
    if (resolveSpecialContinue) {
      resolveSpecialContinue();
    }
    removeContinueListeners?.();
    if (specialRevealContinueHint) specialRevealContinueHint.classList.remove('show');
    stopArcaneHum(260);
  };
  
  // Función para saltar animación
  const skipHandler = () => {
    skipAnimation = true;
    cleanupPackSFX();
    // Cancelar todos los timeouts pendientes
    animationTimeouts.forEach(timeoutId => clearTimeout(timeoutId));
    animationTimeouts = [];
    
    if (!animationFinished) {
      finishAnimation();
    }
  };
  
  // Función helper para timeout interruptible
  const interruptibleTimeout = (ms) => {
    return new Promise((resolve) => {
      if (skipAnimation) {
        resolve();
        return;
      }
      const timeoutId = setTimeout(() => {
        animationTimeouts = animationTimeouts.filter(id => id !== timeoutId);
        resolve();
      }, ms);
      animationTimeouts.push(timeoutId);
    });
  };
  
  // Añadir listener al botón saltar
  skipAnimationBtn?.addEventListener('click', skipHandler);

  // Secuencia de overlay: rectángulo del tamaño de la carta + split + línea inferior + pausa + revelado lento con máscara (imagen estática)
  if (sorted.length > 0) {
    const placeholderTop = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="300" height="420"><rect width="100%" height="100%" fill="#222"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#ccc" font-family="Arial" font-size="22">Carta</text></svg>');
    packCardImg.onerror = () => { if (packCardImg.src !== placeholderTop) packCardImg.src = placeholderTop; };
    packCardImg.src = top.imageUrl || placeholderTop;
    if (packCardMaskImg) {
      packCardMaskImg.onerror = () => {
        if (packCardMaskImg.src !== qualityTheme.maskFallbackImage && !packCardMaskImg.src.endsWith('/icon-especiales.png') && !packCardMaskImg.src.endsWith('/icono.png') && !packCardMaskImg.src.endsWith('/icon-oro.png')) {
          packCardMaskImg.src = qualityTheme.maskFallbackImage || './assets/qualities/oro.png';
        }
      };
      packCardMaskImg.src = qualityTheme.maskImage;
      packCardMaskImg.style.display = 'none';
      packCardMaskImg.style.opacity = '0';
      packCardMaskImg.style.clipPath = 'inset(0 0 0 0)';
      packCardMaskImg.classList.remove('mask-fade-in');
    }

    packOverlay.classList.remove('quality-bronce', 'quality-plata', 'quality-oro', 'quality-icono', 'quality-evo', 'important-card-event');
    packOverlay.classList.add(qualityTheme.overlayClass);
    applyPackOpeningTheme(packOpeningTheme);
    packOverlay.classList.add('show');

    // Whoosh ~1s antes del inicio visual del split para cuadrar mejor la apertura
    splitWhooshTimeout = setTimeout(() => {
      if (!skipAnimation && !animationFinished) {
        playSFX('packSplitWhoosh', { volumeMultiplier: 0.9 });
      }
      splitWhooshTimeout = null;
    }, 700);
    
    // 1) pausa inicial con rectángulo morado completo (vertical)
    await interruptibleTimeout(1200);
    if (skipAnimation) return;
    
    // 2) split con chispas (más épico)
    spawnSparks(36, { color: packOpeningTheme.sparkColor, size: 5, spread: 240, duration: 1300 });
    packBody?.classList.add('opening');
    if (isImportantCard) {
      humStartTimeout = setTimeout(() => {
        if (!skipAnimation && !animationFinished && !activeArcaneHum) {
          activeArcaneHum = playSFX('packArcaneHum', { volumeMultiplier: 0.55, loop: true });
        }
        humStartTimeout = null;
      }, 1000);
    }
    await interruptibleTimeout(420);
    if (skipAnimation) return;

    spawnSparks(26, { color: packOpeningTheme.sparkColor, size: 4, spread: 210, duration: 1200 });
    await interruptibleTimeout(680);
    if (skipAnimation) return;

    // 3) evento especial para cartas importantes (media >= 90) ANTES del reveal
    if (isImportantCard) {
      packOverlay.classList.add('important-card-event');
      spawnSparks(72, { color: packOpeningTheme.sparkColor, size: 6, spread: 280, duration: 1700 });
      await interruptibleTimeout(650);
      if (skipAnimation) return;

      spawnSparks(44, { color: packOpeningTheme.sparkColor, size: 5, spread: 240, duration: 1500 });
      await interruptibleTimeout(1150);
      if (skipAnimation) return;

      // Pausa épica extra: sobre quieto/agitando en zona morada antes de icon-calidad
      await interruptibleTimeout(2200);
      if (skipAnimation) return;
    }
    
    // 4) carta visible. Si es importante, primero aparece icon-calidad y luego reveal normal.
    packCardImg.style.transform = 'none';
    
    if (isImportantCard && packCardMaskImg) {
      packCard.classList.add('show');
      packCardImg.style.clipPath = 'inset(0 0 0 0)';
      packCardImg.style.opacity = '0';
      packCardMaskImg.style.display = 'block';
      packCardMaskImg.style.opacity = '0';
      packCardMaskImg.style.clipPath = 'inset(0 0 0 0)';
      packCardMaskImg.style.animation = 'maskFadeIn 4.2s ease forwards';

      // Icon-calidad tarda varios segundos en aparecer por completo
      await interruptibleTimeout(4200);
      if (skipAnimation) return;

      // Pequeña pausa manteniendo icon-calidad
      await interruptibleTimeout(1200);
      if (skipAnimation) return;

      if (specialRevealBanner) {
        // Nombre en mayúscula en el recuadro
        specialRevealBanner.textContent = (cardProvenance || 'PROCEDENCIA DESCONOCIDA').toUpperCase();
        specialRevealBanner.classList.add('show');
        playSFX('packSparkle', { volumeMultiplier: 0.72 });
      }

      // Esperar a que se vea completo el primer recuadro
      await interruptibleTimeout(2400);
      if (skipAnimation) return;

      // Segundo recuadro (owner) debajo del sobre, misma duración de aparición
      if (specialRevealOwnerBanner) {
        specialRevealOwnerBanner.textContent = (cardOwner || 'OWNER DESCONOCIDO').toUpperCase();
        specialRevealOwnerBanner.classList.add('show');
        playSFX('packChime', { volumeMultiplier: 0.76 });
      }

      // Esperar a que el segundo recuadro se vea completo
      await interruptibleTimeout(2400);
      if (skipAnimation) return;

      packCardMaskImg.style.animation = 'maskFadeOutSlow 1.9s ease forwards';
      await interruptibleTimeout(1900);
      if (skipAnimation) return;

      packCardMaskImg.style.display = 'none';
      packCardMaskImg.style.opacity = '';
      packCardMaskImg.style.clipPath = '';
      packCardMaskImg.style.animation = '';
      packCardMaskImg.classList.remove('mask-fade-in');

      // Mantener hum pero más bajo para priorizar riser/impact
      fadeArcaneHumTo(0.14, 700);

      // Reveal de carta exactamente como sobres normales
      packCard.classList.add('peek-line');
      await interruptibleTimeout(800);
      if (skipAnimation) return;

      // La carta original aparece justo al comenzar el reveal lento
      packCardImg.style.opacity = '1';
      riserTimeout = setTimeout(() => {
        if (!skipAnimation && !animationFinished) {
          playSFX('packRiser', { volumeMultiplier: 0.9 });
        }
        riserTimeout = null;
      }, 500);
      packCard.classList.add('reveal-up');
      impactTimeout = setTimeout(() => {
        if (!skipAnimation && !animationFinished) {
          playSFX('packImpact', { volumeMultiplier: 0.92 });
        }
        impactTimeout = null;
      }, 8200);
      await interruptibleTimeout(12200);
      if (skipAnimation) return;

      if (specialRevealContinueHint) specialRevealContinueHint.classList.add('show');
      await waitForSpecialContinue();
      if (skipAnimation) return;
    } else {
      // 5) mostrar solo la línea inferior de píxeles
      packCardImg.style.opacity = '1';
      packCardImg.style.clipPath = 'inset(99% 0 0 0)';
      packCard.classList.add('show', 'peek-line');
      await interruptibleTimeout(800);
      if (skipAnimation) return;
      
      // 6) revelado lento desde abajo hacia arriba (aumenta la máscara, imagen no se mueve)
      packCard.classList.add('reveal-up');
      await interruptibleTimeout(12200);
      if (skipAnimation) return;
    }
    
    finishAnimation();
  }
  
  function finishAnimation() {
    if (animationFinished) return;
    animationFinished = true;
    cleanupPackSFX();
    
    // Cancelar timeouts pendientes
    animationTimeouts.forEach(timeoutId => clearTimeout(timeoutId));
    animationTimeouts = [];
    
    // Remover listener
    skipAnimationBtn?.removeEventListener('click', skipHandler);
    
    // Mostrar carta completamente (forzar visibilidad)
    packCard.classList.add('show');
    packCard.style.visibility = 'visible';
    packCard.style.opacity = '1';
    packCardImg.style.transform = 'none';
    packCardImg.style.clipPath = 'none';
    packCardImg.style.visibility = 'visible';
    packCardImg.style.opacity = '1';
    if (packCardMaskImg) {
      packCardMaskImg.style.display = 'none';
      packCardMaskImg.style.opacity = '';
      packCardMaskImg.style.clipPath = '';
      packCardMaskImg.classList.remove('mask-fade-in');
    }
    
    // Detener animaciones CSS
    packCard.classList.remove('reveal-up', 'peek-line', 'reveal-quality-mask', 'reveal-quality-mask-slow');
    packCardImg.style.animation = 'none';
    
    // permitir zoom
    packCard.onclick = () => openLightbox(packCardImg.src);
    
    setTimeout(() => {
      // limpiar
      packOverlay.classList.remove('show');
      packOverlay.classList.remove('quality-bronce', 'quality-plata', 'quality-oro', 'quality-icono', 'quality-evo', 'important-card-event');
      if (specialRevealBanner) specialRevealBanner.classList.remove('show');
      if (specialRevealOwnerBanner) specialRevealOwnerBanner.classList.remove('show');
      packCard.classList.remove('show', 'peek-line', 'reveal-up', 'peek-bottom', 'reveal-slow', 'peek-20', 'reveal-go', 'reveal-quality-mask', 'reveal-quality-mask-slow');
      packCardImg.style.clipPath = '';
      packCardImg.style.animation = '';
      if (packCardMaskImg) {
        packCardMaskImg.style.display = 'none';
        packCardMaskImg.style.opacity = '';
        packCardMaskImg.style.clipPath = '';
        packCardMaskImg.classList.remove('mask-fade-in');
      }
      if (specialRevealBanner) specialRevealBanner.textContent = '';
      if (specialRevealOwnerBanner) specialRevealOwnerBanner.textContent = '';
      if (specialRevealContinueHint) specialRevealContinueHint.classList.remove('show');
      packOverlay.classList.remove('important-card-event');
      packBody?.classList.remove('opening');
      clearPackOpeningTheme();
      clearSparks();
      
      // Mostrar cartas obtenidas
      showPackResults(sorted);
    }, 1000);
  }

}

function getQualityRevealTheme(card) {
  const qualityRaw = String(card?.calidadId || card?.calidad || card?.quality || '').toLowerCase().trim();
  const media = Number(card?.media) || 0;

  // Preservar exactamente el funcionamiento especial de Evo
  if (qualityRaw === 'evo' || qualityRaw.includes('evo')) {
    return {
      overlayClass: 'quality-evo',
      sparkColor: '#c084fc',
      maskImage: './assets/qualities/icono.png',
      maskFallbackImage: './icon-especiales.png'
    };
  }

  // Buscar en lista global de calidades dinámicas
  const qualitiesList = window.appQualities || window.appQualitiesCache || [];
  if (Array.isArray(qualitiesList) && qualitiesList.length > 0) {
    const qClean = qualityRaw.replace(/[\s\-_]/g, '');
    const qObj = qualitiesList.find(q => {
      const idClean = String(q.id || '').toLowerCase().replace(/[\s\-_]/g, '');
      const nameClean = String(q.name || '').toLowerCase().replace(/[\s\-_]/g, '');
      return idClean === qClean || nameClean === qClean || q.id === qualityRaw || q.name === qualityRaw;
    });
    if (qObj) {
      const rawMask = qObj.maskImage || qObj.image || './assets/qualities/icono.png';
      const maskUrl = typeof normalizeAssetUrl === 'function' ? normalizeAssetUrl(rawMask) : rawMask;
      const isOroQuality = qObj.id === 'oro' || String(qObj.name || '').toLowerCase() === 'oro';
      const isPlataQuality = qObj.id === 'plata' || String(qObj.name || '').toLowerCase() === 'plata';
      const isBronceQuality = qObj.id === 'bronce' || String(qObj.name || '').toLowerCase() === 'bronce';
      const fallback = isOroQuality ? './icon-oro.png' : (isPlataQuality ? './icon-plata.png' : (isBronceQuality ? './icon-bronce.png' : './icon-especiales.png'));
      return {
        overlayClass: `quality-${qObj.id || 'icono'}`,
        sparkColor: qObj.sparkColor || qObj.color || (qObj.special ? '#f8fafc' : '#fbbf24'),
        maskImage: maskUrl,
        maskFallbackImage: fallback
      };
    }
  }

  // Fallbacks conocidos por clave
  let key = 'bronce';
  if (qualityRaw.includes('heroe') || qualityRaw.includes('héroe')) key = 'heroe';
  else if (qualityRaw.includes('super') && qualityRaw.includes('prime')) key = 'icono';
  else if (qualityRaw.includes('icon') || qualityRaw.includes('prime') || qualityRaw.includes('especial')) key = 'icono';
  else if (qualityRaw.includes('oro') || qualityRaw.includes('gold')) key = 'oro';
  else if (qualityRaw.includes('plata') || qualityRaw.includes('silver')) key = 'plata';
  else if (qualityRaw.includes('bronce') || qualityRaw.includes('bronze')) key = 'bronce';
  else if (media >= 80) key = 'oro';
  else if (media >= 70) key = 'plata';

  const byKey = {
    bronce: {
      overlayClass: 'quality-bronce',
      sparkColor: '#d97706',
      maskImage: './assets/qualities/bronce.png',
      maskFallbackImage: './icon-bronce.png'
    },
    plata: {
      overlayClass: 'quality-plata',
      sparkColor: '#cbd5e1',
      maskImage: './assets/qualities/plata.png',
      maskFallbackImage: './icon-plata.png'
    },
    oro: {
      overlayClass: 'quality-oro',
      sparkColor: '#fbbf24',
      maskImage: './assets/qualities/oro.png',
      maskFallbackImage: './icon-oro.png'
    },
    icono: {
      overlayClass: 'quality-icono',
      sparkColor: '#f8fafc',
      maskImage: './assets/qualities/icono.png',
      maskFallbackImage: './icon-icono.png'
    },
    heroe: {
      overlayClass: 'quality-heroe',
      sparkColor: '#ff007a',
      maskImage: './assets/qualities/heroe.png',
      maskFallbackImage: './icon-heroe.png'
    }
  };

  return byKey[key] || {
    overlayClass: `quality-${key}`,
    sparkColor: '#f8fafc',
    maskImage: `./assets/qualities/${key}.png`,
    maskFallbackImage: `./icon-${key}.png`
  };
}

async function showPackResults(sorted) {
  loadPendingPackCards();

  // Si la opción de autoguardar está activada en ajustes
  if (typeof isAutoSavePackCardsEnabled === 'function' && isAutoSavePackCardsEnabled()) {
    await handleSaveAll(true);
    if (typeof updateGlobalNotificationBadges === 'function') {
      updateGlobalNotificationBadges();
    }
    return;
  }

  // Mostrar cartas obtenidas con animación de revelado progresivo (todas las acumuladas)
  const obtainedSection = document.getElementById('obtained-cards-section');
  if (obtainedSection) obtainedSection.style.display = 'block';

  // Obtener inventario actual para determinar cuáles cartas ya posee el jugador
  let ownedCards = {};
  try {
    const inv = await window.kvrcards.getInventory();
    if (inv && inv.ok && inv.cards) {
      ownedCards = inv.cards;
    }
  } catch (e) {
    console.warn('[PACKS] Error obteniendo inventario para repetidos:', e);
  }

  // Rastrear cartas vistas dentro de este mismo sobre para marcar si salen duplicadas dentro del paquete
  const seenInPack = {};

  cardsDiv.innerHTML = '';
  const cardsToRender = (pendingCards && pendingCards.length > 0) ? pendingCards : sorted;
  for (const card of cardsToRender) {
    const cardId = card.id;
    const isDuplicate = (Number(ownedCards[cardId]) > 0) || (Number(seenInPack[cardId]) > 0);
    seenInPack[cardId] = (seenInPack[cardId] || 0) + 1;

    const div = document.createElement('div');
    div.className = 'card reveal' + (isDuplicate ? ' card-duplicate' : '');
    
    const img = document.createElement('img');
    const placeholder = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="280"><rect width="100%" height="100%" fill="#222"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#ccc" font-family="Arial" font-size="18">Carta</text></svg>');
    img.onerror = () => { if (img.src !== placeholder) img.src = placeholder; };
    img.src = (typeof normalizeAssetUrl === 'function' ? normalizeAssetUrl(card.imageUrl) : card.imageUrl) || placeholder;
    img.alt = card.name;
    img.addEventListener('click', () => openLightbox(img.src));
    div.appendChild(img);

    // Si es repetida, agregar indicador dorado '(Repetido)' en lugar del texto antiguo de nombre/media
    if (isDuplicate) {
      const repTag = document.createElement('div');
      repTag.className = 'card-duplicate-tag';
      repTag.textContent = '(Repetido)';
      div.appendChild(repTag);
    }

    cardsDiv.appendChild(div);
    await new Promise(r => setTimeout(r, 200));
    div.classList.add('revealed');
  }

  // Mostrar botones de acción
  if (saveAllBtn) saveAllBtn.style.display = 'inline-block';
  if (sellAllBtn) sellAllBtn.style.display = 'inline-block';

  // Actualizar visualización de sobres poseídos y badges
  await renderOwnedPacks();
  if (typeof updateGlobalNotificationBadges === 'function') {
    updateGlobalNotificationBadges();
  }
}

function spawnSparks(n = 20, options = {}) {
  if (!sparksEl) return;
  const color = options.color || '#fbbf24';
  const size = options.size || 4;
  const spread = options.spread || 180;
  const duration = options.duration || 1200;
  const rect = sparksEl.getBoundingClientRect();
  const width = (rect && rect.width > 0) ? rect.width : window.innerWidth;
  const height = (rect && rect.height > 0) ? rect.height : window.innerHeight;

  for (let i = 0; i < n; i++) {
    const s = document.createElement('div');
    s.className = 'spark';
    s.style.setProperty('--spark-color', color);
    s.style.width = `${size}px`;
    s.style.height = `${size}px`;
    s.style.animationDuration = `${duration}ms`;
    const sx = Math.random() * width * 0.5 + width * 0.25;
    const sy = Math.random() * height * 0.5 + height * 0.25;
    const dx = (Math.random() - 0.5) * spread;
    const dy = 100 + Math.random() * 160;
    s.style.setProperty('--sx', `${sx}px`);
    s.style.setProperty('--sy', `${sy}px`);
    s.style.setProperty('--dx', `${dx}px`);
    s.style.setProperty('--dy', `${dy}px`);
    sparksEl.appendChild(s);
    setTimeout(() => {
      if (s.parentNode) s.remove();
    }, duration);
  }
}

function clearSparks() {
  if (sparksEl) sparksEl.innerHTML = '';
}

// Funciones para guardar/vender cartas del sobre
async function handleSaveAll(silent = false) {
  loadPendingPackCards();
  if (!isElectron || pendingCardIds.length === 0) return;

  let inventoryBeforeSave = {};
  try {
    const invBefore = await window.kvrcards.getInventory();
    if (invBefore?.ok) {
      inventoryBeforeSave = invBefore.cards || {};
    }
  } catch {}

  const receivedCardsCount = pendingCards.reduce((acc, card) => {
    const cardId = normalizePrestigeCardId(card?.id);
    if (!cardId) return acc;
    acc[cardId] = (acc[cardId] || 0) + 1;
    return acc;
  }, {});
  
  const { ok, error } = await window.kvrcards.savePackCards(pendingCardIds);
  if (!ok) {
    if (!silent) alert(error || 'Error al guardar cartas');
    return;
  }

  try {
    await applyDuplicatePrestigeXp(receivedCardsCount, inventoryBeforeSave);
  } catch (e) {
    console.warn('[PRESTIGE] No se pudo aplicar XP por duplicados del sobre:', e?.message || e);
  }
  
  // Las estadísticas se incrementan automáticamente en el backend
  console.log('[CARDS] Cartas guardadas, estadísticas actualizadas en backend');
  
  // Limpiar estado y persistencia
  clearPendingPackCards();
  
  // Ocultar botones y sección
  if (saveAllBtn) saveAllBtn.style.display = 'none';
  if (sellAllBtn) sellAllBtn.style.display = 'none';
  const obtainedSection = document.getElementById('obtained-cards-section');
  if (obtainedSection) obtainedSection.style.display = 'none';
  
  // Limpiar cartas mostradas
  cardsDiv.innerHTML = '';
  
  // Refrescar colección y actualizar misiones
  await Promise.all([
    renderCollection(),
    updateMissionsProgress(),
    renderOwnedPacks()
  ]);
  
  if (!silent) {
    alert('¡Cartas guardadas correctamente!');
  }
}

async function handleSellAllPrompt() {
  loadPendingPackCards();
  if (!isElectron || pendingCards.length === 0) return;
  
  // Calcular valor total
  const totalValue = pendingCards.reduce((sum, card) => sum + (card.valor || 10), 0);
  
  // Mostrar modal de confirmación
  sellAllMessage.textContent = `Vas a vender ${pendingCards.length} carta${pendingCards.length > 1 ? 's' : ''}:`;
  sellAllValue.innerHTML = `Obtendrás: ${coinIcon(totalValue)}`;
  sellAllModal?.classList.add('show');
}

async function handleSellAllConfirm() {
  loadPendingPackCards();
  if (!isElectron || pendingCardIds.length === 0) return;
  
  const { ok, totalValue, newBalance, error } = await window.kvrcards.sellAllPackCards(pendingCardIds);
  
  if (!ok) {
    alert(error || 'Error al vender cartas');
    return;
  }
  
  // Las estadísticas se incrementan automáticamente en el backend
  console.log('[SELL] Cartas vendidas por', totalValue, 'coins. Estadísticas actualizadas en backend');
  
  // Cerrar modal
  sellAllModal?.classList.remove('show');
  
  // Limpiar estado y persistencia
  clearPendingPackCards();
  
  // Ocultar botones y sección
  if (saveAllBtn) saveAllBtn.style.display = 'none';
  if (sellAllBtn) sellAllBtn.style.display = 'none';
  const obtainedSection = document.getElementById('obtained-cards-section');
  if (obtainedSection) obtainedSection.style.display = 'none';
  
  // Limpiar cartas mostradas
  cardsDiv.innerHTML = '';
  
  // Refrescar wallet y actualizar misiones
  await Promise.all([
    renderWallet(),
    updateMissionsProgress()
  ]);
  
  alert(`¡Cartas vendidas! Has ganado ${totalValue} coins.`);
}

// Funciones de códigos canjeables
async function handleRedeemCode() {
  if (!isElectron) return;
  
  const code = codeInput?.value?.trim();
  if (!code) {
    showCodeMessage('Por favor, introduce un código', 'error');
    return;
  }
  
  // Deshabilitar botón mientras procesa
  if (redeemCodeBtn) redeemCodeBtn.disabled = true;
  
  const res = await window.kvrcards.redeemCode(code);
  
  // Rehabilitar botón
  if (redeemCodeBtn) redeemCodeBtn.disabled = false;
  
  if (!res.ok) {
    showCodeMessage(res.error || 'Error al canjear código', 'error');
    return;
  }
  
  // Las estadísticas se incrementan automáticamente en el backend
  console.log('[CODE] Código canjeado. Recompensas:', res.rewards);
  
  // Éxito
  const rewardsText = res.rewards && res.rewards.length > 0 ? res.rewards.join(', ') : 'Recompensas recibidas';
  showCodeMessage(`✅ ${res.description}! Has recibido: ${rewardsText}`, 'success');
  
  // Si es Bendición del Supporter, mostrar la animación especial
  if (res.isBlessing) {
    const blessingModal = document.getElementById('blessing-claimed-modal');
    if (blessingModal) {
      const daysCountEl = document.getElementById('blessing-modal-days-count');
      const statusEl = document.getElementById('blessing-modal-claim-status');
      
      const totalDays = res.daysRemaining || (res.blessingState?.daysRemaining) || 30;
      if (daysCountEl) {
        daysCountEl.textContent = `${totalDays}`;
      }

      if (statusEl) {
        if (res.canClaimToday === false) {
          statusEl.style.color = '#fde047';
          statusEl.textContent = 'ℹ️ Ya has reclamado los 30 KvR de hoy. Los 30 días se han acumulado y podrás volver a reclamar mañana a partir de las 06:00 AM (hora Madrid).';
        } else {
          statusEl.style.color = '#86efac';
          statusEl.textContent = '✨ ¡Tienes tus 30 KvR diarios de hoy listos para reclamar ahora en el desplegable de tu perfil!';
        }
      }

      blessingModal.classList.add('show');
      const okBtn = document.getElementById('blessing-claimed-ok-btn');
      const closeBlessing = () => blessingModal.classList.remove('show');
      okBtn?.addEventListener('click', closeBlessing, { once: true });
      blessingModal.addEventListener('click', (e) => {
        if (e.target === blessingModal) closeBlessing();
      }, { once: true });
    }
  } else {
    // Si es un código regular, mostrar el HUD unificado de recompensas
    const itemsToShow = (Array.isArray(res.structuredRewards) && res.structuredRewards.length > 0)
      ? res.structuredRewards
      : (Array.isArray(res.rewards) ? res.rewards.map(r => ({ name: r })) : []);
    
    if (typeof window.showUnifiedRewardsHUD === 'function' && itemsToShow.length > 0) {
      await window.showUnifiedRewardsHUD(itemsToShow, '¡CÓDIGO CANJEADO!');
    }
  }

  // Limpiar input
  if (codeInput) codeInput.value = '';
  
  // Recargar códigos canjeados
  await loadRedeemedCodes();

  // Actualizar interfaz de la bendición en el perfil
  if (typeof window.updateProfileBlessingUI === 'function') {
    window.updateProfileBlessingUI();
  }
  
  // Actualizar wallet y vistas
  await Promise.all([renderWallet(), renderCollection(), renderOwnedPacks()]);
}

// ========================================
// GAMBLING - MINIJUEGO HIGHER OR LOWER
// ========================================

let currentHolCurrency = 'coins';
let holGameSession = null;

function updateHolModalBalances() {
  const coinsAmt = document.getElementById('wallet-coins-amt')?.textContent || '0';
  const kvrAmt = document.getElementById('wallet-kvr-amt')?.textContent || '0';
  
  const modalCoins = document.getElementById('hol-balance-coins-val');
  const modalKvr = document.getElementById('hol-balance-kvr-val');
  if (modalCoins) modalCoins.textContent = coinsAmt;
  if (modalKvr) modalKvr.textContent = kvrAmt;
}

window.openHigherOrLowerModal = function() {
  const modal = document.getElementById('gambling-hol-modal');
  if (!modal) return;
  
  console.log('[GAMBLING] Abriendo Higher or Lower');
  modal.classList.add('active');
  
  // Ocultar panel de Gambling de fondo para inmersión total
  const gamblingPanel = document.getElementById('gambling-panel');
  if (gamblingPanel) gamblingPanel.style.display = 'none';
  
  // Resetear estados visuales iniciales
  document.getElementById('hol-bet-screen').style.display = 'flex';
  document.getElementById('hol-game-screen').style.display = 'none';
  document.getElementById('hol-bet-amount').value = '';
  document.getElementById('hol-bet-error').style.display = 'none';
  document.getElementById('hol-start-game-btn').disabled = true;
  
  // Seleccionar moneda por defecto (coins) y actualizar saldos
  selectHolCurrency('coins');
  updateHolModalBalances();

  if (window.DiscordPresence) {
    window.DiscordPresence.setGambling('Higher or Lower');
  }
};

window.closeHigherOrLowerModal = function() {
  const modal = document.getElementById('gambling-hol-modal');
  if (!modal) return;
  
  // Si hay una sesión activa de juego, advertir de que perderá todo
  if (holGameSession) {
    const confirmClose = confirm('⚠️ Si cierras el juego ahora, perderás tu apuesta y racha actual. ¿Estás seguro?');
    if (!confirmClose) return;
  }
  
  console.log('[GAMBLING] Cerrando Higher or Lower');
  modal.classList.remove('active');
  holGameSession = null;
  
  // Volver a abrir el panel de Gambling
  const gamblingPanel = document.getElementById('gambling-panel');
  if (gamblingPanel) gamblingPanel.style.display = 'block';

  if (window.DiscordPresence) {
    window.DiscordPresence.setGambling('Seleccion de Juego');
  }
};

window.selectHolCurrency = function(type) {
  currentHolCurrency = type;
  
  const coinsBtn = document.getElementById('hol-bet-coins-btn');
  const kvrBtn = document.getElementById('hol-bet-kvr-btn');
  const minHint = document.getElementById('hol-min-bet-text');
  
  if (type === 'coins') {
    coinsBtn.classList.add('active');
    kvrBtn.classList.remove('active');
    minHint.textContent = 'Mínimo: 1000 Coins';
  } else {
    kvrBtn.classList.add('active');
    coinsBtn.classList.remove('active');
    minHint.textContent = 'Mínimo: 10 KVR';
  }
  
  validateHolBetInput();
};

window.validateHolBetInput = function() {
  const inputEl = document.getElementById('hol-bet-amount');
  const startBtn = document.getElementById('hol-start-game-btn');
  const errorEl = document.getElementById('hol-bet-error');
  
  const amount = parseInt(inputEl.value) || 0;
  const minBet = currentHolCurrency === 'coins' ? 1000 : 10;
  
  errorEl.style.display = 'none';
  
  if (amount >= minBet) {
    startBtn.disabled = false;
  } else {
    startBtn.disabled = true;
  }
};

// Obtener URL base para la API de Gambling adaptándonos a Electron
async function getGamblingBaseUrl() {
  if (window.kvrcards && typeof window.kvrcards.getInventoryServerInfo === 'function') {
    try {
      const serverInfo = await window.kvrcards.getInventoryServerInfo();
      if (serverInfo && serverInfo.ok && serverInfo.effectiveBaseUrl) {
        let base = serverInfo.effectiveBaseUrl;
        if (base.endsWith('/')) {
          base = base.slice(0, -1);
        }
        return base;
      }
    } catch (e) {
      console.error('[GAMBLING] Error al obtener getInventoryServerInfo:', e);
    }
  }
  // Fallback si estamos en Electron pero falló serverInfo
  if (window.kvrcards) {
    return 'http://localhost:4321';
  }
  // En navegador tradicional, usar relative path (vacío)
  return '';
}

window.startHigherOrLowerGame = async function() {
  const inputEl = document.getElementById('hol-bet-amount');
  const amount = parseInt(inputEl.value) || 0;
  const startBtn = document.getElementById('hol-start-game-btn');
  const errorEl = document.getElementById('hol-bet-error');
  
  if (!currentUser) {
    alert('Debes iniciar sesión para poder apostar');
    return;
  }
  
  startBtn.disabled = true;
  errorEl.style.display = 'none';
  
  try {
    const baseUrl = await getGamblingBaseUrl();
    const response = await fetch(`${baseUrl}/api/gambling/start/${currentUser}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        betType: currentHolCurrency,
        betAmount: amount
      })
    });
    
    const result = await response.json();
    
    if (!response.ok || !result.ok) {
      errorEl.textContent = result.error || 'Error al iniciar la apuesta';
      errorEl.style.display = 'block';
      startBtn.disabled = false;
      return;
    }
    
    console.log('[GAMBLING] ¡Apuesta iniciada con éxito!', result);
    
    // Resetear racha visual
    document.getElementById('hol-streak-count-val').textContent = '0';
    
    // Crear sesión local
    holGameSession = {
      betType: currentHolCurrency,
      betAmount: amount,
      currentCard: result.currentCard,
      step: 1
    };
    
    // Sincronizar monedero local con el servidor de forma inmediata en Electron
    if (window.kvrcards && typeof window.kvrcards.inventoryReloadFromServer === 'function') {
      try {
        await window.kvrcards.inventoryReloadFromServer();
      } catch (syncErr) {
        console.error('[GAMBLING] Error al sincronizar inventario tras apuesta:', syncErr);
      }
    }
    
    // Actualizar monedero local en la UI
    await renderWallet();
    updateHolModalBalances();
    
    // Transición a la pantalla de juego
    document.getElementById('hol-bet-screen').style.display = 'none';
    document.getElementById('hol-game-screen').style.display = 'flex';
    
    // Ocultar botón retirada al inicio
    document.getElementById('hol-cashout-btn').style.display = 'none';
    
    // Dibujar datos iniciales de la mesa
    renderHolGameRound(result);
    
  } catch (err) {
    console.error('[GAMBLING] Error HTTP en start:', err);
    errorEl.textContent = 'Error de conexión con el servidor. Inténtalo de nuevo.';
    errorEl.style.display = 'block';
    startBtn.disabled = false;
  }
};

function renderHolGameRound(data) {
  // 1. Estadísticas y Racha
  document.getElementById('hol-racha-val').textContent = `x${(data.rachaMultiplier || 1.0).toFixed(2)}`;
  document.getElementById('hol-win-val').textContent = data.currentWin || holGameSession.betAmount;
  
  // Icono de premio correspondiente
  const winIcon = document.getElementById('hol-win-icon');
  if (holGameSession.betType === 'coins') {
    winIcon.src = './coin.png';
  } else {
    winIcon.src = './kvr.png';
  }
  
  // 2. Pista
  document.getElementById('hol-hint-label').textContent = data.hint.label;
  document.getElementById('hol-hint-value').textContent = data.hint.value;
  
  // 3. Carta de referencia actual
  const cardImg = document.getElementById('hol-current-card-img');
  const cardMedia = document.getElementById('hol-current-card-media');
  const cardName = document.getElementById('hol-current-card-name');
  
  // Asegurar que las animaciones visuales están desactivadas
  cardImg.classList.remove('win-scale', 'fail-shake');
  
  cardImg.src = data.currentCard.imageUrl || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="170" height="255"><rect width="100%" height="100%" fill="%23222"/></svg>';
  cardMedia.textContent = data.currentCard.media;
  cardName.textContent = data.currentCard.name;
  
  // 4. Botones LOWER / HIGHER con multiplicadores dinámicos
  document.getElementById('hol-lower-mult').textContent = `x${data.multipliers.lower.toFixed(2)}`;
  document.getElementById('hol-higher-mult').textContent = `x${data.multipliers.higher.toFixed(2)}`;
  
  // 5. Botón de Cashout (retirada)
  const cashoutBtn = document.getElementById('hol-cashout-btn');
  if (holGameSession.step > 1) {
    cashoutBtn.style.display = 'block';
    cashoutBtn.textContent = `RETIRARSE Y RECLAMAR: ${data.currentWin} ${holGameSession.betType.toUpperCase()}`;
  } else {
    cashoutBtn.style.display = 'none';
  }
}

window.sendHigherOrLowerGuess = async function(prediction) {
  if (!holGameSession || !currentUser) return;
  
  // Deshabilitar botones de predicción temporalmente durante animación
  const lowerBtn = document.getElementById('hol-lower-btn');
  const higherBtn = document.getElementById('hol-higher-btn');
  const cashoutBtn = document.getElementById('hol-cashout-btn');
  
  lowerBtn.disabled = true;
  higherBtn.disabled = true;
  cashoutBtn.disabled = true;
  
  try {
    const baseUrl = await getGamblingBaseUrl();
    const response = await fetch(`${baseUrl}/api/gambling/guess/${currentUser}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        prediction
      })
    });
    
    const result = await response.json();
    
    if (!response.ok || !result.ok) {
      alert(result.error || 'Error procesando tu predicción');
      lowerBtn.disabled = false;
      higherBtn.disabled = false;
      cashoutBtn.disabled = false;
      return;
    }
    
    const cardImg = document.getElementById('hol-current-card-img');
    
    if (result.win) {
      console.log('[GAMBLING] ¡ACIERTO!', result);
      
      // Animación de Acierto (Escala y destello verde)
      cardImg.classList.add('win-scale');
      if (typeof playSFX === 'function') playSFX('cardSelect'); // Efecto agradable
      
      // Actualizar racha visual
      document.getElementById('hol-streak-count-val').textContent = result.step - 1;
      
      // Actualizar sesión local
      holGameSession.step = result.step;
      holGameSession.currentCard = result.currentCard;
      
      // Esperar que termine la animación
      setTimeout(() => {
        renderHolGameRound(result);
        
        // Reactivar controles
        lowerBtn.disabled = false;
        higherBtn.disabled = false;
        cashoutBtn.disabled = false;
      }, 700);
      
    } else {
      console.log('[GAMBLING] ¡FALLO! JUEGO TERMINADO', result);
      
      // Animación de Fallo (Sacudida y resplandor rojo)
      cardImg.classList.add('fail-shake');
      if (typeof playSFX === 'function') playSFX('packSplitWhoosh'); // Efecto de corte dramático
      
      // Revelar la carta perdedora en la UI
      const cardMedia = document.getElementById('hol-current-card-media');
      const cardName = document.getElementById('hol-current-card-name');
      
      cardImg.src = result.revealedCard.imageUrl || '';
      cardMedia.textContent = result.revealedCard.media;
      cardName.textContent = `❌ REVELADA: ${result.revealedCard.name}`;
      
      // Esperar a que el jugador vea el fallo
      setTimeout(() => {
        alert(`💥 ¡Oh no! La carta era "${result.revealedCard.name}" con una media de ${result.revealedCard.media}.\n\n¡Has perdido la apuesta de ${holGameSession.betAmount} ${holGameSession.betType}!`);
        
        // Limpiar sesión local y volver a la pantalla de apuesta
        holGameSession = null;
        document.getElementById('hol-bet-screen').style.display = 'flex';
        document.getElementById('hol-game-screen').style.display = 'none';
        
        lowerBtn.disabled = false;
        higherBtn.disabled = false;
        cashoutBtn.disabled = false;
      }, 2000);
    }
    
  } catch (err) {
    console.error('[GAMBLING] Error HTTP en guess:', err);
    alert('Error al conectar con el servidor.');
    lowerBtn.disabled = false;
    higherBtn.disabled = false;
    cashoutBtn.disabled = false;
  }
};

window.cashoutHigherOrLower = async function() {
  if (!holGameSession || !currentUser) return;
  
  const confirmCashout = confirm(`¿Estás seguro de retirarte ahora y cobrar tus ganancias acumuladas?`);
  if (!confirmCashout) return;
  
  try {
    const baseUrl = await getGamblingBaseUrl();
    const response = await fetch(`${baseUrl}/api/gambling/cashout/${currentUser}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    const result = await response.json();
    
    if (!response.ok || !result.ok) {
      alert(result.error || 'Error procesando tu cobro');
      return;
    }
    
    console.log('[GAMBLING] Cobro procesado correctamente', result);
    
    alert(`🎉 ¡FELICIDADES! Te has retirado con éxito y has ganado:\n\n💎 ${result.payout} ${holGameSession.betType.toUpperCase()}`);
    
    // Limpiar sesión local y volver a la pantalla de apuesta
    holGameSession = null;
    document.getElementById('hol-bet-screen').style.display = 'flex';
    document.getElementById('hol-game-screen').style.display = 'none';
    
    // Sincronizar monedero local con el servidor de forma inmediata en Electron
    if (window.kvrcards && typeof window.kvrcards.inventoryReloadFromServer === 'function') {
      try {
        await window.kvrcards.inventoryReloadFromServer();
      } catch (syncErr) {
        console.error('[GAMBLING] Error al sincronizar inventario tras cobro:', syncErr);
      }
    }
    
    // Actualizar monedero local en la UI
    await renderWallet();
    updateHolModalBalances();
    
  } catch (err) {
    console.error('[GAMBLING] Error HTTP en cashout:', err);
    alert('Error al conectar con el servidor.');
  }
};

window.refreshGamblingLeaderboardData = async function() {
  try {
    const baseUrl = await getGamblingBaseUrl();
    const response = await fetch(`${baseUrl}/api/gambling/leaderboard`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    });
    
    const result = await response.json();
    if (result.ok && result.leaderboard) {
      renderLeaderboardTables(result.leaderboard);
    } else {
      const errorMsg = '<tr><td colspan="4" style="text-align: center; color: #ef4444;">Error al cargar datos</td></tr>';
      const errorMsg3 = '<tr><td colspan="3" style="text-align: center; color: #ef4444;">Error al cargar datos</td></tr>';
      document.getElementById('leaderboard-streak-tbody').innerHTML = errorMsg;
      document.getElementById('leaderboard-mult-tbody').innerHTML = errorMsg;
      document.getElementById('leaderboard-upgrades-tbody').innerHTML = errorMsg3;
      ['easy', 'normal', 'hard', 'impossible'].forEach(d => {
        const el = document.getElementById(`leaderboard-race-${d}-tbody`);
        if (el) el.innerHTML = errorMsg3;
      });
      ['epic', 'legendary'].forEach(r => {
        const el = document.getElementById(`leaderboard-pack-${r}-tbody`);
        if (el) el.innerHTML = errorMsg3;
      });
    }
  } catch (err) {
    console.error('[GAMBLING] Error al obtener leaderboard:', err);
    const connMsg = '<tr><td colspan="4" style="text-align: center; color: #ef4444;">Error de conexion</td></tr>';
    const connMsg3 = '<tr><td colspan="3" style="text-align: center; color: #ef4444;">Error de conexion</td></tr>';
    document.getElementById('leaderboard-streak-tbody').innerHTML = connMsg;
    document.getElementById('leaderboard-mult-tbody').innerHTML = connMsg;
    document.getElementById('leaderboard-upgrades-tbody').innerHTML = connMsg3;
    ['easy', 'normal', 'hard', 'impossible'].forEach(d => {
      const el = document.getElementById(`leaderboard-race-${d}-tbody`);
      if (el) el.innerHTML = connMsg3;
    });
    ['epic', 'legendary'].forEach(r => {
      const el = document.getElementById(`leaderboard-pack-${r}-tbody`);
      if (el) el.innerHTML = connMsg3;
    });
  }
};

window.openGamblingLeaderboard = async function() {
  const modal = document.getElementById('gambling-leaderboard-modal');
  if (!modal) return;
  
  console.log('[GAMBLING] Abriendo Leaderboard');
  modal.classList.add('active');
  
  // Resetear a categoria HIGHER OR LOWER al abrir
  if (typeof switchLeaderboardCategory === 'function') {
    switchLeaderboardCategory('hol');
  }
  
  // Limpiar tablas antes de cargar
  document.getElementById('leaderboard-streak-tbody').innerHTML = '<tr><td colspan="4" style="text-align: center;">Cargando clasificaciones...</td></tr>';
  document.getElementById('leaderboard-mult-tbody').innerHTML = '<tr><td colspan="4" style="text-align: center;">Cargando clasificaciones...</td></tr>';
  document.getElementById('leaderboard-upgrades-tbody').innerHTML = '<tr><td colspan="3" style="text-align: center;">Cargando clasificaciones...</td></tr>';
  ['easy', 'normal', 'hard', 'impossible'].forEach(d => {
    const el = document.getElementById(`leaderboard-race-${d}-tbody`);
    if (el) el.innerHTML = '<tr><td colspan="3" style="text-align: center;">Cargando clasificaciones...</td></tr>';
  });
  ['epic', 'legendary'].forEach(r => {
    const el = document.getElementById(`leaderboard-pack-${r}-tbody`);
    if (el) el.innerHTML = '<tr><td colspan="3" style="text-align: center;">Cargando clasificaciones...</td></tr>';
  });
  
  await window.refreshGamblingLeaderboardData();
};

window.closeGamblingLeaderboard = function() {
  const modal = document.getElementById('gambling-leaderboard-modal');
  if (modal) modal.classList.remove('active');
};

window.switchLeaderboardCategory = function(catType) {
  const catHol = document.getElementById('leaderboard-cat-hol');
  const catUpgrader = document.getElementById('leaderboard-cat-upgrader');
  const catCardRace = document.getElementById('leaderboard-cat-cardrace');
  const catLegendaryPack = document.getElementById('leaderboard-cat-legendarypack');
  
  const tabStreak = document.getElementById('leaderboard-tab-streak');
  const tabMult = document.getElementById('leaderboard-tab-mult');
  const tabUpgrades = document.getElementById('leaderboard-tab-upgrades');
  const tabRaceEasy = document.getElementById('leaderboard-tab-race-easy');
  const tabRaceNormal = document.getElementById('leaderboard-tab-race-normal');
  const tabRaceHard = document.getElementById('leaderboard-tab-race-hard');
  const tabRaceImpossible = document.getElementById('leaderboard-tab-race-impossible');
  const tabPackEpic = document.getElementById('leaderboard-tab-pack-epic');
  const tabPackLegendary = document.getElementById('leaderboard-tab-pack-legendary');
  
  // Set all category badges as inactive
  [catHol, catUpgrader, catCardRace, catLegendaryPack].forEach(btn => {
    if (btn) {
      btn.classList.remove('active');
      btn.style.background = 'rgba(255, 255, 255, 0.02)';
      btn.style.border = '1px solid rgba(255, 255, 255, 0.05)';
      btn.style.color = 'rgba(255, 255, 255, 0.5)';
      btn.style.boxShadow = 'none';
    }
  });

  // Set the selected one as active
  let activeBtn = null;
  if (catType === 'hol') activeBtn = catHol;
  else if (catType === 'upgrader') activeBtn = catUpgrader;
  else if (catType === 'cardrace') activeBtn = catCardRace;
  else if (catType === 'legendarypack') activeBtn = catLegendaryPack;

  if (activeBtn) {
    activeBtn.classList.add('active');
    activeBtn.style.background = 'rgba(251, 191, 36, 0.12)';
    activeBtn.style.border = '2px solid #f59e0b';
    activeBtn.style.color = '#fbbf24';
    activeBtn.style.boxShadow = '0 0 10px rgba(251, 191, 36, 0.15)';
  }

  // Hide all tabs
  [tabStreak, tabMult, tabUpgrades, tabRaceEasy, tabRaceNormal, tabRaceHard, tabRaceImpossible, tabPackEpic, tabPackLegendary].forEach(tab => {
    if (tab) tab.style.display = 'none';
  });

  // Show relevant tabs
  if (catType === 'hol') {
    if (tabStreak) tabStreak.style.display = 'inline-block';
    if (tabMult) tabMult.style.display = 'inline-block';
    switchLeaderboardTab('streak');
  } else if (catType === 'upgrader') {
    if (tabUpgrades) tabUpgrades.style.display = 'inline-block';
    switchLeaderboardTab('upgrades');
  } else if (catType === 'cardrace') {
    if (tabRaceEasy) tabRaceEasy.style.display = 'inline-block';
    if (tabRaceNormal) tabRaceNormal.style.display = 'inline-block';
    if (tabRaceHard) tabRaceHard.style.display = 'inline-block';
    if (tabRaceImpossible) tabRaceImpossible.style.display = 'inline-block';
    switchLeaderboardTab('race-easy');
  } else if (catType === 'legendarypack') {
    if (tabPackEpic) tabPackEpic.style.display = 'inline-block';
    if (tabPackLegendary) tabPackLegendary.style.display = 'inline-block';
    switchLeaderboardTab('pack-epic');
  }
};

window.switchLeaderboardTab = function(tabType) {
  const tabs = [
    'leaderboard-tab-streak', 'leaderboard-tab-mult', 'leaderboard-tab-upgrades',
    'leaderboard-tab-race-easy', 'leaderboard-tab-race-normal', 'leaderboard-tab-race-hard', 'leaderboard-tab-race-impossible',
    'leaderboard-tab-pack-epic', 'leaderboard-tab-pack-legendary'
  ];
  const panels = [
    'leaderboard-streak-panel', 'leaderboard-mult-panel', 'leaderboard-upgrades-panel',
    'leaderboard-race-easy-panel', 'leaderboard-race-normal-panel', 'leaderboard-race-hard-panel', 'leaderboard-race-impossible-panel',
    'leaderboard-pack-epic-panel', 'leaderboard-pack-legendary-panel'
  ];

  tabs.forEach(tId => {
    const el = document.getElementById(tId);
    if (el) el.classList.remove('active');
  });

  panels.forEach(pId => {
    const el = document.getElementById(pId);
    if (el) el.style.display = 'none';
  });

  const activeTabId = `leaderboard-tab-${tabType}`;
  const activePanelId = `leaderboard-${tabType}-panel`;

  const activeTab = document.getElementById(activeTabId);
  const activePanel = document.getElementById(activePanelId);

  if (activeTab) activeTab.classList.add('active');
  if (activePanel) activePanel.style.display = 'block';
};

function renderLeaderboardTables(leaderboard) {
  const streakTbody = document.getElementById('leaderboard-streak-tbody');
  const multTbody = document.getElementById('leaderboard-mult-tbody');
  
  // 1. Racha Maxima
  const streakData = leaderboard.maxStreak || [];
  if (streakTbody) {
    if (streakData.length === 0) {
      streakTbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #9ca3af;">Nadie ha conseguido una racha aun</td></tr>';
    } else {
      streakTbody.innerHTML = streakData.map((row, index) => {
        const position = index + 1;
        let medal = position;
        if (position === 1) medal = '🥇';
        else if (position === 2) medal = '🥈';
        else if (position === 3) medal = '🥉';
        
        const currencyLabel = row.betType === 'coins' ? 'Coins' : 'KVR';
        return `
          <tr>
            <td style="font-weight: bold; text-align: center;">${medal}</td>
            <td>${row.username}</td>
            <td style="text-align: center; font-weight: bold; color: #fbbf24;">${row.streak}</td>
            <td style="text-align: center; color: #9ca3af;">${row.betAmount} ${currencyLabel}</td>
          </tr>
        `;
      }).join('');
    }
  }
  
  // 2. Multiplicador Maximo
  const multData = leaderboard.maxMultiplier || [];
  if (multTbody) {
    if (multData.length === 0) {
      multTbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #9ca3af;">Nadie se ha retirado con premio aun</td></tr>';
    } else {
      multTbody.innerHTML = multData.map((row, index) => {
        const position = index + 1;
        let medal = position;
        if (position === 1) medal = '🥇';
        else if (position === 2) medal = '🥈';
        else if (position === 3) medal = '🥉';
        
        const currencyLabel = row.betType === 'coins' ? 'Coins' : 'KVR';
        return `
          <tr>
            <td style="font-weight: bold; text-align: center;">${medal}</td>
            <td>${row.username}</td>
            <td style="text-align: center; font-weight: bold; color: #fbbf24;">x${row.multiplier.toFixed(2)}</td>
            <td style="text-align: center; color: #10b981; font-weight: bold;">+${row.payout} ${currencyLabel}</td>
          </tr>
        `;
      }).join('');
    }
  }
  
  // 3. Maestros de la Mejora
  const upgradesTbody = document.getElementById('leaderboard-upgrades-tbody');
  if (upgradesTbody) {
    const upgradesData = leaderboard.maxUpgrades || [];
    if (upgradesData.length === 0) {
      upgradesTbody.innerHTML = '<tr><td colspan="3" style="text-align: center; color: #9ca3af;">Nadie ha mejorado una carta con exito aun</td></tr>';
    } else {
      upgradesTbody.innerHTML = upgradesData.map((row, index) => {
        const position = index + 1;
        let medal = position;
        if (position === 1) medal = '🥇';
        else if (position === 2) medal = '🥈';
        else if (position === 3) medal = '🥉';
        
        return `
          <tr>
            <td style="font-weight: bold; text-align: center;">${medal}</td>
            <td>${row.username}</td>
            <td style="text-align: center; font-weight: bold; color: #10b981;">${row.upgrades} cartas</td>
          </tr>
        `;
      }).join('');
    }
  }

  // 4. Carrera de Cartas (por dificultad)
  const raceDiffs = ['easy', 'normal', 'hard', 'impossible'];
  raceDiffs.forEach(diff => {
    const tbody = document.getElementById(`leaderboard-race-${diff}-tbody`);
    if (tbody) {
      const diffData = (leaderboard.cardRace && leaderboard.cardRace[diff]) || [];
      if (diffData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" style="text-align: center; color: #9ca3af;">Nadie ha ganado una carrera en esta dificultad aún</td></tr>';
      } else {
        tbody.innerHTML = diffData.map((row, index) => {
          const position = index + 1;
          let medal = position;
          if (position === 1) medal = '🥇';
          else if (position === 2) medal = '🥈';
          else if (position === 3) medal = '🥉';
          
          return `
            <tr>
              <td style="font-weight: bold; text-align: center;">${medal}</td>
              <td>${row.username}</td>
              <td style="text-align: center; font-weight: bold; color: #10b981;">${row.wins} victorias</td>
            </tr>
          `;
        }).join('');
      }
    }
  });

  // 5. Sobre Legendario (por rareza)
  const packRarities = ['epic', 'legendary'];
  packRarities.forEach(rarity => {
    const tbody = document.getElementById(`leaderboard-pack-${rarity}-tbody`);
    if (tbody) {
      const rarityData = (leaderboard.legendaryPack && leaderboard.legendaryPack[rarity]) || [];
      if (rarityData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="3" style="text-align: center; color: #9ca3af;">Nadie ha obtenido un sobre de esta rareza aún</td></tr>';
      } else {
        tbody.innerHTML = rarityData.map((row, index) => {
          const position = index + 1;
          let medal = position;
          if (position === 1) medal = '🥇';
          else if (position === 2) medal = '🥈';
          else if (position === 3) medal = '🥉';
          
          return `
            <tr>
              <td style="font-weight: bold; text-align: center;">${medal}</td>
              <td>${row.username}</td>
              <td style="text-align: center; font-weight: bold; color: #10b981;">${row.wins} sobres</td>
            </tr>
          `;
        }).join('');
      }
    }
  });
}

