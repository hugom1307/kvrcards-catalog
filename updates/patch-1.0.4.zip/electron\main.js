const { app, BrowserWindow, Menu, ipcMain, net, shell } = require('electron');
const childProcess = require('child_process');
const path = require('path');
const fs = require('fs');
const cloudSync = require('../server/cloud-sync-server');
let autoPatcher = null;
try {
  autoPatcher = require('./modules/auto-patcher');
} catch {
  try {
    autoPatcher = require('./electron/modules/auto-patcher');
  } catch (errAuto) {
    console.warn('[AUTO-PATCHER] No se pudo cargar módulo auto-patcher:', errAuto.message);
  }
}

let discordRpc = null;
try {
  discordRpc = require('./modules/discord-rpc');
} catch {
  try {
    discordRpc = require('./electron/modules/discord-rpc');
  } catch {
    try {
      discordRpc = require(path.join(__dirname, 'modules', 'discord-rpc'));
    } catch (errRpc) {
      console.warn('[DISCORD-RPC] No se pudo cargar módulo discord-rpc:', errRpc.message);
    }
  }
}

if (discordRpc && typeof discordRpc.init === 'function') {
  discordRpc.init('1553143643710296206');
}

function findWorkspaceRoot(startDir = __dirname) {
  const candidates = [
    path.resolve(startDir, '..', '..', '..', '..'),
    path.resolve(startDir, '..', '..', '..', '..', '..'),
    path.resolve(process.execPath, '..', '..'),
    process.cwd()
  ];
  for (const c of candidates) {
    if (fs.existsSync(path.join(c, 'public', 'index.html')) && fs.existsSync(path.join(c, 'package.json'))) {
      return c;
    }
  }
  return null;
}

const workspaceRoot = findWorkspaceRoot(__dirname);
const isDev = !app.isPackaged;
let isCurrentUserAdmin = false;

ipcMain.on('admin:setStatus', (_event, isAdmin) => {
  isCurrentUserAdmin = Boolean(isAdmin);
  console.log(`[ELECTRON] Estado de admin actualizado: ${isCurrentUserAdmin}`);
  if (!isCurrentUserAdmin) {
    BrowserWindow.getAllWindows().forEach(w => {
      if (w.webContents && w.webContents.isDevToolsOpened()) {
        w.webContents.closeDevTools();
      }
    });
  }
});

ipcMain.handle('admin:getStatus', () => {
  return isCurrentUserAdmin;
});

ipcMain.on('admin:openDevTools', (event) => {
  if (isCurrentUserAdmin) {
    const targetWin = BrowserWindow.fromWebContents(event.sender);
    if (targetWin) targetWin.webContents.openDevTools();
  }
});

function createWindow() {
  const isDevWorkspace = Boolean(workspaceRoot) && !process.argv.includes('--packaged-only');

  const preloadPath = isDevWorkspace && fs.existsSync(path.join(workspaceRoot, 'electron', 'preload.js'))
    ? path.join(workspaceRoot, 'electron', 'preload.js')
    : path.join(__dirname, 'preload.js');

  const iconCandidates = [
    path.join(__dirname, 'build', 'kvcards.ico'),
    path.join(__dirname, 'build', 'kvrcardslogo.ico'),
    path.join(__dirname, 'public', 'favicon.ico'),
    path.join(__dirname, 'favicon.ico'),
    path.join(__dirname, '..', 'build', 'kvcards.ico'),
    path.join(__dirname, '..', 'build', 'kvrcardslogo.ico'),
    path.join(workspaceRoot || '', 'build', 'kvcards.ico')
  ];
  const appIcon = iconCandidates.find(p => fs.existsSync(p));

  const win = new BrowserWindow({
    width: 1920,
    height: 1080,
    fullscreen: true,
    autoHideMenuBar: true,
    icon: appIcon,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: preloadPath,
      cache: false,
      enableWebSQL: false,
      spellcheck: false,
      offscreen: false,
    },
    title: 'KVRCards',
    acceptFirstMouse: true,
  });

  // Quitar completamente la barra superior de la aplicación
  win.setMenu(null);
  Menu.setApplicationMenu(null);

  // Limpiar caché de sesión al crear ventana
  win.webContents.session.clearCache();

  if (isDev) {
    const url = 'http://localhost:3000';
    win.loadURL(url);
  } else if (isDevWorkspace) {
    const devFilePath = path.join(workspaceRoot, 'public', 'index.html');
    console.log('[ELECTRON] [MODO DESARROLLO LOCAL] Cargando directamente desde:', devFilePath);
    win.loadFile(devFilePath);
  } else {
    const filePath = path.join(__dirname, '..', 'public', 'index.html');
    console.log('[ELECTRON] [MODO DISTRIBUCION] Cargando desde:', filePath);
    win.loadFile(filePath);
  }

  // Developer Tools y atajos: restringidos exclusivamente a administradores
  win.webContents.on('before-input-event', (event, input) => {
    if (input.type === 'keyDown') {
      const isDevToolsKey =
        input.key === 'F12' ||
        (input.control && input.shift && ['i', 'j', 'c'].includes(input.key.toLowerCase())) ||
        (input.control && input.key.toLowerCase() === 'u');

      if (isDevToolsKey) {
        if (!isCurrentUserAdmin) {
          event.preventDefault();
          return;
        }
        if (input.key === 'F12') {
          win.webContents.toggleDevTools();
          event.preventDefault();
          return;
        }
      } else if (input.key === 'F5' || (input.control && input.key.toLowerCase() === 'r')) {
        console.log('[ELECTRON] Recargando ventana sin cache...');
        win.webContents.reloadIgnoringCache();
      }
    }
  });

  // Menú contextual (clic derecho): Inspeccionar elemento solo para administradores
  win.webContents.on('context-menu', (event, params) => {
    if (!isCurrentUserAdmin) {
      event.preventDefault();
      return;
    }
    const contextMenu = Menu.buildFromTemplate([
      {
        label: 'Inspeccionar elemento',
        click: () => {
          win.webContents.inspectElement(params.x, params.y);
        }
      },
      {
        label: 'Abrir DevTools',
        click: () => {
          win.webContents.openDevTools();
        }
      }
    ]);
    contextMenu.popup();
  });
}

app.whenReady().then(async () => {
  // Interceptar todas las peticiones a raw.githubusercontent.com y redirigirlas a GitHub Pages CDN para evitar el rate limit 429
  try {
    const { session } = require('electron');
    session.defaultSession.webRequest.onBeforeRequest(
      { urls: ['*://raw.githubusercontent.com/*'] },
      (details, callback) => {
        const newUrl = details.url.replace(
          /^https?:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/main\/(.*)$/i,
          'https://$1.github.io/$2/$3'
        );
        if (newUrl !== details.url) {
          console.log(`[ASSET REDIRECT] ${details.url} -> ${newUrl}`);
          return callback({ redirectURL: newUrl });
        }
        callback({});
      }
    );
  } catch (e) {
    console.error('[ASSET REDIRECT ERROR]', e);
  }

  // Inicializa datos persistentes y luego crea la ventana
  await loadData();
  console.log('='.repeat(80));
  console.log('[APP INIT] remoteConfig después de loadData:', JSON.stringify(remoteConfig, null, 2));
  console.log('='.repeat(80));
  // Asegurar servidor local de inventarios si está configurado a localhost
  try { await ensureLocalInventoryServer(); } catch {}
  // Mantener vivo el servidor (reintentos periódicos si cae)
  try { startInventoryKeepAliveMonitor(); } catch {}

  const catalogBaseUrl = remoteConfig?.catalog?.baseUrl || 'https://hugom1307.github.io/kvrcards-catalog/';

  if (autoPatcher && typeof autoPatcher.checkAndApplyAutoPatch === 'function') {
    try {
      await autoPatcher.checkAndApplyAutoPatch({
        app,
        BrowserWindow,
        ipcMain,
        catalogBaseUrl,
        onLaunchGame: () => {
          createWindow();
        }
      });
    } catch (errPatcher) {
      console.error('[AUTO-PATCHER ERROR]', errPatcher);
      createWindow();
    }
  } else {
    createWindow();
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
app.on('before-quit', () => { try { if (invSyncTimer) clearInterval(invSyncTimer); } catch {} });
app.on('before-quit', () => { try { if (invServerMonitorTimer) clearInterval(invServerMonitorTimer); } catch {} });

// ---- Estado en memoria e IPC para modo offline ----
// fs ya declarado al inicio
const qualityStore = new Map(); // name/id -> quality definition
const cardStore = new Map(); // id -> card (definiciones)
const packStore = new Map(); // id -> { id, name, cardsPerPack, distribution } (plantillas)
const powerStore = new Map(); // id -> power (definiciones de poderes)
const traitStore = new Map(); // id -> trait (definiciones de rasgos)
// Inventarios por usuario (perfil)
const ownedCards = new Map(); // id -> count (colección) del usuario actual
const ownedPacks = new Map(); // id -> count (sobres disponibles) del usuario actual
const ownedPowers = new Map(); // id -> {count, uses} para poderes consumibles o {count} para permanentes
const cardTraits = new Map(); // uniqueCardId -> traitId (rasgos asignados a cartas específicas)
const packStock = new Map(); // id -> stock restante en tienda (global)
const redeemedCodes = new Set(); // códigos ya canjeados por el usuario
let supporterBlessing = null; // { active: bool, daysRemaining: number, lastClaimCycle: string, lastUpdatedCycle: string, ... }
let profile = { 
  username: '', 
  lastCommandsVersion: '',
  password: '',
  profileImage: '',
  currentTitle: '',
  unlockedTitles: ['novato'],
  showcaseCards: [null, null, null],
  resetAt: 0,
  isReset: false
};
let catalogInfo = { cardsSource: 'none', packsSource: 'none', cardsCount: 0, packsCount: 0, version: '0', remote: false };
let remoteConfig = { baseUrl: '', enabled: false, inventory: { enabled: false, baseUrl: '' }, maintenance: { enabled: false, title: '', message: '', estimatedTime: '' }, version: { current: '1.0.0', minimumRequired: '1.0.0', downloadUrl: '', changelog: '', forceUpdate: false } };
let invSyncTimer = null;
let inventoryEffectiveBaseUrl = '';
let invServerMonitorTimer = null;
let profileImageDirty = false;
let clientRankingsCache = { data: null, timestamp: 0 };
const CLIENT_RANKINGS_CACHE_TTL_MS = 45 * 1000;
const DEFAULT_WALLET = {
  coins: 0,
  kvr: 0,
  traits: 0,
  'infinite-coins': 0,
  'infinite-cardpoints': 0
};

function normalizeWallet(rawWallet) {
  const source = rawWallet && typeof rawWallet === 'object' ? rawWallet : {};
  return {
    coins: Math.max(0, Number(source.coins) || 0),
    kvr: Math.max(0, Number(source.kvr) || 0),
    traits: Math.max(0, Number(source.traits) || 0),
    'infinite-coins': Math.max(0, Number(source['infinite-coins']) || 0),
    'infinite-cardpoints': Math.max(0, Number(source['infinite-cardpoints']) || 0)
  };
}

let wallet = { ...DEFAULT_WALLET };
let lastSyncHash = null; // Hash de los datos en la última sincronización exitosa
let localUpdatedAt = Date.now(); // Timestamp de última actualización local

let inTransaction = false;

function logCriticalEvent(action, message) {
  const timestamp = new Date().toISOString();
  const logMsg = `[${timestamp}] [Inventory] [${action.toUpperCase()}] ${message}\n`;
  console.log(logMsg.trim());
  
  try {
    const { dataDir } = getDataPaths();
    const logFile = path.join(dataDir, 'inventory_changes.log');
    fs.appendFileSync(logFile, logMsg, 'utf-8');
  } catch (err) {
    console.error('Error writing to inventory changes log:', err);
  }
}

// Estadísticas del usuario (históricas)
let userStats = {
  totalCardsObtained: 0,
  totalPacksOpened: 0,
  totalCoinsEarned: 0,
  battlesWon: 0,
  battlesPlayed: 0
};

// Estadísticas semanales (se resetean cada lunes)
let weeklyStats = {
  cards: 0,
  packs: 0,
  coins: 0,
  weekStart: null // Timestamp del inicio de la semana
};

// Variables de misiones
let availableMissions = [];
let userMissions = {}; // {missionId: {completed, claimedAt, progress}} - AHORA REMOTO
let userKizunas = {}; // {kizunaId: {claimed: boolean, claimedAt: number}} - Aislado por cuenta
let completedDeliverables = []; // Entregables completados por el usuario
let deliverableCompletions = {}; // { [deliverableId]: count }
let deliverableDailyCompletions = {}; // { [deliverableId]: { cycle: string, count: number } } (Reseteo a las 06:00 AM)
let packPurchases = {}; // { [packId]: count } (Veces que el usuario ha comprado cada sobre en tienda)
const cardUpgrades = new Map(); // uniqueCardId -> upgradeData (mejoras de cartas)

// Variables de configuración del usuario
let userSettings = {
  theme: {
    active: 'default',
    customTheme: null
  }
}; // AHORA REMOTO

// Función para verificar y resetear estadísticas semanales
function checkWeeklyReset() {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0 = Domingo, 1 = Lunes, etc.
  const currentMonday = new Date(now);
  
  // Calcular el lunes de esta semana
  const diff = (dayOfWeek === 0 ? -6 : 1) - dayOfWeek;
  currentMonday.setDate(now.getDate() + diff);
  currentMonday.setHours(0, 0, 0, 0);
  
  const mondayTimestamp = currentMonday.getTime();
  
  // Si no hay weekStart o es de una semana anterior, resetear
  if (!weeklyStats.weekStart || weeklyStats.weekStart < mondayTimestamp) {
    console.log('[RANKINGS] Reseteando estadísticas semanales');
    weeklyStats = {
      cards: 0,
      packs: 0,
      coins: 0,
      weekStart: mondayTimestamp
    };
    saveInventory();
  }
}

// Funciones para incrementar estadísticas
// NOTA: NO hacemos checkWeeklyReset aquí - el servidor maneja el reset automáticamente
function incrementCardsObtained(count) {
  // Asegurar que weekStart existe
  if (!weeklyStats.weekStart) {
    const now = new Date();
    const dayOfWeek = now.getDay();
    const currentMonday = new Date(now);
    const diff = (dayOfWeek === 0 ? -6 : 1) - dayOfWeek;
    currentMonday.setDate(now.getDate() + diff);
    currentMonday.setHours(0, 0, 0, 0);
    weeklyStats.weekStart = currentMonday.getTime();
    console.log('[STATS] Initialized weekStart:', weeklyStats.weekStart);
  }
  
  userStats.totalCardsObtained = (userStats.totalCardsObtained || 0) + count;
  weeklyStats.cards = (weeklyStats.cards || 0) + count;
  console.log(`[STATS] +${count} cartas. Total histórico: ${userStats.totalCardsObtained}, Semanal: ${weeklyStats.cards}`);
  saveInventory();
}

function incrementPacksOpened(count = 1) {
  // Asegurar que weekStart existe
  if (!weeklyStats.weekStart) {
    const now = new Date();
    const dayOfWeek = now.getDay();
    const currentMonday = new Date(now);
    const diff = (dayOfWeek === 0 ? -6 : 1) - dayOfWeek;
    currentMonday.setDate(now.getDate() + diff);
    currentMonday.setHours(0, 0, 0, 0);
    weeklyStats.weekStart = currentMonday.getTime();
    console.log('[STATS] Initialized weekStart:', weeklyStats.weekStart);
  }
  
  userStats.totalPacksOpened = (userStats.totalPacksOpened || 0) + count;
  weeklyStats.packs = (weeklyStats.packs || 0) + count;
  console.log(`[STATS] +${count} sobres. Total histórico: ${userStats.totalPacksOpened}, Semanal: ${weeklyStats.packs}`);
  saveInventory();
}

function incrementCoinsEarned(amount) {
  if (amount > 0) {
    // Asegurar que weekStart existe
    if (!weeklyStats.weekStart) {
      const now = new Date();
      const dayOfWeek = now.getDay();
      const currentMonday = new Date(now);
      const diff = (dayOfWeek === 0 ? -6 : 1) - dayOfWeek;
      currentMonday.setDate(now.getDate() + diff);
      currentMonday.setHours(0, 0, 0, 0);
      weeklyStats.weekStart = currentMonday.getTime();
      console.log('[STATS] Initialized weekStart:', weeklyStats.weekStart);
    }
    
    userStats.totalCoinsEarned = (userStats.totalCoinsEarned || 0) + amount;
    weeklyStats.coins = (weeklyStats.coins || 0) + amount;
    console.log(`[STATS] +${amount} coins. Total histórico: ${userStats.totalCoinsEarned}, Semanal: ${weeklyStats.coins}`);
    saveInventory();
  }
}

// Rutas de datos en userData
function getDataPaths() {
  const userDir = app.getPath('userData');
  const dataDir = path.join(userDir, 'data');
  const inventoryFile = path.join(dataDir, 'inventory.json');
  const inventoryBackupFile = path.join(dataDir, 'inventory_backup.json');
  const profileFile = path.join(dataDir, 'profile.json');
  const cacheDir = path.join(dataDir, 'catalog-cache');
  const cacheManifest = path.join(cacheDir, 'manifest.json');
  const cacheCards = path.join(cacheDir, 'cards.json');
  const cachePacks = path.join(cacheDir, 'packs.json');
  const cacheTraits = path.join(cacheDir, 'traits.json');
  const cacheQualities = path.join(cacheDir, 'calidades.json');
  const commandsCache = path.join(cacheDir, 'commands.json');
  return { dataDir, inventoryFile, inventoryBackupFile, profileFile, cacheDir, cacheManifest, cacheCards, cachePacks, cacheTraits, cacheQualities, commandsCache };
}

function getRedeemedCodesFilePath(username) {
  const { dataDir } = getDataPaths();
  const safeUser = (username || profile.username || 'default').trim().replace(/[^a-zA-Z0-9_-]/g, '_');
  return path.join(dataDir, `redeemed_codes_${safeUser}.json`);
}

function loadUserRedeemedCodes(username) {
  try {
    const filePath = getRedeemedCodesFilePath(username);
    if (fs.existsSync(filePath)) {
      const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      if (Array.isArray(data)) {
        data.forEach(c => redeemedCodes.add(String(c).toUpperCase()));
      }
    }
  } catch (e) {
    console.error('[CODES] Error cargando archivo dedicado de códigos canjeados:', e);
  }
}

function saveUserRedeemedCodes(username) {
  try {
    const filePath = getRedeemedCodesFilePath(username);
    const arr = Array.from(redeemedCodes);
    writeJSONAtomic(filePath, arr);
  } catch (e) {
    console.error('[CODES] Error guardando archivo dedicado de códigos canjeados:', e);
  }
}

function getSupporterBlessingFilePath(username) {
  const { dataDir } = getDataPaths();
  const safeUser = (username || profile.username || 'default').trim().replace(/[^a-zA-Z0-9_-]/g, '_');
  return path.join(dataDir, `supporter_blessing_${safeUser}.json`);
}

function loadUserSupporterBlessing(username) {
  try {
    const filePath = getSupporterBlessingFilePath(username);
    if (fs.existsSync(filePath)) {
      const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      if (data && typeof data === 'object' && data.active && (data.daysRemaining || 0) > 0) {
        return data;
      }
    }
  } catch (e) {
    console.error('[BLESSING] Error cargando archivo dedicado de bendición:', e);
  }
  return null;
}

function saveUserSupporterBlessing(username, blessingObj) {
  try {
    const user = (username || profile.username || '').trim();
    if (!user) return;
    const filePath = getSupporterBlessingFilePath(user);
    if (blessingObj && typeof blessingObj === 'object') {
      writeJSONAtomic(filePath, blessingObj);
    }
  } catch (e) {
    console.error('[BLESSING] Error guardando archivo dedicado de bendición:', e);
  }
}

function ensureSupporterBlessingLoaded(username) {
  const user = (username || profile.username || '').trim();
  if (!user) return;

  // 1. Si ya hay una bendición activa en memoria con días > 0, respaldarla en archivo dedicado
  if (supporterBlessing && supporterBlessing.active && (supporterBlessing.daysRemaining || 0) > 0) {
    saveUserSupporterBlessing(user, supporterBlessing);
    return;
  }

  // 2. Intentar cargar desde el archivo dedicado permanente
  const fromDedicated = loadUserSupporterBlessing(user);
  if (fromDedicated && fromDedicated.active && (fromDedicated.daysRemaining || 0) > 0) {
    supporterBlessing = { ...fromDedicated };
    console.log('[BLESSING] Restaurada bendición activa desde archivo dedicado:', supporterBlessing.daysRemaining, 'días restantes');
    return;
  }

  // 3. Intentar recuperar desde inventario local o backup
  try {
    const { inventoryFile, inventoryBackupFile } = getDataPaths();
    if (fs.existsSync(inventoryFile)) {
      const inv = readJSON(inventoryFile, null);
      const userInv = inv?.users?.[user];
      if (userInv?.supporterBlessing && typeof userInv.supporterBlessing === 'object' && userInv.supporterBlessing.active && (userInv.supporterBlessing.daysRemaining || 0) > 0) {
        supporterBlessing = { ...userInv.supporterBlessing };
        saveUserSupporterBlessing(user, supporterBlessing);
        console.log('[BLESSING] Restaurada bendición activa desde inventario local:', supporterBlessing.daysRemaining, 'días restantes');
        return;
      }
    }
    if (fs.existsSync(inventoryBackupFile)) {
      const bInv = readJSON(inventoryBackupFile, null);
      const bUserInv = bInv?.users?.[user];
      if (bUserInv?.supporterBlessing && typeof bUserInv.supporterBlessing === 'object' && bUserInv.supporterBlessing.active && (bUserInv.supporterBlessing.daysRemaining || 0) > 0) {
        supporterBlessing = { ...bUserInv.supporterBlessing };
        saveUserSupporterBlessing(user, supporterBlessing);
        console.log('[BLESSING] Restaurada bendición activa desde backup local:', supporterBlessing.daysRemaining, 'días restantes');
        return;
      }
    }
  } catch (e) {
    console.error('[BLESSING] Error buscando en inventarios:', e);
  }

  // 4. AUTO-RECUPERACIÓN: Si el usuario canjeó un código de bendición (SUPPORTER30 o en used_single_codes), reconstruir
  try {
    loadUserRedeemedCodes(user);
    const userCodes = Array.from(redeemedCodes).map(c => String(c).toUpperCase());
    const { dataDir } = getDataPaths();
    const usedCodesFile = path.join(dataDir, 'used_single_codes.json');
    let localUsed = {};
    if (fs.existsSync(usedCodesFile)) {
      try { localUsed = JSON.parse(fs.readFileSync(usedCodesFile, 'utf-8')); } catch {}
    }

    const hasBlessingCode = userCodes.some(c => c.includes('SUPPORTER') || c.includes('BENDICION')) ||
                            Object.keys(localUsed).some(code => (code.includes('SUPPORTER') || code.includes('BENDICION')) && localUsed[code]?.user === user);

    if (hasBlessingCode) {
      const currentCycle = typeof getMadridDayCycle === 'function' ? getMadridDayCycle() : '2026-09-02';
      supporterBlessing = {
        active: true,
        daysRemaining: 29, // Recuperado tras la activación
        totalDays: 30,
        dailyAmount: 30,
        activatedAt: new Date(Date.now() - 86400000).toISOString(),
        activatedCycle: currentCycle,
        lastUpdatedCycle: currentCycle,
        lastClaimCycle: null // Permitir reclamar hoy
      };
      saveUserSupporterBlessing(user, supporterBlessing);
      console.log('✨ [BLESSING RECOVERY] Bendición de supporter auto-recuperada exitosamente para:', user);
    }
  } catch (errRec) {
    console.error('[BLESSING RECOVERY] Error comprobando auto-recuperación:', errRec);
  }
}

function readJSON(filePath, fallback) {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    const raw = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function writeJSON(filePath, obj) {
  writeJSONAtomic(filePath, obj);
}

function writeJSONAtomic(filePath, obj) {
  const tempPath = filePath + '.tmp';
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(tempPath, JSON.stringify(obj, null, 2), 'utf-8');
  fs.renameSync(tempPath, filePath);
}

function uuid() {
  return Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
}

function getPackMediaLimits(pack) {
  if (!pack || typeof pack !== 'object') {
    return { minMedia: null, maxMedia: null };
  }

  let minMedia = null;
  let maxMedia = null;

  // 1. Campos directos numéricos
  const rawMin = pack.minMedia ?? pack.min_media ?? pack.minRating ?? pack.min_rating ?? pack.mediaMin ?? pack.media_min ?? pack.ratingMin;
  if (rawMin !== undefined && rawMin !== null && rawMin !== '') {
    const num = Number(rawMin);
    if (!isNaN(num)) minMedia = num;
  }

  const rawMax = pack.maxMedia ?? pack.max_media ?? pack.maxRating ?? pack.max_rating ?? pack.mediaMax ?? pack.media_max ?? pack.ratingMax;
  if (rawMax !== undefined && rawMax !== null && rawMax !== '') {
    const num = Number(rawMax);
    if (!isNaN(num)) maxMedia = num;
  }

  // 2. Objetos o arrays de rangos
  const rangeObj = pack.mediaRange || pack.ratingRange || pack.mediaLimits || pack.ratingLimits || 
                   pack.media_range || pack.rating_range || pack.rangoMedia || pack.limits ||
                   (typeof pack.media === 'object' ? pack.media : null) || 
                   (typeof pack.rating === 'object' ? pack.rating : null);

  if (rangeObj) {
    if (Array.isArray(rangeObj) && rangeObj.length > 0) {
      if (minMedia === null && rangeObj[0] !== undefined && rangeObj[0] !== null && rangeObj[0] !== '') {
        const num = Number(rangeObj[0]);
        if (!isNaN(num)) minMedia = num;
      }
      if (maxMedia === null && rangeObj[1] !== undefined && rangeObj[1] !== null && rangeObj[1] !== '') {
        const num = Number(rangeObj[1]);
        if (!isNaN(num)) maxMedia = num;
      }
    } else if (typeof rangeObj === 'object') {
      if (minMedia === null) {
        const val = rangeObj.min ?? rangeObj.minMedia ?? rangeObj.min_media ?? rangeObj.minRating ?? rangeObj.min_rating ?? rangeObj.from;
        if (val !== undefined && val !== null && val !== '') {
          const num = Number(val);
          if (!isNaN(num)) minMedia = num;
        }
      }
      if (maxMedia === null) {
        const val = rangeObj.max ?? rangeObj.maxMedia ?? rangeObj.max_media ?? rangeObj.maxRating ?? rangeObj.max_rating ?? rangeObj.to;
        if (val !== undefined && val !== null && val !== '') {
          const num = Number(val);
          if (!isNaN(num)) maxMedia = num;
        }
      }
    }
  }

  // 3. Cadenas de texto como "+80", "80+", "80-85", ">=80"
  const rawStrings = [
    typeof pack.media === 'string' ? pack.media : null,
    typeof pack.rating === 'string' ? pack.rating : null,
    typeof pack.mediaRange === 'string' ? pack.mediaRange : null,
    typeof pack.ratingRange === 'string' ? pack.ratingRange : null,
    typeof pack.limits === 'string' ? pack.limits : null
  ].filter(Boolean);

  for (const str of rawStrings) {
    const trimmed = str.trim();
    if (trimmed.startsWith('+')) {
      const n = Number(trimmed.slice(1).trim());
      if (!isNaN(n) && minMedia === null) minMedia = n;
    } else if (trimmed.endsWith('+')) {
      const n = Number(trimmed.slice(0, -1).trim());
      if (!isNaN(n) && minMedia === null) minMedia = n;
    } else if (trimmed.startsWith('>=') || trimmed.startsWith('=>')) {
      const n = Number(trimmed.slice(2).trim());
      if (!isNaN(n) && minMedia === null) minMedia = n;
    } else if (trimmed.startsWith('<=') || trimmed.startsWith('=<')) {
      const n = Number(trimmed.slice(2).trim());
      if (!isNaN(n) && maxMedia === null) maxMedia = n;
    } else if (trimmed.includes('-') || trimmed.includes('..')) {
      const delimiter = trimmed.includes('..') ? '..' : '-';
      const parts = trimmed.split(delimiter).map(p => Number(p.trim()));
      if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
        if (minMedia === null) minMedia = parts[0];
        if (maxMedia === null) maxMedia = parts[1];
      }
    }
  }

  return { minMedia, maxMedia };
}

function parseQualityWeights(rawWeights) {
  if (!rawWeights || typeof rawWeights !== 'object') return null;
  const map = {};
  for (const [key, val] of Object.entries(rawWeights)) {
    if (val !== undefined && val !== null && val !== '') {
      const num = Number(val);
      if (!isNaN(num)) {
        const normKey = String(key).trim().toLowerCase().replace(/[\s\-]+/g, '_');
        map[normKey] = num;
      }
    }
  }
  return Object.keys(map).length > 0 ? map : null;
}

function resolveCardQualityWeight(card, normalizedWeights, getQualityObjFn, allowedQualities = null) {
  if (!normalizedWeights) return 1;

  const qObj = typeof getQualityObjFn === 'function' ? getQualityObjFn(card) : null;
  const qId = String(qObj?.id || card?.calidadId || '').trim().toLowerCase().replace(/[\s\-]+/g, '_');
  const qName = String(qObj?.name || card?.calidad || card?.quality || '').trim().toLowerCase().replace(/[\s\-]+/g, '_');
  const isSpecial = Boolean(qObj?.special);

  // 1. Coincidencia por ID de la calidad en calidades.json (ej: "bronce", "plata", "oro", "exclusive")
  // Si se filtra directamente por la calidad, sí se permite aunque packable sea false
  if (qId && normalizedWeights[qId] !== undefined) {
    return Math.max(0, normalizedWeights[qId]);
  }

  // 2. Coincidencia por Nombre de la calidad (retrocompatibilidad)
  if (qName && normalizedWeights[qName] !== undefined) {
    return Math.max(0, normalizedWeights[qName]);
  }

  // 3. Si la calidad tiene special === true en calidades.json, buscar peso 'special' / 'especial' / 'especiales'
  if (isSpecial) {
    const specialVal = normalizedWeights['special'] ?? normalizedWeights['especial'] ?? normalizedWeights['especiales'];
    if (specialVal !== undefined) {
      const isPackable = (qObj?.packable !== false && qObj?.packable !== 'false') &&
                         (card?.packable !== false && card?.packable !== 'false');

      let allowedSet = allowedQualities;
      if (allowedQualities && !(allowedQualities instanceof Set)) {
        if (Array.isArray(allowedQualities)) {
          allowedSet = new Set(allowedQualities.map(q => String(q).trim().toLowerCase().replace(/[\s\-]+/g, '_')).filter(Boolean));
        } else if (typeof allowedQualities === 'object') {
          allowedSet = getPackAllowedQualities(allowedQualities);
        }
      }

      const isExplicitlyAllowed = allowedSet && (allowedSet.has(qId) || allowedSet.has(qName));

      // Si no es packable, solo puede salir por 'special' si el sobre la permite explícitamente (allowedQualities)
      if (!isPackable && !isExplicitlyAllowed) {
        return 0;
      }
      return Math.max(0, specialVal);
    }
  }

  return 0;
}

function getPackAllowedQualities(pack) {
  if (!pack) return null;
  const raw = pack.allowedQualities ?? pack.allowed_qualities ?? 
              pack.allowQualities ?? pack.allow_qualities ?? 
              pack.calidadesPermitidas ?? pack.allowedCalidades ??
              pack.allowUnpackableQualities ?? pack.allowedNonPackableQualities;
  if (!raw) return null;
  const arr = Array.isArray(raw) ? raw : [raw];
  const set = new Set(arr.map(q => String(q).trim().toLowerCase().replace(/[\s\-]+/g, '_')).filter(Boolean));
  return set.size > 0 ? set : null;
}

function getPackAllowedProcedencias(pack) {
  if (!pack) return null;
  const raw = pack.allowedProcedencias ?? pack.allowed_procedencias ?? pack.procedencias;
  if (!raw) return null;
  const arr = Array.isArray(raw) ? raw : [raw];
  const set = new Set(arr.map(p => String(p).trim().toLowerCase()).filter(Boolean));
  return set.size > 0 ? set : null;
}

function getPackAllowedOwners(pack) {
  if (!pack) return null;
  const raw = pack.allowedOwners ?? pack.allowed_owners ?? pack.owners ?? pack.allowedPropietarios ?? pack.propietarios;
  if (!raw) return null;
  const arr = Array.isArray(raw) ? raw : [raw];
  const set = new Set(arr.map(o => String(o).trim().toLowerCase()).filter(Boolean));
  return set.size > 0 ? set : null;
}

function getPackExcludedIds(pack) {
  if (!pack) return null;
  const raw = pack.excludedIds ?? pack.excluded_ids ?? pack.excludedCardIds ?? pack.excluded_card_ids;
  if (!raw) return null;
  const arr = Array.isArray(raw) ? raw : [raw];
  const set = new Set(arr.map(id => String(id).trim()).filter(Boolean));
  return set.size > 0 ? set : null;
}

function sampleByWeights(distribution, cardsPerPack, pack = null) {
  const entries = Object.entries(distribution);
  if (entries.length === 0 && (!pack || !packStore)) return [];

  const { minMedia, maxMedia } = getPackMediaLimits(pack);
  const hasMediaLimits = minMedia !== null || maxMedia !== null;

  const rawQWeights = pack?.qualityWeights || pack?.qualityweights || pack?.quality_weights || pack?.qualityheights || pack?.quality_heights || null;
  const normQWeights = parseQualityWeights(rawQWeights);
  const hasQualityWeights = !!normQWeights;

  const allowedProcedencias = getPackAllowedProcedencias(pack);
  const allowedOwners = getPackAllowedOwners(pack);
  const allowedQualities = getPackAllowedQualities(pack);
  const excludedIds = getPackExcludedIds(pack);

  const explicitCardIdsRaw = pack && Array.isArray(pack.allowedCardIds) ? pack.allowedCardIds : [];
  const explicitCardIds = new Set(explicitCardIdsRaw.map(id => String(id)));
  const hasExplicitCardIds = explicitCardIds.size > 0;
  
  // Calidades explícitamente excluidas
  const excludedQualities = (pack && pack.excludedQualities)
    ? pack.excludedQualities.map(q => String(q).trim().toLowerCase().replace(/[\s\-]+/g, '_'))
    : [];

  // Modo exclusivo: si hay allowedCardIds y todos los qualityWeights son 0
  const hasPositiveQualityWeights = normQWeights && Object.values(normQWeights).some(w => Number(w) > 0);
  const explicitOnlyMode = hasExplicitCardIds && hasQualityWeights && !hasPositiveQualityWeights;

  // Permitir que allowedCardIds o filtros de media / procedencia / owner / calidades / qualityWeights metan cartas aunque no estén en distribution (peso base 1).
  const sourceEntries = [...entries];
  const needsAllCandidates = sourceEntries.length === 0 || hasMediaLimits || allowedProcedencias !== null || allowedOwners !== null || allowedQualities !== null || hasQualityWeights;

  if (needsAllCandidates) {
    cardStore.forEach((_c, id) => {
      const alreadyIncluded = sourceEntries.some(([entryId]) => entryId === id);
      if (!alreadyIncluded) {
        sourceEntries.push([id, 1]);
      }
    });
  } else if (hasExplicitCardIds) {
    for (const id of explicitCardIds) {
      const alreadyIncluded = entries.some(([entryId]) => entryId === id);
      if (!alreadyIncluded && cardStore.has(id)) {
        sourceEntries.push([id, 1]);
      }
    }
  }
  
  console.log('[PACK FILTER] Abriendo sobre:', pack?.name || 'unknown');
  if (minMedia !== null || maxMedia !== null) {
    console.log(`[PACK FILTER] Límites de media: min=${minMedia ?? '-∞'}, max=${maxMedia ?? '+∞'}`);
  }
  if (normQWeights) {
    console.log('[PACK FILTER] qualityWeights (por ID):', normQWeights);
  }
  if (allowedProcedencias) {
    console.log('[PACK FILTER] allowedProcedencias:', Array.from(allowedProcedencias));
  }
  if (allowedOwners) {
    console.log('[PACK FILTER] allowedOwners:', Array.from(allowedOwners));
  }
  if (allowedQualities) {
    console.log('[PACK FILTER] allowedQualities:', Array.from(allowedQualities));
  }
  if (excludedIds) {
    console.log('[PACK FILTER] excludedIds:', Array.from(excludedIds));
  }
  console.log('[PACK FILTER] Calidades excluidas:', excludedQualities);
  console.log('[PACK FILTER] allowedCardIds:', Array.from(explicitCardIds));
  console.log('[PACK FILTER] explicitOnlyMode:', explicitOnlyMode);
  console.log('[PACK FILTER] Total cartas candidatas:', sourceEntries.length);
  
  // Aplicar filtros y probabilidad inversa
  let excludedCount = 0;
  const adjustedDistribution = sourceEntries
    .map(([id, baseWeight]) => {
      // 0. EXCLUSIÓN DIRECTA POR ID (excludedIds)
      if (excludedIds && excludedIds.has(String(id))) {
        excludedCount++;
        return null;
      }

      const card = cardStore.get(id);
      if (!card) return null; // Excluir cartas que no existen

      const isExplicitCard = explicitCardIds.has(id);

      // Si está activo el modo exclusivo, solo pasan las cartas explícitas.
      if (explicitOnlyMode && !isExplicitCard) {
        excludedCount++;
        return null;
      }
      
      const cardQuality = card.calidad || 'Bronce';
      const isEvo = cardQuality === 'Evo' || card.calidadId === 'evo' || String(cardQuality).toLowerCase() === 'evo';

      // Las cartas Evo NUNCA pueden salir en sobres salvo que estén en allowedCardIds
      if (isEvo && !isExplicitCard) {
        return null;
      }

      // Las cartas explícitas siempre pueden entrar
      if (!isExplicitCard) {
        const qObj = qualityStore.get(cardQuality) || qualityStore.get(card.calidadId) ||
          Array.from(qualityStore.values()).find(x => x.name === cardQuality || x.id === cardQuality || x.id === card.calidadId);
        const cardQNorm = String(cardQuality).trim().toLowerCase().replace(/[\s\-]+/g, '_');
        const cardQId = String(qObj?.id || card.calidadId || '').trim().toLowerCase().replace(/[\s\-]+/g, '_');

        // EXCLUSIÓN EXPLÍCITA: Si la calidad está en excludedQualities, excluir completamente
        if (excludedQualities.includes(cardQNorm) || excludedQualities.includes(cardQId)) {
          excludedCount++;
          return null;
        }

        // FILTRO POR CALIDADES PERMITIDAS (allowedQualities)
        if (allowedQualities) {
          const isAllowedQ = allowedQualities.has(cardQNorm) || allowedQualities.has(cardQId);
          // Si no tiene qualityWeights con special, allowedQualities actúa como whitelist estricto
          const hasSpecialWeight = normQWeights && (normQWeights['special'] !== undefined || normQWeights['especial'] !== undefined || normQWeights['especiales'] !== undefined);
          if (!hasSpecialWeight && !isAllowedQ) {
            excludedCount++;
            return null;
          }
        }

        // FILTRO POR PROCEDENCIA (allowedProcedencias)
        if (allowedProcedencias) {
          const proc = String(card.procedencia ?? card.Procedencia ?? card.origin ?? card.origen ?? '').trim().toLowerCase();
          if (!proc || !allowedProcedencias.has(proc)) {
            excludedCount++;
            return null;
          }
        }

        // FILTRO POR OWNER (allowedOwners)
        if (allowedOwners) {
          const owner = String(card.owner ?? card.Owner ?? card.propietario ?? card.Propietario ?? card.creador ?? card.creator ?? '').trim().toLowerCase();
          if (!owner || !allowedOwners.has(owner)) {
            excludedCount++;
            return null;
          }
        }

        // FILTRO POR LÍMITES DE MEDIA (minMedia / maxMedia)
        const media = Number(card.media) || 0;
        if (minMedia !== null && media < minMedia) {
          excludedCount++;
          return null;
        }
        if (maxMedia !== null && media > maxMedia) {
          excludedCount++;
          return null;
        }

        // CONTROL DE PACKABLE (packable === false):
        // Por defecto packable es true si no se especifica.
        // Si packable es false (en la calidad o en la carta), NO puede salir en sobres salvo que:
        // 1. Esté en allowedCardIds (isExplicitCard - ya controlado arriba)
        // 2. Esté en allowedQualities / allowQualities del sobre
        // 3. Se filtre explícitamente por su calidad en qualityWeights (ej: { "exclusive": 100 })
        const isPackable = (qObj?.packable !== false && qObj?.packable !== 'false') &&
                           (card?.packable !== false && card?.packable !== 'false');
        if (!isPackable) {
          const isExplicitQuality = normQWeights && (normQWeights[cardQId] !== undefined || normQWeights[cardQNorm] !== undefined);
          const isAllowedQuality = allowedQualities && (allowedQualities.has(cardQId) || allowedQualities.has(cardQNorm));
          if (!isExplicitQuality && !isAllowedQuality) {
            excludedCount++;
            return null;
          }
        }

        // FILTRO Y PESO POR QUALITYWEIGHTS (por ID en calidades.json o 'special')
        if (hasQualityWeights) {
          const qWeight = resolveCardQualityWeight(card, normQWeights, () => qObj, allowedQualities);
          if (qWeight <= 0) {
            excludedCount++;
            return null;
          }
          baseWeight = qWeight;
        }
      }
    
      const media = Number(card.media) || 0;
    
    // Fórmula de probabilidad inversa continua mejorada:
    // Cuanto mayor la media, exponencialmente menor la probabilidad
    // Cartas de 85+ son especialmente difíciles de conseguir
    // Fórmula: multiplier = e^(-(media - 50) / factor)
    // Factor varía según el rango de media para crear una curva más agresiva
    
    let factor;
    let multiplier;
    
    if (media >= 85) {
      // Cartas 85+: Super difíciles (factor 8 = caída muy pronunciada)
      // Media 85 -> ≈ 0.018 (1.8% de prob base)
      // Media 90 -> ≈ 0.007 (0.7% de prob base) 
      // Media 95 -> ≈ 0.003 (0.3% de prob base)
      factor = 8;
      multiplier = Math.exp(-(media - 50) / factor);
    } else if (media >= 80) {
      // Cartas 80-84: Muy raras (factor 12)
      // Media 80 -> ≈ 0.054 (5.4% de prob base)
      // Media 84 -> ≈ 0.026 (2.6% de prob base)
      factor = 12;
      multiplier = Math.exp(-(media - 50) / factor);
    } else if (media >= 75) {
      // Cartas 75-79: Raras (factor 15)
      // Media 75 -> ≈ 0.082 (8.2% de prob base)
      // Media 79 -> ≈ 0.049 (4.9% de prob base)
      factor = 15;
      multiplier = Math.exp(-(media - 50) / factor);
    } else {
      // Cartas < 75: Probabilidad estándar (factor 18)
      // Media 50 -> ≈ 1.0 (100% prob base)
      // Media 60 -> ≈ 0.56 (56% de prob base)
      // Media 70 -> ≈ 0.32 (32% de prob base)
      factor = 18;
      multiplier = Math.exp(-(media - 50) / factor);
    }
    
    return { id, weight: baseWeight * multiplier };
  })
  .filter(item => item !== null); // Eliminar cartas excluidas
  
  console.log(`[PACK FILTER] ✅ Total cartas excluidas: ${excludedCount}`);
  console.log(`[PACK FILTER] ✅ Cartas válidas restantes: ${adjustedDistribution.length}`);
  
  // Validar que quedan cartas después del filtro
  if (adjustedDistribution.length === 0) {
    console.error('[PACK FILTER] ❌ ERROR: No hay cartas válidas después de aplicar filtros');
    return [];
  }
  
  const total = adjustedDistribution.reduce((s, item) => s + item.weight, 0);
  if (total === 0) {
    console.error('[PACK FILTER] ERROR: Peso total es 0 después de aplicar filtros');
    return [];
  }
  
  const cumulative = [];
  let acc = 0;
  for (const item of adjustedDistribution) {
    acc += item.weight;
    cumulative.push({ id: item.id, threshold: acc / total });
  }
  const picks = [];
  for (let i = 0; i < cardsPerPack; i++) {
    const r = Math.random();
    const found = cumulative.find(c => r <= c.threshold) || cumulative[cumulative.length - 1];
    if (found) picks.push(found.id);
  }
  return picks;
}

function deriveQuality(media) {
  const m = Number(media) || 0;
  if (m >= 90) return 'Icono';
  if (m >= 80) return 'Oro';
  if (m >= 70) return 'Plata';
  return 'Bronce';
}

function getCardSellValue(card) {
  if (!card) return 10;
  const normQ = normalizeQuality(card.calidad);
  if (normQ && qualityStore.has(normQ)) {
    const qObj = qualityStore.get(normQ);
    if (qObj && typeof qObj.valor === 'number') return qObj.valor;
  }
  for (const qObj of qualityStore.values()) {
    if (qObj.name === card.calidad || qObj.id === card.calidad) {
      if (typeof qObj.valor === 'number') return qObj.valor;
    }
  }
  return typeof card.valor === 'number' ? card.valor : 10;
}

function normalizeQuality(q) {
  if (!q) return null;
  try {
    const raw = String(q).trim();
    if (!raw) return null;

    // 1. Coincidencia directa por id o por nombre en qualityStore
    if (qualityStore.has(raw)) {
      return qualityStore.get(raw).name;
    }
    for (const [key, qObj] of qualityStore.entries()) {
      if (qObj.id === raw || qObj.name === raw) return qObj.name;
    }

    // 2. Normalización de caracteres y comparación limpia (id y nombre)
    const s = raw.toLowerCase();
    const clean = (s.normalize ? s.normalize('NFD').replace(/[\u0300-\u036f]/g, '') : s).replace(/[\s\-_]/g, '');

    for (const [key, qObj] of qualityStore.entries()) {
      const targetIdClean = String(qObj.id || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\s\-_]/g, '');
      const targetNameClean = String(qObj.name || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\s\-_]/g, '');
      if (clean === targetIdClean || clean === targetNameClean) {
        return qObj.name;
      }
    }

    // 3. Fallbacks heurísticos conocidos
    const t = (s.normalize ? s.normalize('NFD').replace(/[\u0300-\u036f]/g, '') : s).replace(/[-_]/g, ' ');
    if (t.includes('super') && t.includes('prime')) return 'Icono Super Prime';
    if (t.includes('prime')) return 'Icono Prime';
    if (t.includes('heroe') || t.includes('héroe')) return 'Heroe';
    if (t.includes('icono') || t.includes('icon')) return 'Icono';
    if (t.includes('especial')) return 'Especial';
    if (t.includes('oro') || t.includes('gold')) return 'Oro';
    if (t.includes('plata') || t.includes('silver')) return 'Plata';
    if (t.includes('bronce') || t.includes('bronze')) return 'Bronce';
    if (t.includes('evo')) return 'Evo';
    if (t === 'knight') return 'Knight';
  } catch {}
  return null;
}

// Subida de imagen (offline): guarda en userData/uploads y devuelve file:// URL
ipcMain.handle('upload:image', async (_e, payload) => {
  try {
    const { bufferBase64, filename } = payload || {};
    if (!bufferBase64 || !filename) return { error: 'Invalid payload' };
    const uploadsDir = path.join(app.getPath('userData'), 'uploads');
    if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
    const ext = path.extname(filename) || '.png';
    const name = uuid() + ext;
    const dest = path.join(uploadsDir, name);
    const data = Buffer.from(bufferBase64, 'base64');
    fs.writeFileSync(dest, data);
    const url = 'file://' + dest.replace(/\\/g, '/');
    return { ok: true, url };
  } catch (err) {
    return { error: String(err) };
  }
});

// Cartas
ipcMain.handle('cards:add', (_e, payload) => {
  const { name, stats, imageUrl, media, calidad, valor } = payload || {};
  if (!name || !Array.isArray(stats) || stats.length !== 6) {
    return { error: 'Invalid payload: name and 6 stats required' };
  }
  const normQ = normalizeQuality(calidad);
  if (!normQ) {
    return { error: 'Invalid payload: calidad requerida no válida' };
  }
  const id = uuid();
  const [stat1, stat2, stat3, stat4, stat5, stat6] = stats;
  const computed = Math.round((Number(stat1)||0 + (Number(stat2)||0) + (Number(stat3)||0) + (Number(stat4)||0) + (Number(stat5)||0) + (Number(stat6)||0)) / 6);
  
  // Calcular valor por defecto desde qualityStore si no se proporciona
  const qObj = qualityStore.get(normQ) || qualityStore.get(calidad) || Array.from(qualityStore.values()).find(x => x.name === normQ || x.id === calidad);
  const finalValor = typeof valor === 'number' ? valor : (qObj?.valor || 10);
  const calidadId = qObj ? qObj.id : (calidad ? String(calidad).toLowerCase().replace(/\s+/g, '_') : 'bronce');
  
  const card = { id, name, imageUrl, stat1, stat2, stat3, stat4, stat5, stat6, media: typeof media === 'number' ? media : computed, calidad: normQ, calidadId, quality: normQ, valor: finalValor };
  cardStore.set(id, card);
  // persistir
  try { saveCards(); } catch {}
  return { ok: true, card };
});

ipcMain.handle('cards:getAll', () => Array.from(cardStore.values()));
ipcMain.handle('qualities:getAll', () => Array.from(new Set(qualityStore.values())));
ipcMain.handle('cards:delete', (_e, id) => {
  if (!cardStore.has(id)) return { error: 'Card not found' };
  cardStore.delete(id);
  try { saveCards(); } catch {}
  return { ok: true };
});

// Vender carta
ipcMain.handle('cards:sell', (_e, payload) => {
  // payload puede ser: {cardId: 'card_id'} o {cardId: 'card_id', instanceId: 'trait_123'}
  const { cardId, instanceId } = typeof payload === 'string' ? { cardId: payload, instanceId: null } : payload;
  
  const card = cardStore.get(cardId);
  if (!card) {
    console.log('[SELL] Card not found:', cardId);
    return { error: 'Carta no encontrada' };
  }
  
  console.log('[SELL] Selling card:', cardId, 'instanceId:', instanceId);
  
  // Verificar que tenemos la carta
  const currentCount = ownedCards.get(cardId) || 0;
  if (currentCount <= 0) return { error: 'No tienes esta carta' };
  
  inTransaction = true;
  try {
    // Si tiene instanceId, es una carta con trait
    if (instanceId && cardTraits.has(instanceId)) {
      console.log('[SELL] Removing trait instance:', instanceId);
      cardTraits.delete(instanceId);
    }
    
    // SIEMPRE decrementar el contador (las cartas con trait también cuentan)
    console.log('[SELL] Decrementing count from', currentCount, 'to', currentCount - 1);
    if (currentCount > 1) {
      ownedCards.set(cardId, currentCount - 1);
    } else {
      ownedCards.delete(cardId);
    }
    
    // Añadir coins al monedero usando el valor dinámico de la calidad
    const sellValue = getCardSellValue(card);
    wallet.coins = (wallet.coins || 0) + sellValue;
    
    // Incrementar contador de coins ganados
    incrementCoinsEarned(sellValue);
    
    logCriticalEvent('remove', `Removed card: ${card.name || cardId} (ID: ${cardId}). Reason: Sold for ${sellValue} coins.`);
    
    inTransaction = false;
    saveInventory();
    
    console.log('[SELL] Sold successfully. New balance:', wallet.coins);
    return { ok: true, soldValue: sellValue, newBalance: wallet.coins };
  } catch (err) {
    inTransaction = false;
    console.error('Error during sell transaction:', err);
    return { error: 'Error al procesar la venta' };
  }
});

// Packs
ipcMain.handle('packs:create', (_e, payload) => {
  const { name, distribution, cardsPerPack = 5 } = payload || {};
  if (!name || typeof distribution !== 'object') return { error: 'Invalid payload: name and distribution required' };
  const id = uuid();
  const pack = { id, name, cardsPerPack, distribution };
  packStore.set(id, pack);
  // persistir
  try { savePacks(); } catch {}
  return { ok: true, pack };
});

ipcMain.handle('packs:open', (_e, packId) => {
  const pack = packStore.get(packId);
  if (!pack) return { error: 'Pack not found' };
  // si hay inventario de packs, consumir 1 si existe
  const current = ownedPacks.get(packId) || 0;
  if (current <= 0) return { error: 'No tienes sobres de este tipo' };

  const pickedIds = sampleByWeights(pack.distribution, pack.cardsPerPack, pack);
  if (!Array.isArray(pickedIds) || pickedIds.length === 0) {
    return { error: 'El sobre no tiene cartas válidas con la configuración actual (revisa qualityWeights y allowedCardIds)' };
  }

  // Consumir el sobre de manera atómica
  inTransaction = true;
  try {
    ownedPacks.set(packId, current - 1);
    incrementPacksOpened(1);
    
    logCriticalEvent('remove', `Removed pack: ${pack.name || packId} (ID: ${packId}). Reason: Opened pack.`);
    
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('Error during packs:open transaction:', err);
    return { error: 'Error al abrir el sobre' };
  }

  const cards = pickedIds.map(id => cardStore.get(id)).filter(Boolean);
  if (cards.length === 0) {
    // Failsafe: restaurar el sobre si no se pudo resolver ninguna carta.
    inTransaction = true;
    try {
      ownedPacks.set(packId, current);
      inTransaction = false;
      saveInventory();
    } catch {}
    return { error: 'No se pudieron resolver las cartas del sobre (IDs inválidos o catálogo desactualizado)' };
  }
  
  return { ok: true, cards, cardIds: pickedIds };
});

// Guardar cartas del sobre en el inventario
ipcMain.handle('packs:saveCards', (_e, cardIds) => {
  if (!Array.isArray(cardIds)) return { error: 'Invalid card IDs' };
  
  console.log('[SAVE CARDS] Adding cards to inventory:', cardIds);
  
  inTransaction = true;
  try {
    for (const id of cardIds) {
      const cnt = ownedCards.get(id) || 0;
      ownedCards.set(id, cnt + 1);
      console.log('[SAVE CARDS] Card', id, 'count:', cnt, '->', cnt + 1);
      
      const card = cardStore.get(id);
      const cardName = card ? card.name : id;
      logCriticalEvent('add', `Added card: ${cardName} (ID: ${id}). Reason: Pack opening.`);
    }
    
    incrementCardsObtained(cardIds.length);
    
    inTransaction = false;
    saveInventory();
  } catch (e) {
    inTransaction = false;
    console.error('Error saving cards:', e);
    return { error: 'Error al guardar cartas' };
  }
  
  return { ok: true };
});

// Vender todas las cartas del sobre
ipcMain.handle('packs:sellAllCards', (_e, cardIds) => {
  if (!Array.isArray(cardIds)) return { error: 'Invalid card IDs' };
  
  // Calcular valor total usando valor dinámico de calidad
  let totalValue = 0;
  for (const id of cardIds) {
    const card = cardStore.get(id);
    if (card) {
      totalValue += getCardSellValue(card);
    }
  }
  
  inTransaction = true;
  try {
    // Añadir dinero al monedero
    wallet.coins = (wallet.coins || 0) + totalValue;
    incrementCoinsEarned(totalValue);
    
    logCriticalEvent('add', `Sold all cards from pack. Added coins: ${totalValue}. Reason: Sell all cards from pack.`);
    
    inTransaction = false;
    saveInventory();
  } catch (e) {
    inTransaction = false;
    console.error('Error saving after sell:', e);
    return { error: 'Error al guardar cambios' };
  }
  
  return { ok: true, totalValue, newBalance: wallet.coins };
});

ipcMain.handle('packs:getAll', () => {
  // Devolver packs con stock actualizado restando compras del usuario
  return Array.from(packStore.values()).map(pack => {
    let currentStock = pack.stock;
    if (pack.stock !== null && pack.stock !== undefined) {
      const bought = Number(packPurchases[pack.id]) || 0;
      currentStock = Math.max(0, Number(pack.stock) - bought);
    }
    return { ...pack, stock: currentStock };
  });
});
ipcMain.handle('packs:delete', (_e, id) => {
  if (!packStore.has(id)) return { error: 'Pack not found' };
  packStore.delete(id);
  try { savePacks(); } catch {}
  return { ok: true };
});

ipcMain.handle('packs:deduct', async (_e, packId) => {
  const current = ownedPacks.get(packId) || 0;
  if (current <= 0) return { error: 'No tienes sobres de este tipo' };
  
  inTransaction = true;
  try {
    ownedPacks.set(packId, current - 1);
    
    const pack = packStore.get(packId);
    const packName = pack ? pack.name : packId;
    logCriticalEvent('remove', `Removed pack: ${packName} (ID: ${packId}). Reason: Deduct pack.`);
    
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('[GAMBLING] Error al guardar o sincronizar tras deducción de sobre:', err);
  }
  return { ok: true, packs: Object.fromEntries(ownedPacks) };
});

ipcMain.handle('packs:getLegendaryUpgradeRewardCard', (_e, rarity) => {
  const cards = Array.from(cardStore.values());
  if (cards.length === 0) {
    return { error: 'Catálogo de cartas vacío' };
  }

  // Helper para identificar cartas especiales (NO incluye 'Evo')
  const isSpecialQuality = (q) => (q === 'Icono' || q === 'Heroe' || q === 'Icono Prime' || q === 'Icono Super Prime');

  // Helper para selección ponderada
  const pickWeighted = (list, getWeight) => {
    if (!list || list.length === 0) return null;
    const weighted = [];
    for (const c of list) {
      const w = Math.max(1, Math.round(getWeight(c)));
      for (let i = 0; i < w; i++) {
        weighted.push(c);
      }
    }
    if (weighted.length === 0) return list[Math.floor(Math.random() * list.length)];
    return weighted[Math.floor(Math.random() * weighted.length)];
  };

  let chosenCard = null;

  if (rarity === 'Poco Común') {
    // Media 75-76, nunca menor de 75, nunca 'Evo'
    let pool = cards.filter(c => c.calidad !== 'Evo' && Number(c.media) >= 75 && Number(c.media) <= 76);
    if (pool.length === 0) pool = cards.filter(c => c.calidad !== 'Evo' && Number(c.media) >= 75 && Number(c.media) <= 77);
    if (pool.length > 0) {
      chosenCard = pool[Math.floor(Math.random() * pool.length)];
    }
  } else if (rarity === 'Raro') {
    // 5% de probabilidad de especial (máximo 85 de media, dando prioridad a las de menos media)
    // 95% cartas normales de entre 80-83 (dando prioridad a las de menos media)
    // NUNCA cartas 'Evo'
    const isSpecialRoll = Math.random() < 0.05;
    if (isSpecialRoll) {
      const specialPool = cards.filter(c => isSpecialQuality(c.calidad) && c.calidad !== 'Evo' && Number(c.media) <= 85);
      if (specialPool.length > 0) {
        chosenCard = pickWeighted(specialPool, c => Math.max(1, 86 - Number(c.media)));
      }
    }

    if (!chosenCard) {
      // Cartas normales entre 80 y 83 (prioridad a menor media)
      const normalPool = cards.filter(c => !isSpecialQuality(c.calidad) && c.calidad !== 'Evo' && Number(c.media) >= 80 && Number(c.media) <= 83);
      if (normalPool.length > 0) {
        chosenCard = pickWeighted(normalPool, c => Math.max(1, 84 - Number(c.media)));
      } else {
        // Fallback seguro rango 80-85
        const fallback = cards.filter(c => c.calidad !== 'Evo' && Number(c.media) >= 80 && Number(c.media) <= 85);
        if (fallback.length > 0) {
          chosenCard = pickWeighted(fallback, c => Math.max(1, 86 - Number(c.media)));
        }
      }
    }
  } else if (rarity === 'Épico') {
    // 10% probabilidad de especial (mínimo 84 y máximo 89 de media, prioridad a menor media)
    // 90% cartas normales de entre 84 y 89 (prioridad a menor media)
    // NUNCA cartas 'Evo'
    const isSpecialRoll = Math.random() < 0.10;
    if (isSpecialRoll) {
      const specialPool = cards.filter(c => isSpecialQuality(c.calidad) && c.calidad !== 'Evo' && Number(c.media) >= 84 && Number(c.media) <= 89);
      if (specialPool.length > 0) {
        chosenCard = pickWeighted(specialPool, c => Math.max(1, 90 - Number(c.media)));
      }
    }

    if (!chosenCard) {
      // Cartas normales entre 84 y 89 (prioridad a menor media)
      const normalPool = cards.filter(c => !isSpecialQuality(c.calidad) && c.calidad !== 'Evo' && Number(c.media) >= 84 && Number(c.media) <= 89);
      if (normalPool.length > 0) {
        chosenCard = pickWeighted(normalPool, c => Math.max(1, 90 - Number(c.media)));
      } else {
        const fallback = cards.filter(c => c.calidad !== 'Evo' && Number(c.media) >= 84 && Number(c.media) <= 89);
        if (fallback.length > 0) {
          chosenCard = pickWeighted(fallback, c => Math.max(1, 90 - Number(c.media)));
        }
      }
    }
  } else if (rarity === 'Legendario') {
    // Cartas +90 (mínimo 90 de media). Pudiendo salir todas (normales y especiales >= 90, NUNCA 'Evo' ni Bronce/Plata).
    // Prioridad a las más bajas y a las oro normales un poco más probables que las especiales pero sin pasarse
    // (Ej: Especial 91 más probable que Oro 93). Especiales también tienen que ser mínimo 90.
    const legPool = cards.filter(c => {
      const m = Number(c.media) || 0;
      return m >= 90 && c.calidad !== 'Evo' && c.calidad !== 'Bronce' && c.calidad !== 'Plata';
    });

    if (legPool.length > 0) {
      chosenCard = pickWeighted(legPool, c => {
        const m = Number(c.media) || 90;
        const baseWeight = Math.max(1, 100 - m); // Prioridad a menores medias
        const isSpecial = isSpecialQuality(c.calidad);
        const oroMultiplier = isSpecial ? 1.0 : 1.20; // Oro normal un poco más probable que especial de la misma media
        return baseWeight * oroMultiplier;
      });
    }
  } else {
    return { error: 'Rareza desconocida' };
  }

  if (!chosenCard) {
    // Fallback absoluto: cualquier carta que no sea 'Evo'
    const safeCards = cards.filter(c => c.calidad !== 'Evo');
    const finalPool = safeCards.length > 0 ? safeCards : cards;
    chosenCard = finalPool[Math.floor(Math.random() * finalPool.length)];
  }

  return chosenCard;
});

// Inventario (colecciones)
ipcMain.handle('inventory:get', () => {
  return {
    ok: true,
    cards: Object.fromEntries(ownedCards),
    packs: Object.fromEntries(ownedPacks),
    cardTraits: Object.fromEntries(cardTraits),
    cardUpgrades: Object.fromEntries(cardUpgrades),
    completedDeliverables: completedDeliverables,
    deliverableCompletions: deliverableCompletions,
    deliverableDailyCompletions: deliverableDailyCompletions,
    packPurchases: packPurchases,
    wallet: { ...wallet },
    stats: { ...userStats }, // Incluir estadísticas históricas
    kizunas: { ...userKizunas }, // Incluir kizunas aislados por usuario
    updatedAt: localUpdatedAt, // Timestamp de última actualización local
    resetAt: Number(profile.resetAt) || 0,
    isReset: Boolean(profile.isReset)
  };
});

// Obtener solo el monedero (wallet)
ipcMain.handle('wallet:get', () => {
  return { ...wallet };
});

ipcMain.handle('wallet:updateInfiniteCurrencies', (_e, payload) => {
  inTransaction = true;
  try {
    wallet = normalizeWallet({ ...wallet, ...(payload || {}) });
    logCriticalEvent('add', `Updated infinite currencies. Wallet: ${JSON.stringify(wallet)}`);
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('Error updating infinite currencies:', err);
  }
  return { ok: true, wallet: { ...wallet } };
});

// Descontar apuesta de gambling (Carrera de Cartas)
ipcMain.handle('gambling:bet', async (_e, amount) => {
  const amt = Number(amount) || 0;
  if (amt <= 0) return { error: 'Cantidad de apuesta inválida' };
  if ((wallet.coins || 0) < amt) {
    return { error: 'No tienes suficientes coins para realizar esta apuesta' };
  }
  
  inTransaction = true;
  try {
    wallet.coins -= amt;
    logCriticalEvent('remove', `Removed ${amt} coins. Reason: Placed bet in gambling game.`);
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('[GAMBLING] Error al guardar o sincronizar tras apuesta:', err);
  }
  return { ok: true, coins: wallet.coins };
});

// Acreditar ganancias de gambling (Carrera de Cartas, etc.)
ipcMain.handle('gambling:payout', async (_e, amount) => {
  const amt = Number(amount) || 0;
  if (amt <= 0) return { error: 'Cantidad de ganancia inválida' };
  
  inTransaction = true;
  try {
    wallet.coins = (wallet.coins || 0) + amt;
    incrementCoinsEarned(amt);
    logCriticalEvent('add', `Added ${amt} coins. Reason: Won gambling game.`);
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('[GAMBLING] Error al guardar o sincronizar tras victoria:', err);
  }
  return { ok: true, coins: wallet.coins };
});

// Añadir sobres al inventario (administración previa, vía CLI o pre-carga)
ipcMain.handle('inventory:addPack', (_e, { packId, count }) => {
  if (!packStore.has(packId)) return { error: 'Pack not found' };
  const c = Number(count) || 0; if (c <= 0) return { error: 'Count inválido' };
  
  inTransaction = true;
  try {
    const cur = ownedPacks.get(packId) || 0;
    ownedPacks.set(packId, cur + c);
    
    const pack = packStore.get(packId);
    const packName = pack ? pack.name : packId;
    logCriticalEvent('add', `Added pack: ${packName} (ID: ${packId}) x${c}. Reason: Manual admin addition.`);
    
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('Error manually adding pack:', err);
  }
  return { ok: true, packs: Object.fromEntries(ownedPacks) };
});

// ==================== WINDOW FOCUS ====================
// Forzar focus en la ventana (workaround para inputs en Electron)
ipcMain.handle('window:forceFocus', () => {
  const win = BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows()[0];
  if (win) {
    win.focus();
    win.webContents.focus();
    // CRÍTICO: Forzar que Electron reconozca que hay un input editable
    win.webContents.setIgnoreMenuShortcuts(true);
    // Esperar un poco y volver a habilitar shortcuts
    setTimeout(() => {
      win.webContents.setIgnoreMenuShortcuts(false);
    }, 200);
    return { ok: true };
  }
  return { ok: false };
});

// ==================== DISPLAY / SCREEN MODES ====================
function applyDisplayModeDirect(mode, subMode) {
  const win = BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows()[0];
  if (!win) return false;

  const targetMode = mode || 'fullscreen';
  const targetSubMode = subMode || 'windowed-1080';

  console.log(`[DISPLAY] Aplicando modo de pantalla: mode=${targetMode}, subMode=${targetSubMode}`);

  if (targetMode === 'fullscreen') {
    if (!win.isFullScreen()) {
      win.setFullScreen(true);
    }
  } else {
    // Salir de pantalla completa exclusiva si está activa
    if (win.isFullScreen()) {
      win.setFullScreen(false);
    }

    if (targetSubMode === 'borderless') {
      // Modo ventana sin bordes / maximizado
      if (!win.isMaximized()) {
        win.maximize();
      }
    } else {
      // Modo ventana (1920x1080) centrado
      if (win.isMaximized()) {
        win.unmaximize();
      }
      win.setResizable(true);
      win.setSize(1920, 1080);
      win.center();
    }
  }
  return true;
}

ipcMain.handle('window:setDisplayMode', async (_event, payload) => {
  const win = BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows()[0];
  if (!win) return { ok: false, error: 'No active window' };

  const mode = payload?.mode || 'fullscreen';
  const subMode = payload?.subMode || 'windowed-1080';

  applyDisplayModeDirect(mode, subMode);

  // Guardar en userSettings
  if (userSettings && typeof userSettings === 'object') {
    userSettings.displayMode = mode;
    userSettings.windowSubMode = subMode;
    try { saveInventory(); } catch {}
  }

  return {
    ok: true,
    mode,
    subMode,
    isFullScreen: win.isFullScreen(),
    isMaximized: win.isMaximized()
  };
});

ipcMain.handle('window:getDisplayMode', () => {
  const win = BrowserWindow.getFocusedWindow() || BrowserWindow.getAllWindows()[0];
  if (!win) {
    return {
      ok: true,
      mode: userSettings?.displayMode || 'fullscreen',
      subMode: userSettings?.windowSubMode || 'windowed-1080',
      isFullScreen: true
    };
  }

  const isFull = win.isFullScreen();
  return {
    ok: true,
    mode: isFull ? 'fullscreen' : 'windowed',
    subMode: userSettings?.windowSubMode || (win.isMaximized() ? 'borderless' : 'windowed-1080'),
    isFullScreen: isFull,
    isMaximized: win.isMaximized()
  };
});

// ==================== POWERS API ====================
// Obtener todos los poderes disponibles
ipcMain.handle('powers:getAll', () => Array.from(powerStore.values()));

// Obtener inventario de poderes del usuario
ipcMain.handle('powers:getInventory', () => {
  const powers = {};
  ownedPowers.forEach((data, id) => {
    powers[id] = data;
  });
  return { ok: true, powers };
});

// ==================== TRAITS API ====================
// Obtener todos los rasgos disponibles (directamente del JSON remoto oficial)
ipcMain.handle('traits:getAll', async () => {
  try {
    const rawUrl = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/traits.json?t=${Date.now()}`;
    const remoteData = await httpGetJson(rawUrl).catch(async () => {
      return await httpGetJson(`https://hugom1307.github.io/kvrcards-catalog/traits.json?t=${Date.now()}`).catch(() => null);
    });
    if (remoteData && (Array.isArray(remoteData) || Array.isArray(remoteData.traits))) {
      const list = Array.isArray(remoteData) ? remoteData : remoteData.traits;
      list.forEach(t => {
        if (t && t.id) traitStore.set(t.id, t);
      });
      console.log(`[TRAITS:GETALL] Devueltos ${list.length} rasgos directamente de remoto`);
      return list;
    }
  } catch (err) {
    console.warn('[TRAITS] Error en traits:getAll remoto:', err);
  }
  return Array.from(traitStore.values());
});

// ==================== TRAINERS API (MODO OFFLINE) ====================
function safeParseJsonMain(rawText) {
  if (typeof rawText !== 'string') return rawText;
  try {
    return JSON.parse(rawText);
  } catch (initialErr) {
    try {
      let cleaned = rawText.replace(/^\uFEFF/, '');
      cleaned = cleaned.replace(/\/\*[\s\S]*?\*\/|([^\\:]|^)\/\/.*$/gm, '$1');
      let prev;
      do {
        prev = cleaned;
        cleaned = cleaned.replace(/,\s*([\]}])/g, '$1');
        cleaned = cleaned.replace(/,\s*,/g, ',');
      } while (cleaned !== prev);
      return JSON.parse(cleaned);
    } catch {
      throw initialErr;
    }
  }
}

// Obtener todos los entrenadores configurados (directamente del JSON remoto oficial con sanitización)
ipcMain.handle('trainers:getAll', async () => {
  const urls = [
    `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/trainers.json?t=${Date.now()}`,
    `https://hugom1307.github.io/kvrcards-catalog/trainers.json?t=${Date.now()}`
  ];

  for (const url of urls) {
    try {
      let text = null;
      if (typeof net !== 'undefined' && net.fetch) {
        const resp = await net.fetch(url, { cache: 'no-store' });
        if (resp.ok) text = await resp.text();
      } else if (typeof fetch === 'function') {
        const resp = await fetch(url, { cache: 'no-store' });
        if (resp.ok) text = await resp.text();
      }
      if (text) {
        const parsed = safeParseJsonMain(text);
        const list = Array.isArray(parsed) 
          ? parsed 
          : (Array.isArray(parsed?.trainers) ? parsed.trainers : (Array.isArray(parsed?.entrenadores) ? parsed.entrenadores : []));
        if (list.length > 0) {
          console.log(`[TRAINERS:GETALL] ✅ ${list.length} entrenadores cargados desde ${url}`);
          return list;
        }
      }
    } catch (err) {
      console.warn('[TRAINERS] Error cargando entrenadores desde', url, err.message);
    }
  }

  // Fallback local en seeds
  try {
    const localSeeds = path.join(__dirname, '..', 'seeds', 'trainers.json');
    if (fs.existsSync(localSeeds)) {
      const data = safeParseJsonMain(fs.readFileSync(localSeeds, 'utf-8'));
      if (Array.isArray(data) && data.length > 0) return data;
      if (Array.isArray(data?.trainers) && data.trainers.length > 0) return data.trainers;
    }
  } catch {}

  // Fallback por defecto sincronizado con las dificultades actuales
  return [
    { 
      id: 'doman_kurimonzoso',
      nombre: 'Doman Kurimonzoso', 
      titulo: 'Estratega de la Niebla',
      imagen: 'https://hugom1307.github.io/kvrcards-catalog/image/botsoffline/doman.png',
      dificultades: ['principiante', 'amateur'],
      fondo: 'https://hugom1307.github.io/kvrcards-catalog/image/fondos/fondo_ronan_hatake.png',
      song: null,
      intervaloMedias: [76, 85],
      cartasObligatorias: ['doman_kurimonzoso', 'kai_senju_icono'],
      cartasProhibidas: ['kiri_uzumaki_icono'],
      poderes: 'aleatorio'
    },
    { 
      id: 'zion_hatake', 
      nombre: 'Zion Hatake', 
      titulo: 'Maestro del Rayo',
      imagen: 'https://hugom1307.github.io/kvrcards-catalog/image/botsoffline/zion.png',
      dificultades: ['amateur', 'experimentado'],
      fondo: 'https://hugom1307.github.io/kvrcards-catalog/image/fondos/fondo_ronan_hatake.png',
      song: null,
      intervaloMedias: [79, 84],
      cartasObligatorias: ['zion_hatake', 'kinan_hatake_icono', 'betocs_hatake_icono'],
      cartasProhibidas: [],
      poderes: 'aleatorio'
    },
    { 
      id: 'tan_uzumaki', 
      nombre: 'Tan Uzumaki', 
      titulo: 'Heredero Carmesí',
      imagen: 'https://hugom1307.github.io/kvrcards-catalog/image/botsoffline/tan.png',
      dificultades: ['profesional'],
      fondo: null,
      song: null,
      intervaloMedias: [73, 87],
      cartasObligatorias: ['tan_uzumaki', 'manuel_hyuga_icono'],
      cartasProhibidas: ['kiri_uzumaki_icono'],
      poderes: 'aleatorio'
    },
    {
      id: 'shinobi_inmortal',
      nombre: 'Inmortal Shinobi',
      titulo: 'Deidad de las Sombras',
      imagen: 'https://api.dicebear.com/7.x/avataaars/svg?seed=inmo-legend',
      dificultades: ['dios-antiguo', 'inmo'],
      fondo: 'https://hugom1307.github.io/kvrcards-catalog/assets/backgrounds/inmo_arena.jpg',
      song: null,
      intervaloMedias: [90, 99],
      cartasObligatorias: ['kaguya_otsutsuki'],
      cartasProhibidas: [],
      poderes: 'aleatorio'
    }
  ];
});

// Debug: Modificar traits
ipcMain.handle('traits:debugModify', (_e, amount) => {
  const val = Number(amount) || 0;
  inTransaction = true;
  try {
    wallet.traits = Math.max(0, (wallet.traits || 0) + val);
    logCriticalEvent('debug', `Debug modified traits: ${val}. Balance: ${wallet.traits}`);
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('Error debug modifying traits:', err);
  }
  return { ok: true, traits: wallet.traits, newBalance: wallet.traits };
});

// Debug: Asignar un rasgo a una carta sin coste ni restricciones
ipcMain.handle('traits:debugAssign', (_e, { cardId, traitId, instanceId }) => {
  if (!cardId) return { error: 'ID de carta no especificado' };
  if (!traitId) return { error: 'ID de rasgo no especificado' };

  const baseCardId = String(cardId);
  const targetTraitId = String(traitId);

  // Asegurar que el usuario posee al menos 1 copia de la carta
  const count = ownedCards.get(baseCardId) || 0;
  if (count < 1) {
    ownedCards.set(baseCardId, 1);
  }

  // Limpiar cualquier entrada legacy asociada directamente al baseCardId
  if (cardTraits.has(baseCardId)) {
    cardTraits.delete(baseCardId);
  }

  let targetInstanceId = instanceId ? String(instanceId) : null;
  if (!targetInstanceId || !cardTraits.has(targetInstanceId)) {
    // Buscar si existe alguna instancia asignada a esta carta
    for (const [instId, data] of cardTraits.entries()) {
      const cid = typeof data === 'object' && data ? data.cardId : instId;
      if (cid === baseCardId && instId.startsWith('trait_')) {
        targetInstanceId = instId;
        break;
      }
    }
  }

  if (!targetInstanceId || !targetInstanceId.startsWith('trait_')) {
    targetInstanceId = `trait_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
  }

  cardTraits.set(targetInstanceId, { cardId: baseCardId, traitId: targetTraitId });

  inTransaction = true;
  try {
    logCriticalEvent('debug', `[DEBUG] Assigned trait: ${targetTraitId} to card: ${baseCardId} (instance: ${targetInstanceId})`);
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('Error guardando inventario en debugAssign:', err);
  }

  return { ok: true, cardId: baseCardId, traitId: targetTraitId, instanceId: targetInstanceId };
});

// Debug: Quitar rasgo de una carta
ipcMain.handle('traits:debugRemove', (_e, { cardId, instanceId }) => {
  if (!cardId && !instanceId) return { error: 'Especifica carta o instancia' };

  let removed = 0;
  if (instanceId && cardTraits.has(String(instanceId))) {
    cardTraits.delete(String(instanceId));
    removed++;
  } else if (cardId) {
    const baseCardId = String(cardId);
    const toDelete = [];
    for (const [instId, data] of cardTraits.entries()) {
      const cid = typeof data === 'object' && data ? data.cardId : instId;
      if (cid === baseCardId) {
        toDelete.push(instId);
      }
    }
    for (const instId of toDelete) {
      cardTraits.delete(instId);
      removed++;
    }
  }

  inTransaction = true;
  try {
    logCriticalEvent('debug', `[DEBUG] Removed trait from card: ${cardId || instanceId}`);
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('Error guardando inventario en debugRemove:', err);
  }

  return { ok: true, removedCount: removed };
});

// Asignar un rasgo a una carta
ipcMain.handle('traits:assign', (_e, { uniqueCardId, traitId, createNew }) => {
  if (!traitStore.has(traitId)) return { error: 'Rasgo no encontrado' };
  if (wallet.traits < 1) return { error: 'No tienes suficientes Traits' };
  
  let targetId = String(uniqueCardId || '');
  
  // Determinar el cardId base
  let baseCardId = targetId;
  if (cardTraits.has(targetId)) {
    const existingObj = cardTraits.get(targetId);
    baseCardId = typeof existingObj === 'object' ? existingObj.cardId : targetId;
  } else if (targetId.startsWith('trait_')) {
    const existing = cardTraits.get(targetId);
    if (existing) baseCardId = typeof existing === 'object' ? existing.cardId : targetId;
  }

  const count = ownedCards.get(baseCardId) || 0;
  if (count < 1) {
    console.log('[MAIN] ERROR: No posees esta carta base:', baseCardId);
    return { error: 'No posees esta carta' };
  }

  // Buscar instancias existentes de traits para esta carta
  const existingInstancesForCard = [];
  for (const [instId, data] of cardTraits.entries()) {
    const cid = typeof data === 'object' && data ? data.cardId : instId;
    if (cid === baseCardId) {
      existingInstancesForCard.push({ instanceId: instId, traitId: typeof data === 'object' ? data.traitId : data });
    }
  }

  console.log('[MAIN] ============ TRAIT ASSIGNMENT START ============');
  console.log('[MAIN] uniqueCardId:', uniqueCardId, 'baseCardId:', baseCardId);
  console.log('[MAIN] traitId:', traitId);
  console.log('[MAIN] createNew:', createNew);
  console.log('[MAIN] Owned copies:', count, 'Existing trait instances:', existingInstancesForCard.length);

  // Si targetId ya existe en cardTraits, sobrescribirlo directamente
  if (cardTraits.has(targetId)) {
    cardTraits.set(targetId, { cardId: baseCardId, traitId: traitId });
    console.log('[MAIN] Overwritten existing instance:', targetId, 'with new trait:', traitId);
  } else if (!createNew && existingInstancesForCard.length > 0) {
    // Si no es createNew o el targetId no coincide exactamente, sobrescribir la primera instancia existente
    targetId = existingInstancesForCard[0].instanceId;
    cardTraits.set(targetId, { cardId: baseCardId, traitId: traitId });
    console.log('[MAIN] Overwritten instance by card lookup:', targetId, 'with new trait:', traitId);
  } else {
    // Es createNew o nueva asignación
    // Si ya todas las copias tienen trait (o no hay copias sin trait disponibles), SOBRESCRIBIR la primera en vez de duplicar
    if (existingInstancesForCard.length >= count && existingInstancesForCard.length > 0) {
      targetId = existingInstancesForCard[0].instanceId;
      cardTraits.set(targetId, { cardId: baseCardId, traitId: traitId });
      console.log('[MAIN] All owned copies have traits. Overwriting existing instance:', targetId);
    } else {
      // Crear nueva instancia única para una copia adicional sin trait
      targetId = `trait_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
      cardTraits.set(targetId, { cardId: baseCardId, traitId: traitId });
      console.log('[MAIN] Created new trait instance:', targetId, 'for card:', baseCardId);
    }
  }

  inTransaction = true;
  try {
    wallet.traits -= 1;
    
    const trait = traitStore.get(traitId);
    const traitName = trait ? trait.name : traitId;
    const cardName = cardStore.get(baseCardId)?.name || baseCardId;
    logCriticalEvent('add', `Assigned trait: ${traitName} (ID: ${traitId}) to card: ${cardName} (Instance ID: ${targetId}). Reason: Trait assignment.`);
    
    console.log('[MAIN] Trait assigned successfully:', targetId, '->', traitId);
    console.log('[MAIN] Total trait instances:', cardTraits.size);
    
    inTransaction = false;
    saveInventory();
  } catch (e) {
    inTransaction = false;
    console.error('Error saving inventory after trait assignment:', e);
  }
  
  return { ok: true, newBalance: wallet.traits, assignedTrait: traitId, newUniqueId: targetId };
});

// Añadir poder al inventario
ipcMain.handle('powers:add', (_e, powerId) => {
  const power = powerStore.get(powerId);
  if (!power) return { error: 'Poder no encontrado' };
  
  const current = ownedPowers.get(powerId);
  
  if (power.permanent && current) {
    return { ok: true, alreadyOwned: true, power: current };
  }
  
  inTransaction = true;
  try {
    if (current) {
      if (power.consumable) {
        current.uses = (current.uses || 0) + 1;
      }
    } else {
      if (power.consumable) {
        ownedPowers.set(powerId, { uses: 1 });
      } else {
        ownedPowers.set(powerId, { permanent: true });
      }
    }
    
    logCriticalEvent('add', `Added power: ${power.name || powerId} (ID: ${powerId}). Reason: Added power.`);
    
    inTransaction = false;
    saveInventory();
  } catch (error) {
    inTransaction = false;
    console.error('Error guardando poder:', error);
  }
  
  return { ok: true, power: ownedPowers.get(powerId) };
});

// Usar/consumir poder (decrementar uses)
ipcMain.handle('powers:use', (_e, powerId) => {
  const power = powerStore.get(powerId);
  if (!power) return { error: 'Poder no encontrado' };
  
  const current = ownedPowers.get(powerId);
  if (!current) {
    return { error: 'No tienes este poder' };
  }
  
  if (power.permanent) {
    return { ok: true, permanent: true, power: current };
  }
  
  if (current.uses && current.uses > 0) {
    inTransaction = true;
    try {
      current.uses--;
      
      logCriticalEvent('remove', `Consumed power: ${power.name || powerId} (ID: ${powerId}). Remaining uses: ${current.uses || 0}.`);
      
      if (current.uses <= 0) {
        ownedPowers.delete(powerId);
      }
      
      inTransaction = false;
      saveInventory();
    } catch (error) {
      inTransaction = false;
      console.error('Error guardando poder:', error);
    }
  } else {
    return { error: 'No tienes usos disponibles de este poder' };
  }
  
  const remaining = ownedPowers.get(powerId);
  return { ok: true, remaining: remaining || null };
});

// ==================== MISSIONS API ====================
// Obtener estadísticas del usuario
ipcMain.handle('missions:getStats', () => {
  return { ok: true, stats: { ...userStats } };
});

// Incrementar victorias (para evoluciones)
ipcMain.handle('missions:addBattleWon', () => {
  userStats.battlesWon = (userStats.battlesWon || 0) + 1;
  console.log('[STATS] Batalla ganada, total:', userStats.battlesWon);
  saveInventory();
  return { ok: true, battlesWon: userStats.battlesWon };
});

// Incrementar batallas jugadas (para evoluciones y misiones)
ipcMain.handle('missions:addBattlePlayed', () => {
  userStats.battlesPlayed = (userStats.battlesPlayed || 0) + 1;
  console.log('[STATS] Batalla jugada, total:', userStats.battlesPlayed);
  saveInventory();
  return { ok: true, battlesPlayed: userStats.battlesPlayed };
});

// Añadir monedas (para misiones)
ipcMain.handle('missions:addCoins', (_e, amount) => {
  const amt = Number(amount) || 0;
  if (amt <= 0) return { error: 'Cantidad inválida' };
  
  inTransaction = true;
  try {
    wallet.coins = (wallet.coins || 0) + amt;
    incrementCoinsEarned(amt);
    logCriticalEvent('add', `Added coins: ${amt}. Reason: Mission reward.`);
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('Error adding mission coins:', err);
  }
  return { ok: true, coins: wallet.coins };
});

// Añadir KvR (para misiones)
ipcMain.handle('missions:addKvR', (_e, amount) => {
  const amt = Number(amount) || 0;
  if (amt <= 0) return { error: 'Cantidad inválida' };
  
  inTransaction = true;
  try {
    wallet.kvr = (wallet.kvr || 0) + amt;
    logCriticalEvent('add', `Added kvr: ${amt}. Reason: Mission reward.`);
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('Error adding mission KvR:', err);
  }
  return { ok: true, kvr: wallet.kvr };
});

// Añadir Traits (para misiones, modo infinito, prestigio)
ipcMain.handle('missions:addTraits', (_e, amount) => {
  const amt = Number(amount) || 0;
  if (amt <= 0) return { error: 'Cantidad inválida' };
  
  inTransaction = true;
  try {
    wallet.traits = Math.max(0, (wallet.traits || 0) + amt);
    logCriticalEvent('add', `Added traits: ${amt}. Reason: Mission / Infinite reward. Balance: ${wallet.traits}`);
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('Error adding mission traits:', err);
  }
  return { ok: true, traits: wallet.traits, newBalance: wallet.traits };
});

// Añadir sobre (para misiones)
ipcMain.handle('missions:addPack', (_e, packIdOrObj, countArg) => {
  const packId = (typeof packIdOrObj === 'object' && packIdOrObj !== null)
    ? (packIdOrObj.packId || packIdOrObj.id || packIdOrObj.sobreId || packIdOrObj.pack || packIdOrObj.targetId)
    : packIdOrObj;
  let count = (typeof packIdOrObj === 'object' && packIdOrObj !== null)
    ? (Number(packIdOrObj.count || packIdOrObj.amount || packIdOrObj.cantidad || packIdOrObj.quantity) || 1)
    : (Number(countArg) || 1);
  if (count <= 0) count = 1;

  let targetPackId = String(packId || '').trim();
  if (!targetPackId) return { error: 'ID de pack inválido' };

  if (!packStore.has(targetPackId)) {
    const lower = targetPackId.toLowerCase();
    const cleanLower = lower.replace(/[_\-\s]/g, '');
    for (const [key, pack] of packStore.entries()) {
      const kLower = String(key).toLowerCase();
      const pName = String(pack?.name || '').toLowerCase();
      if (kLower === lower || pName === lower || kLower.replace(/[_\-\s]/g, '') === cleanLower || pName.replace(/[_\-\s]/g, '') === cleanLower) {
        targetPackId = key;
        break;
      }
    }
  }
  
  inTransaction = true;
  try {
    const cur = ownedPacks.get(targetPackId) || 0;
    ownedPacks.set(targetPackId, cur + count);
    
    const packName = packStore.get(targetPackId)?.name || targetPackId;
    logCriticalEvent('add', `Added pack: ${packName} (ID: ${targetPackId}) x${count}. Reason: Mission reward.`);
    
    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('Error adding mission pack:', err);
  }
  return { ok: true, packs: Object.fromEntries(ownedPacks), packId: targetPackId, count };
});

// Añadir carta (para misiones, prestigio, kizunas, recompensas)
ipcMain.handle('missions:addCard', (_e, cardId, countArg) => {
  let targetId = String(cardId || '').trim();
  if (!targetId) return { error: 'ID de carta inválido' };
  let count = Number(countArg) || 1;
  if (count <= 0) count = 1;

  if (!cardStore.has(targetId)) {
    const SUFFIX_REGEX = /_(?:icono|heroe|oro|plata|bronce|especial|comun|evo|prime|iconoprime|iconosuperprime|superprime|legendaria)$/i;
    const lower = targetId.toLowerCase();
    const withoutSuffix = lower.replace(SUFFIX_REGEX, '');

    let foundKey = null;
    for (const key of cardStore.keys()) {
      const kLower = String(key).toLowerCase();
      const kWithoutSuffix = kLower.replace(SUFFIX_REGEX, '');
      if (kLower === lower || kLower === withoutSuffix || kWithoutSuffix === lower || kWithoutSuffix === withoutSuffix) {
        foundKey = key;
        break;
      }
    }

    if (!foundKey) {
      for (const [key, card] of cardStore.entries()) {
        const cName = String(card?.name || card?.nombre || '').trim().toLowerCase();
        if (cName && (cName === lower || cName === withoutSuffix)) {
          foundKey = key;
          break;
        }
      }
    }

    if (foundKey) {
      console.log(`[REWARDS] missions:addCard resolución de alias: "${cardId}" -> "${foundKey}"`);
      targetId = foundKey;
    } else {
      console.warn(`[REWARDS] missions:addCard: Carta no encontrada en catálogo "${cardId}", añadiendo como id directo para no perder recompensa.`);
    }
  }

  inTransaction = true;
  try {
    const cur = ownedCards.get(targetId) || 0;
    ownedCards.set(targetId, cur + count);
    incrementCardsObtained(count);

    const cardName = cardStore.get(targetId)?.name || targetId;
    logCriticalEvent('add', `Added card: ${cardName} (ID: ${targetId}) x${count}. Reason: Mission/Prestige reward.`);

    inTransaction = false;
    saveInventory();
  } catch (err) {
    inTransaction = false;
    console.error('Error adding mission card:', err);
  }
  return { ok: true, cards: Object.fromEntries(ownedCards), cardId: targetId, count };
});
// ==================== END MISSIONS API ====================

// ==================== RANKINGS API ====================
// Obtener lista de todos los usuarios del servidor remoto
async function fetchAllRemoteUsers() {
  console.log('[fetchAllRemoteUsers] remoteConfig.inventory:', JSON.stringify(remoteConfig.inventory));
  console.log('[fetchAllRemoteUsers] inventoryEffectiveBaseUrl:', inventoryEffectiveBaseUrl);
  if (!remoteConfig.inventory?.enabled) {
    console.log('[fetchAllRemoteUsers] Inventory no habilitado, retornando null');
    return null; // Retorna null si no está habilitado
  }
  const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
  console.log('[fetchAllRemoteUsers] urlBase:', urlBase);
  if (!urlBase) {
    console.log('[fetchAllRemoteUsers] No hay URL base, retornando null');
    return null; // Retorna null si no hay URL configurada
  }
  const url = new URL('api/inventory', urlBase).toString();
  console.log('[fetchAllRemoteUsers] Fetching from:', url);
  
  try {
    const result = await httpGetJson(url);
    console.log('[fetchAllRemoteUsers] Result:', JSON.stringify(result));
    if (result && Array.isArray(result.users)) {
      console.log('[fetchAllRemoteUsers] Retornando', result.users.length, 'usuarios');
      return result.users;
    }
    console.log('[fetchAllRemoteUsers] Result no válido, retornando null');
    return null;
  } catch (e) {
    console.log('[fetchAllRemoteUsers] Error:', e);
    console.log('[RANKINGS] Remote server not available, will use local data');
    return null;
  }
}

// Obtener datos de un usuario remoto
async function fetchRemoteUserData(username) {
  if (!remoteConfig.inventory?.enabled) return null;
  const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
  if (!urlBase) return null;
  const url = new URL('api/inventory/' + encodeURIComponent(username), urlBase).toString();
  
  try {
    const data = await httpGetJson(url);
    return data;
  } catch (e) {
    return null;
  }
}

function getCurrentMondayTimestamp() {
  const now = new Date();
  const dayOfWeek = now.getDay();
  const currentMonday = new Date(now);
  const diff = (dayOfWeek === 0 ? -6 : 1) - dayOfWeek;
  currentMonday.setDate(now.getDate() + diff);
  currentMonday.setHours(0, 0, 0, 0);
  return currentMonday.getTime();
}

function getEffectiveWeeklyValue(userData, category, currentMondayTimestamp) {
  const weekStart = Number(userData?.weeklyStats?.weekStart) || 0;
  if (!weekStart || weekStart < currentMondayTimestamp) {
    return 0;
  }

  if (category === 'cards') return Number(userData.weeklyStats.cards) || 0;
  if (category === 'packs') return Number(userData.weeklyStats.packs) || 0;
  if (category === 'coins') return Number(userData.weeklyStats.coins) || 0;
  return 0;
}

async function fetchGlobalRankings() {
  const now = Date.now();
  if (clientRankingsCache.data && (now - clientRankingsCache.timestamp < CLIENT_RANKINGS_CACHE_TTL_MS)) {
    return clientRankingsCache.data;
  }
  if (!remoteConfig.inventory?.enabled) return null;
  const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
  if (!urlBase) return null;
  const url = new URL('api/rankings', urlBase).toString();
  try {
    const res = await httpGetJson(url);
    if (res && res.weekly && res.historical) {
      clientRankingsCache = { data: res, timestamp: now };
      return res;
    }
  } catch (e) {
    console.warn('[RANKINGS] No se pudo obtener /api/rankings, usando fallback:', e.message);
  }
  return null;
}

// Obtener rankings semanales (100% remoto con endpoint optimizado y caché)
ipcMain.handle('rankings:getWeekly', async (_e, category) => {
  console.log('[RANKINGS] getWeekly called with category:', category);
  
  // 1. Intentar endpoint ligero /api/rankings (consume < 1KB en vez de 5MB)
  try {
    const globalRankings = await fetchGlobalRankings();
    if (globalRankings && globalRankings.weekly && Array.isArray(globalRankings.weekly[category])) {
      return { ok: true, rankings: globalRankings.weekly[category] };
    }
  } catch (errFast) {
    console.warn('[RANKINGS] Error en ruta rápida de rankings semanales:', errFast.message);
  }

  // 2. Fallback de cálculo manual si el servidor no tiene /api/rankings
  const rankings = [];
  const debugInfo = {
    remoteConfigInventory: remoteConfig.inventory,
    inventoryEffectiveBaseUrl: inventoryEffectiveBaseUrl,
  };
  const currentMondayTimestamp = getCurrentMondayTimestamp();
  
  try {
    console.log('[RANKINGS] Calling fetchAllRemoteUsers fallback...');
    const usernames = await fetchAllRemoteUsers();
    debugInfo.usernames = usernames;
    
    if (!usernames || usernames.length === 0) {
      return { ok: true, rankings: [], debug: debugInfo };
    }
    
    const userDataPromises = usernames.map(username => fetchRemoteUserData(username));
    const usersData = await Promise.all(userDataPromises);
    debugInfo.usersData = usersData;
    
    for (let i = 0; i < usersData.length; i++) {
      const userData = usersData[i];
      if (!userData || !userData.weeklyStats) continue;
      if (userData.isAdmin === true || userData.role === 'admin') continue;

      const value = getEffectiveWeeklyValue(userData, category, currentMondayTimestamp);
      rankings.push({
        username: userData.username || usernames[i],
        value
      });
    }
  } catch (e) {
    console.error('[RANKINGS] Error getting weekly rankings fallback:', e);
    return { ok: false, error: 'Error connecting to server' };
  }
  
  rankings.sort((a, b) => b.value - a.value);
  const top10 = rankings.slice(0, 10);
  return { ok: true, rankings: top10, debug: debugInfo };
});

// Obtener rankings históricos (100% remoto con endpoint optimizado y caché)
ipcMain.handle('rankings:getHistorical', async (_e, category) => {
  console.log('[RANKINGS] getHistorical called with category:', category);
  
  // 1. Intentar endpoint ligero /api/rankings (consume < 1KB en vez de 5MB)
  try {
    const globalRankings = await fetchGlobalRankings();
    if (globalRankings && globalRankings.historical && Array.isArray(globalRankings.historical[category])) {
      return { ok: true, rankings: globalRankings.historical[category] };
    }
  } catch (errFast) {
    console.warn('[RANKINGS] Error en ruta rápida de rankings históricos:', errFast.message);
  }

  // 2. Fallback de cálculo manual si el servidor no tiene /api/rankings
  const rankings = [];
  try {
    const usernames = await fetchAllRemoteUsers();
    if (!usernames || usernames.length === 0) {
      return { ok: true, rankings: [] };
    }
    
    const userDataPromises = usernames.map(username => fetchRemoteUserData(username));
    const usersData = await Promise.all(userDataPromises);
    
    for (let i = 0; i < usersData.length; i++) {
      const userData = usersData[i];
      if (!userData || !userData.stats) continue;
      if (userData.isAdmin === true || userData.role === 'admin') continue;
      
      let value = 0;
      if (category === 'cards') value = userData.stats.totalCardsObtained || 0;
      else if (category === 'packs') value = userData.stats.totalPacksOpened || 0;
      else if (category === 'coins') value = userData.stats.totalCoinsEarned || 0;
      
      rankings.push({
        username: userData.username || usernames[i],
        value
      });
    }
  } catch (e) {
    console.error('[RANKINGS] Error getting historical rankings fallback:', e);
    return { ok: false, error: 'Error connecting to server' };
  }
  
  rankings.sort((a, b) => b.value - a.value);
  const top10 = rankings.slice(0, 10);
  return { ok: true, rankings: top10 };
});

// Obtener perfil completo de un usuario (100% remoto)
ipcMain.handle('profile:getUserProfile', async (_e, username) => {
  try {
    // Obtener del servidor remoto
    let userData = await fetchRemoteUserData(username);
    
    // Fallback: Si no se pudo obtener del servidor y coincide con el usuario activo, usar datos locales
    if (!userData && username === (profile.username || '').trim()) {
      const { inventoryFile } = getDataPaths();
      const inv = readJSON(inventoryFile, { users: {} });
      userData = inv?.users?.[username] || null;
    }
    
    if (!userData) {
      return { error: 'Usuario no encontrado en el servidor' };
    }
    
    console.log('[PROFILE DEBUG] userData.profileImage:', userData.profileImage);
    console.log('[PROFILE DEBUG] userData.currentTitle:', userData.currentTitle);
    const resolvedBackground = userData.currentBackground || userData.settings?.currentBackground || 'default';
    const resolvedUnlockedBackgrounds = (Array.isArray(userData.unlockedBackgrounds) && userData.unlockedBackgrounds.length > 0)
      ? userData.unlockedBackgrounds
      : (Array.isArray(userData.settings?.unlockedBackgrounds) ? userData.settings.unlockedBackgrounds : ['default']);
    console.log('[PROFILE DEBUG] userData.currentBackground resolved:', resolvedBackground);
    console.log('[PROFILE DEBUG] userData.showcaseCards:', userData.showcaseCards);
    
    // Contar cartas únicas (que tengan al menos 1)
    let uniqueCards = 0;
    if (userData.cards) {
      uniqueCards = Object.values(userData.cards).filter(count => count > 0).length;
    }
    
    // Obtener las 3 cartas del showcase del usuario
    const showcaseCards = [];
    if (userData.showcaseCards && Array.isArray(userData.showcaseCards)) {
      for (const cardId of userData.showcaseCards) {
        if (cardId) {
          const cardData = cardStore.get(cardId);
          if (cardData) {
            showcaseCards.push({
              id: cardId,
              name: cardData.name || 'Sin nombre',
              image: cardData.imageUrl || cardData.image || '',
              count: userData.cards?.[cardId] || 0
            });
          }
        }
      }
    }
    
    const profile = {
      username,
      profileImage: userData.profileImage || '',
      currentTitle: userData.currentTitle || '',
      unlockedTitles: Array.isArray(userData.unlockedTitles) ? userData.unlockedTitles : ['novato'],
      currentBackground: resolvedBackground,
      unlockedBackgrounds: resolvedUnlockedBackgrounds,
      stats: {
        totalCardsObtained: (userData.stats?.totalCardsObtained || 0),
        totalPacksOpened: (userData.stats?.totalPacksOpened || 0),
        totalCoinsEarned: (userData.stats?.totalCoinsEarned || 0),
        uniqueCards
      },
      weeklyStats: {
        cards: (userData.weeklyStats?.cards || 0),
        packs: (userData.weeklyStats?.packs || 0),
        coins: (userData.weeklyStats?.coins || 0)
      },
      showcaseCards // Las 3 cartas del showcase
    };
    
    console.log('[PROFILE] Perfil obtenido para:', username);
    return { ok: true, profile };
  } catch (e) {
    console.error('[PROFILE] Error getting user profile:', e);
    return { error: 'Error al obtener perfil: ' + String(e) };
  }
});

// Actualizar datos del perfil del usuario (imagen, título, showcase, fondos)
ipcMain.handle('profile:updateUserProfile', async (_e, data) => {
  const currentUser = (profile.username || '').trim();
  if (!currentUser) {
    return { error: 'No hay sesión activa' };
  }
  
  console.log('[PROFILE DEBUG] Actualizando perfil para:', currentUser);
  console.log('[PROFILE DEBUG] Datos recibidos:', JSON.stringify(data, null, 2));
  
  // Actualizar en memoria
  if (data.profileImage !== undefined) {
    profile.profileImage = data.profileImage;
    profileImageDirty = true;
  }
  if (data.currentTitle !== undefined) {
    profile.currentTitle = data.currentTitle;
  }
  if (data.unlockedTitles !== undefined && Array.isArray(data.unlockedTitles)) {
    const existing = Array.isArray(profile.unlockedTitles) ? profile.unlockedTitles : ['novato'];
    profile.unlockedTitles = Array.from(new Set([...existing, ...data.unlockedTitles, 'novato'])).filter(Boolean);
  }
  if (data.currentBackground !== undefined) {
    profile.currentBackground = data.currentBackground;
    if (!userSettings) userSettings = {};
    userSettings.currentBackground = data.currentBackground;
  }
  if (data.unlockedBackgrounds !== undefined && Array.isArray(data.unlockedBackgrounds)) {
    const existing = Array.isArray(profile.unlockedBackgrounds) ? profile.unlockedBackgrounds : ['default'];
    profile.unlockedBackgrounds = Array.from(new Set([...existing, ...data.unlockedBackgrounds, 'default'])).filter(Boolean);
    if (!userSettings) userSettings = {};
    userSettings.unlockedBackgrounds = profile.unlockedBackgrounds;
  }
  if (data.showcaseCards !== undefined && Array.isArray(data.showcaseCards)) {
    profile.showcaseCards = data.showcaseCards;
  }
  
  // Guardar en inventario
  saveInventory();
  
  // Forzar sincronización remota inmediata con imagen si cambió
  try {
    lastSyncHash = null;
    const syncRes = await syncInventoryRemote({ includeProfileImage: true, force: true });
    console.log('[PROFILE] Sincronización remota tras equipar/actualizar fondo:', syncRes);
  } catch (errSync) {
    console.error('[PROFILE] Error en sincronización remota tras actualizar perfil:', errSync);
  }
  
  console.log('[PROFILE] Perfil actualizado para:', currentUser, 'unlockedTitles:', profile.unlockedTitles, 'currentBackground:', profile.currentBackground);
  return { ok: true, currentBackground: profile.currentBackground };
});
// ==================== END RANKINGS API ====================

// Definiciones (cartas/packs) ahora son de solo lectura y vienen del paquete o carpeta externa

function getCardCount(userInv) {
  if (!userInv || !userInv.cards || typeof userInv.cards !== 'object') return 0;
  return Object.values(userInv.cards).reduce((sum, n) => sum + (Number(n) || 0), 0);
}

function getPackCount(userInv) {
  if (!userInv || !userInv.packs || typeof userInv.packs !== 'object') return 0;
  return Object.values(userInv.packs).reduce((sum, n) => sum + (Number(n) || 0), 0);
}

function validateInventorySave(currentUser, newCardsObj, newPacksObj, previousUserInv) {
  if (!newCardsObj || typeof newCardsObj !== 'object') {
    throw new Error('Cards inventory is null, undefined, or not an object');
  }
  
  const newCardsCount = Object.values(newCardsObj).reduce((sum, n) => sum + (Number(n) || 0), 0);
  let prevCardsCount = 0;
  if (previousUserInv && previousUserInv.cards && typeof previousUserInv.cards === 'object') {
    prevCardsCount = Object.values(previousUserInv.cards).reduce((sum, n) => sum + (Number(n) || 0), 0);
  }
  
  if (prevCardsCount > 0) {
    if (newCardsCount === 0) {
      throw new Error(`CRITICAL: Attempted to overwrite inventory with 0 cards (previous count: ${prevCardsCount})`);
    }
    
    const ratio = newCardsCount / prevCardsCount;
    if (prevCardsCount >= 10 && ratio < 0.1) {
      throw new Error(`CRITICAL: Attempted to save inventory with >90% card loss. Previous: ${prevCardsCount}, New: ${newCardsCount} (Ratio: ${ratio.toFixed(2)})`);
    }
  }
  return true;
}

function validateIncomingInventory(incomingData, context = 'unknown') {
  if (!incomingData || typeof incomingData !== 'object') {
    throw new Error(`Incoming data for ${context} is null or not an object`);
  }
  
  const incomingCardsCount = getCardCount(incomingData);
  const currentCardsCount = Array.from(ownedCards.values()).reduce((sum, n) => sum + (Number(n) || 0), 0);
  
  console.log(`[VALIDATION] context: ${context}, current in-memory cards: ${currentCardsCount}, incoming cards: ${incomingCardsCount}`);
  
  if (currentCardsCount > 0) {
    if (incomingCardsCount === 0) {
      throw new Error(`CRITICAL: Incoming inventory for ${context} has 0 cards. Current in-memory cards: ${currentCardsCount}. Aborting to prevent overwrite!`);
    }
    
    const ratio = incomingCardsCount / currentCardsCount;
    if (currentCardsCount >= 10 && ratio < 0.1) {
      throw new Error(`CRITICAL: Incoming inventory for ${context} has >90% card loss. Current: ${currentCardsCount}, Incoming: ${incomingCardsCount} (Ratio: ${ratio.toFixed(2)}). Aborting!`);
    }
  }
  return true;
}

function selectValidInventory(username, remoteData, localData, backupData) {
  const localInv = (localData && localData.users) ? localData.users[username] : null;
  const backupInv = (backupData && backupData.users) ? backupData.users[username] : null;
  
  const localCards = getCardCount(localInv);
  const backupCards = getCardCount(backupInv);
  
  console.log(`[INVENTORY VALIDATION] Local cards: ${localCards}, Backup cards: ${backupCards}`);
  
  let bestLocalInv = null;
  let localSource = 'none';
  let bestLocalCards = 0;
  
  if (localInv && backupInv) {
    if (localCards === 0 && backupCards > 0) {
      console.warn(`[INVENTORY] Local inventory is empty but backup has ${backupCards} cards. Restoring backup!`);
      bestLocalInv = backupInv;
      localSource = 'backup';
      bestLocalCards = backupCards;
      logCriticalEvent('restore', `Restored inventory from backup. Cards: ${backupCards}`);
    } else if (localCards > 0 && backupCards >= localCards) {
      bestLocalInv = localInv;
      localSource = 'local';
      bestLocalCards = localCards;
    } else {
      bestLocalInv = localInv;
      localSource = 'local';
      bestLocalCards = localCards;
    }
  } else if (localInv) {
    bestLocalInv = localInv;
    localSource = 'local';
    bestLocalCards = localCards;
  } else if (backupInv) {
    console.warn(`[INVENTORY] Local inventory not found, but backup exists. Loading from backup!`);
    bestLocalInv = backupInv;
    localSource = 'backup';
    bestLocalCards = backupCards;
    logCriticalEvent('restore', `Restored inventory from backup. Cards: ${backupCards}`);
  }
  
  let selectedInv = null;
  let finalSource = 'none';
  
  const hasRemote = !!(remoteData && (remoteData.username === username || remoteData.ok));
  const remoteCards = hasRemote ? getCardCount(remoteData) : 0;
  
  if (hasRemote) {
    console.log(`[INVENTORY VALIDATION] Remote cards found: ${remoteCards}`);
    
    if (bestLocalCards > 0 && remoteCards === 0) {
      console.error(`[INVENTORY] CRITICAL: Remote returned 0 cards, but local has ${bestLocalCards} cards. Ignoring remote data to prevent loss!`);
      selectedInv = bestLocalInv;
      finalSource = `local_fallback_from_remote_zero (${localSource})`;
    } else if (bestLocalCards >= 10 && remoteCards < bestLocalCards * 0.1) {
      console.error(`[INVENTORY] CRITICAL: Remote returned ${remoteCards} cards, which is >90% drop from local ${bestLocalCards} cards. Ignoring remote data!`);
      selectedInv = bestLocalInv;
      finalSource = `local_fallback_from_remote_drop (${localSource})`;
    } else {
      selectedInv = remoteData;
      finalSource = 'remote';
    }
  } else {
    selectedInv = bestLocalInv;
    finalSource = localSource;
  }
  
  if (selectedInv && bestLocalInv && bestLocalInv !== selectedInv) {
    const localCodes = Array.isArray(bestLocalInv.redeemedCodes) ? bestLocalInv.redeemedCodes : [];
    const selectedCodes = Array.isArray(selectedInv.redeemedCodes) ? selectedInv.redeemedCodes : [];
    selectedInv.redeemedCodes = Array.from(new Set([...localCodes, ...selectedCodes]));

    const localBlessing = bestLocalInv?.supporterBlessing;
    const selectedBlessing = selectedInv?.supporterBlessing;
    if (localBlessing && typeof localBlessing === 'object' && localBlessing.active) {
      if (!selectedBlessing || !selectedBlessing.active || (localBlessing.daysRemaining || 0) > (selectedBlessing.daysRemaining || 0)) {
        selectedInv.supporterBlessing = { ...localBlessing };
      }
    }
  }

  return { selectedInv, finalSource };
}

function resetSessionState() {
  console.log('[SESSION] Reseteando estado de sesion en memoria a valores limpios');
  ownedCards.clear();
  ownedPacks.clear();
  ownedPowers.clear();
  cardTraits.clear();
  cardUpgrades.clear();
  wallet = { coins: 0, kvr: 0, traits: 0, 'infinite-coins': 0, 'infinite-cardpoints': 0 };
  userStats = { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0, battlesWon: 0, battlesPlayed: 0 };
  weeklyStats = { cards: 0, packs: 0, coins: 0, weekStart: null };
  userMissions = {};
  userKizunas = {};
  completedDeliverables = [];
  deliverableCompletions = {};
  deliverableDailyCompletions = {};
  packPurchases = {};
  redeemedCodes.clear();
  supporterBlessing = null;
  userSettings = {
    theme: { active: 'default', customTheme: null },
    currentBackground: 'default',
    unlockedBackgrounds: ['default']
  };
  profile = {
    username: '',
    password: '',
    profileImage: '',
    currentTitle: 'Novato',
    unlockedTitles: ['novato'],
    currentBackground: 'default',
    unlockedBackgrounds: ['default'],
    showcaseCards: [null, null, null]
  };
  lastSyncHash = null;
}

function applyInventoryData(data) {
  if (!data) return;
  
  ownedCards.clear();
  ownedPacks.clear();
  ownedPowers.clear();
  cardTraits.clear();
  cardUpgrades.clear();
  
  if (data.cards && typeof data.cards === 'object') {
    for (const [id, count] of Object.entries(data.cards)) {
      const c = Number(count) || 0;
      if (c > 0) ownedCards.set(id, c);
    }
  }
  
  if (data.packs && typeof data.packs === 'object') {
    for (const [id, count] of Object.entries(data.packs)) {
      const c = Number(count) || 0;
      if (c > 0) ownedPacks.set(id, c);
    }
  }
  
  if (data.powers && typeof data.powers === 'object') {
    for (const [id, pData] of Object.entries(data.powers)) {
      if (typeof pData === 'object') {
        ownedPowers.set(id, pData);
      }
    }
  }
  
  if (data.cardTraits && typeof data.cardTraits === 'object') {
    for (const [instanceId, traitData] of Object.entries(data.cardTraits)) {
      if (typeof traitData === 'object' && traitData && traitData.cardId && traitData.traitId) {
        cardTraits.set(instanceId, { cardId: String(traitData.cardId), traitId: String(traitData.traitId) });
      } else if (typeof traitData === 'string') {
        let cardId = instanceId;
        if (instanceId.includes('_')) {
          const parts = instanceId.split('_');
          if (parts.length >= 3 && !isNaN(parts[parts.length - 1]) && !isNaN(parts[parts.length - 2])) {
            cardId = parts.slice(0, -2).join('_');
          }
        }
        cardTraits.set(instanceId, { cardId: cardId, traitId: traitData });
      }
    }
  }

  // Deduplicar y limpiar excesos de traits según las cartas que realmente posee el usuario
  const traitsPerCard = new Map();
  for (const [instId, traitObj] of Array.from(cardTraits.entries())) {
    const cardId = traitObj.cardId;
    const maxAllowed = ownedCards.get(cardId) || 0;
    if (maxAllowed <= 0) {
      cardTraits.delete(instId);
      continue;
    }
    const currentList = traitsPerCard.get(cardId) || [];
    if (currentList.length >= maxAllowed) {
      cardTraits.delete(instId);
      console.log(`[TRAITS SANITIZE] Removed excess trait instance ${instId} for card ${cardId} (owned: ${maxAllowed})`);
    } else {
      currentList.push(instId);
      traitsPerCard.set(cardId, currentList);
    }
  }
  
  if (data.cardUpgrades && typeof data.cardUpgrades === 'object') {
    for (const [instanceId, upgradeData] of Object.entries(data.cardUpgrades)) {
      if (typeof upgradeData === 'object' && upgradeData.cardId) {
        cardUpgrades.set(instanceId, upgradeData);
      }
    }
  }
  
  // Billetera limpia del usuario (sin fusionar con valores residuales en memoria)
  wallet = normalizeWallet(data.wallet || {});
  
  userStats = { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0, battlesWon: 0, battlesPlayed: 0, ...(data.stats || {}) };
  if (typeof userStats.battlesWon !== 'number') userStats.battlesWon = 0;
  if (typeof userStats.battlesPlayed !== 'number') userStats.battlesPlayed = 0;
  
  weeklyStats = { cards: 0, packs: 0, coins: 0, weekStart: null, ...(data.weeklyStats || {}) };
  
  userMissions = (data.missions && typeof data.missions === 'object') ? { ...data.missions } : {};
  userKizunas = (data.kizunas && typeof data.kizunas === 'object') ? { ...data.kizunas } : {};
  
  completedDeliverables = Array.isArray(data.completedDeliverables) ? [...data.completedDeliverables] : [];
  if (data.deliverableCompletions && typeof data.deliverableCompletions === 'object') {
    deliverableCompletions = { ...data.deliverableCompletions };
  } else {
    deliverableCompletions = {};
    completedDeliverables.forEach(id => {
      if (!deliverableCompletions[id]) deliverableCompletions[id] = 1;
    });
  }

  deliverableDailyCompletions = (data.deliverableDailyCompletions && typeof data.deliverableDailyCompletions === 'object')
    ? { ...data.deliverableDailyCompletions }
    : {};

  packPurchases = (data.packPurchases && typeof data.packPurchases === 'object') ? { ...data.packPurchases } : {};
  
  userSettings = (data.settings && typeof data.settings === 'object') ? { ...data.settings } : {};
  if (userSettings.displayMode) {
    try {
      applyDisplayModeDirect(userSettings.displayMode, userSettings.windowSubMode);
    } catch (e) {
      console.warn('[DISPLAY] Error restaurando modo de pantalla:', e);
    }
  }
  
  // Perfil del usuario limpio (evita arrastrar cosméticos o avatar de otra cuenta)
  profile.profileImage = data.profileImage || '';
  profile.currentTitle = data.currentTitle || 'novato';
  profile.unlockedTitles = Array.isArray(data.unlockedTitles) ? Array.from(new Set([...data.unlockedTitles, 'novato'])).filter(Boolean) : ['novato'];
  
  const incomingBg = data.currentBackground || data.settings?.currentBackground || 'default';
  profile.currentBackground = incomingBg;
  const incomingUnlockedBg = (Array.isArray(data.unlockedBackgrounds) && data.unlockedBackgrounds.length > 0)
    ? data.unlockedBackgrounds
    : (Array.isArray(data.settings?.unlockedBackgrounds) ? data.settings.unlockedBackgrounds : ['default']);
  profile.unlockedBackgrounds = Array.from(new Set([...incomingUnlockedBg, 'default'])).filter(Boolean);
  
  if (data.showcaseCards && Array.isArray(data.showcaseCards)) {
    profile.showcaseCards = [...data.showcaseCards];
  } else {
    profile.showcaseCards = [null, null, null];
  }

  // Restaurar códigos canjeados
  redeemedCodes.clear();
  if (data.redeemedCodes && Array.isArray(data.redeemedCodes)) {
    data.redeemedCodes.forEach(code => redeemedCodes.add(String(code).toUpperCase()));
  }
  // Cargar siempre desde archivo dedicado permanente y desde inventario local
  const currentUser = (profile.username || '').trim();
  if (currentUser) {
    loadUserRedeemedCodes(currentUser);
    try {
      const { inventoryFile } = getDataPaths();
      if (fs.existsSync(inventoryFile)) {
        const inv = readJSON(inventoryFile, null);
        const userInv = inv?.users?.[currentUser];
        if (userInv && Array.isArray(userInv.redeemedCodes)) {
          userInv.redeemedCodes.forEach(code => redeemedCodes.add(String(code).toUpperCase()));
        }
      }
    } catch {}
    saveUserRedeemedCodes(currentUser);
  }

  // Restaurar Bendición del Supporter limpia para este usuario
  supporterBlessing = (data.supporterBlessing && typeof data.supporterBlessing === 'object' && data.supporterBlessing.active)
    ? { ...data.supporterBlessing }
    : null;
  if (!supporterBlessing && currentUser) {
    ensureSupporterBlessingLoaded(currentUser);
  }
  if (supporterBlessing && currentUser) {
    saveUserSupporterBlessing(currentUser, supporterBlessing);
  }
}

function saveInventory() {
  if (inTransaction) {
    console.log('[SAVE] Inside transaction, deferring save');
    return;
  }
  
  const currentUser = (profile.username || '').trim();
  if (!currentUser) {
    console.log('[SAVE] No user logged in, skipping save');
    return;
  }
  
  const { inventoryFile, inventoryBackupFile } = getDataPaths();
  try {
    let inv = null;
    try {
      if (fs.existsSync(inventoryFile)) {
        inv = JSON.parse(fs.readFileSync(inventoryFile, 'utf-8'));
      }
    } catch (e) {
      console.error('[SAVE] Error reading inventory.json:', e);
    }
    
    if (!inv || typeof inv !== 'object' || !inv.users) {
      console.warn('[SAVE] inventory.json is corrupt or missing. Trying fallback to backup.');
      try {
        if (fs.existsSync(inventoryBackupFile)) {
          inv = JSON.parse(fs.readFileSync(inventoryBackupFile, 'utf-8'));
        }
      } catch (e) {
        console.error('[SAVE] Error reading backup file during fallback:', e);
      }
    }
    
    if (!inv || typeof inv !== 'object' || !inv.users) {
      inv = { users: {}, lastUser: '' };
    }
    
    const cardsObj = {};
    for (const [id, count] of ownedCards) {
      if (count > 0) cardsObj[id] = count;
    }
    const packsObj = {};
    for (const [id, count] of ownedPacks) {
      if (count > 0) packsObj[id] = count;
    }
    const powersObj = {};
    for (const [id, data] of ownedPowers) {
      powersObj[id] = data;
    }
    const cardTraitsObj = {};
    for (const [instanceId, data] of cardTraits) {
      cardTraitsObj[instanceId] = data;
    }
    const cardUpgradesObj = {};
    for (const [instanceId, data] of cardUpgrades) {
      cardUpgradesObj[instanceId] = data;
    }
    
    const prevUserInv = inv.users[currentUser];
    try {
      validateInventorySave(currentUser, cardsObj, packsObj, prevUserInv);
    } catch (validationError) {
      console.error('[SAVE] [CRITICAL] Inventory validation failed:', validationError.message);
      logCriticalEvent('error', `Save blocked! Validation error: ${validationError.message}`);
      return;
    }
    
    inv.users[currentUser] = {
      cards: cardsObj,
      packs: packsObj,
      powers: powersObj,
      cardTraits: cardTraitsObj,
      cardUpgrades: cardUpgradesObj,
      wallet: wallet,
      stats: userStats,
      weeklyStats: weeklyStats,
      missions: userMissions,
      kizunas: userKizunas,
      settings: {
        ...(userSettings || {}),
        currentBackground: profile.currentBackground || 'default',
        unlockedBackgrounds: Array.isArray(profile.unlockedBackgrounds) ? profile.unlockedBackgrounds : ['default']
      },
      profileImage: profile.profileImage,
      currentTitle: profile.currentTitle,
      unlockedTitles: Array.isArray(profile.unlockedTitles) ? profile.unlockedTitles : ['novato'],
      currentBackground: profile.currentBackground || 'default',
      unlockedBackgrounds: Array.isArray(profile.unlockedBackgrounds) ? profile.unlockedBackgrounds : ['default'],
      showcaseCards: profile.showcaseCards || [null, null, null],
      completedDeliverables: completedDeliverables,
      deliverableCompletions: deliverableCompletions,
      deliverableDailyCompletions: deliverableDailyCompletions,
      packPurchases: packPurchases,
      redeemedCodes: Array.from(redeemedCodes),
      supporterBlessing: supporterBlessing
    };
    inv.lastUser = currentUser;
    
    writeJSONAtomic(inventoryFile, inv);
    writeJSONAtomic(inventoryBackupFile, inv);
    
    console.log('[SAVE] Local inventory saved for', currentUser, '- Cards:', Object.keys(cardsObj).length, 'Packs:', Object.keys(packsObj).length);
    logCriticalEvent('save', `Saved inventory for ${currentUser}. Cards: ${Object.keys(cardsObj).length}, Packs: ${Object.keys(packsObj).length}`);
    
    localUpdatedAt = Date.now();
  } catch (err) {
    console.error('[SAVE] Error saving local inventory:', err);
    logCriticalEvent('error', `Error saving inventory: ${err.message}`);
  }
  
  try { 
    syncInventoryRemote().catch(() => {});
    ensureInventorySyncTimer();
  } catch {}
}

function loadProfile() {
  // Solo cargar credenciales (username y password) para auto-login
  // Todo lo demás viene del servidor remoto
  const { profileFile, inventoryFile } = getDataPaths();
  const p = readJSON(profileFile, { username: '', password: '', resetAt: 0, isReset: false });
  if (p && typeof p.username === 'string') profile.username = p.username.trim();
  if (p && typeof p.password === 'string') profile.password = p.password;
  if (p && p.resetAt) profile.resetAt = Number(p.resetAt) || 0;
  if (p && p.isReset !== undefined) profile.isReset = Boolean(p.isReset);
  
  // Fallback: Si no hay usuario en profile.json, intentar recuperar el último usuario del inventario
  if (!profile.username) {
    try {
      const inv = readJSON(inventoryFile, { users: {}, lastUser: '' });
      if (inv.lastUser && typeof inv.lastUser === 'string') {
        console.log('[PROFILE] Recuperando último usuario desde inventario:', inv.lastUser);
        profile.username = inv.lastUser;
        if (inv.users && inv.users[inv.lastUser] && inv.users[inv.lastUser].resetAt) {
          profile.resetAt = Number(inv.users[inv.lastUser].resetAt) || 0;
        }
        // No tenemos password, así que el auto-login de nube fallará, pero cargaremos los datos locales
      }
    } catch (e) {
      console.error('[PROFILE] Error recuperando fallback user:', e);
    }
  }

  console.log('[THIN CLIENT] Loaded credentials for:', profile.username || '(none)', 'resetAt:', profile.resetAt || 0);
}

function saveProfile() {
  // Solo guardar credenciales (username y password) para auto-login
  // Todo lo demás se guarda en servidor remoto
  const { profileFile } = getDataPaths();
  writeJSON(profileFile, { 
    username: profile.username || '', 
    password: profile.password || '',
    resetAt: Number(profile.resetAt) || 0,
    isReset: Boolean(profile.isReset)
  });
  console.log('[THIN CLIENT] Saved credentials for:', profile.username || '(none)', 'resetAt:', profile.resetAt || 0);
}

// Cargar poderes desde remoto, game-data o seeds
async function loadPowers() {
  try {
    let powersData = null;
    
    // Intentar cargar desde remoto
    if (remoteConfig.enabled && remoteConfig.baseUrl) {
      try {
        const url = `${remoteConfig.baseUrl}/powers.json`;
        const data = await httpGetJson(url);
        if (data && Array.isArray(data.powers)) {
          powersData = data;
          console.log('[POWERS] Poderes cargados desde remoto');
        }
      } catch (e) {
        console.log('[POWERS] No se pudo cargar desde remoto:', e.message);
      }
    }
    
    // Intentar cargar desde game-data junto al ejecutable
    if (!powersData) {
      const exeDir = path.dirname(process.execPath);
      const localPowers = path.join(exeDir, 'game-data', 'powers.json');
      if (fs.existsSync(localPowers)) {
        powersData = JSON.parse(fs.readFileSync(localPowers, 'utf-8'));
        console.log('[POWERS] Poderes cargados desde game-data local');
      }
    }
    
    // Fallback a seeds
    if (!powersData) {
      const seedPowers = path.join(__dirname, '..', 'game-data', 'powers.json');
      if (fs.existsSync(seedPowers)) {
        powersData = JSON.parse(fs.readFileSync(seedPowers, 'utf-8'));
        console.log('[POWERS] Poderes cargados desde seeds');
      }
    }
    
    if (!powersData || !Array.isArray(powersData.powers)) {
      console.warn('[POWERS] No se encontró powers.json');
      return;
    }
    
    // Poblar powerStore
    powerStore.clear();
    powersData.powers.forEach(p => {
      powerStore.set(p.id, p);
    });
    
    console.log(`✅ Cargados ${powerStore.size} poderes`);
    
    // MIGRACIÓN: Limpiar poderes antiguos con estructura incorrecta
    const validPowerIds = new Set(powersData.powers.map(p => p.id));
    const powersToDelete = [];
    
    for (const [powerId, powerData] of ownedPowers.entries()) {
      // Eliminar poderes que ya no existen en el catálogo
      if (!validPowerIds.has(powerId)) {
        powersToDelete.push(powerId);
        console.log('[POWERS] Eliminando poder obsoleto:', powerId);
      }
      // Eliminar poderes con estructura antigua (count en lugar de uses/permanent)
      else if (powerData.count !== undefined && powerData.permanent === undefined && powerData.uses === undefined) {
        powersToDelete.push(powerId);
        console.log('[POWERS] Eliminando poder con estructura antigua:', powerId, powerData);
      }
    }
    
    powersToDelete.forEach(id => ownedPowers.delete(id));
    
    // Asegurar que el usuario siempre tenga los poderes default
    powersData.powers.filter(p => p.default).forEach(p => {
      if (!ownedPowers.has(p.id)) {
        // Solo añadir si no lo tiene ya
        if (p.consumable) {
          ownedPowers.set(p.id, { uses: 1 });
        } else {
          ownedPowers.set(p.id, { permanent: true });
        }
        console.log('[POWERS] Poder default inicializado:', p.id);
      }
    });
    
  } catch (error) {
    console.error('[POWERS] Error cargando poderes:', error);
  }
}

async function loadData() {
  const { inventoryFile } = getDataPaths();
  // Cargar perfil (username) primero
  loadProfile();

  // Buscar overrides junto al ejecutable (carpeta game-data), si no, usar seeds del paquete
  const exeDir = path.dirname(process.execPath);
  const overrideCards = path.join(exeDir, 'game-data', 'cards.json');
  const overridePacks = path.join(exeDir, 'game-data', 'packs.json');

  // Intentar configuración remota desde override o seeds: game-data/catalog.json o seeds/catalog.json
  await loadRemoteConfig();

  // Cargar calidades desde remoto (si activo), override o seeds
  qualityStore.clear();
  let qualitiesArr = null;
  try {
    if (remoteConfig.enabled && remoteConfig.baseUrl) {
      const remote = await tryFetchRemoteCatalog();
      if (remote && remote.qualities) {
        qualitiesArr = Array.isArray(remote.qualities) ? remote.qualities : (Array.isArray(remote.qualities.qualities) ? remote.qualities.qualities : (Array.isArray(remote.qualities.calidades) ? remote.qualities.calidades : null));
        if (qualitiesArr) {
          console.log(`[QUALITIES] Cargadas ${qualitiesArr.length} calidades desde remoto`);
        }
      }
    }
  } catch (e) {
    console.error('[QUALITIES] Error cargando calidades remotas:', e);
  }

  // Fallback override o seeds para calidades
  if (!Array.isArray(qualitiesArr)) {
    const overrideQualities = path.join(exeDir, 'game-data', 'calidades.json');
    if (fs.existsSync(overrideQualities)) {
      qualitiesArr = readJSON(overrideQualities, null);
      if (Array.isArray(qualitiesArr)) console.log('[QUALITIES] Usando game-data/calidades.json como fallback');
    }
  }
  if (!Array.isArray(qualitiesArr)) {
    const seedQualities = path.join(__dirname, '..', 'seeds', 'calidades.json');
    if (fs.existsSync(seedQualities)) {
      qualitiesArr = readJSON(seedQualities, null);
      if (Array.isArray(qualitiesArr)) console.log('[QUALITIES] Usando seeds/calidades.json como fallback');
    }
  }
  if (!Array.isArray(qualitiesArr)) {
    const { cacheQualities } = getDataPaths();
    if (fs.existsSync(cacheQualities)) {
      qualitiesArr = readJSON(cacheQualities, null);
      if (Array.isArray(qualitiesArr)) console.log('[QUALITIES] Usando cache calidades.json como fallback');
    }
  }

  if (Array.isArray(qualitiesArr)) {
    qualitiesArr.forEach((q, idx) => {
      if (q && (q.id || q.name || q.nombre)) {
        const name = q.name || q.nombre || q.id;
        const id = q.id || name.toLowerCase().replace(/\s+/g, '_');
        const maskImageRaw = q.maskImage || q.image || './assets/qualities/icono.png';
        const iconImageRaw = q.iconImage || q.icon || q.miniImage || q.miniIcon || maskImageRaw;
        const qualityObj = {
          id: id,
          name: name,
          special: Boolean(q.special ?? q.especial ?? false),
          packable: (q.packable !== false && q.packable !== 'false'),
          showSeparate: Boolean(q.showSeparate ?? q.separate ?? q.mostrarSeparado ?? q.seccionPropia ?? false),
          maskImage: normalizeAssetUrl(maskImageRaw),
          iconImage: normalizeAssetUrl(iconImageRaw),
          sparkColor: q.sparkColor || q.color || '#f8fafc',
          tradeable: q.tradeable !== undefined ? Boolean(q.tradeable) : (q.tradable !== undefined ? Boolean(q.tradable) : true),
          valor: typeof q.valor === 'number' ? q.valor : (typeof q.value === 'number' ? q.value : 10),
          order: typeof q.order === 'number' ? q.order : (idx + 1)
        };
        qualityStore.set(name, qualityObj);
        qualityStore.set(id, qualityObj);
      }
    });
    console.log(`[QUALITIES] ✅ ${qualityStore.size} claves de calidades inicializadas en memoria`);
  }

  // Cargar cartas desde remoto (si activo), override o seeds, SIEMPRE en cada arranque (solo lectura)
  let cardsArr = null;
  try {
    if (remoteConfig.enabled && remoteConfig.baseUrl) {
      console.log(`[CATALOG] Intentando cargar desde: ${remoteConfig.baseUrl}`);
      // Añadir timeout de 5 segundos para evitar bloqueos largos
      const remote = await Promise.race([
        tryFetchRemoteCatalog(),
        new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 5000))
      ]).catch(err => {
        console.log(`[CATALOG] Timeout o error cargando remoto: ${err.message}`);
        return null;
      });
      if (remote && Array.isArray(remote.cards)) {
        cardsArr = remote.cards;
        catalogInfo.cardsSource = 'remote';
        catalogInfo.version = remote.version || catalogInfo.version;
        catalogInfo.remote = true;
        console.log(`[CATALOG] Catálogo remoto cargado: ${cardsArr.length} cartas`);
      } else {
        console.log('[CATALOG] No se pudo cargar el catálogo remoto');
      }
    }
  } catch (e) {
    console.error('[CATALOG] Error cargando catálogo remoto:', e);
  }
  // Solo usar archivos locales si el remoto no funcionó
  if (!Array.isArray(cardsArr)) {
    console.log('[CATALOG] Remoto no disponible, usando fallback local');
    try {
      if (fs.existsSync(overrideCards)) {
        const raw = fs.readFileSync(overrideCards, 'utf-8');
        const arr = JSON.parse(raw);
        if (Array.isArray(arr)) {
          cardsArr = arr;
          console.log('[CATALOG] Usando game-data/cards.json como fallback');
        }
      }
    } catch {}
  }
  if (!Array.isArray(cardsArr)) {
    try {
      const seedPath = path.join(__dirname, '..', 'seeds', 'cards.json');
      if (fs.existsSync(seedPath)) {
        const raw = fs.readFileSync(seedPath, 'utf-8');
        const seeds = JSON.parse(raw);
        if (Array.isArray(seeds)) {
          cardsArr = seeds;
          console.log('[CATALOG] Usando seeds/cards.json como fallback');
        }
      }
    } catch {}
  }
  // Fallback defensivo: si todo falló, intenta leer cache de catálogo previo
  if (!Array.isArray(cardsArr)) {
    try {
      const { cacheCards } = getDataPaths();
      if (fs.existsSync(cacheCards)) {
        const cached = JSON.parse(fs.readFileSync(cacheCards, 'utf-8'));
        if (Array.isArray(cached)) cardsArr = cached;
      }
    } catch {}
  }
  if (!Array.isArray(cardsArr)) cardsArr = [];
  // poblar store
  cardStore.clear();
  // Si vienen sin id (seeds antiguos), generar id determinista por índice
  cardsArr.forEach((c, idx) => {
    if (!c) return;
    let card = c;
    if (!c.id) {
      const [stat1, stat2, stat3, stat4, stat5, stat6] = c.stats || [0,0,0,0,0,0];
      const computed = Math.round((Number(stat1)||0 + (Number(stat2)||0) + (Number(stat3)||0) + (Number(stat4)||0) + (Number(stat5)||0) + (Number(stat6)||0)) / 6);
      card = { 
        id: 'seed-' + idx, 
        name: c.name || 'Jugador', 
        imageUrl: c.imageUrl || '', 
        stat1, stat2, stat3, stat4, stat5, stat6, 
        media: typeof c.media === 'number' ? c.media : computed,
        calidad: c.calidad
      };
    }
    // Asegurar media si falta
    if (typeof card.media !== 'number') {
      const computed = Math.round((Number(card.stat1)||0 + (Number(card.stat2)||0) + (Number(card.stat3)||0) + (Number(card.stat4)||0) + (Number(card.stat5)||0) + (Number(card.stat6)||0)) / 6);
      card.media = computed;
    }
    // Calidad: aceptar id o nombre de la calidad y normalizar
    const rawQ = (c && (c.calidad ?? c.Calidad ?? c.quality ?? c.Quality ?? c.rarity ?? c.Rarity ?? c.calidadId ?? c.qualityId))
                  || card.calidad;
    const n = normalizeQuality(rawQ);
    card.calidad = n || deriveQuality(card.media);
    
    // Obtener objeto de calidad de qualityStore
    const qObj = qualityStore.get(card.calidad) || qualityStore.get(rawQ) || Array.from(qualityStore.values()).find(x => x.name === card.calidad || x.id === card.calidad || x.id === rawQ);
    card.calidadId = qObj ? qObj.id : (rawQ ? String(rawQ).toLowerCase().replace(/\s+/g, '_') : 'bronce');
    card.quality = card.calidad;
    
    // Asegurar normalización de URLs de imágenes para evitar 429 de raw.githubusercontent.com
    card.imageUrl = normalizeAssetUrl(card.imageUrl || '');
    
    // El valor de venta proviene directamente del catálogo dinámico de calidades
    card.valor = (qObj && typeof qObj.valor === 'number') ? qObj.valor : 10;
    
    cardStore.set(card.id, card);
  });
  if (catalogInfo.cardsSource !== 'remote') {
    catalogInfo.cardsSource = fs.existsSync(overrideCards) ? 'game-data' : (cardsArr.length ? 'seeds' : 'none');
  }
  catalogInfo.cardsCount = cardStore.size;

  // Cargar traits exclusivamente desde el JSON remoto oficial en GitHub
  traitStore.clear();
  const traitsMap = new Map();

  function normalizeAssetUrl(url) {
    if (!url || typeof url !== 'string') return url;
    return url.replace(/^https?:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/main\/(.*)$/i, 'https://$1.github.io/$2/$3');
  }

  try {
    const rawUrl = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/traits.json?t=${Date.now()}`;
    const remoteData = await httpGetJson(rawUrl).catch(async () => {
      const altUrl = `https://hugom1307.github.io/kvrcards-catalog/traits.json?t=${Date.now()}`;
      return await httpGetJson(altUrl).catch(() => null);
    });

    if (remoteData && (Array.isArray(remoteData) || Array.isArray(remoteData.traits))) {
      const rTraits = Array.isArray(remoteData) ? remoteData : remoteData.traits;
      rTraits.forEach(t => {
        if (t && t.id) {
          t.imageUrl = normalizeAssetUrl(t.imageUrl || t.image || '');
          traitsMap.set(t.id, t);
        }
      });
      console.log(`[TRAITS] ${traitsMap.size} rasgos cargados directamente del JSON remoto oficial`);
    }
  } catch (e) {
    console.error('[TRAITS] Error cargando traits directamente de remoto:', e);
  }

  // Guardar en traitStore
  traitsMap.forEach((t, id) => {
    traitStore.set(id, t);
  });
  console.log(`[TRAITS] traitStore listo con ${traitStore.size} rasgos desde el JSON remoto`);

  // Cargar packs desde override o seeds (solo lectura)
  packStore.clear();
  let packsArr = null;
  try {
    if (remoteConfig.enabled && remoteConfig.baseUrl) {
      const remote = await tryFetchRemoteCatalog();
      if (remote && remote.packs) {
        packsArr = remote.packs;
        catalogInfo.packsSource = 'remote';
        catalogInfo.version = remote.version || catalogInfo.version;
        catalogInfo.remote = true;
      }
    }
  } catch {}
  // Solo usar archivos locales si el remoto no funcionó
  if (!packsArr) {
    console.log('[CATALOG] Packs remotos no disponibles, usando fallback local');
    try {
      if (fs.existsSync(overridePacks)) {
        const raw = fs.readFileSync(overridePacks, 'utf-8');
        packsArr = JSON.parse(raw);
        console.log('[CATALOG] Usando game-data/packs.json como fallback');
      }
    } catch {}
  }
  if (!packsArr && cardStore.size > 0) {
    // intentar seeds/packs.json
    try {
      const seedPacksPath = path.join(__dirname, '..', 'seeds', 'packs.json');
      if (fs.existsSync(seedPacksPath)) {
        const raw = fs.readFileSync(seedPacksPath, 'utf-8');
        packsArr = JSON.parse(raw);
      }
    } catch {}
  }
  // Fallback defensivo: si no hay packs pero existe cache previa, úsala
  if (!packsArr) {
    try {
      const { cachePacks } = getDataPaths();
      if (fs.existsSync(cachePacks)) {
        packsArr = JSON.parse(fs.readFileSync(cachePacks, 'utf-8'));
      }
    } catch {}
  }
  if (packsArr) {
    const normalizedPacksCatalog = normalizePacksCatalog(packsArr);
    const packDefs = normalizedPacksCatalog.packs;
    const shopEntries = normalizedPacksCatalog.shopEntries;
    const hasShopConfig = normalizedPacksCatalog.hasShopConfig;
    const shopEntryMap = new Map(shopEntries.map((entry, index) => [entry.id, { ...entry, order: Number.isFinite(Number(entry.order)) ? Number(entry.order) : (index + 1) }]));

    const ids = Array.from(cardStore.keys());
    const n = ids.length;
    const half = Math.ceil(n / 2);
    const top = Math.max(1, Math.ceil(n / 3));
    const distByStrategy = (strategy, packDef) => {
      if (strategy === 'equal') return Object.fromEntries(ids.map(id => [id, 1]));
      if (strategy === 'halfTop') return Object.fromEntries(ids.map((id, i) => [id, i < half ? 2 : 1]));
      if (strategy === 'topThird') return Object.fromEntries(ids.map((id, i) => [id, i < top ? 5 : 1]));
      if (strategy === 'qualityMedia') {
        const qWeightsRaw = packDef.qualityWeights || packDef.qualityweights || packDef.quality_weights || packDef.qualityheights || packDef.quality_heights || null;
        const normQWeights = parseQualityWeights(qWeightsRaw);
        const cWeights = packDef.cardWeights || {};
        const weights = {};

        const allowedProcedencias = getPackAllowedProcedencias(packDef);
        const allowedOwners = getPackAllowedOwners(packDef);
        const allowedQualities = getPackAllowedQualities(packDef);
        const excludedIds = getPackExcludedIds(packDef);
        const { minMedia, maxMedia } = getPackMediaLimits(packDef);

        for (const id of ids) {
          if (excludedIds && excludedIds.has(String(id))) {
            weights[id] = 0;
            continue;
          }

          const c = cardStore.get(id);
          if (!c) continue;

          // Evo NUNCA entra en sobres
          const qNorm = normalizeQuality(c.calidad) || deriveQuality(c.media);
          if (qNorm === 'Evo' || c.calidad === 'Evo' || c.calidadId === 'evo' || String(c.calidad).toLowerCase() === 'evo') {
            weights[id] = 0;
            continue;
          }

          const qObj = qualityStore.get(c.calidad) || qualityStore.get(c.calidadId) || 
            Array.from(qualityStore.values()).find(x => x.name === c.calidad || x.id === c.calidad || x.id === c.calidadId);
          const cardQNorm = String(c.calidad || '').trim().toLowerCase().replace(/[\s\-]+/g, '_');
          const cardQId = String(qObj?.id || c.calidadId || '').trim().toLowerCase().replace(/[\s\-]+/g, '_');

          // Filtro por calidades permitidas (allowedQualities)
          if (allowedQualities) {
            const isAllowedQ = allowedQualities.has(cardQNorm) || allowedQualities.has(cardQId);
            const hasSpecialWeight = normQWeights && (normQWeights['special'] !== undefined || normQWeights['especial'] !== undefined || normQWeights['especiales'] !== undefined);
            if (!hasSpecialWeight && !isAllowedQ) {
              weights[id] = 0;
              continue;
            }
          }

          // Filtro por procedencia
          if (allowedProcedencias) {
            const proc = String(c.procedencia ?? c.Procedencia ?? c.origin ?? c.origen ?? '').trim().toLowerCase();
            if (!proc || !allowedProcedencias.has(proc)) {
              weights[id] = 0;
              continue;
            }
          }

          // Filtro por owner
          if (allowedOwners) {
            const owner = String(c.owner ?? c.Owner ?? c.propietario ?? c.Propietario ?? c.creador ?? c.creator ?? '').trim().toLowerCase();
            if (!owner || !allowedOwners.has(owner)) {
              weights[id] = 0;
              continue;
            }
          }

          // Filtro por límites de media
          const media = Number(c.media) || 0;
          if (minMedia !== null && media < minMedia) {
            weights[id] = 0;
            continue;
          }
          if (maxMedia !== null && media > maxMedia) {
            weights[id] = 0;
            continue;
          }

          // SI NO ES PACKABLE: una carta con packable: false NUNCA puede salir en un sobre salvo que:
          // 1. Esté explícitamente en qualityWeights por su calidad directa
          // 2. Esté en allowedQualities
          const isPackable = (qObj?.packable !== false && qObj?.packable !== 'false') &&
                             (c?.packable !== false && c?.packable !== 'false');
          if (!isPackable) {
            const isExplicitQuality = normQWeights && (normQWeights[cardQId] !== undefined || normQWeights[cardQNorm] !== undefined);
            const isAllowedQuality = allowedQualities && (allowedQualities.has(cardQId) || allowedQualities.has(cardQNorm));
            if (!isExplicitQuality && !isAllowedQuality) {
              weights[id] = 0;
              continue;
            }
          }

          // Peso según ID de calidad en calidades.json o 'special'
          const qWeight = resolveCardQualityWeight(c, normQWeights, () => qObj, allowedQualities);

          const cw = Number(cWeights[id]) || 1;
          weights[id] = qWeight > 0 ? qWeight * cw : 0;
        }

        const sum = Object.values(weights).reduce((s, v) => s + v, 0);
        if (sum === 0) return Object.fromEntries(ids.map(id => [id, 1]));
        return weights;
      }
      return Object.fromEntries(ids.map(id => [id, 1]));
    };
    packDefs.forEach((d, idx) => {
      if (!d) return;
      const name = d.name || 'Pack';
      const cardsPerPack = Number(d.cardsPerPack) || 3;
      const distribution = d.distribution && typeof d.distribution === 'object' ? d.distribution : distByStrategy(d.strategy, d);
      const id = d.id || ('seed-pack-' + idx);
      // imageUrl opcional para mostrar portada del sobre
      const imageUrl = normalizeAssetUrl(d.imageUrl) || undefined;
      // Precio (coins/kvr)
      let price = { coins: 0, kvr: 0 };
      try {
        if (d.price && typeof d.price === 'object') {
          const pc = Math.max(0, Number(d.price.coins) || 0);
          const pk = Math.max(0, Number(d.price.kvr) || 0);
          price = { coins: pc, kvr: pk };
        } else if (typeof d.priceCoins !== 'undefined' || typeof d.priceKvr !== 'undefined') {
          const pc = Math.max(0, Number(d.priceCoins) || 0);
          const pk = Math.max(0, Number(d.priceKvr) || 0);
          price = { coins: pc, kvr: pk };
        } else {
          const nm = String(name).toLowerCase();
          if (nm.includes('bronce')) price = { coins: 100, kvr: 0 };
          else if (nm.includes('plata')) price = { coins: 500, kvr: 0 };
          else if (nm.includes('oro')) price = { coins: 1500, kvr: 0 };
          else if (nm.includes('icono')) price = { coins: 2500, kvr: 1 };
          else price = { coins: 300, kvr: 0 };
        }
      } catch {}
      
      const legacyStock = Object.prototype.hasOwnProperty.call(d, 'stock')
        ? (Number.isFinite(Number(d.stock)) ? Math.max(0, Number(d.stock)) : null)
        : null;
      const shopEntry = shopEntryMap.get(id) || null;
      const hasShopEntry = !!shopEntry;
      const stock = hasShopConfig
        ? (hasShopEntry && Object.prototype.hasOwnProperty.call(shopEntry, 'stock') ? shopEntry.stock : null)
        : legacyStock;
      const shopVisible = hasShopConfig ? (hasShopEntry ? shopEntry.visible !== false : false) : true;
      const shopOrder = hasShopEntry ? (Number.isFinite(Number(shopEntry.order)) ? Number(shopEntry.order) : (idx + 1)) : (idx + 1);
      
      // Leer excludedQualities (calidades excluidas explícitamente)
      const excludedQualities = Array.isArray(d.excludedQualities) ? d.excludedQualities : [];
      
      // Leer qualityWeights (pesos por calidad)
      // Soporta alias por compatibilidad con variantes en JSON.
      const qualityWeightsSource =
        (d.qualityWeights && typeof d.qualityWeights === 'object')
          ? d.qualityWeights
          : ((d.qualityweights && typeof d.qualityweights === 'object')
              ? d.qualityweights
              : ((d.quality_weights && typeof d.quality_weights === 'object')
                  ? d.quality_weights
                  : ((d.qualityheights && typeof d.qualityheights === 'object')
                      ? d.qualityheights
                      : ((d.quality_heights && typeof d.quality_heights === 'object') ? d.quality_heights : null))));
      const qualityWeights = qualityWeightsSource || null;
      // Nuevo: lista opcional de ids que pueden salir siempre.
      // Alias soportados por compatibilidad: allowedCardIds, cardIds, onlyCardIds, allowedIds
      const allowedCardIdsSource = Array.isArray(d.allowedCardIds)
        ? d.allowedCardIds
        : (Array.isArray(d.cardIds)
            ? d.cardIds
            : (Array.isArray(d.onlyCardIds)
                ? d.onlyCardIds
                : (Array.isArray(d.allowedIds)
                    ? d.allowedIds
                    : (Array.isArray(d.allowed_ids) ? d.allowed_ids : []))));
      const allowedCardIds = allowedCardIdsSource.map(id => String(id)).filter(Boolean);
      
      const openingGradient = Array.isArray(d.openingGradient)
        ? d.openingGradient
        : (d.openingGradient && typeof d.openingGradient === 'object'
            ? {
                start: d.openingGradient.start ?? d.openingGradient.from,
                mid: d.openingGradient.mid ?? d.openingGradient.middle,
                end: d.openingGradient.end ?? d.openingGradient.to,
              }
            : (typeof d.openingGradient === 'string' ? d.openingGradient : undefined));

      const { minMedia, maxMedia } = getPackMediaLimits(d);

      const allowedProcedenciasRaw = d.allowedProcedencias ?? d.allowed_procedencias ?? d.procedencias ?? null;
      const allowedProcedencias = Array.isArray(allowedProcedenciasRaw) ? allowedProcedenciasRaw : (allowedProcedenciasRaw ? [allowedProcedenciasRaw] : null);

      const allowedOwnersRaw = d.allowedOwners ?? d.allowed_owners ?? d.owners ?? d.allowedPropietarios ?? null;
      const allowedOwners = Array.isArray(allowedOwnersRaw) ? allowedOwnersRaw : (allowedOwnersRaw ? [allowedOwnersRaw] : null);

      const allowedQualitiesRaw = d.allowedQualities ?? d.allowed_qualities ?? d.allowQualities ?? d.allow_qualities ?? d.calidadesPermitidas ?? d.allowedCalidades ?? d.allowUnpackableQualities ?? d.allowedNonPackableQualities ?? null;
      const allowedQualities = Array.isArray(allowedQualitiesRaw) ? allowedQualitiesRaw : (allowedQualitiesRaw ? [allowedQualitiesRaw] : null);

      const excludedIdsRaw = d.excludedIds ?? d.excluded_ids ?? d.excludedCardIds ?? d.excluded_card_ids ?? null;
      const excludedIds = Array.isArray(excludedIdsRaw) ? excludedIdsRaw.map(x => String(x).trim()) : (excludedIdsRaw ? [String(excludedIdsRaw).trim()] : []);

      const p = { 
        id, name, cardsPerPack, distribution, imageUrl, price, stock, 
        excludedQualities, qualityWeights, allowedCardIds, openingGradient, 
        shopVisible, shopOrder, shopConfigured: hasShopConfig, minMedia, maxMedia,
        allowedProcedencias, allowedOwners, allowedQualities, excludedIds
      };
      packStore.set(p.id, p);
      
      // Inicializar stock si no existe aún en packStock y el pack define stock
      if (stock !== null && stock !== undefined && !packStock.has(id)) {
        packStock.set(id, stock);
      }
    });
    if (catalogInfo.packsSource !== 'remote') {
      catalogInfo.packsSource = fs.existsSync(overridePacks) ? 'game-data' : 'seeds';
    }
  }

  if (profile.username) {
    const { inventoryBackupFile } = getDataPaths();
    let remoteData = null;
    try {
      remoteData = await fetchInventoryRemote(profile.username);
    } catch (err) {
      console.error('[loadData] Error fetching remote inventory:', err);
    }
    
    let localData = null;
    try {
      localData = readJSON(inventoryFile, null);
    } catch (err) {
      console.error('[loadData] Error reading local inventory file:', err);
    }
    
    let backupData = null;
    try {
      backupData = readJSON(inventoryBackupFile, null);
    } catch (err) {
      console.error('[loadData] Error reading backup inventory file:', err);
    }
    
    const { selectedInv, finalSource } = selectValidInventory(profile.username, remoteData, localData, backupData);
    console.log(`[loadData] SELECTED INVENTORY SOURCE: ${finalSource}`);
    
    if (selectedInv) {
      applyInventoryData(selectedInv);
      
      // MIGRACIÓN: Convertir formato viejo a nuevo
      console.log('[MIGRATION] Checking for old-format traits...');
      const traitsToMigrate = [];
      if (selectedInv.cardTraits && typeof selectedInv.cardTraits === 'object') {
        for (const [key, value] of Object.entries(selectedInv.cardTraits)) {
          if (typeof value === 'string') {
            console.log(`[MIGRATION] Found old format trait: ${key} -> ${value}`);
            traitsToMigrate.push({ oldKey: key, traitId: value });
          }
        }
      }
      
      for (const { oldKey, traitId } of traitsToMigrate) {
        let cardId = oldKey;
        if (oldKey.includes('_')) {
          const parts = oldKey.split('_');
          if (parts.length >= 3) {
            const lastPart = parts[parts.length - 1];
            const secondLastPart = parts[parts.length - 2];
            if (!isNaN(lastPart) && !isNaN(secondLastPart)) {
              cardId = parts.slice(0, -2).join('_');
            }
          }
        }
        
        if (ownedCards.has(cardId)) {
          const newInstanceId = `trait_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
          cardTraits.set(newInstanceId, { cardId: cardId, traitId: traitId });
          console.log(`[MIGRATION] Migrated trait: ${oldKey} -> ${newInstanceId} (cardId: ${cardId}, trait: ${traitId})`);
        }
      }
      
      if (traitsToMigrate.length > 0) {
        console.log(`[MIGRATION] Migrated ${traitsToMigrate.length} old-format traits`);
        saveInventory();
      }
      
      if (weeklyStats.weekStart) {
        const now = new Date();
        const dayOfWeek = now.getDay();
        const currentMonday = new Date(now);
        const diff = (dayOfWeek === 0 ? -6 : 1) - dayOfWeek;
        currentMonday.setDate(now.getDate() + diff);
        currentMonday.setHours(0, 0, 0, 0);
        const mondayTimestamp = currentMonday.getTime();
        
        if (weeklyStats.weekStart < mondayTimestamp) {
          console.log('[loadData] WeeklyStats expired, resetting...');
          weeklyStats = { cards: 0, packs: 0, coins: 0, weekStart: mondayTimestamp };
          saveInventory();
        }
      } else {
        const now = new Date();
        const dayOfWeek = now.getDay();
        const currentMonday = new Date(now);
        const diff = (dayOfWeek === 0 ? -6 : 1) - dayOfWeek;
        currentMonday.setDate(now.getDate() + diff);
        currentMonday.setHours(0, 0, 0, 0);
        weeklyStats.weekStart = currentMonday.getTime();
      }
    } else {
      console.log(`[loadData] New user profile "${profile.username}", initializing default wallet balance...`);
      wallet = { ...DEFAULT_WALLET };
      wallet.coins = 1000;
      wallet.kvr = 0;
      profile.showcaseCards = [null, null, null];
    }
  }

  // Si aún no hay packs y hay cartas, como último recurso genera uno por defecto equal
  if (packStore.size === 0 && cardStore.size > 0) {
    const ids = Array.from(cardStore.keys());
    const distribution = Object.fromEntries(ids.map(id => [id, 1]));
    const p = { id: 'seed-pack-0', name: 'Sobre Base', cardsPerPack: 3, distribution };
    packStore.set(p.id, p);
    catalogInfo.packsSource = 'generated';
  }
  catalogInfo.packsCount = packStore.size;

  // Cargar poderes desde remoto, game-data o seeds
  await loadPowers();

  // Si la cartera está vacía, regalar saldo inicial
  if ((wallet.coins||0) === 0 && (wallet.kvr||0) === 0) {
    wallet.coins = 1000; // saldo base
    wallet.kvr = 0;
    try { saveInventory(); } catch {}
  }

  // Programar auto-sync de inventario si procede y lanzar un intento inmediato
  try {
    ensureInventorySyncTimer();
    syncInventoryRemote().catch(() => {});
  } catch {}
}

// Resumen de catálogo para diagnóstico/mostrar en UI
ipcMain.handle('catalog:summary', () => ({ ok: true, ...catalogInfo }));

// Permite refrescar el catálogo remoto y recargar datos
ipcMain.handle('catalog:refresh', async () => {
  await refreshCatalog();
  return { ok: true, ...catalogInfo };
});

ipcMain.handle('catalog:clearCache', async () => {
  await clearCatalogCache();
  return { ok: true };
});

// Handler para obtener títulos
ipcMain.handle('titles:get', async () => {
  try {
    let titles = await tryFetchRemoteTitles();
    
    // Si no hay títulos remotos, intentar game-data local
    if (!titles) {
      const exeDir = path.dirname(process.execPath);
      const localTitles = path.join(exeDir, 'game-data', 'titles.json');
      if (fs.existsSync(localTitles)) {
        titles = JSON.parse(fs.readFileSync(localTitles, 'utf-8'));
      }
    }
    
    // Fallback a seeds
    if (!titles) {
      const seedTitles = path.join(__dirname, '..', 'seeds', 'titles.json');
      if (fs.existsSync(seedTitles)) {
        titles = JSON.parse(fs.readFileSync(seedTitles, 'utf-8'));
      }
    }
    
    if (!Array.isArray(titles)) {
      return { ok: false, error: 'No se pudieron cargar los títulos' };
    }
    
    return { ok: true, titles };
  } catch (e) {
    console.error('[TITLES] Error en handler:', e);
    return { ok: false, error: e.message };
  }
});

async function refreshCatalog() {
  // resetea y vuelve a cargar
  catalogInfo = { cardsSource: 'none', packsSource: 'none', cardsCount: 0, packsCount: 0, version: '0', remote: false };
  await loadData();
  try { await ensureLocalInventoryServer(); } catch {}
  try { startInventoryKeepAliveMonitor(); } catch {}
}

async function loadRemoteConfig() {
  try {
    const exeDir = path.dirname(process.execPath);
    
    // Lista de posibles ubicaciones para remote-config.json
    const possiblePaths = [
      path.join(exeDir, 'remote-config.json'),
      path.join(__dirname, '..', 'remote-config.json'), // modo desarrollo
      path.join(__dirname, '..', '..', 'dist', 'KVRCards-win32-x64', 'remote-config.json'),
    ];
    
    let cfg = null;
    let foundPath = null;
    
    // Intentar cargar remote-config.json desde cualquier ubicación
    for (const configPath of possiblePaths) {
      console.log('[loadRemoteConfig] Intentando:', configPath);
      if (fs.existsSync(configPath)) {
        const raw = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
        console.log('[loadRemoteConfig] ✓ remote-config.json encontrado:', JSON.stringify(raw));
        foundPath = configPath;
        // Convertir formato nuevo a formato interno
        cfg = {
          enabled: raw.catalog?.enabled || false,
          baseUrl: raw.catalog?.baseUrl || '',
          inventory: raw.inventory || { enabled: false, baseUrl: '' }
        };
        break;
      }
    }
    
    if (!cfg) {
      // Fallback al formato antiguo catalog.json
      const overrideCfg = path.join(exeDir, 'game-data', 'catalog.json');
      console.log('[loadRemoteConfig] remote-config.json no existe, buscando catalog.json en:', overrideCfg);
      if (fs.existsSync(overrideCfg)) {
        cfg = JSON.parse(fs.readFileSync(overrideCfg, 'utf-8'));
        console.log('[loadRemoteConfig] Config cargada desde override:', JSON.stringify(cfg));
      } else {
        // En modo desarrollo, buscar en dist/KVRCards-win32-x64/game-data/catalog.json
        const distCfg = path.join(__dirname, '..', '..', 'dist', 'KVRCards-win32-x64', 'game-data', 'catalog.json');
        console.log('[loadRemoteConfig] Override no existe, intentando dist:', distCfg);
        if (fs.existsSync(distCfg)) {
          cfg = JSON.parse(fs.readFileSync(distCfg, 'utf-8'));
          console.log('[loadRemoteConfig] Config cargada desde dist:', JSON.stringify(cfg));
        } else {
          const seedCfg = path.join(__dirname, '..', 'seeds', 'catalog.json');
          console.log('[loadRemoteConfig] Dist no existe, intentando seeds:', seedCfg);
          if (fs.existsSync(seedCfg)) {
            cfg = JSON.parse(fs.readFileSync(seedCfg, 'utf-8'));
            console.log('[loadRemoteConfig] Config cargada desde seeds:', JSON.stringify(cfg));
          }
        }
      }
    }
    // helper para normalizar baseUrl (corrige github.com → *.github.io)
    const normalizeBase = (u) => {
      try {
        const s = String(u || '').trim();
        if (!s) return '';
        const url = new URL(s);
        const host = (url.hostname || '').toLowerCase();
        if (host === 'github.com') {
          const parts = url.pathname.replace(/^\/+/, '').split('/');
          const owner = parts[0];
          const repo = (parts[1] || '').replace(/\.git$/i, '');
          if (owner && repo) {
            return ensureSlash(`https://${owner}.github.io/${repo}/`);
          }
        }
        return ensureSlash(s);
      } catch { return ''; }
    };

    if (cfg && typeof cfg === 'object') {
      remoteConfig.baseUrl = normalizeBase(cfg.baseUrl);
      remoteConfig.enabled = Boolean(cfg.enabled && remoteConfig.baseUrl);
      const inv = cfg.inventory || {};
      remoteConfig.inventory = {
        enabled: Boolean(inv.enabled && inv.baseUrl),
        baseUrl: String(inv.baseUrl || '').trim(),
      };
      // Cargar configuración de mantenimiento
      const maint = cfg.maintenance || {};
      remoteConfig.maintenance = {
        enabled: Boolean(maint.enabled),
        title: String(maint.title || '🔧 Mantenimiento en Curso'),
        message: String(maint.message || 'Estamos actualizando el juego. Volveremos pronto.'),
        estimatedTime: String(maint.estimatedTime || '')
      };
      // Cargar configuración de versión
      const ver = cfg.version || {};
      remoteConfig.version = {
        current: String(ver.current || '1.0.0'),
        minimumRequired: String(ver.minimumRequired || '1.0.0'),
        downloadUrl: String(ver.downloadUrl || ''),
        changelog: String(ver.changelog || ''),
        forceUpdate: Boolean(ver.forceUpdate)
      };
      console.log('[loadRemoteConfig] remoteConfig final:', JSON.stringify(remoteConfig));
    } else {
      remoteConfig = { baseUrl: 'https://hugom1307.github.io/kvrcards-catalog', enabled: true, inventory: { enabled: true, baseUrl: 'https://kvrcards-server.onrender.com' }, maintenance: { enabled: false, title: '', message: '', estimatedTime: '' }, version: { current: '1.0.0', minimumRequired: '1.0.0', downloadUrl: '', changelog: '', forceUpdate: false } };
      console.log('[loadRemoteConfig] No se pudo cargar config, usando defaults oficiales activos');
    }
  } catch (err) {
    console.error('[loadRemoteConfig] Error:', err);
    remoteConfig = { baseUrl: 'https://hugom1307.github.io/kvrcards-catalog', enabled: true, inventory: { enabled: true, baseUrl: 'https://kvrcards-server.onrender.com' } };
  }
}

async function tryFetchRemoteCatalog() {
  const { cacheDir, cacheManifest, cacheCards, cachePacks, cacheTraits, cacheQualities } = getDataPaths();
  if (!remoteConfig.enabled || !remoteConfig.baseUrl) return null;
  const base = ensureSlash(remoteConfig.baseUrl);
  // Añadimos un buster a manifest para evitar caches intermedias
  const manifestUrl = new URL('manifest.json', base).toString() + `?t=${Date.now()}`;
  const cardsBaseUrl = new URL('cards.json', base).toString();
  const packsBaseUrl = new URL('packs.json', base).toString();
  const traitsBaseUrl = new URL('traits.json', base).toString();
  const qualitiesBaseUrl = new URL('calidades.json', base).toString();

  // Lee manifest cache
  let cachedVersion = '0';
  try {
    if (fs.existsSync(cacheManifest)) {
      const m = JSON.parse(fs.readFileSync(cacheManifest, 'utf-8'));
      cachedVersion = String(m.version || '0');
    }
  } catch {}
  // track cached version for debugging
  try { catalogInfo.cachedVersion = cachedVersion; } catch {}

  // Descarga manifest
  const manifest = await httpGetJson(manifestUrl).catch(() => null);
  if (!manifest || !manifest.version) {
    // fallback: usar cache si existe
    try {
      if (fs.existsSync(cacheCards) && fs.existsSync(cachePacks)) {
        const cards = JSON.parse(fs.readFileSync(cacheCards, 'utf-8'));
        const packs = JSON.parse(fs.readFileSync(cachePacks, 'utf-8'));
        let traits = null;
        if (fs.existsSync(cacheTraits)) {
          traits = JSON.parse(fs.readFileSync(cacheTraits, 'utf-8'));
        }
        let qualities = null;
        if (fs.existsSync(cacheQualities)) {
          qualities = JSON.parse(fs.readFileSync(cacheQualities, 'utf-8'));
        }
        return { version: cachedVersion, cards, packs, traits, qualities };
      }
    } catch {}
    return null;
  }
  const remoteVersion = String(manifest.version);
  console.log(`[CATALOG] Versión remota: ${remoteVersion}, Versión cache: ${cachedVersion}`);

  // Descargar ficheros y cachearlos (versionamos la URL para forzar actualización)
  const versionParam = `?v=${encodeURIComponent(remoteVersion)}`;
  console.log(`[CATALOG] Descargando desde: ${cardsBaseUrl + versionParam}`);
  const [cards, packs, traits, qualities] = await Promise.all([
    httpGetJson(cardsBaseUrl + versionParam).catch(e => { console.error('[CATALOG] Error descargando cards:', e); return null; }),
    httpGetJson(packsBaseUrl + versionParam).catch(e => { console.error('[CATALOG] Error descargando packs:', e); return null; }),
    httpGetJson(traitsBaseUrl + versionParam).catch(e => { console.error('[CATALOG] Error descargando traits:', e); return null; }),
    httpGetJson(qualitiesBaseUrl + versionParam).catch(async e => {
      const altUrl = new URL('qualities.json', base).toString() + versionParam;
      const alt = await httpGetJson(altUrl).catch(() => null);
      if (alt) return alt;
      if (base.includes('hugom1307.github.io/kvrcards-catalog') || base.includes('github.io')) {
        const rawUrl = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/calidades.json?t=${Date.now()}`;
        return httpGetJson(rawUrl).catch(() => null);
      }
      return null;
    })
  ]);
  console.log(`[CATALOG] Cards descargadas: ${Array.isArray(cards) ? cards.length : 'null'}`);
  const downloadedPackDefs = Array.isArray(packs) ? packs : (packs && Array.isArray(packs.packs) ? packs.packs : null);
  console.log(`[CATALOG] Packs descargados: ${downloadedPackDefs ? downloadedPackDefs.length : 'null'}`);
  console.log(`[CATALOG] Traits descargados: ${traits && Array.isArray(traits.traits) ? traits.traits.length : 'null'}`);
  const downloadedQualities = Array.isArray(qualities) ? qualities : (qualities && (Array.isArray(qualities.qualities) ? qualities.qualities : (Array.isArray(qualities.calidades) ? qualities.calidades : null)));
  console.log(`[CATALOG] Calidades descargadas: ${downloadedQualities ? downloadedQualities.length : 'null'}`);

  // Si la descarga de la nueva versión falla, usa cache anterior si existe (stale-while-revalidate)
  if (!Array.isArray(cards) || !downloadedPackDefs) {
    try {
      if (fs.existsSync(cacheCards) && fs.existsSync(cachePacks)) {
        const cachedCards = JSON.parse(fs.readFileSync(cacheCards, 'utf-8'));
        const cachedPacks = JSON.parse(fs.readFileSync(cachePacks, 'utf-8'));
        let cachedTraits = null;
        if (fs.existsSync(cacheTraits)) {
          cachedTraits = JSON.parse(fs.readFileSync(cacheTraits, 'utf-8'));
        }
        let cachedQualities = null;
        if (fs.existsSync(cacheQualities)) {
          cachedQualities = JSON.parse(fs.readFileSync(cacheQualities, 'utf-8'));
        }
        return { version: cachedVersion, cards: cachedCards, packs: cachedPacks, traits: cachedTraits, qualities: cachedQualities };
      }
    } catch {}
    return null;
  }
  fs.mkdirSync(cacheDir, { recursive: true });
  fs.writeFileSync(cacheManifest, JSON.stringify({ version: remoteVersion }, null, 2));
  fs.writeFileSync(cacheCards, JSON.stringify(cards, null, 2));
  fs.writeFileSync(cachePacks, JSON.stringify(packs, null, 2));
  if (traits) {
    fs.writeFileSync(cacheTraits, JSON.stringify(traits, null, 2));
  }
  if (qualities) {
    fs.writeFileSync(cacheQualities, JSON.stringify(qualities, null, 2));
  }
  return { version: remoteVersion, cards, packs, traits, qualities: downloadedQualities };
}

// Cargar títulos desde servidor remoto con cache
async function tryFetchRemoteTitles() {
  const { cacheDir } = getDataPaths();
  const cacheTitles = path.join(cacheDir, 'titles.json');
  
  if (!remoteConfig.enabled || !remoteConfig.baseUrl) {
    // Sin config remota, usar cache o fallback
    try {
      if (fs.existsSync(cacheTitles)) {
        return JSON.parse(fs.readFileSync(cacheTitles, 'utf-8'));
      }
    } catch {}
    return null;
  }
  
  const base = ensureSlash(remoteConfig.baseUrl);
  const titlesUrl = new URL('titles.json', base).toString() + `?t=${Date.now()}`;
  
  try {
    console.log('[TITLES] Intentando cargar títulos desde:', titlesUrl);
    const titles = await httpGetJson(titlesUrl);
    
    if (Array.isArray(titles)) {
      // Guardar en cache
      fs.mkdirSync(cacheDir, { recursive: true });
      fs.writeFileSync(cacheTitles, JSON.stringify(titles, null, 2));
      console.log('[TITLES] Títulos remotos cargados:', titles.length);
      return titles;
    }
  } catch (e) {
    console.error('[TITLES] Error cargando títulos remotos:', e);
  }
  
  // Fallback: usar cache si existe
  try {
    if (fs.existsSync(cacheTitles)) {
      console.log('[TITLES] Usando cache de títulos');
      return JSON.parse(fs.readFileSync(cacheTitles, 'utf-8'));
    }
  } catch {}
  
  return null;
}

function ensureSlash(u) { return u.endsWith('/') ? u : u + '/'; }

function normalizeShopEntry(entry, index) {
  if (typeof entry === 'string' || typeof entry === 'number') {
    const id = String(entry).trim();
    return id ? { id, order: index + 1, visible: true, stock: null } : null;
  }
  if (!entry || typeof entry !== 'object') return null;
  const id = String(entry.id || entry.packId || entry.pack || entry.key || '').trim();
  if (!id) return null;

  const hasStock = Object.prototype.hasOwnProperty.call(entry, 'stock');
  const rawStock = hasStock ? Number(entry.stock) : null;
  const rawOrder = Number(entry.order);
  const visibleValue = Object.prototype.hasOwnProperty.call(entry, 'visible')
    ? entry.visible
    : (Object.prototype.hasOwnProperty.call(entry, 'enabled')
      ? entry.enabled
      : (Object.prototype.hasOwnProperty.call(entry, 'show') ? entry.show : true));

  return {
    id,
    order: Number.isFinite(rawOrder) && rawOrder > 0 ? rawOrder : (index + 1),
    visible: visibleValue !== false,
    stock: hasStock ? (Number.isFinite(rawStock) ? Math.max(0, rawStock) : null) : null,
  };
}

function normalizePacksCatalog(raw) {
  if (Array.isArray(raw)) {
    return { packs: raw, shopEntries: [], hasShopConfig: false };
  }

  const source = raw && typeof raw === 'object' ? raw : {};
  const packs = Array.isArray(source.packs)
    ? source.packs
    : (Array.isArray(source.items)
      ? source.items
      : (Array.isArray(source.definitions)
        ? source.definitions
        : (Array.isArray(source.list) ? source.list : [])));

  const shopSource = source.shop ?? source.store ?? source.shopPacks ?? source.shopItems ?? source.shopList;
  let shopEntries = [];
  let hasShopConfig = false;

  if (Array.isArray(shopSource)) {
    hasShopConfig = true;
    shopEntries = shopSource.map((entry, index) => normalizeShopEntry(entry, index)).filter(Boolean);
  } else if (shopSource && typeof shopSource === 'object') {
    hasShopConfig = true;
    const orderList = Array.isArray(shopSource.order)
      ? shopSource.order
      : (Array.isArray(shopSource.ids)
        ? shopSource.ids
        : (Array.isArray(shopSource.packs) ? shopSource.packs : []));
    const limitedMap = shopSource.limited && typeof shopSource.limited === 'object' ? shopSource.limited : {};
    const visibleMap = shopSource.visible && typeof shopSource.visible === 'object' ? shopSource.visible : {};
    const enabledMap = shopSource.enabled && typeof shopSource.enabled === 'object' ? shopSource.enabled : {};

    shopEntries = orderList.map((id, index) => normalizeShopEntry({
      id,
      order: index + 1,
      stock: Object.prototype.hasOwnProperty.call(limitedMap, id) ? limitedMap[id] : null,
      visible: Object.prototype.hasOwnProperty.call(visibleMap, id)
        ? visibleMap[id]
        : (Object.prototype.hasOwnProperty.call(enabledMap, id) ? enabledMap[id] : true),
    }, index)).filter(Boolean);
  }

  return { packs, shopEntries, hasShopConfig };
}

function httpGetJsonWithTimeout(url, timeoutMs = 3000) {
  return new Promise((resolve, reject) => {
    let finished = false;
    const timer = setTimeout(() => {
      if (finished) return; finished = true; reject(new Error('timeout'));
    }, timeoutMs);
    httpGetJson(url).then((v) => { if (finished) return; finished = true; clearTimeout(timer); resolve(v); }, (e) => { if (finished) return; finished = true; clearTimeout(timer); reject(e); });
  });
}

function httpGetRawWithTimeout(url, timeoutMs = 1200) {
  return new Promise((resolve, reject) => {
    let finished = false;
    const timer = setTimeout(() => { if (finished) return; finished = true; reject(new Error('timeout')); }, timeoutMs);
    const request = net.request(url);
    request.on('response', (response) => {
      // Si hay respuesta HTTP, consideramos que hay algo escuchando
      if (finished) return; finished = true; clearTimeout(timer); resolve(true);
      response.resume();
    });
    request.on('error', (e) => { if (finished) return; finished = true; clearTimeout(timer); reject(e); });
    request.end();
  });
}

function safeParseJson(rawText) {
  if (typeof rawText !== 'string') return rawText;
  try {
    return JSON.parse(rawText);
  } catch (initialErr) {
    try {
      let cleaned = rawText.replace(/\/\*[\s\S]*?\*\/|([^\\:]|^)\/\/.*$/gm, '$1');
      cleaned = cleaned.replace(/,\s*([\]}])/g, (match, p1) => p1);
      return JSON.parse(cleaned);
    } catch (cleanErr) {
      try {
        let cleaned2 = rawText.replace(/\/\*[\s\S]*?\*\/|([^\\:]|^)\/\/.*$/gm, '$1');
        // Reparar llaves faltantes antes de cierre de corchetes
        cleaned2 = cleaned2.replace(/(\{[^{}[\]]*?)([\r\n\s]*\])/g, '$1\n}$2');
        cleaned2 = cleaned2.replace(/,\s*([\]}])/g, (match, p1) => p1);
        return JSON.parse(cleaned2);
      } catch (cleanErr2) {
        throw initialErr;
      }
    }
  }
}

function httpGetJson(url) {
  return new Promise((resolve, reject) => {
    const request = net.request(url);
    try {
      request.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      request.setHeader('Pragma', 'no-cache');
      request.setHeader('Expires', '0');
    } catch {}
    let data = '';
    request.on('response', (response) => {
      response.on('data', (chunk) => { data += chunk.toString('utf-8'); });
      response.on('end', () => {
        try { resolve(safeParseJson(data)); } catch (e) { reject(e); }
      });
    });
    request.on('error', reject);
    request.end();
  });
}

function httpPostJson(url, bodyObj) {
  return new Promise((resolve, reject) => {
    const request = net.request({ method: 'POST', url });
    try {
      request.setHeader('Content-Type', 'application/json');
      request.setHeader('Cache-Control', 'no-cache');
    } catch {}
    let data = '';
    request.on('response', (response) => {
      response.on('data', (chunk) => { data += chunk.toString('utf-8'); });
      response.on('end', () => {
        try { resolve(JSON.parse(data)); } catch { resolve({ ok: true }); }
      });
    });
    request.on('error', reject);
    request.end(JSON.stringify(bodyObj || {}));
  });
}

function httpDeleteJson(url) {
  return new Promise((resolve, reject) => {
    const request = net.request({ method: 'DELETE', url });
    try {
      request.setHeader('Cache-Control', 'no-cache');
    } catch {}
    let data = '';
    request.on('response', (response) => {
      response.on('data', (chunk) => { data += chunk.toString('utf-8'); });
      response.on('end', () => {
        try { resolve(JSON.parse(data)); } catch { resolve({ ok: true }); }
      });
    });
    request.on('error', reject);
    request.end();
  });
}

// Función para generar hash de los datos sincronizables
function generateSyncHash() {
  const crypto = require('crypto');
  const syncData = {
    cards: Object.fromEntries(ownedCards),
    packs: Object.fromEntries(ownedPacks),
    wallet: { ...wallet },
    stats: { ...userStats },
    weeklyStats: { ...weeklyStats },
    profileImage: profile.profileImage || '',
    currentTitle: profile.currentTitle || '',
    unlockedTitles: Array.isArray(profile.unlockedTitles) ? profile.unlockedTitles : ['novato'],
    currentBackground: profile.currentBackground || 'default',
    unlockedBackgrounds: Array.isArray(profile.unlockedBackgrounds) ? profile.unlockedBackgrounds : ['default'],
    showcaseCards: profile.showcaseCards || [null, null, null],
    supporterBlessing: supporterBlessing || null,
    password: profile.password || ''
  };
  const jsonStr = JSON.stringify(syncData);
  return crypto.createHash('sha256').update(jsonStr).digest('hex');
}

async function syncInventoryRemote(options = {}) {
  console.log('[syncInventoryRemote] Starting sync...');
  console.log('[syncInventoryRemote] remoteConfig.inventory.enabled:', remoteConfig.inventory?.enabled);
  if (!remoteConfig.inventory?.enabled) {
    console.log('[syncInventoryRemote] Inventory sync disabled, skipping');
    return { skipped: true, reason: 'inventory disabled', config: remoteConfig.inventory };
  }
  const uname = (profile.username || '').trim();
  console.log('[syncInventoryRemote] Username:', uname);
  if (!uname) {
    console.log('[syncInventoryRemote] No username, skipping');
    return { skipped: true, reason: 'no username' };
  }
  
  // Verificar si hay cambios antes de sincronizar
  const currentHash = generateSyncHash();
  if (currentHash === lastSyncHash && !options.force && !profileImageDirty && !options.includeProfileImage) {
    console.log('[syncInventoryRemote] No changes detected, skipping sync');
    return { skipped: true, reason: 'no changes' };
  }
  
  const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
  const url = new URL('api/inventory/' + encodeURIComponent(uname), urlBase).toString();
  console.log('[syncInventoryRemote] Syncing to:', url);

  const localCardsCount = Array.from(ownedCards.values()).reduce((sum, n) => sum + (Number(n) || 0), 0);
  const localPacksCount = Array.from(ownedPacks.values()).reduce((sum, n) => sum + (Number(n) || 0), 0);
  const powersObj = {};
  ownedPowers.forEach((data, id) => {
    // Los poderes tienen { permanent: true } o { uses: X }
    if (data.permanent === true || (data.uses && data.uses > 0)) {
      powersObj[id] = data;
    }
  });
  const localPowersCount = Object.keys(powersObj).length;
  const localInventoryIsEmpty = localCardsCount === 0 && localPacksCount === 0 && localPowersCount === 0;

  // Protección anti-sobrescritura solo si el inventario local está totalmente vacío y no es un reseteo explícito
  if (localInventoryIsEmpty && !options.allowEmptySync) {
    try {
      const existing = await httpGetJson(url + `?t=${Date.now()}`);
      const existingResetAt = Number(existing?.resetAt) || 0;
      const localResetAt = Number(profile.resetAt) || 0;
      if (existingResetAt > 0 && existingResetAt > localResetAt) {
        console.log('[syncInventoryRemote] Servidor remoto en estado reseteado por admin. Aceptando estado vacío.');
        profile.resetAt = existingResetAt;
        profile.isReset = true;
        try { saveProfile(); } catch {}
      } else {
        const remoteCardsCount = Object.values(existing?.cards || {}).reduce((sum, n) => sum + (Number(n) || 0), 0);
        const remotePacksCount = Object.values(existing?.packs || {}).reduce((sum, n) => sum + (Number(n) || 0), 0);
        const remotePowersCount = Object.keys(existing?.powers || {}).length;
        if (remoteCardsCount > 0 || remotePacksCount > 0 || remotePowersCount > 0) {
          console.error('[syncInventoryRemote] BLOCKED destructive sync: local inventory empty while remote has data');
          return { skipped: true, reason: 'blocked-destructive-sync' };
        }
      }
    } catch (e) {
      console.log('[syncInventoryRemote] Pre-check read error (safe to proceed):', e.message);
    }
  }
  
  const payload = {
    username: uname,
    password: profile.password || '', // Contraseña para mostrar en el servidor
    forceReplace: (options.forceReplace || options.allowEmptySync) ? 'true' : 'false',
    cards: Object.fromEntries(ownedCards),
    packs: Object.fromEntries(ownedPacks),
    powers: powersObj, // Poderes del usuario
    cardTraits: Object.fromEntries(cardTraits), // Sincronizar rasgos
    cardUpgrades: Object.fromEntries(cardUpgrades), // Sincronizar mejoras
    completedDeliverables: completedDeliverables, // Sincronizar entregables completados
    deliverableCompletions: deliverableCompletions, // Sincronizar conteo de entregas
    deliverableDailyCompletions: deliverableDailyCompletions, // Sincronizar conteo de entregas diarias
    packPurchases: packPurchases, // Sincronizar compras de sobres limitados
    redeemedCodes: Array.from(redeemedCodes), // Sincronizar códigos canjeados
    supporterBlessing: supporterBlessing, // Sincronizar bendición del supporter
    wallet: { ...wallet },
    stats: { ...userStats }, // Estadísticas históricas
    weeklyStats: { ...weeklyStats }, // Estadísticas semanales
    missions: { ...userMissions }, // Misiones del usuario
    kizunas: { ...userKizunas }, // Kizunas del usuario
    settings: {
      ...(userSettings || {}),
      currentBackground: profile.currentBackground || 'default',
      unlockedBackgrounds: Array.isArray(profile.unlockedBackgrounds) ? profile.unlockedBackgrounds : ['default']
    }, // Configuración del usuario (tema, fondos, etc.)
    currentTitle: profile.currentTitle || '', // Título actual
    unlockedTitles: Array.isArray(profile.unlockedTitles) ? profile.unlockedTitles : ['novato'], // Títulos desbloqueados
    currentBackground: profile.currentBackground || 'default', // Fondo actual de perfil
    unlockedBackgrounds: Array.isArray(profile.unlockedBackgrounds) ? profile.unlockedBackgrounds : ['default'], // Fondos desbloqueados
    showcaseCards: profile.showcaseCards || [null, null, null], // Cartas destacadas
    resetAt: Number(profile.resetAt) || 0,
    updatedAt: Date.now(),
  };

  // Solo enviar profileImage si cambió o se solicita explícitamente (ahorra 99% de ancho de banda)
  if ((profileImageDirty || options.includeProfileImage) && profile.profileImage) {
    payload.profileImage = profile.profileImage;
    profileImageDirty = false;
  }

  console.log('[syncInventoryRemote] Payload stats:', payload.stats);
  console.log('[syncInventoryRemote] Payload weeklyStats:', payload.weeklyStats);
  try {
    const res = await httpPostJson(url, payload);
    console.log('[SYNC] Inventory uploaded for', uname, ', response:', res);
    if (res && res.error === 'account-reset-by-admin') {
      const rAt = Number(res.resetAt) || 0;
      const localResetAt = Number(profile.resetAt) || 0;
      if (rAt > 0 && rAt > localResetAt) {
        console.warn('[syncInventoryRemote] El servidor indica que la cuenta fue reiniciada por el admin. Ejecutando reseteo local único para:', uname);
        await resetUserAccountLocally(uname, profile.password, rAt);
        return { ok: true, wasReset: true, error: 'account-reset-by-admin' };
      }
    }
    // Actualizar hash después de sincronización exitosa
    lastSyncHash = currentHash;
    console.log('[syncInventoryRemote] Sync hash updated');
    return { ...(res || { ok: true }), debug: { url, stats: payload.stats, weeklyStats: payload.weeklyStats } };
  } catch (e) {
    console.error('[syncInventoryRemote] Error:', e);
    return { error: String(e), debug: { url, errorDetail: e } };
  }
}

async function fetchInventoryRemote(username) {
  if (!remoteConfig.inventory?.enabled) return null;
  const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
  const url = new URL('api/inventory/' + encodeURIComponent(username), urlBase).toString() + `?t=${Date.now()}`;
  try { return await httpGetJson(url); } catch { return null; }
}

async function fetchInfiniteRunRemote(username) {
  if (!remoteConfig.inventory?.enabled) return null;
  const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
  if (!urlBase) return null;
  const url = new URL('api/infinite/run/' + encodeURIComponent(username), urlBase).toString() + `?t=${Date.now()}`;
  try { return await httpGetJson(url); } catch { return null; }
}

async function saveInfiniteRunRemote(username, run) {
  if (!remoteConfig.inventory?.enabled) return { ok: false, error: 'Inventory remoto deshabilitado' };
  const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
  if (!urlBase) return { ok: false, error: 'URL de inventario remoto no configurada' };
  const url = new URL('api/infinite/run/' + encodeURIComponent(username), urlBase).toString();
  try {
    return await httpPostJson(url, { run });
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

async function resetInfiniteRunRemote(username) {
  if (!remoteConfig.inventory?.enabled) return { ok: false, error: 'Inventory remoto deshabilitado' };
  const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
  if (!urlBase) return { ok: false, error: 'URL de inventario remoto no configurada' };
  const url = new URL('api/infinite/run/' + encodeURIComponent(username), urlBase).toString();
  try {
    return await httpDeleteJson(url);
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

async function fetchInfiniteRankingsOverviewRemote(username, limit = 5) {
  if (!remoteConfig.inventory?.enabled) return { ok: false, error: 'Inventory remoto deshabilitado' };
  const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
  if (!urlBase) return { ok: false, error: 'URL de inventario remoto no configurada' };

  const safeLimit = Math.min(50, Math.max(1, Number(limit) || 5));
  const safeUsername = String(username || '').trim();
  const params = new URLSearchParams({ limit: String(safeLimit) });
  if (safeUsername) params.set('username', safeUsername);

  const url = new URL(`api/infinite/rankings?${params.toString()}`, urlBase).toString() + `&t=${Date.now()}`;
  try {
    return await httpGetJson(url);
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

async function clearCatalogCache() {
  const { cacheDir } = getDataPaths();
  try {
    if (fs.existsSync(cacheDir)) {
      fs.rmSync(cacheDir, { recursive: true, force: true });
    }
  } catch {}
}

// ---- Perfil IPC ----
ipcMain.handle('profile:get', async () => {
  try { loadProfile(); } catch {}
  return { ok: true, profile };
});

ipcMain.handle('profile:logout', async () => {
  const current = (profile.username || '').trim();
  console.log('[AUTH] Desconectando sesion local para:', current || '(sin usuario)');
  if (current) {
    try { saveInventory(); } catch (e) { console.error('[AUTH] Error guardando antes de logout:', e); }
  }
  resetSessionState();
  const { profileFile } = getDataPaths();
  writeJSON(profileFile, { username: '', password: '' });
  return { ok: true };
});

async function resetUserAccountLocally(targetUser, targetPassword, resetAtTimestamp) {
  const currentUser = (targetUser || profile.username || '').trim();
  const currentPassword = targetPassword || profile.password || '';
  const now = Number(resetAtTimestamp) || Date.now();
  console.log('[RESET] Reinicio total de cuenta localmente para:', currentUser || '(sin usuario)', 'resetAt:', now);

  inTransaction = true;
  try {
    // 1. Limpiar estructuras en memoria a valores de cuenta nueva
    ownedCards.clear();
    ownedPacks.clear();
    ownedPowers.clear();
    cardTraits.clear();
    cardUpgrades.clear();
    wallet = { coins: 0, kvr: 0, traits: 0, 'infinite-coins': 0, 'infinite-cardpoints': 0 };
    userStats = { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0, battlesWon: 0, battlesPlayed: 0 };
    weeklyStats = { cards: 0, packs: 0, coins: 0, weekStart: (typeof getCurrentMondayTimestamp === 'function' ? getCurrentMondayTimestamp() : null) };
    userMissions = {};
    userKizunas = {};
    completedDeliverables = [];
    deliverableCompletions = {};
    deliverableDailyCompletions = {};
    packPurchases = {};
    redeemedCodes.clear();
    supporterBlessing = null;
    userSettings = {
      theme: { active: 'default', customTheme: null },
      currentBackground: 'default',
      unlockedBackgrounds: ['default']
    };
    profile.currentTitle = 'Novato';
    profile.unlockedTitles = ['novato'];
    profile.currentBackground = 'default';
    profile.unlockedBackgrounds = ['default'];
    profile.showcaseCards = [null, null, null];
    profile.profileImage = '';
    profile.username = currentUser;
    profile.password = currentPassword;
    profile.resetAt = now;
    profile.isReset = true;
    lastSyncHash = null;

    // 2. Limpiar archivos dedicados del usuario en disco
    const { dataDir, inventoryFile, inventoryBackupFile } = getDataPaths();
    const userDir = app.getPath('userData');

    if (currentUser) {
      // Códigos canjeados dedicados
      try {
        const codesFile = getRedeemedCodesFilePath(currentUser);
        writeJSONAtomic(codesFile, []);
      } catch (errCodes) {
        console.warn('[RESET] Error guardando códigos dedicados vacíos:', errCodes);
      }

      // Códigos de único uso local
      try {
        const usedCodesFile = path.join(dataDir, 'used_single_codes.json');
        if (fs.existsSync(usedCodesFile)) {
          let localUsed = {};
          try { localUsed = JSON.parse(fs.readFileSync(usedCodesFile, 'utf-8')); } catch {}
          let changed = false;
          for (const [codeKey, usage] of Object.entries(localUsed)) {
            if (usage && (usage.user === currentUser || usage.username === currentUser)) {
              delete localUsed[codeKey];
              changed = true;
            }
          }
          if (changed) {
            writeJSONAtomic(usedCodesFile, localUsed);
          }
        }
      } catch (errSingleCodes) {
        console.warn('[RESET] Error limpiando códigos únicos usados:', errSingleCodes);
      }

      // Bendición del supporter dedicada
      try {
        const blessingFile = getSupporterBlessingFilePath(currentUser);
        if (fs.existsSync(blessingFile)) {
          try { fs.unlinkSync(blessingFile); } catch {
            writeJSONAtomic(blessingFile, { active: false, daysRemaining: 0 });
          }
        }
      } catch (errBlessing) {
        console.warn('[RESET] Error limpiando archivo de bendición:', errBlessing);
      }

      // Evoluciones dedicadas en disco
      try {
        const evoFile = getEvolutionStateFile();
        if (evoFile) {
          writeJSONAtomic(evoFile, {});
        }
        const legacyEvoFile = path.join(userDir, 'evolutions-state.json');
        if (fs.existsSync(legacyEvoFile)) {
          writeJSONAtomic(legacyEvoFile, {});
        }
      } catch (errEvo) {
        console.warn('[RESET] Error limpiando evoluciones en disco:', errEvo);
      }

      // 3. Escribir estado limpio en inventory.json y respaldo
      try {
        let inv = readJSON(inventoryFile, { users: {}, lastUser: currentUser });
        if (!inv || typeof inv !== 'object' || !inv.users) inv = { users: {}, lastUser: currentUser };
        
        inv.users[currentUser] = {
          cards: {},
          packs: {},
          powers: {},
          cardTraits: {},
          cardUpgrades: {},
          wallet: { coins: 0, kvr: 0, traits: 0, 'infinite-coins': 0, 'infinite-cardpoints': 0 },
          stats: { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0, battlesWon: 0, battlesPlayed: 0 },
          weeklyStats: { cards: 0, packs: 0, coins: 0, weekStart: (typeof getCurrentMondayTimestamp === 'function' ? getCurrentMondayTimestamp() : null) },
          missions: {},
          kizunas: {},
          settings: {
            theme: { active: 'default', customTheme: null },
            currentBackground: 'default',
            unlockedBackgrounds: ['default']
          },
          profileImage: '',
          currentTitle: 'Novato',
          unlockedTitles: ['novato'],
          currentBackground: 'default',
          unlockedBackgrounds: ['default'],
          showcaseCards: [null, null, null],
          completedDeliverables: [],
          deliverableCompletions: {},
          deliverableDailyCompletions: {},
          packPurchases: {},
          redeemedCodes: [],
          supporterBlessing: null,
          resetAt: now,
          isReset: true
        };
        inv.lastUser = currentUser;
        writeJSON(inventoryFile, inv);

        // Actualizar respaldo para evitar que una recuperación futura restaure los datos viejos
        try {
          if (fs.existsSync(inventoryBackupFile)) {
            let bInv = readJSON(inventoryBackupFile, null);
            if (bInv && bInv.users) {
              bInv.users[currentUser] = JSON.parse(JSON.stringify(inv.users[currentUser]));
              bInv.lastUser = currentUser;
              writeJSON(inventoryBackupFile, bInv);
            }
          }
        } catch (errBackup) {
          console.warn('[RESET] Error actualizando backup:', errBackup);
        }
      } catch (errInv) {
        console.error('[RESET] Error guardando inventory.json limpio:', errInv);
      }

      // Guardar perfil limpio
      try {
        saveProfile();
      } catch {}
    }

    inTransaction = false;

    // Notificar a todas las ventanas renderer
    try {
      const allWindows = BrowserWindow.getAllWindows();
      for (const w of allWindows) {
        if (w && w.webContents && !w.webContents.isDestroyed()) {
          w.webContents.send('account:reset-by-admin', { username: currentUser, resetAt: now });
        }
      }
    } catch (eNotify) {
      console.warn('[RESET] Error notificando ventanas renderer:', eNotify);
    }

    console.log('[RESET] Reinicio total completado con éxito para:', currentUser);
    return { ok: true, resetAt: now };
  } catch (err) {
    inTransaction = false;
    console.error('[RESET] Error crítico durante el reinicio:', err);
    return { ok: false, error: err.message || String(err) };
  }
}

// Reinicio total de cuenta de usuario (progreso completo de fábrica)
ipcMain.handle('account:resetAll', async () => {
  const currentUser = (profile.username || '').trim();
  const currentPassword = profile.password || '';
  const now = Date.now();
  console.log('[RESET] Reinicio total de cuenta solicitado para usuario:', currentUser || '(sin usuario)');

  const res = await resetUserAccountLocally(currentUser, currentPassword, now);
  if (!res.ok) return res;

  if (currentUser) {
    try {
      await resetInfiniteRunRemote(currentUser);
    } catch {}

    try {
      await syncInventoryRemote({ force: true, allowEmptySync: true, forceReplace: true });
    } catch (errSync) {
      console.warn('[RESET] Error sincronizando a servidor:', errSync);
    }
  }

  return { ok: true };
});

ipcMain.handle('profile:setUsername', async (_e, username) => {
  const uname = String(username || '').trim();
  if (!uname) return { error: 'Nombre de usuario vacio' };

  // Si habia otro usuario activo, guardar sus datos primero
  if (profile.username && profile.username !== uname) {
    console.log('[AUTH] Cambiando de usuario:', profile.username, '->', uname);
    try { saveInventory(); } catch (e) { console.error('[AUTH] Error guardando usuario previo:', e); }
    resetSessionState();
  }
  
  profile.username = uname;
  try { saveProfile(); } catch {}
  
  // Asegurar estructura de inventario por usuarios y migrar si es necesario
  const { inventoryFile } = getDataPaths();
  const inv = readJSON(inventoryFile, { users: {}, lastUser: '' });
  // migracion desde legacy
  if (!inv.users) inv.users = {};
  if (!inv.lastUser && inv.cards) {
    inv.users[uname] = { cards: inv.cards || {}, packs: inv.packs || {} };
    delete inv.cards; delete inv.packs;
  }
  if (!inv.users[uname]) inv.users[uname] = { cards: {}, packs: {} };
  inv.lastUser = uname;
  writeJSON(inventoryFile, inv);
  
  // Recargar a memoria el inventario actual del usuario
  await loadData();
  ensureSupporterBlessingLoaded(uname);

  // Si el usuario en inv tiene resetAt, asignarlo al profile
  if (inv.users && inv.users[uname] && inv.users[uname].resetAt) {
    profile.resetAt = Number(inv.users[uname].resetAt) || profile.resetAt || 0;
  }
  
  // Cargar estadisticas del usuario desde el inventario recien guardado
  if (inv.users && inv.users[uname] && inv.users[uname].stats) {
    userStats = { ...inv.users[uname].stats };
    if (typeof userStats.battlesWon !== 'number') {
      userStats.battlesWon = 0;
    }
    if (typeof userStats.battlesPlayed !== 'number') {
      userStats.battlesPlayed = 0;
    }
    console.log('[STATS] Cargadas para', uname, ':', userStats);
  } else {
    userStats = { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0, battlesWon: 0, battlesPlayed: 0 };
    console.log('[STATS] Iniciadas para', uname);
  }
  
  // Cargar estadisticas semanales
  if (inv.users && inv.users[uname] && inv.users[uname].weeklyStats) {
    weeklyStats = { ...inv.users[uname].weeklyStats };
    console.log('[RANKINGS] Stats semanales cargadas para', uname, ':', weeklyStats);
  } else {
    weeklyStats = { cards: 0, packs: 0, coins: 0, weekStart: null };
    console.log('[RANKINGS] Stats semanales iniciadas para', uname);
  }
  
  checkWeeklyReset(); // Verificar si hay que resetear
  
  try { ensureInventorySyncTimer(); syncInventoryRemote().catch(() => {}); } catch {}
  return { ok: true, profile };
});

// Sincronización remota de inventario (manual)
ipcMain.handle('inventory:syncRemote', async () => {
  console.log('[IPC] inventory:syncRemote handler called');
  const res = await syncInventoryRemote();
  console.log('[IPC] syncInventoryRemote result:', res);
  return res?.error ? { error: res.error } : { ok: true };
});

// Consultar inventario remoto del usuario actual
ipcMain.handle('inventory:getRemote', async () => {
  const uname = (profile.username || '').trim();
  if (!uname) return { error: 'Sin usuario' };
  const data = await fetchInventoryRemote(uname);
  if (!data) return { error: 'No disponible' };

  // Comprobar si la cuenta remota fue reseteada por admin
  const serverResetAt = Number(data.resetAt) || 0;
  const localResetAt = Number(profile.resetAt) || 0;
  if (serverResetAt > 0 && serverResetAt > localResetAt) {
    console.log('[inventory:getRemote] Remoto indica reset por admin. Ejecutando reset local único para:', uname);
    await resetUserAccountLocally(uname, profile.password, serverResetAt);
  }

  return { ok: true, data };
});

ipcMain.handle('infinite:loadRunState', async () => {
  const uname = (profile.username || '').trim();
  if (!uname) return { ok: false, error: 'Sin usuario' };

  const result = await fetchInfiniteRunRemote(uname);
  if (!result || result.ok === false) {
    return { ok: false, error: result?.error || 'No se pudo cargar progreso infinito' };
  }

  return { ok: true, run: result.run || null };
});

ipcMain.handle('infinite:saveRunState', async (_e, run) => {
  const uname = (profile.username || '').trim();
  if (!uname) return { ok: false, error: 'Sin usuario' };

  if (!run || typeof run !== 'object') {
    return { ok: false, error: 'Estado de run inválido' };
  }

  const result = await saveInfiniteRunRemote(uname, run);
  if (!result || result.ok === false) {
    return { ok: false, error: result?.error || 'No se pudo guardar progreso infinito' };
  }

  return { ok: true, run: result.run || null };
});

ipcMain.handle('infinite:resetRunState', async () => {
  const uname = (profile.username || '').trim();
  if (!uname) return { ok: false, error: 'Sin usuario' };

  const result = await resetInfiniteRunRemote(uname);
  if (!result || result.ok === false) {
    return { ok: false, error: result?.error || 'No se pudo resetear la run infinita' };
  }

  if (!wallet) wallet = {};
  wallet['infinite-coins'] = 0;
  wallet['infinite-cardpoints'] = 0;
  try { saveInventory(); } catch {}

  return { ok: true, run: null };
});

ipcMain.handle('infinite:getRankingsOverview', async (_e, limit = 5) => {
  const uname = (profile.username || '').trim();
  const result = await fetchInfiniteRankingsOverviewRemote(uname, limit);
  if (!result || result.ok === false) {
    return { ok: false, error: result?.error || 'No se pudieron cargar los rankings de infinito' };
  }
  return result;
});

// ---- Missions IPC ----
ipcMain.handle('missions:getState', () => {
  return { ok: true, missions: userMissions };
});

ipcMain.handle('missions:saveState', (_e, missions) => {
  if (missions && typeof missions === 'object') {
    userMissions = missions;
    try { saveInventory(); } catch {}
    return { ok: true };
  }
  return { error: 'Datos de misiones inválidos' };
});

// ---- Kizunas IPC ----
ipcMain.handle('kizunas:getState', () => {
  return { ok: true, kizunas: { ...userKizunas } };
});

ipcMain.handle('kizunas:saveState', (_e, kizunas) => {
  if (kizunas && typeof kizunas === 'object') {
    userKizunas = { ...kizunas };
    try { saveInventory(); } catch {}
    return { ok: true };
  }
  return { error: 'Datos de kizunas inválidos' };
});

// ---- Settings IPC ----
ipcMain.handle('settings:get', () => {
  return { ok: true, settings: userSettings };
});

ipcMain.handle('settings:save', (_e, settings) => {
  if (settings && typeof settings === 'object') {
    userSettings = settings;
    try { saveInventory(); } catch {}
    return { ok: true };
  }
  return { error: 'Datos de configuración inválidos' };
});

// Compra de sobres (descuenta saldo y añade al inventario)
ipcMain.handle('shop:buyPack', async (_e, packId, preferred, amount = 1) => {
  const pack = packStore.get(packId);
  if (!pack) return { error: 'Pack no encontrado' };
  if (pack.shopVisible === false) return { error: 'Sobre no disponible en tienda' };
  
  const qty = Math.max(1, parseInt(amount, 10) || 1);

  // Verificar stock restando compras del usuario
  let currentStock = pack.stock;
  if (pack.stock !== null && pack.stock !== undefined) {
    const bought = Number(packPurchases[packId]) || 0;
    currentStock = Math.max(0, Number(pack.stock) - bought);
    if (currentStock <= 0) {
      return { error: 'Sobre agotado' };
    }
    if (qty > currentStock) {
      return { error: `Solo puedes comprar un máximo de ${currentStock} sobres de este tipo` };
    }
  }
  
  const price = pack.price || { coins: 0, kvr: 0 };
  const pc = Math.max(0, Number(price.coins) || 0);
  const pk = Math.max(0, Number(price.kvr) || 0);
  const totalPc = pc * qty;
  const totalPk = pk * qty;
  
  // Respetar la moneda preferida del usuario
  if (preferred === 'kvr') {
    // Usuario quiere pagar con KvR
    if (totalPk > 0 && (wallet.kvr || 0) >= totalPk) {
      wallet.kvr = Math.max(0, (wallet.kvr || 0) - totalPk);
    } else if (totalPk === 0) {
      // Si el precio en kvr es 0, es gratis
    } else {
      return { error: 'KvR insuficiente' };
    }
  } else {
    // Usuario quiere pagar con Coins (por defecto)
    if (totalPc > 0 && (wallet.coins || 0) >= totalPc) {
      wallet.coins = Math.max(0, (wallet.coins || 0) - totalPc);
    } else if (totalPc === 0) {
      // Si el precio en coins es 0, es gratis
    } else {
      return { error: 'Coins insuficientes' };
    }
  }
  
  // Registrar compra de sobre limitado
  if (pack.stock !== null && pack.stock !== undefined) {
    packPurchases[packId] = (Number(packPurchases[packId]) || 0) + qty;
  }
  
  const cur = ownedPacks.get(packId) || 0;
  ownedPacks.set(packId, cur + qty);
  try { saveInventory(); } catch {}
  return { ok: true, packs: Object.fromEntries(ownedPacks), wallet: { ...wallet } };
});

// ---- Admin: limpiar historial de comandos ejecutados ----
ipcMain.handle('admin:clearCommandHistory', async () => {
  try {
    if (!profile.executedCommands) profile.executedCommands = [];
    const count = profile.executedCommands.length;
    profile.executedCommands = [];
    profile.lastCommandsVersion = null;
    saveProfile();
    return { ok: true, cleared: count };
  } catch (e) {
    return { error: String(e) };
  }
});

// ---- Admin: sincronización de comandos desde remoto o override ----
// Formato esperado de commands.json: { version: "1", commands: [{ username: "pepe", action: "add|remove", cardId: "...", count: 1 }] }
ipcMain.handle('admin:syncCommands', async () => {
  try {
    const res = await syncAdminCommands();
    return { ok: true, ...res };
  } catch (e) {
    return { error: String(e) };
  }
});

// Forzar sincronización ignorando versión
ipcMain.handle('admin:syncCommandsForce', async () => {
  try {
    const res = await syncAdminCommands(/*force*/true);
    return { ok: true, ...res };
  } catch (e) {
    return { error: String(e) };
  }
});

// ---- SISTEMA DE BENDICIÓN DEL SUPPORTER (RESETEO A LAS 06:00 MADRID) ----

function getMadridDayCycle(date = new Date()) {
  const formatter = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Madrid',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });
  const parts = formatter.formatToParts(date);
  let y = 2026, m = 1, d = 1, hour = 12;
  for (const p of parts) {
    if (p.type === 'year') y = parseInt(p.value, 10);
    if (p.type === 'month') m = parseInt(p.value, 10);
    if (p.type === 'day') d = parseInt(p.value, 10);
    if (p.type === 'hour') hour = parseInt(p.value, 10);
  }

  // Las 6:00 AM hora Madrid es el momento de reseteo diario
  const madridDate = new Date(Date.UTC(y, m - 1, d));
  if (hour < 6) {
    madridDate.setUTCDate(madridDate.getUTCDate() - 1);
  }
  
  const cycleYear = madridDate.getUTCFullYear();
  const cycleMonth = String(madridDate.getUTCMonth() + 1).padStart(2, '0');
  const cycleDay = String(madridDate.getUTCDate()).padStart(2, '0');
  return `${cycleYear}-${cycleMonth}-${cycleDay}`;
}

function calculateCyclesDiff(cycleA, cycleB) {
  if (!cycleA || !cycleB) return 0;
  const [y1, m1, d1] = cycleA.split('-').map(Number);
  const [y2, m2, d2] = cycleB.split('-').map(Number);
  const dt1 = Date.UTC(y1, m1 - 1, d1);
  const dt2 = Date.UTC(y2, m2 - 1, d2);
  return Math.round((dt2 - dt1) / (1000 * 60 * 60 * 24));
}

function updateBlessingState() {
  const currentUsername = (profile.username || '').trim();
  ensureSupporterBlessingLoaded(currentUsername);

  if (!supporterBlessing || !supporterBlessing.active) {
    return { active: false, daysRemaining: 0, canClaimToday: false };
  }

  const currentCycle = getMadridDayCycle();
  const lastCycle = supporterBlessing.lastUpdatedCycle || currentCycle;
  
  if (currentCycle !== lastCycle) {
    const elapsedDays = calculateCyclesDiff(lastCycle, currentCycle);
    if (elapsedDays > 0) {
      supporterBlessing.daysRemaining = Math.max(0, (supporterBlessing.daysRemaining || 0) - elapsedDays);
      supporterBlessing.lastUpdatedCycle = currentCycle;
      if (supporterBlessing.daysRemaining <= 0) {
        supporterBlessing.active = false;
      }
      try {
        saveUserSupporterBlessing(currentUsername, supporterBlessing);
        saveInventory();
      } catch {}
    }
  }

  const canClaimToday = Boolean(
    supporterBlessing.active && 
    supporterBlessing.daysRemaining > 0 && 
    supporterBlessing.lastClaimCycle !== currentCycle
  );

  return {
    active: Boolean(supporterBlessing.active && supporterBlessing.daysRemaining > 0),
    daysRemaining: supporterBlessing.daysRemaining || 0,
    canClaimToday,
    lastClaimCycle: supporterBlessing.lastClaimCycle,
    currentCycle
  };
}

ipcMain.handle('blessing:getStatus', () => {
  return { ok: true, ...updateBlessingState() };
});

ipcMain.handle('blessing:claimDaily', () => {
  const currentUsername = (profile.username || '').trim();
  ensureSupporterBlessingLoaded(currentUsername);

  const state = updateBlessingState();
  if (!state.active) {
    return { ok: false, error: 'No tienes la Bendición del Supporter activa' };
  }
  if (!state.canClaimToday) {
    return { ok: false, error: 'Ya has reclamado tus 30 KvR de hoy. Se reinicia a las 06:00 AM hora Madrid.' };
  }

  const currentCycle = getMadridDayCycle();
  const dailyKvR = supporterBlessing.dailyAmount || 30;
  wallet.kvr = (wallet.kvr || 0) + dailyKvR;
  supporterBlessing.lastClaimCycle = currentCycle;

  try {
    saveUserSupporterBlessing(currentUsername, supporterBlessing);
    saveInventory();
    lastSyncHash = null;
    syncInventoryRemote().catch(() => {});
  } catch (e) {
    console.error('[BLESSING] Error guardando inventario tras reclamar diario:', e);
  }

  return {
    ok: true,
    amount: dailyKvR,
    newWallet: { ...wallet },
    ...updateBlessingState()
  };
});

// ---- Códigos canjeables ----
ipcMain.handle('codes:redeem', async (_e, code) => {
  if (!code || typeof code !== 'string') return { error: 'Código inválido' };
  
  const codeUpper = code.trim().toUpperCase();
  
  // Verificar si ya fue canjeado en la cuenta local
  if (redeemedCodes.has(codeUpper)) {
    return { error: 'Este código ya ha sido canjeado en tu cuenta' };
  }
  
  // Cargar códigos desde remoto/override/seeds
  let codesData = null;
  try {
    // Intentar desde remoto
    if (remoteConfig.enabled && remoteConfig.baseUrl) {
      const url = new URL('codes.json', ensureSlash(remoteConfig.baseUrl)).toString() + `?t=${Date.now()}`;
      console.log('[CODES] Intentando cargar desde:', url);
      codesData = await httpGetJson(url).catch((err) => {
        console.error('[CODES] Error en remoto:', err);
        return null;
      });
      if (codesData) {
        console.log('[CODES] Códigos cargados desde remoto');
      }
    }
    
    // Intentar desde override
    if (!codesData) {
      const exeDir = path.dirname(process.execPath);
      const overrideCodes = path.join(exeDir, 'game-data', 'codes.json');
      console.log('[CODES] Intentando cargar desde override:', overrideCodes);
      if (fs.existsSync(overrideCodes)) {
        codesData = JSON.parse(fs.readFileSync(overrideCodes, 'utf-8'));
        console.log('[CODES] Códigos cargados desde override');
      }
    }
    
    // Intentar desde seeds
    if (!codesData) {
      const seedPath = path.join(__dirname, '..', 'seeds', 'codes.json');
      console.log('[CODES] Intentando cargar desde seeds:', seedPath);
      if (fs.existsSync(seedPath)) {
        codesData = JSON.parse(fs.readFileSync(seedPath, 'utf-8'));
        console.log('[CODES] Códigos cargados desde seeds');
      }
    }
  } catch (e) {
    console.error('[CODES] Error cargando códigos:', e);
    return { error: `Error al cargar códigos: ${e.message}` };
  }
  
  if (!codesData) {
    console.error('[CODES] No se encontró codes.json en ninguna ubicación');
    return { error: 'No se encontró el archivo de códigos. Contacta al administrador.' };
  }
  
  if (!Array.isArray(codesData.codes)) {
    console.error('[CODES] Formato inválido de codes.json:', codesData);
    return { error: 'Formato de códigos inválido' };
  }
  
  console.log(`[CODES] ${codesData.codes.length} códigos disponibles`);
  
  // Buscar el código
  const codeEntry = codesData.codes.find(c => c.code === codeUpper);
  
  if (!codeEntry) {
    return { error: 'Código no válido' };
  }
  
  if (!codeEntry.active) {
    return { error: 'Este código ya no está activo' };
  }

  // Comprobar si es un código de único uso
  const isSingleUse = Boolean(codeEntry.singleUse || codeEntry.unicoUso || codeEntry.single_use);
  if (isSingleUse) {
    // 1. Consultar servidor remoto de inventario si está configurado
    if (remoteConfig.inventory && remoteConfig.inventory.enabled && remoteConfig.inventory.baseUrl) {
      try {
        const base = ensureSlash(remoteConfig.inventory.baseUrl);
        const checkUrl = new URL(`api/codes/status/${encodeURIComponent(codeUpper)}`, base).toString();
        const res = await httpGetJson(checkUrl).catch(() => null);
        if (res && res.used) {
          return { error: `Este código de único uso ya ha sido canjeado por ${res.user || 'otro usuario'}.` };
        }
      } catch (e) {
        console.warn('[CODES] No se pudo verificar estado de código único con servidor:', e.message);
      }
    }

    // 2. Consultar archivo local de códigos únicos usados (para juego offline o fallback)
    const { dataDir } = getDataPaths();
    const usedCodesFile = path.join(dataDir, 'used_single_codes.json');
    let localUsed = {};
    try {
      if (fs.existsSync(usedCodesFile)) {
        localUsed = JSON.parse(fs.readFileSync(usedCodesFile, 'utf-8'));
      }
    } catch {}
    if (localUsed[codeUpper]) {
      return { error: 'Este código de único uso ya ha sido canjeado.' };
    }
  }
  
  // Aplicar recompensas
  const rewards = codeEntry.rewards || {};
  const rewardsSummary = [];
  
  // Añadir monedas
  if (rewards.coins && rewards.coins > 0) {
    wallet.coins = (wallet.coins || 0) + rewards.coins;
    incrementCoinsEarned(rewards.coins); // Incrementar contador histórico
    rewardsSummary.push(`${rewards.coins} Coins`);
  }

  // Añadir traits (rasgos)
  const traitsReward = Number(rewards.traits || rewards.trait || 0);
  if (traitsReward > 0) {
    wallet.traits = Math.max(0, (wallet.traits || 0) + traitsReward);
    logCriticalEvent('add', `Added traits from code ${codeUpper}: ${traitsReward}. Balance: ${wallet.traits}`);
    rewardsSummary.push(`${traitsReward} Traits`);
  }

  // Comprobar si es suscripción / bendición del supporter
  const isBlessing = Boolean(codeEntry.subscription || codeEntry.bendicion || codeEntry.supporterBlessing);
  let instantKvr = 0;

  if (isBlessing) {
    // Recompensas de la Bendición del Supporter
    instantKvr = Number(rewards.kvr) || 300;
    wallet.kvr = (wallet.kvr || 0) + instantKvr;
    rewardsSummary.push(`${instantKvr} KvR Instantáneos`);

    const currentCycle = getMadridDayCycle();
    const currentUsername = (profile.username || '').trim();

    // Si supporterBlessing estaba null en memoria, intentar recuperarla del inventario local
    if (!supporterBlessing && currentUsername) {
      try {
        const { inventoryFile } = getDataPaths();
        if (fs.existsSync(inventoryFile)) {
          const inv = readJSON(inventoryFile, null);
          const userInv = inv?.users?.[currentUsername];
          if (userInv?.supporterBlessing && typeof userInv.supporterBlessing === 'object') {
            supporterBlessing = { ...userInv.supporterBlessing };
          }
        }
      } catch {}
    }

    // Actualizar días transcurridos primero si ya había una bendición activa
    if (supporterBlessing && supporterBlessing.active) {
      updateBlessingState();
    }

    const existingDays = (supporterBlessing && supporterBlessing.active && supporterBlessing.daysRemaining > 0)
      ? supporterBlessing.daysRemaining
      : 0;

    // PRESERVAR lastClaimCycle: Si el usuario ya reclamó en el ciclo de hoy, mantenerlo intacto para NO permitir volver a reclamar hoy
    const existingLastClaimCycle = supporterBlessing ? supporterBlessing.lastClaimCycle : null;

    supporterBlessing = {
      active: true,
      daysRemaining: existingDays + 30,
      totalDays: (supporterBlessing?.totalDays || 0) + 30,
      dailyAmount: 30,
      activatedAt: supporterBlessing?.activatedAt || new Date().toISOString(),
      activatedCycle: supporterBlessing?.activatedCycle || currentCycle,
      lastUpdatedCycle: currentCycle,
      lastClaimCycle: existingLastClaimCycle
    };

    saveUserSupporterBlessing(currentUsername, supporterBlessing);
    lastSyncHash = null;

    rewardsSummary.push(`Bendición del Supporter (+30 días. Total acumulado: ${supporterBlessing.daysRemaining} días)`);
  } else if (rewards.kvr && rewards.kvr > 0) {
    wallet.kvr = (wallet.kvr || 0) + rewards.kvr;
    rewardsSummary.push(`${rewards.kvr} KvR`);
  }
  
  // Añadir sobres
  if (Array.isArray(rewards.packs)) {
    for (const packReward of rewards.packs) {
      const packId = packReward.packId;
      const quantity = packReward.quantity || 1;
      const current = ownedPacks.get(packId) || 0;
      ownedPacks.set(packId, current + quantity);
      rewardsSummary.push(`${quantity}x Sobre`);
    }
  }
  
  // Añadir cartas
  if (Array.isArray(rewards.cards)) {
    let totalCards = 0;
    for (const cardReward of rewards.cards) {
      const cardId = cardReward.cardId;
      const quantity = cardReward.quantity || 1;
      const current = ownedCards.get(cardId) || 0;
      ownedCards.set(cardId, current + quantity);
      totalCards += quantity;
      rewardsSummary.push(`${quantity}x Carta`);
    }
    if (totalCards > 0) {
      incrementCardsObtained(totalCards); // Incrementar contador histórico
    }
  }
  
  // Marcar como canjeado en la cuenta del usuario
  redeemedCodes.add(codeUpper);

  // Guardar inmediatamente en archivo dedicado permanente del usuario
  const currentUsername = (profile.username || '').trim();
  if (currentUsername) {
    saveUserRedeemedCodes(currentUsername);
  }

  // Si era de único uso, registrar en el servidor remoto y en local
  if (isSingleUse) {
    const currentUser = currentUsername || 'usuario';
    // 1. Servidor remoto
    if (remoteConfig.inventory && remoteConfig.inventory.enabled && remoteConfig.inventory.baseUrl) {
      try {
        const base = ensureSlash(remoteConfig.inventory.baseUrl);
        const claimUrl = new URL('api/codes/claim', base).toString();
        await httpPostJson(claimUrl, { code: codeUpper, username: currentUser }).catch(() => {});
      } catch (e) {}
    }
    // 2. Guardar en local
    try {
      const { dataDir } = getDataPaths();
      const usedCodesFile = path.join(dataDir, 'used_single_codes.json');
      let localUsed = {};
      if (fs.existsSync(usedCodesFile)) {
        try { localUsed = JSON.parse(fs.readFileSync(usedCodesFile, 'utf-8')); } catch {}
      }
      localUsed[codeUpper] = { user: currentUser, date: new Date().toISOString() };
      writeJSONAtomic(usedCodesFile, localUsed);
    } catch (e) {}
  }
  
  // Guardar inventario local
  try {
    saveInventory();
  } catch (e) {
    console.error('Error guardando inventario después de canjear código:', e);
    return { error: 'Error al guardar recompensas' };
  }

  // Sincronizar de inmediato con el servidor remoto (en segundo plano)
  try {
    syncInventoryRemote().catch(() => {});
  } catch {}

  // Preparar array estructurado para el HUD unificado de recompensas
  const structuredRewards = [];
  if (rewards.coins && rewards.coins > 0) {
    structuredRewards.push({ type: 'coins', amount: rewards.coins });
  }
  if (!isBlessing && rewards.kvr && rewards.kvr > 0) {
    structuredRewards.push({ type: 'kvr', amount: rewards.kvr });
  }
  const traitsStructured = Number(rewards.traits || rewards.trait || 0);
  if (traitsStructured > 0) {
    structuredRewards.push({ type: 'traits', amount: traitsStructured, quantity: traitsStructured });
  }
  if (Array.isArray(rewards.packs)) {
    for (const p of rewards.packs) {
      structuredRewards.push({ type: 'pack', packId: p.packId, amount: p.quantity || 1, quantity: p.quantity || 1 });
    }
  }
  if (Array.isArray(rewards.cards)) {
    for (const c of rewards.cards) {
      structuredRewards.push({ type: 'card', cardId: c.cardId, amount: c.quantity || 1, quantity: c.quantity || 1 });
    }
  }

  const blessingInfo = updateBlessingState();

  return {
    ok: true,
    code: codeUpper,
    description: codeEntry.description || 'Código canjeado con éxito',
    rewards: rewardsSummary,
    structuredRewards,
    newWallet: { ...wallet },
    isBlessing,
    instantKvr,
    daysRemaining: supporterBlessing?.daysRemaining || 0,
    canClaimToday: blessingInfo.canClaimToday,
    blessingState: blessingInfo
  };
});

ipcMain.handle('codes:getRedeemed', async () => {
  // Asegurar que se carguen todos los códigos del usuario actual
  const currentUser = (profile.username || '').trim();
  if (currentUser) {
    loadUserRedeemedCodes(currentUser);
    try {
      const { inventoryFile } = getDataPaths();
      if (fs.existsSync(inventoryFile)) {
        const inv = readJSON(inventoryFile, null);
        const userInv = inv?.users?.[currentUser];
        if (userInv && Array.isArray(userInv.redeemedCodes)) {
          userInv.redeemedCodes.forEach(code => redeemedCodes.add(String(code).toUpperCase()));
        }
      }
    } catch {}
  }

  const redeemedList = Array.from(redeemedCodes);
  
  // Cargar códigos para obtener descripciones
  let codesData = null;
  try {
    if (remoteConfig.enabled && remoteConfig.baseUrl) {
      const url = new URL('codes.json', ensureSlash(remoteConfig.baseUrl)).toString() + `?t=${Date.now()}`;
      codesData = await httpGetJson(url).catch(() => null);
    }
    
    if (!codesData) {
      const exeDir = path.dirname(process.execPath);
      const overrideCodes = path.join(exeDir, 'game-data', 'codes.json');
      if (fs.existsSync(overrideCodes)) {
        codesData = JSON.parse(fs.readFileSync(overrideCodes, 'utf-8'));
      }
    }
    
    if (!codesData) {
      const seedPath = path.join(__dirname, '..', 'seeds', 'codes.json');
      if (fs.existsSync(seedPath)) {
        codesData = JSON.parse(fs.readFileSync(seedPath, 'utf-8'));
      }
    }
  } catch (e) {
    console.error('[CODES] Error cargando datos para getRedeemed:', e);
  }
  
  // Enriquecer con descripciones
  const enrichedCodes = redeemedList.map(code => {
    if (codesData && Array.isArray(codesData.codes)) {
      const codeEntry = codesData.codes.find(c => c.code === code);
      if (codeEntry) {
        return {
          code: code,
          description: codeEntry.description || 'Sin descripción',
          rewards: codeEntry.rewards
        };
      }
    }
    return {
      code: code,
      description: 'Sin descripción',
      rewards: null
    };
  });
  
  return { ok: true, codes: enrichedCodes };
});

// ========== MÚSICA DE FONDO ==========
ipcMain.handle('music:getAvailableTracks', () => {
  try {
    const musicDir = path.join(__dirname, '..', 'public', 'music');
    
    console.log('[MUSIC BACKEND] Buscando en:', musicDir);
    console.log('[MUSIC BACKEND] __dirname:', __dirname);
    
    if (!fs.existsSync(musicDir)) {
      console.log('[MUSIC BACKEND] Carpeta no existe, creándola...');
      fs.mkdirSync(musicDir, { recursive: true });
      return { ok: true, tracks: [] };
    }
    
    const files = fs.readdirSync(musicDir);
    console.log('[MUSIC BACKEND] Archivos encontrados:', files);
    
    const audioExtensions = ['.mp3', '.ogg', '.wav', '.m4a'];
    
    const tracks = files
      .filter(file => {
        const ext = path.extname(file).toLowerCase();
        const isAudio = audioExtensions.includes(ext);
        console.log('[MUSIC BACKEND]', file, '-> extensión:', ext, '-> es audio:', isAudio);
        return isAudio;
      })
      .map(file => {
        const name = path.basename(file, path.extname(file));
        const track = {
          id: file,
          name: name.charAt(0).toUpperCase() + name.slice(1).replace(/_/g, ' '),
          filename: file,
          path: `music/${file}`
        };
        console.log('[MUSIC BACKEND] Track creado:', track);
        return track;
      });
    
    console.log('[MUSIC BACKEND] Total tracks:', tracks.length);
    return { ok: true, tracks };
  } catch (e) {
    console.error('[MUSIC BACKEND] Error scanning music folder:', e);
    return { ok: false, error: e.message, tracks: [] };
  }
});

// Guardar archivo de música subido por el usuario
ipcMain.handle('music:uploadTrack', async (event, { filename, buffer }) => {
  try {
    const musicDir = path.join(__dirname, '..', 'public', 'music');
    
    // Crear carpeta si no existe
    if (!fs.existsSync(musicDir)) {
      fs.mkdirSync(musicDir, { recursive: true });
    }
    
    // Generar nombre único si ya existe
    let finalFilename = filename;
    let counter = 1;
    const ext = path.extname(filename);
    const basename = path.basename(filename, ext);
    
    while (fs.existsSync(path.join(musicDir, finalFilename))) {
      finalFilename = `${basename}_${counter}${ext}`;
      counter++;
    }
    
    const filePath = path.join(musicDir, finalFilename);
    
    // Guardar archivo
    fs.writeFileSync(filePath, Buffer.from(buffer));
    
    console.log('[MUSIC BACKEND] Archivo guardado:', finalFilename);
    
    return { 
      ok: true, 
      filename: finalFilename,
      path: `music/${finalFilename}`
    };
  } catch (e) {
    console.error('[MUSIC BACKEND] Error guardando archivo:', e);
    return { ok: false, error: e.message };
  }
});

// Eliminar archivo de música
ipcMain.handle('music:deleteTrack', async (event, filename) => {
  try {
    const musicDir = path.join(__dirname, '..', 'public', 'music');
    
    // Canciones por defecto que no se pueden eliminar
    const defaultSongs = ['kvrcardsmenu1.mp3', 'kvrcardsmenualternative.mp3'];
    
    if (defaultSongs.some(def => def.toLowerCase() === filename.toLowerCase())) {
      console.log('[MUSIC BACKEND] Intento de eliminar canción por defecto:', filename);
      return { ok: false, error: 'No se pueden eliminar las canciones por defecto' };
    }
    
    const filePath = path.join(musicDir, filename);
    
    // Verificar que el archivo existe
    if (!fs.existsSync(filePath)) {
      return { ok: false, error: 'El archivo no existe' };
    }
    
    // Eliminar archivo
    fs.unlinkSync(filePath);
    
    console.log('[MUSIC BACKEND] Archivo eliminado:', filename);
    
    return { ok: true };
  } catch (e) {
    console.error('[MUSIC BACKEND] Error eliminando archivo:', e);
    return { ok: false, error: e.message };
  }
});

// ===========================
// CLOUD SYNC & AUTH HANDLERS
// ===========================

// Registrar usuario en el servidor remoto oficial
ipcMain.handle('cloud:register', async (event, username, password) => {
  const uname = String(username || '').trim();
  const pwd = String(password || '').trim();
  console.log('[AUTH IPC] Register request for:', uname);
  
  if (!uname || !pwd) {
    return { ok: false, error: 'Usuario y contrasena requeridos' };
  }
  
  const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory?.baseUrl || 'https://kvrcards-server.onrender.com');
  const url = new URL('api/auth/register', urlBase).toString();
  
  try {
    const res = await httpPostJson(url, { username: uname, password: pwd });
    if (res && res.ok) {
      profile.username = uname;
      profile.password = pwd;
      try { saveProfile(); } catch {}
      console.log('[AUTH IPC] Usuario registrado exitosamente en remoto:', uname);
      return { ok: true, username: uname };
    }
    return { ok: false, error: res?.error || 'Error al registrar usuario en el servidor' };
  } catch (e) {
    console.error('[AUTH IPC] Error registering remotely:', e.message);
    return { ok: false, error: 'No se pudo conectar con el servidor. Verifica tu conexion a internet.' };
  }
});

// Iniciar sesion en el servidor remoto oficial
ipcMain.handle('cloud:login', async (event, username, password) => {
  const uname = String(username || '').trim();
  const pwd = String(password || '').trim();
  console.log('[AUTH IPC] Login request for:', uname);
  
  if (!uname || !pwd) {
    return { ok: false, error: 'Usuario y contrasena requeridos' };
  }
  
  const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory?.baseUrl || 'https://kvrcards-server.onrender.com');
  const url = new URL('api/auth/login', urlBase).toString();
  
  try {
    const res = await httpPostJson(url, { username: uname, password: pwd });
    if (res && res.ok) {
      profile.username = uname;
      profile.password = pwd;

      let wasReset = false;
      const serverResetAt = Number(res.resetAt) || 0;
      const localResetAt = Number(profile.resetAt) || 0;
      if (serverResetAt > 0 && serverResetAt > localResetAt) {
        console.log('[AUTH IPC] La cuenta fue reiniciada en el servidor. Ejecutando reseteo local único para:', uname);
        await resetUserAccountLocally(uname, pwd, serverResetAt);
        wasReset = true;
      } else {
        try { saveProfile(); } catch {}
      }

      console.log('[AUTH IPC] Sesion iniciada correctamente en el servidor para:', uname, 'wasReset:', wasReset);
      return { 
        ok: true, 
        username: uname, 
        lastSync: res.lastSync,
        isAdmin: Boolean(res.isAdmin),
        isReset: Boolean(res.isReset),
        resetAt: serverResetAt,
        wasReset
      };
    }
    if (res && res.error) {
      return { ok: false, error: res.error };
    }
  } catch (e) {
    console.warn('[AUTH IPC] Servidor no disponible, comprobando sesion offline:', e.message);
    const { profileFile, inventoryFile } = getDataPaths();
    const savedProf = readJSON(profileFile, null);
    if (savedProf && savedProf.username === uname && savedProf.password === pwd) {
      console.log('[AUTH IPC] Sesion offline concedida para:', uname);
      profile.username = uname;
      profile.password = pwd;
      return { ok: true, username: uname, offline: true };
    }
    return { ok: false, error: 'No se pudo conectar con el servidor remoto. Comprueba tu conexion.' };
  }
  return { ok: false, error: 'Error desconocido al iniciar sesion' };
});

// Subir respaldo completo de seguridad a la nube (Ajustes)
ipcMain.handle('cloud:upload', async (event, username, password) => {
  const uname = String(username || profile.username || '').trim();
  const pwd = String(password || profile.password || '').trim();
  console.log('[CLOUD IPC] Backup de seguridad solicitado para:', uname);
  
  if (!uname) {
    return { ok: false, error: 'No hay sesion activa' };
  }
  
  try {
    saveInventory();
    
    const powersObj = {};
    ownedPowers.forEach((data, id) => {
      if (data.permanent === true || (data.uses && data.uses > 0)) {
        powersObj[id] = data;
      }
    });

    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory?.baseUrl || 'https://kvrcards-server.onrender.com');
    const url = new URL('api/inventory/' + encodeURIComponent(uname), urlBase).toString();

    let existingFriendsData = { friends: [], friendRequests: [], sentRequests: [] };
    try {
      const existing = await httpGetJson(url + `?t=${Date.now()}`);
      if (existing) {
        existingFriendsData = {
          friends: existing.friends || [],
          friendRequests: existing.friendRequests || [],
          sentRequests: existing.sentRequests || []
        };
      }
    } catch {}

    const payload = {
      username: uname,
      password: pwd || profile.password || '',
      forceReplace: true,
      cards: Object.fromEntries(ownedCards),
      packs: Object.fromEntries(ownedPacks),
      powers: powersObj,
      cardTraits: Object.fromEntries(cardTraits),
      cardUpgrades: Object.fromEntries(cardUpgrades),
      completedDeliverables: [...completedDeliverables],
      deliverableCompletions: { ...deliverableCompletions },
      deliverableDailyCompletions: { ...deliverableDailyCompletions },
      packPurchases: { ...packPurchases },
      redeemedCodes: Array.from(redeemedCodes),
      supporterBlessing: supporterBlessing,
      wallet: { ...wallet },
      stats: { ...userStats },
      weeklyStats: { ...weeklyStats },
      missions: { ...userMissions },
      kizunas: { ...userKizunas },
      settings: {
        ...(userSettings || {}),
        currentBackground: profile.currentBackground || 'default',
        unlockedBackgrounds: Array.isArray(profile.unlockedBackgrounds) ? profile.unlockedBackgrounds : ['default']
      },
      profileImage: profile.profileImage || '',
      currentTitle: profile.currentTitle || 'novato',
      unlockedTitles: Array.isArray(profile.unlockedTitles) ? profile.unlockedTitles : ['novato'],
      currentBackground: profile.currentBackground || 'default',
      unlockedBackgrounds: Array.isArray(profile.unlockedBackgrounds) ? profile.unlockedBackgrounds : ['default'],
      showcaseCards: profile.showcaseCards || [null, null, null],
      friends: existingFriendsData.friends,
      friendRequests: existingFriendsData.friendRequests,
      sentRequests: existingFriendsData.sentRequests,
      updatedAt: Date.now()
    };

    console.log('[CLOUD IPC] Enviando snapshot completo a R2 para:', uname);
    const res = await httpPostJson(url, payload);
    if (res && res.ok !== false && !res.error) {
      lastSyncHash = generateSyncHash();
      console.log('[CLOUD IPC] Snapshot guardado exitosamente en R2 para:', uname);
      return { ok: true, message: 'Inventario guardado en la nube correctamente', lastSync: payload.updatedAt };
    }
    return { ok: false, error: res?.error || 'Error al guardar en el servidor' };
  } catch (e) {
    console.error('[CLOUD IPC] Error subiendo snapshot a la nube:', e);
    return { ok: false, error: e.message };
  }
});

// Descargar datos de la nube
ipcMain.handle('cloud:download', async (event, username, password) => {
  const uname = String(username || profile.username || '').trim();
  console.log('[CLOUD IPC] Descargando snapshot de la nube para:', uname);
  if (!uname) return { ok: false, error: 'No hay usuario activo' };
  try {
    const data = await fetchInventoryRemote(uname);
    if (!data) return { ok: false, error: 'No se encontraron datos en la nube para este usuario' };
    return { ok: true, data };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// Aplicar datos descargados localmente
ipcMain.handle('cloud:applyData', async (event, cloudData) => {
  console.log('[CLOUD IPC] Aplicando datos de la nube localmente');
  
  try {
    const { inventoryFile } = getDataPaths();
    
    if (!cloudData || !cloudData.inventory) {
      return { ok: false, error: 'Datos invalidos' };
    }
    
    // Hacer backup del inventario actual
    const backupPath = inventoryFile + `.backup.${Date.now()}`;
    if (fs.existsSync(inventoryFile)) {
      try {
        fs.copyFileSync(inventoryFile, backupPath);
        console.log('[CLOUD IPC] Backup de seguridad creado:', backupPath);
      } catch {}
    }
    
    const inv = cloudData.inventory;
    
    inTransaction = true;
    try {
      applyInventoryData(inv);
      lastSyncHash = null;
      logCriticalEvent('sync', `Cloud data applied successfully. Balance: ${wallet.coins} coins.`);
      inTransaction = false;
      saveInventory();
    } catch (innerErr) {
      inTransaction = false;
      throw innerErr;
    }
    
    console.log('[CLOUD IPC] Datos de la nube aplicados correctamente');
    return { ok: true, message: 'Datos aplicados correctamente' };
  } catch (e) {
    console.error('[CLOUD IPC] Error aplicando datos de la nube:', e);
    return { ok: false, error: e.message };
  }
});

// Limpiar caché local
ipcMain.handle('system:clearCache', async () => {
  console.log('[SYSTEM] Clearing cache');
  
  try {
    const { cacheDir } = getDataPaths();
    const fs = require('fs');
    
    if (fs.existsSync(cacheDir)) {
      const files = fs.readdirSync(cacheDir);
      for (const file of files) {
        const filePath = path.join(cacheDir, file);
        try {
          fs.unlinkSync(filePath);
        } catch (e) {
          console.error('[SYSTEM] Error deleting file:', file, e);
        }
      }
    }
    
    console.log('[SYSTEM] Cache cleared successfully');
    return { ok: true, message: 'Caché limpiada correctamente' };
  } catch (e) {
    console.error('[SYSTEM] Error clearing cache:', e);
    return { ok: false, error: e.message };
  }
});

// Abrir carpeta de datos
ipcMain.handle('system:openDataFolder', async () => {
  console.log('[SYSTEM] Opening data folder');
  
  try {
    const { dataDir } = getDataPaths();
    const fs = require('fs');
    
    // Crear directorio si no existe
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    shell.openPath(dataDir);
    
    return { ok: true };
  } catch (e) {
    console.error('[SYSTEM] Error opening folder:', e);
    return { ok: false, error: e.message };
  }
});

// ---- Friends System IPC Handlers ----

// Send friend request
ipcMain.handle('friends:sendRequest', async (event, targetUsername) => {
  console.log('[FRIENDS] Sending friend request to:', targetUsername);
  
  try {
    const currentUsername = profile.username;
    if (!currentUsername) {
      return { ok: false, error: 'No estás logueado' };
    }
    
    if (!remoteConfig.inventory?.enabled || !inventoryEffectiveBaseUrl) {
      return { ok: false, error: 'Sistema de amigos no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/friends/request', urlBase).toString();
    
    const res = await httpPostJson(url, { from: currentUsername, to: targetUsername });
    console.log('[FRIENDS] Request sent:', res);
    
    return res || { ok: true };
  } catch (e) {
    console.error('[FRIENDS] Error sending request:', e);
    return { ok: false, error: String(e) };
  }
});

// Accept friend request
ipcMain.handle('friends:acceptRequest', async (event, friendUsername) => {
  console.log('[FRIENDS] Accepting request from:', friendUsername);
  
  try {
    const currentUsername = profile.username;
    if (!currentUsername) {
      return { ok: false, error: 'No estás logueado' };
    }
    
    if (!remoteConfig.inventory?.enabled || !inventoryEffectiveBaseUrl) {
      return { ok: false, error: 'Sistema de amigos no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/friends/accept', urlBase).toString();
    
    const res = await httpPostJson(url, { username: currentUsername, friendUsername });
    console.log('[FRIENDS] Request accepted:', res);
    
    return res || { ok: true };
  } catch (e) {
    console.error('[FRIENDS] Error accepting request:', e);
    return { ok: false, error: String(e) };
  }
});

// Reject friend request
ipcMain.handle('friends:rejectRequest', async (event, friendUsername) => {
  console.log('[FRIENDS] Rejecting request from:', friendUsername);
  
  try {
    const currentUsername = profile.username;
    if (!currentUsername) {
      return { ok: false, error: 'No estás logueado' };
    }
    
    if (!remoteConfig.inventory?.enabled || !inventoryEffectiveBaseUrl) {
      return { ok: false, error: 'Sistema de amigos no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/friends/reject', urlBase).toString();
    
    const res = await httpPostJson(url, { username: currentUsername, friendUsername });
    console.log('[FRIENDS] Request rejected:', res);
    
    return res || { ok: true };
  } catch (e) {
    console.error('[FRIENDS] Error rejecting request:', e);
    return { ok: false, error: String(e) };
  }
});

// Remove friend
ipcMain.handle('friends:removeFriend', async (event, friendUsername) => {
  console.log('[FRIENDS] Removing friend:', friendUsername);
  
  try {
    const currentUsername = profile.username;
    if (!currentUsername) {
      return { ok: false, error: 'No estás logueado' };
    }
    
    if (!remoteConfig.inventory?.enabled || !inventoryEffectiveBaseUrl) {
      return { ok: false, error: 'Sistema de amigos no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/friends/remove', urlBase).toString();
    
    const res = await httpPostJson(url, { username: currentUsername, friendUsername });
    console.log('[FRIENDS] Friend removed:', res);
    
    return res || { ok: true };
  } catch (e) {
    console.error('[FRIENDS] Error removing friend:', e);
    return { ok: false, error: String(e) };
  }
});

// Get friends list
ipcMain.handle('friends:getFriendsList', async () => {
  console.log('[FRIENDS] Getting friends list');
  
  try {
    const currentUsername = profile.username;
    if (!currentUsername) {
      return { ok: false, error: 'No estás logueado', friends: [] };
    }
    
    if (!remoteConfig.inventory?.enabled || !inventoryEffectiveBaseUrl) {
      return { ok: false, error: 'Sistema de amigos no disponible (servidor offline)', friends: [] };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL(`api/friends/list/${encodeURIComponent(currentUsername)}`, urlBase).toString();
    
    const res = await httpGetJson(url);
    console.log('[FRIENDS] Friends list retrieved:', res);
    
    return res || { ok: true, friends: [] };
  } catch (e) {
    console.error('[FRIENDS] Error getting friends list:', e);
    return { ok: false, error: String(e), friends: [] };
  }
});

// Get friend requests
ipcMain.handle('friends:getRequests', async () => {
  console.log('[FRIENDS] Getting friend requests');
  
  try {
    const currentUsername = profile.username;
    if (!currentUsername) {
      return { ok: false, error: 'No estás logueado', requests: [] };
    }
    
    if (!remoteConfig.inventory?.enabled || !inventoryEffectiveBaseUrl) {
      return { ok: false, error: 'Sistema de amigos no disponible (servidor offline)', requests: [] };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL(`api/friends/requests/${encodeURIComponent(currentUsername)}`, urlBase).toString();
    
    const res = await httpGetJson(url);
    console.log('[FRIENDS] Requests retrieved:', res);
    
    return res || { ok: true, requests: [] };
  } catch (e) {
    console.error('[FRIENDS] Error getting requests:', e);
    return { ok: false, error: String(e), requests: [] };
  }
});

// Search users
ipcMain.handle('friends:searchUsers', async (event, query) => {
  console.log('[FRIENDS] Searching users:', query);
  
  try {
    const currentUsername = profile.username;
    if (!currentUsername) {
      return { ok: false, error: 'No estás logueado', users: [] };
    }
    
    if (!remoteConfig.inventory?.enabled || !inventoryEffectiveBaseUrl) {
      return { ok: false, error: 'Sistema de amigos no disponible (servidor offline)', users: [] };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/friends/search', urlBase).toString();
    const urlWithParams = `${url}?q=${encodeURIComponent(query || '')}&user=${encodeURIComponent(currentUsername)}`;
    
    const res = await httpGetJson(urlWithParams);
    console.log('[FRIENDS] Search results:', res);
    
    return res || { ok: true, users: [] };
  } catch (e) {
    console.error('[FRIENDS] Error searching users:', e);
    return { ok: false, error: String(e), users: [] };
  }
});

// ---- Trades IPC Handlers ----
let currentActiveTradeIdForSession = null;

app.on('before-quit', () => {
  if (currentActiveTradeIdForSession) {
    try {
      const currentUsername = profile.username?.trim();
      if (currentUsername) {
        const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory?.baseUrl || '');
        const url = new URL('api/trades/cancel', urlBase).toString();
        httpPostJson(url, { tradeId: currentActiveTradeIdForSession, username: currentUsername }).catch(() => {});
      }
      currentActiveTradeIdForSession = null;
    } catch {}
  }
});

ipcMain.handle('trades:sendRequest', async (event, targetUsername) => {
  try {
    const currentUsername = profile.username?.trim();
    if (!currentUsername) {
      return { ok: false, error: 'No username set' };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/trades/request', urlBase).toString();
    
    const res = await httpPostJson(url, { from: currentUsername, to: targetUsername });
    console.log('[TRADES] Request sent:', res);
    
    if (res && res.tradeId) {
      currentActiveTradeIdForSession = res.tradeId;
    }
    
    return res || { ok: true };
  } catch (e) {
    console.error('[TRADES] Error sending trade request:', e);
    return { ok: false, error: String(e) };
  }
});

ipcMain.handle('trades:joinRandomQueue', async () => {
  try {
    const currentUsername = profile.username?.trim();
    if (!currentUsername) {
      return { ok: false, error: 'No username set' };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/trades/random/queue', urlBase).toString();
    
    const res = await httpPostJson(url, { username: currentUsername });
    console.log('[TRADES] Joined queue:', res);
    
    return res || { ok: true };
  } catch (e) {
    console.error('[TRADES] Error joining queue:', e);
    return { ok: false, error: String(e) };
  }
});

ipcMain.handle('trades:checkRandomMatch', async () => {
  try {
    const currentUsername = profile.username?.trim();
    if (!currentUsername) {
      return { ok: false, error: 'No username set' };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL(`api/trades/random/match/${encodeURIComponent(currentUsername)}`, urlBase).toString();
    
    const res = await httpGetJson(url);
    if (res && res.matched && res.tradeId) {
      currentActiveTradeIdForSession = res.tradeId;
    }
    return res || { ok: true, matched: false };
  } catch (e) {
    console.error('[TRADES] Error checking match:', e);
    return { ok: false, error: String(e) };
  }
});

ipcMain.handle('trades:acceptTrade', async (event, tradeId) => {
  try {
    const currentUsername = profile.username?.trim();
    if (!currentUsername) {
      return { ok: false, error: 'No username set' };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)' };
    }
    
    currentActiveTradeIdForSession = tradeId;
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/trades/accept', urlBase).toString();
    
    const res = await httpPostJson(url, { tradeId, username: currentUsername });
    console.log('[TRADES] Trade accepted:', res);
    
    return res || { ok: true };
  } catch (e) {
    console.error('[TRADES] Error accepting trade:', e);
    return { ok: false, error: String(e) };
  }
});

ipcMain.handle('trades:rejectTrade', async (event, tradeId) => {
  try {
    const currentUsername = profile.username?.trim();
    if (!currentUsername) {
      return { ok: false, error: 'No username set' };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/trades/reject', urlBase).toString();
    
    const res = await httpPostJson(url, { tradeId, username: currentUsername });
    console.log('[TRADES] Trade rejected:', res);
    
    return res || { ok: true };
  } catch (e) {
    console.error('[TRADES] Error rejecting trade:', e);
    return { ok: false, error: String(e) };
  }
});

ipcMain.handle('trades:updateOffer', async (event, tradeId, cards, packs, coins, traits, cardTraits) => {
  try {
    const currentUsername = profile.username?.trim();
    console.log('[TRADES IPC] updateOffer called with username:', currentUsername);
    console.log('[TRADES IPC] tradeId:', tradeId);
    console.log('[TRADES IPC] cards:', cards);
    console.log('[TRADES IPC] packs:', packs);
    console.log('[TRADES IPC] coins:', coins);
    console.log('[TRADES IPC] traits:', traits);
    console.log('[TRADES IPC] cardTraits:', cardTraits);
    
    if (!currentUsername) {
      return { ok: false, error: 'No username set' };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/trades/offer', urlBase).toString();
    
    const payload = { tradeId, username: currentUsername, cards, packs, coins, traits, cardTraits };
    console.log('[TRADES IPC] Sending to server:', JSON.stringify(payload));
    
    const res = await httpPostJson(url, payload);
    console.log('[TRADES IPC] Server response:', res);
    
    return res || { ok: true };
  } catch (e) {
    console.error('[TRADES] Error updating offer:', e);
    return { ok: false, error: String(e) };
  }
});

ipcMain.handle('trades:confirmTrade', async (event, tradeId) => {
  try {
    const currentUsername = profile.username?.trim();
    if (!currentUsername) {
      return { ok: false, error: 'No username set' };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/trades/confirm', urlBase).toString();
    
    const res = await httpPostJson(url, { tradeId, username: currentUsername });
    console.log('[TRADES] Trade confirmed:', res);
    
    // Si el trade se completó, forzar sincronización para actualizar inventario
    if (res && res.trade && res.trade.status === 'completed') {
      currentActiveTradeIdForSession = null;
      console.log('[TRADES] Trade completed, reloading inventory...');
      const fetchedInv = await fetchInventoryRemote(currentUsername);
      if (fetchedInv) {
        try {
          validateIncomingInventory(fetchedInv, 'tradeConfirm');
          applyInventoryData(fetchedInv);
          saveInventory();
          lastSyncHash = null; // Resetear hash después de trade
          logCriticalEvent('sync', `Inventory updated after trade confirm. New balance: ${wallet.coins} coins.`);
        } catch (validationError) {
          console.error('[TRADES] Validation failed on trade confirm inventory load:', validationError.message);
          logCriticalEvent('error', `Trade confirm inventory reload blocked! Validation error: ${validationError.message}`);
        }
      }
    }
    
    return res || { ok: true };
  } catch (e) {
    console.error('[TRADES] Error confirming trade:', e);
    return { ok: false, error: String(e) };
  }
});

ipcMain.handle('trades:cancelConfirm', async (event, tradeId) => {
  try {
    const currentUsername = profile.username?.trim();
    if (!currentUsername) {
      return { ok: false, error: 'No username set' };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/trades/cancel-confirm', urlBase).toString();
    
    const res = await httpPostJson(url, { tradeId, username: currentUsername });
    console.log('[TRADES] Confirmation canceled:', res);
    
    return res || { ok: true };
  } catch (e) {
    console.error('[TRADES] Error canceling confirmation:', e);
    return { ok: false, error: String(e) };
  }
});

ipcMain.handle('trades:cancelTrade', async (event, tradeId) => {
  try {
    currentActiveTradeIdForSession = null;
    const currentUsername = profile.username?.trim();
    if (!currentUsername) {
      return { ok: false, error: 'No username set' };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/trades/cancel', urlBase).toString();
    
    const res = await httpPostJson(url, { tradeId, username: currentUsername });
    console.log('[TRADES] Trade cancelled:', res);
    
    return res || { ok: true };
  } catch (e) {
    console.error('[TRADES] Error cancelling trade:', e);
    return { ok: false, error: String(e) };
  }
});

ipcMain.handle('trades:getStatus', async (event, tradeId) => {
  try {
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)' };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL(`api/trades/status/${encodeURIComponent(tradeId)}`, urlBase).toString();
    
    const res = await httpGetJson(url);
    return res || { ok: true };
  } catch (e) {
    console.error('[TRADES] Error getting status:', e);
    return { ok: false, error: String(e) };
  }
});

ipcMain.handle('trades:getPending', async () => {
  try {
    const currentUsername = profile.username?.trim();
    if (!currentUsername) {
      return { ok: false, error: 'No username set', pending: [] };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)', pending: [] };
    }
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL(`api/trades/pending/${encodeURIComponent(currentUsername)}`, urlBase).toString();
    
    const res = await httpGetJson(url);
    return res || { ok: true, pending: [] };
  } catch (e) {
    console.error('[TRADES] Error getting pending trades:', e);
    return { ok: false, error: String(e), pending: [] };
  }
});

// Accept trade request
ipcMain.handle('trades:acceptRequest', async (event, tradeId) => {
  try {
    const currentUsername = profile.username?.trim();
    if (!currentUsername) {
      return { ok: false, error: 'No username set' };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)' };
    }
    
    console.log('[TRADES] Accepting request:', tradeId);
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/trades/accept', urlBase).toString();
    
    const res = await httpPostJson(url, { tradeId, username: currentUsername });
    return res || { ok: true };
  } catch (e) {
    console.error('[TRADES] Error accepting request:', e);
    return { ok: false, error: String(e) };
  }
});

// Reject trade request
ipcMain.handle('trades:rejectRequest', async (event, tradeId) => {
  try {
    const currentUsername = profile.username?.trim();
    if (!currentUsername) {
      return { ok: false, error: 'No username set' };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de trades no disponible (servidor offline)' };
    }
    
    console.log('[TRADES] Rejecting request:', tradeId);
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL('api/trades/reject', urlBase).toString();
    
    const res = await httpPostJson(url, { tradeId, username: currentUsername });
    return res || { ok: true };
  } catch (e) {
    console.error('[TRADES] Error rejecting request:', e);
    return { ok: false, error: String(e) };
  }
});

// Recargar inventario desde el servidor (después de trade)
ipcMain.handle('inventory:reloadFromServer', async () => {
  try {
    const currentUsername = profile.username?.trim();
    if (!currentUsername) {
      return { ok: false, error: 'No username set' };
    }
    
    if (!remoteConfig.inventory?.enabled) {
      return { ok: false, error: 'Sistema de inventario no disponible (servidor offline)' };
    }
    
    console.log('[INVENTORY] Reloading from server for:', currentUsername);
    
    const urlBase = ensureSlash(inventoryEffectiveBaseUrl || remoteConfig.inventory.baseUrl || '');
    const url = new URL(`api/inventory/${encodeURIComponent(currentUsername)}`, urlBase).toString();
    
    const res = await httpGetJson(url);
    
    if (res && res.username) {
      try {
        validateIncomingInventory(res, 'reloadFromServer');
      } catch (validationError) {
        console.error('[INVENTORY] Validation failed on reload from server:', validationError.message);
        logCriticalEvent('error', `Reload from server blocked! Validation error: ${validationError.message}`);
        return { ok: false, error: validationError.message };
      }
      
      applyInventoryData(res);
      
      // Guardar localmente
      saveInventory();
      
      console.log('[INVENTORY] ✓ Reloaded successfully from server');
      console.log('[INVENTORY] New inventory:', {
        cards: ownedCards.size,
        packs: ownedPacks.size,
        coins: wallet.coins
      });
      
      return { ok: true, message: 'Inventory reloaded from server' };
    }
    
    console.error('[INVENTORY] Invalid response from server:', res);
    return { ok: false, error: 'Failed to reload inventory' };
  } catch (e) {
    console.error('[INVENTORY] Error reloading from server:', e);
    return { ok: false, error: String(e) };
  }
});

async function syncAdminCommands(force = false) {
  const { cacheDir, commandsCache } = getDataPaths();
  fs.mkdirSync(cacheDir, { recursive: true });
  // Fuentes: 1) remoto baseUrl/commands.json 2) override junto al exe game-data/commands.json 3) cache
  let commandsDoc = null;
  const baseOk = remoteConfig.enabled && remoteConfig.baseUrl;
  if (baseOk) {
    const url = new URL('commands.json', ensureSlash(remoteConfig.baseUrl)).toString() + `?t=${Date.now()}`;
    commandsDoc = await httpGetJson(url).catch(() => null);
  }
  if (!commandsDoc) {
    try {
      const exeDir = path.dirname(process.execPath);
      const override = path.join(exeDir, 'game-data', 'commands.json');
      if (fs.existsSync(override)) {
        commandsDoc = JSON.parse(fs.readFileSync(override, 'utf-8'));
      }
    } catch {}
  }
  if (!commandsDoc) {
    try {
      if (fs.existsSync(commandsCache)) {
        commandsDoc = JSON.parse(fs.readFileSync(commandsCache, 'utf-8'));
      }
    } catch {}
  }
  if (!commandsDoc || !Array.isArray(commandsDoc.commands)) {
    return { applied: 0 };
  }
  // Evitar aplicar dos veces: si trae version y coincide con la última aplicada en el perfil, salta
  const docVersion = String(commandsDoc.version || '');
  if (!force && docVersion && profile.lastCommandsVersion && docVersion === profile.lastCommandsVersion) {
    return { applied: 0, skipped: true };
  }
  // Guardar cache
  try { fs.writeFileSync(commandsCache, JSON.stringify(commandsDoc, null, 2)); } catch {}

  // Aplicar comandos dirigidos a nuestro usuario actual
  const uname = (profile.username || '').trim();
  const unameLower = uname.toLowerCase();
  if (!uname) return { applied: 0 };
  
  if (!profile.executedCommands) {
    profile.executedCommands = [];
  }
  
  let applied = 0;
  let skipped = 0;
  console.log(`[SYNC] Procesando ${commandsDoc.commands.length} comandos para usuario: ${uname}`);
  console.log(`[SYNC] Versión del documento: ${docVersion}`);
  console.log(`[SYNC] Última versión aplicada: ${profile.lastCommandsVersion}`);
  console.log(`[SYNC] Comandos ya ejecutados: ${profile.executedCommands.length}`);
  console.log(`[SYNC] Firmas de dinero: ${profile.moneyCommandSignatures?.length || 0}`);
  
  // Debug: mostrar todos los IDs ejecutados para análisis
  if (profile.executedCommands.length > 0) {
    console.log(`[SYNC] Todos los IDs ejecutados:`, profile.executedCommands);
  }
  if (profile.moneyCommandSignatures && profile.moneyCommandSignatures.length > 0) {
    console.log(`[SYNC] Todas las firmas de dinero:`, profile.moneyCommandSignatures);
  }
  
  inTransaction = true;
  try {
    for (let i = 0; i < commandsDoc.commands.length; i++) {
      const cmd = commandsDoc.commands[i];
      if (!cmd) continue;
      
      // Crear un ID único para el comando basado únicamente en el contenido esencial
      // Normalizar valores para crear un ID estable
      const normalizedCmd = {
        username: String(cmd.username || '').toLowerCase().trim(),
        action: String(cmd.action || '').toLowerCase().trim(),
        cardId: cmd.cardId ? String(cmd.cardId).trim() : null,
        cardName: cmd.cardName ? String(cmd.cardName).trim() : null,
        packId: cmd.packId ? String(cmd.packId).trim() : null,
        packName: cmd.packName ? String(cmd.packName).trim() : null,
        count: Number(cmd.count) || Number(cmd.amount) || 1
      };
      
      // Crear un ID único más robusto
      let cmdId;
      
      // Método 1: Si el comando tiene un ID único proporcionado, usarlo
      if (cmd.id) {
        cmdId = `unique-${cmd.id}`;
      } 
      // Método 2: Si tiene timestamp, combinar con contenido básico
      else if (cmd.timestamp || cmd.createdAt) {
        const ts = cmd.timestamp || cmd.createdAt;
        cmdId = `ts-${ts}-${normalizedCmd.action}-${normalizedCmd.username}`;
      }
      // Método 3: Crear hash simple del contenido esencial
      else {
        // Crear un hash simple pero determinista
        const essentialData = `${normalizedCmd.username}|${normalizedCmd.action}|${normalizedCmd.count}`;
        let hash = 0;
        for (let j = 0; j < essentialData.length; j++) {
          const char = essentialData.charCodeAt(j);
          hash = ((hash << 5) - hash) + char;
          hash = hash & hash; // Convert to 32bit integer
        }
        cmdId = `hash-${Math.abs(hash)}-${normalizedCmd.action}`;
      }
      
      console.log(`[SYNC] === Comando ${i} ===`);
      console.log(`[SYNC] ID generado: ${cmdId}`);
      
      // Si ya se ejecutó este comando específico, saltarlo
      if (profile.executedCommands.includes(cmdId)) {
        console.log(`[SYNC] ✅ Comando ya ejecutado, saltando: ${cmdId}`);
        skipped++;
        continue;
      }
      
      console.log(`[SYNC] 🚀 Ejecutando comando: ${cmdId}`);
      
      const target = String((cmd.username || '').trim());
      const tLower = target.toLowerCase();
      const matchesUser = (target && tLower === unameLower) || tLower === '*' || tLower === 'all';
      if (!matchesUser) continue;
      const action = String(cmd.action || '').toLowerCase();
      const count = Math.max(1, Number(cmd.count) || 1);

      if (action === 'add' || action === 'remove') {
        let cardId = cmd.cardId;
        if (!cardId && cmd.cardName) {
          // buscar por nombre exacto (case-sensitive primero, luego insensitive)
          const entries = Array.from(cardStore.values());
          let found = entries.find(c => c.name === cmd.cardName);
          if (!found) found = entries.find(c => (c.name || '').toLowerCase() === String(cmd.cardName).toLowerCase());
          if (found) cardId = found.id;
        }
        if (!cardId) continue;
        if (action === 'add') {
          const cur = ownedCards.get(cardId) || 0;
          ownedCards.set(cardId, cur + count);
          applied++;
          const cardName = cardStore.get(cardId)?.name || cardId;
          logCriticalEvent('add', `Added card: ${cardName} (ID: ${cardId}) x${count}. Reason: Admin commands sync.`);
        } else {
          const cur = ownedCards.get(cardId) || 0;
          const next = Math.max(0, cur - count);
          if (next === 0) ownedCards.delete(cardId); else ownedCards.set(cardId, next);
          applied++;
          const cardName = cardStore.get(cardId)?.name || cardId;
          logCriticalEvent('remove', `Removed card: ${cardName} (ID: ${cardId}) x${count}. Reason: Admin commands sync.`);
        }
        // Marcar comando como ejecutado
        profile.executedCommands.push(cmdId);
        continue;
      }

      if (action === 'addpack' || action === 'removepack') {
        let packId = cmd.packId;
        if (!packId && cmd.packName) {
          const entries = Array.from(packStore.values());
          let found = entries.find(p => p.name === cmd.packName);
          if (!found) found = entries.find(p => (p.name || '').toLowerCase() === String(cmd.packName).toLowerCase());
          if (found) packId = found.id;
        }
        if (!packId) continue;
        if (action === 'addpack') {
          const cur = ownedPacks.get(packId) || 0;
          ownedPacks.set(packId, cur + count);
          applied++;
          const packName = packStore.get(packId)?.name || packId;
          logCriticalEvent('add', `Added pack: ${packName} (ID: ${packId}) x${count}. Reason: Admin commands sync.`);
        } else {
          const cur = ownedPacks.get(packId) || 0;
          const next = Math.max(0, cur - count);
          if (next === 0) ownedPacks.delete(packId); else ownedPacks.set(packId, next);
          applied++;
          const packName = packStore.get(packId)?.name || packId;
          logCriticalEvent('remove', `Removed pack: ${packName} (ID: ${packId}) x${count}. Reason: Admin commands sync.`);
        }
        // Marcar comando como ejecutado
        profile.executedCommands.push(cmdId);
        continue;
      }

      // Monedas
      if (action === 'addcoins' || action === 'removecoins' || action === 'addkvr' || action === 'removekvr') {
        const amt = Math.max(1, Number(cmd.amount ?? cmd.count ?? 1) || 1);
        
        // Protección extra para comandos de dinero: verificar si ya se aplicó la misma cantidad recientemente
        const moneySignature = `${normalizedCmd.username}-${action}-${amt}`;
        if (!profile.moneyCommandSignatures) profile.moneyCommandSignatures = [];
        
        // Si esta combinación exacta se ejecutó recientemente, saltarla (protección anti-spam)
        if (profile.moneyCommandSignatures.includes(moneySignature)) {
          console.log(`[SYNC] Comando de dinero duplicado detectado, saltando: ${moneySignature}`);
          profile.executedCommands.push(cmdId);
          continue;
        }
        
        // Ejecutar el comando de dinero
        if (action === 'addcoins') {
          const oldCoins = wallet.coins || 0;
          wallet.coins = Math.max(0, oldCoins + amt);
          if (amt > 0) incrementCoinsEarned(amt); // Incrementar contador histórico
          logCriticalEvent('add', `Added coins: ${amt}. Reason: Admin commands sync.`);
        }
        if (action === 'removecoins') {
          wallet.coins = Math.max(0, (wallet.coins || 0) - amt);
          logCriticalEvent('remove', `Removed coins: ${amt}. Reason: Admin commands sync.`);
        }
        if (action === 'addkvr') {
          wallet.kvr = Math.max(0, (wallet.kvr || 0) + amt);
          logCriticalEvent('add', `Added kvr: ${amt}. Reason: Admin commands sync.`);
        }
        if (action === 'removekvr') {
          wallet.kvr = Math.max(0, (wallet.kvr || 0) - amt);
          logCriticalEvent('remove', `Removed kvr: ${amt}. Reason: Admin commands sync.`);
        }
        
        applied++;
        // Marcar comando como ejecutado
        profile.executedCommands.push(cmdId);
        // Añadir a firmas de dinero (mantener solo las últimas 50)
        profile.moneyCommandSignatures.push(moneySignature);
        if (profile.moneyCommandSignatures.length > 50) {
          profile.moneyCommandSignatures = profile.moneyCommandSignatures.slice(-50);
        }
        continue;
      }
    }
    
    inTransaction = false;
    if (applied > 0) {
      saveInventory();
      // Guardar el perfil actualizado con los comandos ejecutados
      try { saveProfile(); } catch {}
    }
    // Marcar versión como aplicada solo si hubo cambios
    if (docVersion && applied > 0) {
      profile.lastCommandsVersion = docVersion;
      try { saveProfile(); } catch {}
    }
  } catch (err) {
    console.error('[SYNC] Error executing admin commands:', err);
  } finally {
    inTransaction = false;
  }
  
  // Limpiar array de comandos ejecutados si está muy grande (mantener solo los últimos 1000)
  if (profile.executedCommands && profile.executedCommands.length > 1000) {
    profile.executedCommands = profile.executedCommands.slice(-1000);
    try { saveProfile(); } catch {}
  }
  
  console.log(`[SYNC] Resultado: ${applied} aplicados, ${skipped} saltados`);
  return { applied, skipped, version: docVersion };
}

function ensureInventorySyncTimer() {
  if (invSyncTimer) { try { clearInterval(invSyncTimer); } catch {} invSyncTimer = null; }
  if (!remoteConfig.inventory?.enabled) return;
  const uname = (profile.username || '').trim();
  if (!uname) return;
  
  console.log('[SYNC] Starting auto-sync timer (every 60 seconds)');
  
  // Sincronizar inmediatamente
  syncInventoryRemote().catch(() => {});
  
  // Luego cada 60 segundos
  invSyncTimer = setInterval(() => {
    console.log('[SYNC] Auto-syncing inventory...');
    syncInventoryRemote().catch(() => {});
  }, 60 * 1000);
}

// Si el baseUrl del inventario apunta a localhost y no hay servidor escuchando, lo arrancamos automáticamente
async function ensureLocalInventoryServer() {
  try {
    if (!remoteConfig.inventory?.enabled || !remoteConfig.inventory.baseUrl) return;
    const base = ensureSlash(remoteConfig.inventory.baseUrl);
    const u = new URL(base);
    const host = (u.hostname || '').toLowerCase();
    // Caso 1: remoto (no localhost). Si está sano, usarlo. Si no, caer a local auto.
    if (host !== 'localhost' && host !== '127.0.0.1') {
      try {
        const healthUrl = new URL('api/health', base).toString();
        await httpGetJsonWithTimeout(healthUrl, 2000);
        inventoryEffectiveBaseUrl = base; // usar remoto
        return;
      } catch {}
      // remoto no disponible: arrancar local en 4321 o 5005 como fallback
  // Siempre usar http para el servidor local (nuestro Express no expone https)
  const localBasePrimary = `http://localhost:4321/`;
  const localBaseAlt = `http://localhost:5005/`;
      // intentar primario
      try {
        const serverPath = path.join(__dirname, '..', 'server', 'inventory-server.js');
        const node = process.execPath;
        const env = { ...process.env, PORT: String(4321), CATALOG_BASE_URL: String(remoteConfig.baseUrl || ''), ELECTRON_RUN_AS_NODE: '1' };
        const child = childProcess.spawn(node, [serverPath], { cwd: path.join(__dirname, '..'), env, stdio: 'ignore', windowsHide: true, detached: true });
        child.unref();
        await new Promise(r => setTimeout(r, 900));
        const healthUrl = new URL('api/health', localBasePrimary).toString();
        await httpGetJsonWithTimeout(healthUrl, 2000);
        inventoryEffectiveBaseUrl = localBasePrimary;
        return;
      } catch {}
      // intentar alternativo 5005
      try {
        const serverPath = path.join(__dirname, '..', 'server', 'inventory-server.js');
        const node = process.execPath;
        const env = { ...process.env, PORT: String(5005), CATALOG_BASE_URL: String(remoteConfig.baseUrl || ''), ELECTRON_RUN_AS_NODE: '1' };
        const child = childProcess.spawn(node, [serverPath], { cwd: path.join(__dirname, '..'), env, stdio: 'ignore', windowsHide: true, detached: true });
        child.unref();
        await new Promise(r => setTimeout(r, 900));
        const healthUrl = new URL('api/health', localBaseAlt).toString();
        await httpGetJsonWithTimeout(healthUrl, 2000);
        inventoryEffectiveBaseUrl = localBaseAlt;
        return;
      } catch {}
      return; // si no se pudo, se mantiene sin efectivo
    }
    // Caso 2: localhost → lógica existente
    const port = Number(u.port || (u.protocol === 'https:' ? 443 : 80));
    // Probar health
    try {
      const healthUrl = new URL('api/health', base).toString();
      await httpGetJsonWithTimeout(healthUrl, 1500);
      inventoryEffectiveBaseUrl = base;
      return; // ya está arriba
    } catch {}
    // Si el puerto responde con algo (aunque no sea JSON), asumimos que está ocupado por otro servicio y no arrancamos para evitar EADDRINUSE
    try {
      const rawUrl = base; // raíz
      await httpGetRawWithTimeout(rawUrl, 1200);
      inventoryEffectiveBaseUrl = base;
      return; // hay algo escuchando en ese puerto
    } catch {}
    // Intentar requerir el servidor dentro del propio proceso (si está empaquetado, debe estar incluido)
    try {
      const serverPath = path.join(__dirname, '..', 'server', 'inventory-server.js');
      // Ejecutar el binario de Electron como Node (ELECTRON_RUN_AS_NODE)
      const node = process.execPath;
      const env = { ...process.env, PORT: String(port), CATALOG_BASE_URL: String(remoteConfig.baseUrl || ''), ELECTRON_RUN_AS_NODE: '1' };
      const child = childProcess.spawn(node, [serverPath], { cwd: path.join(__dirname, '..'), env, stdio: 'ignore', windowsHide: true, detached: true });
      child.unref();
    } catch {}
    // Darle un respiro y re-comprobar
    try {
      const healthUrl = new URL('api/health', base).toString();
      await new Promise(r => setTimeout(r, 800));
      await httpGetJsonWithTimeout(healthUrl, 2000);
      inventoryEffectiveBaseUrl = base;
      return;
    } catch {}
    // Fallback a 5005 si 4321 no está disponible
    const altPort = 5005;
    const altBase = `${u.protocol}//${u.hostname}:${altPort}/`;
    try {
      const serverPath = path.join(__dirname, '..', 'server', 'inventory-server.js');
      const node = process.execPath;
      const env = { ...process.env, PORT: String(altPort), CATALOG_BASE_URL: String(remoteConfig.baseUrl || ''), ELECTRON_RUN_AS_NODE: '1' };
      const child = childProcess.spawn(node, [serverPath], { cwd: path.join(__dirname, '..'), env, stdio: 'ignore', windowsHide: true, detached: true });
      child.unref();
      await new Promise(r => setTimeout(r, 1000));
      const healthUrl = new URL('api/health', altBase).toString();
      await httpGetJsonWithTimeout(healthUrl, 2000);
      inventoryEffectiveBaseUrl = altBase;
      return;
    } catch {}
  } catch {}
}

// Monitor de keep-alive: comprueba /api/health periódicamente y relanza si cae
function startInventoryKeepAliveMonitor() {
  try {
    if (invServerMonitorTimer) { clearInterval(invServerMonitorTimer); invServerMonitorTimer = null; }
  } catch {}
  const check = async () => {
    try {
      const baseCfg = ensureSlash(remoteConfig?.inventory?.baseUrl || 'http://localhost:4321/');
      const base = ensureSlash(inventoryEffectiveBaseUrl || baseCfg);
      const healthUrl = new URL('api/health', base).toString();
      await httpGetJsonWithTimeout(healthUrl, 1500);
      // OK
      // Si estamos usando local pero hay remoto configurado, intenta switchear a remoto cuando esté disponible
      try {
        const uCfg = new URL(baseCfg);
        const hCfg = (uCfg.hostname || '').toLowerCase();
        const usingLocal = base.includes('localhost:4321') || base.includes('localhost:5005');
        const remoteConfigured = hCfg !== 'localhost' && hCfg !== '127.0.0.1';
        if (usingLocal && remoteConfigured) {
          const remoteHealth = new URL('api/health', baseCfg).toString();
          const ok = await httpGetJsonWithTimeout(remoteHealth, 1200).then(()=>true,()=>false);
          if (ok) inventoryEffectiveBaseUrl = baseCfg;
        }
      } catch {}
    } catch {
      try { await ensureLocalInventoryServer(); } catch {}
    }
  };
  check().catch(() => {});
  invServerMonitorTimer = setInterval(() => { check().catch(() => {}); }, 30 * 1000);
}

// Exponer información del servidor de inventario por IPC (opcional para UI)
ipcMain.handle('inventory:serverInfo', async () => {
  return {
    ok: true,
    configuredBaseUrl: remoteConfig?.inventory?.baseUrl || '',
    effectiveBaseUrl: inventoryEffectiveBaseUrl || remoteConfig?.inventory?.baseUrl || '',
    enabled: !!remoteConfig?.inventory?.enabled,
  };
});

// Handler para cargar evoluciones desde GitHub con soporte multi-fuente y fallback local
ipcMain.handle('evolutions:load', async () => {
  const https = require('https');
  const rawUrl = 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/evolutions.json';
  const ghPagesUrl = 'https://hugom1307.github.io/kvrcards-catalog/evolutions.json';

  const fetchHttpsJson = (targetUrl, timeoutMs = 5000) => {
    return new Promise((resolve, reject) => {
      try {
        const u = new URL(targetUrl);
        const req = https.get({
          protocol: u.protocol,
          hostname: u.hostname,
          path: u.pathname + (u.search || ''),
          headers: {
            'User-Agent': 'KVRCards-Game/1.0',
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache'
          }
        }, (res) => {
          if (res.statusCode < 200 || res.statusCode >= 300) {
            return reject(new Error(`HTTP status ${res.statusCode}`));
          }
          let body = '';
          res.setEncoding('utf8');
          res.on('data', chunk => { body += chunk; });
          res.on('end', () => {
            try {
              resolve(safeParseJson(body));
            } catch (e) {
              reject(e);
            }
          });
        });
        req.setTimeout(timeoutMs, () => {
          req.destroy();
          reject(new Error(`Timeout de ${timeoutMs}ms al solicitar ${targetUrl}`));
        });
        req.on('error', reject);
      } catch (err) {
        reject(err);
      }
    });
  };

  // 1. Intentar raw.githubusercontent.com (Node https directo)
  try {
    console.log('[EVOLUTIONS] Intentando cargar desde raw GitHub:', rawUrl);
    const data = await fetchHttpsJson(rawUrl + `?t=${Date.now()}`, 5000);
    if (data && Array.isArray(data.evolutions) && data.evolutions.length > 0) {
      console.log('[EVOLUTIONS] ✅ Cargadas desde raw GitHub:', data.evolutions.length);
      return { ok: true, evolutions: data.evolutions, source: 'raw' };
    }
  } catch (err1) {
    console.warn('[EVOLUTIONS] Falló raw GitHub:', err1?.message || err1);
  }

  // 2. Intentar GitHub Pages (Node https directo)
  try {
    console.log('[EVOLUTIONS] Intentando cargar desde GitHub Pages:', ghPagesUrl);
    const data = await fetchHttpsJson(ghPagesUrl + `?t=${Date.now()}`, 5000);
    if (data && Array.isArray(data.evolutions) && data.evolutions.length > 0) {
      console.log('[EVOLUTIONS] ✅ Cargadas desde GitHub Pages:', data.evolutions.length);
      return { ok: true, evolutions: data.evolutions, source: 'github_pages' };
    }
  } catch (err2) {
    console.warn('[EVOLUTIONS] Falló GitHub Pages:', err2?.message || err2);
  }

  // 3. Intentar con httpGetJson de Electron si existiera diferencia de proxy/red
  try {
    console.log('[EVOLUTIONS] Intentando cargar via net.request (Electron):', ghPagesUrl);
    const data = await httpGetJsonWithTimeout(ghPagesUrl + `?t=${Date.now()}`, 4000);
    if (data && Array.isArray(data.evolutions) && data.evolutions.length > 0) {
      console.log('[EVOLUTIONS] ✅ Cargadas via net.request:', data.evolutions.length);
      return { ok: true, evolutions: data.evolutions, source: 'electron_net' };
    }
  } catch (err3) {
    console.warn('[EVOLUTIONS] Falló net.request:', err3?.message || err3);
  }

  // 4. Fallback a archivo local game-data/evolutions.json
  try {
    const candidates = [
      path.join(app.getAppPath(), 'game-data', 'evolutions.json'),
      path.join(__dirname, '..', 'game-data', 'evolutions.json'),
      path.join(process.cwd(), 'game-data', 'evolutions.json')
    ];
    for (const localPath of candidates) {
      if (fs.existsSync(localPath)) {
        const content = fs.readFileSync(localPath, 'utf-8');
        const data = safeParseJson(content);
        if (data && Array.isArray(data.evolutions) && data.evolutions.length > 0) {
          console.log('[EVOLUTIONS] ✅ Cargadas desde fallback local:', localPath, data.evolutions.length);
          return { ok: true, evolutions: data.evolutions, source: 'local_fallback' };
        }
      }
    }
  } catch (err4) {
    console.warn('[EVOLUTIONS] Falló fallback local:', err4?.message || err4);
  }

  return { ok: false, error: 'No se pudieron cargar evoluciones de ninguna fuente', evolutions: [] };
});

function getEvolutionStateFile() {
  const userDir = app.getPath('userData');
  const uname = (profile.username || '').trim().replace(/[^a-zA-Z0-9_\-]/g, '_');
  if (uname) {
    return path.join(userDir, `evolutions-state-${uname}.json`);
  }
  return path.join(userDir, 'evolutions-state.json');
}

// Handler para guardar estado de evoluciones en archivo por usuario
ipcMain.handle('evolutions:saveState', async (event, data) => {
  const stateFile = getEvolutionStateFile();
  try {
    console.log('[EVOLUTIONS STATE] Guardando estado en:', stateFile);
    fs.writeFileSync(stateFile, JSON.stringify(data || {}, null, 2), 'utf-8');
    console.log('[EVOLUTIONS STATE] Estado guardado correctamente');
    return { ok: true };
  } catch (error) {
    console.error('[EVOLUTIONS STATE] Error al guardar:', error);
    return { ok: false, error: String(error) };
  }
});

// Handler para cargar estado de evoluciones desde archivo por usuario
ipcMain.handle('evolutions:loadState', async () => {
  const stateFile = getEvolutionStateFile();
  try {
    if (!fs.existsSync(stateFile)) {
      console.log('[EVOLUTIONS STATE] Archivo no existe para usuario actual, retornando estado vacio');
      return { ok: true, data: {} };
    }
    console.log('[EVOLUTIONS STATE] Cargando estado desde:', stateFile);
    const content = fs.readFileSync(stateFile, 'utf-8');
    const data = JSON.parse(content);
    
    if (typeof data !== 'object' || data === null) {
      return { ok: true, data: {} };
    }
    
    return { ok: true, data };
  } catch (error) {
    console.error('[EVOLUTIONS STATE] Error al cargar:', error);
    return { ok: true, data: {} };
  }
});

// ==================== EVENTOS Y ENTREGABLES API ====================

// Obtener la lista y conteo de entregables completados por el usuario
ipcMain.handle('deliverables:getCompleted', () => {
  const currentCycle = typeof getMadridDayCycle === 'function' ? getMadridDayCycle() : '2026-09-24';
  return {
    completedDeliverables,
    deliverableCompletions,
    deliverableDailyCompletions,
    currentCycle
  };
});

// Completar un entregable (Transacción Atómica de Entrega de Cartas)
ipcMain.handle('deliverables:complete', async (_e, { deliverableId, cardsToDeduct, rewards }) => {
  try {
    const currentUser = (profile.username || '').trim();
    if (!currentUser) {
      return { ok: false, error: 'No hay sesión activa' };
    }

    console.log(`[DELIVERABLES] Procesando entregable "${deliverableId}" para: "${currentUser}"`);

    // 1. Agrupar y validar propiedad de todas las cartas requeridas
    const cardsToDeductMap = new Map();
    for (const card of cardsToDeduct) {
      const id = card.instanceId || card.cardId;
      cardsToDeductMap.set(id, (cardsToDeductMap.get(id) || 0) + 1);
    }

    for (const [id, reqCount] of cardsToDeductMap) {
      if (cardTraits.has(id) || cardUpgrades.has(id)) {
        if (reqCount > 1) {
          return { ok: false, error: `Validación fallida: La instancia única ${id} no puede entregarse múltiples veces.` };
        }
        const traitData = cardTraits.get(id);
        const upgradeData = cardUpgrades.get(id);
        const baseCardId = traitData?.cardId || upgradeData?.cardId;
        if (!baseCardId) {
          return { ok: false, error: `Validación fallida: No se encontró la carta base de la instancia ${id}.` };
        }
        const ownedCount = ownedCards.get(baseCardId) || 0;
        if (ownedCount < 1) {
          return { ok: false, error: `No posees la carta base para la instancia ${id}.` };
        }
      } else {
        const ownedCount = ownedCards.get(id) || 0;
        let instancesOfThisCardBeingDelivered = 0;
        for (const card of cardsToDeduct) {
          if (card.instanceId) {
            const traitData = cardTraits.get(card.instanceId);
            const upgradeData = cardUpgrades.get(card.instanceId);
            const baseId = traitData?.cardId || upgradeData?.cardId;
            if (baseId === id) {
              instancesOfThisCardBeingDelivered++;
            }
          }
        }
        if (ownedCount < (reqCount + instancesOfThisCardBeingDelivered)) {
          return { ok: false, error: `No tienes suficientes copias de la carta ${id}.` };
        }
      }
    }

    const currentCycle = typeof getMadridDayCycle === 'function' ? getMadridDayCycle() : '2026-09-24';

    // Comienza la transacción atómica
    inTransaction = true;
    try {
      // 2. Proceder a la deducción de las cartas
      for (const card of cardsToDeduct) {
        if (card.instanceId) {
          // Eliminar instancia única de rasgos y mejoras
          const traitData = cardTraits.get(card.instanceId);
          const upgradeData = cardUpgrades.get(card.instanceId);
          const baseCardId = traitData?.cardId || upgradeData?.cardId;
          
          cardTraits.delete(card.instanceId);
          cardUpgrades.delete(card.instanceId);
          
          if (baseCardId) {
            const currentCount = ownedCards.get(baseCardId) || 0;
            if (currentCount > 1) {
              ownedCards.set(baseCardId, currentCount - 1);
            } else {
              ownedCards.delete(baseCardId);
            }
            
            const cardName = cardStore.get(baseCardId)?.name || baseCardId;
            logCriticalEvent('remove', `Removed trait/upgrade card instance: ${cardName} (Instance ID: ${card.instanceId}, Base ID: ${baseCardId}). Reason: Completed deliverable "${deliverableId}"`);
          }
        } else {
          // Restar copia estándar
          const currentCount = ownedCards.get(card.cardId) || 0;
          if (currentCount > 1) {
            ownedCards.set(card.cardId, currentCount - 1);
          } else {
            ownedCards.delete(card.cardId);
          }
          
          const cardName = cardStore.get(card.cardId)?.name || card.cardId;
          logCriticalEvent('remove', `Removed card: ${cardName} (ID: ${card.cardId}). Reason: Completed deliverable "${deliverableId}"`);
        }
      }

      // 3. Otorgar recompensas al usuario
      if (rewards.coins) {
        wallet.coins = (wallet.coins || 0) + (Number(rewards.coins) || 0);
        incrementCoinsEarned(Number(rewards.coins) || 0);
        logCriticalEvent('add', `Added coins: ${rewards.coins}. Reason: Completed deliverable "${deliverableId}"`);
      }
      if (rewards.kvr) {
        wallet.kvr = (wallet.kvr || 0) + (Number(rewards.kvr) || 0);
        logCriticalEvent('add', `Added kvr: ${rewards.kvr}. Reason: Completed deliverable "${deliverableId}"`);
      }
      if (rewards.traits) {
        wallet.traits = (wallet.traits || 0) + (Number(rewards.traits) || 0);
        logCriticalEvent('add', `Added traits: ${rewards.traits}. Reason: Completed deliverable "${deliverableId}"`);
      }
      if (rewards.packs && Array.isArray(rewards.packs)) {
        for (const pReward of rewards.packs) {
          const packId = pReward.id || pReward.packId;
          const cantidad = Number(pReward.cantidad || pReward.amount || 1) || 1;
          if (packId && cantidad > 0) {
            const cur = ownedPacks.get(packId) || 0;
            ownedPacks.set(packId, cur + cantidad);
            
            const packName = packStore.get(packId)?.name || packId;
            logCriticalEvent('add', `Added pack: ${packName} (ID: ${packId}) x${cantidad}. Reason: Completed deliverable "${deliverableId}"`);
          }
        }
      }
      if (rewards.cards && Array.isArray(rewards.cards)) {
        for (const cReward of rewards.cards) {
          const cardId = cReward.id || cReward.cardId;
          const cantidad = Number(cReward.cantidad || cReward.amount || 1) || 1;
          if (cardId && cantidad > 0) {
            const cur = ownedCards.get(cardId) || 0;
            ownedCards.set(cardId, cur + cantidad);
            
            const cardName = cardStore.get(cardId)?.name || cardId;
            logCriticalEvent('add', `Added card: ${cardName} (ID: ${cardId}) x${cantidad}. Reason: Completed deliverable "${deliverableId}"`);
          }
        }
      }
      if (rewards.card) {
        const cardId = typeof rewards.card === 'string' ? rewards.card : (rewards.card.id || rewards.card.cardId);
        const cantidad = typeof rewards.card === 'object' ? (Number(rewards.card.cantidad || rewards.card.amount || 1) || 1) : 1;
        if (cardId && cantidad > 0) {
          const cur = ownedCards.get(cardId) || 0;
          ownedCards.set(cardId, cur + cantidad);
          
          const cardName = cardStore.get(cardId)?.name || cardId;
          logCriticalEvent('add', `Added card: ${cardName} (ID: ${cardId}) x${cantidad}. Reason: Completed deliverable "${deliverableId}"`);
        }
      }
      if (rewards.titles && Array.isArray(rewards.titles)) {
        if (!Array.isArray(profile.unlockedTitles)) profile.unlockedTitles = ['novato'];
        for (const tReward of rewards.titles) {
          const tId = String(typeof tReward === 'string' ? tReward : (tReward.id || tReward.titleId || '')).toLowerCase().trim();
          if (tId && !profile.unlockedTitles.includes(tId)) {
            profile.unlockedTitles.push(tId);
            logCriticalEvent('add', `Unlocked title: ${tId}. Reason: Completed deliverable "${deliverableId}"`);
          }
        }
      }
      if (rewards.title) {
        if (!Array.isArray(profile.unlockedTitles)) profile.unlockedTitles = ['novato'];
        const tId = String(typeof rewards.title === 'string' ? rewards.title : (rewards.title.id || rewards.title.titleId || '')).toLowerCase().trim();
        if (tId && !profile.unlockedTitles.includes(tId)) {
          profile.unlockedTitles.push(tId);
          logCriticalEvent('add', `Unlocked title: ${tId}. Reason: Completed deliverable "${deliverableId}"`);
        }
      }

      // 4. Marcar entregable como completado e incrementar contador total y diario (06:00 AM Madrid)
      deliverableCompletions[deliverableId] = (Number(deliverableCompletions[deliverableId]) || 0) + 1;
      if (!completedDeliverables.includes(deliverableId)) {
        completedDeliverables.push(deliverableId);
      }

      if (!deliverableDailyCompletions[deliverableId] || deliverableDailyCompletions[deliverableId].cycle !== currentCycle) {
        deliverableDailyCompletions[deliverableId] = { cycle: currentCycle, count: 1 };
      } else {
        deliverableDailyCompletions[deliverableId].count = (Number(deliverableDailyCompletions[deliverableId].count) || 0) + 1;
      }

      // Fin de la transacción atómica
      inTransaction = false;
      saveInventory();
    } catch (innerErr) {
      inTransaction = false;
      throw innerErr;
    }

    console.log(`[DELIVERABLES] Entregable "${deliverableId}" completado con éxito. Veces completado: ${deliverableCompletions[deliverableId]}`);
    return {
      ok: true,
      wallet: { ...wallet },
      packs: Object.fromEntries(ownedPacks),
      cards: Object.fromEntries(ownedCards),
      profile: { ...profile },
      completedDeliverables,
      deliverableCompletions,
      deliverableDailyCompletions,
      currentCycle
    };
  } catch (err) {
    console.error(`[DELIVERABLES] Error al completar entregable:`, err);
    return { ok: false, error: String(err) };
  }
});

// ==================== MAINTENANCE & VERSION CHECK ====================

// Función para verificar estado de mantenimiento desde el servidor remoto
async function checkMaintenanceStatus() {
  try {
    // Intentar cargar remote-config desde el catálogo (GitHub Pages)
    const baseUrl = remoteConfig?.catalog?.baseUrl || '';
    if (!baseUrl) {
      console.log('[MAINTENANCE] No hay URL de catálogo configurada, usando config local');
      return { maintenance: remoteConfig.maintenance, version: remoteConfig.version };
    }

    // Construir URL para obtener remote-config actualizado desde GitHub Pages
    const configUrl = new URL('remote-config.json', ensureSlash(baseUrl)).toString();
    console.log('[MAINTENANCE] Verificando desde:', configUrl);
    
    const freshConfig = await httpGetJsonWithTimeout(configUrl + `?t=${Date.now()}`, 5000).catch(() => null);
    
    if (freshConfig) {
      // Actualizar configuración de mantenimiento
      const maint = freshConfig.maintenance || {};
      remoteConfig.maintenance = {
        enabled: Boolean(maint.enabled),
        title: String(maint.title || '🔧 Mantenimiento en Curso'),
        message: String(maint.message || 'Estamos actualizando el juego. Volveremos pronto.'),
        estimatedTime: String(maint.estimatedTime || '')
      };
      
      // Actualizar configuración de versión
      const ver = freshConfig.version || {};
      remoteConfig.version = {
        current: String(ver.current || '1.0.0'),
        minimumRequired: String(ver.minimumRequired || '1.0.0'),
        downloadUrl: String(ver.downloadUrl || ''),
        changelog: String(ver.changelog || ''),
        forceUpdate: Boolean(ver.forceUpdate)
      };
      
      console.log('[MAINTENANCE] Config actualizada:', { maintenance: remoteConfig.maintenance, version: remoteConfig.version });
    }
    
    return { maintenance: remoteConfig.maintenance, version: remoteConfig.version };
  } catch (error) {
    console.error('[MAINTENANCE] Error al verificar:', error);
    return { maintenance: remoteConfig.maintenance, version: remoteConfig.version };
  }
}

// Handler IPC para que el frontend obtenga estado de mantenimiento
ipcMain.handle('maintenance:check', async () => {
  return await checkMaintenanceStatus();
});

// Handler IPC para obtener versión actual del juego (desde package.json)
ipcMain.handle('app:getVersion', async () => {
  try {
    const packagePath = path.join(__dirname, '..', 'package.json');
    if (fs.existsSync(packagePath)) {
      const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf-8'));
      return { version: pkg.version || '1.0.0' };
    }
  } catch {}
  return { version: '1.0.0' };
});

// Handler IPC para abrir URLs externas
ipcMain.handle('shell:openExternal', async (event, url) => {
  try {
    await shell.openExternal(url);
    return { ok: true };
  } catch (error) {
    console.error('[SHELL] Error al abrir URL:', error);
    return { ok: false, error: String(error) };
  }
});

// Handler IPC para salir/cerrar el juego
ipcMain.handle('app:quit', () => {
  console.log('[APP] Cerrando juego a petición del usuario...');
  app.quit();
});

// ==================== FIN MAINTENANCE & VERSION CHECK ====================
