const https = require('https');
const data = JSON.stringify({
  username: 'TestWriteUser',
  cards: { ken_inazuma: 1 },
  packs: {},
  wallet: { coins: 123, kvr: 5 },
  currentTitle: 'Tester',
  showcaseCards: ['ken_inazuma', null, null]
});

const options = {
  hostname: 'inventory-43i0.onrender.com',
  path: '/api/inventory/TestWriteUser',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(data)
  }
};

const req = https.request(options, (res) => {
  let body = '';
  res.setEncoding('utf8');
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    console.log('STATUS', res.statusCode);
    console.log('BODY', body);
    // Now GET the created user
    https.get('https://inventory-43i0.onrender.com/api/inventory/TestWriteUser', (gres) => {
      let gbody = '';
      gres.setEncoding('utf8');
      gres.on('data', c => gbody += c);
      gres.on('end', () => {
        console.log('GET STATUS', gres.statusCode);
        console.log('GET BODY', gbody);
      });
    }).on('error', e => console.error('GET ERR', e));
  });
});

req.on('error', (e) => { console.error('REQ ERR', e); });
req.write(data);
req.end();
