(function () {
  const state = {
    currentFloor: 1,
    panelOpen: false,
    selectingTeam: false,
    initialTeamLocked: false,
    runActive: false,
    decisionOpen: false,
    runDeckIds: [],
    runStats: {
      upgrades: 0,
      riskEvents: 0,
      shopVisits: 0,
      addedFromOutside: 0
    },
    runCardBuffs: {},
    floorModifiers: {},
    upgradeInProgress: false,
    catalogCardsById: {},
    inventoryCards: [],
    inventoryPowers: [],
    selectedInitialCards: [],
    selectedInitialCardIds: [],
    selectedInitialPowers: [],
    selectedInitialPowerIds: [],
    originalTeamBuilderCards: null,
    initialTeamSnapshot: null,
    initialPowersSnapshot: null,
    worldConfig: null,
    arcWorldAssignments: {},
    shopConfig: null,
    riskConfig: null,
    activeRiskEvent: null,
    shopItemStock: {},
    shopDecisionWillBeConsumed: false,
    shopRestocking: false,
    currentShopItemIds: null,
    consumableItems: [],
    runTemporalCards: {},
    shopCurrencies: {
      coins: 0,
      kvr: 0,
      'infinite-coins': 0,
      'infinite-cardpoints': 0
    },
    claimedMilestones: []
  };

  function getInfiniteUserKey(baseKey) {
    const user = (typeof currentUser === 'string' && currentUser.trim()) ? currentUser.trim() : (localStorage.getItem('kvrUsername') || '');
    return user ? `${baseKey}_${user}` : baseKey;
  }

  const INFINITE_SEASON_REMOTE_URL = window.KVR_INFINITE_SEASON_REMOTE_URL
    || localStorage.getItem('KVR_INFINITE_SEASON_REMOTE_URL')
    || 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/infinite-season.json';

  const FALLBACK_INFINITE_SEASON_CONFIG = {
    version: 1,
    season: {
      id: 'season-1',
      name: 'Temporada 1: El Despertar del Infinito'
    },
    rewards: [
      {
        level: 10,
        rewards: [
          { type: 'coins', amount: 5000 },
          { type: 'traits', amount: 3 }
        ]
      },
      {
        level: 20,
        rewards: [
          { type: 'coins', amount: 10000 },
          { type: 'pack', packId: 'sobre_oro', amount: 3 },
          { type: 'traits', amount: 2 }
        ]
      },
      {
        level: 30,
        rewards: [
          { type: 'pack', packId: 'sobre_83_plus', amount: 1 },
          { type: 'traits', amount: 5 }
        ]
      },
      {
        level: 40,
        rewards: [
          { type: 'coins', amount: 30000 },
          { type: 'pack', packId: 'sobre_83_plus', amount: 2 }
        ]
      },
      {
        level: 50,
        rewards: [
          { type: 'title', titleId: 'conquistador_del_infinito', name: 'Conquistador del Infinito' },
          { type: 'card', cardId: 'carta_exclusiva_infinito', name: 'Carta Exclusiva Infinito' },
          { type: 'traits', amount: 10 }
        ]
      },
      {
        level: 60,
        rewards: [
          { type: 'traits', amount: 15 }
        ]
      },
      {
        level: 70,
        rewards: [
          { type: 'traits', amount: 20 }
        ]
      },
      {
        level: 80,
        rewards: [
          { type: 'pack', packId: 'sobre_85_plus', amount: 1 },
          { type: 'coins', amount: 25000 }
        ]
      },
      {
        level: 90,
        rewards: [
          { type: 'traits', amount: 25 }
        ]
      },
      {
        level: 100,
        rewards: [
          { type: 'coins', amount: 100000 },
          { type: 'pack', packId: 'sobre_especial', amount: 1 }
        ]
      }
    ],
    beyondLevel100: {
      startLevel: 101,
      perLevelRewards: [
        { type: 'traits', amount: 1 }
      ]
    }
  };

  let cachedSeasonConfig = null;

  async function loadInfiniteSeasonConfig() {
    if (cachedSeasonConfig) return cachedSeasonConfig;

    try {
      const resp = await fetch('/api/infinite/season', { cache: 'no-store' });
      if (resp.ok) {
        const data = await resp.json();
        if (data && data.ok && Array.isArray(data.rewards)) {
          cachedSeasonConfig = data;
          return cachedSeasonConfig;
        }
      }
    } catch {}

    try {
      const resp = await fetch(`${INFINITE_SEASON_REMOTE_URL}?t=${Date.now()}`, { cache: 'no-store' });
      if (resp.ok) {
        const data = await resp.json();
        if (data && Array.isArray(data.rewards)) {
          cachedSeasonConfig = data;
          return cachedSeasonConfig;
        }
      }
    } catch {}

    cachedSeasonConfig = FALLBACK_INFINITE_SEASON_CONFIG;
    return cachedSeasonConfig;
  }

  function computeInfiniteFloorRewards(level, role) {
    const safeLevel = Number(level) || 1;
    const safeRole = String(role || '').toLowerCase();
    const isBoss = safeRole === 'boss' || (safeLevel > 0 && safeLevel % 10 === 0);
    const isMiniboss = !isBoss && (safeRole === 'miniboss' || safeRole === 'mini-boss' || (safeLevel > 0 && safeLevel % 10 === 5));

    let coins = 0;
    let cardpoints = 0;
    let traits = 0;

    if (isBoss) {
      coins = Math.random() < 0.7 ? 3 : 2;
      cardpoints = Math.random() < 0.4 ? 2 : 1;
    } else if (isMiniboss) {
      coins = 2;
      cardpoints = Math.random() < 0.5 ? 1 : 0;
    } else {
      coins = Math.random() < 0.4 ? 2 : 1;
      cardpoints = 0;
    }

    if (safeLevel >= 101) {
      traits = 1;
    }

    const items = [];
    if (coins > 0) {
      items.push({ type: 'infinite-coins', amount: coins, name: `${coins} Infinite Coins` });
    }
    if (cardpoints > 0) {
      items.push({ type: 'infinite-cardpoints', amount: cardpoints, name: `${cardpoints} Infinite Card Points` });
    }
    if (traits > 0) {
      items.push({ type: 'traits', amount: traits, name: `${traits} Trait` });
    }

    return items;
  }
  window.computeInfiniteFloorRewards = computeInfiniteFloorRewards;

  async function checkAndClaimInfiniteMilestone(floor) {
    const safeFloor = Number(floor) || 0;
    if (safeFloor <= 0) return [];

    state.claimedMilestones = Array.isArray(state.claimedMilestones) ? state.claimedMilestones : [];
    if (state.claimedMilestones.includes(safeFloor)) {
      return [];
    }

    const seasonConfig = await loadInfiniteSeasonConfig();
    const rewardsList = Array.isArray(seasonConfig?.rewards) ? seasonConfig.rewards : [];
    const milestone = rewardsList.find((entry) => Number(entry.level) === safeFloor);

    if (!milestone) return [];

    const rewardsToGrant = Array.isArray(milestone.rewards) ? milestone.rewards : [];
    if (rewardsToGrant.length === 0) return [];

    state.claimedMilestones.push(safeFloor);
    persistInfiniteRunState();

    return rewardsToGrant;
  }
  window.checkAndClaimInfiniteMilestone = checkAndClaimInfiniteMilestone;

  function infiniteAddCurrency(currency, amount) {
    const safeCurrency = String(currency || '').trim().toLowerCase();
    const safeAmount = Number(amount) || 0;
    if (!safeAmount) return;

    if (safeCurrency === 'infinite-coins' || safeCurrency === 'infinite-coin') {
      state.shopCurrencies['infinite-coins'] = Math.max(0, (Number(state.shopCurrencies['infinite-coins']) || 0) + safeAmount);
    } else if (safeCurrency === 'infinite-cardpoints' || safeCurrency === 'infinite-cardpoint') {
      state.shopCurrencies['infinite-cardpoints'] = Math.max(0, (Number(state.shopCurrencies['infinite-cardpoints']) || 0) + safeAmount);
    } else if (safeCurrency === 'coins') {
      state.shopCurrencies.coins = Math.max(0, (Number(state.shopCurrencies.coins) || 0) + safeAmount);
    } else if (safeCurrency === 'kvr') {
      state.shopCurrencies.kvr = Math.max(0, (Number(state.shopCurrencies.kvr) || 0) + safeAmount);
    }

    persistInfiniteCurrencies();
    renderShopCurrencyBar();
  }
  window.infiniteAddCurrency = infiniteAddCurrency;

  const INFINITE_WORLDS_REMOTE_URL = window.KVR_INFINITE_WORLDS_REMOTE_URL
    || localStorage.getItem('KVR_INFINITE_WORLDS_REMOTE_URL')
    || 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/infinite-worlds.json';

  const INFINITE_SHOP_REMOTE_URL = window.KVR_INFINITE_SHOP_REMOTE_URL
    || localStorage.getItem('KVR_INFINITE_SHOP_REMOTE_URL')
    || 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/infinite-shop.json';

  const INFINITE_RISK_EVENTS_REMOTE_URL = window.KVR_INFINITE_RISK_EVENTS_REMOTE_URL
    || localStorage.getItem('KVR_INFINITE_RISK_EVENTS_REMOTE_URL')
    || 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/infinite-risk-events.json';

  function createFallbackLevels(worldId, trainerPrefix, trainerImageA, trainerImageB, arcImage) {
    return Array.from({ length: 10 }, (_, index) => {
      const levelNumber = index + 1;
      const trainerImage = levelNumber % 2 === 0 ? trainerImageA : trainerImageB;
      return {
        id: `${worldId}-level-${levelNumber}`,
        number: levelNumber,
        name: `Nivel ${levelNumber}`,
        arcImage,
        trainer: {
          id: `${worldId}-trainer-${levelNumber}`,
          name: `${trainerPrefix} ${levelNumber}`,
          image: trainerImage
        }
      };
    });
  }

  const FALLBACK_WORLD_CONFIG = {
    version: 1,
    worldOrder: ['initial-city', 'storm-islands', 'crimson-kingdom', 'celestial-temple'],
    worlds: [
      {
        id: 'initial-city',
        name: 'Arco Ciudad Inicial',
        worldImage: './assets/menu/play-button.png',
        fallback: 'linear-gradient(135deg, #0f172a, #1d4ed8)',
        levels: createFallbackLevels(
          'initial-city',
          'Entrenador Urbano',
          './bots/doman.png',
          './bots/zion.png',
          './assets/menu/play-button.png'
        ),
        bots: [
          { id: 'city-guardian', name: 'Guardian de la Ciudad', image: './bots/doman.png' },
          { id: 'city-scout', name: 'Explorador Urbano', image: './bots/zion.png' }
        ]
      },
      {
        id: 'storm-islands',
        name: 'Arco Islas Tormenta',
        worldImage: './assets/menu/collection-button.png',
        fallback: 'linear-gradient(135deg, #111827, #0ea5e9)',
        levels: createFallbackLevels(
          'storm-islands',
          'Capitan Tormenta',
          './bots/tan.png',
          './bots/doman.png',
          './assets/menu/collection-button.png'
        ),
        bots: [
          { id: 'storm-captain', name: 'Capitan de la Tormenta', image: './bots/tan.png' }
        ]
      },
      {
        id: 'crimson-kingdom',
        name: 'Arco Reino Carmesi',
        worldImage: './assets/menu/missions-button.png',
        fallback: 'linear-gradient(135deg, #1f2937, #b91c1c)',
        levels: createFallbackLevels(
          'crimson-kingdom',
          'Caballero Carmesi',
          './bots/doman.png',
          './bots/tan.png',
          './assets/menu/missions-button.png'
        ),
        bots: [
          { id: 'crimson-knight', name: 'Caballero Carmesi', image: './bots/doman.png' }
        ]
      },
      {
        id: 'celestial-temple',
        name: 'Arco Templo Celestial',
        worldImage: './assets/menu/ranking-button.png',
        fallback: 'linear-gradient(135deg, #1e293b, #7c3aed)',
        levels: createFallbackLevels(
          'celestial-temple',
          'Sabio Celestial',
          './bots/zion.png',
          './bots/doman.png',
          './assets/menu/ranking-button.png'
        ),
        bots: [
          { id: 'temple-sage', name: 'Sabio Celestial', image: './bots/zion.png' }
        ]
      }
    ]
  };

  const FALLBACK_RISK_EVENTS_CONFIG = {
    version: 1,
    events: [
      {
        id: 'altar-of-shadows',
        title: 'Altar de las Sombras',
        worldIds: ['initial-city', 'storm-islands', 'crimson-kingdom', 'celestial-temple'],
        minFloor: 1,
        maxFloor: 9999,
        startNodeId: 'intro',
        nodes: [
          {
            id: 'intro',
            text: 'Encuentras un altar antiguo envuelto en humo negro. Una voz susurra que puede potenciar tu mazo... o romperlo.',
            choices: [
              {
                id: 'safe-prayer',
                label: 'Oracion prudente (80%)',
                description: 'Intentas un ritual estable para mejorar Ninjutsu un 3%.',
                successChance: 0.8,
                successResult: {
                  text: 'La llama del altar responde. El poder fluye hacia una carta de tu run.',
                  effects: [
                    { type: 'cardStatPercent', target: 'random-run-card', stat: 'ninjutsu', percent: 3 }
                  ]
                },
                failureResult: {
                  text: 'El humo te envuelve y la energia se vuelve inestable.',
                  effects: [
                    { type: 'cardStatPercent', target: 'random-run-card', stat: 'ninjutsu', percent: 3, mode: 'nerf' }
                  ]
                }
              },
              {
                id: 'high-prayer',
                label: 'Oracion agresiva (50%)',
                description: 'Doblas la apuesta por un 6% a Ninjutsu.',
                successChance: 0.5,
                successResult: {
                  text: 'El altar ruge. La bendicion cae sobre tu mazo.',
                  effects: [
                    { type: 'cardStatPercent', target: 'random-run-card', stat: 'ninjutsu', percent: 6 }
                  ]
                },
                failureResult: {
                  text: 'El altar se quiebra y arrastra poder de tu equipo.',
                  effects: [
                    { type: 'cardStatPercent', target: 'random-run-card', stat: 'ninjutsu', percent: 6, mode: 'nerf' }
                  ]
                }
              }
            ]
          }
        ]
      }
    ]
  };

  const refs = {};
  const NODES_PER_ARC = 13;
  const DECISION_NODE_POSITIONS = new Set([5, 11]);
  const REWARD_NODE_POSITION = 13;
  const MAX_RUN_DECK_CARDS = 14;

  function sanitizeRunStats(stats) {
    const raw = stats && typeof stats === 'object' ? stats : {};
    return {
      upgrades: Number(raw.upgrades || 0),
      riskEvents: Number(raw.riskEvents || 0),
      shopVisits: Number(raw.shopVisits || 0),
      addedFromOutside: Number(raw.addedFromOutside || 0)
    };
  }

  function sanitizeRunCardBuffs(rawBuffs) {
    if (!rawBuffs || typeof rawBuffs !== 'object') return {};
    const result = {};

    Object.entries(rawBuffs).forEach(([cardId, statMap]) => {
      const safeCardId = String(cardId || '').trim();
      if (!safeCardId || !statMap || typeof statMap !== 'object') return;

      const cleanStats = {};
      Object.entries(statMap).forEach(([statKey, delta]) => {
        const safeStat = String(statKey || '').trim().toLowerCase();
        const safeDelta = Number(delta) || 0;
        if (!safeStat || !Number.isFinite(safeDelta) || safeDelta === 0) return;
        cleanStats[safeStat] = safeDelta;
      });

      if (Object.keys(cleanStats).length > 0) {
        result[safeCardId] = cleanStats;
      }
    });

    return result;
  }

  function persistInfiniteRunState() {
    if (!window.kvrcards || typeof window.kvrcards.saveInfiniteRunState !== 'function') return;

    const payload = {
      version: 1,
      savedAt: Date.now(),
      currentFloor: normalizeFloorValue(state.currentFloor),
      initialTeamLocked: !!state.initialTeamLocked,
      runActive: !!state.runActive,
      runDeckIds: Array.isArray(state.runDeckIds) ? [...state.runDeckIds] : [],
      runStats: sanitizeRunStats(state.runStats),
      runCardBuffs: sanitizeRunCardBuffs(state.runCardBuffs),
      selectedInitialCardIds: Array.isArray(state.selectedInitialCardIds) ? [...state.selectedInitialCardIds] : [],
      selectedInitialPowerIds: Array.isArray(state.selectedInitialPowerIds) ? [...state.selectedInitialPowerIds] : [],
      initialTeamSnapshot: Array.isArray(state.initialTeamSnapshot) ? [...state.initialTeamSnapshot] : null,
      initialPowersSnapshot: Array.isArray(state.initialPowersSnapshot) ? [...state.initialPowersSnapshot] : null,
      consumableItems: Array.isArray(state.consumableItems) ? [...state.consumableItems] : [],
      runTemporalCards: state.runTemporalCards && typeof state.runTemporalCards === 'object' ? { ...state.runTemporalCards } : {},
      shopRestocking: !!state.shopRestocking,
      claimedMilestones: Array.isArray(state.claimedMilestones) ? [...state.claimedMilestones] : [],
      floorModifiers: state.floorModifiers && typeof state.floorModifiers === 'object' ? { ...state.floorModifiers } : {},
      arcWorldAssignments: state.arcWorldAssignments && typeof state.arcWorldAssignments === 'object'
        ? { ...state.arcWorldAssignments }
        : {}
    };

    try {
      localStorage.setItem(getInfiniteUserKey('INFINITE_CLAIMED_MILESTONES'), JSON.stringify(state.claimedMilestones || []));
      localStorage.setItem('INFINITE_RUN_CONSUMABLES', JSON.stringify(state.consumableItems || []));
      localStorage.setItem('INFINITE_RUN_TEMPORAL_CARDS', JSON.stringify(state.runTemporalCards || {}));
      localStorage.setItem('INFINITE_RUN_SHOP_RESTOCKING', String(!!state.shopRestocking));
      localStorage.setItem('INFINITE_FLOOR_MODIFIERS', JSON.stringify(state.floorModifiers || {}));
    } catch {}

    window.kvrcards.saveInfiniteRunState(payload).then((result) => {
      if (!result?.ok) {
        console.warn('[INFINITE] No se pudo guardar progreso remoto de run:', result?.error || 'respuesta inválida');
      }
    }).catch((error) => {
      console.warn('[INFINITE] Error guardando progreso remoto de run:', error?.message || error);
    });
  }

  async function resetInfiniteRunState() {
    if (!window.currentUserIsAdmin) {
      console.warn('[ADMIN] Acceso denegado: solo cuentas admin pueden resetear la run.');
      return;
    }

    const confirmed = confirm('Esto borrará el progreso de la run infinita y te permitirá empezar desde cero. ¿Continuar?');
    if (!confirmed) return;

    try {
      if (window.kvrcards && typeof window.kvrcards.resetInfiniteRunState === 'function') {
        const result = await window.kvrcards.resetInfiniteRunState();
        if (result && result.ok === false) {
          alert(result.error || 'No se pudo resetear la run.');
          return;
        }
      }
    } catch (error) {
      alert(`No se pudo resetear la run: ${error?.message || error}`);
      return;
    }

    state.currentFloor = 1;
    state.initialTeamLocked = false;
    state.runActive = false;
    state.runDeckIds = [];
    state.runStats = {
      upgrades: 0,
      riskEvents: 0,
      shopVisits: 0,
      addedFromOutside: 0
    };
    state.runCardBuffs = {};
    state.floorModifiers = {};
    state.consumableItems = [];
    state.runTemporalCards = {};
    state.shopRestocking = false;
    state.claimedMilestones = [];
    state.shopCurrencies['infinite-coins'] = 0;
    state.shopCurrencies['infinite-cardpoints'] = 0;
    try {
      localStorage.removeItem(getInfiniteUserKey('INFINITE_CLAIMED_MILESTONES'));
      localStorage.removeItem('INFINITE_RUN_CONSUMABLES');
      localStorage.removeItem('INFINITE_RUN_TEMPORAL_CARDS');
      localStorage.removeItem('INFINITE_RUN_SHOP_RESTOCKING');
      localStorage.removeItem('INFINITE_FLOOR_MODIFIERS');
      localStorage.removeItem('infinite_saved_team');
    } catch {}
    persistInfiniteCurrencies();
    renderShopCurrencyBar();
    state.selectedInitialCards = [];
    state.selectedInitialCardIds = [];
    state.selectedInitialPowers = [];
    state.selectedInitialPowerIds = [];
    state.initialTeamSnapshot = null;
    state.initialPowersSnapshot = null;
    state.arcWorldAssignments = {};
    state.shopItemStock = {};

    if (Array.isArray(window.selectedTeam)) window.selectedTeam = [];
    if (Array.isArray(window.selectedTeamPowers)) window.selectedTeamPowers = [];
    if (Array.isArray(window.allTeams) && Number.isInteger(window.currentTeamIndex)) {
      window.allTeams[window.currentTeamIndex] = [];
    }
    if (Array.isArray(window.allTeamPowers) && Number.isInteger(window.currentTeamIndex)) {
      window.allTeamPowers[window.currentTeamIndex] = [];
    }

    closeInitialPicker();
    restoreTeamBuilderPoolIfNeeded();
    renderFloorStrip();
    renderMyRankingPreview();
    renderTeamPreview();
    renderTeamPowersPreview();
    renderRunStatus();
    renderInfiniteConsumables();
    updateStartRunButton();

    if (refs.selectTeamBtn) refs.selectTeamBtn.textContent = 'Elegir equipo inicial';
    if (refs.panel) refs.panel.style.display = 'block';
    state.panelOpen = true;
    state.selectingTeam = false;

    closeDecisionModal();
    persistInfiniteRunState();
  }

  async function restoreInfiniteRunState() {
    if (!window.kvrcards || typeof window.kvrcards.loadInfiniteRunState !== 'function') return;

    try {
      const result = await window.kvrcards.loadInfiniteRunState();
      if (!result?.ok || !result.run) return;

      const parsed = result.run;
      if (!parsed || typeof parsed !== 'object') return;

      state.currentFloor = normalizeFloorValue(parsed.currentFloor);
      state.initialTeamLocked = !!parsed.initialTeamLocked;
      state.runActive = !!parsed.runActive;
      state.shopRestocking = !!parsed.shopRestocking || localStorage.getItem('INFINITE_RUN_SHOP_RESTOCKING') === 'true';
      state.runDeckIds = Array.isArray(parsed.runDeckIds) ? [...parsed.runDeckIds] : [];
      state.runStats = sanitizeRunStats(parsed.runStats);
      state.runCardBuffs = sanitizeRunCardBuffs(parsed.runCardBuffs);
      state.selectedInitialCardIds = Array.isArray(parsed.selectedInitialCardIds) ? [...parsed.selectedInitialCardIds] : [];
      state.selectedInitialPowerIds = Array.isArray(parsed.selectedInitialPowerIds) ? [...parsed.selectedInitialPowerIds] : [];
      state.initialTeamSnapshot = Array.isArray(parsed.initialTeamSnapshot)
        ? [...parsed.initialTeamSnapshot]
        : (state.selectedInitialCardIds.length > 0 ? [...state.selectedInitialCardIds] : null);
      state.initialPowersSnapshot = Array.isArray(parsed.initialPowersSnapshot)
        ? [...parsed.initialPowersSnapshot]
        : (state.selectedInitialPowerIds.length > 0 ? [...state.selectedInitialPowerIds] : null);
      if (state.selectedInitialCardIds.length === 0 && Array.isArray(state.initialTeamSnapshot)) {
        state.selectedInitialCardIds = state.initialTeamSnapshot.filter(Boolean).map((id) => String(id));
      }
      if (state.selectedInitialPowerIds.length === 0 && Array.isArray(state.initialPowersSnapshot)) {
        state.selectedInitialPowerIds = state.initialPowersSnapshot.filter(Boolean).map((id) => String(id));
      }

      // Sincronizar reactivamente a infinite_saved_team local para que siempre esté disponible
      if (state.selectedInitialPowerIds.length >= 3 || (Array.isArray(state.selectedInitialCardIds) && state.selectedInitialCardIds.length >= 8)) {
        try {
          const teamKey = getInfiniteUserKey('infinite_saved_team');
          const raw = localStorage.getItem(teamKey) || localStorage.getItem('infinite_saved_team');
          const current = raw ? JSON.parse(raw) : {};
          if (state.selectedInitialPowerIds.length >= 3) {
            current.powers = state.selectedInitialPowerIds.slice(0, 3);
            current.powerIds = state.selectedInitialPowerIds.slice(0, 3);
          }
          if (Array.isArray(state.selectedInitialCardIds) && state.selectedInitialCardIds.length >= 8) {
            current.team = state.selectedInitialCardIds.slice(0, 8);
            current.cardIds = state.selectedInitialCardIds.slice(0, 8);
          }
          current.timestamp = new Date().toISOString();
          localStorage.setItem(teamKey, JSON.stringify(current));
        } catch (e) {}
      }

      if (Array.isArray(parsed.consumableItems)) {
        state.consumableItems = [...parsed.consumableItems];
      } else {
        try {
          state.consumableItems = JSON.parse(localStorage.getItem('INFINITE_RUN_CONSUMABLES') || '[]');
        } catch {
          state.consumableItems = [];
        }
      }
      if (parsed.runTemporalCards && typeof parsed.runTemporalCards === 'object') {
        state.runTemporalCards = { ...parsed.runTemporalCards };
      } else {
        try {
          state.runTemporalCards = JSON.parse(localStorage.getItem('INFINITE_RUN_TEMPORAL_CARDS') || '{}');
        } catch {
          state.runTemporalCards = {};
        }
      }
      if (state.runTemporalCards && typeof state.runTemporalCards === 'object') {
        Object.entries(state.runTemporalCards).forEach(([id, card]) => {
          if (card && id) {
            state.catalogCardsById[id] = card;
          }
        });
      }
      if (parsed.floorModifiers && typeof parsed.floorModifiers === 'object') {
        state.floorModifiers = { ...parsed.floorModifiers };
      } else {
        try {
          state.floorModifiers = JSON.parse(localStorage.getItem('INFINITE_FLOOR_MODIFIERS') || '{}');
        } catch {
          state.floorModifiers = {};
        }
      }
      if (Array.isArray(parsed.claimedMilestones)) {
        state.claimedMilestones = [...parsed.claimedMilestones];
      } else {
        try {
          state.claimedMilestones = JSON.parse(localStorage.getItem(getInfiniteUserKey('INFINITE_CLAIMED_MILESTONES')) || '[]');
        } catch {
          state.claimedMilestones = [];
        }
      }
      renderInfiniteConsumables();
      state.arcWorldAssignments = parsed.arcWorldAssignments && typeof parsed.arcWorldAssignments === 'object'
        ? { ...parsed.arcWorldAssignments }
        : {};

      console.log('[INFINITE] Progreso de run restaurado:', {
        floor: state.currentFloor,
        runActive: state.runActive,
        locked: state.initialTeamLocked
      });
    } catch (error) {
      console.warn('[INFINITE] No se pudo restaurar el progreso remoto de run:', error?.message || error);
    }
  }

  function getTrainerRoleByFloor(floor) {
    const combat = getCombatNumberByFloor(floor);
    if (combat === 10) return 'boss';
    if (combat === 5) return 'mini-boss';
    return 'normal';
  }

  function getTrainerRoleLabel(role) {
    if (role === 'boss') return '✦✦ BOSS ✦✦';
    if (role === 'mini-boss') return '✧ MINI-BOSS ✧';
    return 'COMBATE';
  }

  function ensureTrainerPreviewModal() {
    if (refs.trainerPreviewModal) return;

    const modal = document.createElement('div');
    modal.id = 'infinite-trainer-preview-modal';
    modal.className = 'infinite-trainer-preview-modal';
    modal.style.display = 'none';

    modal.innerHTML = `
      <div class="infinite-trainer-preview-backdrop"></div>
      <div class="infinite-trainer-preview-card" role="dialog" aria-modal="true" aria-label="Vista del entrenador">
        <button class="infinite-trainer-preview-close" type="button" aria-label="Cerrar">✕</button>
        <div id="infinite-trainer-preview-title" class="infinite-trainer-preview-title">ENTRENADOR</div>
        <div class="infinite-trainer-preview-image-wrap">
          <img id="infinite-trainer-preview-image" class="infinite-trainer-preview-image" alt="Entrenador" />
        </div>
        <div id="infinite-trainer-preview-level" class="infinite-trainer-preview-level">NIVEL 1</div>
      </div>
    `;

    document.body.appendChild(modal);

    const closeBtn = modal.querySelector('.infinite-trainer-preview-close');
    const backdrop = modal.querySelector('.infinite-trainer-preview-backdrop');

    function closeModal() {
      modal.style.display = 'none';
    }

    closeBtn?.addEventListener('click', closeModal);
    backdrop?.addEventListener('click', closeModal);
    modal.addEventListener('click', (event) => {
      if (event.target === modal) closeModal();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && modal.style.display !== 'none') closeModal();
    });

    refs.trainerPreviewModal = modal;
    refs.trainerPreviewImage = modal.querySelector('#infinite-trainer-preview-image');
    refs.trainerPreviewTitle = modal.querySelector('#infinite-trainer-preview-title');
    refs.trainerPreviewLevel = modal.querySelector('#infinite-trainer-preview-level');
  }

  function resolveTraitFromCardMeta(cardMeta = {}) {
    const uniqueId = String(cardMeta?.uniqueId || '').trim();
    const cardId = String(cardMeta?.cardId || '').trim();

    if (uniqueId && uniqueId.includes('_notrait')) return null;

    let traitId = '';
    if (cardMeta?.traitId) {
      traitId = String(cardMeta.traitId).trim();
    }

    if (!traitId && typeof cardTraitsMap !== 'undefined' && cardTraitsMap && typeof cardTraitsMap === 'object') {
      const raw = cardId ? cardTraitsMap[cardId] : null;
      if (raw) {
        traitId = String(raw?.traitId || raw || '').trim();
      }
    }

    if (!traitId || typeof availableTraits === 'undefined' || !Array.isArray(availableTraits)) return null;
    const trait = availableTraits.find((t) => String(t?.id || '') === traitId);
    if (!trait) return null;

    return {
      id: traitId,
      name: String(trait?.name || 'Rasgo'),
      imageUrl: String(trait?.imageUrl || './trait.png'),
      description: String(trait?.description || ''),
      stats: trait?.stats && typeof trait.stats === 'object' ? trait.stats : null
    };
  }

  const INFINITE_STAT_DEFS = [
    { key: 'ninjutsu', label: 'Ninjutsu', index: 0, aliases: ['ninjutsu', 'ninjutsu_base', 'stat1'] },
    { key: 'taijutsu', label: 'Taijutsu', index: 1, aliases: ['taijutsu', 'taijutsu_base', 'stat2'] },
    { key: 'resistencia', label: 'Resistencia', index: 2, aliases: ['resistencia', 'resistencia_base', 'stat3'] },
    { key: 'velocidad', label: 'Velocidad', index: 3, aliases: ['velocidad', 'speed', 'velocidad_base', 'speed_base', 'stat4'] },
    { key: 'defensa', label: 'Defensa', index: 4, aliases: ['defensa', 'defensa_base', 'stat5'] },
    { key: 'fisico', label: 'Fisico', index: 5, aliases: ['fisico', 'fisico_base', 'stat6'] }
  ];

  function extractCardStatsForInfinite(rawCard = {}) {
    const rawStatsArray = Array.isArray(rawCard?.stats)
      ? rawCard.stats
      : (Array.isArray(rawCard?.parametros) ? rawCard.parametros : []);
    const srcStats = rawCard?.stats && typeof rawCard.stats === 'object' ? rawCard.stats : null;
    const pick = (keys = []) => {
      if (keys.length > 0 && rawStatsArray.length > 0) {
        const last = String(keys[keys.length - 1] || '');
        const m = /^stat([1-6])$/i.exec(last);
        if (m) {
          const index = Number(m[1]) - 1;
          const arrayValue = Number(rawStatsArray[index]);
          if (Number.isFinite(arrayValue) && arrayValue > 0) return Math.round(arrayValue);
        }
      }

      for (const key of keys) {
        const direct = Number(rawCard?.[key]);
        if (Number.isFinite(direct) && direct > 0) return Math.round(direct);
        const fromStats = Number(srcStats?.[key]);
        if (Number.isFinite(fromStats) && fromStats > 0) return Math.round(fromStats);
      }
      return 0;
    };

    return {
      stat1: pick(['stat1', 'ninjutsu', 'ninjutsu_base']),
      stat2: pick(['stat2', 'taijutsu', 'taijutsu_base']),
      stat3: pick(['stat3', 'resistencia', 'resistencia_base']),
      stat4: pick(['stat4', 'velocidad', 'speed', 'velocidad_base', 'speed_base']),
      stat5: pick(['stat5', 'defensa', 'defensa_base']),
      stat6: pick(['stat6', 'fisico', 'fisico_base'])
    };
  }

  function resolveCardDataFromMeta(cardMeta = {}) {
    const uniqueId = String(cardMeta?.uniqueId || '').trim();
    const rawCardId = String(cardMeta?.cardId || '').trim();
    const baseCardId = extractBaseCardId(rawCardId || uniqueId);
    const catalogMap = state.catalogCardsById && typeof state.catalogCardsById === 'object' ? state.catalogCardsById : {};
    const pool = Array.isArray(window.teamBuilderCards) ? window.teamBuilderCards : [];

    const byUnique = uniqueId
      ? pool.find((card) => String(card?.uniqueId || card?.id || '') === uniqueId)
      : null;

    if (byUnique) {
      const resolvedId = String(byUnique?.id || baseCardId || '');
      return { card: catalogMap[resolvedId] || byUnique, cardId: resolvedId };
    }

    const byBase = baseCardId
      ? pool.find((card) => String(card?.id || '') === baseCardId)
      : null;

    if (byBase) {
      const resolvedId = String(byBase?.id || baseCardId || '');
      return { card: catalogMap[resolvedId] || byBase, cardId: resolvedId };
    }

    if (baseCardId && catalogMap[baseCardId]) {
      return { card: catalogMap[baseCardId], cardId: String(baseCardId) };
    }

    const byInventory = (Array.isArray(state.inventoryCards) ? state.inventoryCards : []).find((card) => String(card?.id || '') === baseCardId);
    return { card: byInventory || null, cardId: String(baseCardId || '') };
  }

  function getCardBaseStatValue(cardData, statDef) {
    if (!cardData || !statDef) return 0;

    const statsArray = Array.isArray(cardData?.stats)
      ? cardData.stats
      : (Array.isArray(cardData?.parametros) ? cardData.parametros : null);
    if (statsArray && Number.isInteger(statDef.index) && statDef.index >= 0 && statDef.index < statsArray.length) {
      const fromArray = Number(statsArray[statDef.index]);
      if (Number.isFinite(fromArray) && fromArray > 0) return Math.round(fromArray);
    }

    const aliases = Array.isArray(statDef.aliases) ? statDef.aliases : [statDef.key];

    for (const alias of aliases) {
      const value = Number(cardData?.[alias]);
      if (Number.isFinite(value) && value > 0) return Math.round(value);
    }

    return 0;
  }

  function buildCardStatsRows(cardMeta = {}) {
    const resolved = resolveCardDataFromMeta(cardMeta);
    const cardData = resolved.card;
    const cardId = String(resolved.cardId || '').trim();
    const buffs = cardId ? (state.runCardBuffs?.[cardId] || {}) : {};

    return INFINITE_STAT_DEFS.map((statDef) => {
      const base = getCardBaseStatValue(cardData, statDef);
      const buff = Number(buffs?.[statDef.key]) || 0;
      if (base <= 0 && buff === 0) return null;
      return {
        label: statDef.label,
        base,
        buff,
        total: Math.max(1, base + buff)
      };
    }).filter(Boolean);
  }

  function ensureInfiniteCardZoomModal() {
    if (refs.cardZoomModal) return;

    const modal = document.createElement('div');
    modal.id = 'infinite-card-zoom-modal';
    modal.className = 'infinite-card-zoom-modal';
    modal.style.display = 'none';
    modal.innerHTML = `
      <div class="infinite-card-zoom-backdrop"></div>
      <div class="infinite-card-zoom-content" role="dialog" aria-modal="true" aria-label="Zoom carta modo infinito">
        <button class="infinite-card-zoom-close" type="button" aria-label="Cerrar">✕</button>
        <div class="infinite-card-zoom-trait" id="infinite-card-zoom-trait"></div>
        <div class="infinite-card-zoom-stats" id="infinite-card-zoom-stats"></div>
        <img id="infinite-card-zoom-image" class="infinite-card-zoom-image" alt="Carta" />
      </div>
    `;

    document.body.appendChild(modal);

    const closeBtn = modal.querySelector('.infinite-card-zoom-close');
    const backdrop = modal.querySelector('.infinite-card-zoom-backdrop');
    const content = modal.querySelector('.infinite-card-zoom-content');

    const closeModal = () => {
      if (!refs.cardZoomModal) return;
      refs.cardZoomModal.style.display = 'none';
      if (refs.cardZoomImage) {
        refs.cardZoomImage.src = '';
        refs.cardZoomImage.alt = 'Carta';
      }
      if (refs.cardZoomTrait) refs.cardZoomTrait.innerHTML = '';
      if (refs.cardZoomStats) refs.cardZoomStats.innerHTML = '';
    };

    closeBtn?.addEventListener('click', closeModal);
    backdrop?.addEventListener('click', closeModal);
    modal.addEventListener('click', (event) => {
      if (event.target === modal) closeModal();
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && refs.cardZoomModal?.style.display === 'flex') {
        closeModal();
      }
    });

    refs.cardZoomModal = modal;
    refs.cardZoomContent = content;
    refs.cardZoomImage = modal.querySelector('#infinite-card-zoom-image');
    refs.cardZoomTrait = modal.querySelector('#infinite-card-zoom-trait');
    refs.cardZoomStats = modal.querySelector('#infinite-card-zoom-stats');
    refs.closeInfiniteCardZoom = closeModal;
  }

  function openInfiniteCardZoom(imageUrl, cardMeta = {}) {
    const src = String(imageUrl || '').trim();
    if (!src) return;

    ensureInfiniteCardZoomModal();
    if (!refs.cardZoomModal || !refs.cardZoomImage || !refs.cardZoomTrait || !refs.cardZoomStats) return;

    const trait = resolveTraitFromCardMeta(cardMeta);
    if (trait) {
      const statText = trait.stats
        ? Object.entries(trait.stats).map(([key, value]) => `${key}: +${value}`).join(' | ')
        : '';
      refs.cardZoomTrait.innerHTML = `
        <div class="infinite-card-zoom-trait-head">
          <img src="${trait.imageUrl}" alt="${trait.name}">
          <div>
            <h4>${trait.name}</h4>
            <p>${trait.description || 'Rasgo activo en esta carta.'}</p>
          </div>
        </div>
        ${statText ? `<div class="infinite-card-zoom-trait-stats">${statText}</div>` : ''}
      `;
      refs.cardZoomTrait.style.display = 'block';
    } else {
      refs.cardZoomTrait.innerHTML = '';
      refs.cardZoomTrait.style.display = 'none';
    }

    const statRows = buildCardStatsRows(cardMeta);
    if (statRows.length > 0) {
      refs.cardZoomStats.innerHTML = `
        <div class="infinite-card-zoom-stats-title">Stats actualizadas</div>
        <div class="infinite-card-zoom-stats-table">
          ${statRows.map((row) => `
            <div class="infinite-card-zoom-stats-row">
              <span class="infinite-card-zoom-stats-label">${row.label}</span>
              <span class="infinite-card-zoom-stats-value">
                <strong>${row.total}</strong>
                ${row.buff !== 0 ? `<em class="${row.buff > 0 ? 'is-positive' : 'is-negative'}">${row.buff > 0 ? '+' : ''}${row.buff}</em><small>base ${row.base}</small>` : `<small>base ${row.base}</small>`}
              </span>
            </div>
          `).join('')}
        </div>
      `;
    } else {
      refs.cardZoomStats.innerHTML = '<div class="infinite-card-zoom-stats-title">Stats actualizadas</div><div class="infinite-card-zoom-stats-empty">No hay stats disponibles para esta carta.</div>';
    }

    refs.cardZoomImage.src = src;
    refs.cardZoomImage.alt = String(cardMeta?.name || 'Carta');
    refs.cardZoomModal.style.display = 'flex';
  }

  function attachInfiniteCardZoom(targetImage, cardMeta = {}) {
    if (!targetImage) return;
    targetImage.classList.add('infinite-zoomable-card');
    targetImage.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      openInfiniteCardZoom(targetImage.src, cardMeta);
    });
  }

  function openTrainerPreview(data) {
    ensureTrainerPreviewModal();

    const absoluteFloor = Number(data?.floor) || Number(data?.relativeLevel) || 1;
    const trainerName = String(data?.trainerName || 'Entrenador').trim();
    const trainerImage = String(data?.trainerImage || '').trim();
    const relativeLevel = Number(data?.relativeLevel) || 1;
    const role = getTrainerRoleByFloor(absoluteFloor);

    if (refs.trainerPreviewTitle) {
      refs.trainerPreviewTitle.textContent = trainerName.toUpperCase();
    }

    if (refs.trainerPreviewImage) {
      refs.trainerPreviewImage.src = trainerImage || '';
      refs.trainerPreviewImage.alt = trainerName || 'Entrenador';
      refs.trainerPreviewImage.onerror = function () {
        refs.trainerPreviewImage.src = 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22512%22 height=%22512%22%3E%3Crect width=%22100%25%22 height=%22100%25%22 fill=%22%230f172a%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%23e2e8f0%22 font-size=%2242%22%3EENTRENADOR%3C/text%3E%3C/svg%3E';
      };
    }

    if (refs.trainerPreviewLevel) {
      refs.trainerPreviewLevel.classList.remove('mini-boss', 'boss');
      if (role === 'mini-boss') refs.trainerPreviewLevel.classList.add('mini-boss');
      if (role === 'boss') refs.trainerPreviewLevel.classList.add('boss');
      refs.trainerPreviewLevel.textContent = `NIVEL ${relativeLevel} · ${getTrainerRoleLabel(role)}`;
    }

    if (refs.trainerPreviewModal) {
      refs.trainerPreviewModal.style.display = 'flex';
    }
  }

  function byId(id) {
    return document.getElementById(id);
  }

  function toRawGithubUrl(url) {
    const input = String(url || '').trim();
    if (!input) return input;

    try {
      const parsed = new URL(input);
      if (parsed.hostname !== 'github.com') return input;

      const parts = parsed.pathname.split('/').filter(Boolean);
      if (parts.length < 3) return input;

      const owner = parts[0];
      const repo = parts[1];
      let branch = 'main';
      let fileParts = [];

      if (parts[2] === 'blob' || parts[2] === 'raw') {
        branch = parts[3] || 'main';
        fileParts = parts.slice(4);
      } else {
        branch = parts[2] || 'main';
        fileParts = parts.slice(3);
      }

      if (fileParts.length === 0) return input;
      return `https://raw.githubusercontent.com/${owner}/${repo}/${branch}/${fileParts.join('/')}`;
    } catch {
      return input;
    }
  }

  function withCacheBuster(url) {
    const normalized = toRawGithubUrl(url);
    const separator = String(normalized || '').includes('?') ? '&' : '?';
    return `${normalized}${separator}t=${Date.now()}`;
  }

  function resolveAssetUrl(value, baseUrl) {
    const input = String(value || '').trim();
    if (!input) return '';

    if (/^(https?:|data:|blob:)/i.test(input)) return input;

    if (!baseUrl) return input;

    try {
      return new URL(input, baseUrl).toString();
    } catch {
      return input;
    }
  }

  function resolveSongUrl(value, baseUrl) {
    const input = String(value || '').trim();
    if (!input) return '';

    // Si es una URL completa (http / https), normalizar URLs de GitHub
    if (/^https?:\/\//i.test(input)) {
      return toRawGithubUrl(input);
    }

    // Si es una ruta local del juego en public/music/
    if (/^\.?\/?music\//i.test(input)) {
      return input.replace(/^\.\//, '').replace(/^\//, '');
    }

    // Si es relativa a la fuente del JSON remoto de GitHub
    if (baseUrl) {
      try {
        const resolved = new URL(input, baseUrl).toString();
        return toRawGithubUrl(resolved);
      } catch {
        return input;
      }
    }

    return input;
  }

  function normalizeSongList(rawSong, sourceUrl) {
    if (!rawSong) return [];
    let items = [];
    if (Array.isArray(rawSong)) {
      items = rawSong;
    } else if (typeof rawSong === 'string') {
      items = [rawSong];
    }
    return items
      .map(s => resolveSongUrl(s, sourceUrl))
      .filter(s => typeof s === 'string' && s.trim().length > 0);
  }

  function normalizeWorldConfig(rawConfig, sourceUrl) {
    const source = rawConfig && typeof rawConfig === 'object' ? rawConfig : FALLBACK_WORLD_CONFIG;
    const sourceWorlds = Array.isArray(source.worlds) ? source.worlds : [];

    const worlds = sourceWorlds
      .map((world, index) => {
        const id = String(world?.id || `world-${index + 1}`).trim();
        if (!id) return null;

        const baseWorldImage = resolveAssetUrl(world?.worldImage || world?.arcImage || '', sourceUrl);
        const rawWorldMusic = world?.battleMusic || world?.battleSong || world?.battleSongs || world?.cancion || world?.canciones || world?.musica || world?.music || world?.songs || null;
        const worldBattleSongs = normalizeSongList(rawWorldMusic, sourceUrl);

        const normalizedBots = Array.isArray(world?.bots)
          ? world.bots.map((bot, botIndex) => ({
            id: String(bot?.id || `${id}-bot-${botIndex + 1}`),
            name: String(bot?.name || `Bot ${botIndex + 1}`),
            image: resolveAssetUrl(bot?.image || '', sourceUrl)
          }))
          : [];

        const normalizedLevels = Array.isArray(world?.levels)
          ? world.levels.slice(0, 10).map((level, levelIndex) => {
            const levelNumber = Number(level?.number) || (levelIndex + 1);
            const rawTrainerMusic = level?.trainer?.song || level?.trainer?.cancion || level?.trainer?.canciones || level?.trainer?.musica || level?.trainer?.battleSong || level?.trainer?.battleMusic || null;
            const rawLevelMusic = level?.battleMusic || level?.battleSong || level?.battleSongs || level?.cancion || level?.canciones || level?.musica || level?.song || level?.songs || rawTrainerMusic || null;
            const levelBattleSongs = normalizeSongList(rawLevelMusic, sourceUrl);
            const trainerBattleSongs = normalizeSongList(rawTrainerMusic, sourceUrl);

            const trainer = level?.trainer && typeof level.trainer === 'object'
              ? {
                id: String(level.trainer.id || `${id}-trainer-${levelNumber}`),
                name: String(level.trainer.name || `Entrenador ${levelNumber}`),
                image: resolveAssetUrl(level.trainer.image || '', sourceUrl),
                battleSongs: trainerBattleSongs
              }
              : null;

            return {
              id: String(level?.id || `${id}-level-${levelNumber}`),
              number: levelNumber,
              name: String(level?.name || `Nivel ${levelNumber}`),
              arcImage: resolveAssetUrl(level?.arcImage || level?.levelImage || baseWorldImage, sourceUrl),
              battleSongs: levelBattleSongs,
              trainer: trainer || {
                id: `${id}-trainer-${levelNumber}`,
                name: normalizedBots[levelIndex % Math.max(1, normalizedBots.length)]?.name || `Entrenador ${levelNumber}`,
                image: normalizedBots[levelIndex % Math.max(1, normalizedBots.length)]?.image || '',
                battleSongs: []
              }
            };
          })
          : Array.from({ length: 10 }, (_, levelIndex) => {
            const levelNumber = levelIndex + 1;
            const bot = normalizedBots[levelIndex % Math.max(1, normalizedBots.length)] || {};
            return {
              id: `${id}-level-${levelNumber}`,
              number: levelNumber,
              name: `Nivel ${levelNumber}`,
              arcImage: baseWorldImage,
              battleSongs: [],
              trainer: {
                id: String(bot.id || `${id}-trainer-${levelNumber}`),
                name: String(bot.name || `Entrenador ${levelNumber}`),
                image: String(bot.image || ''),
                battleSongs: []
              }
            };
          });

        while (normalizedLevels.length < 10) {
          const levelNumber = normalizedLevels.length + 1;
          normalizedLevels.push({
            id: `${id}-level-${levelNumber}`,
            number: levelNumber,
            name: `Nivel ${levelNumber}`,
            arcImage: baseWorldImage,
            battleSongs: [],
            trainer: {
              id: `${id}-trainer-${levelNumber}`,
              name: `Entrenador ${levelNumber}`,
              image: '',
              battleSongs: []
            }
          });
        }

        return {
          id,
          name: String(world?.name || `Mundo ${index + 1}`),
          worldImage: baseWorldImage,
          fallback: String(world?.fallback || 'linear-gradient(135deg, #111827, #334155)'),
          battleSongs: worldBattleSongs,
          levels: normalizedLevels,
          bots: normalizedBots
        };
      })
      .filter(Boolean);

    if (worlds.length === 0) {
      return normalizeWorldConfig(FALLBACK_WORLD_CONFIG);
    }

    const worldIds = new Set(worlds.map((world) => world.id));
    const configuredOrder = Array.isArray(source.worldOrder)
      ? source.worldOrder.map((id) => String(id)).filter((id) => worldIds.has(id))
      : [];

    const worldOrder = configuredOrder.length > 0 ? configuredOrder : worlds.map((world) => world.id);
    const rawRootMusic = source.battleMusic || source.battleSong || source.battleSongs || source.cancion || source.canciones || source.musica || source.music || source.songs || null;
    const rootBattleSongs = normalizeSongList(rawRootMusic, sourceUrl);

    return {
      version: Number(source.version) || 1,
      battleSongs: rootBattleSongs,
      worlds,
      worldsById: Object.fromEntries(worlds.map((world) => [world.id, world])),
      worldOrder
    };
  }

  function pickBattleSongForFloor(floorNumber) {
    const activeLevel = getLevelByFloor(floorNumber);
    const activeTheme = getThemeByFloor(floorNumber);
    const activeTrainer = getTrainerByFloor(floorNumber);

    // 1. Prioridad: nivel o entrenador específico
    const levelSongs = (activeLevel?.battleSongs?.length > 0)
      ? activeLevel.battleSongs
      : (activeTrainer?.battleSongs?.length > 0 ? activeTrainer.battleSongs : []);

    if (levelSongs.length > 0) {
      return levelSongs[Math.floor(Math.random() * levelSongs.length)];
    }

    // 2. Prioridad: mundo / tema activo
    const worldSongs = activeTheme?.battleSongs || [];
    if (worldSongs.length > 0) {
      return worldSongs[Math.floor(Math.random() * worldSongs.length)];
    }

    // 3. Prioridad: configuración global del modo infinito (root en infinite-worlds.json)
    const rootSongs = state.worldConfig?.battleSongs || [];
    if (rootSongs.length > 0) {
      return rootSongs[Math.floor(Math.random() * rootSongs.length)];
    }

    return null;
  }

  async function loadInfiniteWorldConfig() {
    state.worldConfig = normalizeWorldConfig(FALLBACK_WORLD_CONFIG);
    try {
      const response = await fetch(withCacheBuster(INFINITE_WORLDS_REMOTE_URL));
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      state.worldConfig = normalizeWorldConfig(data, response.url || INFINITE_WORLDS_REMOTE_URL);
      state.arcWorldAssignments = {};
      console.log('[INFINITE] Configuracion remota cargada:', {
        version: state.worldConfig.version,
        worlds: state.worldConfig.worlds.length,
        order: state.worldConfig.worldOrder
      });
    } catch (error) {
      console.warn('[INFINITE] No se pudo cargar configuracion remota, usando fallback local:', error?.message || error);
    }
  }

  function getArcIndexByFloor(floor) {
    const safeFloor = normalizeFloorValue(floor);
    return Math.floor((safeFloor - 1) / NODES_PER_ARC);
  }

  function normalizeFloorValue(floor) {
    const parsed = Number(floor);
    if (!Number.isFinite(parsed) || parsed < 1) return 1;
    return Math.floor(parsed);
  }

  function getRelativeNodeInArc(floor) {
    const safeFloor = normalizeFloorValue(floor);
    return ((safeFloor - 1) % NODES_PER_ARC) + 1;
  }

  function getCombatNumberByFloor(floor) {
    const node = getRelativeNodeInArc(floor);
    if (DECISION_NODE_POSITIONS.has(node) || node === REWARD_NODE_POSITION) return null;
    if (node < 5) return node;
    if (node < 11) return node - 1;
    if (node < 13) return 10;
    return null;
  }

  function getGlobalCombatNumberByFloor(floor) {
    const localCombat = getCombatNumberByFloor(floor);
    if (!localCombat) return null;
    const arcIndex = getArcIndexByFloor(floor);
    return (arcIndex * 10) + localCombat;
  }

  function isRewardFloor(floor) {
    const rel = getRelativeNodeInArc(floor);
    return rel === REWARD_NODE_POSITION;
  }

  function getWorldForArc(arcIndex) {
    const config = state.worldConfig || normalizeWorldConfig(FALLBACK_WORLD_CONFIG);
    const worldOrder = config.worldOrder || [];
    const worldPool = worldOrder.length > 0 ? worldOrder : config.worlds.map((world) => world.id);
    const safeArcIndex = Number.isFinite(Number(arcIndex)) ? Math.max(0, Math.floor(Number(arcIndex))) : 0;

    if (worldPool.length === 0) {
      return {
        id: 'fallback-world',
        name: 'Arco sin configurar',
        worldImage: '',
        fallback: 'linear-gradient(135deg, #111827, #334155)',
        bots: []
      };
    }

    let worldId = null;

    if (safeArcIndex < worldOrder.length) {
      worldId = worldOrder[safeArcIndex];
    } else {
      if (!state.arcWorldAssignments[safeArcIndex]) {
        const randomId = worldPool[Math.floor(Math.random() * worldPool.length)];
        state.arcWorldAssignments[safeArcIndex] = randomId;
      }
      worldId = state.arcWorldAssignments[safeArcIndex];
    }

    return config.worldsById[worldId] || config.worlds[0];
  }

  function getThemeByFloor(floor) {
    return getWorldForArc(getArcIndexByFloor(floor));
  }

  function getLevelByFloor(floor) {
    const world = getThemeByFloor(floor);
    const combatNumber = getCombatNumberByFloor(floor);
    if (!combatNumber) return null;
    const levelIndex = Math.max(0, Math.min(9, combatNumber - 1));
    return world?.levels?.[levelIndex] || null;
  }

  function getTrainerByFloor(floor) {
    return getLevelByFloor(floor)?.trainer || null;
  }

  function floorTag(floor) {
    if (isRewardFloor(floor)) return 'RECOMPENSA';
    if (isDecisionFloor(floor)) return 'DECISION';
    return 'COMBATE';
  }

  function floorPhaseLabel(floor) {
    if (isRewardFloor(floor)) return 'Nodo de recompensa (post-boss)';
    if (isDecisionFloor(floor)) return 'Nodo de decision (no combate)';
    const localCombat = getCombatNumberByFloor(floor) || 1;
    const globalCombat = getGlobalCombatNumberByFloor(floor) || localCombat;
    if (localCombat === 10) return `Combate ${globalCombat} (Boss)`;
    return `Combate ${globalCombat}`;
  }

  function getRelativeFloor(floor) {
    return getRelativeNodeInArc(floor);
  }

  function isDecisionFloor(floor) {
    const rel = getRelativeNodeInArc(floor);
    return DECISION_NODE_POSITIONS.has(rel);
  }

  function isBossFloor(floor) {
    return !isDecisionFloor(floor) && !isRewardFloor(floor) && getCombatNumberByFloor(floor) === 10;
  }

  function getDecisionContextByFloor(floor) {
    const node = getRelativeNodeInArc(floor);
    const arcBase = getArcIndexByFloor(floor) * 10;

    if (node === 5) {
      return {
        afterCombat: arcBase + 4,
        nextCombat: arcBase + 5
      };
    }

    if (node === 11) {
      return {
        afterCombat: arcBase + 9,
        nextCombat: arcBase + 10
      };
    }

    const fallback = getGlobalCombatNumberByFloor(floor) || (arcBase + 1);
    return {
      afterCombat: fallback,
      nextCombat: fallback
    };
  }

  function getDisplayLevelNumberByFloor(floor) {
    if (isDecisionFloor(floor)) {
      return getDecisionContextByFloor(floor).afterCombat;
    }
    if (isRewardFloor(floor)) {
      return (getArcIndexByFloor(floor) * 10) + 10;
    }
    return getGlobalCombatNumberByFloor(floor) || 1;
  }

  function getCurrentLocationName() {
    const world = getThemeByFloor(state.currentFloor);
    const trainer = getTrainerByFloor(state.currentFloor);
    if (isRewardFloor(state.currentFloor)) {
      return `${world.name} - Recompensa post-boss`;
    }
    if (isDecisionFloor(state.currentFloor)) {
      const { afterCombat } = getDecisionContextByFloor(state.currentFloor);
      return `${world.name} - Decision tras combate ${afterCombat}`;
    }
    const combat = getGlobalCombatNumberByFloor(state.currentFloor) || 1;
    const trainerName = trainer?.name ? ` | ${trainer.name}` : '';
    return `${world.name} - Nivel ${combat}${trainerName}`;
  }

  function renderFloorStrip() {
    if (!refs.floorStrip) return;

    refs.floorStrip.innerHTML = '';

    let floorsToRender = [];
    if (state.currentFloor <= 1) {
      floorsToRender = [1, 2, 3];
    } else if (state.currentFloor === 2) {
      floorsToRender = [1, 2, 3, 4];
    } else {
      floorsToRender = [
        state.currentFloor - 2,
        state.currentFloor - 1,
        state.currentFloor,
        state.currentFloor + 1,
        state.currentFloor + 2
      ];
    }

    refs.floorStrip.style.setProperty('--floor-columns', String(floorsToRender.length));

    for (const floor of floorsToRender) {
      const theme = getThemeByFloor(floor);
      const level = getLevelByFloor(floor);
      const trainer = getTrainerByFloor(floor);
      const rewardNode = isRewardFloor(floor);
      const decisionNode = isDecisionFloor(floor);
      const card = document.createElement('div');
      card.className = 'infinite-floor-card' + (floor === state.currentFloor ? ' current' : '');
      if (rewardNode) {
        card.classList.add('reward-node');
        card.style.backgroundImage = 'linear-gradient(135deg, rgba(250, 204, 21, 0.94), rgba(245, 158, 11, 0.9))';
      } else {
        const floorImage = level?.arcImage || theme.worldImage;
        card.style.backgroundImage = floorImage
          ? `${theme.fallback}, url('${floorImage}')`
          : theme.fallback;
      }

      const number = document.createElement('div');
      number.className = 'floor-number';
      if (decisionNode || rewardNode) {
        number.textContent = '';
        number.style.display = 'none';
      } else {
        number.textContent = String(getGlobalCombatNumberByFloor(floor) || 1);
      }

      const tag = document.createElement('div');
      tag.className = 'floor-tag';
      tag.textContent = floorTag(floor);
      if (rewardNode) tag.classList.add('reward');
      if (decisionNode) tag.classList.add('decision');

      const trainerLabel = document.createElement('div');
      trainerLabel.className = 'floor-tag floor-trainer';
      trainerLabel.textContent = rewardNode
        ? 'Nodo de recompensa'
        : decisionNode
          ? 'Nodo de decision'
          : (trainer?.name || 'Entrenador');

      let trainerAvatar = null;
      if (!decisionNode && !rewardNode) {
        trainerAvatar = document.createElement('div');
        trainerAvatar.className = 'floor-trainer-avatar';
        trainerAvatar.title = trainer?.name || 'Entrenador';
        trainerAvatar.setAttribute('role', 'button');
        trainerAvatar.setAttribute('tabindex', '0');

        const relativeLevel = getGlobalCombatNumberByFloor(floor) || (level?.number || getCombatNumberByFloor(floor) || 1);

        function openAvatarPreview() {
          openTrainerPreview({
            trainerName: trainer?.name || 'Entrenador',
            trainerImage: trainer?.image || '',
            floor,
            relativeLevel
          });
        }

        trainerAvatar.addEventListener('click', openAvatarPreview);
        trainerAvatar.addEventListener('keydown', (event) => {
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            openAvatarPreview();
          }
        });

        if (trainer?.image) {
          const trainerImg = document.createElement('img');
          trainerImg.src = trainer.image;
          trainerImg.alt = trainer?.name || 'Entrenador';
          trainerImg.loading = 'lazy';
          trainerImg.onerror = function () {
            trainerAvatar.innerHTML = '<span style="font-size:12px;font-weight:900;color:#cbd5e1;">VS</span>';
            trainerAvatar.classList.add('fallback');
          };
          trainerAvatar.appendChild(trainerImg);
        } else {
          trainerAvatar.innerHTML = '<span style="font-size:12px;font-weight:900;color:#cbd5e1;">VS</span>';
          trainerAvatar.classList.add('fallback');
        }

        // Recompensas en esquina superior derecha de recuadros de combate
        const combatNumber = getCombatNumberByFloor(floor);
        const role = getTrainerRoleByFloor(floor);
        const globalCombat = getGlobalCombatNumberByFloor(floor) || 1;

        const rewardsPreview = document.createElement('div');
        rewardsPreview.className = 'floor-rewards-preview';

        if (role === 'boss') {
          rewardsPreview.innerHTML = `
            <span class="floor-reward-pill" title="2-3 Infinite Coins">2 <img src="./infinite-coin.png" alt="coin" /></span>
            <span class="floor-reward-pill" title="1-2 Infinite Card Points">1 <img src="./infinite-cardpoint.png" alt="cardpoint" /></span>
          `;
        } else if (role === 'mini-boss' || role === 'miniboss') {
          rewardsPreview.innerHTML = `
            <span class="floor-reward-pill" title="2 Infinite Coins">2 <img src="./infinite-coin.png" alt="coin" /></span>
          `;
        } else {
          rewardsPreview.innerHTML = `
            <span class="floor-reward-pill" title="1-2 Infinite Coins">1 <img src="./infinite-coin.png" alt="coin" /></span>
          `;
        }

        if (globalCombat >= 101) {
          rewardsPreview.innerHTML += `
            <span class="floor-reward-pill" title="+1 Trait asegurado">1 <img src="./trait.png" alt="trait" /></span>
          `;
        }

        card.appendChild(rewardsPreview);
      }

      // Recompensas en el recuadro dorado (en el centro del recuadro)
      if (rewardNode) {
        const arcIndex = getArcIndexByFloor(floor);
        const milestoneLevel = (arcIndex * 10) + 10;
        const seasonConfig = cachedSeasonConfig || FALLBACK_INFINITE_SEASON_CONFIG;
        const milestone = seasonConfig?.rewards?.find((r) => Number(r.level) === Number(milestoneLevel));
        const milestoneRewards = Array.isArray(milestone?.rewards) ? milestone.rewards : [];
        const bottomRewards = document.createElement('div');
        bottomRewards.className = 'floor-reward-items-preview';

        milestoneRewards.forEach((r) => {
          const type = String(r.type || '').toLowerCase();
          const amt = Number(r.amount) || 1;
          const title = r.name || `${amt} ${type}`;

          const iconEl = document.createElement('div');
          iconEl.className = 'floor-reward-item-icon';
          iconEl.title = title;

          if (type === 'coins') {
            iconEl.innerHTML = `<img src="./coin.png" alt="coins" /><span class="floor-reward-item-qty">${amt >= 1000 ? `${Math.round(amt / 1000)}k` : amt}</span>`;

          } else if (type === 'traits' || type === 'trait') {
            iconEl.innerHTML = `<img src="./trait.png" alt="trait" /><span class="floor-reward-item-qty">${amt}</span>`;

          } else if (type === 'pack' || type === 'packs') {
            const packId = String(r.packId || '').toLowerCase();
            const packImgUrl = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${packId}.png`;
            iconEl.classList.add('is-pack');
            const packImg = document.createElement('img');
            packImg.alt = packId;
            packImg.src = packImgUrl;
            packImg.onerror = function() {
              packImg.src = packId.includes('oro') ? './icon-oro.png' : './icon-especiales.png';
            };
            const qtyEl = document.createElement('span');
            qtyEl.className = 'floor-reward-item-qty';
            qtyEl.textContent = String(amt);
            iconEl.appendChild(packImg);
            iconEl.appendChild(qtyEl);

          } else if (type === 'card') {
            const cardId = String(r.cardId || r.id || '').trim();
            iconEl.classList.add('is-card');
            const cardImg = document.createElement('img');
            cardImg.alt = r.name || cardId;

            // Buscar imagen en el catalogo cargado
            const catalogCard = state.catalogCardsById?.[cardId];
            const rawImgUrl = catalogCard?.imageUrl
              || `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${cardId}.png`;
            cardImg.src = rawImgUrl;
            cardImg.onerror = function() {
              cardImg.src = './icon-especiales.png';
              iconEl.classList.remove('is-card');
            };
            cardImg.style.cursor = 'zoom-in';
            const qtyEl = document.createElement('span');
            qtyEl.className = 'floor-reward-item-qty';
            qtyEl.textContent = String(amt);
            iconEl.appendChild(cardImg);
            iconEl.appendChild(qtyEl);

            // Zoom al clicar la imagen de la carta
            iconEl.addEventListener('click', (ev) => {
              ev.stopPropagation();
              const src = catalogCard?.imageUrl || rawImgUrl;
              if (typeof openLightbox === 'function') {
                openLightbox(src, catalogCard || { id: cardId, name: r.name || cardId }, false);
              } else if (typeof openInfiniteCardZoom === 'function') {
                openInfiniteCardZoom(src, catalogCard || { id: cardId, name: r.name || cardId });
              }
            });

          } else {
            // Tipo generico
            iconEl.innerHTML = `<img src="./icon-especiales.png" alt="${type}" /><span class="floor-reward-item-qty">${amt}</span>`;
          }

          bottomRewards.appendChild(iconEl);
        });

        card.appendChild(bottomRewards);
      }

      card.appendChild(number);
      card.appendChild(tag);
      card.appendChild(trainerLabel);
      if (trainerAvatar) card.appendChild(trainerAvatar);
      refs.floorStrip.appendChild(card);
    }

    const activeTheme = getThemeByFloor(state.currentFloor);
    const activeLevel = getLevelByFloor(state.currentFloor);
    const activeTrainer = getTrainerByFloor(state.currentFloor);
    if (refs.panel) {
      const activeArcImage = activeLevel?.arcImage || activeTheme.worldImage || '';
      refs.panel.style.setProperty('--infinite-panel-arc-bg', activeArcImage ? `url('${activeArcImage}')` : 'none');
    }
    if (refs.themeName) refs.themeName.textContent = activeTheme.name;
    if (refs.titleLocation) refs.titleLocation.textContent = `Destino: ${activeTheme.name}`;
  }

  function extractBaseCardId(rawId) {
    const value = String(rawId || '').trim();
    if (!value) return '';

    if (value.includes('trait_') && typeof cardTraitsMap !== 'undefined' && cardTraitsMap && typeof cardTraitsMap === 'object') {
      const traitEntry = cardTraitsMap[value];
      const traitCardId = String(traitEntry?.cardId || '').trim();
      if (traitCardId) return traitCardId;
    }

    const markerIndex = value.indexOf('_notrait');
    const normalized = markerIndex >= 0 ? value.slice(0, markerIndex) : value;

    if (Array.isArray(window.teamBuilderCards)) {
      const fromPool = window.teamBuilderCards.find((c) => String(c?.uniqueId || c?.id || '') === normalized);
      if (fromPool?.id) return String(fromPool.id);
    }

    return normalized;
  }

  function resolveCardFromUniqueId(uniqueId) {
    if (!uniqueId) return null;
    if (!Array.isArray(window.teamBuilderCards)) return null;

    let card = window.teamBuilderCards.find((c) => (c.uniqueId || c.id) === uniqueId);
    if (card) return card;

    const baseId = extractBaseCardId(uniqueId);

    card = window.teamBuilderCards.find((c) => c.id === baseId);
    return card || null;
  }

  function renderTeamPreview() {
    if (!refs.teamPreview) return;
    refs.teamPreview.innerHTML = '';

    const runDeckBaseIds = Array.isArray(state.runDeckIds)
      ? Array.from(new Set(state.runDeckIds.map((id) => extractBaseCardId(id)).filter(Boolean)))
      : [];

    if (state.runActive && runDeckBaseIds.length > 0) {
      const inventoryMap = new Map((state.inventoryCards || []).map((card) => [String(card.id), card]));
      runDeckBaseIds.forEach((baseId) => {
        const fromInventory = inventoryMap.get(String(baseId));
        const fromCatalog = state.catalogCardsById?.[String(baseId)];
        const fromPool = resolveCardFromUniqueId(baseId);
        const cardObj = fromInventory || fromCatalog || fromPool;
        const image = cardObj?.imageUrl || cardObj?.image || cardObj?.imagen || '';
        const name = cardObj?.name || cardObj?.nombre || baseId;

        if (image) {
          const img = document.createElement('img');
          img.className = 'infinite-team-card';
          img.src = image;
          img.alt = name;
          img.title = name;
          attachInfiniteCardZoom(img, { name, uniqueId: String(baseId), cardId: String(baseId) });
          refs.teamPreview.appendChild(img);
          return;
        }

        const fallback = document.createElement('div');
        fallback.className = 'infinite-team-card-fallback';
        fallback.title = name;
        fallback.textContent = '🃏';
        refs.teamPreview.appendChild(fallback);
      });
      return;
    }

    const snapshot = Array.isArray(state.initialTeamSnapshot) ? state.initialTeamSnapshot : [];
    const slotVisuals = [];

    for (let slotIndex = 0; slotIndex < 8; slotIndex += 1) {
      const uniqueId = snapshot[slotIndex] || null;
      const baseId = extractBaseCardId(uniqueId);
      const cardData = uniqueId ? (resolveCardFromUniqueId(uniqueId) || resolveCardFromUniqueId(baseId)) : null;
      const slotElement = document.querySelector(`.team-slot[data-slot="${slotIndex}"]`);
      const slotImg = slotElement?.querySelector('.team-slot-card-img');

      slotVisuals.push({
        uniqueId,
        baseId,
        imageUrl: cardData?.imageUrl || cardData?.image || slotImg?.src || '',
        name: cardData?.name || cardData?.nombre || slotImg?.alt || (slotIndex === 7 ? 'Reserva' : `Slot ${slotIndex + 1}`)
      });
    }

    const filledSlots = slotVisuals.filter((entry) => !!entry.uniqueId || !!entry.baseId || !!entry.imageUrl);
    const selectedCardMap = new Map((state.selectedInitialCards || []).map((c) => [c.id, c]));

    if (filledSlots.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'infinite-team-preview-empty';
      empty.textContent = 'Aqui se mostraran las cartas de tu equipo inicial';
      refs.teamPreview.appendChild(empty);
      return;
    }

    filledSlots.forEach(({ uniqueId, baseId, imageUrl, name }) => {
      const fallbackFromInitial = selectedCardMap.get(baseId || uniqueId || '')?.imageUrl || '';
      const finalImage = imageUrl || fallbackFromInitial;
      const finalName = name || selectedCardMap.get(baseId || uniqueId || '')?.name || 'Carta';

      if (finalImage) {
        const img = document.createElement('img');
        img.className = 'infinite-team-card';
        img.src = finalImage;
        img.alt = finalName;
        img.title = finalName;
        attachInfiniteCardZoom(img, { name: finalName, uniqueId: uniqueId || '', cardId: baseId || '' });
        refs.teamPreview.appendChild(img);
        return;
      }

      const fallback = document.createElement('div');
      fallback.className = 'infinite-team-card-fallback';
      fallback.title = finalName;
      fallback.textContent = '🃏';
      refs.teamPreview.appendChild(fallback);
    });
  }

  function renderTeamPowersPreview() {
    if (!refs.teamPowersPreview) return;
    refs.teamPowersPreview.innerHTML = '';

    const powerIdsSnapshot = Array.isArray(state.initialPowersSnapshot) ? state.initialPowersSnapshot.filter(Boolean) : [];
    let powersForPreview = Array.isArray(state.selectedInitialPowers) ? state.selectedInitialPowers.filter(Boolean) : [];

    const inventoryPowers = Array.isArray(state.inventoryPowers) ? state.inventoryPowers : [];
    const allAvailable = Array.isArray(window.availablePowers) ? window.availablePowers : [];

    if (powersForPreview.length === 0 && powerIdsSnapshot.length > 0) {
      powersForPreview = powerIdsSnapshot.map((powerId) => {
        const fromInventory = inventoryPowers.find((power) => power.id === powerId);
        if (fromInventory) return fromInventory;
        const fromAvail = allAvailable.find((power) => power.id === powerId);
        if (fromAvail) {
          return {
            id: fromAvail.id,
            name: fromAvail.name || fromAvail.id,
            imageUrl: fromAvail.imageUrl || fromAvail.image || ''
          };
        }
        return {
          id: powerId,
          name: powerId,
          imageUrl: ''
        };
      });
    }

    // Fallback adicional desde infinite_saved_team
    if (powersForPreview.length === 0) {
      try {
        const teamKey = getInfiniteUserKey('infinite_saved_team');
        const saved = localStorage.getItem(teamKey) || localStorage.getItem('infinite_saved_team');
        if (saved) {
          const parsed = JSON.parse(saved);
          const savedPowers = Array.isArray(parsed.powers) ? parsed.powers.filter(Boolean) : (Array.isArray(parsed.powerIds) ? parsed.powerIds.filter(Boolean) : []);
          if (savedPowers.length > 0) {
            powersForPreview = savedPowers.slice(0, 3).map((p) => {
              const pId = typeof p === 'string' ? p : p?.id;
              const fromInventory = inventoryPowers.find((power) => power.id === pId);
              if (fromInventory) return fromInventory;
              const fromAvail = allAvailable.find((power) => power.id === pId);
              if (fromAvail) {
                return {
                  id: fromAvail.id,
                  name: fromAvail.name || fromAvail.id,
                  imageUrl: fromAvail.imageUrl || fromAvail.image || ''
                };
              }
              return typeof p === 'string' ? { id: p, name: p, imageUrl: '' } : p;
            });
          }
        }
      } catch (e) {}
    }

    if (powersForPreview.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'infinite-team-preview-empty';
      empty.textContent = 'Aqui se mostraran los 3 poderes elegidos';
      refs.teamPowersPreview.appendChild(empty);
      return;
    }

    powersForPreview.slice(0, 3).forEach((power) => {
      let powerImage = power.imageUrl || power.image || '';
      if (!powerImage && allAvailable.length > 0) {
        const found = allAvailable.find((a) => a.id === power.id);
        if (found) powerImage = found.imageUrl || found.image || '';
      }

      if (powerImage) {
        const img = document.createElement('img');
        img.className = 'infinite-team-power-icon';
        img.src = powerImage;
        img.alt = power.name || 'Poder';
        img.title = power.name || 'Poder';
        refs.teamPowersPreview.appendChild(img);
        return;
      }

      const fallback = document.createElement('div');
      fallback.className = 'infinite-team-power-fallback';
      fallback.title = power.name || 'Poder';
      fallback.textContent = '⚡';
      refs.teamPowersPreview.appendChild(fallback);
    });
  }

  function renderRunStatus() {
    renderInfiniteConsumables();
  }

  function updateAdminInfiniteButtons(isAdmin = Boolean(window.currentUserIsAdmin)) {
    const show = Boolean(isAdmin);
    if (refs.completeFloorBtn) {
      refs.completeFloorBtn.style.display = show ? '' : 'none';
    }
    if (refs.resetRunBtn) {
      refs.resetRunBtn.style.display = show ? '' : 'none';
    }
  }
  window.updateInfiniteAdminButtons = updateAdminInfiniteButtons;

  function updateStartRunButton() {
    if (!refs.startRunBtn || !refs.completeFloorBtn) return;
    updateAdminInfiniteButtons();

    if (!state.runActive) {
      refs.startRunBtn.textContent = 'Iniciar run';
      refs.startRunBtn.classList.remove('run-active', 'btn-decide', 'btn-claim');
      refs.completeFloorBtn.disabled = true;
      refs.completeFloorBtn.classList.add('complete-floor-btn');
      return;
    }

    refs.startRunBtn.classList.add('run-active');
    refs.completeFloorBtn.disabled = false;
    refs.completeFloorBtn.classList.add('complete-floor-btn');

    if (isDecisionFloor(state.currentFloor)) {
      refs.startRunBtn.textContent = 'Decidir';
      refs.startRunBtn.classList.add('btn-decide');
      refs.startRunBtn.classList.remove('btn-claim');
    } else if (isRewardFloor(state.currentFloor)) {
      refs.startRunBtn.textContent = 'Reclamar';
      refs.startRunBtn.classList.add('btn-claim');
      refs.startRunBtn.classList.remove('btn-decide');
    } else {
      refs.startRunBtn.textContent = 'Jugar';
      refs.startRunBtn.classList.remove('btn-decide', 'btn-claim');
    }
  }

  function computeTargetOpponentAverage() {
    const floor = normalizeFloorValue(state.currentFloor);
    if (typeof window.getInfiniteFloorMediaInterval === 'function') {
      const interval = window.getInfiniteFloorMediaInterval(floor);
      if (interval.max === Infinity) {
        return interval.min + 3;
      }
      return (interval.min + interval.max) / 2;
    }
    const baseAverage = 63;
    const progressTo50 = Math.max(0, Math.min(1, (floor - 1) / 49));
    const targetAt50 = 89;
    return baseAverage + ((targetAt50 - baseAverage) * progressTo50);
  }

  function syncInitialSelectionFromCurrentTeam() {
    if (!Array.isArray(state.inventoryCards) || state.inventoryCards.length === 0) return;
    if (!Array.isArray(state.inventoryPowers) || state.inventoryPowers.length === 0) return;

    const teamEntries = Array.isArray(window.selectedTeam) ? window.selectedTeam.slice(0, 8).filter(Boolean) : [];
    const powerEntries = Array.isArray(window.selectedTeamPowers) ? window.selectedTeamPowers.filter(Boolean) : [];

    if (teamEntries.length === 0 && powerEntries.length === 0) return;

    const pool = Array.isArray(window.teamBuilderCards) ? window.teamBuilderCards : [];
    const selectedCards = [];
    const selectedCardIds = new Set();

    teamEntries.forEach((entry) => {
      const matchedPoolCard = pool.find((card) => (card.uniqueId || card.id) === entry) || pool.find((card) => card.id === entry);
      const baseId = matchedPoolCard?.id
        || (String(entry).includes('_notrait') ? String(entry).split('_notrait')[0] : String(entry));
      const inventoryCard = state.inventoryCards.find((card) => card.id === baseId);
      if (!inventoryCard) return;
      if (selectedCardIds.has(inventoryCard.id)) return;
      selectedCards.push(inventoryCard);
      selectedCardIds.add(inventoryCard.id);
    });

    if (selectedCards.length > 0) {
      state.selectedInitialCards = selectedCards.slice(0, 8);
    }

    const selectedPowers = [];
    const selectedPowerIds = new Set();
    powerEntries.forEach((powerId) => {
      const inventoryPower = state.inventoryPowers.find((power) => power.id === powerId);
      if (!inventoryPower) return;
      if (selectedPowerIds.has(inventoryPower.id)) return;
      selectedPowers.push(inventoryPower);
      selectedPowerIds.add(inventoryPower.id);
    });

    if (selectedPowers.length > 0) {
      state.selectedInitialPowers = selectedPowers.slice(0, 3);
    }
  }

  function moveToNextCombatFloor() {
    let nextFloor = normalizeFloorValue(state.currentFloor) + 1;
    let guard = 0;
    while ((isDecisionFloor(nextFloor) || isRewardFloor(nextFloor)) && guard < 30) {
      nextFloor += 1;
      guard += 1;
    }
    state.currentFloor = nextFloor;
    renderFloorStrip();
    renderRunStatus();
    updateStartRunButton();
    persistInfiniteRunState();
  }

  function returnToInfinitePanelFromBattle(playerWon = false) {
    if (typeof window.cleanUpBattleCompletely === 'function') {
      window.cleanUpBattleCompletely({ resumeMenuMusic: true });
    }
    const battleScreen = document.getElementById('battle-screen');
    if (battleScreen) battleScreen.style.display = 'none';
    const resultScreen = document.getElementById('battle-result-screen');
    if (resultScreen) resultScreen.style.display = 'none';
    const mainMenu = document.getElementById('main-menu');
    if (mainMenu) mainMenu.style.display = 'none';
    const gameView = document.getElementById('game-view');
    if (gameView) gameView.style.display = 'block';

    state.runActive = true;
    if (playerWon) {
      advanceFloorAfterClear();
    }
    openPanel();
  }

  function goToNextFloorAndPlayFromBattle() {
    if (typeof window.cleanUpBattleCompletely === 'function') {
      window.cleanUpBattleCompletely();
    }
    const battleScreen = document.getElementById('battle-screen');
    if (battleScreen) battleScreen.style.display = 'none';
    const resultScreen = document.getElementById('battle-result-screen');
    if (resultScreen) resultScreen.style.display = 'none';
    const mainMenu = document.getElementById('main-menu');
    if (mainMenu) mainMenu.style.display = 'none';
    const gameView = document.getElementById('game-view');
    if (gameView) gameView.style.display = 'block';

    state.runActive = true;
    advanceFloorAfterClear();
    if (isDecisionFloor(state.currentFloor)) {
      openPanel();
      openDecisionModal();
    } else if (isRewardFloor(state.currentFloor)) {
      openPanel();
    } else {
      startInfiniteBattleFromCurrentFloor();
    }
  }

  function openPlayConfirmModal() {
    if (!refs.playConfirmModal || !refs.playConfirmDesc) return;

    const trainer = getTrainerByFloor(state.currentFloor);
    const trainerName = trainer?.name || 'Entrenador';
    refs.playConfirmDesc.textContent = `Seguro que quieres jugar el nivel ${getDisplayLevelNumberByFloor(state.currentFloor)} contra ${trainerName}?`;
    refs.playConfirmModal.style.display = 'flex';
  }

  function closePlayConfirmModal() {
    if (!refs.playConfirmModal) return;
    refs.playConfirmModal.style.display = 'none';
  }

  async function prepareInfiniteTeamForBattle() {
    if (!state.initialTeamLocked) return false;

    // Asegurar catálogo e inventario disponibles para resolución de cartas
    if (!state.catalogCardsById || Object.keys(state.catalogCardsById).length === 0) {
      try {
        state.inventoryCards = await loadInitialInventoryCards();
      } catch (e) {
        console.warn('[INFINITE] Error precargando inventario/catálogo inicial:', e);
      }
    }

    // Cargar inventario de team builder si aún no está en memoria
    if (!Array.isArray(window.teamBuilderCards) || window.teamBuilderCards.length === 0) {
      if (typeof window.loadTeamBuilderInventory === 'function') {
        try {
          await window.loadTeamBuilderInventory();
        } catch (e) {
          console.warn('[INFINITE] Error cargando teamBuilderCards:', e);
        }
      }
    }
    if (typeof window.loadPowers === 'function') {
      try {
        await window.loadPowers();
      } catch (e) {}
    }

    // 1. Obtener datos de infinite_saved_team
    let team = null;
    let powers = null;
    const teamKey = getInfiniteUserKey('infinite_saved_team');
    try {
      const raw = localStorage.getItem(teamKey) || localStorage.getItem('infinite_saved_team');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed.team) && parsed.team.length === 8 && parsed.team.filter(Boolean).length === 8) {
          team = [...parsed.team];
        }
        if (Array.isArray(parsed.powers) && parsed.powers.filter(Boolean).length === 3) {
          powers = [...parsed.powers].slice(0, 3);
        } else if (Array.isArray(parsed.powerIds) && parsed.powerIds.filter(Boolean).length === 3) {
          powers = [...parsed.powerIds].slice(0, 3);
        }
      }
    } catch (e) {}

    // 2. Si no estaba en localStorage o estaba incompleto, armar desde state
    if (!team) {
      if (Array.isArray(state.selectedInitialCardIds) && state.selectedInitialCardIds.length >= 8) {
        team = state.selectedInitialCardIds.slice(0, 8);
      } else if (Array.isArray(state.initialTeamSnapshot) && state.initialTeamSnapshot.filter(Boolean).length >= 8) {
        team = state.initialTeamSnapshot.slice(0, 8);
      }
    }

    if (!powers) {
      if (Array.isArray(state.selectedInitialPowerIds) && state.selectedInitialPowerIds.filter(Boolean).length >= 3) {
        powers = state.selectedInitialPowerIds.filter(Boolean).slice(0, 3);
      } else if (Array.isArray(state.initialPowersSnapshot) && state.initialPowersSnapshot.filter(Boolean).length >= 3) {
        powers = state.initialPowersSnapshot.filter(Boolean).slice(0, 3);
      } else if (Array.isArray(state.selectedInitialPowers) && state.selectedInitialPowers.filter(Boolean).length >= 3) {
        powers = state.selectedInitialPowers.map((p) => (typeof p === 'string' ? p : p?.id)).filter(Boolean).slice(0, 3);
      }
    }

    if (!Array.isArray(team) || team.slice(0, 7).filter(Boolean).length !== 7 || !team[7]) {
      console.warn('[INFINITE] Equipo infinito incompleto:', team);
      return false;
    }
    if (!Array.isArray(powers) || powers.filter(Boolean).length !== 3) {
      console.warn('[INFINITE] Poderes infinitos incompletos:', powers);
      return false;
    }

    // Normalizar powers a strings
    powers = powers.map((p) => String(typeof p === 'object' && p?.id ? p.id : p));

    // Sincronizar reactivamente a infinite_saved_team y al state (ambas claves para consistencia)
    try {
      const existingRaw = localStorage.getItem(teamKey) || localStorage.getItem('infinite_saved_team');
      const existing = existingRaw ? JSON.parse(existingRaw) : {};
      const updated = {
        ...existing,
        team: [...team],
        powers: [...powers],
        cardIds: [...team],
        powerIds: [...powers],
        timestamp: new Date().toISOString()
      };
      localStorage.setItem(teamKey, JSON.stringify(updated));
      localStorage.setItem('infinite_saved_team', JSON.stringify(updated));
    } catch (e) {}

    state.selectedInitialPowerIds = [...powers];
    state.initialPowersSnapshot = [...powers];

    // Asegurar catálogo completo como fallback
    let fullCatalog = null;
    if (!Array.isArray(window.teamBuilderCards)) window.teamBuilderCards = [];

    // Asegurar que cada carta del equipo infinito esté en window.teamBuilderCards
    for (const cardEntry of team) {
      if (!cardEntry) continue;
      let resolved = resolveCardFromUniqueId(cardEntry);
      if (!resolved) {
        const baseId = extractBaseCardId(cardEntry);
        let found = (state.inventoryCards || []).find((c) => c.id === baseId) || 
                    state.catalogCardsById?.[baseId] || 
                    state.runTemporalCards?.[baseId];

        if (!found && window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
          if (!fullCatalog) {
            try {
              const catRes = await window.kvrcards.getAllCards();
              fullCatalog = Array.isArray(catRes) ? catRes : (catRes?.ok && Array.isArray(catRes.cards) ? catRes.cards : []);
            } catch (err) {
              fullCatalog = [];
            }
          }
          found = (fullCatalog || []).find(c => c.id === baseId);
        }

        if (found) {
          const stats = typeof extractCardStatsForInfinite === 'function' ? extractCardStatsForInfinite(found) : {};
          const isTraitCard = String(cardEntry).includes('trait_');
          window.teamBuilderCards.push({
            ...found,
            id: found.id || baseId,
            name: found.nombre || found.name || baseId,
            imageUrl: found.imageUrl || found.image || found.imagen || '',
            image: found.imageUrl || found.image || found.imagen || '',
            media: Number(found.media) || 0,
            uniqueId: cardEntry,
            instanceId: isTraitCard ? cardEntry : null,
            hasTrait: isTraitCard,
            ...stats
          });
        }
      }
    }

    // Validación estricta: asegurar que las 7 cartas principales y 1 reserva se pueden resolver
    let unresolvedCount = 0;
    for (let i = 0; i < 8; i++) {
      const entry = team[i];
      const res = resolveCardFromUniqueId(entry);
      if (!res) {
        unresolvedCount++;
        console.error('[INFINITE] No se pudo resolver la carta del slot', i, entry);
      }
    }

    if (unresolvedCount > 0) {
      console.error('[INFINITE] Error crítico: Hay', unresolvedCount, 'cartas sin resolver en el equipo.');
      if (typeof window.loadTeamBuilderInventory === 'function') {
        try {
          await window.loadTeamBuilderInventory();
        } catch (e) {}
      }
    }

    window.selectedTeam = [...team];
    window.selectedTeamPowers = [...powers];
    window.selectedDifficulty = 'inmo';
    return true;
  }

  async function startInfiniteBattleFromCurrentFloor() {
    if (!state.initialTeamLocked) {
      alert('Debes confirmar tu equipo antes de jugar por primera vez');
      return;
    }

    const teamReady = await prepareInfiniteTeamForBattle();
    if (!teamReady) {
      alert('Debes confirmar tu equipo antes de jugar por primera vez');
      return;
    }

    if (!state.runActive) {
      state.runActive = true;
      state.currentFloor = normalizeFloorValue(state.currentFloor);
      state.runDeckIds = [...state.selectedInitialCardIds];
      state.runStats = {
        upgrades: 0,
        riskEvents: 0,
        shopVisits: 0,
        addedFromOutside: 0
      };
      updateStartRunButton();
      renderFloorStrip();
      renderRunStatus();
      persistInfiniteRunState();
      alert('Run infinita iniciada. Pulsa Jugar para entrar en combate.');
      return;
    }

    if (isDecisionFloor(state.currentFloor) || isRewardFloor(state.currentFloor)) {
      alert('Este piso no es de combate. Usa "Completar piso actual" para avanzar.');
      return;
    }

    if (!validateInfiniteTeam()) return;

    if (refs.panel) {
      refs.panel.style.display = 'none';
    }
    const gameViewEl = byId('game-view');
    if (gameViewEl) {
      gameViewEl.style.display = 'none';
    }

    const trainer = getTrainerByFloor(state.currentFloor);
    const activeTheme = getThemeByFloor(state.currentFloor);
    const activeLevel = getLevelByFloor(state.currentFloor);
    const trainerName = trainer?.name || `Entrenador Nivel ${getDisplayLevelNumberByFloor(state.currentFloor)}`;
    const trainerImage = trainer?.image || '';
    const arcImage = activeLevel?.arcImage || activeTheme?.worldImage || '';
    const targetAverage = computeTargetOpponentAverage();
    const displayFloor = getDisplayLevelNumberByFloor(state.currentFloor);
    let floorModifier = null;
    if (window.InfiniteModifiers && typeof window.InfiniteModifiers.getOrAssignModifierForFloor === 'function') {
      floorModifier = window.InfiniteModifiers.getOrAssignModifierForFloor(displayFloor, state.floorModifiers);
    }

    const chosenBattleSong = pickBattleSongForFloor(state.currentFloor);
    if (chosenBattleSong) {
      console.log('[INFINITE] Musica de batalla seleccionada para piso', displayFloor, ':', chosenBattleSong);
    }

    const trainerRole = getTrainerRoleByFloor(state.currentFloor);

    window.__infiniteBattleContext = {
      active: true,
      floor: displayFloor,
      trainerRole,
      trainerName,
      trainerImage,
      arcImage,
      targetAverage,
      modifier: floorModifier,
      battleSong: chosenBattleSong,
      opponentSong: chosenBattleSong
    };

    window.__infiniteRunCardBuffs = state.runCardBuffs && typeof state.runCardBuffs === 'object' ? { ...state.runCardBuffs } : {};

    window.selectedDifficulty = 'inmo';
    state.selectingTeam = false;
    window.isInfiniteModeTeamBuilding = false;
    persistInfiniteRunState();

    // Verificación estricta de 7 titulares + 1 reserva antes de invocar flujo de batalla
    const activeTeam = Array.isArray(window.selectedTeam) ? window.selectedTeam.filter(Boolean) : [];
    if (activeTeam.length < 8) {
      console.warn('[INFINITE] Verificación antes de batalla: selectedTeam incompleto (' + activeTeam.length + '/8). Rehidratando equipo...');
      await prepareInfiniteTeamForBattle();
    }

    if (typeof window.validateTeamAndContinue === 'function') {
      window.validateTeamAndContinue();
    } else {
      alert('No se pudo iniciar la batalla: flujo de batalla no disponible.');
    }
  }

  function normalizePoolKey(value) {
    const raw = String(value || '');
    if (!raw) return '';
    if (raw.includes('trait_')) return raw;
    if (raw.includes('_notrait')) {
      return `${raw.split('_notrait')[0]}_notrait`;
    }
    return raw;
  }

  function getBaseCardName(cardId, cardObj = null) {
    if (typeof window.getBasePlayerIdentifier === 'function') {
      return window.getBasePlayerIdentifier(cardId, cardObj);
    }
    let cleanId = String(cardId || '').toLowerCase().trim();
    if (cleanId.includes('_notrait')) cleanId = cleanId.split('_notrait')[0];
    const versionSuffixes = [
      '_iconoprime', '_icono_prime', '_icon_prime', '_prime_icon',
      '_diosantiguo', '_dios_antiguo', '_ancientgod',
      '_superheroe', '_legendario', '_legendaria',
      '_especiales', '_especial', '_special',
      '_iconos', '_icono', '_icon',
      '_heroes', '_heroe', '_hero',
      '_bronce', '_bronze',
      '_plata', '_silver',
      '_oro', '_gold',
      '_evolucion', '_evolution', '_evo',
      '_inmortal', '_inmo',
      '_legend', '_prime', '_tots', '_toty',
      '_evento', '_event'
    ];
    for (const suffix of versionSuffixes) {
      if (cleanId.endsWith(suffix)) {
        cleanId = cleanId.slice(0, -suffix.length);
        break;
      }
    }
    return cleanId.replace(/_+$/, '').replace(/[^a-z0-9]/g, '');
  }

  async function loadInitialInventoryCards() {
    if (!window.kvrcards || typeof window.kvrcards.getInventory !== 'function') return [];

    const [inv, allCardsData] = await Promise.all([
      window.kvrcards.getInventory(),
      window.kvrcards.getAllCards()
    ]);

    if (!inv || !inv.ok) return [];

    const cardsList = Array.isArray(allCardsData)
      ? allCardsData
      : (allCardsData && allCardsData.ok && Array.isArray(allCardsData.cards) ? allCardsData.cards : []);

    state.catalogCardsById = cardsList.reduce((acc, card) => {
      const id = String(card?.id || '').trim();
      if (!id) return acc;
      acc[id] = card;
      return acc;
    }, {});

    return cardsList
      .filter((card) => (inv.cards?.[card.id] || 0) > 0)
      .map((card) => {
        const stats = extractCardStatsForInfinite(card);
        return {
          id: card.id,
          name: card.nombre || card.name || card.id,
          imageUrl: card.imageUrl || card.imagen || '',
          image: card.imageUrl || card.imagen || '',
          media: Number(card.media) || 0,
          stats: Array.isArray(card.stats) ? [...card.stats] : (Array.isArray(card.parametros) ? [...card.parametros] : []),
          ...stats
        };
      })
      .sort((a, b) => b.media - a.media);
  }

  async function hydrateSelectedCardsFromInventory() {
    const sourceIdsRaw = Array.isArray(state.selectedInitialCardIds) && state.selectedInitialCardIds.length > 0
      ? state.selectedInitialCardIds
      : (Array.isArray(state.initialTeamSnapshot) ? state.initialTeamSnapshot : []);

    const sourceIds = sourceIdsRaw
      .map((id) => extractBaseCardId(id))
      .filter(Boolean)
      .slice(0, 8);

    if (sourceIds.length === 0) return;

    if (!Array.isArray(state.inventoryCards) || state.inventoryCards.length === 0) {
      try {
        state.inventoryCards = await loadInitialInventoryCards();
      } catch {
        state.inventoryCards = [];
      }
    }

    const mapped = sourceIds.map((cardId) => {
      const fromInventory = state.inventoryCards.find((card) => card.id === cardId);
      if (fromInventory) return fromInventory;
      return { id: cardId, name: cardId, imageUrl: '', image: '' };
    });

    state.selectedInitialCards = mapped.filter(Boolean);
    state.selectedInitialCardIds = sourceIds;
  }

  async function loadInitialInventoryPowers() {
    if (!window.kvrcards || typeof window.kvrcards.getAllPowers !== 'function' || typeof window.kvrcards.getPowersInventory !== 'function') {
      return [];
    }

    const [allPowers, powersInventory] = await Promise.all([
      window.kvrcards.getAllPowers(),
      window.kvrcards.getPowersInventory()
    ]);

    const powersList = Array.isArray(allPowers) ? allPowers : [];
    const inventoryMap = powersInventory && powersInventory.ok && powersInventory.powers
      ? powersInventory.powers
      : {};

    return powersList
      .filter((power) => {
        const item = inventoryMap[power.id];
        if (!item) return false;
        return item.permanent === true || Number(item.uses || 0) > 0;
      })
      .map((power) => {
        const item = inventoryMap[power.id] || {};
        return {
          id: power.id,
          name: power.name || power.id,
          imageUrl: power.imageUrl || '',
          uses: Number(item.uses || 0),
          permanent: item.permanent === true
        };
      });
  }

  async function hydrateSelectedPowersFromInventory() {
    const sourceIds = Array.isArray(state.selectedInitialPowerIds) && state.selectedInitialPowerIds.length > 0
      ? state.selectedInitialPowerIds
      : (Array.isArray(state.selectedInitialPowers) ? state.selectedInitialPowers.map((p) => (typeof p === 'string' ? p : p?.id)).filter(Boolean) : []);
    if (sourceIds.length === 0) return;

    if (!Array.isArray(state.inventoryPowers) || state.inventoryPowers.length === 0) {
      try {
        state.inventoryPowers = await loadInitialInventoryPowers();
      } catch {
        state.inventoryPowers = [];
      }
    }

    const allAvailable = Array.isArray(window.availablePowers) ? window.availablePowers : [];

    const mapped = sourceIds.slice(0, 3).map((powerId) => {
      const fromInventory = state.inventoryPowers.find((power) => power.id === powerId);
      if (fromInventory) return fromInventory;
      const fromAvail = allAvailable.find((power) => power.id === powerId);
      if (fromAvail) {
        return {
          id: fromAvail.id,
          name: fromAvail.name || fromAvail.id,
          imageUrl: fromAvail.imageUrl || fromAvail.image || ''
        };
      }
      return { id: powerId, name: powerId, imageUrl: '' };
    });

    state.selectedInitialPowers = mapped.filter(Boolean);
    if (!Array.isArray(state.selectedInitialPowerIds) || state.selectedInitialPowerIds.length === 0) {
      state.selectedInitialPowerIds = mapped.map((power) => power.id);
    }
  }

  function updateConfirmPickButtonState() {
    if (!refs.confirmPickBtn) return;
    refs.confirmPickBtn.disabled = !(state.selectedInitialCards.length === 8 && state.selectedInitialPowers.length === 3);
  }

  function renderPickedStrip() {
    if (!refs.pickedStrip) return;
    refs.pickedStrip.innerHTML = '';

    if (state.selectedInitialCards.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'infinite-team-preview-empty';
      empty.textContent = 'Selecciona 8 cartas para tu equipo inicial';
      refs.pickedStrip.appendChild(empty);
    } else {
      state.selectedInitialCards.forEach((card, idx) => {
        const img = document.createElement('img');
        img.className = 'infinite-picked-mini';
        img.src = card.imageUrl || '';
        img.alt = card.name;
        img.title = card.name;
        attachInfiniteCardZoom(img, {
          name: card.name,
          cardId: card.id,
          uniqueId: String(state.selectedInitialCardIds?.[idx] || card.id || '')
        });
        refs.pickedStrip.appendChild(img);
      });
    }

    if (refs.pickedCount) {
      refs.pickedCount.textContent = `${state.selectedInitialCards.length}/8`;
    }
    updateConfirmPickButtonState();
  }

  function renderPickedPowersStrip() {
    if (!refs.pickedPowersStrip) return;
    refs.pickedPowersStrip.innerHTML = '';

    if (state.selectedInitialPowers.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'infinite-team-preview-empty';
      empty.textContent = 'Selecciona 3 poderes para tu run inicial';
      refs.pickedPowersStrip.appendChild(empty);
    } else {
      state.selectedInitialPowers.forEach((power) => {
        if (power.imageUrl) {
          const img = document.createElement('img');
          img.className = 'infinite-picked-power-mini';
          img.src = power.imageUrl;
          img.alt = power.name;
          img.title = power.name;
          refs.pickedPowersStrip.appendChild(img);
        } else {
          const fallback = document.createElement('div');
          fallback.className = 'infinite-picked-power-fallback';
          fallback.title = power.name;
          fallback.textContent = '⚡';
          refs.pickedPowersStrip.appendChild(fallback);
        }
      });
    }

    if (refs.pickedPowersCount) {
      refs.pickedPowersCount.textContent = `${state.selectedInitialPowers.length}/3`;
    }
    updateConfirmPickButtonState();
  }

  function renderInitialInventoryGrid() {
    if (!refs.initialInventory) return;
    refs.initialInventory.innerHTML = '';

    state.inventoryCards.forEach((card) => {
      const isSelected = state.selectedInitialCards.some((c) => c.id === card.id);
      const cardDiv = document.createElement('div');
      cardDiv.className = 'infinite-inventory-card' + (isSelected ? ' selected' : '');

      cardDiv.innerHTML = `
        <img src="${card.imageUrl}" alt="${card.name}" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22300%22%3E%3Crect width=%22200%22 height=%22300%22 fill=%22%231e293b%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%23fff%22 font-size=%2212%22%3ECarta%3C/text%3E%3C/svg%3E'" />
        <div class="infinite-inventory-card-name">${card.name}</div>
        <button class="infinite-inventory-card-btn">${isSelected ? '✓ Seleccionada' : '+ Elegir'}</button>
      `;

      const cardImg = cardDiv.querySelector('img');
      attachInfiniteCardZoom(cardImg, { name: card.name, cardId: card.id, uniqueId: card.id });

      const btn = cardDiv.querySelector('.infinite-inventory-card-btn');
      btn.addEventListener('click', () => {
        if (isSelected) {
          state.selectedInitialCards = state.selectedInitialCards.filter((c) => c.id !== card.id);
        } else {
          if (state.selectedInitialCards.length >= 8) {
            alert('Solo puedes seleccionar 8 cartas.');
            return;
          }
          const isDuplicate = state.selectedInitialCards.some((c) => {
            if (typeof window.areSamePlayerCards === 'function') {
              return window.areSamePlayerCards(c, card);
            }
            return getBaseCardName(c.id, c) === getBaseCardName(card.id, card);
          });
          if (isDuplicate) {
            alert(`Ya tienes una versión de ${card.name || 'este personaje'} en la selección.\n\nNo se permite seleccionar dos versiones del mismo personaje.`);
            return;
          }
          state.selectedInitialCards.push(card);
        }
        renderInitialInventoryGrid();
        renderPickedStrip();
      });

      refs.initialInventory.appendChild(cardDiv);
    });
  }

  function renderInitialPowersGrid() {
    if (!refs.initialPowersInventory) return;
    refs.initialPowersInventory.innerHTML = '';

    if (!Array.isArray(state.inventoryPowers) || state.inventoryPowers.length === 0) {
      refs.initialPowersInventory.innerHTML = '<div class="infinite-team-preview-empty">No tienes poderes disponibles.</div>';
      renderPickedPowersStrip();
      return;
    }

    state.inventoryPowers.forEach((power) => {
      const isSelected = state.selectedInitialPowers.some((p) => p.id === power.id);
      const powerDiv = document.createElement('div');
      powerDiv.className = 'infinite-power-inventory-item' + (isSelected ? ' selected' : '');

      const usesLabel = power.permanent ? '♾️ Permanente' : `${power.uses} usos`;

      powerDiv.innerHTML = `
        <img src="${power.imageUrl}" alt="${power.name}" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22120%22 height=%22120%22%3E%3Ccircle cx=%2260%22 cy=%2260%22 r=%2255%22 fill=%22%231e293b%22/%3E%3Ctext x=%2250%25%22 y=%2255%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%23fff%22 font-size=%2246%22%3E⚡%3C/text%3E%3C/svg%3E'" />
        <div class="infinite-power-inventory-name">${power.name}<br><small>${usesLabel}</small></div>
        <button class="infinite-power-inventory-btn">${isSelected ? '✓ Seleccionado' : '+ Elegir'}</button>
      `;

      const btn = powerDiv.querySelector('.infinite-power-inventory-btn');
      btn.addEventListener('click', () => {
        if (isSelected) {
          state.selectedInitialPowers = state.selectedInitialPowers.filter((p) => p.id !== power.id);
        } else {
          if (state.selectedInitialPowers.length >= 3) {
            alert('Solo puedes seleccionar 3 poderes.');
            return;
          }
          state.selectedInitialPowers.push(power);
        }
        renderInitialPowersGrid();
        renderPickedPowersStrip();
      });

      refs.initialPowersInventory.appendChild(powerDiv);
    });
  }

  async function openInitialPicker() {
    if (!refs.initialPicker) return;
    refs.initialPicker.style.display = 'block';

    if (state.inventoryCards.length === 0) {
      try {
        state.inventoryCards = await loadInitialInventoryCards();
      } catch {
        state.inventoryCards = [];
      }
    }

    if (state.inventoryPowers.length === 0) {
      try {
        state.inventoryPowers = await loadInitialInventoryPowers();
      } catch {
        state.inventoryPowers = [];
      }
    }

    if (state.selectedInitialCards.length === 0 && state.selectedInitialPowers.length === 0) {
      syncInitialSelectionFromCurrentTeam();
    }

    renderInitialInventoryGrid();
    renderPickedStrip();
    renderInitialPowersGrid();
    renderPickedPowersStrip();
  }

  function closeInitialPicker() {
    if (refs.initialPicker) refs.initialPicker.style.display = 'none';
  }

  function getRunDeckBaseIds() {
    const source = Array.isArray(state.runDeckIds) && state.runDeckIds.length > 0
      ? state.runDeckIds
      : state.selectedInitialCardIds;
    return Array.from(new Set((source || []).map((id) => extractBaseCardId(id)).filter(Boolean)));
  }

  function openDecisionModal() {
    if (!refs.decisionModal) return;
    state.decisionOpen = true;
    state.upgradeInProgress = false;
    const { afterCombat, nextCombat } = getDecisionContextByFloor(state.currentFloor);
    refs.decisionTitle.textContent = `Nodo de decision - Nivel ${afterCombat}`;
    refs.decisionDesc.textContent = `Zona: ${getCurrentLocationName()}. Acabas de superar el nivel ${afterCombat}; elige una ruta antes del nivel ${nextCombat}.`;
    if (refs.decisionMainOptions) refs.decisionMainOptions.style.display = 'grid';
    if (refs.upgradeFlow) refs.upgradeFlow.style.display = 'none';
    if (refs.upgradeCardPicker) refs.upgradeCardPicker.style.display = 'none';
    if (refs.upgradeCardGrid) refs.upgradeCardGrid.innerHTML = '';
    if (refs.addCardFlow) refs.addCardFlow.style.display = 'none';
    if (refs.addCardGrid) refs.addCardGrid.innerHTML = '';
    refs.decisionModal.style.display = 'flex';
  }

  function closeDecisionModal() {
    if (state.upgradeInProgress) return;
    state.decisionOpen = false;
    if (refs.decisionMainOptions) refs.decisionMainOptions.style.display = 'grid';
    if (refs.upgradeFlow) refs.upgradeFlow.style.display = 'none';
    if (refs.upgradeCardPicker) refs.upgradeCardPicker.style.display = 'none';
    if (refs.upgradeCardGrid) refs.upgradeCardGrid.innerHTML = '';
    if (refs.addCardFlow) refs.addCardFlow.style.display = 'none';
    if (refs.addCardGrid) refs.addCardGrid.innerHTML = '';
    if (refs.shopFlow) refs.shopFlow.style.display = 'none';
    if (refs.shopItemsGrid) refs.shopItemsGrid.innerHTML = '';
    if (refs.decisionModal) refs.decisionModal.style.display = 'none';
    closeShopItemPreview();
  }

  function getUnselectedCandidates() {
    const selectedSet = new Set((state.selectedInitialCardIds || []).map((id) => String(id)));
    return (state.inventoryCards || []).filter((card) => !selectedSet.has(String(card.id)));
  }

  function openAddCardFlow() {
    const runDeckBaseIds = getRunDeckBaseIds();
    if (runDeckBaseIds.length >= MAX_RUN_DECK_CARDS) {
      alert(`Ya has alcanzado el maximo de cartas en la run (${MAX_RUN_DECK_CARDS}).`);
      return;
    }

    if (refs.decisionMainOptions) refs.decisionMainOptions.style.display = 'none';
    if (refs.upgradeFlow) refs.upgradeFlow.style.display = 'none';
    if (refs.addCardFlow) refs.addCardFlow.style.display = 'block';
    renderAddCardInventory();
  }

  function confirmAddCardToRun(cardId, cardName) {
    const confirmed = confirm(`¿Quieres añadir la carta ${cardName} a tu run?`);
    if (!confirmed) return;

    if (getRunDeckBaseIds().length >= MAX_RUN_DECK_CARDS) {
      alert(`Ya has alcanzado el maximo de cartas en la run (${MAX_RUN_DECK_CARDS}).`);
      return;
    }

    const alreadyInRun = getRunDeckBaseIds().some(rId => {
      if (typeof window.areSamePlayerCards === 'function') {
        return window.areSamePlayerCards(rId, cardId);
      }
      return getBaseCardName(rId) === getBaseCardName(cardId);
    });

    if (alreadyInRun) {
      alert(`Ya tienes una versión de ${cardName} en tu run actual del Modo Infinito.`);
      return;
    }

    if (!state.runDeckIds.includes(cardId)) {
      state.runDeckIds.push(cardId);
    }
    state.runStats.addedFromOutside += 1;
    state.shopRestocking = false;
    persistInfiniteRunState();
    renderTeamPreview();
    closeDecisionModal();
    advanceFloorAfterClear();
  }

  function renderAddCardInventory() {
    if (!refs.addCardGrid) return;

    const runDeckBaseIds = getRunDeckBaseIds();
    const reachedMax = runDeckBaseIds.length >= MAX_RUN_DECK_CARDS;
    const cards = Array.isArray(state.inventoryCards) ? state.inventoryCards : [];
    refs.addCardGrid.innerHTML = '';

    if (cards.length === 0) {
      refs.addCardGrid.innerHTML = '<div class="infinite-team-preview-empty">No hay cartas en inventario.</div>';
      return;
    }

    cards.forEach((card) => {
      const baseId = String(card?.id || '');
      const inRun = runDeckBaseIds.some(rId => {
        if (typeof window.areSamePlayerCards === 'function') {
          return window.areSamePlayerCards(rId, card);
        }
        return getBaseCardName(rId) === getBaseCardName(baseId, card);
      });

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `infinite-add-card-item${inRun ? ' in-run' : ''}`;
      btn.disabled = inRun || reachedMax;
      btn.innerHTML = `
        <img src="${card.imageUrl || card.image || ''}" alt="${card.name || baseId}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
        <span class="infinite-upgrade-card-fallback" style="display:none;">🃏</span>
        <span class="infinite-add-card-item-name">${card.name || baseId}</span>
      `;

      if (!inRun) {
        btn.addEventListener('click', () => {
          confirmAddCardToRun(baseId, card.name || baseId);
        });
      }

      refs.addCardGrid.appendChild(btn);
    });
  }

  function getUpgradeCandidateIds() {
    return Array.from(new Set(
      (Array.isArray(state.runDeckIds) && state.runDeckIds.length > 0 ? state.runDeckIds : state.selectedInitialCardIds)
        .map((id) => extractBaseCardId(id))
        .filter(Boolean)
    ));
  }

  function getCardSummaryForUpgrade(cardId) {
    const resolved = resolveCardDataFromMeta({ cardId });
    const card = resolved?.card || null;
    return {
      id: String(cardId || ''),
      name: String(card?.name || card?.nombre || cardId || 'Carta'),
      image: String(card?.imageUrl || card?.image || card?.imagen || '')
    };
  }

  function openUpgradeFlow() {
    const candidateIds = getUpgradeCandidateIds();
    if (candidateIds.length === 0) {
      alert('No hay cartas disponibles para mejorar en esta run.');
      return;
    }

    if (refs.decisionMainOptions) refs.decisionMainOptions.style.display = 'none';
    if (refs.upgradeFlow) refs.upgradeFlow.style.display = 'block';
    if (refs.upgradeCardPicker) refs.upgradeCardPicker.style.display = 'none';
    if (refs.upgradeCardGrid) refs.upgradeCardGrid.innerHTML = '';
  }

  function renderUpgradeCardPicker() {
    if (!refs.upgradeCardGrid || !refs.upgradeCardPicker) return;
    const candidateIds = getUpgradeCandidateIds();
    if (candidateIds.length === 0) {
      refs.upgradeCardGrid.innerHTML = '<div class="infinite-team-preview-empty">No hay cartas para buffear en esta run.</div>';
      refs.upgradeCardPicker.style.display = 'block';
      return;
    }

    refs.upgradeCardGrid.innerHTML = '';
    refs.upgradeCardPicker.style.display = 'block';

    candidateIds.forEach((cardId) => {
      const info = getCardSummaryForUpgrade(cardId);
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'infinite-upgrade-card-btn';
      button.innerHTML = `
        <img src="${info.image}" alt="${info.name}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
        <span class="infinite-upgrade-card-fallback" style="display:none;">🃏</span>
        <span class="infinite-upgrade-card-name">${info.name}</span>
      `;
      button.addEventListener('click', async () => {
        await executeUpgradeChoice({ mode: 'target', forcedCardId: info.id, minPercent: 2, maxPercent: 6 });
      });
      refs.upgradeCardGrid.appendChild(button);
    });
  }

  function computeUpgradeOutcome(chosenCardId, minPercent, maxPercent) {
    const cardLookup = resolveCardDataFromMeta({ cardId: chosenCardId });
    const cardData = cardLookup?.card || null;
    const upgradableStats = INFINITE_STAT_DEFS.filter((statDef) => getCardBaseStatValue(cardData, statDef) > 0);
    const chosenStat = upgradableStats.length > 0
      ? upgradableStats[Math.floor(Math.random() * upgradableStats.length)]
      : INFINITE_STAT_DEFS[Math.floor(Math.random() * INFINITE_STAT_DEFS.length)];

    const detectedBase = getCardBaseStatValue(cardData, chosenStat);
    const baseValue = detectedBase > 0 ? detectedBase : Math.max(1, Math.round(Number(cardData?.media) || 80));
    const percent = Math.max(minPercent, minPercent + Math.floor(Math.random() * (maxPercent - minPercent + 1)));
    const increase = Math.max(1, Math.round((baseValue * percent) / 100));

    if (!state.runCardBuffs[chosenCardId] || typeof state.runCardBuffs[chosenCardId] !== 'object') {
      state.runCardBuffs[chosenCardId] = {};
    }
    const currentBuff = Math.max(0, Number(state.runCardBuffs[chosenCardId][chosenStat.key]) || 0);
    state.runCardBuffs[chosenCardId][chosenStat.key] = currentBuff + increase;

    return {
      cardName: String(cardData?.name || cardData?.nombre || chosenCardId),
      cardImage: String(cardData?.imageUrl || cardData?.image || cardData?.imagen || ''),
      statLabel: chosenStat.label,
      statKey: chosenStat.key,
      percent,
      increase
    };
  }

  async function playUpgradeResultAnimation(result, modeLabel) {
    if (!refs.upgradeRollModal || !refs.upgradeRollPercent || !refs.upgradeRollStat || !refs.upgradeRollResult || !refs.upgradeRollCardName) {
      return;
    }

    const randomPercents = Array.from({ length: 9 }, (_, idx) => `+${idx + 2}%`);
    const randomStats = INFINITE_STAT_DEFS.map((entry) => entry.label);

    refs.upgradeRollCardName.textContent = `${result.cardName} • ${modeLabel}`;
    if (refs.upgradeRollCardImage) {
      refs.upgradeRollCardImage.src = result.cardImage || '';
    }

    // Reproducir SFX personalizado de mejora al iniciar la animación.
    if (typeof playSFX === 'function') {
      try {
        playSFX('upgradeCard', { volumeMultiplier: 1.0 });
      } catch {}
    }

    refs.upgradeRollResult.textContent = 'Rodando mejora...';
    refs.upgradeRollModal.style.display = 'flex';

    const reel = setInterval(() => {
      const randomPercent = randomPercents[Math.floor(Math.random() * randomPercents.length)];
      const randomStat = randomStats[Math.floor(Math.random() * randomStats.length)];
      refs.upgradeRollPercent.textContent = randomPercent;
      refs.upgradeRollStat.textContent = randomStat;
    }, 75);

    await new Promise((resolve) => setTimeout(resolve, 5000));
    clearInterval(reel);

    refs.upgradeRollPercent.textContent = `+${result.percent}%`;
    refs.upgradeRollStat.textContent = result.statLabel;
    refs.upgradeRollResult.textContent = `Resultado: +${result.increase} a ${result.statLabel}`;

    await new Promise((resolve) => setTimeout(resolve, 3000));
    refs.upgradeRollModal.style.display = 'none';
    if (refs.upgradeRollCardImage) refs.upgradeRollCardImage.src = '';
  }

  async function executeUpgradeChoice({ mode, forcedCardId = null, minPercent, maxPercent }) {
    if (state.upgradeInProgress) return;

    const candidateIds = getUpgradeCandidateIds();
    if (candidateIds.length === 0) {
      alert('No hay cartas disponibles para mejorar en esta run.');
      return;
    }

    let chosenCardId = forcedCardId;
    if (!chosenCardId) {
      chosenCardId = candidateIds[Math.floor(Math.random() * candidateIds.length)];
    }

    state.upgradeInProgress = true;
    if (refs.decisionCancel) refs.decisionCancel.disabled = true;
    if (refs.upgradeBackBtn) refs.upgradeBackBtn.disabled = true;

    try {
      const outcome = computeUpgradeOutcome(chosenCardId, minPercent, maxPercent);
      state.runStats.upgrades += 1;
      state.shopRestocking = false;
      await playUpgradeResultAnimation(outcome, mode === 'target' ? 'Eleccion' : 'Aleatoria');
      state.upgradeInProgress = false;
      if (refs.decisionCancel) refs.decisionCancel.disabled = false;
      if (refs.upgradeBackBtn) refs.upgradeBackBtn.disabled = false;
      closeDecisionModal();
      advanceFloorAfterClear();
    } catch (error) {
      state.upgradeInProgress = false;
      if (refs.decisionCancel) refs.decisionCancel.disabled = false;
      if (refs.upgradeBackBtn) refs.upgradeBackBtn.disabled = false;
      alert(`No se pudo aplicar la mejora: ${error?.message || error}`);
    }
  }

  async function loadShopConfig() {
    try {
      const response = await fetch(INFINITE_SHOP_REMOTE_URL + '?t=' + Date.now(), { cache: 'no-store' });
      if (response.ok) {
        const config = await response.json();
        if (config && Array.isArray(config.items) && config.items.length > 0) return config;
      }
    } catch (error) {
      console.warn('[INFINITE] No se pudo cargar configuracion remota de tienda:', error?.message || error);
    }

    try {
      const localResponse = await fetch('./infinite-shop.json?t=' + Date.now(), { cache: 'no-store' });
      if (localResponse.ok) {
        const localConfig = await localResponse.json();
        if (localConfig && Array.isArray(localConfig.items) && localConfig.items.length > 0) return localConfig;
      }
    } catch (localError) {
      console.warn('[INFINITE] No se pudo cargar configuracion local de tienda:', localError?.message || localError);
    }

    return null;
  }

  function getCurrentWorldId() {
    const worldConfig = state.worldConfig;
    if (!worldConfig || !Array.isArray(worldConfig.worldOrder) || worldConfig.worldOrder.length === 0) return null;
    const currentArcIndex = Math.floor((state.currentFloor - 1) / NODES_PER_ARC);
    return worldConfig.worldOrder[Math.min(currentArcIndex, worldConfig.worldOrder.length - 1)] || null;
  }

  function normalizeShopCurrency(rawCurrency) {
    const safe = String(rawCurrency || '').trim().toLowerCase();
    if (safe === 'kvr' || safe === 'kvr-coins' || safe === 'kvrcoin' || safe === 'kvrcoins') return 'kvr';
    if (safe === 'infinite-coins' || safe === 'infinite_coin' || safe === 'infinitecoins') return 'infinite-coins';
    if (safe === 'infinite-cardpoints' || safe === 'infinite_cardpoints' || safe === 'infinitecardpoints') return 'infinite-cardpoints';
    return 'coins';
  }

  function getShopCurrencyIcon(currency) {
    const normalized = normalizeShopCurrency(currency);
    if (normalized === 'kvr') return './kvr.png';
    if (normalized === 'infinite-coins') return './infinite-coin.png';
    if (normalized === 'infinite-cardpoints') return './infinite-cardpoint.png';
    return './coin.png';
  }

  function parseShopPrice(item) {
    const rawPrice = item?.price;
    if (rawPrice && typeof rawPrice === 'object') {
      return {
        amount: Math.max(0, Number(rawPrice.amount) || 0),
        currency: normalizeShopCurrency(rawPrice.currency)
      };
    }

    return {
      amount: Math.max(0, Number(rawPrice) || 0),
      currency: 'coins'
    };
  }

  function hydrateShopCurrencies() {
    const coinsValue = Number(String(byId('wallet-coins-amt')?.textContent || '0').replace(/[^\d.-]/g, '')) || 0;
    const kvrValue = Number(String(byId('wallet-kvr-amt')?.textContent || '0').replace(/[^\d.-]/g, '')) || 0;
    const coinsKey = getInfiniteUserKey('INFINITE_CURRENCY_COINS');
    const pointsKey = getInfiniteUserKey('INFINITE_CURRENCY_CARDPOINTS');
    const infiniteCoins = Number(localStorage.getItem(coinsKey) || localStorage.getItem('INFINITE_CURRENCY_COINS') || '0') || 0;
    const infiniteCardpoints = Number(localStorage.getItem(pointsKey) || localStorage.getItem('INFINITE_CURRENCY_CARDPOINTS') || '0') || 0;

    state.shopCurrencies.coins = Math.max(0, Math.floor(coinsValue));
    state.shopCurrencies.kvr = Math.max(0, Math.floor(kvrValue));
    state.shopCurrencies['infinite-coins'] = Math.max(0, Math.floor(infiniteCoins));
    state.shopCurrencies['infinite-cardpoints'] = Math.max(0, Math.floor(infiniteCardpoints));
  }

  async function hydrateInfiniteCurrenciesFromInventory() {
    if (!window.kvrcards || typeof window.kvrcards.getWallet !== 'function') return;

    try {
      const wallet = await window.kvrcards.getWallet();
      if (!wallet || typeof wallet !== 'object') return;

      const inventoryInfiniteCoins = Math.max(0, Math.floor(Number(wallet['infinite-coins']) || 0));
      const inventoryInfiniteCardpoints = Math.max(0, Math.floor(Number(wallet['infinite-cardpoints']) || 0));

      state.shopCurrencies['infinite-coins'] = inventoryInfiniteCoins;
      state.shopCurrencies['infinite-cardpoints'] = inventoryInfiniteCardpoints;

      localStorage.setItem(getInfiniteUserKey('INFINITE_CURRENCY_COINS'), String(inventoryInfiniteCoins));
      localStorage.setItem(getInfiniteUserKey('INFINITE_CURRENCY_CARDPOINTS'), String(inventoryInfiniteCardpoints));

      renderShopCurrencyBar();
    } catch (error) {
      console.warn('[INFINITE] No se pudo hidratar monedas infinitas desde inventario:', error?.message || error);
    }
  }

  function syncInfiniteCurrenciesToInventory() {
    if (!window.kvrcards || typeof window.kvrcards.walletUpdateInfiniteCurrencies !== 'function') return;

    const payload = {
      'infinite-coins': Math.max(0, Math.floor(Number(state.shopCurrencies['infinite-coins']) || 0)),
      'infinite-cardpoints': Math.max(0, Math.floor(Number(state.shopCurrencies['infinite-cardpoints']) || 0))
    };

    window.kvrcards.walletUpdateInfiniteCurrencies(payload).catch((error) => {
      console.warn('[INFINITE] No se pudieron guardar monedas infinitas en inventario:', error?.message || error);
    });
  }

  function persistInfiniteCurrencies() {
    localStorage.setItem(getInfiniteUserKey('INFINITE_CURRENCY_COINS'), String(Math.max(0, Math.floor(Number(state.shopCurrencies['infinite-coins']) || 0))));
    localStorage.setItem(getInfiniteUserKey('INFINITE_CURRENCY_CARDPOINTS'), String(Math.max(0, Math.floor(Number(state.shopCurrencies['infinite-cardpoints']) || 0))));
    syncInfiniteCurrenciesToInventory();
  }

  function renderShopCurrencyBar() {
    const coinsEl = byId('infinite-shop-currency-coins');
    const kvrEl = byId('infinite-shop-currency-kvr');
    const infCoinsEl = byId('infinite-shop-currency-infinite-coins');
    const infCardpointsEl = byId('infinite-shop-currency-infinite-cardpoints');

    if (coinsEl) coinsEl.textContent = String(Math.max(0, Math.floor(Number(state.shopCurrencies.coins) || 0)));
    if (kvrEl) kvrEl.textContent = String(Math.max(0, Math.floor(Number(state.shopCurrencies.kvr) || 0)));
    if (infCoinsEl) infCoinsEl.textContent = String(Math.max(0, Math.floor(Number(state.shopCurrencies['infinite-coins']) || 0)));
    if (infCardpointsEl) infCardpointsEl.textContent = String(Math.max(0, Math.floor(Number(state.shopCurrencies['infinite-cardpoints']) || 0)));
  }

  async function renderShopkeeper() {
    if (!refs.shopkeeperImageBtn || !refs.shopkeeperImage) return;

    let shopConfig = state.shopConfig;
    if (!shopConfig) {
      shopConfig = await loadShopConfig();
      state.shopConfig = shopConfig;
    }

    if (!shopConfig || !Array.isArray(shopConfig.shopkeepers) || shopConfig.shopkeepers.length === 0) {
      refs.shopkeeperImageBtn.style.display = 'none';
      return;
    }

    const currentWorldId = getCurrentWorldId();
    const availableShopkeepers = shopConfig.shopkeepers.filter((shopkeeper) => {
      if (!currentWorldId) return true;
      return Array.isArray(shopkeeper.availableAt) && shopkeeper.availableAt.includes(currentWorldId);
    });

    const selectedShopkeeper = availableShopkeepers[0] || shopConfig.shopkeepers[0];
    if (!selectedShopkeeper) {
      refs.shopkeeperImageBtn.style.display = 'none';
      return;
    }

    refs.shopkeeperImage.src = selectedShopkeeper.image || '';
    refs.shopkeeperImage.alt = selectedShopkeeper.name || 'Tiendero';
    refs.shopkeeperImageBtn.style.display = 'block';
    refs.shopkeeperImageBtn.onclick = () => showShopkeeperDialogue(selectedShopkeeper);
  }

  function showShopkeeperDialogue(shopkeeper) {
    if (!shopkeeper || !Array.isArray(shopkeeper.dialogues) || shopkeeper.dialogues.length === 0) return;

    const bubble = refs.shopDialogueBubble;
    const text = refs.shopDialogueText;
    if (!bubble || !text) return;

    const randomDialogue = shopkeeper.dialogues[Math.floor(Math.random() * shopkeeper.dialogues.length)];

    // SFX corto al iniciar interacción con el tiendero.
    if (typeof playSFX === 'function') {
      try {
        playSFX('shopkeeperInteract', { volumeMultiplier: 1.0 });
      } catch {}
    }

    if (window.shopDialogueTypeInterval) {
      clearInterval(window.shopDialogueTypeInterval);
      window.shopDialogueTypeInterval = null;
    }

    if (window.shopDialogueTypingAudio) {
      try {
        if (typeof stopSFX === 'function') {
          stopSFX(window.shopDialogueTypingAudio, 120);
        } else {
          window.shopDialogueTypingAudio.pause();
          window.shopDialogueTypingAudio.currentTime = 0;
        }
      } catch {}
      window.shopDialogueTypingAudio = null;
    }

    text.textContent = '';
    bubble.style.display = 'block';

    if (typeof playSFX === 'function') {
      try {
        window.shopDialogueTypingAudio = playSFX('shopkeeperTyping', { volumeMultiplier: 0.42, loop: true }) || null;
      } catch {
        window.shopDialogueTypingAudio = null;
      }
    }

    let charIndex = 0;
    window.shopDialogueTypeInterval = setInterval(() => {
      charIndex += 1;
      text.textContent = randomDialogue.slice(0, charIndex);

      if (charIndex >= randomDialogue.length) {
        clearInterval(window.shopDialogueTypeInterval);
        window.shopDialogueTypeInterval = null;
        if (window.shopDialogueTypingAudio) {
          try {
            if (typeof stopSFX === 'function') {
              stopSFX(window.shopDialogueTypingAudio, 120);
            } else {
              window.shopDialogueTypingAudio.pause();
              window.shopDialogueTypingAudio.currentTime = 0;
            }
          } catch {}
          window.shopDialogueTypingAudio = null;
        }
      }
    }, 36);

    if (window.shopDialogueTimeout) {
      clearTimeout(window.shopDialogueTimeout);
    }

    window.shopDialogueTimeout = setTimeout(() => {
      if (window.shopDialogueTypeInterval) {
        clearInterval(window.shopDialogueTypeInterval);
        window.shopDialogueTypeInterval = null;
      }
      if (window.shopDialogueTypingAudio) {
        try {
          if (typeof stopSFX === 'function') {
            stopSFX(window.shopDialogueTypingAudio, 120);
          } else {
            window.shopDialogueTypingAudio.pause();
            window.shopDialogueTypingAudio.currentTime = 0;
          }
        } catch {}
        window.shopDialogueTypingAudio = null;
      }
      bubble.style.display = 'none';
    }, 5200);
  }

  function openShopFlow() {
    if (refs.decisionMainOptions) refs.decisionMainOptions.style.display = 'none';
    if (refs.upgradeFlow) refs.upgradeFlow.style.display = 'none';
    if (refs.addCardFlow) refs.addCardFlow.style.display = 'none';
    state.shopDecisionWillBeConsumed = false;
    state.currentShopItemIds = null; // Forces a fresh probability roll for this visit
    if (refs.shopFlow) refs.shopFlow.style.display = 'block';
    hydrateShopCurrencies();
    hydrateInfiniteCurrenciesFromInventory();
    renderShopCurrencyBar();
    renderShopItems();
    renderShopkeeper();
  }

  function normalizeShopItemRarity(rawRarity) {
    const safe = String(rawRarity || '').trim().toLowerCase();
    if (safe === 'knight') return 'knight';
    if (safe === 'legendary') return 'legendary';
    if (safe === 'epic') return 'epic';
    if (safe === 'rare') return 'rare';
    if (safe === 'uncommon') return 'uncommon';
    return 'common';
  }

  function parseItemProbability(item) {
    const raw = item?.probability;
    if (raw === undefined || raw === null || raw === '') return 1;
    const num = Number(raw);
    if (isNaN(num)) return 1;
    return Math.max(0, Math.min(1, num));
  }

  function rollShopItemsForCurrentVisit(shopConfig) {
    if (!shopConfig || !Array.isArray(shopConfig.items) || shopConfig.items.length === 0) {
      state.currentShopItemIds = [];
      return [];
    }

    const currentLevel = normalizeFloorValue(state.currentFloor);
    const candidateItems = shopConfig.items.filter((item) => currentLevel >= Math.max(1, Number(item?.minLevel || 1)));

    const rolled = candidateItems.filter((item) => {
      const prob = parseItemProbability(item);
      if (prob <= 0) return false;
      if (prob >= 1) return true;
      return Math.random() < prob;
    });

    if (rolled.length === 0 && candidateItems.length > 0) {
      const guaranteed = candidateItems.filter((item) => parseItemProbability(item) >= 1);
      if (guaranteed.length > 0) {
        state.currentShopItemIds = guaranteed.map((i) => String(i.id || ''));
        return guaranteed;
      }
    }

    state.currentShopItemIds = rolled.map((i) => String(i.id || ''));
    return rolled;
  }

  async function renderShopItems() {
    if (!refs.shopItemsGrid) return;

    let shopConfig = state.shopConfig;
    if (!shopConfig) {
      shopConfig = await loadShopConfig();
      state.shopConfig = shopConfig;
    }

    if (!shopConfig || !Array.isArray(shopConfig.items) || shopConfig.items.length === 0) {
      refs.shopItemsGrid.innerHTML = '<div class="infinite-team-preview-empty">No hay objetos disponibles en la tienda.</div>';
      return;
    }

    // Aplicar fondo desde shopConfig
    const shopBackgroundEl = byId('infinite-shop-background');
    if (shopBackgroundEl && shopConfig.backgroundImage) {
      shopBackgroundEl.style.backgroundImage = `url('${shopConfig.backgroundImage}')`;
    }

    refs.shopItemsGrid.innerHTML = '';

    if (!Array.isArray(state.currentShopItemIds)) {
      rollShopItemsForCurrentVisit(shopConfig);
    }

    const currentLevel = normalizeFloorValue(state.currentFloor);
    const visibleItemIds = new Set(state.currentShopItemIds || []);
    const availableItems = shopConfig.items.filter((item) => {
      if (currentLevel < Math.max(1, Number(item?.minLevel || 1))) return false;
      return visibleItemIds.has(String(item.id || ''));
    });

    if (availableItems.length === 0) {
      refs.shopItemsGrid.innerHTML = '<div class="infinite-team-preview-empty">No hay objetos disponibles en esta visita de la tienda.</div>';
      return;
    }

    const getStockForItem = (item) => {
      const itemId = String(item?.id || '').trim();
      if (!itemId) return { total: 0, remaining: 0 };

      if (!state.shopItemStock[itemId]) {
        const total = Math.max(0, Number(item?.quantity ?? item?.stock ?? 1) || 0);
        state.shopItemStock[itemId] = { total, remaining: total };
      }

      const stock = state.shopItemStock[itemId];
      return {
        total: Math.max(0, Number(stock.total) || 0),
        remaining: Math.max(0, Number(stock.remaining) || 0)
      };
    };

    availableItems.forEach((item) => {
      const rarity = normalizeShopItemRarity(item?.rarity);
      const stock = getStockForItem(item);
      const soldOut = stock.remaining <= 0;

      const btn = document.createElement('button');
      const priceInfo = parseShopPrice(item);
      const priceIcon = getShopCurrencyIcon(priceInfo.currency);
      btn.type = 'button';
      btn.className = `infinite-shop-item rarity-${rarity}${soldOut ? ' is-sold-out' : ''}`;
      btn.disabled = soldOut;
      btn.innerHTML = `
        <span class="infinite-shop-item-stock">${stock.remaining}/${stock.total}</span>
        <img src="${item.image || ''}" alt="${item.name || 'Objeto'}" class="infinite-shop-item-image" onerror="this.style.display='none';" />
        <span class="infinite-shop-item-name">${item.name || 'Objeto'}</span>
        <span class="infinite-shop-item-price"><img src="${priceIcon}" alt="${priceInfo.currency}" class="price-currency-icon" /> ${priceInfo.amount}</span>
        ${soldOut ? '<span class="infinite-shop-item-soldout">AGOTADO</span>' : ''}
      `;

      if (!soldOut) {
        btn.addEventListener('click', () => {
          openShopItemPreview(item);
        });
      }

      refs.shopItemsGrid.appendChild(btn);
    });
  }

  function openShopItemPreview(item) {
    if (!item || typeof item !== 'object') return;

    const itemId = String(item?.id || '').trim();
    const stock = state.shopItemStock[itemId];
    const remaining = Math.max(0, Number(stock?.remaining) || 0);
    const total = Math.max(0, Number(stock?.total) || 0);
    if (total > 0 && remaining <= 0) return;

    const previewModal = refs.shopItemPreviewModal;
    if (!previewModal) return;

    const previewName = byId('infinite-shop-preview-name');
    const previewPrice = byId('infinite-shop-preview-price');
    const previewImage = byId('infinite-shop-preview-image');
    const previewCard = previewModal.querySelector('.infinite-shop-item-preview-card');
    const previewImageWrap = previewModal.querySelector('.infinite-shop-preview-image-wrap');
    const previewDescription = byId('infinite-shop-preview-description');
    const confirmBtn = byId('infinite-shop-preview-confirm');
    const cancelBtn = byId('infinite-shop-preview-cancel');
    const rarity = normalizeShopItemRarity(item?.rarity);
    const priceInfo = parseShopPrice(item);

    const rarityClasses = ['rarity-common', 'rarity-uncommon', 'rarity-rare', 'rarity-epic', 'rarity-legendary', 'rarity-knight'];

    if (previewCard) {
      previewCard.classList.remove(...rarityClasses);
      previewCard.classList.add(`rarity-${rarity}`);
    }

    if (previewImageWrap) {
      previewImageWrap.classList.remove(...rarityClasses);
      previewImageWrap.classList.add(`rarity-${rarity}`);
    }

    if (previewName) previewName.textContent = item.name || 'Objeto';
    if (previewPrice) previewPrice.innerHTML = `<img src="${getShopCurrencyIcon(priceInfo.currency)}" alt="${priceInfo.currency}" class="price-currency-icon" /> Precio: ${priceInfo.amount} · Disponibles: ${remaining}/${total}`;
    if (previewImage) previewImage.src = item.image || '';
    if (previewDescription) previewDescription.textContent = item.description || 'Sin descripción disponible.';

    if (confirmBtn) {
      confirmBtn.textContent = 'Comprar Objeto';
      confirmBtn.onclick = () => confirmPurchaseItem(item);
    }

    if (cancelBtn) {
      cancelBtn.onclick = () => closeShopItemPreview();
    }

    previewModal.style.display = 'flex';
  }

  function closeShopItemPreview() {
    if (refs.shopItemPreviewModal) {
      refs.shopItemPreviewModal.style.display = 'none';
    }
  }

  function parseItemEffects(item) {
    if (!item || typeof item !== 'object') return [];

    // 1. Direct explicit effects array or object
    if (Array.isArray(item.effects) && item.effects.length > 0) {
      return item.effects;
    }
    if (item.effect && typeof item.effect === 'object') {
      return [item.effect];
    }
    if (item.buff && typeof item.buff === 'object') {
      return Array.isArray(item.buff) ? item.buff : [item.buff];
    }

    // 2. Parse from item.description
    const desc = String(item.description || '').toLowerCase();
    const effects = [];

    // Split on connectors, but do NOT split 'defensa y velocidad'
    const clauseRegex = /\s*(?:mientras que|pero|además|ademas|\by\s+(?=(?:baja|reduce|disminuye|resta|aumenta|incrementa|sube|suma|pierde)\b))\s*/i;
    const clauses = desc.split(clauseRegex);

    clauses.forEach((clause) => {
      clause = clause.trim();
      if (!clause) return;

      const isDecrease = /\b(baja|reduce|disminuye|resta|nerf|nerfeo|pierde)\b/i.test(clause);
      const isIncrease = /\b(aumenta|incrementa|sube|suma|otorga|da|bufeo|buff)\b/i.test(clause);

      // Extract percent or flat
      const percentMatch = clause.match(/(\d+)\s*%/);
      const flatMatches = [...clause.matchAll(/(\d+)\s*(?:puntos?|pts)/gi)];

      // Target determination
      let target = 'same-target';
      const procedencias = ['jinushi', 'kizoku', 'atsuigakure', 'atsui', 'konohagakure', 'konoha', 'sunagakure', 'suna', 'kirigakure', 'kiri', 'kumogakure', 'kumo', 'iwagakure', 'iwa', 'otogakure', 'oto', 'akatsuki', 'samurai', 'anbu', 'raiz', 'monjes', 'artistas'];
      for (const proc of procedencias) {
        if (clause.includes(proc)) {
          target = `procedencia:${proc}`;
          break;
        }
      }

      if (target === 'same-target') {
        if (clause.includes('todo el equipo') || clause.includes('todas las cartas') || clause.includes('a todo')) {
          target = 'all';
        } else if (clause.includes('aleatoria') || clause.includes('elección') || clause.includes('eleccion') || clause.includes('una carta')) {
          target = 'single-card';
        }
      }

      // Check stats
      let stats = [];
      if (clause.includes('todas las stats') || clause.includes('todos los stats') || clause.includes('todas') || clause.includes('todos')) {
        stats = 'all';
      } else {
        if (clause.includes('ninjutsu')) stats.push('ninjutsu');
        if (clause.includes('taijutsu')) stats.push('taijutsu');
        if (clause.includes('resistencia')) stats.push('resistencia');
        if (clause.includes('velocidad') || clause.includes('speed')) stats.push('velocidad');
        if (clause.includes('defensa') || clause.includes('defense')) stats.push('defensa');
        if (clause.includes('fisico') || clause.includes('físico')) stats.push('fisico');
        if (stats.length === 0) stats = 'all';
      }

      const percent = percentMatch ? Number(percentMatch[1]) * (isDecrease ? -1 : 1) : null;

      if (flatMatches.length > 0) {
        flatMatches.forEach((m) => {
          const num = Number(m[1]) * (isDecrease ? -1 : 1);
          const snippetAfter = clause.substring(m.index + m[0].length, m.index + m[0].length + 25).toLowerCase();
          let specificStat = null;
          if (snippetAfter.includes('ninjutsu')) specificStat = ['ninjutsu'];
          else if (snippetAfter.includes('taijutsu')) specificStat = ['taijutsu'];
          else if (snippetAfter.includes('resistencia')) specificStat = ['resistencia'];
          else if (snippetAfter.includes('velocidad')) specificStat = ['velocidad'];
          else if (snippetAfter.includes('defensa')) specificStat = ['defensa'];
          else if (snippetAfter.includes('fisico')) specificStat = ['fisico'];

          effects.push({
            target,
            stats: specificStat || stats,
            flat: num,
            percent: null
          });
        });
      } else if (percent !== null) {
        effects.push({
          target,
          stats,
          flat: null,
          percent
        });
      } else {
        effects.push({
          target,
          stats,
          flat: isDecrease ? -1 : 1,
          percent: null
        });
      }
    });

    if (effects.length === 0) {
      return [{ target: 'single-card', stats: ['velocidad', 'defensa'], percent: 5, flat: null }];
    }

    return effects;
  }

  function applyShopItemEffect(item, chosenCardId = null) {
    const candidateIds = getUpgradeCandidateIds();
    if (candidateIds.length === 0) {
      return { success: false, message: 'No hay cartas en la run actual.', affectedCards: [] };
    }

    if (isBastonItem(item)) {
      const sharedCardId = chosenCardId || candidateIds[0];
      const card = resolveCardDataFromMeta({ cardId: sharedCardId })?.card;
      return applyBastonEffectToCard(sharedCardId, card, item);
    }

    const effects = parseItemEffects(item);
    const affectedMap = {};

    // Pick 1 single card to be the shared target for any single-card / same-target clauses
    const sharedSingleCardId = chosenCardId || candidateIds[Math.floor(Math.random() * candidateIds.length)];

    effects.forEach((eff) => {
      let targetCardIds = [];
      const targetType = String(eff.target || '').toLowerCase();

      if (targetType.startsWith('procedencia:') || eff.targetFilter?.procedencia || eff.procedencia) {
        const proc = (eff.targetFilter?.procedencia || eff.procedencia || targetType.replace('procedencia:', '')).toLowerCase().trim();
        targetCardIds = candidateIds.filter((id) => {
          const c = resolveCardDataFromMeta({ cardId: id })?.card;
          const cardProc = String(c?.procedencia || c?.origen || c?.source || c?.aldea || '').toLowerCase();
          return cardProc.includes(proc);
        });
      } else if (targetType.startsWith('calidad:') || eff.targetFilter?.calidad || eff.calidad) {
        const qual = (eff.targetFilter?.calidad || eff.calidad || targetType.replace('calidad:', '')).toLowerCase().trim();
        targetCardIds = candidateIds.filter((id) => {
          const c = resolveCardDataFromMeta({ cardId: id })?.card;
          const cardQual = String(c?.calidad || '').toLowerCase();
          return cardQual.includes(qual);
        });
      } else if (targetType === 'all' || targetType === 'team' || targetType.includes('todo')) {
        targetCardIds = [...candidateIds];
      } else {
        // 'single-card', 'same-target', 'random', or unspecified -> all apply to the SAME target card!
        targetCardIds = [sharedSingleCardId];
      }

      let statDefsToModify = [];
      if (eff.stats === 'all' || eff.stats === 'todas' || !eff.stats) {
        statDefsToModify = [...INFINITE_STAT_DEFS];
      } else if (Array.isArray(eff.stats)) {
        statDefsToModify = eff.stats.map((s) => findStatDefByKey(s)).filter(Boolean);
      } else {
        const s = findStatDefByKey(eff.stats);
        statDefsToModify = s ? [s] : [...INFINITE_STAT_DEFS];
      }

      targetCardIds.forEach((cardId) => {
        const resolved = resolveCardDataFromMeta({ cardId });
        const card = resolved?.card;
        if (!card) return;

        if (!state.runCardBuffs[cardId] || typeof state.runCardBuffs[cardId] !== 'object') {
          state.runCardBuffs[cardId] = {};
        }

        if (!affectedMap[cardId]) {
          affectedMap[cardId] = {
            cardId,
            card,
            cardName: String(card?.name || card?.nombre || cardId),
            cardImage: String(card?.imageUrl || card?.image || card?.imagen || './icon-oro.png'),
            procedencia: String(card?.procedencia || card?.origen || card?.source || card?.aldea || ''),
            changes: []
          };
        }

        statDefsToModify.forEach((statDef) => {
          const baseValue = Math.max(1, getCardBaseStatValue(card, statDef) || Number(card?.media) || 75);
          let delta = 0;
          let percent = 0;

          if (eff.percent !== null && eff.percent !== undefined) {
            percent = Number(eff.percent) || 0;
            delta = Math.round((baseValue * percent) / 100);
            if (percent > 0 && delta === 0) delta = 1;
            if (percent < 0 && delta === 0) delta = -1;
          } else if (eff.flat !== null && eff.flat !== undefined) {
            delta = Number(eff.flat) || 0;
          }

          if (delta === 0) return;

          const currentBuff = Number(state.runCardBuffs[cardId][statDef.key]) || 0;
          const newBuff = currentBuff + delta;
          state.runCardBuffs[cardId][statDef.key] = newBuff;

          affectedMap[cardId].changes.push({
            statKey: statDef.key,
            statLabel: statDef.label,
            delta,
            percent: percent || 0,
            isPositive: delta > 0,
            previousBuff: currentBuff,
            newBuff
          });
        });
      });
    });

    persistInfiniteRunState();
    renderTeamPreview();
    renderRunStatus();

    return {
      success: true,
      affectedCards: Object.values(affectedMap)
    };
  }

  function showBuffAnimation(item, result) {
    return new Promise((resolve) => {
      const modal = refs.buffAnimationModal;
      const titleEl = refs.buffAnimationTitle;
      const contentEl = refs.buffAnimationContent;
      const acceptBtn = refs.buffAnimationAcceptBtn;

      if (!modal || !contentEl) {
        if (result?.messages?.length) alert(result.messages.join('\n'));
        resolve();
        return;
      }

      const affectedCards = Array.isArray(result?.affectedCards) ? result.affectedCards : [];
      const itemName = item?.name || 'Mejora de Tienda';
      const itemImg = item?.image || '';

      if (typeof playSFX === 'function') {
        try {
          playSFX('upgradeCard', { volumeMultiplier: 1.0 });
        } catch {}
      }

      const itemBadgeHtml = `
        <div class="infinite-buff-item-badge">
          ${itemImg ? `<img src="${itemImg}" alt="${itemName}" class="infinite-buff-item-badge-img" onerror="this.style.display='none';" />` : ''}
          <span>${itemName}</span>
        </div>
      `;

      if (affectedCards.length === 1) {
        if (titleEl) titleEl.textContent = '¡MEJORA APLICADA!';
        const cardInfo = affectedCards[0];
        const changesHtml = cardInfo.changes.map((ch) => {
          const sign = ch.delta > 0 ? '+' : '';
          const pctLabel = ch.percent ? ` (${sign}${ch.percent}%)` : '';
          const cls = ch.isPositive ? 'positive' : 'negative';
          const icon = ch.isPositive ? '▲' : '▼';
          return `<div class="infinite-buff-stat-pill ${cls}">${icon} ${ch.statLabel} ${sign}${ch.delta}${pctLabel}</div>`;
        }).join('');

        contentEl.innerHTML = `
          ${itemBadgeHtml}
          <div class="infinite-buff-single-wrap">
            <img src="${cardInfo.cardImage}" alt="${cardInfo.cardName}" class="infinite-buff-single-card-img" onerror="this.src='./icon-oro.png';" />
            <div class="infinite-buff-single-card-name">${cardInfo.cardName} ${cardInfo.procedencia ? `<span style="font-size:12px; color:#94a3b8; font-weight:normal;">(${cardInfo.procedencia.toUpperCase()})</span>` : ''}</div>
            <div class="infinite-buff-single-stats-list">${changesHtml}</div>
          </div>
        `;
      } else if (affectedCards.length > 1) {
        if (titleEl) titleEl.textContent = '¡MEJORAS DE EQUIPO APLICADAS!';
        const cardsGridHtml = affectedCards.map((cardInfo) => {
          const tagsHtml = cardInfo.changes.map((ch) => {
            const sign = ch.delta > 0 ? '+' : '';
            const cls = ch.isPositive ? 'positive' : 'negative';
            return `<span class="infinite-buff-multi-tag ${cls}">${ch.statLabel} ${sign}${ch.delta}</span>`;
          }).join('');

          return `
            <div class="infinite-buff-multi-card-item">
              <img src="${cardInfo.cardImage}" alt="${cardInfo.cardName}" class="infinite-buff-multi-card-thumb" onerror="this.src='./icon-oro.png';" />
              <div class="infinite-buff-multi-card-info">
                <div class="infinite-buff-multi-card-name">${cardInfo.cardName}</div>
                <div class="infinite-buff-multi-card-proc">${cardInfo.procedencia ? cardInfo.procedencia.toUpperCase() : 'GENERAL'}</div>
                <div class="infinite-buff-multi-changes-list">${tagsHtml}</div>
              </div>
            </div>
          `;
        }).join('');

        contentEl.innerHTML = `
          ${itemBadgeHtml}
          <div class="infinite-buff-multi-grid">${cardsGridHtml}</div>
        `;
      } else {
        if (titleEl) titleEl.textContent = '¡EFECTO APLICADO!';
        contentEl.innerHTML = `
          ${itemBadgeHtml}
          <p style="color:#e2e8f0; margin:16px 0;">El objeto se ha aplicado correctamente.</p>
        `;
      }

      modal.style.display = 'flex';

      const handleClose = () => {
        modal.style.display = 'none';
        if (acceptBtn) acceptBtn.onclick = null;
        resolve();
      };

      if (acceptBtn) {
        acceptBtn.onclick = handleClose;
      }
    });
  }

  function renderInfiniteConsumables() {
    if (!refs.consumablesContainer) return;
    const items = Array.isArray(state.consumableItems) ? state.consumableItems : [];
    refs.consumablesContainer.innerHTML = '';
    if (items.length === 0) {
      refs.consumablesContainer.style.display = 'none';
      return;
    }
    refs.consumablesContainer.style.display = 'inline-flex';

    items.forEach((item, index) => {
      const rarity = normalizeShopItemRarity(item?.rarity);
      const slot = document.createElement('div');
      slot.className = `infinite-consumable-slot rarity-${rarity}`;
      slot.setAttribute('data-index', String(index));
      slot.setAttribute('role', 'button');
      slot.setAttribute('tabindex', '0');
      slot.innerHTML = `
        <img src="${item.image || ''}" alt="${item.name || 'Consumible'}" class="infinite-consumable-img" onerror="this.style.display='none';" />
        <div class="infinite-consumable-tooltip">
          <div class="infinite-consumable-tooltip-title">${item.name || 'Objeto Consumible'}</div>
          <div class="infinite-consumable-tooltip-desc">${item.description || 'Haz click para usar este objeto.'}</div>
          <div class="infinite-consumable-tooltip-cta">▶ Haz click para activar</div>
        </div>
      `;

      slot.addEventListener('click', () => {
        activateConsumableItem(index);
      });

      refs.consumablesContainer.appendChild(slot);
    });
  }

  function isItemMatch(item, num) {
    if (!item || typeof item !== 'object') return false;
    const id = String(item.id || '').trim().toLowerCase();
    const numStr = String(num);
    const padStr = numStr.padStart(3, '0');

    if (id === `item${numStr}` || id === `item_${numStr}` || id === `item${padStr}` || id === `item_${padStr}`) {
      return true;
    }

    const match = id.match(/^item_?0*(\d+)$/i);
    if (match && parseInt(match[1], 10) === num) {
      return true;
    }

    const name = String(item.name || '').trim().toLowerCase();
    if (name === `item ${numStr}` || name === `item ${padStr}` || name === `item${numStr}`) {
      return true;
    }

    return false;
  }

  function isPergaminoItem(item) {
    if (!item || typeof item !== 'object') return false;
    for (let n = 20; n <= 25; n++) {
      if (isItemMatch(item, n)) return false;
    }
    const id = String(item.id || '').toLowerCase();
    const name = String(item.name || '').toLowerCase();
    const desc = String(item.description || '').toLowerCase();
    return id.includes('pergamino') || ['item_004', 'item_005', 'item_006', 'item_007', 'item_008'].includes(id) || name.includes('pergamino') || desc.includes('stat a elección') || desc.includes('stat a eleccion');
  }

  function getPergaminoPoints(item) {
    const id = String(item?.id || '').toLowerCase();
    if (id === 'item_004') return 1;
    if (id === 'item_005') return 2;
    if (id === 'item_006') return 3;
    if (id === 'item_007') return 4;
    if (id === 'item_008') return 5;

    const desc = String(item?.description || '').toLowerCase();
    const m = desc.match(/(\d+)\s*(?:pts?|puntos?)/i);
    return m ? Math.max(1, Number(m[1]) || 1) : 1;
  }

  function handlePergaminoChoiceFlow(item) {
    return new Promise((resolve) => {
      const modal = refs.pergaminoModal;
      const titleEl = refs.pergaminoTitle;
      const subtitleEl = refs.pergaminoSubtitle;
      const stepCards = refs.pergaminoStepCards;
      const stepStats = refs.pergaminoStepStats;
      const cardPreview = refs.pergaminoCardPreview;
      const statsGrid = refs.pergaminoStatsGrid;
      const cancelBtn = refs.pergaminoCancelBtn;

      const points = getPergaminoPoints(item);
      const candidateIds = getUpgradeCandidateIds();
      if (candidateIds.length === 0) {
        alert('No tienes cartas en tu equipo para mejorar.');
        resolve({ cancelled: true });
        return;
      }

      // 1. Pick card randomly
      const chosenCardId = candidateIds[Math.floor(Math.random() * candidateIds.length)];
      const resolved = resolveCardDataFromMeta({ cardId: chosenCardId });
      const card = resolved?.card;
      const cardName = String(card?.name || card?.nombre || chosenCardId);
      const cardImg = String(card?.imageUrl || card?.image || card?.imagen || './icon-oro.png');
      const cardProc = String(card?.procedencia || card?.origen || card?.source || card?.aldea || '').trim();

      if (!modal || !statsGrid) {
        const res = applyShopItemEffect(item);
        showBuffAnimation(item, res).then(resolve);
        return;
      }

      if (titleEl) titleEl.textContent = `📜 ${item.name || 'MEJORA DE PERGAMINO'} (+${points} PTS)`;
      if (subtitleEl) subtitleEl.textContent = `Carta elegida al azar: ${cardName}. Selecciona la estadística que deseas aumentar (+${points} pts):`;

      if (stepCards) stepCards.style.display = 'none';
      if (stepStats) stepStats.style.display = 'block';

      if (cardPreview) {
        cardPreview.innerHTML = `
          <img src="${cardImg}" alt="${cardName}" onerror="this.src='./icon-oro.png';" />
          <div class="infinite-pergamino-card-preview-info">
            <div class="infinite-pergamino-card-preview-name">${cardName}</div>
            <div style="font-size:11px; color:#94a3b8; text-transform:uppercase;">${cardProc || 'GENERAL'} · CARTA ALEATORIA</div>
          </div>
        `;
      }

      statsGrid.innerHTML = '';
      const statIcons = {
        ninjutsu: '🔮',
        taijutsu: '🥋',
        resistencia: '🛡️',
        velocidad: '⚡',
        defensa: '🏰',
        fisico: '💥'
      };

      INFINITE_STAT_DEFS.forEach((statDef) => {
        const currentBase = Math.max(1, getCardBaseStatValue(card, statDef) || Number(card?.media) || 75);
        const currentBuff = Number(state.runCardBuffs?.[chosenCardId]?.[statDef.key]) || 0;
        const currentTotal = currentBase + currentBuff;
        const newTotal = currentTotal + points;

        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'infinite-pergamino-stat-btn';
        btn.innerHTML = `
          <span class="infinite-pergamino-stat-name">${statIcons[statDef.key] || '✦'} ${statDef.label}</span>
          <span class="infinite-pergamino-stat-badge">+${points} (${currentTotal} → ${newTotal})</span>
        `;

        btn.addEventListener('click', async () => {
          if (!state.runCardBuffs[chosenCardId] || typeof state.runCardBuffs[chosenCardId] !== 'object') {
            state.runCardBuffs[chosenCardId] = {};
          }
          state.runCardBuffs[chosenCardId][statDef.key] = currentBuff + points;

          persistInfiniteRunState();
          renderTeamPreview();
          renderRunStatus();

          modal.style.display = 'none';

          const result = {
            success: true,
            affectedCards: [
              {
                cardId: chosenCardId,
                card,
                cardName,
                cardImage: cardImg,
                procedencia: cardProc,
                changes: [
                  {
                    statKey: statDef.key,
                    statLabel: statDef.label,
                    delta: points,
                    percent: 0,
                    isPositive: true,
                    previousBuff: currentBuff,
                    newBuff: currentBuff + points
                  }
                ]
              }
            ]
          };

          await showBuffAnimation(item, result);
          resolve({ success: true });
        });

        statsGrid.appendChild(btn);
      });

      modal.style.display = 'flex';

      if (cancelBtn) {
        cancelBtn.onclick = () => {
          modal.style.display = 'none';
          resolve({ cancelled: true });
        };
      }
    });
  }

  function isChapaItem(item) {
    if (!item || typeof item !== 'object') return false;
    const id = String(item.id || '').toLowerCase();
    const name = String(item.name || '').toLowerCase();
    const desc = String(item.description || '').toLowerCase();
    return id.includes('chapa') || ['item_009', 'item_011', 'item_012', 'item_013', 'item_014'].includes(id) || name.includes('chapa') || desc.includes('recibes una carta');
  }

  function isEvoCard(c) {
    if (!c) return false;
    const q = String(c?.calidad || c?.quality || '').toLowerCase().trim();
    return q === 'evo' || !!c.isEvo || String(c.id || '').toLowerCase().includes('_evo');
  }

  function isSpecialQuality(c) {
    if (!c) return false;
    const q = String(c?.calidad || c?.quality || '').toLowerCase().trim();
    if (!q || q === 'bronce' || q === 'plata' || q === 'oro' || q === 'evo') return false;
    return true;
  }

  function pickWeightedLowerMedia(cards, customWeightFn) {
    if (!cards || cards.length === 0) return null;
    if (cards.length === 1) return cards[0];

    let minMedia = Infinity;
    let maxMedia = -Infinity;
    cards.forEach((c) => {
      const m = Number(c.media) || 0;
      if (m < minMedia) minMedia = m;
      if (m > maxMedia) maxMedia = m;
    });

    const weightedList = cards.map((c) => {
      const m = Number(c.media) || 0;
      let w = 1;
      if (typeof customWeightFn === 'function') {
        w = customWeightFn(m, minMedia, maxMedia);
      } else {
        w = Math.pow(Math.max(1, maxMedia - m + 1), 2);
      }
      return { card: c, weight: Math.max(0.01, w) };
    });

    const totalWeight = weightedList.reduce((sum, item) => sum + item.weight, 0);
    let random = Math.random() * totalWeight;

    for (const item of weightedList) {
      if (random < item.weight) {
        return item.card;
      }
      random -= item.weight;
    }

    return weightedList[weightedList.length - 1].card;
  }

  async function handleChapaActivationFlow(item) {
    if (getRunDeckBaseIds().length >= MAX_RUN_DECK_CARDS) {
      alert(`Ya tienes el máximo de cartas en tu run (${MAX_RUN_DECK_CARDS} cartas).`);
      return { success: false };
    }

    let allCards = Object.values(state.catalogCardsById || {});
    if (allCards.length === 0 && window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
      const resp = await window.kvrcards.getAllCards();
      allCards = Array.isArray(resp) ? resp : (resp?.cards || []);
      if (allCards.length > 0) {
        state.catalogCardsById = allCards.reduce((acc, c) => {
          if (c?.id) acc[c.id] = c;
          return acc;
        }, {});
      }
    }

    if (allCards.length === 0) {
      alert('No se pudo cargar el catálogo de cartas para generar la recompensa.');
      return { success: false };
    }

    // Filtrar cartas EVO totalmente de cualquier chapa
    const validCards = allCards.filter((c) => !isEvoCard(c));

    const id = String(item?.id || '').toLowerCase();
    const desc = String(item?.description || '').toLowerCase();
    let eligibleCards = [];
    let isUniformRandom = false;
    let customWeightFn = null;

    if (id === 'item_009' || desc.includes('bronce')) {
      // 1. Chapa de Bronce: calidad bronce, prioridad a los de menos media
      eligibleCards = validCards.filter((c) => String(c?.calidad || '').toLowerCase() === 'bronce');
    } else if (id === 'item_011' || desc.includes('plata o de oro') || (desc.includes('plata') && desc.includes('oro'))) {
      // 2. Chapa de Plata/Oro: 80% Plata (65-74) / 20% Oro (75-85), prioridad a menos media
      const isGold = Math.random() < 0.2;
      if (isGold) {
        eligibleCards = validCards.filter((c) => {
          const q = String(c?.calidad || '').toLowerCase();
          const m = Number(c?.media) || 0;
          return q === 'oro' && m >= 75 && m <= 85;
        });
        if (eligibleCards.length === 0) {
          eligibleCards = validCards.filter((c) => String(c?.calidad || '').toLowerCase() === 'oro' && (Number(c?.media) || 0) <= 85);
        }
      } else {
        eligibleCards = validCards.filter((c) => {
          const q = String(c?.calidad || '').toLowerCase();
          const m = Number(c?.media) || 0;
          return q === 'plata' && m >= 65 && m <= 74;
        });
        if (eligibleCards.length === 0) {
          eligibleCards = validCards.filter((c) => String(c?.calidad || '').toLowerCase() === 'plata');
        }
      }
      if (eligibleCards.length === 0) {
        eligibleCards = validCards.filter((c) => ['plata', 'oro'].includes(String(c?.calidad || '').toLowerCase()));
      }
    } else if (id === 'item_012' || desc.includes('oro o superior') || desc.includes('prodigio')) {
      // 3. Chapa Prodigio: 80% Oro / 20% Especiales, rango 80 a 90+, pero a partir de 89 especialmente raro
      const isSpecial = Math.random() < 0.2;
      if (isSpecial) {
        eligibleCards = validCards.filter((c) => isSpecialQuality(c) && (Number(c?.media) || 0) >= 80);
        if (eligibleCards.length === 0) {
          eligibleCards = validCards.filter((c) => isSpecialQuality(c));
        }
      }
      if (eligibleCards.length === 0) {
        eligibleCards = validCards.filter((c) => String(c?.calidad || '').toLowerCase() === 'oro' && (Number(c?.media) || 0) >= 80);
      }
      if (eligibleCards.length === 0) {
        eligibleCards = validCards.filter((c) => String(c?.calidad || '').toLowerCase() === 'oro');
      }

      customWeightFn = (m) => {
        if (m < 89) {
          return Math.pow(89 - m, 2) * 15;
        } else if (m === 89) {
          return 2;
        } else if (m === 90) {
          return 1;
        } else {
          return Math.max(0.1, 1 / (m - 89));
        }
      };
    } else if (id === 'item_013' || desc.includes('85-92') || desc.includes('leyenda')) {
      // 4. Chapa Leyenda: 85-92 de media, la ÚNICA totalmente aleatoria uniforme
      eligibleCards = validCards.filter((c) => {
        const media = Number(c?.media) || 0;
        return media >= 85 && media <= 92;
      });
      isUniformRandom = true;
    } else if (id === 'item_014' || desc.includes('90+') || desc.includes('deidad')) {
      // 5. Chapa Deidad: 90+ de media, prioridad a menos media
      eligibleCards = validCards.filter((c) => {
        const media = Number(c?.media) || 0;
        return media >= 90;
      });
      customWeightFn = (m) => {
        return Math.pow(Math.max(1, 100 - m), 2);
      };
    } else {
      eligibleCards = validCards;
    }

    const existingRunCharacters = new Set(
      [
        ...(Array.isArray(state.runDeckIds) ? state.runDeckIds : []),
        ...(Array.isArray(state.selectedInitialCardIds) ? state.selectedInitialCardIds : []),
        ...(Array.isArray(state.selectedInitialCards) ? state.selectedInitialCards.map((c) => c.id) : []),
        ...getUpgradeCandidateIds()
      ].map((cardId) => getBaseCardName(cardId)).filter(Boolean)
    );

    // Filtrar cartas de personajes que ya estén en la run (incluso en diferentes versiones/calidades)
    let nonDuplicateCards = eligibleCards.filter((c) => {
      const charKey = getBaseCardName(c.id, c);
      return !existingRunCharacters.has(charKey);
    });

    if (nonDuplicateCards.length > 0) {
      eligibleCards = nonDuplicateCards;
    } else {
      const remainingCatalog = validCards.filter((c) => {
        const charKey = getBaseCardName(c.id, c);
        return !existingRunCharacters.has(charKey);
      });
      if (remainingCatalog.length > 0) {
        eligibleCards = remainingCatalog;
      }
    }

    let pickedCard = null;
    if (isUniformRandom) {
      pickedCard = eligibleCards[Math.floor(Math.random() * eligibleCards.length)];
    } else {
      pickedCard = pickWeightedLowerMedia(eligibleCards, customWeightFn);
    }

    if (!pickedCard) {
      alert('No se pudo seleccionar una carta válida.');
      return { success: false };
    }

    if (!Array.isArray(state.runDeckIds)) state.runDeckIds = [];
    const baseId = extractBaseCardId(pickedCard.id);
    if (!state.runDeckIds.includes(baseId)) {
      state.runDeckIds.push(baseId);
    }
    if (!state.runTemporalCards || typeof state.runTemporalCards !== 'object') {
      state.runTemporalCards = {};
    }
    state.runTemporalCards[baseId] = pickedCard;
    state.catalogCardsById[baseId] = pickedCard;

    persistInfiniteRunState();
    renderTeamPreview();
    renderRunStatus();

    if (typeof playSFX === 'function') {
      try {
        playSFX('packSparkle', { volumeMultiplier: 1.0 });
      } catch {}
    }

    return new Promise((resolve) => {
      const modal = refs.chapaModal;
      const content = refs.chapaContent;
      const acceptBtn = refs.chapaAcceptBtn;

      if (!modal || !content) {
        alert(`¡Has obtenido la carta temporal: ${pickedCard.nombre || pickedCard.name}!\nSe ha añadido a tu equipo de la run actual.`);
        resolve({ success: true, card: pickedCard });
        return;
      }

      const cardName = pickedCard.nombre || pickedCard.name || pickedCard.id;
      const cardImg = pickedCard.imageUrl || pickedCard.image || pickedCard.imagen || './icon-oro.png';
      const cardQual = String(pickedCard.calidad || 'oro').toUpperCase();
      const cardMedia = Number(pickedCard.media) || 0;

      content.innerHTML = `
        <img src="${cardImg}" alt="${cardName}" class="infinite-chapa-card-img" onerror="this.src='./icon-oro.png';" />
        <div class="infinite-chapa-reward-name">${cardName}</div>
        <div class="infinite-chapa-reward-badge">${cardQual} · MEDIA: ${cardMedia}</div>
        <p class="infinite-chapa-reward-notice">✨ Esta carta se ha añadido temporalmente a tu equipo para la run del Modo Infinito.</p>
      `;

      modal.style.display = 'flex';

      const handleClose = () => {
        modal.style.display = 'none';
        if (acceptBtn) acceptBtn.onclick = null;
        resolve({ success: true, card: pickedCard });
      };

      if (acceptBtn) {
        acceptBtn.onclick = handleClose;
      }
    });
  }

  function isBastonItem(item) {
    if (!item || typeof item !== 'object') return false;
    const id = String(item.id || '').toLowerCase();
    const name = String(item.name || '').toLowerCase();
    const desc = String(item.description || '').toLowerCase();
    return id === 'item_015' || name.includes('bastón') || name.includes('baston') || (desc.includes('baston') && desc.includes('atsuigakure')) || (desc.includes('ninjutsu') && desc.includes('taijutsu') && desc.includes('atsuigakure'));
  }

  function applyBastonEffectToCard(cardId, card, item) {
    const cardName = String(card?.name || card?.nombre || cardId);
    const cardImg = String(card?.imageUrl || card?.image || card?.imagen || './icon-oro.png');
    const cardProc = String(card?.procedencia || card?.origen || card?.source || card?.aldea || '').trim();
    const isAtsui = cardProc.toLowerCase().includes('atsui') || cardProc.toLowerCase().includes('atsuigakure');

    const buffBonus = isAtsui ? 2 : 0;
    const nerfBonus = isAtsui ? 2 : 0;

    const ninjutsuDelta = 8 + buffBonus;
    const defensaDelta = 5 + buffBonus;
    const taijutsuDelta = -(6 + nerfBonus);

    if (!state.runCardBuffs[cardId] || typeof state.runCardBuffs[cardId] !== 'object') {
      state.runCardBuffs[cardId] = {};
    }

    const prevNin = Number(state.runCardBuffs[cardId].ninjutsu) || 0;
    const prevDef = Number(state.runCardBuffs[cardId].defensa) || 0;
    const prevTai = Number(state.runCardBuffs[cardId].taijutsu) || 0;

    state.runCardBuffs[cardId].ninjutsu = prevNin + ninjutsuDelta;
    state.runCardBuffs[cardId].defensa = prevDef + defensaDelta;
    state.runCardBuffs[cardId].taijutsu = prevTai + taijutsuDelta;

    persistInfiniteRunState();
    renderTeamPreview();
    renderRunStatus();

    return {
      success: true,
      affectedCards: [
        {
          cardId,
          card,
          cardName,
          cardImage: cardImg,
          procedencia: cardProc,
          changes: [
            {
              statKey: 'ninjutsu',
              statLabel: 'Ninjutsu',
              delta: ninjutsuDelta,
              percent: 0,
              isPositive: true,
              previousBuff: prevNin,
              newBuff: prevNin + ninjutsuDelta
            },
            {
              statKey: 'defensa',
              statLabel: 'Defensa',
              delta: defensaDelta,
              percent: 0,
              isPositive: true,
              previousBuff: prevDef,
              newBuff: prevDef + defensaDelta
            },
            {
              statKey: 'taijutsu',
              statLabel: 'Taijutsu',
              delta: taijutsuDelta,
              percent: 0,
              isPositive: false,
              previousBuff: prevTai,
              newBuff: prevTai + taijutsuDelta
            }
          ]
        }
      ]
    };
  }

  function handleBastonFlow(item) {
    return new Promise((resolve) => {
      const modal = refs.pergaminoModal;
      const titleEl = refs.pergaminoTitle;
      const subtitleEl = refs.pergaminoSubtitle;
      const stepCards = refs.pergaminoStepCards;
      const cardsGrid = refs.pergaminoCardsGrid;
      const stepStats = refs.pergaminoStepStats;
      const cancelBtn = refs.pergaminoCancelBtn;

      const candidateIds = getUpgradeCandidateIds();
      if (candidateIds.length === 0) {
        alert('No tienes cartas en tu equipo para aplicar este objeto.');
        resolve({ cancelled: true });
        return;
      }

      if (!modal || !cardsGrid) {
        const cardId = candidateIds[0];
        const card = resolveCardDataFromMeta({ cardId })?.card;
        const res = applyBastonEffectToCard(cardId, card, item);
        showBuffAnimation(item, res).then(resolve);
        return;
      }

      if (titleEl) titleEl.textContent = `🎋 ${item.name || 'BASTÓN DE ATSUIGAKURE'}`;
      if (subtitleEl) subtitleEl.textContent = 'Selecciona a qué carta de tu run deseas aplicar el poder del Bastón (+8 Ninjutsu, +5 Defensa, -6 Taijutsu. Las tropas de Atsuigakure reciben ±2 extra).';

      stepCards.style.display = 'block';
      if (stepStats) stepStats.style.display = 'none';
      cardsGrid.innerHTML = '';

      candidateIds.forEach((cardId) => {
        const resolved = resolveCardDataFromMeta({ cardId });
        const card = resolved?.card;
        const cardName = String(card?.name || card?.nombre || cardId);
        const cardImg = String(card?.imageUrl || card?.image || card?.imagen || './icon-oro.png');
        const cardProc = String(card?.procedencia || card?.origen || card?.source || card?.aldea || '').trim();
        const isAtsui = cardProc.toLowerCase().includes('atsui') || cardProc.toLowerCase().includes('atsuigakure');

        const cardBtn = document.createElement('button');
        cardBtn.type = 'button';
        cardBtn.className = 'infinite-pergamino-card-btn';
        cardBtn.innerHTML = `
          <img src="${cardImg}" alt="${cardName}" onerror="this.src='./icon-oro.png';" />
          <span>${cardName}</span>
          <span style="font-size:10px; color:${isAtsui ? '#facc15' : '#94a3b8'}; margin-top:2px; font-weight:700;">
            ${cardProc || 'GENERAL'}${isAtsui ? ' ✦' : ''}
          </span>
        `;

        cardBtn.addEventListener('click', async () => {
          modal.style.display = 'none';
          const result = applyBastonEffectToCard(cardId, card, item);
          await showBuffAnimation(item, result);
          resolve({ success: true });
        });

        cardsGrid.appendChild(cardBtn);
      });

      modal.style.display = 'flex';

      if (cancelBtn) {
        cancelBtn.onclick = () => {
          modal.style.display = 'none';
          resolve({ cancelled: true });
        };
      }
    });
  }

  function isEspadasItem(item) {
    if (!item || typeof item !== 'object') return false;
    const id = String(item.id || '').toLowerCase();
    const name = String(item.name || '').toLowerCase();
    const desc = String(item.description || '').toLowerCase();
    return id === 'item_003' || name.includes('espadach') || (name.includes('espada') && (name.includes('maldit') || desc.includes('espadach') || desc.includes('maldit')));
  }

  function handleEspadasFlow(item) {
    return new Promise((resolve) => {
      const modal = refs.pergaminoModal;
      const titleEl = refs.pergaminoTitle;
      const subtitleEl = refs.pergaminoSubtitle;
      const stepCards = refs.pergaminoStepCards;
      const cardsGrid = refs.pergaminoCardsGrid;
      const stepStats = refs.pergaminoStepStats;
      const cancelBtn = refs.pergaminoCancelBtn;

      const candidateIds = getUpgradeCandidateIds();
      if (candidateIds.length === 0) {
        alert('No tienes cartas en tu equipo para aplicar este objeto.');
        resolve({ cancelled: true });
        return;
      }

      if (!modal || !cardsGrid) {
        const cardId = candidateIds[0];
        const res = applyShopItemEffect(item, cardId);
        showBuffAnimation(item, res).then(resolve);
        return;
      }

      if (titleEl) titleEl.textContent = `⚔️ ${item.name || 'ESPADAS DEL ESPADACHÍN MALDITO'}`;
      if (subtitleEl) subtitleEl.textContent = 'Selecciona la carta de tu equipo que deseas mejorar con las Espadas del Espadachín Maldito:';

      stepCards.style.display = 'block';
      if (stepStats) stepStats.style.display = 'none';
      cardsGrid.innerHTML = '';

      candidateIds.forEach((cardId) => {
        const resolved = resolveCardDataFromMeta({ cardId });
        const card = resolved?.card;
        const cardName = String(card?.name || card?.nombre || cardId);
        const cardImg = String(card?.imageUrl || card?.image || card?.imagen || './icon-oro.png');
        const cardProc = String(card?.procedencia || card?.origen || card?.source || card?.aldea || '').trim();

        const cardBtn = document.createElement('button');
        cardBtn.type = 'button';
        cardBtn.className = 'infinite-pergamino-card-btn';
        cardBtn.innerHTML = `
          <img src="${cardImg}" alt="${cardName}" onerror="this.src='./icon-oro.png';" />
          <span>${cardName}</span>
          <span style="font-size:10px; color:#94a3b8; margin-top:2px; font-weight:700;">
            ${cardProc || 'GENERAL'}
          </span>
        `;

        cardBtn.addEventListener('click', async () => {
          modal.style.display = 'none';
          const result = applyShopItemEffect(item, cardId);
          await showBuffAnimation(item, result);
          resolve({ success: true });
        });

        cardsGrid.appendChild(cardBtn);
      });

      modal.style.display = 'flex';

      if (cancelBtn) {
        cancelBtn.onclick = () => {
          modal.style.display = 'none';
          resolve({ cancelled: true });
        };
      }
    });
  }

  function handleItem20Flow(item) {
    return new Promise((resolve) => {
      const modal = refs.pergaminoModal;
      const titleEl = refs.pergaminoTitle;
      const subtitleEl = refs.pergaminoSubtitle;
      const stepCards = refs.pergaminoStepCards;
      const cardsGrid = refs.pergaminoCardsGrid;
      const stepStats = refs.pergaminoStepStats;
      const cardPreview = refs.pergaminoCardPreview;
      const statsGrid = refs.pergaminoStatsGrid;
      const cancelBtn = refs.pergaminoCancelBtn;

      const candidateIds = getUpgradeCandidateIds();
      if (candidateIds.length === 0) {
        alert('No tienes cartas en tu equipo para aplicar este objeto.');
        resolve({ cancelled: true });
        return;
      }

      if (!modal || !cardsGrid || !statsGrid) {
        resolve({ cancelled: true });
        return;
      }

      function cleanup() {
        modal.style.display = 'none';
        if (cancelBtn) cancelBtn.onclick = null;
      }

      const itemName = item?.name || 'Objeto 20';
      if (titleEl) titleEl.textContent = itemName.toUpperCase();
      if (subtitleEl) subtitleEl.textContent = 'Selecciona la carta a la que deseas aumentar dos estadisticas (+1 cada una):';

      stepCards.style.display = 'block';
      if (stepStats) stepStats.style.display = 'none';
      cardsGrid.innerHTML = '';

      candidateIds.forEach((cardId) => {
        const resolved = resolveCardDataFromMeta({ cardId });
        const card = resolved?.card;
        const cardName = String(card?.name || card?.nombre || cardId);
        const cardImg = String(card?.imageUrl || card?.image || card?.imagen || './icon-oro.png');
        const cardProc = String(card?.procedencia || card?.origen || card?.source || card?.aldea || '').trim();

        const cardBtn = document.createElement('button');
        cardBtn.type = 'button';
        cardBtn.className = 'infinite-pergamino-card-btn';
        cardBtn.innerHTML = `
          <img src="${cardImg}" alt="${cardName}" onerror="this.src='./icon-oro.png';" />
          <span>${cardName}</span>
          <span style="font-size:10px; color:#94a3b8; margin-top:2px; font-weight:700;">
            ${cardProc || 'GENERAL'}
          </span>
        `;

        cardBtn.addEventListener('click', () => {
          stepCards.style.display = 'none';
          stepStats.style.display = 'block';

          if (cardPreview) {
            cardPreview.innerHTML = `
              <img src="${cardImg}" alt="${cardName}" onerror="this.src='./icon-oro.png';" />
              <div class="infinite-pergamino-card-preview-info">
                <div class="infinite-pergamino-card-preview-name">${cardName}</div>
                <div style="font-size:11px; color:#94a3b8; text-transform:uppercase;">${cardProc || 'GENERAL'}</div>
              </div>
            `;
          }

          let firstStatKey = null;
          let firstStatLabel = '';

          function renderStatsStep(stepNum) {
            if (stepNum === 1) {
              if (subtitleEl) subtitleEl.textContent = `Carta: ${cardName}. Selecciona la primera estadistica a aumentar (+1 pt):`;
            } else {
              if (subtitleEl) subtitleEl.textContent = `Carta: ${cardName}. Primera elegida: ${firstStatLabel}. Selecciona la segunda estadistica (distinta) a aumentar (+1 pt):`;
            }

            statsGrid.innerHTML = '';

            const availableStats = stepNum === 2
              ? INFINITE_STAT_DEFS.filter((s) => s.key !== firstStatKey)
              : INFINITE_STAT_DEFS;

            availableStats.forEach((statDef) => {
              const currentBase = Math.max(1, getCardBaseStatValue(card, statDef) || Number(card?.media) || 75);
              const currentBuff = Number(state.runCardBuffs?.[cardId]?.[statDef.key]) || 0;
              const currentTotal = currentBase + currentBuff;
              const nextTotal = currentTotal + 1;

              const btn = document.createElement('button');
              btn.type = 'button';
              btn.className = 'infinite-pergamino-stat-btn';
              btn.innerHTML = `
                <span class="infinite-pergamino-stat-name">${statDef.label}</span>
                <span class="infinite-pergamino-stat-badge">+1 (${currentTotal} → ${nextTotal})</span>
              `;

              btn.addEventListener('click', async () => {
                if (stepNum === 1) {
                  firstStatKey = statDef.key;
                  firstStatLabel = statDef.label;
                  renderStatsStep(2);
                } else {
                  const secondStatKey = statDef.key;
                  const secondStatLabel = statDef.label;

                  if (!state.runCardBuffs[cardId] || typeof state.runCardBuffs[cardId] !== 'object') {
                    state.runCardBuffs[cardId] = {};
                  }

                  const prevBuff1 = Number(state.runCardBuffs[cardId][firstStatKey]) || 0;
                  state.runCardBuffs[cardId][firstStatKey] = prevBuff1 + 1;

                  const prevBuff2 = Number(state.runCardBuffs[cardId][secondStatKey]) || 0;
                  state.runCardBuffs[cardId][secondStatKey] = prevBuff2 + 1;

                  persistInfiniteRunState();
                  renderTeamPreview();
                  renderRunStatus();

                  cleanup();

                  const changes = [];
                  if (firstStatKey === secondStatKey) {
                    changes.push({
                      statKey: firstStatKey,
                      statLabel: firstStatLabel,
                      delta: 2,
                      percent: 0,
                      isPositive: true,
                      previousBuff: prevBuff1,
                      newBuff: prevBuff1 + 2
                    });
                  } else {
                    changes.push({
                      statKey: firstStatKey,
                      statLabel: firstStatLabel,
                      delta: 1,
                      percent: 0,
                      isPositive: true,
                      previousBuff: prevBuff1,
                      newBuff: prevBuff1 + 1
                    });
                    changes.push({
                      statKey: secondStatKey,
                      statLabel: secondStatLabel,
                      delta: 1,
                      percent: 0,
                      isPositive: true,
                      previousBuff: prevBuff2,
                      newBuff: prevBuff2 + 1
                    });
                  }

                  const result = {
                    success: true,
                    affectedCards: [
                      {
                        cardId,
                        card,
                        cardName,
                        cardImage: cardImg,
                        procedencia: cardProc,
                        changes
                      }
                    ]
                  };

                  await showBuffAnimation(item, result);
                  resolve({ success: true });
                }
              });

              statsGrid.appendChild(btn);
            });
          }

          renderStatsStep(1);
        });

        cardsGrid.appendChild(cardBtn);
      });

      modal.style.display = 'flex';

      if (cancelBtn) {
        cancelBtn.onclick = () => {
          cleanup();
          resolve({ cancelled: true });
        };
      }
    });
  }

  function handleItem21Flow(item) {
    return new Promise((resolve) => {
      const modal = refs.pergaminoModal;
      const titleEl = refs.pergaminoTitle;
      const subtitleEl = refs.pergaminoSubtitle;
      const stepCards = refs.pergaminoStepCards;
      const stepStats = refs.pergaminoStepStats;
      const cardPreview = refs.pergaminoCardPreview;
      const statsGrid = refs.pergaminoStatsGrid;
      const cancelBtn = refs.pergaminoCancelBtn;

      const candidateIds = getUpgradeCandidateIds();
      if (candidateIds.length === 0) {
        alert('No tienes cartas en tu equipo para aplicar este objeto.');
        resolve({ cancelled: true });
        return;
      }

      if (!modal || !statsGrid) {
        resolve({ cancelled: true });
        return;
      }

      function cleanup() {
        modal.style.display = 'none';
        if (cancelBtn) cancelBtn.onclick = null;
      }

      // 1. Pick card randomly
      const chosenCardId = candidateIds[Math.floor(Math.random() * candidateIds.length)];
      const resolved = resolveCardDataFromMeta({ cardId: chosenCardId });
      const card = resolved?.card;
      const cardName = String(card?.name || card?.nombre || chosenCardId);
      const cardImg = String(card?.imageUrl || card?.image || card?.imagen || './icon-oro.png');
      const cardProc = String(card?.procedencia || card?.origen || card?.source || card?.aldea || '').trim();

      const itemName = item?.name || 'Objeto 21';
      if (titleEl) titleEl.textContent = itemName.toUpperCase();

      stepCards.style.display = 'none';
      stepStats.style.display = 'block';

      if (cardPreview) {
        cardPreview.innerHTML = `
          <img src="${cardImg}" alt="${cardName}" onerror="this.src='./icon-oro.png';" />
          <div class="infinite-pergamino-card-preview-info">
            <div class="infinite-pergamino-card-preview-name">${cardName}</div>
            <div style="font-size:11px; color:#94a3b8; text-transform:uppercase;">${cardProc || 'GENERAL'} · CARTA ALEATORIA</div>
          </div>
        `;
      }

      let firstStatKey = null;
      let firstStatLabel = '';

      function renderStatsStep(stepNum) {
        if (stepNum === 1) {
          if (subtitleEl) subtitleEl.textContent = `Carta elegida al azar: ${cardName}. Selecciona la primera estadistica a aumentar (+1 pt):`;
        } else {
          if (subtitleEl) subtitleEl.textContent = `Carta: ${cardName}. Primera elegida: ${firstStatLabel}. Selecciona la segunda estadistica (distinta) a aumentar (+1 pt):`;
        }

        statsGrid.innerHTML = '';

        const availableStats = stepNum === 2
          ? INFINITE_STAT_DEFS.filter((s) => s.key !== firstStatKey)
          : INFINITE_STAT_DEFS;

        availableStats.forEach((statDef) => {
          const currentBase = Math.max(1, getCardBaseStatValue(card, statDef) || Number(card?.media) || 75);
          const currentBuff = Number(state.runCardBuffs?.[chosenCardId]?.[statDef.key]) || 0;
          const currentTotal = currentBase + currentBuff;
          const nextTotal = currentTotal + 1;

          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'infinite-pergamino-stat-btn';
          btn.innerHTML = `
            <span class="infinite-pergamino-stat-name">${statDef.label}</span>
            <span class="infinite-pergamino-stat-badge">+1 (${currentTotal} → ${nextTotal})</span>
          `;

          btn.addEventListener('click', async () => {
            if (stepNum === 1) {
              firstStatKey = statDef.key;
              firstStatLabel = statDef.label;
              renderStatsStep(2);
            } else {
              const secondStatKey = statDef.key;
              const secondStatLabel = statDef.label;

              if (!state.runCardBuffs[chosenCardId] || typeof state.runCardBuffs[chosenCardId] !== 'object') {
                state.runCardBuffs[chosenCardId] = {};
              }

              const prevBuff1 = Number(state.runCardBuffs[chosenCardId][firstStatKey]) || 0;
              state.runCardBuffs[chosenCardId][firstStatKey] = prevBuff1 + 1;

              const prevBuff2 = Number(state.runCardBuffs[chosenCardId][secondStatKey]) || 0;
              state.runCardBuffs[chosenCardId][secondStatKey] = prevBuff2 + 1;

              persistInfiniteRunState();
              renderTeamPreview();
              renderRunStatus();

              cleanup();

              const changes = [];
              if (firstStatKey === secondStatKey) {
                changes.push({
                  statKey: firstStatKey,
                  statLabel: firstStatLabel,
                  delta: 2,
                  percent: 0,
                  isPositive: true,
                  previousBuff: prevBuff1,
                  newBuff: prevBuff1 + 2
                });
              } else {
                changes.push({
                  statKey: firstStatKey,
                  statLabel: firstStatLabel,
                  delta: 1,
                  percent: 0,
                  isPositive: true,
                  previousBuff: prevBuff1,
                  newBuff: prevBuff1 + 1
                });
                changes.push({
                  statKey: secondStatKey,
                  statLabel: secondStatLabel,
                  delta: 1,
                  percent: 0,
                  isPositive: true,
                  previousBuff: prevBuff2,
                  newBuff: prevBuff2 + 1
                });
              }

              const result = {
                success: true,
                affectedCards: [
                  {
                    cardId: chosenCardId,
                    card,
                    cardName,
                    cardImage: cardImg,
                    procedencia: cardProc,
                    changes
                  }
                ]
              };

              await showBuffAnimation(item, result);
              resolve({ success: true });
            }
          });

          statsGrid.appendChild(btn);
        });
      }

      renderStatsStep(1);

      modal.style.display = 'flex';

      if (cancelBtn) {
        cancelBtn.onclick = () => {
          cleanup();
          resolve({ cancelled: true });
        };
      }
    });
  }

  function handleItem22Flow(item) {
    return new Promise((resolve) => {
      const modal = refs.pergaminoModal;
      const titleEl = refs.pergaminoTitle;
      const subtitleEl = refs.pergaminoSubtitle;
      const stepCards = refs.pergaminoStepCards;
      const cardsGrid = refs.pergaminoCardsGrid;
      const stepStats = refs.pergaminoStepStats;
      const cancelBtn = refs.pergaminoCancelBtn;

      const candidateIds = getUpgradeCandidateIds();
      if (candidateIds.length === 0) {
        alert('No tienes cartas en tu equipo para aplicar este objeto.');
        resolve({ cancelled: true });
        return;
      }

      if (!modal || !cardsGrid) {
        resolve({ cancelled: true });
        return;
      }

      function cleanup() {
        modal.style.display = 'none';
        if (cancelBtn) cancelBtn.onclick = null;
      }

      const itemName = item?.name || 'Objeto 22';
      if (titleEl) titleEl.textContent = itemName.toUpperCase();
      if (subtitleEl) subtitleEl.textContent = 'Selecciona una carta de tu equipo (+2 a 3 estadisticas aleatorias independientes):';

      stepCards.style.display = 'block';
      if (stepStats) stepStats.style.display = 'none';
      cardsGrid.innerHTML = '';

      candidateIds.forEach((cardId) => {
        const resolved = resolveCardDataFromMeta({ cardId });
        const card = resolved?.card;
        const cardName = String(card?.name || card?.nombre || cardId);
        const cardImg = String(card?.imageUrl || card?.image || card?.imagen || './icon-oro.png');
        const cardProc = String(card?.procedencia || card?.origen || card?.source || card?.aldea || '').trim();

        const cardBtn = document.createElement('button');
        cardBtn.type = 'button';
        cardBtn.className = 'infinite-pergamino-card-btn';
        cardBtn.innerHTML = `
          <img src="${cardImg}" alt="${cardName}" onerror="this.src='./icon-oro.png';" />
          <span>${cardName}</span>
          <span style="font-size:10px; color:#94a3b8; margin-top:2px; font-weight:700;">
            ${cardProc || 'GENERAL'}
          </span>
        `;

        cardBtn.addEventListener('click', async () => {
          cleanup();

          const statKeys = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
          const rolls = {};
          for (let i = 0; i < 3; i++) {
            const pickedKey = statKeys[Math.floor(Math.random() * statKeys.length)];
            rolls[pickedKey] = (rolls[pickedKey] || 0) + 2;
          }

          if (!state.runCardBuffs[cardId] || typeof state.runCardBuffs[cardId] !== 'object') {
            state.runCardBuffs[cardId] = {};
          }

          const changes = [];
          Object.keys(rolls).forEach((statKey) => {
            const statDef = findStatDefByKey(statKey);
            const delta = rolls[statKey];
            const prevBuff = Number(state.runCardBuffs[cardId][statKey]) || 0;
            const newBuff = prevBuff + delta;
            state.runCardBuffs[cardId][statKey] = newBuff;

            changes.push({
              statKey,
              statLabel: statDef?.label || statKey,
              delta,
              percent: 0,
              isPositive: true,
              previousBuff: prevBuff,
              newBuff
            });
          });

          persistInfiniteRunState();
          renderTeamPreview();
          renderRunStatus();

          const result = {
            success: true,
            affectedCards: [
              {
                cardId,
                card,
                cardName,
                cardImage: cardImg,
                procedencia: cardProc,
                changes
              }
            ]
          };

          await showBuffAnimation(item, result);
          resolve({ success: true });
        });

        cardsGrid.appendChild(cardBtn);
      });

      modal.style.display = 'flex';

      if (cancelBtn) {
        cancelBtn.onclick = () => {
          cleanup();
          resolve({ cancelled: true });
        };
      }
    });
  }

  function handleItem23Flow(item) {
    return new Promise((resolve) => {
      const modal = refs.pergaminoModal;
      const titleEl = refs.pergaminoTitle;
      const subtitleEl = refs.pergaminoSubtitle;
      const stepCards = refs.pergaminoStepCards;
      const cardsGrid = refs.pergaminoCardsGrid;
      const stepStats = refs.pergaminoStepStats;
      const cancelBtn = refs.pergaminoCancelBtn;

      const candidateIds = getUpgradeCandidateIds();
      if (candidateIds.length === 0) {
        alert('No tienes cartas en tu equipo para aplicar este objeto.');
        resolve({ cancelled: true });
        return;
      }

      if (!modal || !cardsGrid) {
        resolve({ cancelled: true });
        return;
      }

      function cleanup() {
        modal.style.display = 'none';
        if (cancelBtn) cancelBtn.onclick = null;
      }

      const itemName = item?.name || 'Objeto 23';
      if (titleEl) titleEl.textContent = itemName.toUpperCase();
      if (subtitleEl) subtitleEl.textContent = 'Selecciona una carta de tu equipo (+3 Defensa y +3 Resistencia. Si procede de Sunagakure: +5 a ambas):';

      stepCards.style.display = 'block';
      if (stepStats) stepStats.style.display = 'none';
      cardsGrid.innerHTML = '';

      candidateIds.forEach((cardId) => {
        const resolved = resolveCardDataFromMeta({ cardId });
        const card = resolved?.card;
        const cardName = String(card?.name || card?.nombre || cardId);
        const cardImg = String(card?.imageUrl || card?.image || card?.imagen || './icon-oro.png');
        const cardProc = String(card?.procedencia || card?.origen || card?.source || card?.aldea || '').trim();

        const cardBtn = document.createElement('button');
        cardBtn.type = 'button';
        cardBtn.className = 'infinite-pergamino-card-btn';
        cardBtn.innerHTML = `
          <img src="${cardImg}" alt="${cardName}" onerror="this.src='./icon-oro.png';" />
          <span>${cardName}</span>
          <span style="font-size:10px; color:#94a3b8; margin-top:2px; font-weight:700;">
            ${cardProc || 'GENERAL'}
          </span>
        `;

        cardBtn.addEventListener('click', async () => {
          cleanup();

          const idStr = (String(cardId || '') + ' ' + String(card?.id || '')).toLowerCase();
          const isKuraiTenro = idStr.includes('kurai_tenro') || idStr.includes('kurai-tenro');
          const procLower = cardProc.toLowerCase();
          const isSuna = procLower.includes('sunagakure') || procLower.includes('suna');

          let boost = 3;
          if (isKuraiTenro) {
            boost = 7;
          } else if (isSuna) {
            boost = 5;
          }

          if (!state.runCardBuffs[cardId] || typeof state.runCardBuffs[cardId] !== 'object') {
            state.runCardBuffs[cardId] = {};
          }

          const prevDef = Number(state.runCardBuffs[cardId].defensa) || 0;
          const prevRes = Number(state.runCardBuffs[cardId].resistencia) || 0;

          state.runCardBuffs[cardId].defensa = prevDef + boost;
          state.runCardBuffs[cardId].resistencia = prevRes + boost;

          persistInfiniteRunState();
          renderTeamPreview();
          renderRunStatus();

          const result = {
            success: true,
            affectedCards: [
              {
                cardId,
                card,
                cardName,
                cardImage: cardImg,
                procedencia: cardProc,
                changes: [
                  {
                    statKey: 'defensa',
                    statLabel: 'Defensa',
                    delta: boost,
                    percent: 0,
                    isPositive: true,
                    previousBuff: prevDef,
                    newBuff: prevDef + boost
                  },
                  {
                    statKey: 'resistencia',
                    statLabel: 'Resistencia',
                    delta: boost,
                    percent: 0,
                    isPositive: true,
                    previousBuff: prevRes,
                    newBuff: prevRes + boost
                  }
                ]
              }
            ]
          };

          await showBuffAnimation(item, result);
          resolve({ success: true });
        });

        cardsGrid.appendChild(cardBtn);
      });

      modal.style.display = 'flex';

      if (cancelBtn) {
        cancelBtn.onclick = () => {
          cleanup();
          resolve({ cancelled: true });
        };
      }
    });
  }

  function handleItem24Flow(item) {
    return new Promise((resolve) => {
      const candidateIds = getUpgradeCandidateIds();
      if (candidateIds.length === 0) {
        alert('No tienes cartas en tu equipo para aplicar este objeto.');
        resolve({ cancelled: true });
        return;
      }

      const affectedCards = [];
      const statDefs = [...INFINITE_STAT_DEFS];

      candidateIds.forEach((cardId) => {
        const resolved = resolveCardDataFromMeta({ cardId });
        const card = resolved?.card;
        if (!card) return;

        const cardName = String(card?.name || card?.nombre || cardId);
        const cardImg = String(card?.imageUrl || card?.image || card?.imagen || './icon-oro.png');
        const cardProc = String(card?.procedencia || card?.origen || card?.source || card?.aldea || '').trim();
        const procLower = cardProc.toLowerCase();

        const isKizoku = procLower.includes('kizoku');
        const isJinushi = procLower.includes('jinushi');

        if (!isKizoku && !isJinushi) return;

        const delta = isKizoku ? 2 : -1;

        if (!state.runCardBuffs[cardId] || typeof state.runCardBuffs[cardId] !== 'object') {
          state.runCardBuffs[cardId] = {};
        }

        const changes = [];
        statDefs.forEach((statDef) => {
          const prevBuff = Number(state.runCardBuffs[cardId][statDef.key]) || 0;
          const newBuff = prevBuff + delta;
          state.runCardBuffs[cardId][statDef.key] = newBuff;

          changes.push({
            statKey: statDef.key,
            statLabel: statDef.label,
            delta,
            percent: 0,
            isPositive: delta > 0,
            previousBuff: prevBuff,
            newBuff
          });
        });

        affectedCards.push({
          cardId,
          card,
          cardName,
          cardImage: cardImg,
          procedencia: cardProc,
          changes
        });
      });

      persistInfiniteRunState();
      renderTeamPreview();
      renderRunStatus();

      const result = {
        success: true,
        affectedCards
      };

      if (affectedCards.length === 0) {
        alert('Ninguna carta de tu equipo pertenece a Kizoku (+2) ni a Jinushi (-1). No se han producido cambios en las estadisticas.');
        resolve({ success: true });
        return;
      }

      showBuffAnimation(item, result).then(() => {
        resolve({ success: true });
      });
    });
  }

  function handleItem25Flow(item) {
    return new Promise((resolve) => {
      const modal = refs.pergaminoModal;
      const titleEl = refs.pergaminoTitle;
      const subtitleEl = refs.pergaminoSubtitle;
      const stepCards = refs.pergaminoStepCards;
      const cardsGrid = refs.pergaminoCardsGrid;
      const stepStats = refs.pergaminoStepStats;
      const cardPreview = refs.pergaminoCardPreview;
      const statsGrid = refs.pergaminoStatsGrid;
      const cancelBtn = refs.pergaminoCancelBtn;

      const candidateIds = getUpgradeCandidateIds();
      if (candidateIds.length === 0) {
        alert('No tienes cartas en tu equipo para aplicar este objeto.');
        resolve({ cancelled: true });
        return;
      }

      if (!modal || !cardsGrid || !statsGrid) {
        resolve({ cancelled: true });
        return;
      }

      function cleanup() {
        modal.style.display = 'none';
        if (cancelBtn) cancelBtn.onclick = null;
      }

      const itemName = item?.name || 'Objeto 25';
      if (titleEl) titleEl.textContent = itemName.toUpperCase();
      if (subtitleEl) subtitleEl.textContent = 'Selecciona una carta de tu equipo (+1 a la estadistica elegida, 50% de +2 si es de Hispania o Hispalis):';

      stepCards.style.display = 'block';
      if (stepStats) stepStats.style.display = 'none';
      cardsGrid.innerHTML = '';

      candidateIds.forEach((cardId) => {
        const resolved = resolveCardDataFromMeta({ cardId });
        const card = resolved?.card;
        const cardName = String(card?.name || card?.nombre || cardId);
        const cardImg = String(card?.imageUrl || card?.image || card?.imagen || './icon-oro.png');
        const cardProc = String(card?.procedencia || card?.origen || card?.source || card?.aldea || '').trim();

        const cardBtn = document.createElement('button');
        cardBtn.type = 'button';
        cardBtn.className = 'infinite-pergamino-card-btn';
        cardBtn.innerHTML = `
          <img src="${cardImg}" alt="${cardName}" onerror="this.src='./icon-oro.png';" />
          <span>${cardName}</span>
          <span style="font-size:10px; color:#94a3b8; margin-top:2px; font-weight:700;">
            ${cardProc || 'GENERAL'}
          </span>
        `;

        cardBtn.addEventListener('click', () => {
          stepCards.style.display = 'none';
          stepStats.style.display = 'block';

          if (cardPreview) {
            cardPreview.innerHTML = `
              <img src="${cardImg}" alt="${cardName}" onerror="this.src='./icon-oro.png';" />
              <div class="infinite-pergamino-card-preview-info">
                <div class="infinite-pergamino-card-preview-name">${cardName}</div>
                <div style="font-size:11px; color:#94a3b8; text-transform:uppercase;">${cardProc || 'GENERAL'}</div>
              </div>
            `;
          }

          if (subtitleEl) subtitleEl.textContent = `Carta: ${cardName}. Selecciona la estadistica que deseas aumentar:`;

          statsGrid.innerHTML = '';

          INFINITE_STAT_DEFS.forEach((statDef) => {
            const currentBase = Math.max(1, getCardBaseStatValue(card, statDef) || Number(card?.media) || 75);
            const currentBuff = Number(state.runCardBuffs?.[cardId]?.[statDef.key]) || 0;
            const currentTotal = currentBase + currentBuff;

            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'infinite-pergamino-stat-btn';
            btn.innerHTML = `
              <span class="infinite-pergamino-stat-name">${statDef.label}</span>
              <span class="infinite-pergamino-stat-badge">Aumentar (${currentTotal})</span>
            `;

            btn.addEventListener('click', async () => {
              cleanup();

              const idStr = (String(cardId || '') + ' ' + String(card?.id || '')).toLowerCase();
              const isRonanHatake = idStr.includes('ronan_hatake') || idStr.includes('ronan-hatake');
              const procLower = cardProc.toLowerCase();
              const isHispania = procLower.includes('hispania') || procLower.includes('hispalis');

              let points = 1;
              if (isRonanHatake) {
                points = 2;
              } else if (isHispania) {
                points = Math.random() < 0.5 ? 2 : 1;
              } else {
                points = 1;
              }

              if (!state.runCardBuffs[cardId] || typeof state.runCardBuffs[cardId] !== 'object') {
                state.runCardBuffs[cardId] = {};
              }

              const prevBuff = Number(state.runCardBuffs[cardId][statDef.key]) || 0;
              state.runCardBuffs[cardId][statDef.key] = prevBuff + points;

              persistInfiniteRunState();
              renderTeamPreview();
              renderRunStatus();

              const result = {
                success: true,
                affectedCards: [
                  {
                    cardId,
                    card,
                    cardName,
                    cardImage: cardImg,
                    procedencia: cardProc,
                    changes: [
                      {
                        statKey: statDef.key,
                        statLabel: statDef.label,
                        delta: points,
                        percent: 0,
                        isPositive: true,
                        previousBuff: prevBuff,
                        newBuff: prevBuff + points
                      }
                    ]
                  }
                ]
              };

              await showBuffAnimation(item, result);
              resolve({ success: true });
            });

            statsGrid.appendChild(btn);
          });
        });

        cardsGrid.appendChild(cardBtn);
      });

      modal.style.display = 'flex';

      if (cancelBtn) {
        cancelBtn.onclick = () => {
          cleanup();
          resolve({ cancelled: true });
        };
      }
    });
  }

  async function executeInfiniteItem(item) {
    if (!item || typeof item !== 'object') return { cancelled: true };

    if (isItemMatch(item, 20)) {
      return await handleItem20Flow(item);
    } else if (isItemMatch(item, 21)) {
      return await handleItem21Flow(item);
    } else if (isItemMatch(item, 22)) {
      return await handleItem22Flow(item);
    } else if (isItemMatch(item, 23)) {
      return await handleItem23Flow(item);
    } else if (isItemMatch(item, 24)) {
      return await handleItem24Flow(item);
    } else if (isItemMatch(item, 25)) {
      return await handleItem25Flow(item);
    } else if (isBastonItem(item)) {
      return await handleBastonFlow(item);
    } else if (isEspadasItem(item)) {
      return await handleEspadasFlow(item);
    } else if (isPergaminoItem(item)) {
      return await handlePergaminoChoiceFlow(item);
    } else if (isChapaItem(item)) {
      if (getRunDeckBaseIds().length >= MAX_RUN_DECK_CARDS) {
        alert(`Ya tienes el maximo de cartas en tu run (${MAX_RUN_DECK_CARDS} cartas).`);
        return { cancelled: true };
      }
      const chapaRes = await handleChapaActivationFlow(item);
      if (chapaRes && chapaRes.success === false) {
        return { cancelled: true };
      }
      return { success: true };
    } else {
      const result = applyShopItemEffect(item);
      await showBuffAnimation(item, result);
      return { success: true };
    }
  }

  async function activateConsumableItem(index) {
    if (!Array.isArray(state.consumableItems) || index < 0 || index >= state.consumableItems.length) return;
    const item = state.consumableItems[index];
    if (!item) return;

    if (typeof playSFX === 'function') {
      try {
        playSFX('powerActivate', { volumeMultiplier: 0.9 });
      } catch {}
    }

    const res = await executeInfiniteItem(item);
    if (res && res.cancelled) {
      return;
    }

    state.consumableItems.splice(index, 1);
    persistInfiniteRunState();
    renderInfiniteConsumables();
  }

  async function confirmPurchaseItem(item) {
    if (!item || typeof item !== 'object') return;

    if (isChapaItem(item) && getRunDeckBaseIds().length >= MAX_RUN_DECK_CARDS) {
      alert(`Ya tienes el maximo de cartas en tu run (${MAX_RUN_DECK_CARDS} cartas).`);
      return;
    }

    const itemId = String(item?.id || '').trim();
    const stock = state.shopItemStock[itemId];
    if (!stock || stock.remaining <= 0) {
      alert('Este objeto esta agotado.');
      closeShopItemPreview();
      renderShopItems();
      return;
    }

    const priceInfo = parseShopPrice(item);
    const amount = Math.max(0, Number(priceInfo.amount) || 0);
    const currency = normalizeShopCurrency(priceInfo.currency);
    const balance = Math.max(0, Number(state.shopCurrencies[currency]) || 0);
    if (balance < amount) {
      alert(`No tienes suficiente ${currency}. Necesitas ${amount} y tienes ${balance}.`);
      return;
    }

    const confirmed = confirm(
      `Comprar ${item.name} por ${amount} ${currency}?\n\n` +
      'Aviso: al comprar un objeto, cuando cierres la tienda se consumira este nodo de decision.'
    );
    if (!confirmed) return;

    state.shopCurrencies[currency] = Math.max(0, balance - amount);
    state.shopDecisionWillBeConsumed = true;
    persistInfiniteCurrencies();
    renderShopCurrencyBar();

    stock.remaining = Math.max(0, Number(stock.remaining) - 1);
    closeShopItemPreview();
    renderShopItems();

    const isConsumable = String(item?.type || '').toLowerCase() === 'consumable';

    if (isConsumable) {
      state.consumableItems.push({ ...item });
      persistInfiniteRunState();
      renderInfiniteConsumables();
      alert(`Has comprado: ${item.name}.\n\nSe ha guardado en tu barra de consumibles a la derecha de los botones principales. Haz click sobre el en cualquier momento para activarlo.`);
    } else {
      const res = await executeInfiniteItem(item);
      if (res && res.cancelled) {
        state.consumableItems.push({ ...item });
        persistInfiniteRunState();
        renderInfiniteConsumables();
        alert(`Has adquirido: ${item.name}.\nSe ha guardado en tus consumibles para que puedas aplicarlo cuando quieras.`);
      }
    }
  }

  function shouldConsumeDecisionOnShopClose() {
    return !!state.shopDecisionWillBeConsumed;
  }

  function askConfirmConsumeDecisionOnShopClose() {
    return confirm('Si cierras la tienda se consumirá el nodo de decisión, ¿estás seguro de que no vas a comprar nada más?');
  }

  function closeShopFlowToDecisionOptions() {
    if (refs.shopFlow) refs.shopFlow.style.display = 'none';
    if (refs.shopItemsGrid) refs.shopItemsGrid.innerHTML = '';
    closeShopItemPreview();
    if (refs.decisionMainOptions) refs.decisionMainOptions.style.display = 'grid';
  }

  function closeShopFlowAndConsumeDecisionNode() {
    state.shopDecisionWillBeConsumed = false;
    state.shopRestocking = true;
    persistInfiniteRunState();
    if (refs.shopFlow) refs.shopFlow.style.display = 'none';
    if (refs.shopItemsGrid) refs.shopItemsGrid.innerHTML = '';
    closeShopItemPreview();
    closeDecisionModal();
    advanceFloorAfterClear();
  }

  function normalizeRiskEventsConfig(raw) {
    const fallback = FALLBACK_RISK_EVENTS_CONFIG;
    const source = raw && typeof raw === 'object' ? raw : fallback;
    const events = Array.isArray(source.events) ? source.events : [];

    const normalizedEvents = events
      .map((event, eventIndex) => {
        const eventId = String(event?.id || `risk-event-${eventIndex + 1}`).trim();
        const nodes = Array.isArray(event?.nodes)
          ? event.nodes
              .map((node, nodeIndex) => {
                const nodeId = String(node?.id || `node-${nodeIndex + 1}`).trim();
                if (!nodeId) return null;
                return {
                  id: nodeId,
                  title: String(node?.title || event?.title || 'Evento de riesgo'),
                  text: String(node?.text || ''),
                  choices: Array.isArray(node?.choices) ? node.choices : []
                };
              })
              .filter(Boolean)
          : [];

        if (!eventId || nodes.length === 0) return null;

        return {
          id: eventId,
          title: String(event?.title || 'Evento de riesgo'),
          worldIds: (() => {
            const fromArray = Array.isArray(event?.worldIds)
              ? event.worldIds
              : (Array.isArray(event?.worlds) ? event.worlds : null);
            if (fromArray) {
              return fromArray
                .map((worldId) => String(worldId || '').trim())
                .filter(Boolean);
            }

            const single = String(event?.worldId || event?.world || '').trim();
            return single ? [single] : [];
          })(),
          minFloor: Math.max(1, Number(event?.minFloor || 1) || 1),
          maxFloor: Math.max(1, Number(event?.maxFloor || 9999) || 9999),
          startNodeId: String(event?.startNodeId || nodes[0].id),
          nodes
        };
      })
      .filter(Boolean);

    return {
      version: Number(source.version || fallback.version || 1),
      events: normalizedEvents.length > 0 ? normalizedEvents : fallback.events
    };
  }

  async function loadRiskEventsConfig() {
    if (state.riskConfig) return state.riskConfig;

    state.riskConfig = normalizeRiskEventsConfig(FALLBACK_RISK_EVENTS_CONFIG);

    try {
      const response = await fetch(withCacheBuster(INFINITE_RISK_EVENTS_REMOTE_URL));
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json();
      state.riskConfig = normalizeRiskEventsConfig(data);
      console.log('[INFINITE] Configuración remota de riesgo cargada:', {
        version: state.riskConfig.version,
        events: state.riskConfig.events.length
      });
    } catch (error) {
      console.warn('[INFINITE] No se pudo cargar configuración remota de riesgo, usando fallback:', error?.message || error);
    }

    return state.riskConfig;
  }

  function ensureRiskEventModal() {
    if (refs.riskModal) return;

    const modal = document.createElement('div');
    modal.id = 'infinite-risk-modal';
    modal.className = 'infinite-risk-modal';
    modal.style.display = 'none';
    modal.innerHTML = `
      <div class="infinite-risk-modal-backdrop"></div>
      <div class="infinite-risk-modal-card" role="dialog" aria-modal="true" aria-label="Evento de riesgo">
        <div id="infinite-risk-title" class="infinite-risk-title">Evento de riesgo</div>
        <div id="infinite-risk-text" class="infinite-risk-text"></div>
        <div id="infinite-risk-outcome" class="infinite-risk-outcome" style="display:none;"></div>
        <div id="infinite-risk-choices" class="infinite-risk-choices"></div>
        <div class="infinite-risk-actions">
          <button id="infinite-risk-continue" class="infinite-confirm-pick-btn" style="display:none;">Continuar</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);
    refs.riskModal = modal;
    refs.riskTitle = modal.querySelector('#infinite-risk-title');
    refs.riskText = modal.querySelector('#infinite-risk-text');
    refs.riskOutcome = modal.querySelector('#infinite-risk-outcome');
    refs.riskChoices = modal.querySelector('#infinite-risk-choices');
    refs.riskContinueBtn = modal.querySelector('#infinite-risk-continue');
  }

  function parseSuccessChance(rawChance) {
    const raw = Number(rawChance);
    if (!Number.isFinite(raw)) return null;
    if (raw > 1) return Math.max(0, Math.min(1, raw / 100));
    return Math.max(0, Math.min(1, raw));
  }

  function normalizeOutcomeStatus(rawStatus) {
    const safe = String(rawStatus || '').trim().toLowerCase();
    if (!safe) return 'neutral';
    if (['success', 'win', 'positive', 'good', 'continue', 'advanced', 'pass'].includes(safe)) return 'success';
    if (['failure', 'fail', 'lose', 'negative', 'bad', 'dead', 'loss'].includes(safe)) return 'failure';
    return 'neutral';
  }

  function toRiskBranchResult(rawBranch) {
    if (!rawBranch || typeof rawBranch !== 'object') return null;

    if (rawBranch.result && typeof rawBranch.result === 'object') {
      return rawBranch.result;
    }

    return {
      text: rawBranch.text,
      nextNodeId: rawBranch.nextNodeId,
      effects: rawBranch.effects
    };
  }

  function pickWeightedOutcome(outcomes) {
    const weighted = outcomes
      .map((item) => {
        const rawChance = item?.chance ?? item?.probability ?? item?.weight;
        const chance = parseSuccessChance(rawChance);
        return {
          item,
          chance: chance === null ? 0 : chance
        };
      })
      .filter((entry) => entry.chance > 0);

    if (weighted.length === 0) {
      return outcomes[0] || null;
    }

    const total = weighted.reduce((acc, entry) => acc + entry.chance, 0);
    let roll = Math.random() * total;
    for (const entry of weighted) {
      roll -= entry.chance;
      if (roll <= 0) return entry.item;
    }

    return weighted[weighted.length - 1].item;
  }

  function resolveRiskChoiceBranch(choice) {
    const outcomes = Array.isArray(choice?.outcomes) ? choice.outcomes.filter(Boolean) : [];
    if (outcomes.length > 0) {
      const selectedOutcome = pickWeightedOutcome(outcomes);
      const branch = toRiskBranchResult(selectedOutcome);
      const status = normalizeOutcomeStatus(
        selectedOutcome?.status
        || selectedOutcome?.outcomeStatus
        || selectedOutcome?.outcome
        || selectedOutcome?.kind
      );
      return { branch, status };
    }

    const chance = parseSuccessChance(choice?.successChance);
    if (chance !== null) {
      const success = Math.random() <= chance;
      const branch = success
        ? (choice?.successResult && typeof choice.successResult === 'object' ? choice.successResult : null)
        : (choice?.failureResult && typeof choice.failureResult === 'object' ? choice.failureResult : null);
      return { branch, status: success ? 'success' : 'failure' };
    }

    const branch =
      (choice?.result && typeof choice.result === 'object')
      ? choice.result
      : {
          text: choice?.text,
          nextNodeId: choice?.nextNodeId,
          effects: choice?.effects
        };

    return {
      branch,
      status: normalizeOutcomeStatus(choice?.status || choice?.outcomeStatus)
    };
  }

  function findStatDefByKey(statKey) {
    const safeKey = String(statKey || '').trim().toLowerCase();
    return INFINITE_STAT_DEFS.find((def) => {
      if (def.key === safeKey) return true;
      return Array.isArray(def.aliases) && def.aliases.map((alias) => String(alias).toLowerCase()).includes(safeKey);
    }) || null;
  }

  function normalizeRiskStatKeys(rawValue) {
    if (Array.isArray(rawValue)) {
      return rawValue.map((value) => String(value || '').trim().toLowerCase()).filter(Boolean);
    }

    const safe = String(rawValue || '').trim().toLowerCase();
    return safe ? [safe] : [];
  }

  function resolveRiskStatDefs(effect) {
    const statsFromStat = Array.isArray(effect?.stat)
      ? effect.stat
      : (effect?.stat ? [effect.stat] : []);
    const statsFromStats = Array.isArray(effect?.stats) ? effect.stats : [];
    const requested = [...statsFromStat, ...statsFromStats]
      .map((value) => findStatDefByKey(value))
      .filter(Boolean);

    const uniqueRequested = Array.from(new Map(requested.map((def) => [def.key, def])).values());
    if (uniqueRequested.length > 0) return uniqueRequested;

    const statKey = String(effect?.stat || '').trim().toLowerCase();
    if (statKey === 'all-stats') return [...INFINITE_STAT_DEFS];

    const single = findStatDefByKey(statKey);
    return single ? [single] : [];
  }

  function getRiskPercentByStatIndex(effect, statIndex) {
    const indexedPercent = Math.abs(Number(effect?.[`percent${statIndex + 1}`]) || 0);
    if (indexedPercent > 0) return indexedPercent;
    return Math.abs(Number(effect?.percent) || 0);
  }

  function getBuffMapForCard(cardId) {
    const safeId = String(cardId || '').trim();
    if (!safeId) return {};
    const map = state.runCardBuffs && typeof state.runCardBuffs === 'object' ? state.runCardBuffs : {};
    return map[safeId] && typeof map[safeId] === 'object' ? map[safeId] : {};
  }

  function getCardEffectiveAverageForRisk(cardId) {
    const resolved = resolveCardDataFromMeta({ cardId });
    const card = resolved?.card || null;
    if (!card) return 0;

    const buffs = getBuffMapForCard(cardId);
    const values = INFINITE_STAT_DEFS
      .map((statDef) => {
        const base = getCardBaseStatValue(card, statDef);
        const buff = Number(buffs?.[statDef.key]) || 0;
        const total = Math.max(1, base + buff);
        return base > 0 ? total : 0;
      })
      .filter((value) => value > 0);

    if (values.length === 0) {
      return Math.max(0, Number(card?.media) || 0);
    }

    const sum = values.reduce((acc, value) => acc + value, 0);
    return sum / values.length;
  }

  function resolveRiskTargetCardId(target, candidateCardIds, statDefs) {
    const safeTarget = String(target || 'random-run-card').trim().toLowerCase();

    const hasRequiredStats = (cardId) => {
      const resolved = resolveCardDataFromMeta({ cardId });
      return statDefs.some((statDef) => getCardBaseStatValue(resolved?.card, statDef) > 0);
    };

    const validCandidates = candidateCardIds.filter((cardId) => hasRequiredStats(cardId));
    if (validCandidates.length === 0) return '';

    if (safeTarget === 'higher-run-card' || safeTarget === 'lower-run-card') {
      const sorted = [...validCandidates].sort((a, b) => {
        const avgA = getCardEffectiveAverageForRisk(a);
        const avgB = getCardEffectiveAverageForRisk(b);
        return safeTarget === 'higher-run-card' ? (avgB - avgA) : (avgA - avgB);
      });
      return String(sorted[0] || '');
    }

    if (safeTarget === 'random-run-card') {
      const shuffled = [...validCandidates].sort(() => Math.random() - 0.5);
      return String(shuffled[0] || '');
    }

    return '';
  }

  function resolveRiskStatModeForKey(mode, statKey, effect) {
    const safeMode = String(mode || '').trim().toLowerCase();
    if (safeMode === 'nerf') return 'nerf';
    if (safeMode !== 'nerfandbuff') return 'buff';

    const buffSet = new Set(normalizeRiskStatKeys(effect?.buff));
    const nerfSet = new Set(normalizeRiskStatKeys(effect?.nerf));

    if (buffSet.has(statKey)) return 'buff';
    if (nerfSet.has(statKey)) return 'nerf';

    // Fallback for incomplete configs in nerfandbuff mode.
    return 'buff';
  }

  function applyCardStatPercentEffect(effect) {
    const target = String(effect?.target || 'random-run-card').trim().toLowerCase();
    if (!['random-run-card', 'higher-run-card', 'lower-run-card'].includes(target)) {
      return ['Efecto ignorado: target no soportado.'];
    }

    const candidateCardIds = getUpgradeCandidateIds().filter(Boolean);
    if (candidateCardIds.length === 0) {
      return ['No hay cartas en run para aplicar el evento.'];
    }

    const statDefs = resolveRiskStatDefs(effect);

    if (statDefs.length === 0) {
      return ['Efecto ignorado: stat no válida.'];
    }

    const chosenCardId = resolveRiskTargetCardId(target, candidateCardIds, statDefs);
    const chosenCard = chosenCardId ? (resolveCardDataFromMeta({ cardId: chosenCardId })?.card || null) : null;

    if (!chosenCardId) {
      return ['No se encontró una carta válida para ese stat.'];
    }

    if (!state.runCardBuffs[chosenCardId] || typeof state.runCardBuffs[chosenCardId] !== 'object') {
      state.runCardBuffs[chosenCardId] = {};
    }

    const cardName = String(chosenCard?.name || chosenCard?.nombre || chosenCardId);
    const messages = [];
    const isMultiStatSelection = statDefs.length > 1;
    const mode = String(effect?.mode || '').trim().toLowerCase();

    const availablePercents = statDefs
      .map((_, index) => getRiskPercentByStatIndex(effect, index))
      .filter((value) => value > 0);
    if (availablePercents.length === 0) {
      return ['Efecto ignorado: porcentaje inválido.'];
    }

    statDefs.forEach((statDef, statIndex) => {
      const requestedPercent = getRiskPercentByStatIndex(effect, statIndex);
      if (requestedPercent <= 0) return;

      const statMode = resolveRiskStatModeForKey(mode, statDef.key, effect);
      const isNerf = statMode === 'nerf';
      const baseValue = Math.max(1, getCardBaseStatValue(chosenCard, statDef));
      const rawDelta = Math.max(1, Math.round((baseValue * requestedPercent) / 100));
      const requestedDelta = isNerf ? -rawDelta : rawDelta;
      const currentBuff = Number(state.runCardBuffs[chosenCardId][statDef.key]) || 0;
      const minAllowedBuff = -(Math.max(1, baseValue) - 1);
      const nextBuff = Math.max(minAllowedBuff, currentBuff + requestedDelta);
      const appliedDelta = nextBuff - currentBuff;
      const finalValue = Math.max(1, baseValue + nextBuff);

      if (nextBuff === 0) {
        delete state.runCardBuffs[chosenCardId][statDef.key];
      } else {
        state.runCardBuffs[chosenCardId][statDef.key] = nextBuff;
      }

      const signal = appliedDelta > 0 ? '+' : '';
      if (isMultiStatSelection) {
        messages.push(`${cardName}: ${statDef.label} ${signal}${appliedDelta} (valor final ${finalValue}).`);
      } else if (appliedDelta === 0) {
        messages.push(`${cardName}: ${statDef.label} sin cambios (ya estaba al mínimo permitido).`);
      } else {
        messages.push(`${cardName}: ${statDef.label} ${signal}${appliedDelta} (valor final ${finalValue}).`);
      }
    });

    if (Object.keys(state.runCardBuffs[chosenCardId]).length === 0) {
      delete state.runCardBuffs[chosenCardId];
    }

    if (messages.length === 0) {
      return ['Efecto ignorado: no se pudo aplicar porcentaje válido a las stats.'];
    }

    return messages;
  }

  function applyRiskEffects(effects) {
    if (!Array.isArray(effects) || effects.length === 0) return [];

    const messages = [];

    effects.forEach((effect) => {
      if (!effect || typeof effect !== 'object') return;

      const type = String(effect.type || '').trim().toLowerCase();
      if (type === 'cardstatpercent') {
        messages.push(...applyCardStatPercentEffect(effect));
        return;
      }

      if (type === 'currencydelta') {
        const currency = normalizeShopCurrency(effect.currency);
        const amount = Math.round(Number(effect.amount) || 0);
        const current = Math.max(0, Number(state.shopCurrencies[currency]) || 0);
        const next = Math.max(0, current + amount);
        state.shopCurrencies[currency] = next;
        persistInfiniteCurrencies();
        renderShopCurrencyBar();
        messages.push(`${currency}: ${amount >= 0 ? '+' : ''}${amount}.`);
        return;
      }

      messages.push(`Efecto no soportado: ${type || 'desconocido'}.`);
    });

    renderTeamPreview();
    persistInfiniteRunState();
    return messages;
  }

  async function typeRiskText(element, text, speed = 20) {
    if (!element) return;

    const content = String(text || '');
    element.textContent = '';
    if (!content) return;

    for (let i = 1; i <= content.length; i += 1) {
      element.textContent = content.slice(0, i);
      await new Promise((resolve) => setTimeout(resolve, speed));
    }
  }

  function getRiskNodeById(eventDef, nodeId) {
    const safeId = String(nodeId || '').trim();
    if (!safeId) return null;
    return (eventDef?.nodes || []).find((node) => String(node.id) === safeId) || null;
  }

  async function finalizeRiskEventAndConsumeNode() {
    if (refs.riskModal) refs.riskModal.style.display = 'none';
    if (refs.riskChoices) refs.riskChoices.innerHTML = '';
    if (refs.riskOutcome) {
      refs.riskOutcome.style.display = 'none';
      refs.riskOutcome.textContent = '';
      refs.riskOutcome.classList.remove('is-success', 'is-failure');
    }
    if (refs.riskContinueBtn) refs.riskContinueBtn.style.display = 'none';
    state.activeRiskEvent = null;
    state.shopRestocking = false;
    persistInfiniteRunState();

    closeDecisionModal();
    advanceFloorAfterClear();
  }

  async function renderRiskNode(eventDef, nodeId) {
    const node = getRiskNodeById(eventDef, nodeId);
    if (!node) {
      await finalizeRiskEventAndConsumeNode();
      return;
    }

    if (refs.riskTitle) refs.riskTitle.textContent = node.title || eventDef.title || 'Evento de riesgo';
    if (refs.riskChoices) refs.riskChoices.innerHTML = '';
    if (refs.riskOutcome) {
      refs.riskOutcome.style.display = 'none';
      refs.riskOutcome.textContent = '';
      refs.riskOutcome.classList.remove('is-success', 'is-failure');
    }
    if (refs.riskContinueBtn) refs.riskContinueBtn.style.display = 'none';

    await typeRiskText(refs.riskText, node.text || '', 18);

    const choices = Array.isArray(node.choices) ? node.choices : [];
    if (choices.length === 0) {
      if (refs.riskContinueBtn) {
        refs.riskContinueBtn.style.display = 'inline-flex';
        refs.riskContinueBtn.onclick = () => {
          finalizeRiskEventAndConsumeNode();
        };
      }
      return;
    }

    choices.forEach((choice) => {
      const choiceBtn = document.createElement('button');
      choiceBtn.type = 'button';
      choiceBtn.className = 'infinite-risk-choice-btn';
      choiceBtn.innerHTML = `
        <span class="infinite-risk-choice-title">${String(choice?.label || 'Elegir')}</span>
        <span class="infinite-risk-choice-desc">${String(choice?.description || '')}</span>
      `;

      choiceBtn.addEventListener('click', async () => {
        if (refs.riskChoices) {
          Array.from(refs.riskChoices.querySelectorAll('button')).forEach((btn) => {
            btn.disabled = true;
          });
        }

        const resolved = resolveRiskChoiceBranch(choice);
        const branch = resolved?.branch || null;
        const status = resolved?.status || 'neutral';

        const resultText = String(branch?.text || 'No ocurrió nada relevante.');
        const effectMessages = applyRiskEffects(branch?.effects);

        if (refs.riskOutcome) {
          refs.riskOutcome.style.display = 'block';
          refs.riskOutcome.textContent = '';
          refs.riskOutcome.classList.remove('is-success', 'is-failure');
          if (status === 'success') refs.riskOutcome.classList.add('is-success');
          if (status === 'failure') refs.riskOutcome.classList.add('is-failure');
          await typeRiskText(refs.riskOutcome, resultText, 18);
          if (effectMessages.length > 0) {
            refs.riskOutcome.textContent += `\n\n${effectMessages.join('\n')}`;
          }
        }

        const nextNodeId = String(branch?.nextNodeId || '').trim();
        if (nextNodeId) {
          if (refs.riskContinueBtn) {
            refs.riskContinueBtn.style.display = 'inline-flex';
            refs.riskContinueBtn.onclick = () => {
              renderRiskNode(eventDef, nextNodeId);
            };
          }
          return;
        }

        if (refs.riskContinueBtn) {
          refs.riskContinueBtn.style.display = 'inline-flex';
          refs.riskContinueBtn.onclick = () => {
            finalizeRiskEventAndConsumeNode();
          };
        }
      });

      refs.riskChoices?.appendChild(choiceBtn);
    });
  }

  function pickRiskEventForCurrentFloor(riskConfig) {
    const events = Array.isArray(riskConfig?.events) ? riskConfig.events : [];
    const floor = normalizeFloorValue(state.currentFloor);
    const currentWorldId = String(getCurrentWorldId() || '').trim();
    const available = events.filter((eventDef) => {
      const inFloorRange = floor >= eventDef.minFloor && floor <= eventDef.maxFloor;
      if (!inFloorRange) return false;

      const worldIds = Array.isArray(eventDef.worldIds)
        ? eventDef.worldIds.map((id) => String(id || '').trim()).filter(Boolean)
        : [];

      if (worldIds.length === 0) return true;
      if (!currentWorldId) return false;
      return worldIds.includes(currentWorldId);
    });
    if (available.length === 0) return null;
    return available[Math.floor(Math.random() * available.length)] || null;
  }

  async function openRiskEventFlow() {
    alert('Eventos de Riesgo está en creación, esperando a que Grejino02 trabaje...');
    return;
  }

  function applyDecisionChoice(choice) {
    switch (choice) {
      case 'upgrade': {
        openUpgradeFlow();
        return;
      }
      case 'risk': {
        alert('Eventos de Riesgo está en creación, esperando a que Grejino02 trabaje...');
        return;
      }
      case 'shop': {
        if (state.shopRestocking) {
          alert('Lo sentimos, estamos reponiendo la tienda');
          return;
        }
        state.runStats.shopVisits += 1;
        openShopFlow();
        return;
      }
      case 'add-unselected': {
        openAddCardFlow();
        return;
      }
      default:
        return;
    }

    closeDecisionModal();
    advanceFloorAfterClear();
  }

  async function handleClaimArcReward() {
    const arcIndex = getArcIndexByFloor(state.currentFloor);
    const world = getThemeByFloor(state.currentFloor);
    const milestoneLevel = (arcIndex * 10) + 10;

    // 1. Obtener recompensas de hito de temporada si aplica (unicamente las de GitHub)
    const seasonConfig = await loadInfiniteSeasonConfig();
    const milestone = seasonConfig?.rewards?.find((r) => Number(r.level) === Number(milestoneLevel));
    const milestoneRewards = Array.isArray(milestone?.rewards) ? [...milestone.rewards] : [];

    const allRewards = [...milestoneRewards];

    // 3. Otorgar recompensas mediante grantPrestigeRewards
    if (typeof window.grantPrestigeRewards === 'function') {
      await window.grantPrestigeRewards(allRewards);
    } else {
      for (const item of allRewards) {
        const itemType = String(item.type || '').toLowerCase();
        const itemAmt = Number(item.amount) || 1;
        if (itemType === 'infinite-coins' || itemType === 'infinite-coin') {
          if (typeof window.infiniteAddCurrency === 'function') window.infiniteAddCurrency('infinite-coins', itemAmt);
        } else if (itemType === 'infinite-cardpoints' || itemType === 'infinite-cardpoint') {
          if (typeof window.infiniteAddCurrency === 'function') window.infiniteAddCurrency('infinite-cardpoints', itemAmt);
        } else if (itemType === 'coins' && window.kvrcards?.addCoins) {
          await window.kvrcards.addCoins(itemAmt);
        } else if (itemType === 'traits' || itemType === 'trait') {
          let traitGiven = false;
          if (window.kvrcards?.addTraits) {
            const res = await window.kvrcards.addTraits(itemAmt);
            if (res?.ok) traitGiven = true;
          }
          if (!traitGiven && window.kvrcards?.debugModifyTraits) {
            const res = await window.kvrcards.debugModifyTraits(itemAmt);
            if (res?.ok) traitGiven = true;
          }
          if (!traitGiven) {
            if (window.userProfile) {
              window.userProfile.traits = (Number(window.userProfile.traits) || 0) + itemAmt;
              traitGiven = true;
              if (typeof saveUserProfile === 'function') await saveUserProfile();
            }
            try {
              const cur = Number(localStorage.getItem('kvr_wallet_traits')) || 0;
              localStorage.setItem('kvr_wallet_traits', String(cur + itemAmt));
            } catch {}
          }
        }
      }
    }

    if (typeof renderWallet === 'function') {
      await renderWallet().catch(() => {});
    }
    if (typeof renderTraitsPanel === 'function') {
      renderTraitsPanel();
    }
    if (typeof window.renderTraitsPanel === 'function') {
      window.renderTraitsPanel();
    }

    // 4. Marcar hito como reclamado
    state.claimedMilestones = Array.isArray(state.claimedMilestones) ? state.claimedMilestones : [];
    if (!state.claimedMilestones.includes(milestoneLevel)) {
      state.claimedMilestones.push(milestoneLevel);
    }
    persistInfiniteRunState();

    if (typeof playSFX === 'function') {
      try {
        playSFX('packSparkle', { volumeMultiplier: 1.0 });
      } catch {}
    }

    // 5. Animación unificada de recompensas reclamadas (la misma de misiones, kizunas, etc.)
    if (typeof window.showUnifiedRewardsHUD === 'function') {
      await window.showUnifiedRewardsHUD(allRewards, `¡MUNDO ${arcIndex + 1} COMPLETADO!`);
    }

    advanceFloorAfterClear();
  }

  function advanceFloorAfterClear() {
    const justCleared = normalizeFloorValue(state.currentFloor);

    if (isBossFloor(justCleared)) {
      const theme = getThemeByFloor(justCleared);
      alert(`Jefe derrotado en ${theme.name}. Avanzas al siguiente arco.`);
    }

    state.currentFloor = justCleared + 1;
    renderFloorStrip();
    renderRunStatus();
    renderMyRankingPreview();
    renderTeamPreview();
    updateStartRunButton();
    persistInfiniteRunState();
  }

  function completeCurrentFloor() {
    if (!window.currentUserIsAdmin) {
      console.warn('[ADMIN] Acceso denegado: solo cuentas admin pueden completar pisos.');
      return;
    }
    if (!state.runActive) return;

    if (isDecisionFloor(state.currentFloor)) {
      openDecisionModal();
      return;
    }

    if (isRewardFloor(state.currentFloor)) {
      handleClaimArcReward();
      return;
    }

    advanceFloorAfterClear();
  }

  function startRun() {
    if (!state.runActive) {
      startInfiniteBattleFromCurrentFloor();
      return;
    }

    if (isDecisionFloor(state.currentFloor)) {
      openDecisionModal();
      return;
    }

    if (isRewardFloor(state.currentFloor)) {
      handleClaimArcReward();
      return;
    }

    openPlayConfirmModal();
  }

  function applyTeamBuilderRestriction() {
    if (!state.initialTeamLocked) return;
    if (!Array.isArray(window.teamBuilderCards)) window.teamBuilderCards = [];

    state.originalTeamBuilderCards = [...window.teamBuilderCards];
    const sourceIds = Array.isArray(state.runDeckIds) && state.runDeckIds.length > 0
      ? state.runDeckIds
      : state.selectedInitialCardIds;
    if (!Array.isArray(sourceIds) || sourceIds.length === 0) return;

    // Inject temporary run cards (e.g. from chapas) into window.teamBuilderCards if not present
    sourceIds.forEach((id) => {
      const baseId = extractBaseCardId(id);
      const exists = window.teamBuilderCards.some((c) => extractBaseCardId(c.id) === baseId);
      if (!exists) {
        const catCard = state.runTemporalCards?.[baseId] || state.catalogCardsById?.[baseId];
        if (catCard) {
          const stats = extractCardStatsForInfinite(catCard);
          window.teamBuilderCards.push({
            ...catCard,
            id: catCard.id,
            name: catCard.nombre || catCard.name || catCard.id,
            imageUrl: catCard.imageUrl || catCard.image || catCard.imagen || '',
            image: catCard.imageUrl || catCard.image || catCard.imagen || '',
            media: Number(catCard.media) || 0,
            procedencia: String(catCard.procedencia || catCard.origen || catCard.source || catCard.aldea || ''),
            uniqueId: `${catCard.id}_notrait`,
            instanceId: null,
            hasTrait: false,
            availableCount: 1,
            isRunTemporal: true,
            ...stats
          });
        }
      }
    });

    const allowed = new Set(sourceIds.map((id) => normalizePoolKey(extractBaseCardId(id))));

    // CRÍTICO: Nunca eliminar cartas que están actualmente en window.selectedTeam
    if (Array.isArray(window.selectedTeam)) {
      window.selectedTeam.forEach((selectedId) => {
        if (selectedId) {
          allowed.add(normalizePoolKey(extractBaseCardId(selectedId)));
          allowed.add(normalizePoolKey(selectedId));
        }
      });
    }

    const restricted = window.teamBuilderCards.filter((card) => {
      const unique = normalizePoolKey(card.uniqueId || card.id);
      const base = normalizePoolKey(card.id);
      return allowed.has(unique) || allowed.has(base);
    });

    restricted.sort((a, b) => (Number(b.media) || 0) - (Number(a.media) || 0));

    window.teamBuilderCards = restricted;
  }

  function restoreTeamBuilderPoolIfNeeded() {
    window.isInfiniteModeTeamBuilding = false;
    if (window.selectedDifficulty === 'inmo') {
      window.selectedDifficulty = null;
    }

    if (Array.isArray(state.originalTeamBuilderCards) && state.originalTeamBuilderCards.length > 0) {
      window.teamBuilderCards = [...state.originalTeamBuilderCards];
      state.originalTeamBuilderCards = null;
    } else if (Array.isArray(window.teamBuilderCards)) {
      window.teamBuilderCards = window.teamBuilderCards.filter((c) => !c.isRunTemporal);
    }

    // Restaurar los equipos y poderes normales guardados en localStorage
    if (typeof window.loadSavedTeam === 'function') {
      window.loadSavedTeam();
    }
  }

  function prefillTeamBuilderFromInitialSelection() {
    if (!state.initialTeamLocked || !Array.isArray(state.selectedInitialCardIds)) return;

    const desiredIds = state.selectedInitialCardIds.slice(0, 8);
    const equipped = [];
    const usedUniqueIds = new Set();
    const pool = Array.isArray(window.teamBuilderCards) ? window.teamBuilderCards : [];
    const runSeed = Date.now();

    desiredIds.forEach((baseId, index) => {
      const candidate = pool.find((card) => {
        if (!card || card.id !== baseId) return false;
        const uniqueId = String(card.uniqueId || card.id || '');
        return !usedUniqueIds.has(uniqueId);
      });

      if (!candidate) {
        equipped.push(null);
        return;
      }

      const candidateUnique = String(candidate.uniqueId || candidate.id || '');
      usedUniqueIds.add(candidateUnique);

      if (candidate.hasTrait) {
        equipped.push(candidateUnique);
      } else {
        equipped.push(`${candidate.id}_notrait_${runSeed}_${index}`);
      }
    });

    while (equipped.length < 8) equipped.push(null);

    window.selectedTeam = [...equipped];
  }

  function prefillTeamBuilderPowersFromInitialSelection() {
    const sourcePowerIds = (Array.isArray(state.selectedInitialPowerIds) && state.selectedInitialPowerIds.filter(Boolean).length > 0)
      ? state.selectedInitialPowerIds
      : (Array.isArray(state.initialPowersSnapshot) ? state.initialPowersSnapshot.filter(Boolean) : []);
    if (sourcePowerIds.length === 0) return;

    const powerSelection = sourcePowerIds.slice(0, 3);
    while (powerSelection.length < 3) powerSelection.push(null);

    window.selectedTeamPowers = [...powerSelection];
  }

  async function resolveInfinitePanelUsername() {
    try {
      if (window.kvrcards && typeof window.kvrcards.getProfile === 'function') {
        const profileResult = await window.kvrcards.getProfile();
        const profileUsername = String(profileResult?.profile?.username || '').trim();
        if (profileUsername) return profileUsername;
      }
    } catch (error) {
      console.warn('[INFINITE PANEL] No se pudo resolver usuario desde perfil:', error?.message || error);
    }

    try {
      const storedUsername = String(
        window.currentUser ||
        localStorage.getItem('kvrUsername') ||
        localStorage.getItem('userId') ||
        ''
      ).trim();
      if (storedUsername) return storedUsername;
    } catch {}

    return '';
  }

  async function fetchInfinitePanelRankings(limit = 5, username = '') {
    const url = new URL('https://kvrcards-server.onrender.com/api/infinite/rankings');
    url.searchParams.set('limit', String(Math.max(1, Math.min(50, Number(limit) || 5))));
    if (username) url.searchParams.set('username', username);
    url.searchParams.set('t', String(Date.now()));

    const response = await fetch(url.toString(), { cache: 'no-store' });
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    return response.json();
  }

  async function renderMyRankingPreview() {
    if (!refs.myRanking) return;

    refs.myRanking.textContent = 'Tu puesto: cargando...';
    if (refs.seasonName) refs.seasonName.textContent = 'Temporada: cargando...';
    if (refs.seasonTop) refs.seasonTop.innerHTML = '<div style="text-align:center;padding:10px;color:#999;">Cargando top de temporada...</div>';
    if (refs.seasonSelf) refs.seasonSelf.textContent = '';

    try {
      const resolvedUsername = await resolveInfinitePanelUsername();
      let result = null;
      
      // Intentar bridge primero
      if (window.kvrcards && typeof window.kvrcards.getInfiniteRankingsOverview === 'function') {
        try {
          result = await window.kvrcards.getInfiniteRankingsOverview(5);
          if (result && result.ok) {
            console.log('[INFINITE PANEL] Bridge exitoso');
          } else {
            console.warn('[INFINITE PANEL] Bridge retornó error:', result?.error);
            result = null; // Intentar fallback
          }
        } catch (bridgeError) {
          console.warn('[INFINITE PANEL] Bridge falló:', bridgeError?.message);
          result = null; // Intentar fallback
        }
      }

      // Fallback a API remota si bridge falló o no devolvió posición útil
      const bridgeSeasonalRank = Number(result?.you?.seasonalRank) || Number(result?.you?.rank) || 0;
      if (!result || !result.ok || bridgeSeasonalRank <= 0) {
        try {
          console.log('[INFINITE PANEL] Intentando fallback a API remota con usuario:', resolvedUsername || '(vacío)');
          const fallbackResult = await fetchInfinitePanelRankings(5, resolvedUsername);
          if (fallbackResult && fallbackResult.ok) {
            result = fallbackResult;
            console.log('[INFINITE PANEL] Fallback exitoso');
          } else {
            throw new Error(fallbackResult?.error || 'Respuesta inválida');
          }
        } catch (fallbackError) {
          console.warn('[INFINITE PANEL] Fallback falló:', fallbackError?.message);
          refs.myRanking.textContent = 'Tu puesto: no disponible (error al cargar)';
          if (refs.seasonTop) refs.seasonTop.innerHTML = '<div style="text-align:center;padding:10px;color:#ff6b6b;">Error al cargar ranking. Verifica tu conexión.</div>';
          return;
        }
      }

      // Si llegamos aquí, tenemos un resultado válido
      if (!result || !result.ok) {
        refs.myRanking.textContent = 'Tu puesto: no disponible';
        if (refs.seasonTop) refs.seasonTop.innerHTML = '<div style="text-align:center;padding:10px;color:#999;">No se pudo cargar el ranking.</div>';
        return;
      }

      const rawTopSeasonal = Array.isArray(result.topSeasonal) ? result.topSeasonal : [];
      const topSeasonal = rawTopSeasonal.filter(entry => {
        if (!entry) return false;
        if (entry.isAdmin === true || entry.role === 'admin') return false;
        if (window.currentUserIsAdmin && String(entry.username || '').trim().toLowerCase() === String(resolvedUsername || '').trim().toLowerCase()) return false;
        return true;
      });
      const you = result.you && typeof result.you === 'object' ? result.you : {};
      const season = result.season && typeof result.season === 'object' ? result.season : {};
      const seasonId = String(season.id || '').trim();
      const seasonName = String(season.name || '').trim();

      if (refs.seasonName) {
        refs.seasonName.textContent = seasonName
          ? `Temporada: ${seasonName}${seasonId ? ` (${seasonId})` : ''}`
          : 'Temporada: no disponible';
      }

      if (refs.seasonTop) {
        refs.seasonTop.innerHTML = '';

        const list = document.createElement('div');
        list.className = 'infinite-season-top-list';

        if (topSeasonal.length === 0) {
          const empty = document.createElement('div');
          empty.className = 'infinite-season-top-row';
          empty.innerHTML = '<span class="infinite-season-top-rank">—</span><span class="infinite-season-top-user">Sin jugadores</span>';
          list.appendChild(empty);
        } else {
          topSeasonal.slice(0, 5).forEach((entry, idx) => {
            const row = document.createElement('div');
            row.className = 'infinite-season-top-row';
            const entryUser = String(entry?.username || '').trim().toLowerCase();
            const youUser = String(you?.username || '').trim().toLowerCase();
            if (entryUser && youUser && entryUser === youUser) {
              row.classList.add('you');
            }

            const rank = document.createElement('span');
            rank.className = 'infinite-season-top-rank';
            rank.textContent = `#${idx + 1}`;

            const user = document.createElement('span');
            user.className = 'infinite-season-top-user';
            user.textContent = String(entry?.username || 'Jugador');

            const score = document.createElement('span');
            score.className = 'infinite-season-top-score';
            const scoreValue = Number(entry?.score) || Number(entry?.seasonalScore) || 0;
            score.textContent = scoreValue.toLocaleString();

            row.appendChild(rank);
            row.appendChild(user);
            row.appendChild(score);
            list.appendChild(row);
          });
        }

        const separator = document.createElement('div');
        separator.className = 'infinite-season-separator';
        list.appendChild(separator);

        refs.seasonTop.appendChild(list);
      }

      if (window.currentUserIsAdmin) {
        refs.myRanking.textContent = 'Tu puesto: cuenta admin (no clasifica)';
        if (refs.seasonSelf) {
          refs.seasonSelf.innerHTML = '<div class="infinite-season-top-row"><span class="infinite-season-top-rank">—</span><span class="infinite-season-top-user">Cuenta Admin</span><span class="infinite-season-top-score">—</span></div>';
        }
      } else {
        const seasonalRank = Number(you?.seasonalRank) || Number(you?.rank) || 0;
        const seasonalScore = Math.max(0, Number(you?.seasonalScore) || Number(you?.score) || 0);
        const youUsername = String(you?.username || resolvedUsername || 'Tu cuenta').trim().toLowerCase();

        // Buscar si el usuario está en el top mostrado para validar su posición
        let userRankInTop = 0;
        if (youUsername) {
          const foundIndex = topSeasonal.findIndex(entry => 
            String(entry?.username || '').trim().toLowerCase() === youUsername
          );
          if (foundIndex !== -1) {
            userRankInTop = foundIndex + 1;
          }
        }

        // Determinar la posición real: si está en el top mostrado, usarla; si no, usar seasonalRank/rank
        const finalRank = userRankInTop > 0 ? userRankInTop : seasonalRank;

        if (finalRank > 0) {
          refs.myRanking.textContent = `Tu puesto: #${finalRank}`;
        } else {
          refs.myRanking.textContent = 'Tu puesto: sin posición';
        }

        if (refs.seasonSelf) {
          if (finalRank > 0) {
            const selfScore = seasonalScore.toLocaleString();
            refs.seasonSelf.innerHTML = `<div class="infinite-season-top-row you"><span class="infinite-season-top-rank">#${finalRank}</span><span class="infinite-season-top-user">${you?.username || resolvedUsername || 'Tu cuenta'}</span><span class="infinite-season-top-score">${selfScore}</span></div>`;
          } else {
            refs.seasonSelf.innerHTML = '<div class="infinite-season-top-row"><span class="infinite-season-top-rank">—</span><span class="infinite-season-top-user">Sin posición</span><span class="infinite-season-top-score">0</span></div>';
          }
        }
      }
    } catch (error) {
      console.error('[INFINITE PANEL] Error inesperado:', error);
      refs.myRanking.textContent = 'Tu puesto: error al cargar';
      if (refs.seasonTop) refs.seasonTop.innerHTML = '<div style="text-align:center;padding:10px;color:#ff6b6b;">Error inesperado al cargar ranking.</div>';
    }
  }

  function openRankingsModal() {
    const modal = byId('rankings-modal');
    if (modal) modal.classList.add('show');

    if (typeof window.switchRankingCategory === 'function') {
      window.switchRankingCategory('infinite');
    } else if (typeof window.loadRankings === 'function') {
      window.loadRankings();
    }
  }

  async function openSeasonRewardsModal() {
    const modal = refs.rewardsModal || byId('infinite-season-rewards-modal');
    if (!modal) return;

    if (typeof playSFX === 'function') {
      try { playSFX('cardSelect'); } catch (e) {}
    }

    await renderSeasonRewardsContent();
    modal.style.display = 'flex';
  }

  function closeSeasonRewardsModal() {
    const modal = refs.rewardsModal || byId('infinite-season-rewards-modal');
    if (!modal) return;
    modal.style.display = 'none';
  }

  async function renderSeasonRewardsContent() {
    const container = refs.rewardsCatalog || byId('infinite-season-rewards-catalog');
    if (!container) return;

    const titleEl = byId('infinite-season-rewards-title');
    const subtitleEl = byId('infinite-season-rewards-subtitle');

    container.innerHTML = '<div style="text-align:center;padding:20px;color:#94a3b8;grid-column:1/-1;">Cargando recompensas de temporada...</div>';

    const seasonConfig = await loadInfiniteSeasonConfig();
    const seasonName = seasonConfig?.season?.name || 'Temporada 1 - Modo Infinito';
    if (titleEl) titleEl.textContent = `Recompensas: ${seasonName}`;
    if (subtitleEl) subtitleEl.textContent = 'Alcanza los pisos clave para desbloquear estas recompensas.';

    container.innerHTML = '';

    const rewardsList = Array.isArray(seasonConfig?.rewards) ? seasonConfig.rewards : [];
    const claimedList = Array.isArray(state.claimedMilestones) ? state.claimedMilestones : [];

    // Construir cache de cartas del catalogo para buscar imagenes reales
    const catalogCards = {};
    if (Array.isArray(state.catalogCardsById) || state.catalogCardsById) {
      Object.assign(catalogCards, state.catalogCardsById || {});
    }

    const GITHUB_IMG_BASE = 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/';

    rewardsList.forEach((entry) => {
      const lvl = Number(entry.level) || 10;
      const isClaimed = claimedList.includes(lvl);
      const items = Array.isArray(entry.rewards) ? entry.rewards : [];

      const card = document.createElement('div');
      card.className = 'infinite-reward-card' + (isClaimed ? ' milestone-claimed' : '');

      let itemsHtml = '';
      const cardClickHandlers = [];

      items.forEach((item, idx) => {
        const type = String(item.type || '').toLowerCase();
        const amt = Number(item.amount) || 1;
        let imgSrc = './icon-especiales.png';
        let name = item.name || '';
        let sub = '';
        let isClickable = false;
        let imgClass = '';
        let zoomSrc = '';
        let packImgFallback = './icon-especiales.png';

        if (type === 'coins') {
          imgSrc = './coin.png';
          name = `${amt.toLocaleString('es-ES')} Coins`;
          sub = 'Monedas de juego';

        } else if (type === 'traits' || type === 'trait') {
          imgSrc = './trait.png';
          name = `${amt} ${amt === 1 ? 'Trait' : 'Traits'}`;
          sub = 'Puntos de rasgos';

        } else if (type === 'pack' || type === 'packs') {
          const packId = String(item.packId || '').toLowerCase();
          imgSrc = `${GITHUB_IMG_BASE}${packId}.png`;
          imgClass = 'style="width:40px;height:56px;object-fit:contain;"';
          packImgFallback = packId.includes('oro') ? './icon-oro.png' : './icon-especiales.png';
          if (packId.includes('oro')) {
            name = `${amt}x Sobre Oro`;
          } else if (packId.includes('83')) {
            name = `${amt}x Sobre +83`;
          } else if (packId.includes('85')) {
            name = `${amt}x Sobre +85`;
          } else if (packId.includes('especial')) {
            name = `${amt}x Sobre Especial`;
          } else {
            name = `${amt}x Sobre`;
          }
          sub = 'Sobre de cartas';

        } else if (type === 'title') {
          imgSrc = './icon-especiales.png';
          name = item.name || 'Titulo Exclusivo';
          sub = 'Titulo cosmetico';

        } else if (type === 'card') {
          const cardId = String(item.cardId || item.id || '').trim();
          const catalogCard = catalogCards[cardId];
          imgSrc = catalogCard?.imageUrl || `${GITHUB_IMG_BASE}${cardId}.png`;
          imgClass = 'style="width:40px;height:56px;object-fit:contain;cursor:zoom-in;"';
          name = item.name || catalogCard?.name || 'Carta Exclusiva';
          sub = 'Carta de coleccion';
          isClickable = true;
          zoomSrc = imgSrc;
          cardClickHandlers.push({ idx, imgSrc: zoomSrc, cardId, catalogCard });

        } else {
          name = item.name || `${amt} ${type}`;
        }

        const fallbackAttr = (type === 'pack' || type === 'packs')
          ? ` onerror="this.src='${packImgFallback}';this.style.width='';this.style.height='';"`
          : (type === 'card' ? ` onerror="this.src='./icon-especiales.png';this.style.cursor='';this.style.width='';this.style.height='';"` : '');

        const clickAttr = isClickable ? ` data-reward-card-click="${idx}"` : '';

        itemsHtml += `
          <div class="infinite-reward-item-row"${clickAttr}>
            <img src="${imgSrc}" alt="${type}" ${imgClass}${fallbackAttr} />
            <div class="infinite-reward-item-info">
              <span class="infinite-reward-item-name">${name}</span>
              ${sub ? `<span class="infinite-reward-item-sub">${sub}</span>` : ''}
            </div>
          </div>
        `;
      });

      card.innerHTML = `
        <div class="infinite-reward-card-header">
          <span class="infinite-reward-level-tag">NIVEL ${lvl}</span>
          ${isClaimed ? '<span class="infinite-reward-claimed-tag">RECLAMADO</span>' : ''}
        </div>
        <div class="infinite-reward-items-list">
          ${itemsHtml}
        </div>
      `;

      // Asignar handlers de zoom para cartas
      cardClickHandlers.forEach(({ idx, imgSrc, cardId, catalogCard }) => {
        const clickRow = card.querySelector(`[data-reward-card-click="${idx}"]`);
        if (clickRow) {
          clickRow.style.cursor = 'zoom-in';
          clickRow.addEventListener('click', () => {
            if (typeof openLightbox === 'function') {
              openLightbox(imgSrc, catalogCard || { id: cardId, name: catalogCard?.name || cardId }, false);
            } else if (typeof openInfiniteCardZoom === 'function') {
              openInfiniteCardZoom(imgSrc, catalogCard || { id: cardId, name: catalogCard?.name || cardId });
            }
          });
        }
      });

      container.appendChild(card);
    });

    // Anadir tarjeta de Nivel 101+
    const beyondCard = document.createElement('div');
    beyondCard.className = 'infinite-reward-card';
    beyondCard.innerHTML = `
      <div class="infinite-reward-card-header">
        <span class="infinite-reward-level-tag">NIVEL 101+</span>
        <span class="infinite-reward-claimed-tag" style="background:rgba(234,179,8,0.2);border-color:rgba(234,179,8,0.5);color:#fef08a;">CONTINUO</span>
      </div>
      <div class="infinite-reward-items-list">
        <div class="infinite-reward-item-row">
          <img src="./trait.png" alt="trait" />
          <div class="infinite-reward-item-info">
            <span class="infinite-reward-item-name">+1 Trait por nivel ganado</span>
            <span class="infinite-reward-item-sub">Premio garantizado por cada victoria</span>
          </div>
        </div>
      </div>
    `;
    container.appendChild(beyondCard);
  }



  function openModifiersCatalogModal() {
    const modal = refs.modifiersModal || byId('infinite-modifiers-modal');
    if (!modal) return;

    if (typeof playSFX === 'function') {
      try { playSFX('cardSelect'); } catch (e) {}
    }

    renderModifiersCatalogContent();
    modal.style.display = 'flex';
  }

  function closeModifiersCatalogModal() {
    const modal = refs.modifiersModal || byId('infinite-modifiers-modal');
    if (!modal) return;
    modal.style.display = 'none';
  }

  function renderModifiersCatalogContent() {
    const container = refs.modifiersCatalog || byId('infinite-modifiers-catalog');
    if (!container) return;

    const normalMods = window.InfiniteModifiers?.NORMAL_MODIFIERS || [];
    const specialMods = window.InfiniteModifiers?.SPECIAL_MODIFIERS || [];

    const getTargetLabel = (target) => {
      switch (target) {
        case 'player': return 'Afecta al Jugador';
        case 'boss': return 'Afecta al Boss';
        case 'both': return 'Afecta a Ambos';
        case 'none': return 'Neutral';
        default: return 'Combate';
      }
    };

    const escapeText = (str) => {
      return String(str || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    };

    const renderCard = (mod, isSpecial) => {
      const typeClass = isSpecial ? 'special' : 'normal';
      const badgeText = isSpecial ? 'ESPECIAL' : 'NORMAL';
      const targetLabel = getTargetLabel(mod.target);

      let doubledHTML = '';
      if (isSpecial && mod.descDoubled && mod.descDoubled !== mod.baseDesc) {
        doubledHTML = `<div class="infinite-modifier-item-doubled"><span class="infinite-modifier-doubled-tag">Piso ≥51 (x2):</span> ${escapeText(mod.descDoubled)}</div>`;
      }

      return `
        <div class="infinite-modifier-card-item ${typeClass}">
          <div class="infinite-modifier-item-top">
            <span class="infinite-modifier-item-name">${escapeText(mod.name.toUpperCase())}</span>
            <div class="infinite-modifier-item-badges">
              <span class="infinite-modifier-item-target">${escapeText(targetLabel)}</span>
              <span class="infinite-modifier-item-badge ${typeClass}">${badgeText}</span>
            </div>
          </div>
          <div class="infinite-modifier-item-desc">${escapeText(mod.baseDesc)}</div>
          ${doubledHTML}
        </div>
      `;
    };

    container.innerHTML = `
      <div class="infinite-modifiers-section">
        <div class="infinite-modifiers-section-header normal">
          <h4>Modificadores Normales</h4>
          <span class="infinite-modifiers-section-note">(Pisos regulares y probabilidad en Mini-Boss)</span>
        </div>
        <div class="infinite-modifiers-grid">
          ${normalMods.map(m => renderCard(m, false)).join('')}
        </div>
      </div>

      <div class="infinite-modifiers-section">
        <div class="infinite-modifiers-section-header special">
          <h4>Modificadores Especiales</h4>
          <span class="infinite-modifiers-section-note">(Pisos de Boss 100%, Mini-Boss 50%)</span>
        </div>
        <div class="infinite-modifiers-grid">
          ${specialMods.map(m => renderCard(m, true)).join('')}
        </div>
      </div>
    `;
  }

  function validateInfiniteTeam(customTeam = null, customPowers = null) {
    const selectedTeam = Array.isArray(customTeam) ? customTeam : (Array.isArray(window.selectedTeam) ? window.selectedTeam : []);
    const selectedPowers = Array.isArray(customPowers) ? customPowers : (Array.isArray(window.selectedTeamPowers) ? window.selectedTeamPowers : []);

    const mainCount = selectedTeam.slice(0, 7).filter(Boolean).length;
    const reserve = selectedTeam[7];
    const powersCount = selectedPowers.filter(Boolean).length;

    if (mainCount !== 7) {
      alert(`Debes tener exactamente 7 cartas en el equipo titular (actualmente: ${mainCount}/7).`);
      return false;
    }
    if (!reserve) {
      alert('Necesitas 1 carta en el slot de reserva (slot R).');
      return false;
    }
    if (powersCount !== 3) {
      alert(`Necesitas 3 poderes equipados (actualmente: ${powersCount}/3).`);
      return false;
    }

    // Validar duplicados de personaje en todo el equipo del Modo Infinito
    const allSlots = [...selectedTeam.slice(0, 7).filter(Boolean), reserve];
    const seenChars = new Map();
    for (const uid of allSlots) {
      const cardObj = resolveCardFromUniqueId(uid);
      const charKey = getBaseCardName(uid, cardObj);
      const displayName = cardObj?.name || cardObj?.nombre || uid;
      if (seenChars.has(charKey)) {
        const prevName = seenChars.get(charKey);
        alert(`No puedes tener dos versiones del mismo personaje en el equipo de Modo Infinito:\n\n• ${prevName}\n• ${displayName}\n\nPor favor, cambia una de las dos cartas antes de continuar.`);
        return false;
      }
      seenChars.set(charKey, displayName);
    }

    return true;
  }

  function markTeamAsLocked() {
    state.initialTeamLocked = true;
    state.selectingTeam = false;

    const selectedTeam = Array.isArray(window.selectedTeam) ? window.selectedTeam.slice(0, 8).filter(Boolean) : [];
    const selectedPowerIdsFromSlots = Array.isArray(window.selectedTeamPowers)
      ? window.selectedTeamPowers.filter(Boolean).map((id) => String(id))
      : [];

    const cardIdsFromSlots = selectedTeam.map((entry) => {
      const resolved = resolveCardFromUniqueId(entry);
      if (resolved?.id) return String(resolved.id);
      const raw = String(entry || '');
      if (raw.includes('_notrait')) return raw.split('_notrait')[0];
      return raw;
    }).filter(Boolean);

    if (cardIdsFromSlots.length > 0) {
      state.selectedInitialCardIds = cardIdsFromSlots;
    } else {
      state.selectedInitialCardIds = state.selectedInitialCards.map((card) => card.id);
    }

    if (selectedPowerIdsFromSlots.length === 3) {
      state.selectedInitialPowerIds = selectedPowerIdsFromSlots;
    } else if (Array.isArray(state.selectedInitialPowers) && state.selectedInitialPowers.length === 3) {
      state.selectedInitialPowerIds = state.selectedInitialPowers.map((power) => (typeof power === 'string' ? power : power?.id)).filter(Boolean);
    } else if (selectedPowerIdsFromSlots.length > 0) {
      state.selectedInitialPowerIds = selectedPowerIdsFromSlots;
    } else {
      state.selectedInitialPowerIds = (state.selectedInitialPowers || []).map((power) => (typeof power === 'string' ? power : power?.id)).filter(Boolean);
    }

    // Asegurar que window.selectedTeamPowers tenga siempre los 3 poderes
    window.selectedTeamPowers = state.selectedInitialPowerIds.slice(0, 3);
    while (window.selectedTeamPowers.length < 3) window.selectedTeamPowers.push(null);

    // Guardar equipo exclusivo de Modo Infinito en localStorage
    try {
      const infiniteTeamData = {
        team: Array.isArray(window.selectedTeam) ? [...window.selectedTeam] : [],
        powers: [...state.selectedInitialPowerIds].slice(0, 3),
        cardIds: cardIdsFromSlots,
        powerIds: [...state.selectedInitialPowerIds].slice(0, 3),
        timestamp: new Date().toISOString()
      };
      localStorage.setItem(getInfiniteUserKey('infinite_saved_team'), JSON.stringify(infiniteTeamData));
    } catch (e) {
      console.warn('[INFINITE] Error guardando infinite_saved_team:', e);
    }

    const inventoryCards = Array.isArray(state.inventoryCards) ? state.inventoryCards : [];
    state.selectedInitialCards = state.selectedInitialCardIds
      .map((id) => inventoryCards.find((card) => card.id === id) || state.runTemporalCards?.[id] || state.catalogCardsById?.[id] || null)
      .filter(Boolean)
      .slice(0, 8);

    const inventoryPowers = Array.isArray(state.inventoryPowers) ? state.inventoryPowers : [];
    const allAvailable = Array.isArray(window.availablePowers) ? window.availablePowers : [];
    state.selectedInitialPowers = state.selectedInitialPowerIds
      .map((id) => {
        const foundInv = inventoryPowers.find((power) => power.id === id);
        if (foundInv) return foundInv;
        const foundAvail = allAvailable.find((power) => power.id === id);
        if (foundAvail) {
          return {
            id: foundAvail.id,
            name: foundAvail.name || foundAvail.id,
            imageUrl: foundAvail.imageUrl || foundAvail.image || ''
          };
        }
        return { id, name: id, imageUrl: '' };
      })
      .filter(Boolean)
      .slice(0, 3);

    if (!Array.isArray(state.runDeckIds)) state.runDeckIds = [];
    state.selectedInitialCardIds.forEach((id) => {
      const b = extractBaseCardId(id);
      if (!state.runDeckIds.includes(b)) state.runDeckIds.push(b);
    });

    state.initialTeamSnapshot = [...state.selectedInitialCardIds];
    while (state.initialTeamSnapshot.length < 8) state.initialTeamSnapshot.push(null);
    state.initialPowersSnapshot = [...state.selectedInitialPowerIds];

    prefillTeamBuilderFromInitialSelection();
    prefillTeamBuilderPowersFromInitialSelection();

    if (refs.teamStatus) {
      refs.teamStatus.classList.add('ready');
      refs.teamStatus.textContent = 'Equipo inicial confirmado y bloqueado para la run actual';
    }

    if (refs.selectTeamBtn) refs.selectTeamBtn.textContent = 'Modificar equipo';

    renderTeamPreview();
    renderTeamPowersPreview();
    renderRunStatus();
    persistInfiniteRunState();
  }

  function openTeamBuilderForInfinite() {
    state.selectingTeam = true;
    window.isInfiniteModeTeamBuilding = true;
    window.selectedDifficulty = 'inmo';
    closeInitialPicker();

    const panel = refs.panel;
    const teamBuilder = byId('team-builder');
    if (panel) panel.style.display = 'none';
    if (teamBuilder) teamBuilder.style.display = 'block';

    if (typeof window.updateTeamBuilderModeUI === 'function') {
      window.updateTeamBuilderModeUI();
    }

    if (typeof window.loadTeamBuilderInventory === 'function') {
      const maybePromise = window.loadTeamBuilderInventory();
      Promise.resolve(maybePromise).then(() => {
        applyTeamBuilderRestriction();
        if (typeof window.clearTeamSlots === 'function') window.clearTeamSlots();

        // 1. Cargar equipo de modo infinito desde infinite_saved_team si existe
        let loadedInfinite = false;
        try {
          const teamKey = getInfiniteUserKey('infinite_saved_team');
          const saved = localStorage.getItem(teamKey) || localStorage.getItem('infinite_saved_team');
          if (saved) {
            const parsed = JSON.parse(saved);
            if (Array.isArray(parsed.team) && parsed.team.length === 8 && parsed.team.filter(Boolean).length > 0) {
              window.selectedTeam = [...parsed.team];
              loadedInfinite = true;
            }
            const loadedPowers = (Array.isArray(parsed.powers) && parsed.powers.filter(Boolean).length > 0)
              ? parsed.powers
              : (Array.isArray(parsed.powerIds) && parsed.powerIds.filter(Boolean).length > 0 ? parsed.powerIds : null);
            if (loadedPowers) {
              window.selectedTeamPowers = [...loadedPowers];
              while (window.selectedTeamPowers.length < 3) window.selectedTeamPowers.push(null);
            }
          }
        } catch (e) {
          console.warn('[INFINITE] Error cargando infinite_saved_team:', e);
        }

        if (!loadedInfinite) {
          prefillTeamBuilderFromInitialSelection();
        }

        // Si no hay poderes en window.selectedTeamPowers, recuperar de snapshots o estado
        if (!Array.isArray(window.selectedTeamPowers) || window.selectedTeamPowers.filter(Boolean).length === 0) {
          prefillTeamBuilderPowersFromInitialSelection();
        }

        if (typeof window.renderTeamSlots === 'function') window.renderTeamSlots();
        if (typeof window.renderPowerSlots === 'function') window.renderPowerSlots();
        if (typeof window.renderTeamBuilderInventory === 'function') window.renderTeamBuilderInventory();
        if (typeof window.renderPowersInventory === 'function') window.renderPowersInventory();
        if (typeof window.updateTeamBuilderModeUI === 'function') window.updateTeamBuilderModeUI();
      });
    }

    if (typeof window.setupContinueButton === 'function') {
      setTimeout(() => {
        window.setupContinueButton();
        if (typeof window.updateTeamBuilderModeUI === 'function') window.updateTeamBuilderModeUI();
      }, 150);
    }
  }

  function openPanel() {
    state.panelOpen = true;
    const gameViewEl = byId('game-view');
    if (gameViewEl) gameViewEl.style.display = 'block';
    const mainMenuEl = byId('main-menu');
    if (mainMenuEl) mainMenuEl.style.display = 'none';
    const battleScreen = byId('battle-screen');
    if (battleScreen) battleScreen.style.display = 'none';
    const resultScreen = byId('battle-result-screen');
    if (resultScreen) resultScreen.style.display = 'none';
    const modeSelection = byId('game-mode-selection');
    if (modeSelection) modeSelection.style.display = 'none';
    if (refs.panel) refs.panel.style.display = 'block';
    renderFloorStrip();
    renderMyRankingPreview();
    renderTeamPreview();
    renderTeamPowersPreview();
    renderRunStatus();
    updateStartRunButton();

    hydrateSelectedPowersFromInventory()
      .then(() => renderTeamPowersPreview())
      .catch(() => {});

    hydrateSelectedCardsFromInventory()
      .then(() => renderTeamPreview())
      .catch(() => {});

    if (window.DiscordPresence) {
      window.DiscordPresence.setInfinite(state.currentFloor);
    }
  }

  function closePanel(showModeSelection = true) {
    state.panelOpen = false;
    if (refs.panel) refs.panel.style.display = 'none';
    const teamBuilder = byId('team-builder');
    if (teamBuilder && state.selectingTeam) teamBuilder.style.display = 'none';
    const modeSelection = byId('game-mode-selection');
    if (showModeSelection && modeSelection) modeSelection.style.display = 'block';
    state.selectingTeam = false;
    closeInitialPicker();
    closeDecisionModal();
    closePlayConfirmModal();

    if (window.DiscordPresence && showModeSelection) {
      window.DiscordPresence.setMenu();
    }
    closeModifiersCatalogModal();
    if (refs.upgradeRollModal) refs.upgradeRollModal.style.display = 'none';
    restoreTeamBuilderPoolIfNeeded();
  }

  function hardHidePanel() {
    state.panelOpen = false;
    if (refs.panel) refs.panel.style.display = 'none';
    state.selectingTeam = false;
    closeInitialPicker();
    closeDecisionModal();
    closePlayConfirmModal();
    closeModifiersCatalogModal();
    if (refs.upgradeRollModal) refs.upgradeRollModal.style.display = 'none';
    restoreTeamBuilderPoolIfNeeded();
  }

  function wireGlobalNavigationGuards() {
    const modeClassicBtn = byId('mode-clasico-btn');
    modeClassicBtn?.addEventListener('click', () => hardHidePanel());

    if (typeof window.returnToMainMenu === 'function') {
      const original = window.returnToMainMenu;
      window.returnToMainMenu = function () {
        hardHidePanel();
        return original.apply(this, arguments);
      };
    }

    if (typeof window.backToModeSelection === 'function') {
      const original = window.backToModeSelection;
      window.backToModeSelection = function () {
        hardHidePanel();
        return original.apply(this, arguments);
      };
    }

    if (typeof window.backToDifficultySelection === 'function') {
      const original = window.backToDifficultySelection;
      window.backToDifficultySelection = function () {
        if (state.selectingTeam || window.isInfiniteModeTeamBuilding) {
          const teamBuilder = byId('team-builder');
          if (teamBuilder) teamBuilder.style.display = 'none';
          if (refs.panel) refs.panel.style.display = 'block';
          state.panelOpen = true;
          state.selectingTeam = false;
          window.isInfiniteModeTeamBuilding = false;
          restoreTeamBuilderPoolIfNeeded();
          if (typeof window.updateTeamBuilderModeUI === 'function') {
            window.updateTeamBuilderModeUI();
          }
          renderFloorStrip();
          renderMyRankingPreview();
          renderTeamPreview();
          renderTeamPowersPreview();
          renderRunStatus();
          updateStartRunButton();
          return;
        }

        return original.apply(this, arguments);
      };
    }
  }

  function wireTeamContinueOverride() {
    if (typeof window.validateTeamAndContinue !== 'function') return;
    if (window.__infiniteOverrideApplied) return;

    const originalValidate = window.validateTeamAndContinue;

    window.validateTeamAndContinue = function () {
      if (!state.selectingTeam && !window.isInfiniteModeTeamBuilding) {
        return originalValidate.apply(this, arguments);
      }

      if (!validateInfiniteTeam()) return;

      const confirmed = confirm('¿Confirmar este equipo para el Modo Infinito?');
      if (!confirmed) return;

      markTeamAsLocked();
      alert('Equipo confirmado para Modo Infinito.');

      const teamBuilder = byId('team-builder');
      if (teamBuilder) teamBuilder.style.display = 'none';
      if (refs.panel) refs.panel.style.display = 'block';
      state.panelOpen = true;
      state.selectingTeam = false;
      window.isInfiniteModeTeamBuilding = false;
      restoreTeamBuilderPoolIfNeeded();
      if (typeof window.updateTeamBuilderModeUI === 'function') {
        window.updateTeamBuilderModeUI();
      }
      renderFloorStrip();
      renderMyRankingPreview();
      renderTeamPreview();
      renderTeamPowersPreview();
      renderRunStatus();
      updateStartRunButton();
    };

    window.__infiniteOverrideApplied = true;
  }

  function wireEvents() {
    refs.backBtn?.addEventListener('click', closePanel);
    refs.openRewardsBtn?.addEventListener('click', openSeasonRewardsModal);
    refs.closeRewardsBtn?.addEventListener('click', closeSeasonRewardsModal);
    refs.dismissRewardsBtn?.addEventListener('click', closeSeasonRewardsModal);
    refs.rewardsModal?.addEventListener('click', (e) => {
      if (e.target === refs.rewardsModal) {
        closeSeasonRewardsModal();
      }
    });
    refs.openRankingsBtn?.addEventListener('click', openRankingsModal);
    refs.openModifiersBtn?.addEventListener('click', openModifiersCatalogModal);
    refs.closeModifiersBtn?.addEventListener('click', closeModifiersCatalogModal);
    refs.dismissModifiersBtn?.addEventListener('click', closeModifiersCatalogModal);
    refs.modifiersModal?.addEventListener('click', (e) => {
      if (e.target === refs.modifiersModal) {
        closeModifiersCatalogModal();
      }
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && refs.modifiersModal && refs.modifiersModal.style.display === 'flex') {
        closeModifiersCatalogModal();
      }
      if (e.key === 'Escape' && refs.rewardsModal && refs.rewardsModal.style.display === 'flex') {
        closeSeasonRewardsModal();
      }
    });
    refs.selectTeamBtn?.addEventListener('click', openTeamBuilderForInfinite);
    refs.resetRunBtn?.addEventListener('click', resetInfiniteRunState);
    refs.cancelPickBtn?.addEventListener('click', closeInitialPicker);
    refs.confirmPickBtn?.addEventListener('click', () => {
      if (state.selectedInitialCards.length !== 8) {
        alert('Debes seleccionar exactamente 8 cartas.');
        return;
      }
      if (state.selectedInitialPowers.length !== 3) {
        alert('Debes seleccionar exactamente 3 poderes.');
        return;
      }

      const confirmed = confirm('Estas 8 cartas y 3 poderes quedaran bloqueados como base del equipo inicial. ¿Continuar?');
      if (!confirmed) return;

      window.selectedTeam = state.selectedInitialCards.map((c) => c.uniqueId || c.id);
      window.selectedTeamPowers = state.selectedInitialPowers.map((p) => (typeof p === 'string' ? p : p?.id)).filter(Boolean);
      markTeamAsLocked();
      closeInitialPicker();
      alert('Equipo inicial bloqueado correctamente. Ahora puedes usar Modificar equipo.');
    });

    refs.startRunBtn?.addEventListener('click', startRun);
    refs.completeFloorBtn?.addEventListener('click', completeCurrentFloor);
    refs.playConfirmCancel?.addEventListener('click', closePlayConfirmModal);
    refs.playConfirmAccept?.addEventListener('click', () => {
      closePlayConfirmModal();
      startInfiniteBattleFromCurrentFloor();
    });

    refs.upgradeBackBtn?.addEventListener('click', () => {
      if (state.upgradeInProgress) return;
      if (refs.upgradeCardPicker) refs.upgradeCardPicker.style.display = 'none';
      if (refs.upgradeCardGrid) refs.upgradeCardGrid.innerHTML = '';
      if (refs.upgradeFlow) refs.upgradeFlow.style.display = 'none';
      if (refs.decisionMainOptions) refs.decisionMainOptions.style.display = 'grid';
    });

    refs.addCardBackBtn?.addEventListener('click', () => {
      if (refs.addCardFlow) refs.addCardFlow.style.display = 'none';
      if (refs.addCardGrid) refs.addCardGrid.innerHTML = '';
      if (refs.decisionMainOptions) refs.decisionMainOptions.style.display = 'grid';
    });

    refs.shopBackBtn?.addEventListener('click', () => {
      if (shouldConsumeDecisionOnShopClose()) {
        const confirmed = askConfirmConsumeDecisionOnShopClose();
        if (!confirmed) return;
        closeShopFlowAndConsumeDecisionNode();
        return;
      }

      closeShopFlowToDecisionOptions();
    });

    refs.upgradeModeRandom?.addEventListener('click', async () => {
      await executeUpgradeChoice({ mode: 'random', minPercent: 6, maxPercent: 10 });
    });

    refs.upgradeModeTarget?.addEventListener('click', () => {
      if (state.upgradeInProgress) return;
      renderUpgradeCardPicker();
    });

    refs.decisionCancel?.addEventListener('click', () => {
      const shopOpen = refs.shopFlow && refs.shopFlow.style.display === 'block';
      if (shopOpen) {
        if (shouldConsumeDecisionOnShopClose()) {
          const confirmed = askConfirmConsumeDecisionOnShopClose();
          if (!confirmed) return;
          closeShopFlowAndConsumeDecisionNode();
          return;
        }

        closeShopFlowToDecisionOptions();
        return;
      }

      closeDecisionModal();
    });
    refs.decisionButtons.forEach((btn) => {
      btn.addEventListener('click', () => {
        const choice = btn.dataset.choice;
        applyDecisionChoice(choice);
      });
    });
  }

  function initRefs() {
    refs.panel = byId('infinite-mode-panel');
    refs.floorStrip = byId('infinite-floor-strip');
    refs.floorMeta = byId('infinite-floor-meta');
    refs.themeName = byId('infinite-theme-name');
    refs.titleLocation = byId('infinite-title-location');
    refs.myRanking = byId('infinite-my-ranking');
    refs.seasonName = byId('infinite-season-name');
    refs.scoreFormula = byId('infinite-score-formula');
    refs.seasonTop = byId('infinite-season-top');
    refs.seasonSelf = byId('infinite-season-self');
    refs.historicalSelf = byId('infinite-historical-self');
    refs.teamStatus = byId('infinite-team-status');
    refs.teamPreview = byId('infinite-team-preview');
    refs.teamPowersPreview = byId('infinite-team-powers-preview');
    refs.initialPicker = byId('infinite-initial-picker');
    refs.initialInventory = byId('infinite-initial-inventory');
    refs.initialPowersInventory = byId('infinite-initial-powers-inventory');
    refs.pickedStrip = byId('infinite-picked-strip');
    refs.pickedCount = byId('infinite-picked-count');
    refs.pickedPowersStrip = byId('infinite-picked-powers-strip');
    refs.pickedPowersCount = byId('infinite-picked-powers-count');
    refs.cancelPickBtn = byId('infinite-cancel-pick-btn');
    refs.confirmPickBtn = byId('infinite-confirm-pick-btn');
    refs.decisionModal = byId('infinite-decision-modal');
    refs.decisionTitle = byId('infinite-decision-title');
    refs.decisionDesc = byId('infinite-decision-desc');
    refs.decisionMainOptions = byId('infinite-decision-main-options');
    refs.decisionCancel = byId('infinite-decision-cancel');
    refs.decisionButtons = document.querySelectorAll('#infinite-decision-modal .infinite-decision-btn');
    refs.upgradeFlow = byId('infinite-upgrade-flow');
    refs.upgradeModeRandom = byId('infinite-upgrade-mode-random');
    refs.upgradeModeTarget = byId('infinite-upgrade-mode-target');
    refs.upgradeCardPicker = byId('infinite-upgrade-card-picker');
    refs.upgradeCardGrid = byId('infinite-upgrade-card-grid');
    refs.upgradeBackBtn = byId('infinite-upgrade-back-btn');
    refs.addCardFlow = byId('infinite-add-card-flow');
    refs.addCardGrid = byId('infinite-add-card-grid');
    refs.addCardBackBtn = byId('infinite-add-card-back-btn');
    refs.shopFlow = byId('infinite-shop-flow');
    refs.shopItemsGrid = byId('infinite-shop-items-grid');
    refs.shopBackBtn = byId('infinite-shop-back-btn');
    refs.shopItemPreviewModal = byId('infinite-shop-item-preview-modal');
    refs.shopkeeperImageBtn = byId('infinite-shopkeeper-image-btn');
    refs.shopkeeperImage = byId('infinite-shopkeeper-image');
    refs.shopDialogueBubble = byId('infinite-shop-dialogue-bubble');
    refs.shopDialogueText = byId('infinite-shop-dialogue-text');
    refs.upgradeRollModal = byId('infinite-upgrade-roll-modal');
    refs.upgradeRollCardName = byId('infinite-upgrade-roll-cardname');
    refs.upgradeRollCardImage = byId('infinite-upgrade-roll-cardimage');
    refs.upgradeRollPercent = byId('infinite-upgrade-roll-percent');
    refs.upgradeRollStat = byId('infinite-upgrade-roll-stat');
    refs.upgradeRollResult = byId('infinite-upgrade-roll-result');
    refs.backBtn = byId('infinite-back-btn');
    refs.openRewardsBtn = byId('infinite-open-rewards-btn');
    refs.rewardsModal = byId('infinite-season-rewards-modal');
    refs.rewardsCatalog = byId('infinite-season-rewards-catalog');
    refs.closeRewardsBtn = byId('infinite-close-rewards-btn');
    refs.dismissRewardsBtn = byId('infinite-dismiss-rewards-btn');
    refs.openRankingsBtn = byId('infinite-open-rankings-btn');
    refs.openModifiersBtn = byId('infinite-open-modifiers-btn');
    refs.modifiersModal = byId('infinite-modifiers-modal');
    refs.closeModifiersBtn = byId('infinite-close-modifiers-btn');
    refs.dismissModifiersBtn = byId('infinite-dismiss-modifiers-btn');
    refs.modifiersCatalog = byId('infinite-modifiers-catalog');
    refs.selectTeamBtn = byId('infinite-select-team-btn');
    refs.startRunBtn = byId('infinite-start-run-btn');
    refs.completeFloorBtn = byId('infinite-complete-floor-btn');
    refs.resetRunBtn = byId('infinite-reset-run-btn');
    refs.playConfirmModal = byId('infinite-play-confirm-modal');
    refs.playConfirmDesc = byId('infinite-play-confirm-desc');
    refs.playConfirmCancel = byId('infinite-play-confirm-cancel');
    refs.playConfirmAccept = byId('infinite-play-confirm-accept');
    refs.consumablesContainer = byId('infinite-consumables-container');
    refs.buffAnimationModal = byId('infinite-buff-animation-modal');
    refs.buffAnimationTitle = byId('infinite-buff-animation-title');
    refs.buffAnimationContent = byId('infinite-buff-animation-content');
    refs.buffAnimationAcceptBtn = byId('infinite-buff-animation-accept-btn');
    refs.pergaminoModal = byId('infinite-pergamino-modal');
    refs.pergaminoTitle = byId('infinite-pergamino-title');
    refs.pergaminoSubtitle = byId('infinite-pergamino-subtitle');
    refs.pergaminoStepCards = byId('infinite-pergamino-step-cards');
    refs.pergaminoCardsGrid = byId('infinite-pergamino-cards-grid');
    refs.pergaminoStepStats = byId('infinite-pergamino-step-stats');
    refs.pergaminoCardPreview = byId('infinite-pergamino-selected-card-preview');
    refs.pergaminoStatsGrid = byId('infinite-pergamino-stats-grid');
    refs.pergaminoCancelBtn = byId('infinite-pergamino-cancel-btn');
    refs.chapaModal = byId('infinite-chapa-reward-modal');
    refs.chapaContent = byId('infinite-chapa-reward-content');
    refs.chapaAcceptBtn = byId('infinite-chapa-reward-accept-btn');
  }

  async function init() {
    initRefs();
    await restoreInfiniteRunState();
    await hydrateSelectedCardsFromInventory();
    await hydrateSelectedPowersFromInventory();
    setTimeout(() => {
      hydrateSelectedCardsFromInventory()
        .then(() => renderTeamPreview())
        .catch(() => {});
    }, 700);
    setTimeout(() => {
      hydrateSelectedPowersFromInventory()
        .then(() => renderTeamPowersPreview())
        .catch(() => {});
    }, 700);
    wireTeamContinueOverride();
    wireEvents();
    wireGlobalNavigationGuards();
    state.worldConfig = normalizeWorldConfig(FALLBACK_WORLD_CONFIG);
    renderFloorStrip();
    renderMyRankingPreview();
    renderTeamPreview();
    renderTeamPowersPreview();
    renderRunStatus();
    updateStartRunButton();

    loadInfiniteWorldConfig().then(() => {
      renderFloorStrip();
      if (state.panelOpen) {
        renderRunStatus();
      }
    });

    window.openInfiniteModePanel = openPanel;
    window.closeInfiniteModePanel = closePanel;
    window.infiniteReturnFromBattle = returnToInfinitePanelFromBattle;
    window.infiniteGoToNextFloorAndPlay = goToNextFloorAndPlayFromBattle;
    hardHidePanel();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
