function showBuyModal(pack, price, count = 1) {
  const qty = Math.max(1, parseInt(count, 10) || 1);
  buyCtx.packId = pack.id;
  buyCtx.qty = qty;
  buyCtx.unitPrice = { coins: Math.max(0, Number(price.coins)||0), kvr: Math.max(0, Number(price.kvr)||0) };
  buyCtx.price = { coins: buyCtx.unitPrice.coins * qty, kvr: buyCtx.unitPrice.kvr * qty };
  const pc = buyCtx.price.coins;
  const pk = buyCtx.price.kvr;
  buyTitle.textContent = `Comprar ${pack.name}${qty > 1 ? ` (x${qty})` : ''}`;

  const sobreText = qty === 1 ? '1 sobre' : `${qty} sobres`;

  if (pc > 0 && pk > 0) {
    buyMsg.innerHTML = `¿Estás seguro de que quieres comprar ${sobreText} por ${coinIcon(pc)} o por ${kvrIcon(pk)}?`;
    buyCoinsBtn.style.display = '';
    buyKvrBtn.style.display = '';
  } else if (pc > 0) {
    buyMsg.innerHTML = `¿Estás seguro de que quieres comprar ${sobreText} por ${coinIcon(pc)}?`;
    buyCoinsBtn.style.display = '';
    buyKvrBtn.style.display = 'none';
  } else if (pk > 0) {
    buyMsg.innerHTML = `¿Estás seguro de que quieres comprar ${sobreText} por ${kvrIcon(pk)}?`;
    buyCoinsBtn.style.display = 'none';
    buyKvrBtn.style.display = '';
  } else {
    buyMsg.textContent = qty === 1
      ? `Este sobre es gratis. ¿Quieres añadirlo a tu inventario?`
      : `Estos ${qty} sobres son gratis. ¿Quieres añadirlos a tu inventario?`;
    buyCoinsBtn.style.display = '';
    buyCoinsBtn.textContent = 'Confirmar';
    buyKvrBtn.style.display = 'none';
  }
  if (pc > 0) {
    buyCoinsBtn.innerHTML = `Pagar ${coinIcon(pc)}`;
  } else if (pk > 0) {
    buyCoinsBtn.textContent = 'Cancelar';
  } else {
    buyCoinsBtn.textContent = 'Confirmar';
  }
  buyKvrBtn.innerHTML = (pk > 0 ? `Pagar ${kvrIcon(pk)}` : '');
  buyModal?.classList.add('show');
}

async function confirmBuy(preferred) {
  const qty = Math.max(1, parseInt(buyCtx.qty, 10) || 1);
  const res = await window.kvrcards.buyPack(buyCtx.packId, preferred, qty);
  buyModal?.classList.remove('show');
  if (!res?.ok) { alert(res?.error || 'No se pudo comprar'); return; }
  await Promise.all([renderOwnedPacks(), renderShop(), renderWallet()]);
}

const PRESTIGE_XP_THRESHOLDS = [100, 500, 2000, 5000, 10000];
const REMOTE_PRESTIGE_CONFIG_URL = 'https://hugom1307.github.io/kvrcards-catalog/prestige-config.json';
const PRESTIGE_PROGRESS_STORAGE_KEY = 'kvrcards_prestige_progress_v1';
let prestigeConfigCache = null;

const defaultPrestigeConfig = {
  xpRules: {
    battlePlayed: 20,
    battleWinBonus: 10,
    duplicateFromPackOrTrade: 500
  },
  levels: [
    { prestige: 1, xpRequired: 100, rewards: [], missions: [] },
    { prestige: 2, xpRequired: 500, rewards: [], missions: [] },
    { prestige: 3, xpRequired: 2000, rewards: [], missions: [] },
    { prestige: 4, xpRequired: 5000, rewards: [], missions: [] },
    { prestige: 5, xpRequired: 10000, rewards: [], missions: [] }
  ]
};

async function renderShop() {
  if (!isElectron) return;
  const [packs, inv] = await Promise.all([
    window.kvrcards.getAllPacks(),
    window.kvrcards.getInventory(),
  ]);
  shopDiv.innerHTML = '';
  const visiblePacks = Array.isArray(packs)
    ? [...packs]
        .filter(pack => pack && pack.shopVisible !== false)
        .sort((a, b) => {
          const orderA = Number.isFinite(Number(a?.shopOrder)) ? Number(a.shopOrder) : Number.MAX_SAFE_INTEGER;
          const orderB = Number.isFinite(Number(b?.shopOrder)) ? Number(b.shopOrder) : Number.MAX_SAFE_INTEGER;
          if (orderA !== orderB) return orderA - orderB;
          return String(a?.name || '').localeCompare(String(b?.name || ''), 'es');
        })
    : [];

  for (const pack of visiblePacks) {
    const currentStock = pack.stock;
    // Filtrar sobres sin stock
    if (currentStock !== undefined && currentStock !== null && currentStock <= 0) {
      continue; // Omitir sobres agotados
    }
    
    const row = document.createElement('div');
    const label = document.createElement('span');
    const count = (inv.ok && inv.packs[pack.id]) || 0;
    
    // thumbnail con badge de stock (igual que en Mis sobres)
    const thumb = document.createElement('div');
    thumb.className = 'pack-thumb';
    const pImg = document.createElement('img');
    pImg.style.width = '120px';
    pImg.style.height = 'auto';
    pImg.style.display = 'block';
    pImg.style.marginBottom = '6px';
    pImg.style.cursor = 'pointer';
    pImg.title = 'Ver detalles del sobre';
    const pPlaceholder = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="120" height="160"><rect width="100%" height="100%" fill="#1f2937"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#9ca3af" font-family="Arial" font-size="12">Sobre</text></svg>');
    pImg.onerror = () => { if (pImg.src !== pPlaceholder) pImg.src = pPlaceholder; };
    pImg.src = (typeof normalizeAssetUrl === 'function' ? normalizeAssetUrl(pack.imageUrl) : pack.imageUrl) || pPlaceholder;
    pImg.addEventListener('click', () => showPackDetails(pack.id));
    thumb.appendChild(pImg);
    
    // Añadir contador de stock si existe
    if (currentStock !== undefined && currentStock !== null && currentStock > 0) {
      const badge = document.createElement('span');
      badge.className = 'count-badge';
      badge.textContent = String(currentStock);
      thumb.appendChild(badge);
    }
    
    // En tienda no mostramos "tienes xN"
    label.textContent = `${pack.name}`;
    const limits = typeof window.getPackMediaLimits === 'function' ? window.getPackMediaLimits(pack) : { minMedia: pack.minMedia, maxMedia: pack.maxMedia };
    if (limits && (limits.minMedia !== null || limits.maxMedia !== null)) {
      const mediaBadge = document.createElement('span');
      mediaBadge.className = 'pack-media-badge';
      mediaBadge.style.cssText = 'display: inline-block; margin-left: 6px; font-size: 11px; font-weight: 700; color: #fbbf24; background: rgba(251, 191, 36, 0.15); border: 1px solid rgba(251, 191, 36, 0.35); border-radius: 4px; padding: 1px 5px; vertical-align: middle;';
      if (limits.minMedia !== null && limits.maxMedia !== null) {
        mediaBadge.textContent = `${limits.minMedia}-${limits.maxMedia}`;
      } else if (limits.minMedia !== null) {
        mediaBadge.textContent = `+${limits.minMedia}`;
      } else {
        mediaBadge.textContent = `≤${limits.maxMedia}`;
      }
      label.appendChild(mediaBadge);
    }
    // Precio
    const price = pack.price || { coins: 0, kvr: 0 };
    const priceEl = document.createElement('div');
    priceEl.style.opacity = '0.92';
    priceEl.style.fontSize = '14px';
    priceEl.className = 'price-line';
  const parts = [];
    if ((price.coins||0) > 0) parts.push(coinIcon(price.coins));
    if ((price.kvr||0) > 0) parts.push(kvrIcon(price.kvr));
    priceEl.innerHTML = parts.join(' <span class="cur-sep">o</span> ') || 'Gratis';
    const isLimited = (currentStock !== undefined && currentStock !== null);
    const maxStock = isLimited ? Math.max(1, Number(currentStock)) : null;

    const actionsDiv = document.createElement('div');
    actionsDiv.className = 'pack-buy-actions';

    const buyBtn = document.createElement('button');
    buyBtn.className = 'btn-buy';
    buyBtn.textContent = 'Comprar';

    const qtyInput = document.createElement('input');
    qtyInput.type = 'number';
    qtyInput.className = 'pack-buy-qty-input';
    qtyInput.min = '1';
    qtyInput.value = '1';
    if (isLimited) {
      qtyInput.max = String(maxStock);
      qtyInput.title = `Stock disponible: ${maxStock}`;
    }

    const validateAndClampQty = () => {
      let val = parseInt(qtyInput.value, 10);
      if (isNaN(val) || val < 1) {
        val = 1;
      } else if (isLimited && val > maxStock) {
        val = maxStock;
      }
      qtyInput.value = val;
      return val;
    };

    qtyInput.addEventListener('input', () => {
      let val = parseInt(qtyInput.value, 10);
      if (isLimited && !isNaN(val) && val > maxStock) {
        qtyInput.value = maxStock;
      }
    });

    qtyInput.addEventListener('change', () => {
      validateAndClampQty();
    });

    qtyInput.addEventListener('blur', () => {
      validateAndClampQty();
    });

    qtyInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        buyBtn.click();
      }
    });

    buyBtn.addEventListener('click', async () => {
      const finalCount = validateAndClampQty();
      const price = pack.price || { coins: 0, kvr: 0 };
      showBuyModal(pack, price, finalCount);
    });

    actionsDiv.appendChild(buyBtn);
    actionsDiv.appendChild(qtyInput);

    row.appendChild(thumb);
    row.appendChild(label);
    row.appendChild(priceEl);
    row.appendChild(actionsDiv);
    shopDiv.appendChild(row);
  }
}

// ==================== MODAL DE OFERTA DE BIENVENIDA ====================

async function refreshKnightSupporterTitle() {
  const el = document.getElementById('welcome-supporter-title');
  if (!el) return;

  let titleObj = null;

  // 1. Intentar obtener de títulos locales/en memoria
  if (typeof window.getTitleDetails === 'function') {
    titleObj = window.getTitleDetails('knight_supporter');
  }

  // 2. Consultar siempre el remoto de GitHub para asegurar la última descripción
  try {
    const res = await fetch(`https://hugom1307.github.io/kvrcards-catalog/titles.json?t=${Date.now()}`);
    if (res.ok) {
      const list = await res.json();
      if (Array.isArray(list)) {
        // Actualizar window.availableTitles si procede
        if (Array.isArray(window.availableTitles)) {
          list.forEach(item => {
            const idx = window.availableTitles.findIndex(t => t.id === item.id);
            if (idx >= 0) window.availableTitles[idx] = item;
            else window.availableTitles.push(item);
          });
        } else {
          window.availableTitles = list;
        }

        const found = list.find(t => 
          String(t.id).toLowerCase() === 'knight_supporter' || 
          String(t.name || '').toLowerCase() === 'knight supporter'
        );
        if (found) titleObj = found;
      }
    }
  } catch (err) {
    console.warn('[SHOP] Error obteniendo títulos remotos para knight_supporter:', err);
  }

  // 3. Aplicar datos y estilo al elemento
  if (titleObj) {
    el.textContent = titleObj.name || 'KNIGHT SUPPORTER';
    el.setAttribute('data-title-id', titleObj.id || 'knight_supporter');
    el.setAttribute('data-title-name', titleObj.name || 'KNIGHT SUPPORTER');
    el.setAttribute('data-title-desc', titleObj.description || titleObj.desc || '');
    if (titleObj.gradient) {
      el.setAttribute('data-title-gradient', titleObj.gradient);
      if (typeof window.applyTitleStyle === 'function') {
        window.applyTitleStyle(el, titleObj.id);
      }
    }
  } else {
    // Fallback descriptivo si no hay conexión o aún no está en el remoto
    el.setAttribute('data-title-id', 'knight_supporter');
    el.setAttribute('data-title-name', 'KNIGHT SUPPORTER');
    if (!el.getAttribute('data-title-desc')) {
      el.setAttribute('data-title-desc', 'Título exclusivo por apoyar al desarrollo del juego con la Oferta de Bienvenida.');
    }
  }
}

function initWelcomeOfferModal() {
  const modal = document.getElementById('welcome-offer-modal');
  const openBtn = document.getElementById('btn-pago-oferta');
  const closeBtn = document.getElementById('welcome-offer-close');
  const okBtn = document.getElementById('welcome-offer-ok-btn');

  if (openBtn) {
    openBtn.addEventListener('click', () => {
      modal?.classList.add('show');
      refreshKnightSupporterTitle();
    });
  }

  const closeModal = () => modal?.classList.remove('show');
  closeBtn?.addEventListener('click', closeModal);
  okBtn?.addEventListener('click', closeModal);

  modal?.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  // Pre-cargar datos del título al inicio
  refreshKnightSupporterTitle();
}

function initSupporterBlessingModal() {
  const modal = document.getElementById('supporter-blessing-modal');
  const openBtn = document.getElementById('btn-pago-suscripcion');
  const closeBtn = document.getElementById('supporter-blessing-close');
  const okBtn = document.getElementById('supporter-blessing-ok-btn');

  if (openBtn) {
    openBtn.addEventListener('click', () => {
      modal?.classList.add('show');
    });
  }

  const closeModal = () => modal?.classList.remove('show');
  closeBtn?.addEventListener('click', closeModal);
  okBtn?.addEventListener('click', closeModal);

  modal?.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });
}

function initShopPaymentModals() {
  initWelcomeOfferModal();
  initSupporterBlessingModal();
  initKvrBundleModals();
}

const KVR_BUNDLES_CONFIG = {
  '1euro': {
    title: '100 KVR',
    totalKvr: 100,
    price: '0.99€',
    baseKvr: 100,
    bonusKvr: 0,
  },
  '3euro': {
    title: '330 KVR',
    totalKvr: 330,
    price: '2.99€',
    baseKvr: 300,
    bonusKvr: 30,
  },
  '5euro': {
    title: '600 KVR',
    totalKvr: 600,
    price: '4.99€',
    baseKvr: 500,
    bonusKvr: 100,
  },
  '10euro': {
    title: '1350 KVR',
    totalKvr: 1350,
    price: '9.99€',
    baseKvr: 1000,
    bonusKvr: 350,
  },
  '20euro': {
    title: '3000 KVR',
    totalKvr: 3000,
    price: '19.99€',
    baseKvr: 2000,
    bonusKvr: 1000,
  }
};

function openKvrBundleModal(bundleKey) {
  const cfg = KVR_BUNDLES_CONFIG[bundleKey];
  if (!cfg) return;

  const modal = document.getElementById('kvr-bundle-modal');
  const titleEl = document.getElementById('kvr-bundle-title');
  const priceIntroEl = document.getElementById('kvr-bundle-price-intro');
  const instantEl = document.getElementById('kvr-bundle-instant');
  const bonusBox = document.getElementById('kvr-bundle-bonus-box');
  const bonusText = document.getElementById('kvr-bundle-bonus-text');
  const bizumPriceEl = document.getElementById('kvr-bundle-bizum-price');

  if (titleEl) titleEl.textContent = cfg.title;
  if (priceIntroEl) priceIntroEl.textContent = cfg.price;
  if (instantEl) instantEl.textContent = `${cfg.totalKvr} KVR`;
  if (bizumPriceEl) bizumPriceEl.textContent = cfg.price;

  if (bonusBox && bonusText) {
    if (cfg.bonusKvr > 0) {
      bonusText.textContent = `${cfg.baseKvr} + ${cfg.bonusKvr} KVR de bonificacion!`;
      bonusBox.style.display = 'block';
    } else {
      bonusBox.style.display = 'none';
    }
  }

  modal?.classList.add('show');
}

function initKvrBundleModals() {
  const modal = document.getElementById('kvr-bundle-modal');
  const closeBtn = document.getElementById('kvr-bundle-close');
  const okBtn = document.getElementById('kvr-bundle-ok-btn');

  const bundleKeys = ['1euro', '3euro', '5euro', '10euro', '20euro'];
  bundleKeys.forEach(key => {
    const btn = document.getElementById(`btn-pago-${key}`);
    if (btn) {
      btn.addEventListener('click', () => openKvrBundleModal(key));
    }
  });

  const closeModal = () => modal?.classList.remove('show');
  closeBtn?.addEventListener('click', closeModal);
  okBtn?.addEventListener('click', closeModal);

  modal?.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });
}

window.toggleShopInfo = function(e) {
  if (e) {
    if (typeof e.preventDefault === 'function') e.preventDefault();
    if (typeof e.stopPropagation === 'function') e.stopPropagation();
  }
  const panel = document.getElementById('shop-info-panel');
  const btn = document.getElementById('shop-info-toggle-btn');
  if (!panel) return;

  const now = Date.now();
  if (window.__lastShopInfoToggle && (now - window.__lastShopInfoToggle < 200)) {
    return;
  }
  window.__lastShopInfoToggle = now;

  const isHidden = panel.style.display === 'none' || !panel.style.display;
  if (isHidden) {
    panel.style.display = 'block';
    if (btn) btn.classList.add('active');
  } else {
    panel.style.display = 'none';
    if (btn) btn.classList.remove('active');
  }
};

function setupShopInfoToggle() {
  const btn = document.getElementById('shop-info-toggle-btn');
  if (btn && !btn.__shopInfoBound) {
    btn.__shopInfoBound = true;
    btn.addEventListener('click', window.toggleShopInfo);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    initShopPaymentModals();
    setupShopInfoToggle();
  });
} else {
  initShopPaymentModals();
  setupShopInfoToggle();
}

