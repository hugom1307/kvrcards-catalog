async function renderBattlePowers(playerPowers, opponentPowers) {
  console.log('[BATTLE] Renderizando poderes del jugador:', playerPowers);
  console.log('[BATTLE] Renderizando poderes del oponente:', opponentPowers);
  
  if (typeof window.availablePowers === 'undefined') {
    window.availablePowers = [];
  }
  let availablePowers = window.availablePowers;

  // Cargar poderes desde el JSON si no están cargados
  if (!availablePowers || availablePowers.length === 0) {
    try {
      if (typeof window.kvrcards !== 'undefined' && typeof window.kvrcards.getAllPowers === 'function') {
        const allPowers = await window.kvrcards.getAllPowers();
        if (Array.isArray(allPowers)) {
          availablePowers = allPowers;
          window.availablePowers = allPowers;
          console.log('[BATTLE] Poderes cargados desde backend Electron:', availablePowers);
        }
      } else {
        // Fallback para versión web: cargar desde GitHub remoto
        console.log('[BATTLE] Cargando poderes desde GitHub remoto...');
        const response = await fetch('https://hugom1307.github.io/kvrcards-catalog/powers.json');
        if (response.ok) {
          const allPowers = await response.json();
          if (Array.isArray(allPowers)) {
            availablePowers = allPowers;
            window.availablePowers = allPowers;
            console.log('[BATTLE] Poderes cargados desde GitHub remoto:', availablePowers);
          }
        }
      }
    } catch (error) {
      console.error('[BATTLE] Error cargando poderes:', error);
    }
  }
  
  // Mapeo de IDs del JSON a nombres internos del código (con soporte cruzado para flujos de Draft)
  const powerIdMap = {
    'reserva': 'swap',
    'reserve_card': 'swap',
    'swap': 'swap',
    'powerup': 'powerup',
    'power_up': 'powerup',
    'nerf': 'nerf',
    'anulo': 'anulo',
    'intercambio': 'intercambio'
  };
  
  // Mapeo de pesos para forzar el orden lógico del DOM: Reserva (1) -> Powerup (2) -> Nerf (3)
  const powerWeights = {
    'swap': 1,
    'reserva': 1,
    'reserve_card': 1,
    'powerup': 2,
    'power_up': 2,
    'nerf': 3,
    'anulo': 4,
    'intercambio': 5
  };

  // Renderizar poderes del jugador
  const playerContainer = document.getElementById('battle-player-powers');
  if (playerContainer) {
    playerContainer.innerHTML = '';
    const validPlayerPowers = playerPowers
      .filter(p => p !== null && p !== undefined)
      .sort((a, b) => (powerWeights[a] || 99) - (powerWeights[b] || 99));
    console.log('[BATTLE] Poderes ordenados y válidos del jugador:', validPlayerPowers);
    
    validPlayerPowers.forEach((powerId, index) => {
      const isSwapPower = ['swap', 'reserva', 'reserve_card'].includes(powerId);
      const isPowerUpPower = ['powerup', 'power_up'].includes(powerId);
      const isNerfPower = ['nerf'].includes(powerId);
      const isAnuloPower = ['anulo'].includes(powerId);
      const isIntercambioPower = ['intercambio'].includes(powerId);

      const power = availablePowers.find(p => {
        if (isSwapPower) return ['swap', 'reserva', 'reserve_card'].includes(p.id);
        if (isPowerUpPower) return ['powerup', 'power_up'].includes(p.id);
        if (isNerfPower) return p.id === 'nerf';
        if (isAnuloPower) return p.id === 'anulo';
        if (isIntercambioPower) return p.id === 'intercambio';
        return p.id === powerId;
      });

      if (power && power.imageUrl) {
        const internalName = powerIdMap[power.id] || powerId;
        const btn = document.createElement('button');
        btn.id = `player-power-${internalName}`;
        btn.className = 'battle-power-btn';
        btn.dataset.power = power.id;
        btn.title = power.name;
        btn.innerHTML = `<img src="${power.imageUrl}" alt="${power.name}" onerror="console.error('[BATTLE] Error cargando imagen:', '${power.imageUrl}')" />`;
        playerContainer.appendChild(btn);
        console.log(`[BATTLE] Poder jugador renderizado:`, powerId, 'como', internalName, power.imageUrl);
      } else {
        console.warn(`[BATTLE] No se encontró poder o imagen para:`, powerId);
      }
    });
  }
  
  // Renderizar poderes del oponente
  const opponentContainer = document.getElementById('battle-opponent-powers');
  if (opponentContainer) {
    opponentContainer.innerHTML = '';
    const validOpponentPowers = opponentPowers
      .filter(p => p !== null && p !== undefined)
      .sort((a, b) => (powerWeights[a] || 99) - (powerWeights[b] || 99));
    console.log('[BATTLE] Poderes ordenados y válidos del oponente:', validOpponentPowers);
    
    validOpponentPowers.forEach((powerId, index) => {
      const isSwapPower = ['swap', 'reserva', 'reserve_card'].includes(powerId);
      const isPowerUpPower = ['powerup', 'power_up'].includes(powerId);
      const isNerfPower = ['nerf'].includes(powerId);
      const isAnuloPower = ['anulo'].includes(powerId);
      const isIntercambioPower = ['intercambio'].includes(powerId);

      const power = availablePowers.find(p => {
        if (isSwapPower) return ['swap', 'reserva', 'reserve_card'].includes(p.id);
        if (isPowerUpPower) return ['powerup', 'power_up'].includes(p.id);
        if (isNerfPower) return p.id === 'nerf';
        if (isAnuloPower) return p.id === 'anulo';
        if (isIntercambioPower) return p.id === 'intercambio';
        return p.id === powerId;
      });

      if (power && power.imageUrl) {
        const internalName = powerIdMap[power.id] || powerId;
        const btn = document.createElement('button');
        btn.id = `opponent-power-${internalName}`;
        btn.className = 'battle-power-btn';
        btn.dataset.power = power.id;
        btn.title = power.name;
        btn.innerHTML = `<img src="${power.imageUrl}" alt="${power.name}" onerror="console.error('[BATTLE] Error cargando imagen:', '${power.imageUrl}')" />`;
        opponentContainer.appendChild(btn);
        console.log(`[BATTLE] Poder oponente renderizado:`, powerId, 'como', internalName, power.imageUrl);
      } else {
        console.warn(`[BATTLE] No se encontró poder o imagen para:`, powerId);
      }
    });
  }
  
  // CRÍTICO: Restaurar estado visual '.used' de poderes ya utilizados
  // Esto es necesario porque renderBattlePowers se llama cada ronda y recrea los botones
  if (window.battleState) {
    const playerPowersUsed = window.battleState.playerPowersUsed || {};
    const opponentPowersUsed = window.battleState.opponentPowersUsed || {};
    
    // Restaurar estado de poderes del jugador
    if (playerPowersUsed.swap) {
      const swapBtn = document.getElementById('player-power-swap');
      if (swapBtn) swapBtn.classList.add('used');
    }
    if (playerPowersUsed.powerup) {
      const powerUpBtn = document.getElementById('player-power-powerup');
      if (powerUpBtn) powerUpBtn.classList.add('used');
    }
    if (playerPowersUsed.nerf) {
      const nerfBtn = document.getElementById('player-power-nerf');
      if (nerfBtn) nerfBtn.classList.add('used');
    }
    if (playerPowersUsed.anulo) {
      const anuloBtn = document.getElementById('player-power-anulo');
      if (anuloBtn) anuloBtn.classList.add('used');
    }
    if (playerPowersUsed.intercambio) {
      const intercambioBtn = document.getElementById('player-power-intercambio');
      if (intercambioBtn) intercambioBtn.classList.add('used');
    }
    
    // Restaurar estado de poderes del oponente
    if (opponentPowersUsed.swap) {
      const swapBtn = document.getElementById('opponent-power-swap');
      if (swapBtn) swapBtn.classList.add('used');
    }
    if (opponentPowersUsed.powerup) {
      const powerUpBtn = document.getElementById('opponent-power-powerup');
      if (powerUpBtn) powerUpBtn.classList.add('used');
    }
    if (opponentPowersUsed.nerf) {
      const nerfBtn = document.getElementById('opponent-power-nerf');
      if (nerfBtn) nerfBtn.classList.add('used');
    }
    if (opponentPowersUsed.anulo) {
      const anuloBtn = document.getElementById('opponent-power-anulo');
      if (anuloBtn) anuloBtn.classList.add('used');
    }
    if (opponentPowersUsed.intercambio) {
      const intercambioBtn = document.getElementById('opponent-power-intercambio');
      if (intercambioBtn) intercambioBtn.classList.add('used');
    }
    
    console.log('[BATTLE] Estado visual de poderes restaurado - Player:', playerPowersUsed, 'Opponent:', opponentPowersUsed);
  }
}

async function startBattle(playerTeam, playerReserveCard) {
  console.log('[BATTLE] Iniciando batalla con equipo:', playerTeam);
  console.log('[BATTLE] Carta de reserva:', playerReserveCard);
  console.log('[BATTLE] Poderes seleccionados del equipo:', window.selectedTeamPowers);
  
  const currentMode = window.selectedGameMode || 'clasico7v7';

  // CRÍTICO: Limpieza exhaustiva de cualquier estado residual previo
  if (typeof window.cleanUpBattleCompletely === 'function') {
    window.cleanUpBattleCompletely({
      playerTeam: playerTeam,
      playerReserveCard: playerReserveCard,
      difficulty: window.selectedDifficulty,
      gameMode: currentMode,
      preserveTeam: true
    });
  }

  // Guardar poderes del jugador (filtrar nulls)
  const playerPowers = (window.selectedTeamPowers || []).filter(p => p !== null && p !== undefined && p !== '');
  window.battleState.playerPowers = playerPowers.length > 0 ? playerPowers : ['reserva', 'powerup', 'nerf'];
  window.battleState.opponentPowers = ['reserva', 'powerup', 'nerf'];
  window.battleState.difficulty = window.selectedDifficulty;
  window.battleState.gameMode = currentMode;
  window.battleState.isOnline = false;

  const isInfiniteBattle = (window.battleState.difficulty === 'inmo' || !!window.__infiniteBattleContext?.active);
  window.battleState.playerRoundsLostCount = 0;
  window.battleState.deseoBossBuffPercent = 0;
  window.battleState.infiniteModifier = isInfiniteBattle
    ? (window.__infiniteBattleContext?.modifier || null)
    : null;

  window.battleState.infiniteCardBuffs = window.__infiniteRunCardBuffs || (window.battleState && window.battleState.infiniteCardBuffs) || {};
  setBattlePrestigeEligibleCardIds();

  window.battleState.cardTraitsMap = cardTraitsMap || {};
  window.battleState.availableTraits = availableTraits || [];

  window.battleState.playerBuffs = calculateBattleBuffs(playerTeam);
  console.log('[BATTLE] Buffeos del jugador:', window.battleState.playerBuffs);

  // Generar equipo oponente según dificultad (asíncrono con carga remota de entrenadores)
  await generateOpponentTeam();
  
  // Asegurar que si el entrenador trajo poderes configurados en trainers.json, se respeten
  if (window.battleState.selectedTrainer) {
    if (!Array.isArray(window.battleState.opponentPowers) || window.battleState.opponentPowers.length === 0) {
      const rawTrainerPowers = window.battleState.selectedTrainer.poderes || window.battleState.selectedTrainer.powers;
      const resolver = (typeof resolveTrainerPowers === 'function') ? resolveTrainerPowers : window.resolveTrainerPowers;
      if (typeof resolver === 'function') {
        window.battleState.opponentPowers = resolver(rawTrainerPowers);
      } else {
        window.battleState.opponentPowers = ['reserva', 'powerup', 'nerf'];
      }
    }
    console.log('[BATTLE] ⚡ Poderes del entrenador oponente aplicados en inicio:', window.battleState.opponentPowers);
  }
  
  // Mostrar animación de inicio
  showBattleIntro();
}

// Mostrar animación de inicio
async function showBattleIntro() {
  console.log('[BATTLE] Mostrando intro de batalla');
  
  // Iniciar inmediatamente la música de intro de batalla (introbatalla.mp3)
  if (typeof playBattleIntroMusic === 'function') {
    playBattleIntroMusic();
  } else if (typeof window.playBattleIntroMusic === 'function') {
    window.playBattleIntroMusic();
  } else if (typeof playBackgroundMusic === 'function') {
    playBackgroundMusic('music/introbatalla.mp3', { volumeMultiplier: 0.85 });
  }

  // Ocultar team builder y game-view
  const teamBuilder = document.getElementById('team-builder');
  if (teamBuilder) teamBuilder.style.display = 'none';
  const gameView = document.getElementById('game-view');
  if (gameView) gameView.style.display = 'none';
  
  // Mostrar pantalla de intro
  const introScreen = document.getElementById('battle-intro');
  if (introScreen) introScreen.style.display = 'block';

  // Aplicar fondo de batalla personalizado del entrenador en la intro si existe
  const introBg = document.querySelector('.battle-intro-background');
  if (introBg) {
    const customBg = window.battleState?.opponentBackground;
    if (customBg && !window.battleState?.isOnline) {
      const cleanBg = String(customBg).replace(/^url\(["']?/, '').replace(/["']?\)$/, '');
      introBg.style.backgroundImage = `linear-gradient(135deg, rgba(26, 26, 46, 0.75) 0%, rgba(22, 33, 62, 0.65) 50%, rgba(15, 52, 96, 0.75) 100%), url("${cleanBg}")`;
      introBg.style.backgroundSize = 'cover';
      introBg.style.backgroundPosition = 'center';
    } else {
      introBg.style.backgroundImage = '';
      introBg.style.backgroundSize = '';
      introBg.style.backgroundPosition = '';
    }
  }
  
  // Obtener datos del usuario actual
  let username = 'Jugador';
  let avatar = 'https://api.dicebear.com/7.x/avataaars/svg?seed=default';
  
  try {
    if (isElectron) {
      // Usar getUserProfile() sin parámetros para obtener usuario actual
      const userResult = await window.kvrcards.getUserProfile();
      console.log('[BATTLE] Usuario obtenido:', userResult);
      
      if (userResult?.ok && userResult?.profile) {
        username = userResult.profile.username || username;
        avatar = userResult.profile.profileImage || avatar;
      } else if (userResult?.username) {
        // Formato alternativo directo
        username = userResult.username;
        avatar = userResult.profileImage || avatar;
      }
    }
  } catch (error) {
    console.error('[BATTLE] Error obteniendo usuario:', error);
  }
  
  console.log('[BATTLE] Usuario final:', username, 'Avatar:', avatar);
  
  // Mostrar perfil del jugador
  document.getElementById('battle-intro-avatar').src = avatar;
  document.getElementById('battle-intro-username').textContent = username;
  
  // Mostrar cartas del equipo con animación (solo las 7 principales, no la reserva)
  const cardsContainer = document.getElementById('battle-intro-cards');
  cardsContainer.innerHTML = '';
  
  const mainCardsForIntro = window.battleState.playerTeam.slice(0, 7);
  mainCardsForIntro.forEach((card, index) => {
    const cardDiv = document.createElement('div');
    cardDiv.className = 'battle-intro-card';
    cardDiv.dataset.cardId = card.id;
    
    const cardImg = document.createElement('img');
    // Probar múltiples propiedades de imagen
    cardImg.src = card.imageUrl || card.imagen || card.image || '';
    cardImg.alt = card.nombre || card.name || '';
    
    console.log('[BATTLE] Cargando imagen de carta:', card.name, '→', cardImg.src);
    
    cardDiv.appendChild(cardImg);
    cardsContainer.appendChild(cardDiv);
    
    // Añadir icono de trait si existe
    const cardKey = card.uniqueId || card.id;
    if (cardTraitsMap && cardTraitsMap[cardKey] && availableTraits && availableTraits.length > 0) {
      const trait = availableTraits.find(t => t.id === cardTraitsMap[cardKey]);
      if (trait) {
        const traitIcon = document.createElement('div');
        traitIcon.className = 'card-trait-icon';
        const traitImg = document.createElement('img');
        traitImg.src = trait.imageUrl;
        traitImg.alt = trait.name;
        traitImg.title = trait.name;
        traitIcon.appendChild(traitImg);
        cardDiv.appendChild(traitIcon);
      }
    }
    
    // Añadir evento click para elegir carta
    cardDiv.addEventListener('click', () => {
      selectFirstCard(card);
    });
  });
  
  // Mostrar instrucción después de que aparezcan todas las cartas
  setTimeout(() => {
    const el = document.getElementById('battle-intro-instruction');
    if (el) el.style.display = 'block';
  }, 2000);
}

// Seleccionar primera carta
function selectFirstCard(card) {
  console.log('[BATTLE] Primera carta seleccionada por jugador:', card.nombre || card.name);
  
  // Reproducir efecto de sonido de selección de carta
  playSFX('cardSelect');
  
  // Guardar carta del jugador
  window.battleState.playerCurrentCard = card;
  
  // Ocultar la instrucción y deshabilitar clicks en cartas
  const instruction = document.getElementById('battle-intro-instruction');
  
  // Verificar si es batalla online
  const isOnlineBattle = window.onlineState && window.onlineState.inBattle && window.onlineState.matchId;
  
  if (isOnlineBattle) {
    instruction.innerHTML = '<h1>⏳ Esperando a que tu rival elija...</h1>';
    
    // Encontrar el índice de la carta seleccionada en el equipo del jugador
    const cardIndex = window.battleState.playerTeam.findIndex(c => 
      (c.uniqueId || c.id) === (card.uniqueId || card.id)
    );
    console.log('[ONLINE-BATTLE] Carta seleccionada index:', cardIndex, 'de', window.battleState.playerTeam.length);
    
    // Emitir carta seleccionada al servidor CON EL ÍNDICE
    if (window.onlineState.socket && cardIndex >= 0) {
      window.onlineState.socket.emit('card-selected', {
        matchId: window.onlineState.matchId,
        cardIndex: cardIndex  // CRÍTICO: Enviar índice, no objeto completo
      });
      console.log('[ONLINE-BATTLE] 📤 card-selected enviado al servidor - índice:', cardIndex);
    } else {
      console.error('[ONLINE-BATTLE] ❌ Error: no se pudo encontrar índice de carta o no hay socket');
    }
  } else {
    const oppName = window.battleState?.opponentName || 'Tu rival';
    instruction.innerHTML = `<h1>⏳ ${oppName} está eligiendo su carta...</h1>`;
  }
  
  // Deshabilitar todas las cartas para que no se pueda hacer click
  const allCards = document.querySelectorAll('.battle-intro-card');
  allCards.forEach(c => {
    c.style.pointerEvents = 'none';
    c.style.opacity = '0.6';
  });
  
  // Resaltar la carta elegida por el jugador
  const selectedCard = document.querySelector(`.battle-intro-card[data-card-id="${card.id}"]`);
  if (selectedCard) {
    selectedCard.style.opacity = '1';
    selectedCard.style.transform = 'scale(1.1)';
    selectedCard.style.border = '3px solid #fbbf24';
  }
  
  // Solo ejecutar IA si NO es batalla online
  if (!isOnlineBattle) {
    // Simular que la IA está "pensando" (1-2 segundos)
    const thinkingTime = 1000 + Math.random() * 1000;
    
    setTimeout(() => {
      // IA elige carta aleatoria de su equipo
      const randomIndex = Math.floor(Math.random() * window.battleState.opponentTeam.length);
      window.battleState.opponentCurrentCard = window.battleState.opponentTeam[randomIndex];
      
      console.log('[BATTLE] IA eligió carta:', window.battleState.opponentCurrentCard.nombre || window.battleState.opponentCurrentCard.name);
      
      // Mostrar mensaje de que ambos han elegido
      instruction.innerHTML = '<h1>✅ Ambos jugadores han elegido. ¡Comienza la batalla!</h1>';
      
      // Esperar un momento antes de la transición
      setTimeout(() => {
        const isInfinite = !!(window.__infiniteBattleContext?.active || window.battleState?.difficulty === 'inmo');
        if (isInfinite && window.InfiniteModifiers && typeof window.InfiniteModifiers.playModifierRoulette === 'function') {
          window.InfiniteModifiers.playModifierRoulette(() => {
            transitionToBattleScreen();
          });
        } else {
          transitionToBattleScreen();
        }
      }, 1500);
    }, thinkingTime);
  }
  // Si es online, NO hacer nada más aquí - el servidor notificará con 'both-cards-selected'
}

// Transición a pantalla de batalla
function ensureAbandonBattleButtonBound() {
  const abandonBtn = document.getElementById('abandon-battle-btn');
  if (!abandonBtn) return;

  if (abandonBtn.dataset.boundAbandonBattle === '1') {
    return;
  }

  abandonBtn.addEventListener('click', (e) => {
    e.preventDefault();
    abandonBattle();
  });

  abandonBtn.dataset.boundAbandonBattle = '1';
  console.log('[BATTLE] Event listener del boton abandonar configurado');
}

async function transitionToBattleScreen() {
  console.log('[BATTLE] Transición a pantalla de batalla');
  
  // Ocultar intro y game-view
  const intro = document.getElementById('battle-intro');
  if (intro) intro.style.display = 'none';
  const gameView = document.getElementById('game-view');
  if (gameView) gameView.style.display = 'none';
  
  // Mostrar pantalla de batalla
  const battleScreen = document.getElementById('battle-screen');
  if (battleScreen) battleScreen.style.display = 'flex';

  const isInfiniteOffline = !!(window.__infiniteBattleContext?.active && window.battleState?.difficulty === 'inmo' && !window.battleState?.isOnline);
  const infiniteArcImage = String(window.__infiniteBattleContext?.arcImage || '').trim();
  if (isInfiniteOffline && infiniteArcImage) {
    battleScreen.classList.add('infinite-theme');
    battleScreen.style.setProperty('--battle-infinite-arc-bg', `url('${infiniteArcImage}')`);
  } else {
    battleScreen.classList.remove('infinite-theme');
    battleScreen.style.setProperty('--battle-infinite-arc-bg', 'none');
  }
  
  // Configurar botón de abandonar batalla
  ensureAbandonBattleButtonBound();
  
  // Renderizar poderes dinámicamente
  console.log('[BATTLE] Renderizando poderes en transición:', window.battleState.playerPowers, window.battleState.opponentPowers);
  await renderBattlePowers(
    window.battleState.playerPowers || [],
    window.battleState.opponentPowers || []
  );
  
  // Configurar botones de poderes DESPUÉS de renderizar
  console.log('[BATTLE] Configurando event listeners de poderes...');
  setupPowerButtons();
  console.log('[BATTLE] Poderes configurados correctamente');
  
  // Inicializar marcador
  document.getElementById('score-player-value').textContent = '0';
  document.getElementById('score-opponent-value').textContent = '0';
  
  // Obtener datos del usuario actual
  let username = 'Jugador';
  let avatar = 'https://api.dicebear.com/7.x/avataaars/svg?seed=default';
  
  try {
    if (isElectron) {
      const userResult = await window.kvrcards.getUserProfile();
      console.log('[BATTLE] Usuario obtenido en transición:', userResult);
      
      if (userResult?.ok && userResult?.profile) {
        username = userResult.profile.username || username;
        avatar = userResult.profile.profileImage || avatar;
      } else if (userResult?.username) {
        username = userResult.username;
        avatar = userResult.profileImage || avatar;
      }
    }
  } catch (error) {
    console.error('[BATTLE] Error obteniendo usuario:', error);
  }
  
  console.log('[BATTLE] Usuario final en transición:', username, 'Avatar:', avatar);
  
  document.getElementById('battle-player-avatar').src = avatar;
  document.getElementById('battle-player-username').textContent = username;
  
  // Verificar si es batalla online
  const isOnlineBattle = window.onlineState && window.onlineState.inBattle && window.onlineState.matchId;
  
  if (isOnlineBattle) {
    // Configurar perfil del oponente REAL
    const opponentUsername = window.battleState.opponentName || window.onlineState.opponentData?.username || 'Rival';
    const opponentAvatarUrl = window.onlineState.opponentData?.profileImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=${opponentUsername}`;
    
    console.log('[ONLINE-BATTLE] Configurando oponente real:', opponentUsername);
    
    document.getElementById('battle-opponent-avatar').src = opponentAvatarUrl;
    document.getElementById('battle-opponent-username').textContent = opponentUsername;
    
    const opponentTitleElement = document.getElementById('battle-opponent-title');
    if (opponentTitleElement) {
      opponentTitleElement.textContent = '🌐 Jugador Online';
    }
  } else {
    // Configurar perfil del oponente IA
    const opponentName = getOpponentName(window.battleState.difficulty);
    const opponentTitle = getOpponentTitle(window.battleState.difficulty);
    const opponentAvatar = getOpponentAvatar(window.battleState.difficulty);
    
    const avatarElement = document.getElementById('battle-opponent-avatar');
    if (avatarElement) {
      avatarElement.src = opponentAvatar;
      // Fallback si la imagen personalizada no carga
      avatarElement.onerror = function() {
        console.log('[BATTLE] Avatar del rival no encontrado/error, usando fallback de DiceBear');
        this.src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(opponentName || 'opponent')}`;
        this.onerror = null;
      };
    }
    
    const usernameElement = document.getElementById('battle-opponent-username');
    if (usernameElement) {
      usernameElement.textContent = opponentName;
    }
    
    const opponentTitleElement = document.getElementById('battle-opponent-title');
    if (opponentTitleElement) {
      if (opponentTitle) {
        const formattedTitle = String(opponentTitle).startsWith('(') ? opponentTitle : `(${opponentTitle})`;
        opponentTitleElement.textContent = formattedTitle;
        opponentTitleElement.style.display = 'inline';
      } else {
        opponentTitleElement.textContent = '';
        opponentTitleElement.style.display = 'none';
      }
    }
  }

  // Aplicar fondo de batalla personalizado del entrenador (si está configurado)
  const battleScreenEl = document.getElementById('battle-screen');
  if (battleScreenEl) {
    const customBg = window.battleState.opponentBackground;
    if (customBg && !window.battleState.isOnline) {
      const cleanUrl = String(customBg).replace(/^url\(["']?/, '').replace(/["']?\)$/, '');
      const formattedBg = `url("${cleanUrl}")`;
      battleScreenEl.classList.add('trainer-theme');
      battleScreenEl.style.setProperty('--trainer-battle-bg', formattedBg);
      battleScreenEl.style.backgroundImage = `linear-gradient(135deg, rgba(15, 12, 41, 0.72) 0%, rgba(48, 43, 99, 0.6) 50%, rgba(36, 36, 62, 0.68) 100%), url("${cleanUrl}")`;
      battleScreenEl.style.backgroundSize = 'cover';
      battleScreenEl.style.backgroundPosition = 'center';
      console.log('[BATTLE] 🎨 Fondo de batalla personalizado del entrenador aplicado en pantalla:', cleanUrl);
    } else if (!battleScreenEl.classList.contains('infinite-theme')) {
      battleScreenEl.classList.remove('trainer-theme');
      battleScreenEl.style.removeProperty('--trainer-battle-bg');
      battleScreenEl.style.backgroundImage = '';
      battleScreenEl.style.backgroundSize = '';
      battleScreenEl.style.backgroundPosition = '';
    }
  }
  
  // Limpiar DOM de stat buttons antes de configurar para la nueva batalla
  document.querySelectorAll('.battle-stat-btn, .battle-stat-display').forEach(el => {
    el.classList.remove('used', 'highlighted', 'annulled', 'disabled', 'selected', 'nerfed');
    el.disabled = false;
    el.style.opacity = '';
    el.style.borderColor = '';
    el.style.background = '';
    el.style.boxShadow = '';
    const label = el.querySelector('.stat-label');
    if (label) {
      label.innerHTML = label.innerHTML.replace(/🔒\s*/g, '');
    }
  });

  // Configurar botones de stats
  if (typeof window.setupStatButtons === 'function') {
    window.setupStatButtons();
  } else if (typeof setupStatButtons === 'function') {
    setupStatButtons();
  }
  
  // INICIAR RULETA para decidir quién empieza
  if (typeof window.startBattleRoulette === 'function') {
    await window.startBattleRoulette();
  } else if (typeof startBattleRoulette === 'function') {
    await startBattleRoulette();
  }
}

// Actualizar cartas en batalla
function updateBattleCards() {
  let playerCard = window.battleState.playerCurrentCard;
  let opponentCard = window.battleState.opponentCurrentCard;
  
  // En modo online, las cartas vienen del servidor con estructura básica
  // Buscar las cartas completas en los equipos locales
  if (window.battleState.isOnline) {
    if (playerCard && window.battleState.playerTeam) {
      let fullPlayerCard = window.battleState.playerTeam.find(c => 
        c.uniqueId === playerCard.uniqueId || c.id === playerCard.id
      );
      if (!fullPlayerCard && window.battleState.opponentTeam) {
        fullPlayerCard = window.battleState.opponentTeam.find(c =>
          c.uniqueId === playerCard.uniqueId || c.id === playerCard.id
        );
      }
      if (fullPlayerCard) {
        playerCard = fullPlayerCard;
        console.log('[BATTLE] Carta completa del jugador encontrada');
      }
    }
    
    if (opponentCard && window.battleState.opponentTeam) {
      let fullOpponentCard = window.battleState.opponentTeam.find(c => 
        c.uniqueId === opponentCard.uniqueId || c.id === opponentCard.id
      );
      if (!fullOpponentCard && window.battleState.playerTeam) {
        fullOpponentCard = window.battleState.playerTeam.find(c =>
          c.uniqueId === opponentCard.uniqueId || c.id === opponentCard.id
        );
      }
      if (fullOpponentCard) {
        opponentCard = fullOpponentCard;
        console.log('[BATTLE] Carta completa del oponente encontrada');
      }
    }
  }
  
  console.log('[BATTLE] ============ updateBattleCards LLAMADO ============');
  console.log('[BATTLE] Actualizando cartas.');
  console.log('[BATTLE] - Jugador:', playerCard?.nombre || playerCard?.name || 'SIN CARTA');
  console.log('[BATTLE] - Oponente:', opponentCard?.nombre || opponentCard?.name || 'SIN CARTA');
  console.log('[BATTLE] - playerUsedCards.length:', window.battleState.playerUsedCards?.length || 0);
  
  // Referencias a elementos - CORREGIDO: usar selectores correctos
  const playerCardDisplay = document.querySelector('.battle-side-player .battle-card-display');
  const opponentCardDisplay = document.querySelector('.battle-side-opponent .battle-card-display');
  const playerCardImg = document.getElementById('battle-player-card');
  const opponentCardImg = document.getElementById('battle-opponent-card');
  
  if (!playerCardDisplay || !opponentCardDisplay || !playerCardImg || !opponentCardImg) {
    console.error('[BATTLE] No se encontraron los elementos de las cartas en el DOM');
    console.error('playerCardDisplay:', playerCardDisplay);
    console.error('opponentCardDisplay:', opponentCardDisplay);
    console.error('playerCardImg:', playerCardImg);
    console.error('opponentCardImg:', opponentCardImg);
    return;
  }
  
  // Detectar si es la primera carta de la batalla (para animación especial)
  const isFirstCard = window.battleState.playerUsedCards.length === 1;
  
  console.log('[BATTLE] isFirstCard:', isFirstCard, '- playerUsedCards.length:', window.battleState.playerUsedCards.length);
  
  // Remover estado "empty" si hay cartas
  if (playerCard) {
    playerCardDisplay.classList.remove('empty');
    playerCardImg.style.display = 'block';
    
    // SIN ANIMACIÓN - Aparición instantánea
    
    // Carta del jugador - probar múltiples propiedades de imagen
    const playerImageUrl = playerCard.imageUrl || playerCard.imagen || playerCard.image || '';
    playerCardImg.src = playerImageUrl;
    
    // Agregar icono de trait si la carta lo tiene
    const existingPlayerTraitIcon = playerCardDisplay.querySelector('.card-trait-icon');
    if (existingPlayerTraitIcon) {
      existingPlayerTraitIcon.remove();
    }
    
    // USAR TRAITS DESDE BATTLESTATE
    const cardTraitsMap = window.battleState.cardTraitsMap || {};
    const availableTraits = window.battleState.availableTraits || [];
    
    const playerCardKey = playerCard.uniqueId || playerCard.id;
    console.log('[BATTLE] Buscando trait para jugador - Key:', playerCardKey, 'En map:', cardTraitsMap[playerCardKey]);
    
    if (cardTraitsMap[playerCardKey] && availableTraits.length > 0) {
      const traitData = cardTraitsMap[playerCardKey];
      const traitId = traitData.traitId || traitData;
      const playerTrait = availableTraits.find(t => t.id === traitId);
      
      console.log('[BATTLE] TraitId:', traitId, 'Trait encontrado:', playerTrait?.name);
      
      if (playerTrait) {
        const traitIcon = document.createElement('div');
        traitIcon.className = 'card-trait-icon';
        const traitImg = document.createElement('img');
        traitImg.src = playerTrait.imageUrl;
        traitImg.alt = playerTrait.name;
        traitImg.title = playerTrait.name;
        traitIcon.appendChild(traitImg);
        playerCardDisplay.appendChild(traitIcon);
        console.log('[BATTLE] ✅ Icono de trait agregado para jugador:', playerTrait.name);
      }
    } else {
      console.log('[BATTLE] ❌ No hay trait para esta carta del jugador');
    }
    
    // Stats pueden estar en 'stats' o 'parametros'
    const playerStats = playerCard.stats || playerCard.parametros || [];
    const playerMedia = parseInt(playerCard.media) || 0;
    
    // Aplicar boost si Power Up está activo
    const playerBoost = window.battleState.playerPowerUpActive ? 3 : 0;
    const playerNerfActive = window.battleState.playerNerfActive || false;
    
    // Obtener boost de trait si existe
    let playerTraitBoosts = {}; // {stat: value} o {all: value}
    // Reusar playerCardKey ya declarado arriba
    if (cardTraitsMap[playerCardKey]) {
      const playerTraitData = cardTraitsMap[playerCardKey];
      const playerTraitId = playerTraitData.traitId || playerTraitData;
      const playerTrait = availableTraits.find(t => t.id === playerTraitId);
      if (playerTrait && playerTrait.effect) {
        if (playerTrait.effect.type === 'boost_stat') {
          playerTraitBoosts[playerTrait.effect.stat] = playerTrait.effect.value || 0;
        } else if (playerTrait.effect.type === 'boost_all') {
          playerTraitBoosts.all = playerTrait.effect.value || 0;
        }
      }
    }
    
    // Obtener buffeos activos del jugador (procedencia)
    let playerBuffBoosts = {}; // {stat: percentage} o {all: percentage}
    if (window.battleState.playerBuffs && playerCard.procedencia) {
      const buffData = window.battleState.playerBuffs.byProcedencia[playerCard.procedencia];
      if (buffData) {
        if (buffData.stats.includes('all')) {
          playerBuffBoosts.all = buffData.percentage;
        } else {
          buffData.stats.forEach(stat => {
            playerBuffBoosts[stat] = buffData.percentage;
          });
        }
      }
    }
    
    // Obtener buffeos de owner del jugador
    let playerOwnerBuffBoosts = {}; // {stat: percentage}
    if (window.battleState.playerBuffs && playerCard.owner) {
      const ownerBuffData = window.battleState.playerBuffs.byOwner[playerCard.owner];
      if (ownerBuffData) {
        ownerBuffData.stats.forEach(stat => {
          playerOwnerBuffBoosts[stat] = ownerBuffData.percentage;
        });
      }
    }
    
    // Actualizar media (NO se aplica buff de owner a media, solo a stats específicas)
    const playerMediaEl = document.getElementById('battle-player-media');
    // Obtener buffeos de Kizuna del jugador
    const playerBaseId = playerCard.id ? String(playerCard.id).replace(/_notrait.*$/, '') : playerCardKey;
    const playerKizunaBuffs = (window.battleState.playerBuffs?.byKizunaCard?.[playerBaseId]) || {};
    const playerMediaKizunaBuffPercentage = playerKizunaBuffs.all || 0;
    const playerMediaKizunaBuffValue = Math.floor(playerMedia * (playerMediaKizunaBuffPercentage / 100));

    let mediaBuffPercentage = playerBuffBoosts.all || 0;
    const mediaBuffValue = Math.floor(playerMedia * (mediaBuffPercentage / 100));

    // Modificadores de Modo Infinito para la carta
    const infiniteBuffMap = window.battleState?.infiniteCardBuffs || window.__infiniteRunCardBuffs;
    const infiniteCardBuffs = infiniteBuffMap ? (infiniteBuffMap[playerCardKey] || infiniteBuffMap[playerCard.id] || infiniteBuffMap[playerBaseId] || {}) : {};

    const statNames = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
    const infiniteStatValues = statNames.map(s => Number(infiniteCardBuffs[s]) || 0);
    const infiniteMediaDelta = Math.round(infiniteStatValues.reduce((a, b) => a + b, 0) / (infiniteStatValues.length || 1));

    const playerModifiers = window.battleState?.statModifiers?.[playerCardKey] || {};
    let playerAllMod = Number(playerModifiers.all) || 0;
    if (playerBoost > 0 && playerAllMod > 0) {
      playerAllMod = Math.max(0, playerAllMod - playerBoost);
    }
    const playerMediaMod = (Number(playerModifiers['media']) || 0) + playerAllMod;

    let modifierMediaDelta = 0;
    if (window.InfiniteModifiers && typeof window.InfiniteModifiers.getCardStatDelta === 'function') {
      modifierMediaDelta = window.InfiniteModifiers.getCardStatDelta('player', playerCard, 'media', playerMedia);
    }
    const totalMediaBoost = playerBoost + (playerTraitBoosts.all || 0) + mediaBuffValue + playerMediaKizunaBuffValue + infiniteMediaDelta + playerMediaMod + modifierMediaDelta;
    
    // Mostrar solo valor final
    const finalMediaValue = Math.max(1, playerMedia + totalMediaBoost);
    playerMediaEl.textContent = finalMediaValue;
    if (totalMediaBoost > 0) {
      playerMediaEl.style.color = '#22c55e';
      playerMediaEl.style.fontWeight = 'bold';
    } else if (totalMediaBoost < 0) {
      playerMediaEl.style.color = '#ef4444';
      playerMediaEl.style.fontWeight = 'bold';
    } else {
      playerMediaEl.textContent = finalMediaValue;
      playerMediaEl.style.color = '';
      playerMediaEl.style.fontWeight = '';
    }
    
    // Actualizar stats
    for (let i = 0; i < 6; i++) {
      const statEl = document.getElementById(`battle-player-stat${i + 1}`);
      const statValue = parseInt(playerStats[i]) || 0;
      
      // Calcular buff de procedencia (porcentaje)
      const statBuffPercentage = playerBuffBoosts[statNames[i]] || playerBuffBoosts.all || 0;
      const statBuffValue = Math.floor(statValue * (statBuffPercentage / 100));
      
      // Calcular buff de owner (porcentaje)
      const statOwnerBuffPercentage = playerOwnerBuffBoosts[statNames[i]] || 0;
      const statOwnerBuffValue = Math.floor(statValue * (statOwnerBuffPercentage / 100));
      
      // Calcular buff de Kizuna (porcentaje)
      const statKizunaBuffPercentage = (playerKizunaBuffs[statNames[i]] || 0) + (playerKizunaBuffs.all || 0);
      const statKizunaBuffValue = Math.floor(statValue * (statKizunaBuffPercentage / 100));

      // Modificador de Modo Infinito para esta stat específica
      const statInfiniteDelta = Number(infiniteCardBuffs[statNames[i]]) || 0;

      // Modificadores temporales de batalla (ej. Nerf u otros)
      const playerBattleMod = (Number(playerModifiers[statNames[i]]) || 0) + playerAllMod;

      // Modificador de combate del Modo Infinito
      let modifierStatDelta = 0;
      if (window.InfiniteModifiers && typeof window.InfiniteModifiers.getCardStatDelta === 'function') {
        modifierStatDelta = window.InfiniteModifiers.getCardStatDelta('player', playerCard, statNames[i], statValue);
      }

      // Sumar todos los boosts: powerup + trait + buff procedencia + buff owner + buff kizuna + infinite run delta + battle mod + combat modifier
      const totalStatBoost = playerBoost + (playerTraitBoosts.all || 0) + (playerTraitBoosts[statNames[i]] || 0) + statBuffValue + statOwnerBuffValue + statKizunaBuffValue + statInfiniteDelta + playerBattleMod + modifierStatDelta;

      const finalStatValue = Math.max(1, statValue + totalStatBoost);
      
      // Mostrar solo valor final
      statEl.textContent = finalStatValue;
      
      // Colorear según tipo de boost
      if (statBuffValue > 0 || statOwnerBuffValue > 0 || statKizunaBuffValue > 0) {
        // Si tiene buff de procedencia, owner o kizuna, morado
        statEl.style.color = '#a855f7';
        statEl.style.fontWeight = 'bold';
      } else if (totalStatBoost > 0) {
        // Si solo tiene trait, power up o mejora positiva de infinito, verde
        statEl.style.color = '#22c55e';
        statEl.style.fontWeight = 'bold';
      } else if (totalStatBoost < 0) {
        // Si tiene un nerfeo neto (ej. -5 o -6), rojo
        statEl.style.color = '#ef4444';
        statEl.style.fontWeight = 'bold';
      } else {
        statEl.style.color = '';
        statEl.style.fontWeight = '';
      }
    }
    
    console.log('[BATTLE] Imagen jugador:', playerImageUrl);
    console.log('[BATTLE] Stats jugador:', playerStats, playerBoost > 0 ? `(+${playerBoost} Power Up)` : '', Object.keys(playerBuffBoosts).length > 0 ? `Buff activo` : '');
  } else {
    console.warn('[BATTLE] No hay carta del jugador para mostrar');
  }
  
  if (opponentCard) {
    opponentCardDisplay.classList.remove('empty');
    opponentCardImg.style.display = 'block';
    
    // SIN ANIMACIÓN - Aparición instantánea
    
    // Carta del oponente
    const opponentImageUrl = opponentCard.imageUrl || opponentCard.imagen || opponentCard.image || '';
    opponentCardImg.src = opponentImageUrl;
    
    // Agregar icono de trait si la carta lo tiene
    const existingOpponentTraitIcon = opponentCardDisplay.querySelector('.card-trait-icon');
    if (existingOpponentTraitIcon) {
      existingOpponentTraitIcon.remove();
    }
    
    // Buscar trait: primero en opponentTraitId (traits de IA), luego en cardTraitsMap (si es carta del jugador)
    let opponentTrait = null;
    console.log('[BATTLE] Buscando trait para oponente - opponentTraitId:', opponentCard.opponentTraitId);
    
    if (opponentCard.opponentTraitId && availableTraits.length > 0) {
      opponentTrait = availableTraits.find(t => t.id === opponentCard.opponentTraitId);
      console.log('[BATTLE] Trait del oponente (AI):', opponentTrait?.name);
    } else {
      const opponentCardKey = opponentCard.uniqueId || opponentCard.id;
      console.log('[BATTLE] Buscando en cardTraitsMap - Key:', opponentCardKey);
      if (cardTraitsMap[opponentCardKey] && availableTraits.length > 0) {
        const traitData = cardTraitsMap[opponentCardKey];
        const traitId = traitData.traitId || traitData;
        opponentTrait = availableTraits.find(t => t.id === traitId);
        console.log('[BATTLE] Trait del oponente (map):', opponentTrait?.name);
      }
    }
    
    if (opponentTrait) {
      console.log('[BATTLE] ✅ Icono de trait agregado para oponente:', opponentTrait.name);
    } else {
      console.log('[BATTLE] ❌ No hay trait para esta carta del oponente');
    }
    
    if (opponentTrait) {
      const traitIcon = document.createElement('div');
      traitIcon.className = 'card-trait-icon';
      const traitImg = document.createElement('img');
      traitImg.src = opponentTrait.imageUrl;
      traitImg.alt = opponentTrait.name;
      traitImg.title = opponentTrait.name;
      traitIcon.appendChild(traitImg);
      opponentCardDisplay.appendChild(traitIcon);
    }
    
    const opponentStats = opponentCard.stats || opponentCard.parametros || [];
    const opponentMedia = parseInt(opponentCard.media) || 0;
    
    // Aplicar boost si Power Up está activo
    const opponentBoost = window.battleState.opponentPowerUpActive ? 3 : 0;
    
    // Obtener boost de trait si existe
    let opponentTraitBoosts = {}; // {stat: value} o {all: value}
    
    // Buscar trait del oponente: primero opponentTraitId (IA), luego cardTraitsMap
    let opponentTraitForBoost = null;
    if (opponentCard.opponentTraitId && availableTraits.length > 0) {
      opponentTraitForBoost = availableTraits.find(t => t.id === opponentCard.opponentTraitId);
    } else {
      const opponentCardKey = opponentCard.uniqueId || opponentCard.id;
      if (cardTraitsMap[opponentCardKey]) {
        const opponentTraitData = cardTraitsMap[opponentCardKey];
        const opponentTraitId = opponentTraitData.traitId || opponentTraitData;
        opponentTraitForBoost = availableTraits.find(t => t.id === opponentTraitId);
      }
    }
    
    if (opponentTraitForBoost && opponentTraitForBoost.effect) {
      if (opponentTraitForBoost.effect.type === 'boost_stat') {
        opponentTraitBoosts[opponentTraitForBoost.effect.stat] = opponentTraitForBoost.effect.value || 0;
      } else if (opponentTraitForBoost.effect.type === 'boost_all') {
        opponentTraitBoosts.all = opponentTraitForBoost.effect.value || 0;
      }
    }
    
    // Obtener buffeos activos del oponente (procedencia)
    let opponentBuffBoosts = {}; // {stat: percentage} o {all: percentage}
    if (window.battleState.opponentBuffs && opponentCard.procedencia) {
      const buffData = window.battleState.opponentBuffs.byProcedencia[opponentCard.procedencia];
      if (buffData) {
        if (buffData.stats.includes('all')) {
          opponentBuffBoosts.all = buffData.percentage;
        } else {
          buffData.stats.forEach(stat => {
            opponentBuffBoosts[stat] = buffData.percentage;
          });
        }
      }
    }
    
    // Obtener buffeos de owner del oponente
    let opponentOwnerBuffBoosts = {}; // {stat: percentage}
    if (window.battleState.opponentBuffs && opponentCard.owner) {
      const ownerBuffData = window.battleState.opponentBuffs.byOwner[opponentCard.owner];
      if (ownerBuffData) {
        ownerBuffData.stats.forEach(stat => {
          opponentOwnerBuffBoosts[stat] = ownerBuffData.percentage;
        });
      }
    }
    
    // Obtener buffeos de Kizuna del oponente
    const opponentCardKey = opponentCard.uniqueId || opponentCard.id;
    const opponentBaseId = opponentCard.id ? String(opponentCard.id).replace(/_notrait.*$/, '') : opponentCardKey;
    const opponentKizunaBuffs = (window.battleState.opponentBuffs?.byKizunaCard?.[opponentBaseId]) || {};
    const opponentMediaKizunaBuffPercentage = opponentKizunaBuffs.all || 0;
    const opponentMediaKizunaBuffValue = Math.floor(opponentMedia * (opponentMediaKizunaBuffPercentage / 100));

    // Actualizar media (NO se aplica buff de owner a media, solo a stats específicas)
    const opponentMediaEl = document.getElementById('battle-opponent-media');
    let opponentMediaBuffPercentage = opponentBuffBoosts.all || 0;
    const opponentMediaBuffValue = Math.floor(opponentMedia * (opponentMediaBuffPercentage / 100));
    const opponentModifiers = window.battleState?.statModifiers?.[opponentCardKey] || {};
    let opponentAllMod = Number(opponentModifiers.all) || 0;
    if (opponentBoost > 0 && opponentAllMod > 0) {
      opponentAllMod = Math.max(0, opponentAllMod - opponentBoost);
    }
    const opponentMediaMod = (Number(opponentModifiers['media']) || 0) + opponentAllMod;

    let modifierOpponentMediaDelta = 0;
    if (window.InfiniteModifiers && typeof window.InfiniteModifiers.getCardStatDelta === 'function') {
      modifierOpponentMediaDelta = window.InfiniteModifiers.getCardStatDelta('opponent', opponentCard, 'media', opponentMedia);
    }
    const totalOpponentMediaBoost = opponentBoost + (opponentTraitBoosts.all || 0) + opponentMediaBuffValue + opponentMediaKizunaBuffValue + opponentMediaMod + modifierOpponentMediaDelta;
    
    // Mostrar solo valor final (sin etiqueta +X)
    const finalOpponentMediaValue = Math.max(1, opponentMedia + totalOpponentMediaBoost);
    if (totalOpponentMediaBoost > 0) {
      opponentMediaEl.textContent = finalOpponentMediaValue;
      opponentMediaEl.style.color = '#22c55e';
      opponentMediaEl.style.fontWeight = 'bold';
    } else if (totalOpponentMediaBoost < 0) {
      opponentMediaEl.textContent = finalOpponentMediaValue;
      opponentMediaEl.style.color = '#ef4444';
      opponentMediaEl.style.fontWeight = 'bold';
    } else {
      opponentMediaEl.textContent = finalOpponentMediaValue;
      opponentMediaEl.style.color = '';
      opponentMediaEl.style.fontWeight = '';
    }
    
    // Actualizar stats
    const statNames = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
    for (let i = 0; i < 6; i++) {
      const statEl = document.getElementById(`battle-opponent-stat${i + 1}`);
      const statValue = parseInt(opponentStats[i]) || 0;
      
      // Calcular buff de procedencia (porcentaje)
      const statBuffPercentage = opponentBuffBoosts[statNames[i]] || opponentBuffBoosts.all || 0;
      const statBuffValue = Math.floor(statValue * (statBuffPercentage / 100));
      
      // Calcular buff de owner (porcentaje)
      const statOwnerBuffPercentage = opponentOwnerBuffBoosts[statNames[i]] || 0;
      const statOwnerBuffValue = Math.floor(statValue * (statOwnerBuffPercentage / 100));
      
      // Calcular buff de Kizuna (porcentaje)
      const statKizunaBuffPercentage = (opponentKizunaBuffs[statNames[i]] || 0) + (opponentKizunaBuffs.all || 0);
      const statKizunaBuffValue = Math.floor(statValue * (statKizunaBuffPercentage / 100));

      // Modificadores temporales de batalla (ej. Nerf u otros)
      const opponentBattleMod = (Number(opponentModifiers[statNames[i]]) || 0) + opponentAllMod;

      // Modificador de combate del Modo Infinito para el oponente
      let modifierOpponentDelta = 0;
      if (window.InfiniteModifiers && typeof window.InfiniteModifiers.getCardStatDelta === 'function') {
        modifierOpponentDelta = window.InfiniteModifiers.getCardStatDelta('opponent', opponentCard, statNames[i], statValue);
      }

      // Sumar todos los boosts: powerup + trait + buff procedencia + buff owner + buff kizuna + battle mod + combat modifier
      const totalStatBoost = opponentBoost + (opponentTraitBoosts.all || 0) + (opponentTraitBoosts[statNames[i]] || 0) + statBuffValue + statOwnerBuffValue + statKizunaBuffValue + opponentBattleMod + modifierOpponentDelta;

      const finalOpponentStatValue = Math.max(1, statValue + totalStatBoost);
      
      // Mostrar solo valor final (sin etiqueta +X)
      statEl.textContent = finalOpponentStatValue;
      
      // Colorear según tipo de boost
      if (statBuffValue > 0 || statOwnerBuffValue > 0 || statKizunaBuffValue > 0) {
        // Si tiene buff de procedencia, owner o kizuna, morado
        statEl.style.color = '#a855f7';
        statEl.style.fontWeight = 'bold';
      } else if (totalStatBoost > 0) {
        // Si tiene trait o power up, verde
        statEl.style.color = '#22c55e';
        statEl.style.fontWeight = 'bold';
      } else if (totalStatBoost < 0) {
        // Si tiene nerf neto, rojo
        statEl.style.color = '#ef4444';
        statEl.style.fontWeight = 'bold';
      } else {
        statEl.textContent = finalOpponentStatValue;
        statEl.style.color = '';
        statEl.style.fontWeight = '';
      }
    }
    
    console.log('[BATTLE] Imagen oponente:', opponentImageUrl);
    console.log('[BATTLE] Stats oponente:', opponentStats, opponentBoost > 0 ? `(+${opponentBoost} Power Up)` : '', Object.keys(opponentBuffBoosts).length > 0 ? `Buff activo` : '');
  } else {
    console.warn('[BATTLE] No hay carta del oponente para mostrar');
  }
  
  // Re-aplicar NERF visual si está activo (puede haberse sobrescrito)
  if (typeof reapplyNerfVisualIfActive === 'function') {
    reapplyNerfVisualIfActive();
  }
  
  // Actualizar buffeos visuales
  updateBattleBuffsDisplay();
}

// Renderizar buffeos activos en la batalla
function updateBattleBuffsDisplay() {
  const playerBuffsContainer = document.getElementById('battle-player-buffs');
  const opponentBuffsContainer = document.getElementById('battle-opponent-buffs');
  
  if (!playerBuffsContainer || !opponentBuffsContainer) {
    console.warn('[BATTLE BUFFS] Contenedores de buffeos no encontrados');
    return;
  }
  
  // Renderizar buffeos del jugador (procedencia + owner + kizuna)
  const playerCard = window.battleState.playerCurrentCard;
  let playerBuffsHTML = [];
  
  // Buff de procedencia
  if (playerCard && playerCard.procedencia && window.battleState.playerBuffs) {
    const buffData = window.battleState.playerBuffs.byProcedencia[playerCard.procedencia];
    if (buffData) {
      let statText;
      if (buffData.stats.includes('all')) {
        statText = 'todas las stats';
      } else {
        statText = buffData.stats.map(s => STAT_NAMES_MAP[s] || s).join(' y ');
      }
      
      playerBuffsHTML.push(`
        <div class="battle-buff-item">
          <div class="battle-buff-icon">${buffData.icon}</div>
          <div class="battle-buff-text">
            ${buffData.procedencia}: +${buffData.percentage}% ${statText}
          </div>
        </div>
      `);
    }
  }
  
  // Buff de owner
  if (playerCard && playerCard.owner && window.battleState.playerBuffs) {
    const ownerBuffData = window.battleState.playerBuffs.byOwner[playerCard.owner];
    if (ownerBuffData) {
      const statText = ownerBuffData.stats.map(s => STAT_NAMES_MAP[s] || s).join(' y ');
      playerBuffsHTML.push(`
        <div class="battle-buff-item buff-item-owner">
          <div class="battle-buff-icon">${ownerBuffData.icon}</div>
          <div class="battle-buff-text">
            ${ownerBuffData.owner}: +${ownerBuffData.percentage}% ${statText}
          </div>
        </div>
      `);
    }
  }
  
  // Buff de Kizuna del jugador
  if (playerCard && window.battleState.playerBuffs) {
    const playerBaseId = (playerCard.id || playerCard.uniqueId || '').replace(/_notrait.*$/, '');
    const activeKizunaList = (window.battleState.playerBuffs.buffs || []).filter(b => b.isKizunaBuff);
    for (const kBuff of activeKizunaList) {
      const appliesToThisCard = kBuff.allTeam || (Array.isArray(kBuff.cardIds) && kBuff.cardIds.includes(playerBaseId));
      if (appliesToThisCard) {
        playerBuffsHTML.push(`
          <div class="battle-buff-item buff-item-kizuna">
            <div class="battle-buff-icon">${kBuff.icon || '⚡'}</div>
            <div class="battle-buff-text">
              ${escapeHtml(kBuff.name)}: ${escapeHtml(kBuff.description)}
            </div>
          </div>
        `);
      }
    }
  }

  // Modificador de Modo Infinito en buffeos del jugador
  const activeModifier = window.battleState?.infiniteModifier || window.__infiniteBattleContext?.modifier;
  if (playerCard && activeModifier && window.InfiniteModifiers) {
    const appliesToPlayer = activeModifier.target === 'player' || activeModifier.target === 'both' || activeModifier.target === 'all' || activeModifier.target === 'none';
    if (appliesToPlayer) {
      const modBuffText = window.InfiniteModifiers.getDynamicModifierBuffText(activeModifier, 'player');
      if (modBuffText) {
        const isSpecial = activeModifier.type === 'especial';
        playerBuffsHTML.push(`
          <div class="battle-buff-item buff-item-modifier ${isSpecial ? 'buff-item-special' : 'buff-item-normal'}">
            <div class="battle-buff-badge ${isSpecial ? 'badge-special' : 'badge-normal'}">${isSpecial ? 'ESPECIAL' : 'MOD'}</div>
            <div class="battle-buff-text">
              <strong>[${escapeHtml(activeModifier.name.toUpperCase())}]</strong> ${escapeHtml(modBuffText)}
            </div>
          </div>
        `);
      }
    }
  }
  
  if (playerBuffsHTML.length > 0) {
    playerBuffsContainer.innerHTML = playerBuffsHTML.join('');
  } else {
    playerBuffsContainer.innerHTML = '<div class="battle-buff-empty">Sin buffeos activos</div>';
  }
  
  // Renderizar buffeos del oponente (procedencia + owner + kizuna)
  const opponentCard = window.battleState.opponentCurrentCard;
  let opponentBuffsHTML = [];
  
  // Buff de procedencia
  if (opponentCard && opponentCard.procedencia && window.battleState.opponentBuffs) {
    const buffData = window.battleState.opponentBuffs.byProcedencia[opponentCard.procedencia];
    if (buffData) {
      let statText;
      if (buffData.stats.includes('all')) {
        statText = 'todas las stats';
      } else {
        statText = buffData.stats.map(s => STAT_NAMES_MAP[s] || s).join(' y ');
      }
      
      opponentBuffsHTML.push(`
        <div class="battle-buff-item">
          <div class="battle-buff-icon">${buffData.icon}</div>
          <div class="battle-buff-text">
            ${buffData.procedencia}: +${buffData.percentage}% ${statText}
          </div>
        </div>
      `);
    }
  }
  
  // Buff de owner
  if (opponentCard && opponentCard.owner && window.battleState.opponentBuffs) {
    const ownerBuffData = window.battleState.opponentBuffs.byOwner[opponentCard.owner];
    if (ownerBuffData) {
      const statText = ownerBuffData.stats.map(s => STAT_NAMES_MAP[s] || s).join(' y ');
      opponentBuffsHTML.push(`
        <div class="battle-buff-item buff-item-owner">
          <div class="battle-buff-icon">${ownerBuffData.icon}</div>
          <div class="battle-buff-text">
            ${ownerBuffData.owner}: +${ownerBuffData.percentage}% ${statText}
          </div>
        </div>
      `);
    }
  }

  // Buff de Kizuna del oponente
  if (opponentCard && window.battleState.opponentBuffs) {
    const opponentBaseId = (opponentCard.id || opponentCard.uniqueId || '').replace(/_notrait.*$/, '');
    const activeKizunaList = (window.battleState.opponentBuffs.buffs || []).filter(b => b.isKizunaBuff);
    for (const kBuff of activeKizunaList) {
      const appliesToThisCard = kBuff.allTeam || (Array.isArray(kBuff.cardIds) && kBuff.cardIds.includes(opponentBaseId));
      if (appliesToThisCard) {
        opponentBuffsHTML.push(`
          <div class="battle-buff-item buff-item-kizuna">
            <div class="battle-buff-icon">${kBuff.icon || '⚡'}</div>
            <div class="battle-buff-text">
              ${escapeHtml(kBuff.name)}: ${escapeHtml(kBuff.description)}
            </div>
          </div>
        `);
      }
    }
  }

  // Modificador de Modo Infinito en buffeos del oponente (solo si afecta al boss/ambos)
  if (opponentCard && activeModifier && window.InfiniteModifiers) {
    const appliesToOpponent = activeModifier.target === 'boss' || activeModifier.target === 'both' || activeModifier.target === 'all';
    if (appliesToOpponent) {
      const oppModBuffText = window.InfiniteModifiers.getDynamicModifierBuffText(activeModifier, 'opponent');
      if (oppModBuffText) {
        const isSpecial = activeModifier.type === 'especial';
        opponentBuffsHTML.push(`
          <div class="battle-buff-item buff-item-modifier ${isSpecial ? 'buff-item-special' : 'buff-item-normal'}">
            <div class="battle-buff-badge ${isSpecial ? 'badge-special' : 'badge-normal'}">${isSpecial ? 'ESPECIAL' : 'MOD'}</div>
            <div class="battle-buff-text">
              <strong>[${escapeHtml(activeModifier.name.toUpperCase())}]</strong> ${escapeHtml(oppModBuffText)}
            </div>
          </div>
        `);
      }
    }
  }
  
  if (opponentBuffsHTML.length > 0) {
    opponentBuffsContainer.innerHTML = opponentBuffsHTML.join('');
  } else {
    opponentBuffsContainer.innerHTML = '<div class="battle-buff-empty">Sin buffeos activos</div>';
  }
}

// Configurar botones de stats
// NOTA: setupStatButtons() está definida más abajo con la lógica completa (online + offline)

// Jugar una ronda
function playRound(statType) {
  console.log('[BATTLE] Jugando ronda con stat:', statType);
  
  // En modo online, el servidor maneja todo - no ejecutar lógica local
  if (window.battleState.isOnline) {
    console.log('[BATTLE] Modo online - esperando resultado del servidor');
    return;
  }
  
  let playerCard = window.battleState.playerCurrentCard;
  let opponentCard = window.battleState.opponentCurrentCard;
  
  let playerValue, opponentValue;
  
  // Nombres de stats para mapear el índice
  const statNames = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
  
  // Obtener valores según el tipo de stat
  playerValue = getStatValue(playerCard, statType);
  opponentValue = getStatValue(opponentCard, statType);
  
  // Aplicar boosts de Power Up
  const playerPowerUpBoost = window.battleState.playerPowerUpActive ? 3 : 0;
  const opponentPowerUpBoost = window.battleState.opponentPowerUpActive ? 3 : 0;
  
  // Aplicar boosts de traits
  let playerTraitBoost = 0;
  let opponentTraitBoost = 0;
  
  // Player trait boost
  const playerCardKey = playerCard.uniqueId || playerCard.id;
  if (cardTraitsMap && cardTraitsMap[playerCardKey]) {
    const playerTraitData = cardTraitsMap[playerCardKey];
    const playerTraitId = playerTraitData.traitId || cardTraitsMap[playerCardKey];
    const playerTrait = availableTraits.find(t => t.id === playerTraitId);
    if (playerTrait && playerTrait.effect) {
      if (playerTrait.effect.type === 'boost_all') {
        playerTraitBoost = playerTrait.effect.value || 0;
      } else if (playerTrait.effect.type === 'boost_stat' && playerTrait.effect.stat === statType) {
        playerTraitBoost = playerTrait.effect.value || 0;
      }
    }
  }
  
  // Opponent trait boost
  let opponentTraitForRound = null;
  if (opponentCard.opponentTraitId && availableTraits) {
    opponentTraitForRound = availableTraits.find(t => t.id === opponentCard.opponentTraitId);
  } else {
    const opponentCardKey = opponentCard.uniqueId || opponentCard.id;
    if (cardTraitsMap && cardTraitsMap[opponentCardKey]) {
      const opponentTraitData = cardTraitsMap[opponentCardKey];
      const opponentTraitId = opponentTraitData.traitId || cardTraitsMap[opponentCardKey];
      opponentTraitForRound = availableTraits.find(t => t.id === opponentTraitId);
    }
  }
  
  if (opponentTraitForRound && opponentTraitForRound.effect) {
    if (opponentTraitForRound.effect.type === 'boost_all') {
      opponentTraitBoost = opponentTraitForRound.effect.value || 0;
    } else if (opponentTraitForRound.effect.type === 'boost_stat' && opponentTraitForRound.effect.stat === statType) {
      opponentTraitBoost = opponentTraitForRound.effect.value || 0;
    }
  }

  // Aplicar buffs de Kizuna
  let playerKizunaBuff = 0;
  let opponentKizunaBuff = 0;
  const playerBaseId = (playerCard.id || playerCard.uniqueId || '').replace(/_notrait.*$/, '');
  const opponentBaseId = (opponentCard.id || opponentCard.uniqueId || '').replace(/_notrait.*$/, '');

  if (window.battleState.playerBuffs?.byKizunaCard?.[playerBaseId]) {
    const pk = window.battleState.playerBuffs.byKizunaCard[playerBaseId];
    const pct = (pk[statType] || 0) + (pk.all || 0);
    playerKizunaBuff = Math.floor(playerValue * (pct / 100));
  }

  if (window.battleState.opponentBuffs?.byKizunaCard?.[opponentBaseId]) {
    const ok = window.battleState.opponentBuffs.byKizunaCard[opponentBaseId];
    const pct = (ok[statType] || 0) + (ok.all || 0);
    opponentKizunaBuff = Math.floor(opponentValue * (pct / 100));
  }
  
  // Aplicar todos los boosts
  playerValue += playerPowerUpBoost + playerTraitBoost + playerKizunaBuff;
  opponentValue += opponentPowerUpBoost + opponentTraitBoost + opponentKizunaBuff;
  
  console.log('[BATTLE] Valores base - Jugador:', playerValue - playerPowerUpBoost - playerTraitBoost - playerKizunaBuff, 'Oponente:', opponentValue - opponentPowerUpBoost - opponentTraitBoost - opponentKizunaBuff);
  console.log('[BATTLE] Boosts jugador - PowerUp:', playerPowerUpBoost, 'Trait:', playerTraitBoost, 'Kizuna:', playerKizunaBuff);
  console.log('[BATTLE] Boosts oponente - PowerUp:', opponentPowerUpBoost, 'Trait:', opponentTraitBoost, 'Kizuna:', opponentKizunaBuff);
  console.log('[BATTLE] Valores finales - Jugador:', playerValue, 'Oponente:', opponentValue);
  
  // Determinar ganador de la ronda
  if (playerValue > opponentValue) {
    console.log('[BATTLE] ¡Jugador gana la ronda!');
    window.battleState.playerScore++;
    alert(`🎉 ¡Ganaste la ronda!\n\nTu ${statType}: ${playerValue}\nOponente: ${opponentValue}`);
  } else if (opponentValue > playerValue) {
    console.log('[BATTLE] Oponente gana la ronda');
    window.battleState.opponentScore++;
    alert(`😢 Perdiste la ronda\n\nTu ${statType}: ${playerValue}\nOponente: ${opponentValue}`);
  } else {
    console.log('[BATTLE] Empate');
    alert(`🤝 Empate\n\nAmbos tienen: ${playerValue}`);
  }
  
  // TODO: Continuar con la siguiente ronda o finalizar batalla
}

// Generar equipo oponente según dificultad
