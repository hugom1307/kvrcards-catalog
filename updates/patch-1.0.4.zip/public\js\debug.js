// ==================== FUNCIONES DE MODO DEBUG ====================

// Sincronizar inventario con R2 después de modificaciones
async function syncInventoryToR2() {
  if (!window.kvrcards) return;
  try {
    const inv = await window.kvrcards.getInventory();
    if (!inv.ok) return;
    
    // El sistema ya sincroniza automáticamente cuando se modifica el inventario local
    // Solo necesitamos forzar una actualización
    await renderCollection();
    await renderOwnedPacks();
    await renderWallet();
    await renderTraitsPanel();
    
    console.log('[DEBUG] Inventario sincronizado con R2');
  } catch (e) {
    console.error('[DEBUG] Error sincronizando con R2:', e);
  }
}

// Añadir carta
async function debugAddCard(cardId, quantity = 1, skipConfirm = false) {
  if (!skipConfirm && !confirm(`¿Añadir ${quantity} carta(s) "${cardId}"?`)) return;
  
  try {
    for (let i = 0; i < quantity; i++) {
      const result = await window.kvrcards.addCard(cardId);
      if (result.error) {
        if (!skipConfirm) {
          alert(`❌ Error en carta ${i + 1}/${quantity}: ${result.error}`);
        }
        return;
      }
    }
    
    if (!skipConfirm) {
      await renderCollection();
      alert(`✅ ${quantity} carta(s) "${cardId}" añadida(s) correctamente`);
    }
  } catch (e) {
    console.error('[DEBUG] Error añadiendo carta:', e);
    if (!skipConfirm) {
      alert('❌ Error: ' + e.message);
    }
  }
}

// Eliminar carta
async function debugRemoveCard(cardId, quantity = 1) {
  if (!confirm(`¿Eliminar ${quantity} unidad(es) de la carta "${cardId}"?`)) return;
  
  try {
    const inv = await window.kvrcards.getInventory();
    if (!inv.ok || !inv.cards[cardId] || inv.cards[cardId] < quantity) {
      alert(`⚠️ No tienes suficientes cartas. Tienes: ${inv.cards[cardId] || 0}, intentas eliminar: ${quantity}`);
      return;
    }
    
    for (let i = 0; i < quantity; i++) {
      const result = await window.kvrcards.sellCard(cardId);
      if (result.error) {
        alert(`❌ Error en carta ${i + 1}/${quantity}: ${result.error}`);
        return;
      }
    }
    
    await renderCollection();
    await renderWallet();
    alert(`✅ ${quantity} carta(s) "${cardId}" eliminada(s) correctamente`);
  } catch (e) {
    console.error('[DEBUG] Error eliminando carta:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Añadir sobres
async function debugAddPack(packId, quantity) {
  if (!confirm(`¿Añadir ${quantity} sobre(s) "${packId}"?`)) return;
  
  try {
    const result = await window.kvrcards.addInventoryPack(packId, quantity);
    if (result.error) {
      alert('❌ Error: ' + result.error);
      return;
    }
    
    await renderOwnedPacks();
    alert(`✅ ${quantity} sobre(s) "${packId}" añadido(s) correctamente`);
  } catch (e) {
    console.error('[DEBUG] Error añadiendo sobre:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Eliminar sobres
async function debugRemovePack(packId, quantity) {
  if (!confirm(`¿Eliminar ${quantity} sobre(s) "${packId}"?`)) return;
  
  try {
    const inv = await window.kvrcards.getInventory();
    if (!inv.ok || !inv.packs[packId] || inv.packs[packId] <= 0) {
      alert('⚠️ No tienes este sobre en tu inventario');
      return;
    }
    
    // Eliminar sobres uno por uno
    for (let i = 0; i < quantity; i++) {
      const currentCount = inv.packs[packId] || 0;
      if (currentCount <= 0) break;
      
      const result = await window.kvrcards.deletePack(packId);
      if (result.error) {
        alert(`❌ Error eliminando sobre ${i + 1}/${quantity}: ` + result.error);
        break;
      }
    }
    
    await renderOwnedPacks();
    alert(`✅ Sobres "${packId}" eliminados correctamente`);
  } catch (e) {
    console.error('[DEBUG] Error eliminando sobre:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Modificar Coins
async function debugModifyCoins(amount) {
  if (!confirm(`¿${amount >= 0 ? 'Añadir' : 'Quitar'} ${Math.abs(amount)} coins?`)) return;
  
  try {
    if (amount > 0) {
      const result = await window.kvrcards.addCoins(amount);
      if (result.error) {
        alert('❌ Error: ' + result.error);
        return;
      }
    } else if (amount < 0) {
      const wallet = await window.kvrcards.getWallet();
      const newAmount = Math.max(0, (wallet.coins || 0) + amount);
      const diff = (wallet.coins || 0) - newAmount;
      if (diff > 0) {
        // No hay API directa para quitar, así que usamos compra de sobres (hack temporal)
        alert('⚠️ No se pueden quitar monedas directamente. Usa el sistema de compras.');
        return;
      }
    }
    
    await renderWallet();
    alert(`✅ ${amount >= 0 ? 'Añadidos' : 'Quitados'} ${Math.abs(amount)} coins`);
  } catch (e) {
    console.error('[DEBUG] Error modificando coins:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Modificar KVR
async function debugModifyKVR(amount) {
  if (!confirm(`¿${amount >= 0 ? 'Añadir' : 'Quitar'} ${Math.abs(amount)} KVR?`)) return;
  
  try {
    if (amount > 0) {
      const result = await window.kvrcards.addKvR(amount);
      if (result.error) {
        alert('❌ Error: ' + result.error);
        return;
      }
    } else if (amount < 0) {
      alert('⚠️ No se pueden quitar KVR directamente. Usa el sistema de compras.');
      return;
    }
    
    await renderWallet();
    alert(`✅ ${amount >= 0 ? 'Añadidos' : 'Quitados'} ${Math.abs(amount)} KVR`);
  } catch (e) {
    console.error('[DEBUG] Error modificando KVR:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Modificar Traits
async function debugModifyTraits(amount) {
  if (!confirm(`¿${amount >= 0 ? 'Añadir' : 'Quitar'} ${Math.abs(amount)} Traits?`)) return;
  
  try {
    // Usamos una llamada IPC personalizada para debug de traits
    // Como no existe addTraits en la API pública, usaremos una llamada directa si es posible
    // O implementaremos un método temporal en el backend
    
    const result = await window.kvrcards.debugModifyTraits(amount);
    
    if (result.error) {
      alert('❌ Error: ' + result.error);
      return;
    }
    
    await renderWallet();
    // Actualizar también el panel de traits si está abierto
    if (document.getElementById('traits-panel').style.display === 'block') {
      await renderTraitsPanel();
    }
    
    alert(`✅ ${amount >= 0 ? 'Añadidos' : 'Quitados'} ${Math.abs(amount)} Traits`);
  } catch (e) {
    console.error('[DEBUG] Error modificando Traits:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Modificar Infinite Coins
async function debugModifyInfiniteCoins(amount) {
  if (!confirm(`¿${amount >= 0 ? 'Añadir' : 'Quitar'} ${Math.abs(amount)} Infinite Coins?`)) return;
  
  try {
    const current = Number(localStorage.getItem('INFINITE_CURRENCY_COINS') || '0') || 0;
    let wallet = {};
    if (window.kvrcards && typeof window.kvrcards.getWallet === 'function') {
      wallet = await window.kvrcards.getWallet() || {};
    }
    const currentWallet = Number(wallet['infinite-coins']) || current;
    const newAmount = Math.max(0, currentWallet + amount);

    localStorage.setItem('INFINITE_CURRENCY_COINS', String(newAmount));

    if (window.kvrcards && typeof window.kvrcards.walletUpdateInfiniteCurrencies === 'function') {
      await window.kvrcards.walletUpdateInfiniteCurrencies({ 'infinite-coins': newAmount });
    }
    
    await renderWallet();
    alert(`✅ ${amount >= 0 ? 'Añadidos' : 'Quitados'} ${Math.abs(amount)} Infinite Coins (Total: ${newAmount})`);
  } catch (e) {
    console.error('[DEBUG] Error modificando Infinite Coins:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Modificar Infinite Cardpoints
async function debugModifyInfiniteCardpoints(amount) {
  if (!confirm(`¿${amount >= 0 ? 'Añadir' : 'Quitar'} ${Math.abs(amount)} Infinite Cardpoints?`)) return;
  
  try {
    const current = Number(localStorage.getItem('INFINITE_CURRENCY_CARDPOINTS') || '0') || 0;
    let wallet = {};
    if (window.kvrcards && typeof window.kvrcards.getWallet === 'function') {
      wallet = await window.kvrcards.getWallet() || {};
    }
    const currentWallet = Number(wallet['infinite-cardpoints']) || current;
    const newAmount = Math.max(0, currentWallet + amount);

    localStorage.setItem('INFINITE_CURRENCY_CARDPOINTS', String(newAmount));

    if (window.kvrcards && typeof window.kvrcards.walletUpdateInfiniteCurrencies === 'function') {
      await window.kvrcards.walletUpdateInfiniteCurrencies({ 'infinite-cardpoints': newAmount });
    }
    
    await renderWallet();
    alert(`✅ ${amount >= 0 ? 'Añadidos' : 'Quitados'} ${Math.abs(amount)} Infinite Cardpoints (Total: ${newAmount})`);
  } catch (e) {
    console.error('[DEBUG] Error modificando Infinite Cardpoints:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Resetear misiones
async function debugResetMissions() {
  if (!confirm('⚠️ ¿Resetear TODAS las misiones? Se perderá el progreso y recompensas reclamadas.')) return;
  
  try {
    // Resetear en localStorage
    localStorage.removeItem('kvr_user_missions');
    userMissions = {};
    
    // Sincronizar con servidor
    const result = await window.kvrcards.saveMissionsState({});
    if (result.error) {
      alert('❌ Error sincronizando: ' + result.error);
      return;
    }
    
    // Recargar estado desde servidor y renderizar
    await loadUserMissionsState();
    await renderMissions();
    alert('✅ Misiones reseteadas correctamente');
  } catch (e) {
    console.error('[DEBUG] Error reseteando misiones:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Completar todas las misiones
async function debugCompleteMissions() {
  if (!confirm('¿Completar TODAS las misiones disponibles?')) return;
  
  try {
    await loadMissions();
    availableMissions.forEach(mission => {
      if (!userMissions[mission.id]) {
        userMissions[mission.id] = {};
      }
      userMissions[mission.id].completed = true;
      userMissions[mission.id].progress = mission.requirements?.value || 1;
    });
    
    // Guardar en localStorage
    localStorage.setItem('kvr_user_missions', JSON.stringify(userMissions));
    
    // Sincronizar con servidor
    const result = await window.kvrcards.saveMissionsState(userMissions);
    if (result.error) {
      alert('❌ Error sincronizando: ' + result.error);
      return;
    }
    
    // Recargar estado desde servidor y renderizar
    await loadUserMissionsState();
    await renderMissions();
    alert('✅ Todas las misiones completadas (no reclamadas)');
  } catch (e) {
    console.error('[DEBUG] Error completando misiones:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Resetear kizunas
async function debugResetKizunas() {
  if (!confirm('⚠️ ¿Resetear TODOS los kizunas? Se perderá el progreso y recompensas reclamadas.')) return;
  
  try {
    localStorage.removeItem('kvr_user_kizunas');
    userKizunas = {};
    await renderKizunas();
    alert('✅ Kizunas reseteados correctamente');
  } catch (e) {
    console.error('[DEBUG] Error reseteando kizunas:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Completar todos los kizunas
async function debugCompleteKizunas() {
  if (!confirm('¿Completar TODOS los kizunas? (Añadir todas las cartas necesarias)')) return;
  
  try {
    await loadKizunas();
    
    // Añadir todas las cartas de todos los kizunas usando addCard
    for (const kizuna of availableKizunas) {
      for (const cardId of kizuna.cardIds) {
        const result = await window.kvrcards.addCard(cardId);
        if (result.error) {
          console.error(`Error añadiendo carta ${cardId}:`, result.error);
        }
      }
    }
    
    await syncInventoryToR2();
    await renderKizunas();
    alert('✅ Todos los kizunas completados (cartas añadidas)');
  } catch (e) {
    console.error('[DEBUG] Error completando kizunas:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Resetear títulos
async function debugResetTitles() {
  if (!confirm('⚠️ ¿Resetear todos los títulos? Solo quedarás con "Novato".')) return;
  
  try {
    if (userProfile) {
      userProfile.unlockedTitles = ['novato'];
      userProfile.title = 'Novato';
      userProfile.currentTitle = 'Novato';
      saveUserProfile();
      updateProfileDisplay();
      alert('✅ Títulos reseteados correctamente');
    }
  } catch (e) {
    console.error('[DEBUG] Error reseteando títulos:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Desbloquear todos los títulos
async function debugUnlockAllTitles() {
  if (!confirm('¿Desbloquear TODOS los títulos disponibles?')) return;
  
  try {
    await loadTitles();
    if (userProfile && availableTitles && availableTitles.length > 0) {
      userProfile.unlockedTitles = availableTitles.map(t => t.id);
      saveUserProfile();
      updateProfileDisplay();
      alert(`✅ ${availableTitles.length} títulos desbloqueados correctamente`);
    } else {
      alert('⚠️ No se pudieron cargar los títulos');
    }
  } catch (e) {
    console.error('[DEBUG] Error desbloqueando títulos:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Reset total
// ==================== DEBUG: PODERES ====================

// Añadir poder
async function debugAddPower(powerId, isPermanent, uses = 1) {
  const powerName = availablePowers.find(p => p.id === powerId)?.name || powerId;
  const typeText = isPermanent ? 'permanente' : `${uses} uso(s)`;
  
  if (!confirm(`¿Añadir poder "${powerName}" (${typeText})?`)) return;
  
  try {
    if (isPermanent) {
      // Añadir como permanente (solo una vez)
      const result = await window.kvrcards.addPower(powerId);
      if (result.error) {
        alert('❌ Error: ' + result.error);
        return;
      }
      if (result.alreadyOwned) {
        alert('⚠️ Ya tienes este poder permanente');
        return;
      }
    } else {
      // Añadir usos consumibles
      for (let i = 0; i < uses; i++) {
        const result = await window.kvrcards.addPower(powerId);
        if (result.error) {
          alert(`❌ Error en uso ${i + 1}/${uses}: ${result.error}`);
          return;
        }
      }
    }
    
    // Recargar inventario de poderes
    await loadPowers();
    alert(`✅ Poder "${powerName}" añadido correctamente`);
  } catch (e) {
    console.error('[DEBUG] Error añadiendo poder:', e);
    alert('❌ Error: ' + e.message);
  }
}

// Eliminar poder
async function debugRemovePower(powerId) {
  const powerName = availablePowers.find(p => p.id === powerId)?.name || powerId;
  
  if (!confirm(`¿Eliminar TODOS los usos del poder "${powerName}"?`)) return;
  
  try {
    const inv = await window.kvrcards.getPowersInventory();
    if (!inv.ok || !inv.powers[powerId]) {
      alert('⚠️ No tienes este poder en tu inventario');
      return;
    }
    
    const powerData = inv.powers[powerId];
    const isPermanent = powerData.permanent === true;
    const uses = powerData.uses || 0;
    
    if (isPermanent) {
      // Eliminar permanente (solo existe una vez, pero usamos el mismo IPC)
      const result = await window.kvrcards.usePower(powerId);
      if (result.error) {
        alert('❌ Error: ' + result.error);
        return;
      }
    } else {
      // Eliminar todos los usos consumibles
      for (let i = 0; i < uses; i++) {
        const result = await window.kvrcards.usePower(powerId);
        if (result.error && !result.error.includes('No tienes')) {
          alert(`❌ Error eliminando uso ${i + 1}/${uses}: ${result.error}`);
          break;
        }
      }
    }
    
    // Recargar inventario de poderes
    await loadPowers();
    alert(`✅ Poder "${powerName}" eliminado correctamente`);
  } catch (e) {
    console.error('[DEBUG] Error eliminando poder:', e);
    alert('❌ Error: ' + e.message);
  }
}

async function debugAdjustPrestigeXP(cardId, amount) {
  const normalizedId = normalizePrestigeCardId(cardId);
  const delta = Number(amount) || 0;
  if (!normalizedId || delta === 0) return;

  const store = loadPrestigeProgressStore();
  const current = store[normalizedId] && typeof store[normalizedId] === 'object'
    ? store[normalizedId]
    : { battlesPlayed: 0, battlesWon: 0, battleXp: 0, missionXp: 0 };

  current.battlesPlayed = Math.max(0, Number(current.battlesPlayed) || 0);
  current.battlesWon = Math.max(0, Number(current.battlesWon) || 0);
  current.missionXp = Math.max(0, Number(current.missionXp) || 0);
  current.battleXp = Math.max(0, (Number(current.battleXp) || 0) + Math.floor(delta));
  current.updatedAt = Date.now();

  store[normalizedId] = current;
  savePrestigeProgressStore(store);

  await renderCollection();
}

async function debugResetAllPrestige() {
  if (!confirm('⚠️ ¿Resetear todos los prestigios a 0 XP?')) return;
  savePrestigeProgressStore({});
  await renderCollection();
  alert('✅ Todos los prestigios fueron reseteados a 0');
}

async function debugCompleteAllPrestige() {
  if (!confirm('¿Completar todos los prestigios de tus cartas actuales?')) return;

  const inv = await window.kvrcards.getInventory();
  if (!inv?.ok) {
    alert('❌ No se pudo leer inventario');
    return;
  }

  const cardIds = Object.entries(inv.cards || {})
    .filter(([, count]) => Number(count) > 0)
    .map(([id]) => String(id));

  const cfg = await getPrestigeConfig();
  const store = loadPrestigeProgressStore();

  cardIds.forEach((cardId) => {
    const profile = resolvePrestigeProfile(cfg, { id: cardId });
    const thresholds = getPrestigeThresholds(profile?.levels || []);
    const maxRequiredXp = thresholds.length > 0 ? Math.max(...thresholds) : PRESTIGE_XP_THRESHOLDS[PRESTIGE_XP_THRESHOLDS.length - 1];

    store[cardId] = {
      battlesPlayed: 999,
      battlesWon: 999,
      battleXp: Math.max(0, Number(maxRequiredXp) || 0),
      missionXp: 0,
      updatedAt: Date.now()
    };
  });

  savePrestigeProgressStore(store);
  await renderCollection();
  alert(`✅ Prestigio completado para ${cardIds.length} carta(s)`);
}

// ==================== FIN DEBUG PODERES ====================

async function debugResetAll() {
  if (!confirm('⚠️⚠️⚠️ ATENCIÓN: Esto reseteará TODO el progreso (misiones, kizunas, títulos).\n\n¿Estás COMPLETAMENTE seguro?')) return;
  if (!confirm('❌ ÚLTIMA CONFIRMACIÓN: Se perderá TODO el progreso de coleccionables. ¿Continuar?')) return;
  
  try {
    // Resetear misiones
    localStorage.removeItem('kvr_user_missions');
    userMissions = {};
    
    // Resetear kizunas
    localStorage.removeItem('kvr_user_kizunas');
    userKizunas = {};
    
    // Resetear títulos
    if (userProfile) {
      userProfile.unlockedTitles = ['novato'];
      userProfile.title = 'Novato';
      userProfile.currentTitle = 'Novato';
      saveUserProfile();
    }
    
    // Resetear evoluciones
    try {
      if (typeof userEvolutions !== 'undefined') {
        for (const k of Object.keys(userEvolutions)) delete userEvolutions[k];
      }
      if (window.userEvolutions) {
        for (const k of Object.keys(window.userEvolutions)) delete window.userEvolutions[k];
      }
      localStorage.removeItem('kvr_user_evolutions_v2');
      if (window.kvrcards?.saveEvolutionState) {
        await window.kvrcards.saveEvolutionState({});
      }
      if (typeof renderEvolutions === 'function') {
        await renderEvolutions();
      }
    } catch (evoErr) {
      console.warn('[DEBUG] Error reseteando evoluciones en reset total:', evoErr);
    }
    
    // Refrescar UI
    await renderMissions();
    await renderKizunas();
    updateProfileDisplay();
    
    alert('✅ TODO reseteado correctamente');
  } catch (e) {
    console.error('[DEBUG] Error en reset total:', e);
    alert('❌ Error: ' + e.message);
  }
}

// ==================== DEBUG: EVOLUCIONES ====================

async function debugEnsureEvolutionsLoaded() {
  if (typeof loadEvolutions === 'function') {
    const list = (typeof availableEvolutions !== 'undefined' ? availableEvolutions : (window.availableEvolutions || []));
    if (!list || list.length === 0) {
      await loadEvolutions();
    }
  }
  if (typeof loadUserEvolutionsState === 'function') {
    await loadUserEvolutionsState();
  }
  return {
    evolutions: (typeof availableEvolutions !== 'undefined' ? availableEvolutions : (window.availableEvolutions || [])),
    state: (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}))
  };
}

async function debugAutoStartEvolution(evolution, silent = false) {
  const state = (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}));
  const evoState = state[evolution.id];
  if (evoState && evoState.started && !evoState.claimedAt) {
    return evoState;
  }

  let cardId = null;
  let cardOption = null;

  if (Array.isArray(evolution.cardOptions) && evolution.cardOptions.length > 0) {
    cardOption = evolution.cardOptions[0];
    cardId = cardOption.cardFrom;
  } else if (Array.isArray(evolution.cardFrom) && evolution.cardFrom.length > 0) {
    cardId = evolution.cardFrom[0];
  } else {
    cardId = evolution.cardFrom;
  }

  if (!cardId) {
    throw new Error(`No se pudo determinar la carta base para "${evolution.name || evolution.id}"`);
  }

  // Asegurar que la carta base esté en el inventario
  try {
    if (window.kvrcards?.getInventory) {
      const inv = await window.kvrcards.getInventory();
      if (!inv?.cards || !inv.cards[cardId] || inv.cards[cardId] <= 0) {
        await window.kvrcards.addCard(cardId);
      }
    }
  } catch (err) {
    console.warn('[DEBUG] Error asegurando carta base:', err);
  }

  const startFn = (typeof startEvolution === 'function') ? startEvolution : window.startEvolution;
  if (startFn) {
    startFn(evolution, cardId, cardOption, silent);
  }

  return (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}))[evolution.id];
}

async function debugCompleteEvolutionMissions(evolutionId) {
  const { evolutions, state } = await debugEnsureEvolutionsLoaded();
  const evoId = evolutionId || document.getElementById('debug-evolution-select')?.value;
  const evolution = evolutions.find(e => e.id === evoId);
  if (!evolution) {
    alert('❌ Selecciona una evolución válida.');
    return;
  }

  let progress = state[evolution.id];
  if (!progress || !progress.started || progress.claimedAt) {
    const startIt = confirm(`La evolución "${evolution.name}" no está iniciada. ¿Deseas iniciarla automáticamente?`);
    if (!startIt) return;
    progress = await debugAutoStartEvolution(evolution, true);
  }

  if (!progress || !progress.started) {
    alert('❌ No se pudo iniciar la evolución.');
    return;
  }

  const phasesFn = (typeof getEvolutionPhases === 'function') ? getEvolutionPhases : window.getEvolutionPhases;
  const phases = phasesFn ? phasesFn(evolution, progress) : [];
  const currentPhaseIndex = Math.max(0, (progress.currentPhase || 1) - 1);
  const currentPhaseData = phases[currentPhaseIndex] || phases[0] || {};
  const missions = currentPhaseData.missions || [];

  if (!progress.missionsCompleted) progress.missionsCompleted = {};
  if (!progress.missionsProgress) progress.missionsProgress = {};

  missions.forEach(mission => {
    progress.missionsCompleted[mission.id] = true;
    const targetValue = mission.target || 
      (Array.isArray(mission.requirements) ? mission.requirements[0]?.amount : null) || 
      (Array.isArray(mission.requirement) ? mission.requirement[0]?.amount : null) || 
      mission.requirement?.amount || 1;
    progress.missionsProgress[mission.id] = {
      current: targetValue,
      target: targetValue,
      completed: true
    };
  });

  const saveFn = (typeof saveUserEvolutionsState === 'function') ? saveUserEvolutionsState : window.saveUserEvolutionsState;
  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (saveFn) await saveFn();
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  alert(`🎯 ¡Misiones de la Fase ${progress.currentPhase}/${progress.totalPhases || phases.length} completadas al 100%! Ya puedes reclamar o avanzar la fase.`);
}

async function debugAdvanceEvolutionPhase(evolutionId, silent = false) {
  const { evolutions, state } = await debugEnsureEvolutionsLoaded();
  const evoId = evolutionId || document.getElementById('debug-evolution-select')?.value;
  const evolution = evolutions.find(e => e.id === evoId);
  if (!evolution) {
    if (!silent) alert('❌ Selecciona una evolución válida.');
    return;
  }

  let progress = state[evolution.id];
  if (!progress || !progress.started || progress.claimedAt) {
    progress = await debugAutoStartEvolution(evolution, true);
  }

  if (!progress || !progress.started) {
    if (!silent) alert('❌ No se pudo iniciar la evolución.');
    return;
  }

  const phasesFn = (typeof getEvolutionPhases === 'function') ? getEvolutionPhases : window.getEvolutionPhases;
  const phases = phasesFn ? phasesFn(evolution, progress) : [];
  const currentPhaseIndex = Math.max(0, (progress.currentPhase || 1) - 1);
  const currentPhaseData = phases[currentPhaseIndex] || phases[0] || {};
  const missions = currentPhaseData.missions || [];

  if (!progress.missionsCompleted) progress.missionsCompleted = {};
  if (!progress.missionsProgress) progress.missionsProgress = {};

  missions.forEach(mission => {
    progress.missionsCompleted[mission.id] = true;
    const targetValue = mission.target || 
      (Array.isArray(mission.requirements) ? mission.requirements[0]?.amount : null) || 
      (Array.isArray(mission.requirement) ? mission.requirement[0]?.amount : null) || 
      mission.requirement?.amount || 1;
    progress.missionsProgress[mission.id] = {
      current: targetValue,
      target: targetValue,
      completed: true
    };
  });

  // Asegurar que la carta activa esté en el inventario para que el intercambio no falle
  if (progress.cardId && window.kvrcards?.getInventory) {
    try {
      const inv = await window.kvrcards.getInventory();
      if (!inv?.cards || !inv.cards[progress.cardId] || inv.cards[progress.cardId] <= 0) {
        await window.kvrcards.addCard(progress.cardId);
      }
    } catch (err) {
      console.warn('[DEBUG] Error asegurando carta en inventario:', err);
    }
  }

  const prevPhaseNum = progress.currentPhase || 1;
  const isFinalPhase = prevPhaseNum >= (progress.totalPhases || phases.length);

  const claimFn = (typeof claimEvolution === 'function') ? claimEvolution : window.claimEvolution;
  if (claimFn) {
    await claimFn(evolution, progress, silent);
  }

  const saveFn = (typeof saveUserEvolutionsState === 'function') ? saveUserEvolutionsState : window.saveUserEvolutionsState;
  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (saveFn) await saveFn();
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  if (!silent) {
    if (isFinalPhase) {
      alert(`🎉 ¡Evolución "${evolution.name}" completada al 100%!`);
    } else {
      alert(`⏩ ¡Fase ${prevPhaseNum} superada! La evolución avanza a la Fase ${prevPhaseNum + 1}.`);
    }
  }
}

async function debugCompleteFullEvolution(evolutionId) {
  const { evolutions } = await debugEnsureEvolutionsLoaded();
  const evoId = evolutionId || document.getElementById('debug-evolution-select')?.value;
  const evolution = evolutions.find(e => e.id === evoId);
  if (!evolution) {
    alert('❌ Selecciona una evolución válida.');
    return;
  }

  if (!confirm(`¿Completar TODAS las fases de la evolución "${evolution.name}"?`)) return;

  let progress = (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}))[evolution.id];
  if (!progress || !progress.started || progress.claimedAt) {
    progress = await debugAutoStartEvolution(evolution, true);
  }

  let iterations = 0;
  while (iterations < 20) {
    iterations++;
    progress = (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}))[evolution.id];
    if (!progress || !progress.started || progress.claimedAt) break;

    const phasesFn = (typeof getEvolutionPhases === 'function') ? getEvolutionPhases : window.getEvolutionPhases;
    const phases = phasesFn ? phasesFn(evolution, progress) : [];
    const isFinalPhase = (progress.currentPhase || 1) >= (progress.totalPhases || phases.length);

    await debugAdvanceEvolutionPhase(evolution.id, true);

    if (isFinalPhase) break;
  }

  const saveFn = (typeof saveUserEvolutionsState === 'function') ? saveUserEvolutionsState : window.saveUserEvolutionsState;
  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (saveFn) await saveFn();
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  alert(`🌟 ¡Evolución "${evolution.name}" completada al 100%! Todas las cartas y fases han sido otorgadas.`);
}

async function debugResetEvolution(evolutionId) {
  const { evolutions, state } = await debugEnsureEvolutionsLoaded();
  const evoId = evolutionId || document.getElementById('debug-evolution-select')?.value;
  const evolution = evolutions.find(e => e.id === evoId);
  if (!evolution) {
    alert('❌ Selecciona una evolución válida.');
    return;
  }

  if (!confirm(`¿Resetear el progreso de la evolución "${evolution.name}"?`)) return;

  delete state[evolution.id];
  if (typeof userEvolutions !== 'undefined') delete userEvolutions[evolution.id];
  if (window.userEvolutions) delete window.userEvolutions[evolution.id];

  const saveFn = (typeof saveUserEvolutionsState === 'function') ? saveUserEvolutionsState : window.saveUserEvolutionsState;
  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (saveFn) await saveFn();
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  alert(`🔄 Evolución "${evolution.name}" reseteada correctamente.`);
}

async function debugCompleteAllActiveEvolutionPhases() {
  const { evolutions, state } = await debugEnsureEvolutionsLoaded();
  const activeEvos = evolutions.filter(e => state[e.id]?.started && !state[e.id]?.claimedAt);

  if (activeEvos.length === 0) {
    alert('⚠️ No hay ninguna evolución activa actualmente.');
    return;
  }

  if (!confirm(`¿Avanzar una fase en las ${activeEvos.length} evolución(es) activa(s)?`)) return;

  for (const evo of activeEvos) {
    await debugAdvanceEvolutionPhase(evo.id, true);
  }

  const saveFn = (typeof saveUserEvolutionsState === 'function') ? saveUserEvolutionsState : window.saveUserEvolutionsState;
  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (saveFn) await saveFn();
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  alert(`✅ Fase avanzada con éxito en ${activeEvos.length} evolución(es) activa(s).`);
}

async function debugCompleteAllEvolutions() {
  const { evolutions } = await debugEnsureEvolutionsLoaded();
  if (!evolutions || evolutions.length === 0) {
    alert('⚠️ No hay evoluciones disponibles.');
    return;
  }

  if (!confirm(`⚠️ ¿Completar al 100% TODAS las evoluciones (${evolutions.length}) del juego?`)) return;

  for (const evo of evolutions) {
    let progress = (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}))[evo.id];
    if (!progress || !progress.started || progress.claimedAt) {
      progress = await debugAutoStartEvolution(evo, true);
    }

    let iterations = 0;
    while (iterations < 20) {
      iterations++;
      progress = (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}))[evo.id];
      if (!progress || !progress.started || progress.claimedAt) break;

      const phasesFn = (typeof getEvolutionPhases === 'function') ? getEvolutionPhases : window.getEvolutionPhases;
      const phases = phasesFn ? phasesFn(evo, progress) : [];
      const isFinalPhase = (progress.currentPhase || 1) >= (progress.totalPhases || phases.length);

      await debugAdvanceEvolutionPhase(evo.id, true);
      if (isFinalPhase) break;
    }
  }

  const saveFn = (typeof saveUserEvolutionsState === 'function') ? saveUserEvolutionsState : window.saveUserEvolutionsState;
  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (saveFn) await saveFn();
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  alert(`🏆 ¡Todas las evoluciones (${evolutions.length}) han sido completadas al 100%!`);
}

async function debugResetAllEvolutions() {
  if (!confirm('⚠️ ¿Resetear el estado de TODAS las evoluciones? Se borrará todo el progreso de evoluciones.')) return;

  if (typeof userEvolutions !== 'undefined') {
    for (const key of Object.keys(userEvolutions)) delete userEvolutions[key];
  }
  if (window.userEvolutions) {
    for (const key of Object.keys(window.userEvolutions)) delete window.userEvolutions[key];
  }

  if (window.kvrcards?.saveEvolutionState) {
    await window.kvrcards.saveEvolutionState({});
  }
  localStorage.removeItem('kvr_user_evolutions_v2');

  const renderFn = (typeof renderEvolutions === 'function') ? renderEvolutions : window.renderEvolutions;
  if (renderFn) await renderFn();

  updateDebugEvolutionInfo();
  populateDebugEvolutionsSelect();

  alert('🔄 Todas las evoluciones han sido reseteadas correctamente.');
}

async function populateDebugEvolutionsSelect() {
  const select = document.getElementById('debug-evolution-select');
  if (!select) return;

  const { evolutions, state } = await debugEnsureEvolutionsLoaded();
  const currentVal = select.value;

  select.innerHTML = '';
  if (!evolutions || evolutions.length === 0) {
    select.innerHTML = '<option value="">No hay evoluciones disponibles</option>';
    updateDebugEvolutionInfo();
    return;
  }

  evolutions.forEach(evo => {
    const opt = document.createElement('option');
    opt.value = evo.id;
    const p = state[evo.id];
    let tag = '⚪ No iniciada';
    if (p?.claimedAt) {
      tag = '✅ Completada';
    } else if (p?.started) {
      tag = `⚡ Activa (Fase ${p.currentPhase || 1}/${p.totalPhases || '?'})`;
    }
    opt.textContent = `${evo.name || evo.id} [${tag}]`;
    select.appendChild(opt);
  });

  if (currentVal && Array.from(select.options).some(o => o.value === currentVal)) {
    select.value = currentVal;
  }

  updateDebugEvolutionInfo();
}

function updateDebugEvolutionInfo() {
  const select = document.getElementById('debug-evolution-select');
  const infoBox = document.getElementById('debug-evolution-info');
  if (!select || !infoBox) return;

  const evoId = select.value;
  const evos = (typeof availableEvolutions !== 'undefined' ? availableEvolutions : (window.availableEvolutions || []));
  const evo = evos.find(e => e.id === evoId);
  const state = (typeof userEvolutions !== 'undefined' ? userEvolutions : (window.userEvolutions || {}));

  if (!evo) {
    infoBox.innerHTML = '<em>Selecciona una evolución para ver su estado</em>';
    return;
  }

  const p = state[evo.id];
  let statusBadge = '<span style="color:#9ca3af; font-weight:bold;">⚪ No iniciada</span>';
  if (p?.claimedAt) {
    statusBadge = '<span style="color:#10b981; font-weight:bold;">✅ Completada</span>';
  } else if (p?.started) {
    statusBadge = `<span style="color:#eab308; font-weight:bold;">⚡ Activa (Fase ${p.currentPhase || 1} de ${p.totalPhases || '?'})</span>`;
  }

  const phasesFn = (typeof getEvolutionPhases === 'function') ? getEvolutionPhases : window.getEvolutionPhases;
  const phases = phasesFn ? phasesFn(evo, p || {}) : [];
  const currentPhaseIndex = Math.max(0, (p?.currentPhase || 1) - 1);
  const currentPhase = phases[currentPhaseIndex] || phases[0] || {};
  const missions = currentPhase.missions || [];

  let missionsHtml = '';
  if (p?.started && missions.length > 0) {
    missionsHtml = '<div style="margin-top:6px; font-size:12px; color:#cbd5e1;"><strong>Misiones de esta fase:</strong><ul style="margin:4px 0 0 16px; padding:0;">';
    missions.forEach(m => {
      const isDone = p.missionsCompleted?.[m.id];
      const prog = p.missionsProgress?.[m.id]?.current || 0;
      const target = p.missionsProgress?.[m.id]?.target || m.target || 1;
      missionsHtml += `<li>${isDone ? '✅' : '⏳'} ${m.name || m.description || m.id}: ${prog}/${target} ${isDone ? '(Completada)' : ''}</li>`;
    });
    missionsHtml += '</ul></div>';
  }

  infoBox.innerHTML = `
    <div><strong>Evolución:</strong> ${evo.name || evo.id} <span style="font-size:11px; color:#aaa;">(${evo.id})</span></div>
    <div><strong>Estado:</strong> ${statusBadge} ${p?.completionsCount ? `| Completada ${p.completionsCount} vez/veces` : ''}</div>
    ${p?.started ? `
      <div><strong>Carta actual:</strong> <code style="background:#0f172a; padding:1px 4px; border-radius:3px;">${p.cardId || '-'}</code> &nbsp;➔&nbsp; <strong>Objetivo de fase:</strong> <code style="background:#0f172a; padding:1px 4px; border-radius:3px;">${p.targetCardTo || '-'}</code></div>
      <div><strong>Fase actual:</strong> ${currentPhase.name || `Fase ${currentPhaseIndex + 1}`} (${currentPhaseIndex + 1}/${phases.length})</div>
      ${missionsHtml}
    ` : `
      <div style="font-size:12px; color:#888;">Fases totales: ${phases.length} | Carta(s) base: ${Array.isArray(evo.cardFrom) ? evo.cardFrom.join(', ') : (evo.cardFrom || 'Opciones múltiples')}</div>
    `}
  `;
}

// Exponer funciones debug en window
window.debugCompleteEvolutionMissions = debugCompleteEvolutionMissions;
window.debugAdvanceEvolutionPhase = debugAdvanceEvolutionPhase;
window.debugCompleteFullEvolution = debugCompleteFullEvolution;
window.debugResetEvolution = debugResetEvolution;
window.debugCompleteAllActiveEvolutionPhases = debugCompleteAllActiveEvolutionPhases;
window.debugCompleteAllEvolutions = debugCompleteAllEvolutions;
window.debugResetAllEvolutions = debugResetAllEvolutions;
window.populateDebugEvolutionsSelect = populateDebugEvolutionsSelect;
window.updateDebugEvolutionInfo = updateDebugEvolutionInfo;
