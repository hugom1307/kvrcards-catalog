window.activeCollectionContainer = null;
window.activeCollectionCardClick = null;
window.activeCollectionSelectionState = null;

var cardUpgradesMap = {};

function openLightbox(src, card = null, userOwns = false, traitId = null, instanceId = null, inventoryCount = 0, isUnowned = false, forceFullColor = false) {
  if (!src) return;
  lightboxImg.src = src;

  const shouldBeUnowned = !forceFullColor && Boolean(isUnowned || (card && !userOwns && showCompleteCollection));
  if (shouldBeUnowned) {
    lightboxImg.classList.add('unowned');
  } else {
    lightboxImg.classList.remove('unowned');
  }
  
  // Limpiar información de traits previa
  const lightboxContent = lightbox?.querySelector('.lightbox-content');
  const existingTraitInfo = lightboxContent?.querySelector('.trait-lightbox-info');
  if (existingTraitInfo) existingTraitInfo.remove();
  const existingInventoryInfo = lightboxContent?.querySelector('.inventory-card-meta');
  if (existingInventoryInfo) existingInventoryInfo.remove();
  const existingPrestigePanel = document.querySelector('.inventory-prestige-panel');
  if (existingPrestigePanel) existingPrestigePanel.remove();
  lightboxContent?.classList.remove('lightbox-inventory-layout');
  
  // Mostrar información del trait si existe (ANTES de añadir la imagen)
  if (traitId && typeof availableTraits !== 'undefined') {
    const trait = availableTraits.find(t => t.id === traitId);
    if (trait) {
      const traitInfo = document.createElement('div');
      traitInfo.className = 'trait-lightbox-info';
      traitInfo.style.cssText = 'margin-bottom: 5px; padding: 10px; background: rgba(0,0,0,0.8); border: 2px solid #fbbf24; border-radius: 12px; color: #fff;';
      
      traitInfo.innerHTML = `
        <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 10px;">
          <img src="${trait.imageUrl}" style="width: 64px; height: 64px; border: 2px solid #fbbf24; border-radius: 8px; background: rgba(0,0,0,0.5); padding: 5px;">
          <div style="text-align: left; flex: 1;">
            <h3 style="margin: 0 0 5px 0; color: #fbbf24; font-size: 20px;">${trait.name}</h3>
            <p style="margin: 0; font-size: 14px; color: #ccc;">${trait.description}</p>
          </div>
        </div>
        ${trait.stats ? `<div style="font-size: 14px; color: #fbbf24; font-weight: bold; text-align: center;">
          ${Object.entries(trait.stats).map(([stat, val]) => `${stat}: +${val}`).join(' | ')}
        </div>` : ''}
      `;
      
      // Insertar ANTES de la imagen
      lightboxContent.insertBefore(traitInfo, lightboxImg);
    }
  }

  if (card && userOwns && lightboxContent) {
    const inventoryCardMeta = document.createElement('div');
    inventoryCardMeta.className = 'inventory-card-meta';

    const provenance = String(card.procedencia || card.source || card.origen || 'Desconocida').trim();
    const owner = String(card.owner || 'Desconocido').trim();
    const prestigeData = getInventoryPrestigeData(inventoryCount, PRESTIGE_XP_THRESHOLDS, card.id);
    const duplicateXp = typeof getDuplicatePrestigeXp === 'function'
      ? getDuplicatePrestigeXp(card)
      : (typeof getCardQualityCategory === 'function' && getCardQualityCategory(card) === 'bronce'
        ? 100
        : (typeof getCardQualityCategory === 'function' && getCardQualityCategory(card) === 'plata' ? 250 : 500));

    let upgradeRow = '';
    if (card.bonus && card.bonus > 0) {
      upgradeRow = `
        <div class="inventory-card-meta-row" style="color: #fbbf24; font-weight: bold;">
          <span class="inventory-card-meta-label" style="color: #fbbf24;">Mejora</span>
          <span class="inventory-card-meta-value" style="color: #fbbf24;">+${card.bonus} Media</span>
        </div>
      `;
    }

    inventoryCardMeta.innerHTML = `
      <div class="inventory-card-meta-title">Datos de inventario</div>
      ${upgradeRow}
      <div class="inventory-card-meta-row">
        <span class="inventory-card-meta-label">Procedencia</span>
        <span class="inventory-card-meta-value">${provenance}</span>
      </div>
      <div class="inventory-card-meta-row">
        <span class="inventory-card-meta-label">Owner</span>
        <span class="inventory-card-meta-value">${owner}</span>
      </div>
      <div class="inventory-card-meta-row inventory-prestige-block">
        <span class="inventory-card-meta-label">Nivel de prestigio</span>
        <span class="inventory-card-meta-value">Prestigio ${prestigeData.level}</span>
      </div>
      <div class="inventory-prestige-bar" aria-hidden="true">
        <div class="inventory-prestige-bar-fill" style="width: ${prestigeData.progress}%;"></div>
      </div>
    `;

    const prestigePanel = document.createElement('div');
    prestigePanel.className = 'inventory-prestige-panel';
    prestigePanel.innerHTML = `
      <button type="button" class="inventory-prestige-trigger">Prestigio</button>
      <div class="inventory-prestige-dropdown">
        <div class="inventory-prestige-modal">
          <div class="inventory-prestige-overlay-head">
            <div class="inventory-prestige-overlay-title">Panel de Prestigio</div>
            <button type="button" class="inventory-prestige-close" aria-label="Cerrar panel de prestigio">×</button>
          </div>
          <div class="inventory-prestige-dropdown-inner">
            <div class="inventory-prestige-card-thumb">
              <img src="${src}" alt="${card.name || 'Carta'}">
            </div>
            <div class="inventory-prestige-progress-wrap">
              <div class="inventory-prestige-progress-header">
                <span class="inventory-prestige-current-label">Prestigio ${prestigeData.level}</span>
                <span>${prestigeData.xp.toLocaleString('es-ES')} XP</span>
              </div>
              <div class="inventory-prestige-gifts"></div>
              <div class="inventory-prestige-progress-bar" aria-hidden="true">
                <div class="inventory-prestige-progress-fill" style="width: ${prestigeData.progress}%;"></div>
              </div>
              <div class="inventory-prestige-thresholds">${prestigeData.thresholds.join(' | ')} XP</div>
              <div class="inventory-prestige-xp-text">
                El prestigio es una forma de demostrar tu lealtad y maestria utilizando esta carta.<br><br>
                -Por cada batalla jugada utilizando la carta ganaras 20 XP de prestigio, si la ganas obtendras un extra de 10 XP de prestigio.<br><br>
                -Si obtienes de nuevo esta carta mediante sobres o trades, obtendras ${duplicateXp} XP (Oro: 500 XP, Plata: 250 XP, Bronce: 100 XP).<br><br>
                -Tambien tendras misiones de prestigio que si completas, este aumentara, y recibiras misiones nuevas cuando aumentes el prestigio.
              </div>
              <div class="inventory-prestige-missions-title">Misiones para obtener XP</div>
              <div class="inventory-prestige-missions-list"></div>
            </div>
          </div>
        </div>
      </div>
    `;

    const prestigeTrigger = prestigePanel.querySelector('.inventory-prestige-trigger');
    const prestigeClose = prestigePanel.querySelector('.inventory-prestige-close');
    const prestigeDropdown = prestigePanel.querySelector('.inventory-prestige-dropdown');
    prestigeTrigger?.addEventListener('click', () => {
      prestigePanel.classList.toggle('open');
    });
    prestigeClose?.addEventListener('click', () => {
      prestigePanel.classList.remove('open');
    });
    prestigeDropdown?.addEventListener('click', (e) => {
      if (e.target === prestigeDropdown) {
        prestigePanel.classList.remove('open');
      }
    });

    getPrestigeConfig().then((cfg) => {
      const profile = resolvePrestigeProfile(cfg, card);
      const thresholds = getPrestigeThresholds(profile.levels);
      const updatedPrestigeData = getInventoryPrestigeData(inventoryCount, thresholds, card.id);
      const xpRules = profile?.xpRules || (typeof defaultPrestigeConfig !== 'undefined' ? defaultPrestigeConfig.xpRules : null);
      const updatedDuplicateXp = typeof getDuplicatePrestigeXp === 'function'
        ? getDuplicatePrestigeXp(card, xpRules)
        : duplicateXp;

      const xpTextEl = prestigePanel.querySelector('.inventory-prestige-xp-text');
      if (xpTextEl) {
        xpTextEl.innerHTML = `
          El prestigio es una forma de demostrar tu lealtad y maestria utilizando esta carta.<br><br>
          -Por cada batalla jugada utilizando la carta ganaras 20 XP de prestigio, si la ganas obtendras un extra de 10 XP de prestigio.<br><br>
          -Si obtienes de nuevo esta carta mediante sobres o trades, obtendras ${updatedDuplicateXp} XP (Oro: 500 XP, Plata: 250 XP, Bronce: 100 XP).<br><br>
          -Tambien tendras misiones de prestigio que si completas, este aumentara, y recibiras misiones nuevas cuando aumentes el prestigio.
        `;
      }

      const metaValue = inventoryCardMeta.querySelector('.inventory-card-meta-row.inventory-prestige-block .inventory-card-meta-value');
      if (metaValue) metaValue.textContent = `Prestigio ${updatedPrestigeData.level}`;

      const currentLabel = prestigePanel.querySelector('.inventory-prestige-current-label');
      if (currentLabel) currentLabel.textContent = `Prestigio ${updatedPrestigeData.level}`;

      const xpLabel = prestigePanel.querySelector('.inventory-prestige-progress-header span:last-child');
      if (xpLabel) xpLabel.textContent = `${updatedPrestigeData.xp.toLocaleString('es-ES')} XP`;

      const fillTop = inventoryCardMeta.querySelector('.inventory-prestige-bar-fill');
      if (fillTop) fillTop.style.width = `${updatedPrestigeData.progress}%`;

      const fillLarge = prestigePanel.querySelector('.inventory-prestige-progress-fill');
      if (fillLarge) fillLarge.style.width = `${updatedPrestigeData.progress}%`;

      const thresholdsText = prestigePanel.querySelector('.inventory-prestige-thresholds');
      if (thresholdsText) thresholdsText.textContent = `${updatedPrestigeData.thresholds.join(' | ')} XP`;

      renderPrestigeMissionsAndRewards(prestigePanel, updatedPrestigeData, cfg, card);
    }).catch(() => {
      renderPrestigeMissionsAndRewards(prestigePanel, prestigeData, defaultPrestigeConfig, card);
    });

    lightboxContent.classList.add('lightbox-inventory-layout');
    if (lightboxContent.querySelector('.trait-lightbox-info')) {
      lightboxContent.insertBefore(inventoryCardMeta, lightboxContent.querySelector('.trait-lightbox-info'));
      document.body.appendChild(prestigePanel);
    } else {
      lightboxContent.insertBefore(inventoryCardMeta, lightboxImg);
      document.body.appendChild(prestigePanel);
    }
  }
  
  // Mostrar botón de venta solo si el usuario posee la carta
  const sellValue = (card && typeof card.valor === 'number') ? card.valor : 10;
  if (card && userOwns && sellValue > 0) {
    lightboxSell.style.display = 'block';
    sellCtx.cardId = card.id;
    sellCtx.cardName = card.name;
    sellCtx.cardValue = sellValue;
    sellCtx.instanceId = instanceId; // Guardar instanceId para cartas con trait
  } else {
    lightboxSell.style.display = 'none';
  }
  
  lightbox.classList.add('show');
}

function closeLightbox() {
  lightbox.classList.remove('show');
  lightboxImg.src = '';
  lightboxImg.classList.remove('unowned');
  lightboxImg.style.filter = '';
  lightboxSell.style.display = 'none';
  
  // Limpiar información de poderes y traits si existe
  const lightboxContent = lightbox?.querySelector('.lightbox-content');
  const powerInfo = lightboxContent?.querySelector('.power-lightbox-info');
  if (powerInfo) powerInfo.remove();
  const traitInfo = lightboxContent?.querySelector('.trait-lightbox-info');
  if (traitInfo) traitInfo.remove();
  const inventoryInfo = lightboxContent?.querySelector('.inventory-card-meta');
  if (inventoryInfo) inventoryInfo.remove();
  const prestigePanel = document.querySelector('.inventory-prestige-panel');
  if (prestigePanel) prestigePanel.remove();
  lightboxContent?.classList.remove('lightbox-inventory-layout');
}

function showSellModal() {
  sellTitle.textContent = 'Confirmar venta';
  sellMessage.innerHTML = `¿Seguro que quieres vender "${sellCtx.cardName}" por ${coinIcon(sellCtx.cardValue)}?`;
  sellModal.classList.add('show');
}

function hideSellModal() {
  sellModal.classList.remove('show');
}

function formatCardProbability(pct) {
  const p = Number(pct) || 0;
  if (p <= 0) return '0%';
  if (p >= 0.01) {
    return `${p.toFixed(2)}%`;
  }
  if (p < 0.0001) {
    return '<0.0001%';
  }
  // Para probabilidades menores a 0.01%: mostrar hasta 4 decimales según sea necesario
  const str = p.toFixed(4).replace(/0+$/, '').replace(/\.$/, '');
  return `${str}%`;
}
const formatProbability = formatCardProbability;
window.formatCardProbability = formatCardProbability;
window.formatProbability = formatProbability;

let appQualitiesCache = null;
async function getAppQualities() {
  if (window.appQualities && Array.isArray(window.appQualities) && window.appQualities.length > 0) {
    appQualitiesCache = window.appQualities;
    return window.appQualities;
  }
  if (appQualitiesCache && appQualitiesCache.length > 0) {
    window.appQualities = appQualitiesCache;
    return appQualitiesCache;
  }
  try {
    if (window.kvrcards && window.kvrcards.getQualities) {
      const q = await window.kvrcards.getQualities();
      if (Array.isArray(q) && q.length > 0) {
        appQualitiesCache = q;
        window.appQualities = q;
        window.appQualitiesCache = q;
        return q;
      }
    }
  } catch {}
  return [];
}
window.getAppQualities = getAppQualities;

function getPackMediaLimits(pack) {
  if (!pack || typeof pack !== 'object') {
    return { minMedia: null, maxMedia: null };
  }

  let minMedia = null;
  let maxMedia = null;

  const rawMin = pack.minMedia ?? pack.min_media ?? pack.minRating ?? pack.min_rating ?? pack.mediaMin ?? pack.media_min ?? pack.ratingMin;
  if (rawMin !== undefined && rawMin !== null && rawMin !== '') {
    const num = Number(rawMin);
    if (!isNaN(num)) minMedia = num;
  }

  const rawMax = pack.maxMedia ?? pack.max_media ?? pack.maxRating ?? pack.max_rating ?? pack.mediaMax ?? pack.media_max ?? pack.ratingMax;
  if (rawMax !== undefined && rawMax !== null && rawMax !== '') {
    const num = Number(rawMax);
    if (!isNaN(num)) maxMedia = num;
  }

  const rangeObj = pack.mediaRange || pack.ratingRange || pack.mediaLimits || pack.ratingLimits || 
                   pack.media_range || pack.rating_range || pack.rangoMedia || pack.limits ||
                   (typeof pack.media === 'object' ? pack.media : null) || 
                   (typeof pack.rating === 'object' ? pack.rating : null);

  if (rangeObj) {
    if (Array.isArray(rangeObj) && rangeObj.length > 0) {
      if (minMedia === null && rangeObj[0] !== undefined && rangeObj[0] !== null && rangeObj[0] !== '') {
        const num = Number(rangeObj[0]);
        if (!isNaN(num)) minMedia = num;
      }
      if (maxMedia === null && rangeObj[1] !== undefined && rangeObj[1] !== null && rangeObj[1] !== '') {
        const num = Number(rangeObj[1]);
        if (!isNaN(num)) maxMedia = num;
      }
    } else if (typeof rangeObj === 'object') {
      if (minMedia === null) {
        const val = rangeObj.min ?? rangeObj.minMedia ?? rangeObj.min_media ?? rangeObj.minRating ?? rangeObj.min_rating ?? rangeObj.from;
        if (val !== undefined && val !== null && val !== '') {
          const num = Number(val);
          if (!isNaN(num)) minMedia = num;
        }
      }
      if (maxMedia === null) {
        const val = rangeObj.max ?? rangeObj.maxMedia ?? rangeObj.max_media ?? rangeObj.maxRating ?? rangeObj.max_rating ?? rangeObj.to;
        if (val !== undefined && val !== null && val !== '') {
          const num = Number(val);
          if (!isNaN(num)) maxMedia = num;
        }
      }
    }
  }

  const rawStrings = [
    typeof pack.media === 'string' ? pack.media : null,
    typeof pack.rating === 'string' ? pack.rating : null,
    typeof pack.mediaRange === 'string' ? pack.mediaRange : null,
    typeof pack.ratingRange === 'string' ? pack.ratingRange : null,
    typeof pack.limits === 'string' ? pack.limits : null
  ].filter(Boolean);

  for (const str of rawStrings) {
    const trimmed = str.trim();
    if (trimmed.startsWith('+')) {
      const n = Number(trimmed.slice(1).trim());
      if (!isNaN(n) && minMedia === null) minMedia = n;
    } else if (trimmed.endsWith('+')) {
      const n = Number(trimmed.slice(0, -1).trim());
      if (!isNaN(n) && minMedia === null) minMedia = n;
    } else if (trimmed.startsWith('>=') || trimmed.startsWith('=>')) {
      const n = Number(trimmed.slice(2).trim());
      if (!isNaN(n) && minMedia === null) minMedia = n;
    } else if (trimmed.startsWith('<=') || trimmed.startsWith('=<')) {
      const n = Number(trimmed.slice(2).trim());
      if (!isNaN(n) && maxMedia === null) maxMedia = n;
    } else if (trimmed.includes('-') || trimmed.includes('..')) {
      const delimiter = trimmed.includes('..') ? '..' : '-';
      const parts = trimmed.split(delimiter).map(p => Number(p.trim()));
      if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
        if (minMedia === null) minMedia = parts[0];
        if (maxMedia === null) maxMedia = parts[1];
      }
    }
  }

  return { minMedia, maxMedia };
}
window.getPackMediaLimits = getPackMediaLimits;

function parseQualityWeights(rawWeights) {
  if (!rawWeights || typeof rawWeights !== 'object') return null;
  const map = {};
  for (const [key, val] of Object.entries(rawWeights)) {
    if (val !== undefined && val !== null && val !== '') {
      const num = Number(val);
      if (!isNaN(num)) {
        const normKey = String(key).trim().toLowerCase().replace(/[\s\-]+/g, '_');
        map[normKey] = num;
      }
    }
  }
  return Object.keys(map).length > 0 ? map : null;
}
window.parseQualityWeights = parseQualityWeights;

function resolveCardQualityWeight(card, normalizedWeights, getQualityObjFn, allowedQualities = null) {
  if (!normalizedWeights) return 1;

  const qObj = typeof getQualityObjFn === 'function' ? getQualityObjFn(card) : null;
  const qId = String(qObj?.id || card?.calidadId || '').trim().toLowerCase().replace(/[\s\-]+/g, '_');
  const qName = String(qObj?.name || card?.calidad || card?.quality || '').trim().toLowerCase().replace(/[\s\-]+/g, '_');
  const isSpecial = Boolean(qObj?.special);

  // 1. Coincidencia por ID de la calidad en calidades.json (ej: "bronce", "plata", "oro", "exclusive")
  // Si se filtra directamente por la calidad, sí se permite aunque packable sea false
  if (qId && normalizedWeights[qId] !== undefined) {
    return Math.max(0, normalizedWeights[qId]);
  }

  // 2. Coincidencia por Nombre de la calidad (retrocompatibilidad)
  if (qName && normalizedWeights[qName] !== undefined) {
    return Math.max(0, normalizedWeights[qName]);
  }

  // 3. Si la calidad tiene special === true en calidades.json, buscar peso 'special' / 'especial' / 'especiales'
  if (isSpecial) {
    const specialVal = normalizedWeights['special'] ?? normalizedWeights['especial'] ?? normalizedWeights['especiales'];
    if (specialVal !== undefined) {
      const isPackable = (qObj?.packable !== false && qObj?.packable !== 'false') &&
                         (card?.packable !== false && card?.packable !== 'false');

      let allowedSet = allowedQualities;
      if (allowedQualities && !(allowedQualities instanceof Set)) {
        if (Array.isArray(allowedQualities)) {
          allowedSet = new Set(allowedQualities.map(q => String(q).trim().toLowerCase().replace(/[\s\-]+/g, '_')).filter(Boolean));
        } else if (typeof allowedQualities === 'object') {
          allowedSet = getPackAllowedQualities(allowedQualities);
        }
      }

      const isExplicitlyAllowed = allowedSet && (allowedSet.has(qId) || allowedSet.has(qName));

      // Si no es packable, solo puede salir por 'special' si el sobre la permite explícitamente (allowedQualities)
      if (!isPackable && !isExplicitlyAllowed) {
        return 0;
      }
      return Math.max(0, specialVal);
    }
  }

  return 0;
}
window.resolveCardQualityWeight = resolveCardQualityWeight;

function getPackAllowedQualities(pack) {
  if (!pack) return null;
  const raw = pack.allowedQualities ?? pack.allowed_qualities ?? 
              pack.allowQualities ?? pack.allow_qualities ?? 
              pack.calidadesPermitidas ?? pack.allowedCalidades ??
              pack.allowUnpackableQualities ?? pack.allowedNonPackableQualities;
  if (!raw) return null;
  const arr = Array.isArray(raw) ? raw : [raw];
  const set = new Set(arr.map(q => String(q).trim().toLowerCase().replace(/[\s\-]+/g, '_')).filter(Boolean));
  return set.size > 0 ? set : null;
}
window.getPackAllowedQualities = getPackAllowedQualities;

function getPackAllowedProcedencias(pack) {
  if (!pack) return null;
  const raw = pack.allowedProcedencias ?? pack.allowed_procedencias ?? pack.procedencias;
  if (!raw) return null;
  const arr = Array.isArray(raw) ? raw : [raw];
  const set = new Set(arr.map(p => String(p).trim().toLowerCase()).filter(Boolean));
  return set.size > 0 ? set : null;
}
window.getPackAllowedProcedencias = getPackAllowedProcedencias;

function getPackAllowedOwners(pack) {
  if (!pack) return null;
  const raw = pack.allowedOwners ?? pack.allowed_owners ?? pack.owners ?? pack.allowedPropietarios ?? pack.propietarios;
  if (!raw) return null;
  const arr = Array.isArray(raw) ? raw : [raw];
  const set = new Set(arr.map(o => String(o).trim().toLowerCase()).filter(Boolean));
  return set.size > 0 ? set : null;
}
window.getPackAllowedOwners = getPackAllowedOwners;

function getPackExcludedIds(pack) {
  if (!pack) return null;
  const raw = pack.excludedIds ?? pack.excluded_ids ?? pack.excludedCardIds ?? pack.excluded_card_ids;
  if (!raw) return null;
  const arr = Array.isArray(raw) ? raw : [raw];
  const set = new Set(arr.map(id => String(id).trim()).filter(Boolean));
  return set.size > 0 ? set : null;
}
window.getPackExcludedIds = getPackExcludedIds;

// Pack details modal
async function showPackDetails(packId) {
  if (!isElectron) return;
  try {
    const [packs, allCards, allQualities] = await Promise.all([
      window.kvrcards.getAllPacks(),
      window.kvrcards.getAllCards(),
      getAppQualities()
    ]);
    
    const pack = packs.find(p => p.id === packId);
    if (!pack) return;

    const { minMedia, maxMedia } = getPackMediaLimits(pack);
    let mediaLimitLabel = '';
    if (minMedia !== null && maxMedia !== null) {
      mediaLimitLabel = ` [Media ${minMedia}-${maxMedia}]`;
    } else if (minMedia !== null) {
      mediaLimitLabel = ` [Media +${minMedia}]`;
    } else if (maxMedia !== null) {
      mediaLimitLabel = ` [Media ≤${maxMedia}]`;
    }
    packDetailsTitle.textContent = pack.name + mediaLimitLabel;
    
    // Obtener distribución de cartas
    const distribution = pack.probabilityDistribution || pack.distribution || {};
    
    // Filtros del sobre (sincronizados con electron/main.js)
    const rawQWeights = pack.qualityWeights || pack.qualityweights || pack.quality_weights || pack.qualityheights || pack.quality_heights || null;
    const normQWeights = parseQualityWeights(rawQWeights);
    const hasQualityWeights = !!normQWeights;

    const allowedProcedencias = getPackAllowedProcedencias(pack);
    const allowedOwners = getPackAllowedOwners(pack);
    const allowedQualities = getPackAllowedQualities(pack);
    const excludedIds = getPackExcludedIds(pack);

    const hasPositiveQualityWeights = normQWeights && Object.values(normQWeights).some(w => Number(w) > 0);
    const excludedQualities = (Array.isArray(pack.excludedQualities) ? pack.excludedQualities : [])
      .map(q => String(q).trim().toLowerCase().replace(/[\s\-]+/g, '_'));

    const allowedCardIdsRaw = Array.isArray(pack.allowedCardIds)
      ? pack.allowedCardIds
      : (Array.isArray(pack.cardIds)
          ? pack.cardIds
          : (Array.isArray(pack.onlyCardIds)
              ? pack.onlyCardIds
              : (Array.isArray(pack.allowedIds)
                  ? pack.allowedIds
                  : (Array.isArray(pack.allowed_ids) ? pack.allowed_ids : []))));
    const allowedCardIds = new Set(allowedCardIdsRaw.map(id => String(id)));
    const hasAllowedCardIds = allowedCardIds.size > 0;
    const explicitOnlyMode = hasAllowedCardIds && hasQualityWeights && !hasPositiveQualityWeights;

    console.log('[PACK DETAILS] qualityWeights (por ID):', normQWeights);
    console.log('[PACK DETAILS] excludedQualities:', excludedQualities);
    console.log('[PACK DETAILS] allowedCardIds:', Array.from(allowedCardIds));
    console.log('[PACK DETAILS] explicitOnlyMode:', explicitOnlyMode);
    if (minMedia !== null || maxMedia !== null) {
      console.log(`[PACK DETAILS] Límites de media: min=${minMedia ?? '-∞'}, max=${maxMedia ?? '+∞'}`);
    }
    if (allowedProcedencias) {
      console.log('[PACK DETAILS] allowedProcedencias:', Array.from(allowedProcedencias));
    }
    if (allowedOwners) {
      console.log('[PACK DETAILS] allowedOwners:', Array.from(allowedOwners));
    }
    if (allowedQualities) {
      console.log('[PACK DETAILS] allowedQualities:', Array.from(allowedQualities));
    }
    if (excludedIds) {
      console.log('[PACK DETAILS] excludedIds:', Array.from(excludedIds));
    }

    // Mapa de consulta rápida de calidades
    const qualityMap = new Map();
    (allQualities || []).forEach(q => {
      if (q && q.name) qualityMap.set(q.name.toLowerCase(), q);
      if (q && q.id) qualityMap.set(q.id.toLowerCase(), q);
    });

    // Permitir que allowedCardIds o filtros metan cartas aunque no estén en distribution (peso base 1)
    const sourceDistribution = { ...distribution };
    const hasMediaLimits = minMedia !== null || maxMedia !== null;
    const needsAllCandidates = Object.keys(sourceDistribution).length === 0 || hasMediaLimits || allowedProcedencias !== null || allowedOwners !== null || allowedQualities !== null || hasQualityWeights;

    if (needsAllCandidates) {
      allCards.forEach(c => {
        if (c && c.id && sourceDistribution[c.id] === undefined) {
          sourceDistribution[c.id] = 1;
        }
      });
    } else if (hasAllowedCardIds) {
      allowedCardIds.forEach(cardId => {
        if (sourceDistribution[cardId] === undefined) {
          sourceDistribution[cardId] = 1;
        }
      });
    }
    
    // Aplicar sistema de probabilidad inversa (igual que en electron/main.js)
    const adjustedDistribution = {};
    Object.entries(sourceDistribution).forEach(([cardId, baseWeight]) => {
      // 0. EXCLUSIÓN DIRECTA POR ID (excludedIds)
      if (excludedIds && excludedIds.has(String(cardId))) {
        return;
      }

      const card = allCards.find(c => c.id === cardId);
      if (!card) return;

      const isExplicitCard = allowedCardIds.has(cardId);
      const cardQuality = card.calidad || 'Bronce';
      const qObj = qualityMap.get(cardQuality.toLowerCase()) || (card.calidadId ? qualityMap.get(card.calidadId.toLowerCase()) : null);
      const isEvo = cardQuality === 'Evo' || card.calidadId === 'evo' || String(cardQuality).toLowerCase() === 'evo';

      // Las cartas Evo NUNCA pueden salir en sobres
      if (isEvo && !isExplicitCard) {
        return;
      }

      // Modo exclusivo por ids: solo cartas incluidas explícitamente.
      if (explicitOnlyMode && !isExplicitCard) {
        return;
      }
      
      // Para cartas no explícitas, aplicar filtros normales.
      if (!isExplicitCard) {
        const cardQNorm = String(cardQuality).trim().toLowerCase().replace(/[\s\-]+/g, '_');
        const cardQId = String(qObj?.id || card.calidadId || '').trim().toLowerCase().replace(/[\s\-]+/g, '_');

        if (excludedQualities.includes(cardQNorm) || excludedQualities.includes(cardQId)) {
          return;
        }

        // Filtro por calidades permitidas (allowedQualities)
        if (allowedQualities) {
          const isAllowedQ = allowedQualities.has(cardQNorm) || allowedQualities.has(cardQId);
          // Si no tiene qualityWeights con special, allowedQualities actúa como whitelist estricto
          const hasSpecialWeight = normQWeights && (normQWeights['special'] !== undefined || normQWeights['especial'] !== undefined || normQWeights['especiales'] !== undefined);
          if (!hasSpecialWeight && !isAllowedQ) {
            return;
          }
        }

        // Filtro por procedencia
        if (allowedProcedencias) {
          const proc = String(card.procedencia ?? card.Procedencia ?? card.origin ?? card.origen ?? '').trim().toLowerCase();
          if (!proc || !allowedProcedencias.has(proc)) {
            return;
          }
        }

        // Filtro por owner
        if (allowedOwners) {
          const owner = String(card.owner ?? card.Owner ?? card.propietario ?? card.Propietario ?? card.creador ?? card.creator ?? '').trim().toLowerCase();
          if (!owner || !allowedOwners.has(owner)) {
            return;
          }
        }

        // Filtro por límites de media (minMedia / maxMedia)
        const media = Number(card.media) || 0;
        if (minMedia !== null && media < minMedia) {
          return;
        }
        if (maxMedia !== null && media > maxMedia) {
          return;
        }

        // CONTROL DE PACKABLE (packable === false):
        // Por defecto packable es true si no se especifica.
        // Si packable es false (en la calidad o en la carta), NO puede salir en sobres salvo que:
        // 1. Esté en allowedCardIds (isExplicitCard - ya controlado arriba)
        // 2. Esté en allowedQualities / allowQualities del sobre
        // 3. Se filtre explícitamente por su calidad en qualityWeights (ej: { "exclusive": 100 })
        const isPackable = (qObj?.packable !== false && qObj?.packable !== 'false') &&
                           (card?.packable !== false && card?.packable !== 'false');
        if (!isPackable) {
          const isExplicitQuality = normQWeights && (normQWeights[cardQId] !== undefined || normQWeights[cardQNorm] !== undefined);
          const isAllowedQuality = allowedQualities && (allowedQualities.has(cardQId) || allowedQualities.has(cardQNorm));
          if (!isExplicitQuality && !isAllowedQuality) {
            return;
          }
        }

        // FILTRO Y PESO POR QUALITYWEIGHTS (por ID en calidades.json o 'special')
        if (hasQualityWeights) {
          const qWeight = resolveCardQualityWeight(card, normQWeights, () => qObj, allowedQualities);
          if (qWeight <= 0) {
            return;
          }
          baseWeight = qWeight;
        }
      }
      
      const media = Number(card.media) || 0;
      
      // Fórmula de probabilidad inversa continua mejorada (igual que electron/main.js):
      // Gran penalización a partir de 85 y escalonamiento pronunciado en 88, 90, 92, 94+
      let factor;
      let multiplier;
      
      if (media >= 94) {
        factor = 4.0;
        multiplier = Math.exp(-(media - 50) / factor);
      } else if (media >= 92) {
        factor = 4.4;
        multiplier = Math.exp(-(media - 50) / factor);
      } else if (media >= 90) {
        factor = 4.9;
        multiplier = Math.exp(-(media - 50) / factor);
      } else if (media >= 88) {
        factor = 5.6;
        multiplier = Math.exp(-(media - 50) / factor);
      } else if (media >= 85) {
        factor = 6.6;
        multiplier = Math.exp(-(media - 50) / factor);
      } else if (media >= 80) {
        factor = 10.5;
        multiplier = Math.exp(-(media - 50) / factor);
      } else if (media >= 75) {
        factor = 14.5;
        multiplier = Math.exp(-(media - 50) / factor);
      } else {
        factor = 18.0;
        multiplier = Math.exp(-(media - 50) / factor);
      }
      
      adjustedDistribution[cardId] = baseWeight * multiplier;
    });
    
    // Calcular probabilidades totales con pesos ajustados
    const totalWeight = Object.values(adjustedDistribution).reduce((sum, w) => sum + (Number(w) || 0), 0);
    
    // Crear array de cartas con sus probabilidades, agrupadas por calidad
    const cardsByQuality = {};
    
    Object.entries(adjustedDistribution).forEach(([cardId, weight]) => {
      const card = allCards.find(c => c.id === cardId);
      if (!card) return;
      
      const rawProbability = totalWeight > 0 ? ((Number(weight) || 0) / totalWeight * 100) : 0;
      const rawQuality = card.calidadId || card.calidad || card.quality || card.rarity || '';
      const qObj = qualityMap.get(String(rawQuality).toLowerCase()) ||
                   qualityMap.get(String(card.calidad || '').toLowerCase()) ||
                   qualityMap.get(String(card.calidadId || '').toLowerCase());
      
      let quality = 'Bronce';
      if (qObj) {
        const isStandardTier = ['Oro', 'Plata', 'Bronce'].includes(qObj.name) || 
                               ['oro', 'plata', 'bronce'].includes(qObj.id);
        const shouldSeparate = Boolean(qObj.showSeparate || qObj.separate || qObj.mostrarSeparado);

        if (shouldSeparate || isStandardTier) {
          quality = qObj.name;
        } else if (qObj.special) {
          quality = 'Especiales';
        } else {
          quality = 'Bronce';
        }
      } else {
        const qLower = String(rawQuality).trim().toLowerCase();
        const media = Number(card.media) || 0;
        const isSpecial = qLower.includes('icon') || qLower.includes('prime') || qLower.includes('heroe') || qLower.includes('héroe') || qLower.includes('especial');
        const isOro = qLower.includes('oro') || qLower.includes('gold');
        const isPlata = qLower.includes('plata') || qLower.includes('silver');
        
        if (isSpecial) quality = 'Especiales';
        else if (isOro) quality = 'Oro';
        else if (isPlata) quality = 'Plata';
        else if (!qLower) {
          if (media >= 90) quality = 'Especiales';
          else if (media >= 80) quality = 'Oro';
          else if (media >= 70) quality = 'Plata';
        }
      }
      
      if (!cardsByQuality[quality]) cardsByQuality[quality] = [];
      cardsByQuality[quality].push({
        card,
        probability: rawProbability
      });
    });
    
    // Ordenar cada grupo por media descendente
    Object.keys(cardsByQuality).forEach(quality => {
      cardsByQuality[quality].sort((a, b) => (b.card.media || 0) - (a.card.media || 0));
    });
    
    // Renderizar por calidades
    packDetailsContent.innerHTML = '';
    
    // Configuración dinámica de calidades
    const qualityConfig = {
      'Especiales': { name: 'Especiales', color: '#00d4ff', imagePath: './assets/qualities/icono.png', order: 999 },
      'Oro': { name: 'Oro', color: '#d4af37', imagePath: './assets/qualities/oro.png', order: 3 },
      'Plata': { name: 'Plata', color: '#c0c0c0', imagePath: './assets/qualities/plata.png', order: 2 },
      'Bronce': { name: 'Bronce', color: '#cd7f32', imagePath: './assets/qualities/bronce.png', order: 1 }
    };

    (allQualities || []).forEach(q => {
      if (q && q.name) {
        const rawIcon = q.iconImage || q.icon || q.miniImage || q.miniIcon || q.maskImage || q.image || './assets/qualities/icono.png';
        const iconUrl = typeof normalizeAssetUrl === 'function' ? normalizeAssetUrl(rawIcon) : rawIcon;
        qualityConfig[q.name] = {
          name: q.name,
          color: q.sparkColor || q.color || '#cd7f32',
          imagePath: iconUrl,
          order: typeof q.order === 'number' ? q.order : 0
        };
      }
    });
    
    // Orden jerárquico de calidades según su atributo order (descendente)
    const activeQualityKeys = Object.keys(cardsByQuality).filter(k => cardsByQuality[k] && cardsByQuality[k].length > 0);
    activeQualityKeys.sort((a, b) => {
      const orderA = qualityConfig[a]?.order ?? getQualityOrder(a);
      const orderB = qualityConfig[b]?.order ?? getQualityOrder(b);
      return orderB - orderA;
    });

    const qualities = [];
    activeQualityKeys.forEach(qualityKey => {
      const cards = cardsByQuality[qualityKey];
      const config = qualityConfig[qualityKey] || { name: qualityKey, color: '#cd7f32', imagePath: './assets/qualities/bronce.png' };
      qualities.push({
        key: qualityKey,
        name: config.name,
        cards: cards,
        color: config.color,
        imagePath: config.imagePath
      });
    });
    
    qualities.forEach(({ name, cards, color, imagePath }) => {
      if (!cards || cards.length === 0) return;
      
      // Sección colapsable para cada calidad
      const section = document.createElement('div');
      section.className = 'quality-section';
      
      const header = document.createElement('div');
      header.className = 'quality-header';
      header.style.borderLeftColor = color;
      
      const headerContent = document.createElement('div');
      headerContent.className = 'quality-header-content';
      
      const iconImg = document.createElement('img');
      iconImg.className = 'quality-icon';
      iconImg.src = imagePath;
      iconImg.alt = name;
      iconImg.onerror = () => {
        const cleanName = name.toLowerCase().replace(/[\s\-_]/g, '_');
        const localFallback = `./assets/qualities/${cleanName}.png`;
        if (iconImg.src !== localFallback) {
          iconImg.src = localFallback;
        } else {
          iconImg.src = './assets/qualities/icono.png';
        }
      };
      
      headerContent.appendChild(iconImg);
      
      const nameSpan = document.createElement('span');
      nameSpan.className = 'quality-name';
      nameSpan.textContent = `Cartas ${name}`;
      headerContent.appendChild(nameSpan);
      
      const countSpan = document.createElement('span');
      countSpan.className = 'quality-count';
      countSpan.textContent = ` (${cards.length})`;
      headerContent.appendChild(countSpan);
      
      // Contenedor derecho: probabilidad sumada de la calidad + flecha
      const headerRight = document.createElement('div');
      headerRight.className = 'quality-header-right';
      
      const totalQualityProbability = cards.reduce((sum, item) => sum + (Number(item.probability) || 0), 0);
      const probBadge = document.createElement('span');
      probBadge.className = 'quality-prob-badge';
      probBadge.textContent = formatProbability(totalQualityProbability);
      headerRight.appendChild(probBadge);
      
      const arrow = document.createElement('span');
      arrow.className = 'quality-arrow';
      arrow.textContent = '▼';
      headerRight.appendChild(arrow);
      
      header.appendChild(headerContent);
      header.appendChild(headerRight);
      
      const cardsContainer = document.createElement('div');
      cardsContainer.className = 'quality-cards collapsed';
      
      // Toggle collapse
      header.addEventListener('click', () => {
        const isCollapsed = cardsContainer.classList.contains('collapsed');
        cardsContainer.classList.toggle('collapsed');
        arrow.textContent = isCollapsed ? '▲' : '▼';
      });
      
      // Renderizar cartas de esta calidad
      cards.forEach(({ card, probability }) => {
        const item = document.createElement('div');
        item.className = 'pack-card-item';
        
        const img = document.createElement('img');
        img.src = card.imageUrl || '';
        const cardTitle = card.name || card.nombre || 'Carta';
        img.alt = cardTitle;
        img.onerror = () => {
          img.src = 'data:image/svg+xml;utf8,' + encodeURIComponent(
            '<svg xmlns="http://www.w3.org/2000/svg" width="200" height="280"><rect width="100%" height="100%" fill="#1f2937"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#9ca3af" font-family="Arial" font-size="14">Sin imagen</text></svg>'
          );
        };
        
        const name = document.createElement('div');
        name.className = 'card-name';
        name.textContent = cardTitle;
        name.title = cardTitle;
        
        const prob = document.createElement('div');
        prob.className = 'card-probability';
        prob.textContent = formatCardProbability(probability);
        
        const media = document.createElement('div');
        media.className = 'card-media';
        media.textContent = `Media: ${card.media || '?'}`;
        
        // Click para ampliar
        item.addEventListener('click', () => {
          lightboxImg.classList.remove('unowned');
          lightboxImg.style.filter = '';
          lightboxImg.src = card.imageUrl || '';
          lightbox.classList.add('show');
          packDetailsModal.classList.remove('show');
        });
        
        item.appendChild(img);
        item.appendChild(name);
        item.appendChild(media);
        item.appendChild(prob);
        cardsContainer.appendChild(item);
      });
      
      section.appendChild(header);
      section.appendChild(cardsContainer);
      packDetailsContent.appendChild(section);
    });
    
    packDetailsModal.classList.add('show');
  } catch (e) {
    console.error('Error showing pack details:', e);
  }
}

function hidePackDetails() {
  packDetailsModal.classList.remove('show');
}

async function confirmSell() {
  try {
    // Enviar payload con cardId e instanceId si existe (para cartas con trait)
    const payload = { cardId: sellCtx.cardId };
    if (sellCtx.instanceId) {
      payload.instanceId = sellCtx.instanceId;
    }
    const result = await window.kvrcards.sellCard(payload);
    if (result?.ok) {
      hideSellModal();
      closeLightbox();
      await Promise.all([renderCollection(), renderWallet()]);
      // Mensaje de éxito removido - venta silenciosa
    } else {
      alert('Error al vender: ' + (result?.error || 'Error desconocido'));
    }
  } catch (e) {
    alert('Error al vender: ' + e);
  }
}
function updateFilterButtonText() {
  if (currentFilterType === 'none') {
    filterButton.textContent = 'Filtrar por: ---- ▼';
  } else if (currentFilterType === 'quality') {
    if (collectionViewType === 'cards') {
      const qualityNames = {
        'bronze': 'Bronce',
        'silver': 'Plata',
        'gold': 'Oro',
        'epic': 'Épica',
        'legendary': 'Legendaria'
      };
      filterButton.textContent = `Filtrar por: ${qualityNames[currentFilterValue] || currentFilterValue} ▼`;
    } else {
      const rarityNames = {
        'common': 'Común',
        'rare': 'Raro',
        'epic': 'Épico',
        'legendary': 'Legendario'
      };
      filterButton.textContent = `Filtrar por: ${rarityNames[currentFilterValue] || currentFilterValue} ▼`;
    }
  } else if (currentFilterType === 'media') {
    filterButton.textContent = `Filtrar por: Media ≥ ${currentFilterValue} ▼`;
  } else if (currentFilterType === 'uses') {
    if (currentFilterValue === 'permanent') {
      filterButton.textContent = 'Filtrar por: Permanente ▼';
    } else {
      filterButton.textContent = `Filtrar por: Usos ≥ ${currentFilterValue} ▼`;
    }
  } else if (currentFilterType === 'procedencia') {
    filterButton.textContent = `Filtrar por: ${currentFilterValue || 'Procedencia'} ▼`;
  } else if (currentFilterType === 'owner') {
    filterButton.textContent = `Filtrar por: ${currentFilterValue || 'Owner'} ▼`;
  }
  
  // Habilitar/deshabilitar filtro 2 según filtro 1
  if (filterButton2) {
    if (currentFilterType === 'none') {
      filterButton2.disabled = true;
      currentFilterType2 = 'none';
      currentFilterValue2 = null;
      updateFilterButton2Text();
    } else {
      filterButton2.disabled = false;
    }
  }
}

// Función para actualizar el texto del segundo botón de filtro
function updateFilterButton2Text() {
  if (!filterButton2) return;
  
  if (currentFilterType2 === 'none') {
    filterButton2.textContent = 'Filtro 2 por: ---- ▼';
  } else if (currentFilterType2 === 'quality') {
    if (collectionViewType === 'cards') {
      const qualityNames = {
        'bronze': 'Bronce',
        'silver': 'Plata',
        'gold': 'Oro',
        'epic': 'Épica',
        'legendary': 'Legendaria'
      };
      filterButton2.textContent = `Filtro 2 por: ${qualityNames[currentFilterValue2] || currentFilterValue2} ▼`;
    } else {
      const rarityNames = {
        'common': 'Común',
        'rare': 'Raro',
        'epic': 'Épico',
        'legendary': 'Legendario'
      };
      filterButton2.textContent = `Filtro 2 por: ${rarityNames[currentFilterValue2] || currentFilterValue2} ▼`;
    }
  } else if (currentFilterType2 === 'media') {
    filterButton2.textContent = `Filtro 2 por: Media ≥ ${currentFilterValue2} ▼`;
  } else if (currentFilterType2 === 'uses') {
    if (currentFilterValue2 === 'permanent') {
      filterButton2.textContent = 'Filtro 2 por: Permanente ▼';
    } else {
      filterButton2.textContent = `Filtro 2 por: Usos ≥ ${currentFilterValue2} ▼`;
    }
  } else if (currentFilterType2 === 'procedencia') {
    filterButton2.textContent = `Filtro 2 por: ${currentFilterValue2 || 'Procedencia'} ▼`;
  } else if (currentFilterType2 === 'owner') {
    filterButton2.textContent = `Filtro 2 por: ${currentFilterValue2 || 'Owner'} ▼`;
  }
}

// Función para inicializar el estado de los filtros
function initializeFilters() {
  // Establecer opción activa inicial
  document.querySelector(`.sort-option[data-sort="${currentSortMode}"]`)?.classList.add('active');
  // Actualizar texto del botón de ordenado
  if (sortButton) {
    sortButton.textContent = `Ordenar por: ${sortModeNames[currentSortMode]} ▼`;
  }
  // Inicializar filtro 1
  currentFilterType = 'none';
  currentFilterValue = null;
  if (filterButton) {
    updateFilterButtonText();
  }
  // Inicializar filtro 2
  currentFilterType2 = 'none';
  currentFilterValue2 = null;
  if (filterButton2) {
    filterButton2.disabled = true;
    updateFilterButton2Text();
  }
}

// Función específica para sync commands (puede llamarse múltiples veces con seguridad)
function initializeSyncCommand() {
  // Remover listener existente si existe
  if (hudSyncCommands) {
    hudSyncCommands.replaceWith(hudSyncCommands.cloneNode(true));
    const newHudSyncCommands = document.getElementById('hud-sync-commands');
    newHudSyncCommands?.addEventListener('click', async () => {
      try {
        const res = await window.kvrcards.syncCommands();
        if (res?.ok) {
          if (res.applied > 0) {
            await Promise.all([renderCollection(), renderOwnedPacks(), renderShop(), renderWallet()]);
            alert(`Comandos aplicados: ${res.applied}`);
          } else if (res.skipped) {
            alert(`Comandos ya aplicados anteriormente. No es necesario sincronizar.`);
          } else {
            alert('No hay comandos disponibles para este usuario.');
          }
        } else if (res?.error) {
          alert('Error al sincronizar: ' + res.error);
        } else {
          alert('Respuesta inesperada: ' + JSON.stringify(res));
        }
      } catch (e) {
        alert('Error al sincronizar: ' + e);
      }
    });
  }
}

// Funciones de filtrado
function shouldShowCard(card, counts) {
  // Aplicar filtro 1
  let passFilter1 = true;
  if (currentFilterType !== 'none') {
    switch (currentFilterType) {
      case 'quality':
        if (String(currentFilterValue).toLowerCase() === 'especiales') {
          passFilter1 = typeof isCardSpecialQuality === 'function'
            ? isCardSpecialQuality(card)
            : (typeof isSpecialQuality === 'function' ? isSpecialQuality(card.calidad || card.quality || card.calidadId) : false);
        } else {
          passFilter1 = card.calidad === currentFilterValue || 
                        card.calidadId === currentFilterValue || 
                        card.quality === currentFilterValue ||
                        String(card.calidad).toLowerCase() === String(currentFilterValue).toLowerCase() ||
                        String(card.calidadId).toLowerCase() === String(currentFilterValue).toLowerCase();
        }
        break;
      case 'media':
        if (currentFilterValue !== null) {
          passFilter1 = (card.media || 0) >= currentFilterValue;
        }
        break;
      case 'procedencia':
        passFilter1 = String(card.procedencia || card.origen || card.source || '').trim() === String(currentFilterValue || '').trim();
        break;
      case 'owner':
        passFilter1 = String(card.owner || '').trim() === String(currentFilterValue || '').trim();
        break;
    }
  }
  
  // Aplicar filtro 2
  let passFilter2 = true;
  if (currentFilterType2 !== 'none') {
    switch (currentFilterType2) {
      case 'quality':
        if (String(currentFilterValue2).toLowerCase() === 'especiales') {
          passFilter2 = typeof isCardSpecialQuality === 'function'
            ? isCardSpecialQuality(card)
            : (typeof isSpecialQuality === 'function' ? isSpecialQuality(card.calidad || card.quality || card.calidadId) : false);
        } else {
          passFilter2 = card.calidad === currentFilterValue2 || 
                        card.calidadId === currentFilterValue2 || 
                        card.quality === currentFilterValue2 ||
                        String(card.calidad).toLowerCase() === String(currentFilterValue2).toLowerCase() ||
                        String(card.calidadId).toLowerCase() === String(currentFilterValue2).toLowerCase();
        }
        break;
      case 'media':
        if (currentFilterValue2 !== null) {
          passFilter2 = (card.media || 0) >= currentFilterValue2;
        }
        break;
      case 'procedencia':
        passFilter2 = String(card.procedencia || card.origen || card.source || '').trim() === String(currentFilterValue2 || '').trim();
        break;
      case 'owner':
        passFilter2 = String(card.owner || '').trim() === String(currentFilterValue2 || '').trim();
        break;
    }
  }
  
  return passFilter1 && passFilter2;
}

function isCardEvoQuality(card) {
  if (!card) return false;
  let qRaw = card.calidad || card.quality || card.calidadId || '';
  if (typeof qRaw === 'object' && qRaw !== null) {
    qRaw = qRaw.id || qRaw.name || '';
  }
  const q = String(qRaw).trim().toLowerCase();
  return q === 'evo' || q === 'evolucion' || q === 'evolución' || q === 'evolution';
}

function filterCards(cards, counts) {
  let filtered = cards;
  
  // Aplicar filtros de calidad y media
  if (currentFilterType !== 'none' || currentFilterType2 !== 'none') {
    filtered = filtered.filter(card => shouldShowCard(card, counts));
  }
  
  // Aplicar filtro de búsqueda por texto
  if (collectionSearchText.trim()) {
    const search = collectionSearchText.toLowerCase();
    filtered = filtered.filter(card => {
      const matchesName = card.name?.toLowerCase().includes(search);
      const matchesClub = card.club?.toLowerCase().includes(search);
      const matchesQuality = card.quality?.toLowerCase().includes(search) || 
                            card.calidad?.toLowerCase().includes(search);
      const matchesPosition = card.position?.toLowerCase().includes(search);
      return matchesName || matchesClub || matchesQuality || matchesPosition;
    });
  }
  
  return filtered;
}

function filterOwnedCards(entries, cardMap) {
  let filtered = entries;
  
  // Helper para obtener carta (soporta IDs únicos)
  const getCard = (id) => {
    if (cardMap.has(id)) return cardMap.get(id);
    if (typeof id === 'string' && id.includes('_')) {
      const baseId = id.split('_')[0];
      return cardMap.get(baseId);
    }
    return null;
  };
  
  // Aplicar filtros de calidad y media
  if (currentFilterType !== 'none' || currentFilterType2 !== 'none') {
    filtered = filtered.filter(([id, count]) => {
      const card = getCard(id);
      return card && shouldShowCard(card, {});
    });
  }
  
  // Aplicar filtro de búsqueda por texto
  if (collectionSearchText.trim()) {
    const search = collectionSearchText.toLowerCase();
    filtered = filtered.filter(([id, count]) => {
      const card = getCard(id);
      if (!card) return false;
      const matchesName = card.name?.toLowerCase().includes(search);
      const matchesClub = card.club?.toLowerCase().includes(search);
      const matchesQuality = card.quality?.toLowerCase().includes(search) || 
                            card.calidad?.toLowerCase().includes(search);
      const matchesPosition = card.position?.toLowerCase().includes(search);
      return matchesName || matchesClub || matchesQuality || matchesPosition;
    });
  }
  
  return filtered;
}

// Funciones de ordenación
function getQualityOrder(quality) {
  if (!quality) return 0;
  const qStr = String(quality).trim();
  const qualitiesList = window.appQualities || window.appQualitiesCache || appQualitiesCache || [];
  if (Array.isArray(qualitiesList) && qualitiesList.length > 0) {
    const qClean = qStr.toLowerCase().replace(/[\s\-_]/g, '');
    const qObj = qualitiesList.find(x => {
      const nameClean = String(x.name || '').toLowerCase().replace(/[\s\-_]/g, '');
      const idClean = String(x.id || '').toLowerCase().replace(/[\s\-_]/g, '');
      return x.id === qStr || x.name === qStr || idClean === qClean || nameClean === qClean;
    });
    if (qObj && typeof qObj.order === 'number') return qObj.order;
  }
  const qLower = qStr.toLowerCase();
  if (qLower.includes('super') && qLower.includes('prime')) return 7;
  if (qLower.includes('prime')) return 6;
  if (qLower.includes('evo')) return 8;
  if (qLower.includes('heroe')) return 5;
  if (qLower.includes('icon') || qLower.includes('especial')) return 4;
  if (qLower.includes('oro') || qLower.includes('gold')) return 3;
  if (qLower.includes('plata') || qLower.includes('silver')) return 2;
  return 1;
}

function sortCards(cards, counts, mode) {
  switch (mode) {
    case 'alphabetic':
      return [...cards].sort((a, b) => a.name.localeCompare(b.name));
    case 'quality':
      return [...cards].sort((a, b) => {
        const orderA = getQualityOrder(a.calidad);
        const orderB = getQualityOrder(b.calidad);
        // Primero por calidad (descendente)
        if (orderA !== orderB) {
          return orderB - orderA; // Icono, Oro, Plata, Bronce
        }
        // Dentro de la misma calidad, ordenar por media (descendente)
        return (b.media || 0) - (a.media || 0);
      });
    case 'media':
      return [...cards].sort((a, b) => (b.media || 0) - (a.media || 0)); // Descendente
    case 'duplicates':
      return [...cards].sort((a, b) => {
        const countA = counts[a.id] || 0;
        const countB = counts[b.id] || 0;
        // Ordenar por cantidad (descendente), las más repetidas primero
        if (countA !== countB) {
          return countB - countA;
        }
        // Si tienen la misma cantidad, ordenar alfabéticamente
        return a.name.localeCompare(b.name);
      });
    case 'obtained':
    default:
      // Orden por obtención: las que tienes primero, después por id (orden de catálogo)
      return [...cards].sort((a, b) => {
        const countA = counts[a.id] || 0;
        const countB = counts[b.id] || 0;
        if (countA > 0 && countB === 0) return -1;
        if (countA === 0 && countB > 0) return 1;
        return a.id.localeCompare(b.id);
      });
  }
}

function sortOwnedCards(entries, cardMap, mode) {
  switch (mode) {
    case 'alphabetic':
      return [...entries].sort((a, b) => {
        const cardA = cardMap.get(a[0]);
        const cardB = cardMap.get(b[0]);
        return (cardA?.name || '').localeCompare(cardB?.name || '');
      });
    case 'quality':
      return [...entries].sort((a, b) => {
        const cardA = cardMap.get(a[0]);
        const cardB = cardMap.get(b[0]);
        const orderA = getQualityOrder(cardA?.calidad);
        const orderB = getQualityOrder(cardB?.calidad);
        // Primero por calidad (descendente)
        if (orderA !== orderB) {
          return orderB - orderA; // Icono, Oro, Plata, Bronce
        }
        // Dentro de la misma calidad, ordenar por media (descendente)
        return (cardB?.media || 0) - (cardA?.media || 0);
      });
    case 'media':
      return [...entries].sort((a, b) => {
        const cardA = cardMap.get(a[0]);
        const cardB = cardMap.get(b[0]);
        return (cardB?.media || 0) - (cardA?.media || 0);
      });
    case 'duplicates':
      return [...entries].sort((a, b) => {
        const countA = a[1] || 0;
        const countB = b[1] || 0;
        // Ordenar por cantidad (descendente), las más repetidas primero
        if (countA !== countB) {
          return countB - countA;
        }
        // Si tienen la misma cantidad, ordenar alfabéticamente
        const cardA = cardMap.get(a[0]);
        const cardB = cardMap.get(b[0]);
        return (cardA?.name || '').localeCompare(cardB?.name || '');
      });
    case 'obtained':
    default:
      return entries; // Mantener orden original (orden de obtención)
  }
}

// Funciones de ordenación para poderes
function sortPowers(powers, ownedPowers, mode) {
  const getRarityOrder = (rarity) => {
    const order = { legendary: 4, epic: 3, rare: 2, common: 1 };
    return order[rarity] || 0;
  };
  
  switch (mode) {
    case 'alphabetic':
      return [...powers].sort((a, b) => a.name.localeCompare(b.name));
    case 'quality':
      return [...powers].sort((a, b) => {
        const orderA = getRarityOrder(a.rarity);
        const orderB = getRarityOrder(b.rarity);
        if (orderA !== orderB) return orderB - orderA;
        return a.name.localeCompare(b.name);
      });
    case 'uses':
      return [...powers].sort((a, b) => {
        const powerDataA = ownedPowers[a.id];
        const powerDataB = ownedPowers[b.id];
        if (!powerDataA && !powerDataB) return 0;
        if (!powerDataA) return 1;
        if (!powerDataB) return -1;
        
        // Permanentes primero
        if (powerDataA.permanent && !powerDataB.permanent) return -1;
        if (!powerDataA.permanent && powerDataB.permanent) return 1;
        if (powerDataA.permanent && powerDataB.permanent) return a.name.localeCompare(b.name);
        
        // Luego por número de usos (descendente)
        const usesA = powerDataA.uses || 0;
        const usesB = powerDataB.uses || 0;
        if (usesA !== usesB) return usesB - usesA;
        return a.name.localeCompare(b.name);
      });
    case 'obtained':
    default:
      // Mantener orden de obtención (orden del catálogo)
      return [...powers].sort((a, b) => {
        const hasA = ownedPowers[a.id] ? 1 : 0;
        const hasB = ownedPowers[b.id] ? 1 : 0;
        if (hasA !== hasB) return hasB - hasA; // Los que tienes primero
        return a.id.localeCompare(b.id);
      });
  }
}

function updateCollectionCountDisplay(total, owned, visible = true) {
  if (!collectionCountDisplay) return;
  if (!visible) {
    collectionCountDisplay.style.display = 'none';
    return;
  }

  collectionCountDisplay.style.display = 'inline-flex';
  collectionCountDisplay.textContent = `${owned}/${total}`;
}

// Funciones de filtrado para poderes
function filterPowersByQuality(powers, rarity) {
  if (!rarity || rarity === 'all') return powers;
  return powers.filter(p => p.rarity === rarity);
}

function filterPowersByUses(powers, ownedPowers, usesValue) {
  if (usesValue === 'permanent') {
    return powers.filter(p => ownedPowers[p.id]?.permanent === true);
  }
  if (usesValue && !isNaN(parseInt(usesValue))) {
    const minUses = parseInt(usesValue);
    return powers.filter(p => {
      const powerData = ownedPowers[p.id];
      if (!powerData) return false;
      if (powerData.permanent) return true; // Permanentes cumplen cualquier mínimo
      return (powerData.uses || 0) >= minUses;
    });
  }
  return powers;
}

let isRenderingCollection = false;

async function renderCollection() {
  if (!isElectron) return; // modo dev http no soportado aquí
  
  if (isRenderingCollection) {
    console.log('[COLLECTION] Renderizado ya en progreso, saltando...');
    return;
  }
  isRenderingCollection = true;
  
  try {
    // Si el modo es poderes, renderizar poderes en su lugar
    if (collectionViewType === 'powers') {
      await renderPowersCollection();
      return;
    }
    
    const [allCards, inv] = await Promise.all([
      window.kvrcards.getAllCards(),
      window.kvrcards.getInventory(),
    ]);
    refreshCardFilterCatalogOptions(allCards);
    const remoteFilterOptions = await fetchRemoteCardFilterOptions();
    if (Array.isArray(remoteFilterOptions?.procedencias) && remoteFilterOptions.procedencias.length > 0) {
      availableProcedencias = remoteFilterOptions.procedencias;
    }
    if (Array.isArray(remoteFilterOptions?.owners) && remoteFilterOptions.owners.length > 0) {
      availableOwners = remoteFilterOptions.owners;
    }
    if (typeof updateFilterOptions === 'function') updateFilterOptions();
    if (typeof updateFilter2Options === 'function') updateFilter2Options();
    
    // Actualizar mapa de traits y upgrades global
    if (inv.ok && inv.cardTraits) {
      cardTraitsMap = inv.cardTraits;
    }
    if (inv.ok && inv.cardUpgrades) {
      cardUpgradesMap = inv.cardUpgrades;
    } else if (inv.ok) {
      cardUpgradesMap = {};
    }
    
    // Cargar availableTraits si no están cargados
    if (!availableTraits || availableTraits.length === 0) {
      try {
        if (window.kvrcards && window.kvrcards.getAllTraits) {
          availableTraits = await window.kvrcards.getAllTraits();
          console.log('[COLLECTION] availableTraits loaded:', availableTraits.length);
        }
      } catch (e) {
        console.error('[COLLECTION] Error loading traits:', e);
      }
    }

    try {
      const summary = await window.kvrcards.catalogSummary?.();
      if (summary?.ok) {
        const ver = summary.version ? `v${summary.version}` : '';
        catalogInfoEl.textContent = `${ver}`;
      }
    } catch {}
    const counts = inv.ok ? inv.cards : {};
    // mapa id -> card
    const map = new Map(allCards.map(c => [c.id, c]));
    
    const container = window.activeCollectionContainer || collectionDiv;
    container.innerHTML = '';
    
    // Cartas excluyendo calidad Evo para contadores y vista completa de coleccion
    const nonEvoCards = allCards.filter(c => !isCardEvoQuality(c));
    const visibleCardsForCounter = filterCards(nonEvoCards, counts);
    const ownedEntriesForCounter = filterOwnedCards(Object.entries(counts), map).filter(([id]) => {
      const c = map.get(id) || (typeof id === 'string' && id.includes('_') ? map.get(id.split('_')[0]) : null);
      return c && !isCardEvoQuality(c);
    });
    updateCollectionCountDisplay(
      visibleCardsForCounter.length,
      showCompleteCollection
        ? visibleCardsForCounter.filter(card => (counts[card.id] || 0) > 0).length
        : ownedEntriesForCounter.length,
      collectionViewType === 'cards'
    );
    
    if (showCompleteCollection) {
      // Vista completa: mostrar todas las cartas del juego (excluyendo calidad Evo)
      if (nonEvoCards.length === 0) {
        container.textContent = 'No hay cartas disponibles en el catálogo.';
        return;
      }
      // Filtrar y ordenar cartas segun el modo seleccionado
      let filteredCards = filterCards(nonEvoCards, counts);
      
      // Aplicar búsqueda por nombre si hay texto en el buscador
      const searchQuery = collectionSearchInput?.value.trim().toLowerCase();
      if (searchQuery) {
        filteredCards = filteredCards.filter(c => c.name.toLowerCase().includes(searchQuery));
      }
      
      const sortedCards = sortCards(filteredCards, counts, currentSortMode);
      const fragment = document.createDocumentFragment();
      
      for (const card of sortedCards) {
        const count = counts[card.id] || 0;
        const placeholder = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="280"><rect width="100%" height="100%" fill="#222"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#ccc" font-family="Arial" font-size="18">Carta</text></svg>');
        const rawCardUrl = (typeof normalizeAssetUrl === 'function' ? normalizeAssetUrl(card.imageUrl) : card.imageUrl) || placeholder;

        // Contabilizar instancias de trait para esta carta
        let traitInstancesForCard = [];
        for (const [instId, data] of Object.entries(cardTraitsMap)) {
          if (data && data.cardId && data.traitId && data.cardId === card.id) {
            traitInstancesForCard.push({ instanceId: instId, traitId: data.traitId });
          } else if (typeof data === 'string') {
            let cid = instId;
            if (instId.includes('_')) {
              const parts = instId.split('_');
              if (parts.length >= 3 && !isNaN(parts[parts.length - 1]) && !isNaN(parts[parts.length - 2])) {
                cid = parts.slice(0, -2).join('_');
              }
            }
            if (cid === card.id) {
              traitInstancesForCard.push({ instanceId: instId, traitId: data });
            }
          }
        }

        const validTraitInstances = count > 0 ? traitInstancesForCard.slice(0, count) : [];
        const countWithTrait = validTraitInstances.length;
        const countWithoutTrait = Math.max(0, count - countWithTrait);

        // 1. Si tiene copias con trait, crear una ficha individual para cada copia con trait (separación)
        validTraitInstances.forEach(({ instanceId, traitId }) => {
          const div = document.createElement('div');
          div.className = 'card owned unique-card';
          
          const img = document.createElement('img');
          img.onerror = () => { if (img.src !== placeholder) img.src = placeholder; };
          img.src = rawCardUrl;
          img.alt = card.name;
          img.addEventListener('click', () => openLightbox(img.src, { ...card, instanceId }, true, traitId, instanceId, 1, false));

          if (traitId && availableTraits && availableTraits.length > 0) {
            const trait = availableTraits.find(t => t.id === traitId);
            if (trait) {
              const traitIcon = document.createElement('div');
              traitIcon.className = 'card-trait-icon';
              traitIcon.innerHTML = `<img src="${trait.imageUrl}" alt="${trait.name}" title="${trait.name}" />`;
              div.appendChild(traitIcon);
            }
          }

          const title = document.createElement('div');
          title.textContent = card.name;
          div.appendChild(img);
          div.appendChild(title);
          fragment.appendChild(div);
        });

        // 2. Ficha para copias normales sin trait (o carta desposeída si count == 0)
        if (countWithoutTrait > 0 || count === 0) {
          const div = document.createElement('div');
          div.className = 'card';
          if (countWithoutTrait > 0) {
            div.classList.add('owned');
          } else {
            div.classList.add('unowned');
          }

          const img = document.createElement('img');
          img.onerror = () => { if (img.src !== placeholder) img.src = placeholder; };
          img.src = rawCardUrl;
          img.alt = card.name;
          img.addEventListener('click', () => openLightbox(img.src, card, countWithoutTrait > 0, null, null, countWithoutTrait, countWithoutTrait <= 0));

          const title = document.createElement('div');
          title.textContent = countWithoutTrait > 1 ? `${card.name} x${countWithoutTrait}` : card.name;
          div.appendChild(img);
          div.appendChild(title);
          fragment.appendChild(div);
        }
      }
      container.appendChild(fragment);
    } else {
      // Vista normal: solo cartas poseídas
      const entries = Object.entries(counts);
      if (entries.length === 0) {
        container.textContent = 'Aún no tienes cartas. Abre un sobre para conseguir cartas.';
        return;
      }
      // Filtrar y ordenar cartas poseídas según el modo seleccionado
      let filteredEntries = filterOwnedCards(entries, map);
      
      // Aplicar búsqueda por nombre si hay texto en el buscador
      const searchQuery = collectionSearchInput?.value.trim().toLowerCase();
      if (searchQuery) {
        filteredEntries = filteredEntries.filter(([id]) => {
          const card = map.get(id);
          return card && card.name.toLowerCase().includes(searchQuery);
        });
      }
      
      const sortedEntries = sortOwnedCards(filteredEntries, map, currentSortMode);
      
      // NUEVO SISTEMA: cardTraitsMap = {instanceId: {cardId, traitId}}
      // Procesar cada carta para separar las que tienen trait o upgrade
      const processedCards = [];
      
      // Primero, organizar traits por cardId
      const traitsByCard = {};
      for (const [instanceId, data] of Object.entries(cardTraitsMap)) {
        if (data && data.cardId && data.traitId) {
          if (!traitsByCard[data.cardId]) {
            traitsByCard[data.cardId] = [];
          }
          traitsByCard[data.cardId].push({ instanceId, traitId: data.traitId });
        } else if (typeof data === 'string') {
          let cardId = instanceId;
          if (instanceId.includes('_')) {
            const parts = instanceId.split('_');
            if (parts.length >= 3 && !isNaN(parts[parts.length - 1]) && !isNaN(parts[parts.length - 2])) {
              cardId = parts.slice(0, -2).join('_');
            }
          }
          if (!traitsByCard[cardId]) traitsByCard[cardId] = [];
          traitsByCard[cardId].push({ instanceId, traitId: data });
        }
      }

      // Organizar upgrades por cardId (excluyendo los que ya están en traits)
      const upgradesByCard = {};
      for (const [instanceId, data] of Object.entries(cardUpgradesMap)) {
        if (data && data.cardId) {
          if (!upgradesByCard[data.cardId]) {
            upgradesByCard[data.cardId] = [];
          }
          const alreadyInTraits = traitsByCard[data.cardId]?.some(t => t.instanceId === instanceId);
          if (!alreadyInTraits) {
            upgradesByCard[data.cardId].push({ instanceId, mediaBonus: Number(data.mediaBonus) || 0 });
          }
        }
      }
      
      for (const [id, count] of sortedEntries) {
        const card = map.get(id);
        if (!card) continue;
        
        const traitsForThisCard = (traitsByCard[id] || []).slice(0, count);
        const upgradesForThisCard = upgradesByCard[id] || [];
        
        const countWithTrait = traitsForThisCard.length;
        const countWithUpgrade = upgradesForThisCard.length;
        const countWithoutMod = Math.max(0, count - countWithTrait - countWithUpgrade);
        
        // 1. Añadir cada instancia con trait (y aplicar upgrade si también lo posee)
        traitsForThisCard.forEach(({ instanceId, traitId }) => {
          const upgradeData = cardUpgradesMap[instanceId];
          const bonus = upgradeData ? (Number(upgradeData.mediaBonus) || 0) : 0;
          processedCards.push({ 
            card: { ...card, instanceId: instanceId, media: (Number(card.media) || 75) + bonus, bonus }, 
            count: 1, 
            traitId: traitId, 
            isUnique: true 
          });
        });

        // 2. Añadir cada instancia con upgrade solo
        upgradesForThisCard.forEach(({ instanceId, mediaBonus }) => {
          processedCards.push({ 
            card: { ...card, instanceId: instanceId, media: (Number(card.media) || 75) + mediaBonus, bonus: mediaBonus }, 
            count: 1, 
            traitId: null, 
            isUnique: true 
          });
        });
        
        // 3. Añadir cartas estándar sin modificadores
        if (countWithoutMod > 0) {
          processedCards.push({ 
            card, 
            count: countWithoutMod,
            traitId: null, 
            isUnique: false 
          });
        }
      }
      
      // Renderizar todas las cartas procesadas de forma atómica usando DocumentFragment
      const fragment = document.createDocumentFragment();

      for (const { card, count, traitId, isUnique } of processedCards) {
        const div = document.createElement('div');
        div.className = 'card';
        if (isUnique) div.classList.add('unique-card');

        // Renderizar estado de selección si el hook está definido
        if (window.activeCollectionSelectionState && typeof window.activeCollectionSelectionState === 'function') {
          const selectedCount = window.activeCollectionSelectionState(card, isUnique);
          if (selectedCount > 0) {
            div.classList.add('selected-for-delivery');
            
            const badge = document.createElement('div');
            badge.className = 'delivery-selection-badge';
            badge.style.cssText = 'position: absolute; top: 8px; left: 8px; background: #22c55e; color: #fff; font-weight: bold; padding: 2px 8px; border-radius: 50%; font-size: 12px; z-index: 10;';
            badge.textContent = selectedCount;
            div.appendChild(badge);
          }
        }

        const img = document.createElement('img');
        const placeholder = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="280"><rect width="100%" height="100%" fill="#222"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#ccc" font-family="Arial" font-size="18">Carta</text></svg>');
        img.onerror = () => { if (img.src !== placeholder) img.src = placeholder; };
        img.src = card.imageUrl || placeholder;
        img.alt = card.name;
        
        const title = document.createElement('div');
        title.textContent = count > 1 ? `${card.name} x${count}` : card.name;
        
        // Añadir indicador de upgrade/mejora si tiene uno
        if (card.bonus && card.bonus > 0) {
          const upgradeBadge = document.createElement('div');
          upgradeBadge.className = 'card-upgrade-badge';
          upgradeBadge.style.cssText = 'position: absolute; top: 8px; right: 8px; background: linear-gradient(135deg, #fbbf24 0%, #d97706 100%); color: #000; font-weight: bold; border: 1.5px solid #f59e0b; padding: 2px 6px; border-radius: 6px; font-size: 10px; font-family: Outfit, sans-serif; box-shadow: 0 0 10px rgba(251, 191, 36, 0.45); z-index: 10;';
          upgradeBadge.textContent = `+${card.bonus}`;
          div.appendChild(upgradeBadge);
          
          title.textContent = `[+${card.bonus}] ${title.textContent}`;
          title.style.color = '#fbbf24';
        }
        
        // Añadir indicador de trait si existe
        if (traitId && availableTraits && availableTraits.length > 0) {
          const trait = availableTraits.find(t => t.id === traitId);
          if (trait) {
            const traitIcon = document.createElement('div');
            traitIcon.className = 'card-trait-icon';
            const traitImg = document.createElement('img');
            traitImg.src = trait.imageUrl;
            traitImg.alt = trait.name;
            traitImg.title = trait.name;
            traitIcon.appendChild(traitImg);
            div.appendChild(traitIcon);
          }
        }
        
        div.appendChild(img);
        div.appendChild(title);
        
        // Añadir click event al div completo
        div.style.cursor = 'pointer';
        if (window.activeCollectionCardClick && typeof window.activeCollectionCardClick === 'function') {
          div.onclick = (e) => {
            window.activeCollectionCardClick(card, isUnique, count);
          };
        } else {
          div.onclick = () => {
            openLightbox(img.src, card, true, traitId, card.instanceId, count);
          };
        }
        
        fragment.appendChild(div);
      }
      container.appendChild(fragment);
    }
  } catch (error) {
    console.error('[COLLECTION] Error renderizando colección:', error);
    const container = window.activeCollectionContainer || collectionDiv;
    container.innerHTML = '<div style="text-align: center; padding: 40px; color: #ef4444;">❌ Error cargando colección</div>';
  } finally {
    isRenderingCollection = false;
  }
}

// Renderizar colección de poderes
async function renderPowersCollection() {
  if (!isElectron) return;
  
  try {
    const [allPowers, powersInv] = await Promise.all([
      window.kvrcards.getAllPowers(),
      window.kvrcards.getPowersInventory()
    ]);
    
    const ownedPowers = powersInv.ok ? powersInv.powers : {};
    const container = window.activeCollectionContainer || collectionDiv;
    container.innerHTML = '';
    
    // Filtrar poderes según colección completa o no
    let powersToShow = allPowers;
    if (!showCompleteCollection) {
      powersToShow = allPowers.filter(p => ownedPowers[p.id]);
    }
    
    // Aplicar Filtro 1 (funciona de forma independiente)
    console.log('[FILTRO 1] Tipo:', currentFilterType, 'Valor:', currentFilterValue);
    console.log('[FILTRO 1] Poderes antes de filtrar:', powersToShow.length, powersToShow.map(p => `${p.name} (${p.rarity})`));
    if (currentFilterType === 'quality' && currentFilterValue) {
      powersToShow = filterPowersByQuality(powersToShow, currentFilterValue);
      console.log('[FILTRO 1] Poderes después de filtrar por calidad:', powersToShow.length, powersToShow.map(p => `${p.name} (${p.rarity})`));
    } else if (currentFilterType === 'uses' && currentFilterValue) {
      powersToShow = filterPowersByUses(powersToShow, ownedPowers, currentFilterValue);
      console.log('[FILTRO 1] Poderes después de filtrar por usos:', powersToShow.length);
    }
    
    // Aplicar Filtro 2 solo si Filtro 1 está activo (es complementario)
    if (currentFilterType !== 'none' && currentFilterType2 !== 'none') {
      if (currentFilterType2 === 'quality' && currentFilterValue2) {
        powersToShow = filterPowersByQuality(powersToShow, currentFilterValue2);
      } else if (currentFilterType2 === 'uses' && currentFilterValue2) {
        powersToShow = filterPowersByUses(powersToShow, ownedPowers, currentFilterValue2);
      }
    }
    
    // Aplicar búsqueda por nombre si hay texto en el buscador
    const searchQuery = collectionSearchInput?.value.trim().toLowerCase();
    if (searchQuery) {
      powersToShow = powersToShow.filter(p => p.name.toLowerCase().includes(searchQuery));
    }

    const visiblePowersTotal = powersToShow.length;
    const visibleOwnedPowers = powersToShow.filter(p => !!ownedPowers[p.id]).length;
    updateCollectionCountDisplay(
      visiblePowersTotal,
      showCompleteCollection ? visibleOwnedPowers : visiblePowersTotal,
      true
    );
    
    // Aplicar ordenación
    powersToShow = sortPowers(powersToShow, ownedPowers, currentSortMode);
    
    if (powersToShow.length === 0) {
      container.innerHTML = '<div style="text-align: center; padding: 40px; color: #9ca3af; font-size: 16px;">⚡ No hay poderes que coincidan con los filtros.</div>';
      return;
    }
    
    // Crear tarjetas de poderes
    for (const power of powersToShow) {
      const powerData = ownedPowers[power.id];
      const isOwned = !!powerData;
      
      const div = document.createElement('div');
      div.className = 'card power-card';
      
      // Si lo posees en colección completa, añadir clase 'owned' para borde amarillo
      if (isOwned && showCompleteCollection) {
        div.classList.add('owned');
      }
      
      // Si no lo posees, aplicar opacidad reducida
      if (!isOwned && showCompleteCollection) {
        div.style.opacity = '0.3';
        div.style.filter = 'grayscale(80%)';
      }
      
      // Imagen del poder
      const img = document.createElement('img');
      const placeholder = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="280"><rect width="100%" height="100%" fill="#1f2937"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#fbbf24" font-family="Arial" font-size="48">⚡</text></svg>');
      img.onerror = () => { if (img.src !== placeholder) img.src = placeholder; };
      img.src = power.imageUrl || placeholder;
      img.alt = power.name;
      
      // Click para abrir lightbox con detalles completos (solo si lo posees)
      if (isOwned) {
        img.addEventListener('click', () => openPowerLightbox(power, powerData));
      }
      
      // Información básica del poder
      const info = document.createElement('div');
      info.className = 'power-info';
      
      const title = document.createElement('div');
      title.className = 'power-title';
      title.textContent = power.name;
      
      const quantity = document.createElement('div');
      quantity.className = 'power-quantity';
      
      if (isOwned) {
        if (powerData.permanent) {
          quantity.innerHTML = '<span style="color: #10b981; font-weight: bold;">♾️ PERMANENTE</span>';
        } else if (powerData.uses !== undefined) {
          const usesColor = powerData.uses > 3 ? '#10b981' : powerData.uses > 0 ? '#f59e0b' : '#ef4444';
          quantity.innerHTML = `<span style="color: ${usesColor}; font-weight: bold;">🔄 ${powerData.uses} usos</span>`;
        }
      } else {
        quantity.innerHTML = '<span style="color: #6b7280; font-size: 12px;">No poseído</span>';
      }
      
      info.appendChild(title);
      info.appendChild(quantity);
      
      div.appendChild(img);
      div.appendChild(info);
      
      container.appendChild(div);
    }
  } catch (error) {
    console.error('[POWERS] Error renderizando poderes:', error);
    const container = window.activeCollectionContainer || collectionDiv;
    container.innerHTML = '<div style="text-align: center; padding: 40px; color: #ef4444;">❌ Error cargando poderes</div>';
  }
}

// Abrir lightbox para mostrar detalles completos de un poder
function openPowerLightbox(power, powerData) {
  const lightboxBackdrop = document.getElementById('lightbox');
  const lightboxContent = lightboxBackdrop?.querySelector('.lightbox-content');
  const lightboxImg = document.getElementById('lightbox-img');
  const lightboxSellBtn = document.getElementById('lightbox-sell');
  
  if (!lightboxBackdrop || !lightboxImg) return;
  lightboxImg.classList.remove('unowned');
  lightboxImg.style.filter = '';
  
  // Ocultar botón de venta
  if (lightboxSellBtn) lightboxSellBtn.style.display = 'none';
  
  // Traducciones de rareza
  const rarityTranslations = {
    common: 'Común',
    rare: 'Raro',
    epic: 'Épico',
    legendary: 'Legendario'
  };
  
  const rarityColors = {
    common: '#9ca3af',
    rare: '#3b82f6',
    epic: '#a855f7',
    legendary: '#f59e0b'
  };
  
  const rarityText = rarityTranslations[power.rarity] || power.rarity;
  const rarityColor = rarityColors[power.rarity] || '#9ca3af';
  
  // Establecer imagen
  lightboxImg.src = power.imageUrl || 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="280"><rect width="100%" height="100%" fill="#1f2937"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#fbbf24" font-family="Arial" font-size="48">⚡</text></svg>');
  lightboxImg.alt = power.name;
  
  // Construir información del poder
  let usesInfo = '';
  if (powerData.permanent) {
    usesInfo = '<span style="color: #10b981; font-weight: bold; background: rgba(16, 185, 129, 0.1); padding: 4px 12px; border-radius: 6px; display: inline-block; margin-left: 12px;">♾️ PERMANENTE</span>';
  } else if (powerData.uses !== undefined) {
    const usesColor = powerData.uses > 3 ? '#10b981' : powerData.uses > 0 ? '#f59e0b' : '#ef4444';
    usesInfo = `<span style="color: ${usesColor}; font-weight: bold; background: rgba(${powerData.uses > 3 ? '16, 185, 129' : powerData.uses > 0 ? '245, 158, 11' : '239, 68, 68'}, 0.1); padding: 4px 12px; border-radius: 6px; display: inline-block; margin-left: 12px;">🔄 ${powerData.uses} ${powerData.uses === 1 ? 'uso' : 'usos'}</span>`;
  }
  
  // Eliminar info de poderes previa si existe
  const existingPowerInfo = lightboxContent?.querySelector('.power-lightbox-info');
  if (existingPowerInfo) existingPowerInfo.remove();
  
  // Crear contenedor de información del poder
  const powerInfo = document.createElement('div');
  powerInfo.className = 'power-lightbox-info';
  powerInfo.innerHTML = `
    <div style="display: flex; align-items: center; justify-content: center; gap: 12px; margin-bottom: 12px; flex-wrap: wrap;">
      <span style="color: ${rarityColor}; font-weight: bold; font-size: 14px; text-transform: uppercase; letter-spacing: 1px;">✦ ${rarityText}</span>
      ${usesInfo}
    </div>
    <h3 style="color: #fbbf24; font-size: 24px; margin: 8px 0 16px 0; text-align: center;">⚡ ${power.name}</h3>
    <div style="background: linear-gradient(135deg, #1f2937 0%, #111827 100%); border: 2px solid #374151; border-radius: 12px; padding: 16px; margin-top: 12px;">
      <p style="color: #e5e7eb; font-size: 15px; line-height: 1.6; margin: 0; text-align: center;">${power.description}</p>
    </div>
  `;
  
  // Insertar la información después de la imagen
  if (lightboxContent) {
    lightboxImg.insertAdjacentElement('afterend', powerInfo);
  }
  
  lightboxBackdrop.classList.add('show');
}

/* ==================== REGISTRO COMPLETO DE CARTAS ==================== */
let registryCatalogCards = null;
let isRegistryInitialized = false;

async function openCardRegistryModal() {
  const modal = document.getElementById('card-registry-modal');
  if (!modal) return;
  modal.style.display = 'flex';
  modal.setAttribute('aria-hidden', 'false');

  try {
    if (window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
      registryCatalogCards = await window.kvrcards.getAllCards();
    }
  } catch (err) {
    console.error('[REGISTRY] Error al cargar cartas:', err);
    if (!registryCatalogCards) registryCatalogCards = [];
  }

  await populateRegistryQualities(registryCatalogCards || []);
  populateRegistryProcedencias(registryCatalogCards || []);
  renderCardRegistry();
}

function closeCardRegistryModal() {
  const modal = document.getElementById('card-registry-modal');
  if (!modal) return;
  modal.style.display = 'none';
  modal.setAttribute('aria-hidden', 'true');
}

async function populateRegistryQualities(cards) {
  const select = document.getElementById('card-registry-filter-quality');
  if (!select) return;
  const currentVal = select.value;

  // Refrescar calidades dinámicas si existe la función (como en Mi Colección)
  if (typeof refreshFilterQualities === 'function') {
    try { await refreshFilterQualities(); } catch (e) {}
  } else if (typeof window.refreshFilterQualities === 'function') {
    try { await window.refreshFilterQualities(); } catch (e) {}
  }

  const qualitySet = new Set();
  const baseQualities = (window.dynamicFilterQualities && Array.isArray(window.dynamicFilterQualities) && window.dynamicFilterQualities.length > 0)
    ? window.dynamicFilterQualities
    : ['Bronce', 'Plata', 'Oro', 'Especiales', 'Icono', 'Heroe', 'Icono Prime', 'Icono Super Prime', 'Evo'];

  baseQualities.forEach(q => {
    if (q) qualitySet.add(String(q).trim());
  });

  // Agregar calidades adicionales que existan en las cartas del catálogo
  if (Array.isArray(cards)) {
    for (const c of cards) {
      const q = String(c.calidad || c.quality || '').trim();
      if (q && !qualitySet.has(q)) {
        qualitySet.add(q);
      }
    }
  }

  select.innerHTML = '<option value="all">Todas las calidades</option>';
  for (const q of qualitySet) {
    const opt = document.createElement('option');
    opt.value = q;
    opt.textContent = q === 'Heroe' ? 'Héroe' : q;
    select.appendChild(opt);
  }

  if (qualitySet.has(currentVal) || currentVal === 'all') {
    select.value = currentVal;
  }
}

function populateRegistryProcedencias(cards) {
  const select = document.getElementById('card-registry-filter-procedencia');
  if (!select) return;
  const currentVal = select.value;
  const set = new Set();

  if (Array.isArray(cards)) {
    for (const c of cards) {
      const p = String(c.procedencia || c.origen || c.source || '').trim();
      if (p) set.add(p);
    }
  }

  // Vincular con availableProcedencias (igual que en Mi Colección)
  const procs = window.availableProcedencias || (typeof availableProcedencias !== 'undefined' ? availableProcedencias : []);
  if (Array.isArray(procs)) {
    procs.forEach(p => {
      const pt = String(p || '').trim();
      if (pt) set.add(pt);
    });
  }

  const sorted = Array.from(set).sort((a, b) => a.localeCompare(b, 'es', { sensitivity: 'base' }));

  select.innerHTML = '<option value="all">Todas las procedencias</option>';
  for (const proc of sorted) {
    const opt = document.createElement('option');
    opt.value = proc;
    opt.textContent = proc;
    select.appendChild(opt);
  }
  if (set.has(currentVal) || currentVal === 'all') {
    select.value = currentVal;
  }
}

function renderCardRegistry() {
  const container = document.getElementById('card-registry-cards');
  const countDisplay = document.getElementById('card-registry-count');
  if (!container || !registryCatalogCards) return;

  const searchInput = document.getElementById('card-registry-search');
  const qualitySelect = document.getElementById('card-registry-filter-quality');
  const procedenciaSelect = document.getElementById('card-registry-filter-procedencia');
  const mediaInput = document.getElementById('card-registry-filter-media');
  const sortSelect = document.getElementById('card-registry-sort');

  const searchText = (searchInput?.value || '').trim().toLowerCase();
  const selectedQuality = qualitySelect?.value || 'all';
  const selectedProcedencia = procedenciaSelect?.value || 'all';
  const minMedia = mediaInput?.value !== '' && !isNaN(Number(mediaInput.value)) ? Number(mediaInput.value) : null;
  const sortMode = sortSelect?.value || 'media-desc';

  let list = registryCatalogCards.slice();

  // Filtro de texto
  if (searchText) {
    list = list.filter(c => {
      const name = String(c.name || c.nombre || '').toLowerCase();
      const club = String(c.club || '').toLowerCase();
      const proc = String(c.procedencia || c.origen || c.source || '').toLowerCase();
      const owner = String(c.owner || '').toLowerCase();
      const pos = String(c.position || c.posicion || '').toLowerCase();
      const quality = String(c.calidad || c.quality || c.calidadId || '').toLowerCase();
      return name.includes(searchText) || club.includes(searchText) || proc.includes(searchText) || owner.includes(searchText) || pos.includes(searchText) || quality.includes(searchText);
    });
  }

  // Filtro de Calidad
  if (selectedQuality !== 'all') {
    const qTarget = selectedQuality.toLowerCase();
    if (qTarget === 'especiales') {
      list = list.filter(c => {
        return typeof isCardSpecialQuality === 'function'
          ? isCardSpecialQuality(c)
          : (typeof isSpecialQuality === 'function' ? isSpecialQuality(c.calidad || c.quality || c.calidadId) : false);
      });
    } else if (qTarget === 'evo') {
      list = list.filter(c => (typeof isCardEvoQuality === 'function' && isCardEvoQuality(c)) || String(c.calidad || c.quality || '').toLowerCase() === 'evo');
    } else {
      list = list.filter(c => {
        const qName = String(c.calidad || c.quality || '').trim().toLowerCase();
        const qId = String(c.calidadId || '').trim().toLowerCase();
        return qName === qTarget || qId === qTarget;
      });
    }
  }

  // Filtro de Procedencia
  if (selectedProcedencia !== 'all') {
    const pTarget = selectedProcedencia.toLowerCase();
    list = list.filter(c => {
      const proc = String(c.procedencia || c.origen || c.source || '').trim().toLowerCase();
      return proc === pTarget;
    });
  }

  // Filtro de Media
  if (minMedia !== null) {
    list = list.filter(c => Number(c.media || 0) >= minMedia);
  }

  // Ordenacion
  list.sort((a, b) => {
    if (sortMode === 'media-desc') {
      return (Number(b.media) || 0) - (Number(a.media) || 0);
    } else if (sortMode === 'media-asc') {
      return (Number(a.media) || 0) - (Number(b.media) || 0);
    } else if (sortMode === 'alphabetic') {
      return String(a.name || '').localeCompare(String(b.name || ''));
    } else if (sortMode === 'quality') {
      const orderA = getQualityOrder(a.calidad);
      const orderB = getQualityOrder(b.calidad);
      if (orderA !== orderB) return orderB - orderA;
      return (Number(b.media) || 0) - (Number(a.media) || 0);
    }
    return 0;
  });

  if (countDisplay) {
    countDisplay.textContent = `${list.length} cartas`;
  }

  container.innerHTML = '';
  if (list.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'card-registry-empty';
    empty.textContent = 'No se encontraron cartas con los filtros seleccionados.';
    container.appendChild(empty);
    return;
  }

  const fragment = document.createDocumentFragment();
  const placeholder = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="280"><rect width="100%" height="100%" fill="#222"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="#ccc" font-family="Arial" font-size="18">Carta</text></svg>');

  for (const card of list) {
    const item = document.createElement('div');
    item.className = 'card-registry-card';

    const isEvo = isCardEvoQuality(card);
    const cardQualityName = String(card.calidad || card.quality || (isEvo ? 'Evo' : 'Estandar')).trim();

    const imgWrap = document.createElement('div');
    imgWrap.className = 'card-registry-card-img-wrap';

    const img = document.createElement('img');
    img.loading = 'lazy';
    img.onerror = () => { if (img.src !== placeholder) img.src = placeholder; };
    const rawUrl = card.imageUrl || card.image || '';
    img.src = (typeof normalizeAssetUrl === 'function' ? normalizeAssetUrl(rawUrl) : rawUrl) || placeholder;
    img.alt = card.name || 'Carta';
    imgWrap.appendChild(img);

    const info = document.createElement('div');
    info.className = 'card-registry-card-info';

    const name = document.createElement('div');
    name.className = 'card-registry-card-name';
    name.textContent = card.name || 'Sin nombre';
    name.title = card.name || '';

    const meta = document.createElement('div');
    meta.className = 'card-registry-card-meta';

    const mediaSpan = document.createElement('span');
    mediaSpan.textContent = `Media: ${card.media || '?'}`;

    const badge = document.createElement('span');
    badge.className = `card-registry-card-badge${isEvo ? ' badge-evo' : ''}`;
    badge.textContent = cardQualityName;

    meta.appendChild(mediaSpan);
    meta.appendChild(badge);

    info.appendChild(name);
    info.appendChild(meta);

    item.appendChild(imgWrap);
    item.appendChild(info);

    // Al hacer click, abrir visor ampliado a todo color (sin filtro gris de desposeida)
    item.addEventListener('click', () => {
      openLightbox(img.src, card, false, null, null, 0, false, true);
    });

    fragment.appendChild(item);
  }

  container.appendChild(fragment);
}

function initCardRegistry() {
  if (isRegistryInitialized) return;
  const openBtn = document.getElementById('open-card-registry-btn');
  const closeBtn = document.getElementById('card-registry-close-btn');
  const overlay = document.getElementById('card-registry-overlay');
  const resetBtn = document.getElementById('card-registry-reset-btn');
  const searchInput = document.getElementById('card-registry-search');
  const qualitySelect = document.getElementById('card-registry-filter-quality');
  const procedenciaSelect = document.getElementById('card-registry-filter-procedencia');
  const mediaInput = document.getElementById('card-registry-filter-media');
  const sortSelect = document.getElementById('card-registry-sort');

  if (!openBtn && !closeBtn && !searchInput) return;
  isRegistryInitialized = true;

  openBtn?.addEventListener('click', () => {
    openCardRegistryModal();
  });

  closeBtn?.addEventListener('click', () => {
    closeCardRegistryModal();
  });

  overlay?.addEventListener('click', () => {
    closeCardRegistryModal();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const modal = document.getElementById('card-registry-modal');
      if (modal && modal.style.display !== 'none') {
        closeCardRegistryModal();
      }
    }
  });

  let debounceTimer = null;
  searchInput?.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(renderCardRegistry, 150);
  });

  qualitySelect?.addEventListener('change', renderCardRegistry);
  procedenciaSelect?.addEventListener('change', renderCardRegistry);
  mediaInput?.addEventListener('input', renderCardRegistry);
  sortSelect?.addEventListener('change', renderCardRegistry);

  resetBtn?.addEventListener('click', () => {
    if (searchInput) searchInput.value = '';
    if (qualitySelect) qualitySelect.value = 'all';
    if (procedenciaSelect) procedenciaSelect.value = 'all';
    if (mediaInput) mediaInput.value = '';
    if (sortSelect) sortSelect.value = 'media-desc';
    renderCardRegistry();
  });
}

// Inicializar cuando el DOM este listo
if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCardRegistry);
  } else {
    setTimeout(initCardRegistry, 0);
  }
}

window.openCardRegistryModal = openCardRegistryModal;
window.closeCardRegistryModal = closeCardRegistryModal;
window.initCardRegistry = initCardRegistry;
window.renderCardRegistry = renderCardRegistry;


