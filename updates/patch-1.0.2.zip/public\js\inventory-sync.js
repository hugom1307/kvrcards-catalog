
// Cerrar sesión
async function handleLogout() {
  console.log('[AUTH] handleLogout called');
  
  // NO USAR window.confirm - rompe el estado de Electron
  // Usar confirmación simple con prompt interno
  const shouldLogout = await new Promise((resolve) => {
    const message = '¿Cerrar sesión? Deberás iniciar sesión nuevamente.';
    // Por ahora simplemente hacer logout sin confirmar para evitar el bug
    // TODO: Implementar modal de confirmación custom
    resolve(true);
  });
  
  if (!shouldLogout) {
    console.log('[AUTH] User cancelled logout');
    return;
  }
  
  console.log('[AUTH] Clearing session and showing auth modal');
  
  // Limpiar sesión actual (no borramos avatares, están asociados por usuario)
  currentUser = null;
  currentUserPassword = null;
  userAvatar = null;
  userProfile = { 
    profileImage: '',
    title: 'Novato',
    currentTitle: 'Novato',
    description: 'Sin descripción', 
    unlockedTitles: ['novato'],
    showcaseCards: [null, null, null],
    stats: { 
      totalCardsObtained: 0,
      totalPacksOpened: 0,
      totalCoinsEarned: 0
    } 
  };
  localStorage.removeItem('kvrUsername');
  localStorage.removeItem('kvrPassword');
  localStorage.removeItem('userId'); // Limpiar userId para sistema de amigos
  
  // Cerrar HUD
  hudPanel?.classList.remove('show');
  
  // Limpiar y habilitar campos explícitamente
  console.log('[AUTH] Clearing and enabling inputs');
  if (loginUsername) {
    loginUsername.value = '';
    loginUsername.disabled = false;
    loginUsername.readOnly = false;
  }
  if (loginPassword) {
    loginPassword.value = '';
    loginPassword.disabled = false;
    loginPassword.readOnly = false;
  }
  if (registerUsername) {
    registerUsername.value = '';
    registerUsername.disabled = false;
    registerUsername.readOnly = false;
  }
  if (registerPassword) {
    registerPassword.value = '';
    registerPassword.disabled = false;
    registerPassword.readOnly = false;
  }
  if (registerPasswordConfirm) {
    registerPasswordConfirm.value = '';
    registerPasswordConfirm.disabled = false;
    registerPasswordConfirm.readOnly = false;
  }
  
  // CRÍTICO: Forzar focus de la ventana después del confirm
  // El dialog confirm captura el focus y lo deja corrupto
  try {
    await window.kvrcards.windowForceFocus();
    console.log('[AUTH] Window focus restored after logout');
  } catch (err) {
    console.error('[AUTH] Failed to restore window focus:', err);
  }
  
  // Esperar un poco para que Electron procese el focus
  await new Promise(resolve => setTimeout(resolve, 50));
  
  // Mostrar modal de auth (obligatorio para seguir jugando)
  showAuthModal();
}

// Verificar y ofrecer sincronización desde la nube al hacer login
async function checkAndOfferCloudSync() {
  if (!currentUser) return;
  
  try {
    console.log('[CLOUD SYNC] Verificando datos en R2...');
    
    // Obtener datos actuales del inventario local
    const localInv = await window.kvrcards.getInventory();
    if (!localInv.ok) {
      console.log('[CLOUD SYNC] No se pudo obtener inventario local');
      return;
    }
    
    // Obtener datos de R2
    const remoteData = await window.kvrcards.getRemoteInventory();
    if (!remoteData.ok || !remoteData.data) {
      console.log('[CLOUD SYNC] No hay datos en R2 o error al obtener');
      return;
    }
    
    const cloudData = remoteData.data;
    
    // Comparar timestamps si existen
    const localTimestamp = localInv.updatedAt || 0;
    const cloudTimestamp = cloudData.updatedAt || 0;
    
    console.log('[CLOUD SYNC] Local timestamp:', localTimestamp, new Date(localTimestamp));
    console.log('[CLOUD SYNC] Cloud timestamp:', cloudTimestamp, new Date(cloudTimestamp));
    
    // Si el timestamp de la nube es más reciente que el local, ofrecer descargar
    if (cloudTimestamp > localTimestamp && cloudTimestamp > 0) {
      const cloudCardsCount = Object.keys(cloudData.cards || {}).length;
      const cloudPacksCount = Object.keys(cloudData.packs || {}).length;
      const cloudCoins = cloudData.wallet?.coins || 0;
      const cloudKvr = cloudData.wallet?.kvr || 0;
      const cloudTraits = cloudData.wallet?.traits || 0;
      
      const localCardsCount = Object.keys(localInv.cards || {}).length;
      const localPacksCount = Object.keys(localInv.packs || {}).length;
      const localCoins = localInv.wallet?.coins || 0;
      const localKvr = localInv.wallet?.kvr || 0;
      const localTraits = localInv.wallet?.traits || 0;
      
      const timeDiff = Math.floor((cloudTimestamp - localTimestamp) / 1000 / 60); // minutos
      
      const confirmMsg = 
        '☁️ Se detectaron datos más recientes en la nube\n\n' +
        `⏰ Última actualización: hace ${timeDiff} minutos\n\n` +
        '📊 DATOS EN LA NUBE:\n' +
        `🃏 Cartas: ${cloudCardsCount}\n` +
        `📦 Sobres: ${cloudPacksCount}\n` +
        `💰 Coins: ${cloudCoins}\n` +
        `💎 KvR: ${cloudKvr}\n` +
        `✨ Traits: ${cloudTraits}\n\n` +
        '📊 DATOS LOCALES ACTUALES:\n' +
        `🃏 Cartas: ${localCardsCount}\n` +
        `📦 Sobres: ${localPacksCount}\n` +
        `💰 Coins: ${localCoins}\n` +
        `💎 KvR: ${localKvr}\n` +
        `✨ Traits: ${localTraits}\n\n` +
        '¿Deseas cargar los datos de la nube?\n' +
        '(Se sobrescribirán tus datos locales actuales)';
      
      if (confirm(confirmMsg)) {
        await applyCloudData(cloudData);
        alert('✅ Datos cargados desde la nube correctamente');
        // Recargar vistas
        await Promise.all([renderCollection(), renderOwnedPacks(), renderShop(), renderWallet()]);
      }
    } else {
      console.log('[CLOUD SYNC] Los datos locales están actualizados o son más recientes');
    }
  } catch (e) {
    console.error('[CLOUD SYNC] Error en verificación:', e);
  }
}

// Aplicar datos de la nube
async function applyCloudData(cloudData) {
  const applyPayload = {
    inventory: {
      cards: cloudData.cards || {},
      packs: cloudData.packs || {},
      cardTraits: cloudData.cardTraits || {},
      wallet: cloudData.wallet || { coins: 0, kvr: 0, traits: 0 },
      stats: cloudData.stats || {},
      weeklyStats: cloudData.weeklyStats || {},
      profileImage: cloudData.profileImage || '',
      currentTitle: cloudData.currentTitle || '',
      unlockedTitles: Array.isArray(cloudData.unlockedTitles) ? cloudData.unlockedTitles : ['novato'],
      currentBackground: cloudData.currentBackground || 'default',
      unlockedBackgrounds: Array.isArray(cloudData.unlockedBackgrounds) ? cloudData.unlockedBackgrounds : ['default'],
      showcaseCards: cloudData.showcaseCards || [null, null, null],
      supporterBlessing: cloudData.supporterBlessing || null,
      friends: cloudData.friends || [],
      friendRequests: cloudData.friendRequests || [],
      sentRequests: cloudData.sentRequests || []
    }
  };
  
  const applyResult = await window.kvrcards.cloudApplyData(applyPayload);
  
  if (!applyResult.ok) {
    throw new Error(applyResult.error || 'Error al aplicar datos');
  }
}

// Descargar desde la nube (R2)
async function downloadFromCloud() {
  if (!currentUser || !currentUserPassword) {
    alert('No hay sesión activa');
    return;
  }
  
  const confirmMsg = '⚠️ ATENCIÓN: Esto reemplazará tus datos locales con los de R2\n\n' +
    '¿Estás seguro de que quieres continuar?';
  
  if (!confirm(confirmMsg)) {
    return;
  }
  
  console.log('[R2 DOWNLOAD] Descargando datos desde R2...');
  
  try {
    // Consultar datos de R2 directamente
    const remoteData = await window.kvrcards.getRemoteInventory();
    
    if (!remoteData.ok) {
      alert('❌ Error: ' + (remoteData.error || 'No se pudieron obtener los datos de R2'));
      return;
    }
    
    const data = remoteData.data;
    
    if (!data || !data.cards) {
      alert('❌ No hay datos guardados en R2 para este usuario');
      return;
    }
    
    console.log('[R2 DOWNLOAD] Datos encontrados en R2:', {
      cards: Object.keys(data.cards || {}).length,
      packs: Object.keys(data.packs || {}).length,
      wallet: data.wallet
    });
    
    // Confirmar antes de aplicar
    const cardsCount = Object.keys(data.cards || {}).length;
    const packsCount = Object.keys(data.packs || {}).length;
    const coins = data.wallet?.coins || 0;
    const kvr = data.wallet?.kvr || 0;
    const traits = data.wallet?.traits || 0;
    
    const confirmApply = confirm(
      `📦 Datos encontrados en R2:\n\n` +
      `🃏 Cartas: ${cardsCount}\n` +
      `📮 Sobres: ${packsCount}\n` +
      `💰 Coins: ${coins}\n` +
      `💎 KvR: ${kvr}\n` +
      `✨ Traits: ${traits}\n\n` +
      `¿Aplicar estos datos?`
    );
    
    if (!confirmApply) {
      return;
    }
    
    // Aplicar datos usando la función auxiliar
    await applyCloudData(data);
    
    alert('✅ Datos de R2 aplicados correctamente\n\n🔄 Reiniciando aplicación...');
    
    // Recargar la app
    window.location.reload();
  } catch (e) {
    console.error('[R2 DOWNLOAD] Error:', e);
    alert('❌ Error al descargar desde R2: ' + e.message);
  }
}

