
// Cerrar sesión
async function handleLogout() {
  console.log('[AUTH] handleLogout called');
  
  // Notificar al backend de Electron para resetear memoria
  if (window.kvrcards && typeof window.kvrcards.logout === 'function') {
    try {
      await window.kvrcards.logout();
      console.log('[AUTH] Backend Electron desconectado exitosamente');
    } catch (e) {
      console.error('[AUTH] Error al desconectar backend:', e);
    }
  }
  
  console.log('[AUTH] Clearing session and showing auth modal');
  
  // Limpiar sesión actual
  currentUser = null;
  currentUserPassword = null;
  userAvatar = null;
  userProfile = { 
    profileImage: '',
    title: 'Novato',
    currentTitle: 'Novato',
    description: 'Sin descripción', 
    unlockedTitles: ['novato'],
    showcaseCards: [null, null, null],
    stats: { 
      totalCardsObtained: 0,
      totalPacksOpened: 0,
      totalCoinsEarned: 0
    } 
  };
  if (typeof userKizunas !== 'undefined') userKizunas = {};
  if (typeof userMissions !== 'undefined') userMissions = {};
  if (typeof userEvolutions !== 'undefined') userEvolutions = {};
  
  localStorage.removeItem('kvrUsername');
  localStorage.removeItem('kvrPassword');
  localStorage.removeItem('userId');
  try { localStorage.removeItem('kvr_user_kizunas'); } catch {}
  
  // Cerrar HUD
  hudPanel?.classList.remove('show');
  
  // Limpiar y habilitar campos explícitamente
  console.log('[AUTH] Clearing and enabling inputs');
  if (loginUsername) {
    loginUsername.value = '';
    loginUsername.disabled = false;
    loginUsername.readOnly = false;
  }
  if (loginPassword) {
    loginPassword.value = '';
    loginPassword.disabled = false;
    loginPassword.readOnly = false;
  }
  if (registerUsername) {
    registerUsername.value = '';
    registerUsername.disabled = false;
    registerUsername.readOnly = false;
  }
  if (registerPassword) {
    registerPassword.value = '';
    registerPassword.disabled = false;
    registerPassword.readOnly = false;
  }
  if (registerPasswordConfirm) {
    registerPasswordConfirm.value = '';
    registerPasswordConfirm.disabled = false;
    registerPasswordConfirm.readOnly = false;
  }
  
  // Forzar focus de la ventana
  try {
    await window.kvrcards.windowForceFocus();
    console.log('[AUTH] Window focus restored after logout');
  } catch (err) {
    console.error('[AUTH] Failed to restore window focus:', err);
  }
  
  await new Promise(resolve => setTimeout(resolve, 50));
  showAuthModal();
}

// Verificar y ofrecer sincronización desde la nube al hacer login
async function checkAndOfferCloudSync() {
  if (!currentUser) return;
  
  try {
    console.log('[CLOUD SYNC] Verificando datos en R2...');
    
    // Obtener datos actuales del inventario local
    const localInv = await window.kvrcards.getInventory();
    if (!localInv.ok) {
      console.log('[CLOUD SYNC] No se pudo obtener inventario local');
      return;
    }
    
    // Obtener datos de R2
    const remoteData = await window.kvrcards.getRemoteInventory();
    if (!remoteData.ok || !remoteData.data) {
      console.log('[CLOUD SYNC] No hay datos en R2 o error al obtener');
      return;
    }
    
    const cloudData = remoteData.data;
    
    // Comparar timestamps si existen
    const localTimestamp = localInv.updatedAt || 0;
    const cloudTimestamp = cloudData.updatedAt || 0;
    
    console.log('[CLOUD SYNC] Local timestamp:', localTimestamp, new Date(localTimestamp));
    console.log('[CLOUD SYNC] Cloud timestamp:', cloudTimestamp, new Date(cloudTimestamp));
    
    // Si la cuenta fue reiniciada de fábrica por el administrador en la nube
    if (cloudData.isReset === true || (cloudData.resetAt && cloudData.resetAt > (localInv.resetAt || 0))) {
      console.log('[CLOUD SYNC] La cuenta fue reiniciada de fábrica en la nube. Aplicando reseteo total local...');
      if (window.kvrcards && typeof window.kvrcards.resetUserAccount === 'function') {
        try { await window.kvrcards.resetUserAccount(); } catch (errR) { console.warn(errR); }
      }
      await applyCloudData(cloudData);
      
      const rawUser = currentUser || '';
      const safeUser = rawUser.toLowerCase();
      [
        'kvr_user_missions', 'kvr_user_kizunas', 'kvr_user_evolutions', 'kvr_user_evolutions_v2',
        'kvrcards_prestige_progress_v1', 'INFINITE_CURRENCY_COINS', 'INFINITE_CURRENCY_CARDPOINTS',
        'kvr_wallet_traits', 'kvr_user_profile', 'DELIVERABLES_COMPLETED_KEY',
        `kvr_user_missions_${safeUser}`, `kvr_user_kizunas_${safeUser}`, `kvr_user_evolutions_${safeUser}`,
        `infinite_saved_team_${safeUser}`, `kvrProfile_${safeUser}`, `kvrProfile_${rawUser}`
      ].forEach(k => { try { localStorage.removeItem(k); } catch {} });

      if (typeof userMissions !== 'undefined' && userMissions) {
        for (const k of Object.keys(userMissions)) delete userMissions[k];
      }
      if (typeof userKizunas !== 'undefined' && userKizunas) {
        for (const k of Object.keys(userKizunas)) delete userKizunas[k];
      }
      if (typeof userEvolutions !== 'undefined' && userEvolutions) {
        for (const k of Object.keys(userEvolutions)) delete userEvolutions[k];
      }

      await Promise.all([
        renderCollection(),
        renderOwnedPacks(),
        renderShop(),
        renderWallet(),
        typeof updateMissionsProgress === 'function' ? updateMissionsProgress() : Promise.resolve(),
        typeof renderMissions === 'function' ? renderMissions() : Promise.resolve(),
        typeof renderKizunas === 'function' ? renderKizunas() : Promise.resolve(),
        typeof renderEvolutions === 'function' ? renderEvolutions() : Promise.resolve()
      ]);

      alert('⚠️ Tu cuenta ha sido restablecida de fábrica por el administrador.');
      return;
    }

    // Si el timestamp de la nube es más reciente que el local, ofrecer descargar
    if (cloudTimestamp > localTimestamp && cloudTimestamp > 0) {
      const cloudCardsCount = Object.keys(cloudData.cards || {}).length;
      const cloudPacksCount = Object.keys(cloudData.packs || {}).length;
      const cloudCoins = cloudData.wallet?.coins || 0;
      const cloudKvr = cloudData.wallet?.kvr || 0;
      const cloudTraits = cloudData.wallet?.traits || 0;
      
      const localCardsCount = Object.keys(localInv.cards || {}).length;
      const localPacksCount = Object.keys(localInv.packs || {}).length;
      const localCoins = localInv.wallet?.coins || 0;
      const localKvr = localInv.wallet?.kvr || 0;
      const localTraits = localInv.wallet?.traits || 0;
      
      const timeDiff = Math.floor((cloudTimestamp - localTimestamp) / 1000 / 60); // minutos
      
      const confirmMsg = 
        'Se detectaron datos mas recientes en la nube\n\n' +
        `Ultima actualizacion: hace ${timeDiff} minutos\n\n` +
        'DATOS EN LA NUBE:\n' +
        `- Cartas: ${cloudCardsCount}\n` +
        `- Sobres: ${cloudPacksCount}\n` +
        `- Coins: ${cloudCoins}\n` +
        `- KvR: ${cloudKvr}\n` +
        `- Traits: ${cloudTraits}\n\n` +
        'DATOS LOCALES ACTUALES:\n' +
        `- Cartas: ${localCardsCount}\n` +
        `- Sobres: ${localPacksCount}\n` +
        `- Coins: ${localCoins}\n` +
        `- KvR: ${localKvr}\n` +
        `- Traits: ${localTraits}\n\n` +
        'Deseas cargar los datos de la nube?\n' +
        '(Se sobrescribiran tus datos locales actuales)';
      
      if (confirm(confirmMsg)) {
        await applyCloudData(cloudData);
        alert('Datos cargados desde la nube correctamente.');
        // Recargar vistas
        await Promise.all([renderCollection(), renderOwnedPacks(), renderShop(), renderWallet()]);
      }
    } else {
      console.log('[CLOUD SYNC] Los datos locales estan actualizados o son mas recientes');
    }
  } catch (e) {
    console.error('[CLOUD SYNC] Error en verificacion:', e);
  }
}

// Aplicar datos de la nube
async function applyCloudData(cloudData) {
  const applyPayload = {
    inventory: {
      cards: cloudData.cards || {},
      packs: cloudData.packs || {},
      powers: cloudData.powers || {},
      cardTraits: cloudData.cardTraits || {},
      cardUpgrades: cloudData.cardUpgrades || {},
      wallet: cloudData.wallet || { coins: 0, kvr: 0, traits: 0 },
      stats: cloudData.stats || {},
      weeklyStats: cloudData.weeklyStats || {},
      missions: cloudData.missions || {},
      completedDeliverables: Array.isArray(cloudData.completedDeliverables) ? cloudData.completedDeliverables : [],
      deliverableCompletions: cloudData.deliverableCompletions || {},
      packPurchases: cloudData.packPurchases || {},
      settings: cloudData.settings || {},
      profileImage: cloudData.profileImage || '',
      currentTitle: cloudData.currentTitle || 'novato',
      unlockedTitles: Array.isArray(cloudData.unlockedTitles) ? cloudData.unlockedTitles : ['novato'],
      currentBackground: cloudData.currentBackground || 'default',
      unlockedBackgrounds: Array.isArray(cloudData.unlockedBackgrounds) ? cloudData.unlockedBackgrounds : ['default'],
      showcaseCards: Array.isArray(cloudData.showcaseCards) ? cloudData.showcaseCards : [null, null, null],
      supporterBlessing: cloudData.supporterBlessing || null,
      redeemedCodes: Array.isArray(cloudData.redeemedCodes) ? cloudData.redeemedCodes : [],
      infiniteRun: cloudData.infiniteRun || null,
      infiniteRankings: cloudData.infiniteRankings || null,
      friends: cloudData.friends || [],
      friendRequests: cloudData.friendRequests || [],
      sentRequests: cloudData.sentRequests || []
    }
  };
  
  const applyResult = await window.kvrcards.cloudApplyData(applyPayload);
  
  if (!applyResult.ok) {
    throw new Error(applyResult.error || 'Error al aplicar datos');
  }
}

// Descargar desde la nube (R2)
async function downloadFromCloud() {
  if (!currentUser || !currentUserPassword) {
    alert('No hay sesion activa');
    return;
  }
  
  const confirmMsg = 'ATENCION: Esto reemplazara tus datos locales con los de la nube.\n\n' +
    'Deseas continuar?';
  
  if (!confirm(confirmMsg)) {
    return;
  }
  
  console.log('[R2 DOWNLOAD] Descargando datos desde R2...');
  
  try {
    const remoteData = await window.kvrcards.getRemoteInventory();
    
    if (!remoteData.ok) {
      alert('Error: ' + (remoteData.error || 'No se pudieron obtener los datos de la nube'));
      return;
    }
    
    const data = remoteData.data;
    
    if (!data || !data.cards) {
      alert('No hay datos guardados en la nube para este usuario');
      return;
    }
    
    console.log('[R2 DOWNLOAD] Datos encontrados en R2:', {
      cards: Object.keys(data.cards || {}).length,
      packs: Object.keys(data.packs || {}).length,
      wallet: data.wallet
    });
    
    const cardsCount = Object.keys(data.cards || {}).length;
    const packsCount = Object.keys(data.packs || {}).length;
    const coins = data.wallet?.coins || 0;
    const kvr = data.wallet?.kvr || 0;
    const traits = data.wallet?.traits || 0;
    
    const confirmApply = confirm(
      'Datos encontrados en la nube:\n\n' +
      `- Cartas: ${cardsCount}\n` +
      `- Sobres: ${packsCount}\n` +
      `- Coins: ${coins}\n` +
      `- KvR: ${kvr}\n` +
      `- Traits: ${traits}\n\n` +
      'Aplicar estos datos?'
    );
    
    if (!confirmApply) {
      return;
    }
    
    await applyCloudData(data);
    
    alert('Datos de la nube aplicados correctamente. Reiniciando aplicacion...');
    window.location.reload();
  } catch (e) {
    console.error('[R2 DOWNLOAD] Error:', e);
    alert('Error al descargar desde la nube: ' + e.message);
  }
}

