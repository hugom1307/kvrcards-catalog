// ==================== MISSIONS ====================

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function getActiveMissionsUsername() {
  if (typeof currentUser === 'string' && currentUser.trim()) return currentUser.trim();
  if (typeof window !== 'undefined' && typeof window.currentUser === 'string' && window.currentUser.trim()) {
    return window.currentUser.trim();
  }
  try {
    const p = localStorage.getItem('kvr_user_profile');
    if (p) {
      const parsed = JSON.parse(p);
      if (parsed && parsed.username) return parsed.username.trim();
    }
  } catch {}
  try {
    const saved = localStorage.getItem('kvrUsername') || localStorage.getItem('userId');
    if (saved && saved.trim()) return saved.trim();
  } catch {}
  return '';
}

function isMissionVisibleForUser(mission, username = null) {
  if (!mission || !mission.visibleOnly) return true;
  const user = String(username || getActiveMissionsUsername() || '').trim().toLowerCase();
  if (!user) return false;
  if (Array.isArray(mission.visibleOnly)) {
    return mission.visibleOnly.some(u => String(u).trim().toLowerCase() === user);
  }
  if (typeof mission.visibleOnly === 'string') {
    return mission.visibleOnly.split(',').map(s => s.trim().toLowerCase()).includes(user);
  }
  return true;
}

// Carga instantánea inicial desde caché local al cargar el script
try {
  const cachedM = localStorage.getItem('kvrcards_missions_cache');
  if (cachedM) {
    const parsedM = JSON.parse(cachedM);
    if (Array.isArray(parsedM) && parsedM.length > 0) availableMissions = parsedM;
  }
} catch {}

try {
  const cachedK = localStorage.getItem('kvr_kizunas_cache');
  if (cachedK) {
    const parsedK = JSON.parse(cachedK);
    if (Array.isArray(parsedK) && parsedK.length > 0) availableKizunas = parsedK;
  }
} catch {}

const missionCatalogCache = {
  packs: null,
  titles: null,
  cards: null
};

function formatTitleFallback(titleId) {
  if (!titleId) return 'Título';
  return String(titleId)
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (l) => l.toUpperCase())
    .trim();
}

function formatPackDisplayName(packId, amount = 1, packObj = null) {
  let rawName = packObj?.name || String(packId || '').replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase());
  const baseName = rawName.replace(/^(?:sobre|pack)\s+/i, '').trim();
  const safeAmount = Number(amount) || 1;

  if (safeAmount > 1) {
    return `${safeAmount} Sobres ${baseName}`;
  } else {
    return `Sobre ${baseName}`;
  }
}

async function ensureMissionCatalogCache() {
  const promises = [];

  if (!Array.isArray(missionCatalogCache.packs)) {
    promises.push(
      (async () => {
        try {
          missionCatalogCache.packs = (typeof window.kvrcards?.getAllPacks === 'function')
            ? await window.kvrcards.getAllPacks()
            : [];
        } catch {
          missionCatalogCache.packs = [];
        }
      })()
    );
  }

  if (!Array.isArray(missionCatalogCache.titles)) {
    if (Array.isArray(window.availableTitles) && window.availableTitles.length > 0) {
      missionCatalogCache.titles = window.availableTitles;
    } else {
      promises.push(
        (async () => {
          try {
            if (typeof window.kvrcards?.getTitles === 'function') {
              const res = await window.kvrcards.getTitles();
              if (res && res.ok && Array.isArray(res.titles)) {
                missionCatalogCache.titles = res.titles;
              }
            }
          } catch {
            missionCatalogCache.titles = window.availableTitles || [];
          }
        })()
      );
    }
  }

  if (!Array.isArray(missionCatalogCache.cards)) {
    promises.push(
      (async () => {
        try {
          missionCatalogCache.cards = (typeof window.kvrcards?.getAllCards === 'function')
            ? await window.kvrcards.getAllCards()
            : [];
        } catch {
          missionCatalogCache.cards = [];
        }
      })()
    );
  }

  if (promises.length > 0) {
    await Promise.all(promises);
  }
}

function normalizeRewardType(reward) {
  let type = String(reward?.type || reward?.tipo || '').toLowerCase().trim();
  if (type === 'coins' || type === 'coin' || type === 'monedas' || type === 'moneda' || type === 'oro' || type === 'gold') type = 'coins';
  else if (type === 'kvr' || type === 'kvr_coins' || type === 'kvrcoins' || type === 'kvrcoin') type = 'kvr';
  else if (type === 'pack' || type === 'packs' || type === 'sobre' || type === 'sobres') type = 'pack';
  else if (type === 'card' || type === 'cards' || type === 'carta' || type === 'cartas') type = 'card';
  else if (type === 'title' || type === 'titles' || type === 'titulo' || type === 'título' || type === 'titulos' || type === 'títulos') type = 'title';
  else if (type === 'traits' || type === 'trait' || type === 'rasgo' || type === 'rasgos') type = 'traits';
  else if (type === 'background' || type === 'backgrounds' || type === 'fondo' || type === 'fondos' || /ba[ck]+gr?o?u?n?d?/.test(type)) type = 'background';

  if (!type || type === 'generic') {
    if (reward?.backgroundId || reward?.fondoId) type = 'background';
    else if (reward?.packId || reward?.sobreId || reward?.pack) type = 'pack';
    else if (reward?.cardId || reward?.cartaId || reward?.card) type = 'card';
    else if (reward?.titleId || reward?.tituloId || reward?.title) type = 'title';
    else if (reward?.coins || reward?.monedas) type = 'coins';
    else if (reward?.kvr) type = 'kvr';
    else if (reward?.traits || reward?.rasgos) type = 'traits';
  }
  return type;
}

function getRewardDisplayInfo(reward) {
  const type = normalizeRewardType(reward);
  const amount = Number(reward?.amount || reward?.cantidad || reward?.quantity || reward?.count || 1) || 1;
  const allPacks = Array.isArray(missionCatalogCache.packs) ? missionCatalogCache.packs : [];
  const allTitles = (Array.isArray(missionCatalogCache.titles) && missionCatalogCache.titles.length > 0)
    ? missionCatalogCache.titles
    : ((Array.isArray(window.availableTitles) && window.availableTitles.length > 0)
      ? window.availableTitles
      : ((typeof rewardHudCatalogCache !== 'undefined' && Array.isArray(rewardHudCatalogCache.titles) && rewardHudCatalogCache.titles.length > 0)
        ? rewardHudCatalogCache.titles
        : []));
  const allCards = (Array.isArray(missionCatalogCache.cards) && missionCatalogCache.cards.length > 0)
    ? missionCatalogCache.cards
    : ((typeof rewardHudCatalogCache !== 'undefined' && Array.isArray(rewardHudCatalogCache.cards) && rewardHudCatalogCache.cards.length > 0)
      ? rewardHudCatalogCache.cards
      : (Array.isArray(window.allCardsCache) ? window.allCardsCache : []));

  if (type === 'coins') {
    return {
      text: `<img class="reward-icon-inline" src="./coin.png" alt="Coins" /> ${amount.toLocaleString('es-ES')} monedas`,
      className: 'coins reward-coins',
      name: `${amount.toLocaleString('es-ES')} Monedas`,
      imageUrl: './coin.png',
      amount
    };
  }

  if (type === 'kvr') {
    return {
      text: `<img class="reward-icon-inline" src="./kvr.png" alt="KvR" /> ${amount.toLocaleString('es-ES')} KvR`,
      className: 'kvr reward-kvr',
      name: `${amount.toLocaleString('es-ES')} KvR`,
      imageUrl: './kvr.png',
      amount
    };
  }

  if (type === 'pack') {
    const rawPackId = String(reward.packId || '');
    const packObj = allPacks.find((p) => p.id === rawPackId || String(p.id).toLowerCase() === rawPackId.toLowerCase());
    const displayName = formatPackDisplayName(rawPackId, amount, packObj);
    
    let packImg = packObj?.imageUrl || packObj?.image || packObj?.iconUrl || '';
    if (!packImg) {
      const lower = rawPackId.toLowerCase();
      if (lower.includes('bronce') || lower.includes('bronze')) {
        packImg = './icon-bronce.png';
      } else if (lower.includes('plata') || lower.includes('silver')) {
        packImg = './icon-plata.png';
      } else if (lower.includes('oro') || lower.includes('gold')) {
        packImg = './icon-oro.png';
      } else if (lower.includes('heroe') || lower.includes('hero')) {
        packImg = './icon-heroe.png';
      } else if (lower.includes('icono') || lower.includes('icon')) {
        packImg = './icon-icono.png';
      } else {
        packImg = './icon-especiales.png';
      }
    }

    return {
      text: `<img class="reward-icon-inline" src="${packImg}" alt="Pack" /> ${displayName}`,
      className: 'pack reward-pack',
      name: displayName,
      imageUrl: packImg,
      amount
    };
  }

  if (type === 'title') {
    const rawTitleId = String(reward.titleId || reward.id || reward.title || '').trim();
    const titleObj = (typeof window.findTitleInCatalog === 'function')
      ? window.findTitleInCatalog(reward, allTitles)
      : allTitles.find((t) => t.id === rawTitleId || String(t.id).toLowerCase() === rawTitleId.toLowerCase() || t.name === rawTitleId);
    const targetTitleId = titleObj?.id || rawTitleId;
    const rawTitleName = titleObj?.name || titleObj?.titulo || reward.name || formatTitleFallback(rawTitleId);
    const cleanTitle = typeof window.stripTitleFormatting === 'function'
      ? window.stripTitleFormatting(rawTitleName)
      : (typeof stripTitleFormatting === 'function' ? stripTitleFormatting(rawTitleName) : String(rawTitleName).replace(/^(?:🏆|\s)*(?:título|titulo)\s*:\s*/i, ''));
    const titleDesc = titleObj?.description || titleObj?.desc || 'Título desbloqueable';
    const gradient = titleObj?.gradient || reward?.gradient || '';

    let textHtml = `<span class="title-emoji">🏆</span> Título: ${escapeHtml(cleanTitle)}`;
    if (gradient) {
      const formatted = typeof window.formatTitleWithGradient === 'function'
        ? window.formatTitleWithGradient(cleanTitle, gradient)
        : `<span class="title-gradient-text" style="background-image:${gradient};">${escapeHtml(cleanTitle)}</span>`;
      textHtml = `<span class="title-emoji">🏆</span> Título: ${formatted}`;
    }

    return {
      text: textHtml,
      className: 'title reward-title',
      name: cleanTitle,
      cleanTitle: cleanTitle,
      cleanName: cleanTitle,
      description: titleDesc,
      gradient: gradient,
      titleId: targetTitleId,
      rawTitleId: rawTitleId,
      imageUrl: '',
      amount: 1
    };
  }

  if (type === 'card') {
    const rawCardId = String(reward.cardId || reward.id || reward.card || reward.card_id || '').trim();
    const cardObj = (typeof window.findCardInCatalog === 'function')
      ? window.findCardInCatalog(reward, allCards)
      : (rawCardId ? allCards.find((c) => c && (c.id === rawCardId || String(c.id).toLowerCase() === rawCardId.toLowerCase())) : null);
    const targetCardId = cardObj?.id || rawCardId;
    const cardName = cardObj?.name || cardObj?.nombre || reward.name || rawCardId;
    const cleanCardName = String(cardName).replace(/^(?:🃏|\s)*(?:carta)\s*:\s*/i, '').trim();
    const cardImg = (reward?.imageUrl && !reward.imageUrl.includes('default-card') && !reward.imageUrl.includes('icon-especiales'))
      ? reward.imageUrl
      : (cardObj?.imageUrl || cardObj?.image || cardObj?.imagen || reward?.imageUrl || reward?.image || '');
    const displayName = amount > 1 ? `${amount}x Carta: ${cleanCardName}` : `Carta: ${cleanCardName}`;

    return {
      text: `🃏 ${displayName}`,
      className: 'card reward-card',
      name: displayName,
      cleanName: cleanCardName,
      imageUrl: cardImg,
      cardId: targetCardId,
      rawCardId: rawCardId,
      card: cardObj,
      amount
    };
  }

  if (type === 'background' || type === 'fondo') {
    const rawBgId = String(reward.backgroundId || reward.fondoId || reward.id || '').trim();
    const allBg = Array.isArray(window.availableBackgrounds) ? window.availableBackgrounds : [];
    const altBgId = rawBgId.startsWith('fondo_') ? rawBgId.replace(/^fondo_/, '') : `fondo_${rawBgId}`;
    const bgObj = allBg.find(b => b && (b.id === rawBgId || String(b.id).toLowerCase() === rawBgId.toLowerCase() || b.id === altBgId || String(b.id).toLowerCase() === altBgId.toLowerCase()));
    const rawFallbackName = rawBgId.replace(/^fondo_/, '').replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    const bgName = bgObj?.nombre || bgObj?.name || reward.name || rawFallbackName;
    const bgImg = bgObj?.imagen || bgObj?.image || bgObj?.imageUrl || './assets/backgrounds/bg_default.svg';

    return {
      text: `<img class="reward-icon-inline reward-bg-thumb" src="${bgImg}" alt="${bgName}" /> Fondo: ${bgName}`,
      className: 'background reward-background',
      name: `Fondo: ${bgName}`,
      imageUrl: bgImg,
      amount: 1
    };
  }

  if (type === 'buff') {
    const statsObj = reward.stats || reward.efecto || {};
    const allTeam = Boolean(reward.allTeam);
    const statParts = [];
    for (const [sKey, sVal] of Object.entries(statsObj)) {
      const sName = (typeof STAT_NAMES_MAP !== 'undefined' && STAT_NAMES_MAP[sKey]) || (sKey.toLowerCase() === 'all' ? 'Todas las stats' : (sKey.charAt(0).toUpperCase() + sKey.slice(1)));
      statParts.push(`+${sVal}% ${sName}`);
    }
    const statsText = statParts.length > 0 ? statParts.join(', ') : 'Buff exclusivo';
    const targetText = allTeam ? 'Todo el equipo' : 'Miembros del Kizuna';
    
    const buffName = reward.name || 'Buff Kizuna';
    const buffDesc = reward.description || (statsText ? `${statsText} (${targetText})` : targetText);
    const displayText = `⚡ Buff: ${buffName}`;

    return {
      text: displayText,
      className: 'buff reward-buff',
      name: buffName,
      cleanName: buffName,
      description: buffDesc,
      stats: statsObj,
      allTeam: allTeam,
      type: 'buff',
      emoji: '⚡',
      imageUrl: '',
      amount
    };
  }

  if (type === 'traits' || type === 'trait') {
    const label = amount === 1 ? '1 Trait' : `${amount.toLocaleString('es-ES')} Traits`;
    return {
      text: `<img class="reward-icon-inline" src="./trait.png" alt="Traits" onerror="this.src='./trait.png'" /> ${label}`,
      className: 'traits reward-traits',
      name: label,
      imageUrl: './trait.png',
      amount
    };
  }

  return {
    text: String(reward?.name || reward?.id || 'Recompensa'),
    className: 'reward-generic',
    name: String(reward?.name || reward?.id || 'Recompensa'),
    imageUrl: './icon-especiales.png',
    amount
  };
}

// Cargar misiones desde remoto (GitHub)
// Cargar misiones desde GitHub o caché local instantáneo
async function loadMissions() {
  console.log('[MISSIONS] Cargando misiones...');
  
  // 1. Cargar caché inmediatamente para que no haya delay en la UI
  const cachedMissions = localStorage.getItem(MISSIONS_CACHE_KEY);
  if (cachedMissions) {
    try {
      const parsed = JSON.parse(cachedMissions);
      if (Array.isArray(parsed) && parsed.length > 0) {
        availableMissions = parsed;
        console.log('[MISSIONS] ✅ Misiones cargadas desde caché local:', availableMissions.length);
      }
    } catch (e) {
      console.warn('[MISSIONS] Error leyendo caché:', e);
    }
  }
  
  // 2. Fetch remoto con timeout de 3 segundos para que nunca se quede colgado
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);
    const response = await fetch(MISSIONS_REMOTE_URL + '?t=' + Date.now(), { signal: controller.signal });
    clearTimeout(timeoutId);
    
    if (response.ok) {
      const data = await response.json();
      if (Array.isArray(data) && data.length > 0) {
        availableMissions = data;
        localStorage.setItem(MISSIONS_CACHE_KEY, JSON.stringify(data));
        console.log('[MISSIONS] ✅ Misiones actualizadas desde GitHub:', availableMissions.length);
        return;
      }
    }
  } catch (error) {
    console.warn('[MISSIONS] ⚠️ No se pudo conectar con GitHub, usando datos locales/caché:', error?.message || error);
  }
  
  // 3. Fallback a seeds locales si no hay caché ni remoto
  if (availableMissions.length === 0) {
    try {
      if (window.kvrcards && typeof window.kvrcards.getMissions === 'function') {
        const local = await window.kvrcards.getMissions();
        if (local && Array.isArray(local.missions)) {
          availableMissions = local.missions;
        }
      }
    } catch {}
  }
}

// Cargar estado de misiones del usuario desde servidor remoto
async function loadUserMissionsState() {
  if (!currentUser) return;
  
  try {
    const result = await window.kvrcards.getMissionsState();
    if (result && result.ok && result.missions && typeof result.missions === 'object') {
      userMissions = { ...result.missions };
      console.log('[MISSIONS] Estado de misiones cargado desde remoto para:', currentUser);
    } else {
      userMissions = {};
    }
  } catch (error) {
    console.error('[MISSIONS] Error al cargar estado de misiones:', error);
    userMissions = {};
  }
}

// Guardar estado de misiones del usuario en servidor remoto
async function saveUserMissionsState() {
  if (!currentUser) return;
  
  try {
    const result = await window.kvrcards.saveMissionsState(userMissions);
    if (result.ok) {
      console.log('[MISSIONS] Estado de misiones guardado en remoto para:', currentUser);
    } else {
      console.error('[MISSIONS] Error al guardar misiones:', result.error);
    }
  } catch (error) {
    console.error('[MISSIONS] Error al guardar estado de misiones:', error);
  }
}

// --- SISTEMA DE CICLOS DIARIOS Y SEMANALES (06:00 AM) ---
function getDailyCycleKey(date = new Date()) {
  const d = new Date(date);
  if (d.getHours() < 6) {
    d.setDate(d.getDate() - 1);
  }
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `D-${y}-${m}-${day}`;
}

function getWeeklyCycleKey(date = new Date()) {
  const d = new Date(date);
  d.setHours(d.getHours() - 6);
  const day = d.getDay();
  const diffToMonday = (day === 0 ? -6 : 1) - day;
  const monday = new Date(d);
  monday.setDate(d.getDate() + diffToMonday);
  const y = monday.getFullYear();
  const m = String(monday.getMonth() + 1).padStart(2, '0');
  const dayStr = String(monday.getDate()).padStart(2, '0');
  return `W-${y}-${m}-${dayStr}`;
}

function getCycleKeyForMission(mission, date = new Date()) {
  if (!mission) return null;
  if (mission.category === 'daily') return getDailyCycleKey(date);
  if (mission.category === 'weekly') return getWeeklyCycleKey(date);
  return null;
}

function isMissionClaimedInCurrentCycle(mission, userMission) {
  if (!userMission || !userMission.claimedAt) return false;
  if (mission.category === 'daily') {
    const currentDaily = getDailyCycleKey();
    if (userMission.claimedCycle) return userMission.claimedCycle === currentDaily;
    return getDailyCycleKey(userMission.claimedAt) === currentDaily;
  }
  if (mission.category === 'weekly') {
    const currentWeekly = getWeeklyCycleKey();
    if (userMission.claimedCycle) return userMission.claimedCycle === currentWeekly;
    return getWeeklyCycleKey(userMission.claimedAt) === currentWeekly;
  }
  return false;
}

// Normalizar requerimientos de una misión (soporta objeto único, array o mission.requirements)
function getMissionRequirements(mission) {
  if (!mission) return [];
  
  if (Array.isArray(mission.requirements) && mission.requirements.length > 0) {
    return mission.requirements;
  }
  if (Array.isArray(mission.requirement) && mission.requirement.length > 0) {
    return mission.requirement;
  }
  if (mission.requirement && typeof mission.requirement === 'object') {
    return [mission.requirement];
  }
  if (mission.type) {
    return [{
      type: mission.type,
      amount: mission.target || mission.amount || 1,
      quality: mission.quality,
      cardId: mission.cardId,
      packId: mission.packId,
      titleId: mission.titleId,
      description: mission.targetDescription || mission.reqDescription
    }];
  }
  return [];
}

// Obtener descripción legible para un requerimiento individual
function getRequirementDescription(req) {
  if (req.text) return req.text;
  if (req.description) return req.description;
  if (req.desc) return req.desc;
  if (req.title) return req.title;
  if (req.name) return req.name;

  const type = String(req.type || '').toLowerCase();
  const amount = Number(req.amount || req.target || 1);

  switch (type) {
    case 'open_packs':
    case 'packs_opened':
      return amount === 1 ? 'Abrir 1 sobre' : `Abrir ${amount} sobres`;
    case 'win_games':
    case 'battles_won':
      return amount === 1 ? 'Ganar 1 combate' : `Ganar ${amount} combates`;
    case 'play_games':
    case 'play_battles':
    case 'games_played':
    case 'battles_played':
      return amount === 1 ? 'Jugar 1 combate' : `Jugar ${amount} combates`;
    case 'complete_daily_missions':
      return amount === 1 ? 'Completar 1 misión diaria' : `Completar ${amount} misiones diarias`;
    case 'complete_all_daily_missions':
    case 'all_daily_missions':
      return 'Completar todas las misiones diarias';
    case 'complete_weekly_missions':
      return amount === 1 ? 'Completar 1 misión semanal' : `Completar ${amount} misiones semanales`;
    case 'complete_all_weekly_missions':
    case 'all_weekly_missions':
      return 'Completar todas las misiones semanales';
    case 'unique_cards':
      return `Conseguir ${amount} cartas únicas`;
    case 'coins':
      return `Acumular ${amount.toLocaleString('es-ES')} Coins`;
    case 'cards_by_quality':
      return `Conseguir ${amount} cartas de calidad ${req.quality || 'específica'}`;
    case 'own_card':
      return `Poseer la carta ${req.cardId || ''}`;
    case 'own_pack':
      return `Poseer ${amount} sobres ${req.packId || ''}`;
    case 'own_title':
      return `Desbloquear título ${req.titleId || ''}`;
    case 'login':
      return 'Iniciar sesión';
    case 'rounds_won':
    case 'card_rounds_won':
      return req.cardRequired ? (amount === 1 ? 'Ganar 1 ronda con esta carta' : `Ganar ${amount} rondas con esta carta`) : (amount === 1 ? 'Ganar 1 ronda' : `Ganar ${amount} rondas`);
    case 'unique_cards_by_quality':
      return amount === 1 ? `Conseguir 1 carta diferente de calidad ${req.quality || 'específica'}` : `Conseguir ${amount} cartas diferentes de calidad ${req.quality || 'específica'}`;
    case 'cards_obtained':
    case 'obtain_cards':
      return amount === 1 ? 'Conseguir 1 carta' : `Conseguir ${amount} cartas`;
    case 'play_infinite_levels':
    case 'infinite_levels':
      return amount === 1 ? 'Jugar 1 nivel en modo infinito' : `Jugar ${amount} niveles en modo infinito`;
    case 'complete_trade':
    case 'trade':
      return amount === 1 ? 'Completar 1 intercambio' : `Completar ${amount} intercambios`;
    case 'play_games_with_card':
    case 'games_played_with_card':
      return amount === 1 ? 'Jugar 1 partida con esta carta' : `Jugar ${amount} partidas con esta carta`;
    case 'win_games_with_card':
      return amount === 1 ? 'Ganar 1 combate con esta carta' : `Ganar ${amount} combates con esta carta`;
    case 'obtain_card':
    case 'duplicate_card':
      return amount === 1 ? 'Obtener 1 copia de esta carta' : `Obtener ${amount} copias de esta carta`;
    case 'complete_specific_mission':
      return `Completar misión: ${req.targetMissionId || req.missionId || ''}`;
    case 'rounds_won_with_filter':
      return `Ganar ${amount} rondas con cartas ${req.origin ? `de ${req.origin}` : ''} ${req.owner ? `de ${req.owner}` : ''}`.trim();
    case 'win_games_with_filter':
      return `Ganar ${amount} combates con cartas ${req.origin ? `de ${req.origin}` : ''} ${req.owner ? `de ${req.owner}` : ''}`.trim();
    case 'win_event_battle':
    case 'event_battle_won':
      return amount === 1 
        ? `Vencer 1 vez a ${req.opponent ? req.opponent.toUpperCase() : 'jefe'} en evento` 
        : `Vencer ${amount} veces a ${req.opponent ? req.opponent.toUpperCase() : 'jefe'} en evento`;
    case 'win_special_event_level':
    case 'complete_special_event_level':
    case 'special_event_level': {
      let detail = '';
      if (req.levelNumber) detail += ` Nivel ${req.levelNumber}`;
      if (req.worldId) detail += ` (${req.worldId})`;
      if (req.levelId && !req.levelNumber) detail += ` (${req.levelId})`;
      return amount === 1 
        ? `Superar 1 nivel de evento especial${detail}`
        : `Superar ${amount} niveles de evento especial${detail}`;
    }
    default:
      return req.type ? `${req.type}: ${amount}` : `Objetivo: ${amount}`;
  }
}

// Determinar si una misión debe rastrearse de forma relativa (empezando desde 0 al activarse o ser añadida)
function isRelativeMission(mission, req = null) {
  if (!mission) return false;
  const isTrue = (val) => val === true || val === 'true' || val === 1 || val === '1';
  return !!(
    mission.repeatable || 
    mission.category === 'daily' || 
    mission.category === 'weekly' ||
    isTrue(mission.startFromZero) ||
    isTrue(mission.start_from_zero) ||
    isTrue(mission.trackFromNow) ||
    isTrue(mission.track_from_now) ||
    isTrue(mission.relative) ||
    isTrue(req?.startFromZero) ||
    isTrue(req?.start_from_zero) ||
    isTrue(req?.trackFromNow) ||
    isTrue(req?.track_from_now) ||
    isTrue(req?.relative)
  );
}

// Calcular progreso de un requerimiento individual
async function checkSingleRequirementProgress(mission, req, context = null, userMission = {}) {
  const reqType = req.type;
  const reqAmount = Number(req.amount || req.target || 1);
  const isCyclicOrRepeatable = isRelativeMission(mission, req);

  const getStats = async () => context?.stats || await window.kvrcards.getUserStats();
  const getInv = async () => context?.inv || await window.kvrcards.getInventory();
  const getAllCards = async () => context?.allCards || missionCatalogCache.cards || await window.kvrcards.getAllCards();
  const getProfile = async () => context?.profile || await window.kvrcards.getUserProfile();

  let progress = 0;

  try {
    switch (reqType) {
      case 'open_packs':
      case 'packs_opened': {
        const result = await getStats();
        if (!result.ok) return 0;
        const currentValue = result.stats?.totalPacksOpened || 0;
        if (isCyclicOrRepeatable && userMission && typeof userMission === 'object') {
          if (!userMission.initialProgress) userMission.initialProgress = {};
          const isExplicitZero = mission.startFromZero || mission.start_from_zero || req?.startFromZero || req?.start_from_zero;
          const needsAnchor = !userMission.anchor_packs_opened ||
                              userMission.initialProgress.packs_opened === undefined ||
                              (isExplicitZero && !userMission.claimedAt && userMission.initialProgress.packs_opened === 0 && currentValue > 0);
          if (needsAnchor) {
            userMission.initialProgress.packs_opened = currentValue;
            userMission.anchor_packs_opened = true;
            if (userMissions && mission.id) {
              if (!userMissions[mission.id]) userMissions[mission.id] = userMission;
              userMissions[mission.id].initialProgress = userMission.initialProgress;
              userMissions[mission.id].anchor_packs_opened = true;
              if (!userMission.claimedAt && isExplicitZero) {
                userMissions[mission.id].completed = false;
                userMissions[mission.id].progressValue = 0;
              }
            }
          }
        }
        const initialValue = isCyclicOrRepeatable ? (Number(userMission?.initialProgress?.packs_opened) || 0) : 0;
        progress = Math.max(0, currentValue - initialValue);
        break;
      }

      case 'win_games':
      case 'battles_won': {
        const result = await getStats();
        if (!result.ok) return 0;
        const currentValue = result.stats?.battlesWon || 0;
        if (isCyclicOrRepeatable && userMission && typeof userMission === 'object') {
          if (!userMission.initialProgress) userMission.initialProgress = {};
          const isExplicitZero = mission.startFromZero || mission.start_from_zero || req?.startFromZero || req?.start_from_zero;
          const needsAnchor = !userMission.anchor_battles_won ||
                              userMission.initialProgress.battles_won === undefined ||
                              (isExplicitZero && !userMission.claimedAt && userMission.initialProgress.battles_won === 0 && currentValue > 0);
          if (needsAnchor) {
            userMission.initialProgress.battles_won = currentValue;
            userMission.anchor_battles_won = true;
            if (userMissions && mission.id) {
              if (!userMissions[mission.id]) userMissions[mission.id] = userMission;
              userMissions[mission.id].initialProgress = userMission.initialProgress;
              userMissions[mission.id].anchor_battles_won = true;
              if (!userMission.claimedAt && isExplicitZero) {
                userMissions[mission.id].completed = false;
                userMissions[mission.id].progressValue = 0;
              }
            }
          }
        }
        const initialValue = isCyclicOrRepeatable ? (Number(userMission?.initialProgress?.battles_won) || 0) : 0;
        progress = Math.max(0, currentValue - initialValue);
        break;
      }

      case 'complete_all_daily_missions':
      case 'all_daily_missions': {
        const pool = (Array.isArray(availableMissions) && availableMissions.length > 0)
          ? availableMissions
          : (Array.isArray(window.availableMissions) ? window.availableMissions : []);
        const otherDaily = pool.filter((m) => m.category === 'daily' && m.id !== mission.id);
        const targetCount = otherDaily.length || Number(req.amount || 1);
        const currentDailyKey = typeof getDailyCycleKey === 'function' ? getDailyCycleKey() : null;
        let done = 0;
        otherDaily.forEach((m) => {
          const uM = userMissions[m.id];
          if (!uM) return;
          const claimedInCycle = (typeof isMissionClaimedInCurrentCycle === 'function')
            ? isMissionClaimedInCurrentCycle(m, uM)
            : false;
          const completedInCycle = !!uM.completed && (uM.currentCycle === currentDailyKey) && !uM.needsReset;
          if (claimedInCycle || completedInCycle) done++;
        });
        progress = done;
        req.amount = targetCount;
        break;
      }

      case 'complete_daily_missions': {
        if (mission.evolutionId && typeof userEvolutions !== 'undefined') {
          const evoProgress = userEvolutions[mission.evolutionId];
          progress = evoProgress?.dailyMissionsCount || 0;
        } else {
          const pool = (Array.isArray(availableMissions) && availableMissions.length > 0)
            ? availableMissions
            : (Array.isArray(window.availableMissions) ? window.availableMissions : []);
          const otherDaily = pool.filter((m) => m.category === 'daily' && m.id !== mission.id);
          const currentDailyKey = typeof getDailyCycleKey === 'function' ? getDailyCycleKey() : null;
          let done = 0;
          otherDaily.forEach((m) => {
            const uM = userMissions[m.id];
            if (!uM) return;
            const claimedInCycle = (typeof isMissionClaimedInCurrentCycle === 'function')
              ? isMissionClaimedInCurrentCycle(m, uM)
              : false;
            const completedInCycle = !!uM.completed && (uM.currentCycle === currentDailyKey) && !uM.needsReset;
            if (claimedInCycle || completedInCycle) done++;
          });
          const tracked = (userMission?.currentCycle === currentDailyKey)
            ? (userMission?.progress?.dailyMissionsCompleted || (typeof userMission?.progress === 'number' ? userMission.progress : 0))
            : 0;
          progress = Math.max(done, tracked);
        }
        break;
      }

      case 'complete_all_weekly_missions':
      case 'all_weekly_missions': {
        const pool = (Array.isArray(availableMissions) && availableMissions.length > 0)
          ? availableMissions
          : (Array.isArray(window.availableMissions) ? window.availableMissions : []);
        const otherWeekly = pool.filter((m) => m.category === 'weekly' && m.id !== mission.id);
        const targetCount = otherWeekly.length || Number(req.amount || 1);
        const currentWeeklyKey = typeof getWeeklyCycleKey === 'function' ? getWeeklyCycleKey() : null;
        let done = 0;
        otherWeekly.forEach((m) => {
          const uM = userMissions[m.id];
          if (!uM) return;
          const claimedInCycle = (typeof isMissionClaimedInCurrentCycle === 'function')
            ? isMissionClaimedInCurrentCycle(m, uM)
            : false;
          const completedInCycle = !!uM.completed && (uM.currentCycle === currentWeeklyKey) && !uM.needsReset;
          if (claimedInCycle || completedInCycle) done++;
        });
        progress = done;
        req.amount = targetCount;
        break;
      }

      case 'complete_weekly_missions': {
        const pool = (Array.isArray(availableMissions) && availableMissions.length > 0)
          ? availableMissions
          : (Array.isArray(window.availableMissions) ? window.availableMissions : []);
        const otherWeekly = pool.filter((m) => m.category === 'weekly' && m.id !== mission.id);
        const currentWeeklyKey = typeof getWeeklyCycleKey === 'function' ? getWeeklyCycleKey() : null;
        let done = 0;
        otherWeekly.forEach((m) => {
          const uM = userMissions[m.id];
          if (!uM) return;
          const claimedInCycle = (typeof isMissionClaimedInCurrentCycle === 'function')
            ? isMissionClaimedInCurrentCycle(m, uM)
            : false;
          const completedInCycle = !!uM.completed && (uM.currentCycle === currentWeeklyKey) && !uM.needsReset;
          if (claimedInCycle || completedInCycle) done++;
        });
        const tracked = (userMission?.currentCycle === currentWeeklyKey)
          ? (userMission?.progress?.weeklyMissionsCompleted || (typeof userMission?.progress === 'number' ? userMission.progress : 0))
          : 0;
        progress = Math.max(done, tracked);
        break;
      }

      case 'unique_cards': {
        const inv = await getInv();
        if (!inv.ok || !inv.cards) return 0;
        const uniqueCards = Object.keys(inv.cards).filter(cardId => inv.cards[cardId] > 0);
        const currentValue = uniqueCards.length;
        if (isCyclicOrRepeatable && userMission && typeof userMission === 'object') {
          if (!userMission.initialProgress) userMission.initialProgress = {};
          if (userMission.initialProgress.unique_cards === undefined) {
            userMission.initialProgress.unique_cards = currentValue;
          }
        }
        const initialValue = isCyclicOrRepeatable ? (userMission?.initialProgress?.unique_cards ?? currentValue) : 0;
        progress = Math.max(0, currentValue - initialValue);
        break;
      }

      case 'coins': {
        const inv = await getInv();
        if (!inv.ok || !inv.wallet) return 0;
        const currentValue = inv.wallet.coins || 0;
        if (isCyclicOrRepeatable && userMission && typeof userMission === 'object') {
          if (!userMission.initialProgress) userMission.initialProgress = {};
          if (userMission.initialProgress.coins === undefined) {
            userMission.initialProgress.coins = currentValue;
          }
        }
        const initialValue = isCyclicOrRepeatable ? (userMission?.initialProgress?.coins ?? currentValue) : 0;
        progress = Math.max(0, currentValue - initialValue);
        break;
      }

      case 'cards_by_quality': {
        const quality = req.quality || '';
        const inv = await getInv();
        if (!inv.ok || !inv.cards) return 0;

        const allCards = await getAllCards();
        let count = 0;
        const targetQualityLower = quality.toLowerCase();

        for (const cardId in inv.cards) {
          if (inv.cards[cardId] > 0) {
            const cardData = Array.isArray(allCards) ? allCards.find(c => c.id === cardId) : null;
            if (cardData) {
              const cardQuality = (cardData.quality || cardData.calidad || cardData.rarity || '').toLowerCase();
              let isMatch = cardQuality === targetQualityLower;
              if (targetQualityLower === 'especial' || targetQualityLower === 'especiales') {
                isMatch = ['especial', 'especiales', 'icono', 'heroe', 'héroe', 'icono prime', 'icono super prime', 'evo'].includes(cardQuality);
              }
              if (isMatch) {
                count += inv.cards[cardId];
              }
            }
          }
        }

        const qualityKey = `cards_${quality.toLowerCase()}`;
        if (isCyclicOrRepeatable && userMission && typeof userMission === 'object') {
          if (!userMission.initialProgress) userMission.initialProgress = {};
          if (userMission.initialProgress[qualityKey] === undefined) {
            userMission.initialProgress[qualityKey] = count;
          }
        }
        const initialValue = isCyclicOrRepeatable ? (userMission?.initialProgress?.[qualityKey] ?? count) : 0;
        progress = Math.max(0, count - initialValue);
        break;
      }

      case 'own_card':
      case 'has_card': {
        const targetId = String(req.cardId || req.id || req.card || '').trim();
        const inv = await getInv();
        if (!inv.ok) return 0;
        let count = 0;
        if (inv.cards) {
          count = Number(inv.cards[targetId]) || 0;
          if (targetId === 'haseo_exclusive' || targetId === 'haseo_otsutsuki_exclusive') {
            count = Math.max(count, Number(inv.cards['haseo_otsutsuki_exclusive'] || 0), Number(inv.cards['haseo_exclusive'] || 0));
          }
        }
        if (count === 0 && inv.cardTraits && typeof inv.cardTraits === 'object') {
          for (const instKey in inv.cardTraits) {
            const cId = String(inv.cardTraits[instKey]?.cardId || '').trim();
            if (cId === targetId || ((targetId === 'haseo_exclusive' || targetId === 'haseo_otsutsuki_exclusive') && (cId === 'haseo_otsutsuki_exclusive' || cId === 'haseo_exclusive'))) {
              count++;
            }
          }
        }
        if (count === 0 && (targetId === 'ayato_uzumaki_flashback' || targetId === 'ayato_hyuga_flashback')) {
          count = (inv.cards?.['ayato_uzumaki_flashback'] || 0) + (inv.cards?.['ayato_hyuga_flashback'] || 0);
        }
        progress = count;
        break;
      }

      case 'own_pack': {
        const packId = req.packId;
        const inv = await getInv();
        if (!inv.ok || !inv.packs) return 0;
        progress = inv.packs[packId] || 0;
        break;
      }

      case 'own_title': {
        const titleId = req.titleId;
        const profile = await getProfile();
        if (!profile.ok) return 0;
        const hasTitle = profile.profile?.unlockedTitles && profile.profile.unlockedTitles.includes(titleId);
        progress = hasTitle ? 1 : 0;
        break;
      }

      case 'play_games':
      case 'play_battles':
      case 'games_played':
      case 'battles_played': {
        const result = await getStats();
        if (!result.ok) return 0;
        const currentValue = result.stats?.battlesPlayed || 0;
        if (isCyclicOrRepeatable && userMission && typeof userMission === 'object') {
          if (!userMission.initialProgress) userMission.initialProgress = {};
          const isExplicitZero = mission.startFromZero || mission.start_from_zero || req?.startFromZero || req?.start_from_zero;
          const needsAnchor = !userMission.anchor_battles_played ||
                              userMission.initialProgress.battles_played === undefined ||
                              (isExplicitZero && !userMission.claimedAt && userMission.initialProgress.battles_played === 0 && currentValue > 0);
          if (needsAnchor) {
            userMission.initialProgress.battles_played = currentValue;
            userMission.anchor_battles_played = true;
            if (userMissions && mission.id) {
              if (!userMissions[mission.id]) userMissions[mission.id] = userMission;
              userMissions[mission.id].initialProgress = userMission.initialProgress;
              userMissions[mission.id].anchor_battles_played = true;
              if (!userMission.claimedAt && isExplicitZero) {
                userMissions[mission.id].completed = false;
                userMissions[mission.id].progressValue = 0;
              }
            }
          }
        }
        const initialValue = isCyclicOrRepeatable ? (Number(userMission?.initialProgress?.battles_played) || 0) : 0;
        progress = Math.max(0, currentValue - initialValue);
        break;
      }

      case 'cards_obtained':
      case 'obtain_cards': {
        const result = await getStats();
        if (!result.ok) return 0;
        const currentValue = result.stats?.totalCardsObtained || 0;
        if (isCyclicOrRepeatable && userMission && typeof userMission === 'object') {
          if (!userMission.initialProgress) userMission.initialProgress = {};
          if (userMission.initialProgress.cards_obtained === undefined) {
            userMission.initialProgress.cards_obtained = currentValue;
          }
        }
        const initialValue = isCyclicOrRepeatable ? (userMission?.initialProgress?.cards_obtained ?? currentValue) : 0;
        progress = Math.max(0, currentValue - initialValue);
        break;
      }

      case 'unique_cards_by_quality': {
        const quality = String(req.quality || '').toLowerCase();
        const inv = await getInv();
        if (!inv.ok || !inv.cards) return 0;
        const allCards = await getAllCards();
        let count = 0;
        for (const cardId in inv.cards) {
          if (inv.cards[cardId] > 0) {
            const cardData = Array.isArray(allCards) ? allCards.find(c => c.id === cardId) : null;
            if (cardData) {
              const cardQ = String(cardData.quality || cardData.calidad || '').toLowerCase();
              if (cardQ === quality || (quality === 'cota' && (cardQ.includes('cota') || cardQ.includes('arc')))) {
                count++;
              }
            }
          }
        }
        progress = count;
        break;
      }

      case 'play_infinite_levels':
      case 'infinite_levels': {
        progress = userMission?.progress?.[reqType] ?? userMission?.progressValue ?? (typeof userMission?.progress === 'number' ? userMission.progress : 0);
        break;
      }

      case 'complete_trade':
      case 'trade': {
        const directVal = userMission?.progress?.[reqType] ?? userMission?.progress?.complete_trade ?? userMission?.progress?.trade ?? userMission?.progressValue ?? (typeof userMission?.progress === 'number' ? userMission.progress : 0);
        let count = Number(directVal) || 0;
        if (count === 0) {
          try {
            const result = await getStats();
            if (result && result.ok && result.stats) {
              const currentTrades = Number(result.stats.tradesCompleted) || 0;
              if (isCyclicOrRepeatable && userMission && typeof userMission === 'object') {
                if (!userMission.initialProgress) userMission.initialProgress = {};
                if (userMission.initialProgress.trades_completed === undefined) {
                  userMission.initialProgress.trades_completed = currentTrades;
                }
              }
              const initialValue = isCyclicOrRepeatable ? (userMission?.initialProgress?.trades_completed ?? currentTrades) : 0;
              if (currentTrades > initialValue) {
                count = Math.max(0, currentTrades - initialValue);
              }
            }
          } catch (_) {}
        }
        progress = count;
        break;
      }

      case 'login': {
        progress = 1;
        break;
      }

      case 'rounds_won':
      case 'card_rounds_won':
      case 'rounds_won_with_filter':
      case 'play_games_with_card':
      case 'games_played_with_card':
      case 'win_games_with_card':
      case 'win_games_with_filter':
      case 'obtain_card':
      case 'duplicate_card': {
        if (mission.evolutionId && typeof userEvolutions !== 'undefined' && userEvolutions[mission.evolutionId]) {
          const evoProg = userEvolutions[mission.evolutionId];
          progress = evoProg?.missionsProgress?.[mission.id]?.current || 0;
        } else {
          progress = userMission?.progress?.[reqType] || (typeof userMission?.progress === 'number' ? userMission.progress : 0);
        }
        break;
      }

      case 'rounds_won_with_stat':
      case 'win_rounds_with_stat': {
        const reqStat = req.stat || req.statRequired || req.statType || '';
        const normStat = String(reqStat).toLowerCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        const key = normStat ? `rounds_won_stat_${normStat}` : 'rounds_won_with_stat';
        if (typeof userMission?.progress === 'object' && userMission.progress !== null) {
          progress = userMission.progress[key] ?? userMission.progress[reqType] ?? userMission.progress['rounds_won_with_stat'] ?? userMission.progressValue ?? 0;
        } else {
          progress = (typeof userMission?.progress === 'number') ? userMission.progress : (userMission?.progressValue || 0);
        }
        break;
      }

      case 'win_event_battle':
      case 'event_battle_won': {
        const battleId = req.battleId || mission.battleId;
        const key = battleId ? `event_battle_${battleId}` : 'win_event_battle';
        if (typeof userMission?.progress === 'object' && userMission.progress !== null) {
          progress = userMission.progress[key] ?? userMission.progress[reqType] ?? userMission.progress['win_event_battle'] ?? userMission.progress['event_battle_won'] ?? userMission.progressValue ?? 0;
        } else {
          progress = (typeof userMission?.progress === 'number') ? userMission.progress : (userMission?.progressValue || 0);
        }
        break;
      }

      case 'win_special_event_level':
      case 'complete_special_event_level':
      case 'special_event_level': {
        const levelKey = req.levelId || req.battleId || mission.levelId;
        const worldKey = req.worldId || mission.worldId;
        const key = levelKey ? `special_level_${levelKey}` : (worldKey ? `special_world_${worldKey}` : 'win_special_event_level');
        if (typeof userMission?.progress === 'object' && userMission.progress !== null) {
          if (levelKey) {
            progress = Number(userMission.progress[key]) || 0;
          } else if (worldKey) {
            progress = Number(userMission.progress[key] ?? userMission.progress[`special_world_${worldKey}`]) || 0;
          } else {
            progress = Number(userMission.progress[key] ?? userMission.progress[reqType] ?? userMission.progress['win_special_event_level'] ?? userMission.progress['complete_special_event_level'] ?? userMission.progressValue) || 0;
          }
        } else {
          progress = (levelKey || worldKey) ? 0 : ((typeof userMission?.progress === 'number') ? userMission.progress : (userMission?.progressValue || 0));
        }
        break;
      }

      case 'complete_specific_mission': {
        const targetId = req.targetMissionId || req.missionId || mission.targetMissionId || mission.missionId;
        if (targetId && typeof userMissions !== 'undefined' && userMissions[targetId]) {
          const targetM = userMissions[targetId];
          progress = (targetM.completed || targetM.claimedAt) ? 1 : 0;
        } else {
          progress = 0;
        }
        break;
      }

      default:
        progress = 0;
        break;
    }
  } catch (error) {
    console.error('[MISSIONS] Error calculando requerimiento individual:', error);
    progress = 0;
  }

  if (mission.repeatable && userMission.needsReset) {
    progress = 0;
  }

  return Math.min(progress, reqAmount);
}

// Calcular progreso de todos los requerimientos de una misión
async function checkMissionRequirementsProgress(mission, context = null) {
  const reqs = getMissionRequirements(mission);
  const userMission = userMissions[mission.id] || {};

  if (reqs.length === 0) {
    return [{
      type: 'default',
      target: 1,
      progress: userMission.completed ? 1 : 0,
      percent: userMission.completed ? 100 : 0,
      isCompleted: !!userMission.completed,
      description: 'Objetivo'
    }];
  }

  const results = [];
  for (let i = 0; i < reqs.length; i++) {
    const req = reqs[i];
    const target = Number(req.amount || req.target || 1);
    let progress = await checkSingleRequirementProgress(mission, req, context, userMission);
    
    // Si la misión ya estaba completada en el guardado, asegurar que se refleje completado
    // (excepto si es una misión relativa/startFromZero que aún no ha sido reclamada)
    const isRelative = isRelativeMission(mission, req);
    if (userMission.claimedAt && !mission.repeatable) {
      progress = target;
    } else if (userMission.completed && !mission.repeatable && !isRelative) {
      progress = target;
    }

    const percent = Math.min((progress / target) * 100, 100);
    const isCompleted = progress >= target;

    results.push({
      type: req.type,
      target,
      progress,
      percent,
      isCompleted,
      description: getRequirementDescription(req)
    });
  }

  return results;
}

// Compatibilidad: calcular progreso general de una misión
async function checkMissionProgress(mission, context = null) {
  const reqs = await checkMissionRequirementsProgress(mission, context);
  return reqs[0]?.progress || 0;
}

// Verificar si una misión se puede reclamar
function canClaimMission(mission, userMission) {
  // Si no existe estado del usuario para esta misión
  if (!userMission) return false;

  // Si la misión no está visible para el usuario actual
  if (!isMissionVisibleForUser(mission)) return false;
  
  // Si es diaria o semanal, verificar expiración de ciclo y si ya fue reclamada en este ciclo (06:00 AM)
  if (mission.category === 'daily' || mission.category === 'weekly') {
    const currentCycle = typeof getCycleKeyForMission === 'function'
      ? getCycleKeyForMission(mission)
      : (mission.category === 'daily' ? getDailyCycleKey() : getWeeklyCycleKey());

    // Si la misión fue registrada en un ciclo anterior, ha expirado para el ciclo actual
    if (userMission.currentCycle && userMission.currentCycle !== currentCycle) {
      return false;
    }
    // Si ya fue reclamada en este ciclo
    if (isMissionClaimedInCurrentCycle(mission, userMission)) {
      return false;
    }
    // Si fue reclamada en un ciclo anterior y aún no se ha completado en el ciclo actual
    if (userMission.claimedAt && !isMissionClaimedInCurrentCycle(mission, userMission)) {
      if (!userMission.currentCycle || userMission.currentCycle !== currentCycle) {
        return false;
      }
    }
  }

  // Si no está completada
  if (!userMission.completed) return false;
  
  // Si es repetible con cooldown estándar
  if (mission.repeatable && userMission.claimedAt) {
    const now = Date.now();
    const cooldownMs = (mission.cooldown || 0) * 1000;
    const timeSinceClaim = now - userMission.claimedAt;
    
    if (cooldownMs > 0 && timeSinceClaim < cooldownMs) {
      return false; // Aún en cooldown
    }
  }
  
  // Si no es repetible y ya fue reclamada (y no es diaria ni semanal)
  if (!mission.repeatable && mission.category !== 'daily' && mission.category !== 'weekly' && userMission.claimedAt) {
    return false;
  }
  
  return true;
}
window.canClaimMission = canClaimMission;

// Función para contar misiones pendientes de reclamar
function getClaimableMissionsCount() {
  let list = Array.isArray(availableMissions) && availableMissions.length > 0 ? availableMissions : null;
  if (!list) {
    try {
      const cached = localStorage.getItem('kvrcards_missions_cache');
      if (cached) list = JSON.parse(cached);
    } catch {}
  }
  if (!Array.isArray(list) || !userMissions) return 0;
  let count = 0;
  for (const m of list) {
    if (!m || !m.id || !isMissionVisibleForUser(m)) continue;
    const uM = userMissions[m.id];
    if (!uM) continue;

    if (m.category === 'daily' || m.category === 'weekly') {
      const currentCycle = typeof getCycleKeyForMission === 'function' ? getCycleKeyForMission(m) : null;
      if (currentCycle && uM.currentCycle && uM.currentCycle !== currentCycle) {
        continue;
      }
    }

    if (canClaimMission(m, uM)) {
      count++;
    }
  }
  return count;
}
window.getClaimableMissionsCount = getClaimableMissionsCount;

// Función para contar misiones pendientes de reclamar por categoría/subapartado
function getClaimableMissionsCountsByCategory() {
  let list = Array.isArray(availableMissions) && availableMissions.length > 0 ? availableMissions : null;
  if (!list) {
    try {
      const cached = localStorage.getItem(MISSIONS_CACHE_KEY);
      if (cached) list = JSON.parse(cached);
    } catch {}
  }
  const counts = {
    fundamentals: 0,
    daily: 0,
    weekly: 0,
    featured: 0,
    limited: 0
  };
  if (!Array.isArray(list) || !userMissions) return counts;
  for (const m of list) {
    if (!m || !m.id || !isMissionVisibleForUser(m)) continue;
    const uM = userMissions[m.id];
    if (!uM) continue;

    if (m.category === 'daily' || m.category === 'weekly') {
      const currentCycle = typeof getCycleKeyForMission === 'function' ? getCycleKeyForMission(m) : null;
      if (currentCycle && uM.currentCycle && uM.currentCycle !== currentCycle) {
        continue;
      }
    }

    if (canClaimMission(m, uM)) {
      const cat = m.category || 'fundamentals';
      if (counts[cat] !== undefined) {
        counts[cat]++;
      } else {
        counts.fundamentals++;
      }
    }
  }
  return counts;
}
window.getClaimableMissionsCountsByCategory = getClaimableMissionsCountsByCategory;

// Actualizar badges en los botones de subapartados de misiones
function updateMissionSubtabBadges() {
  const setBadge = window.setNotificationBadge || (typeof setNotificationBadge === 'function' ? setNotificationBadge : null);
  if (!setBadge) return;
  const counts = getClaimableMissionsCountsByCategory();
  setBadge('.mission-subtab[data-subtab="fundamentals"]', counts.fundamentals);
  setBadge('.mission-subtab[data-subtab="daily"]', counts.daily);
  setBadge('.mission-subtab[data-subtab="weekly"]', counts.weekly);
  setBadge('.mission-subtab[data-subtab="featured"]', counts.featured);
  setBadge('.mission-subtab[data-subtab="limited"]', counts.limited);
}
window.updateMissionSubtabBadges = updateMissionSubtabBadges;

// Función para contar Kizunas pendientes de reclamar
function getClaimableKizunasCount(invCards = null) {
  let list = Array.isArray(availableKizunas) && availableKizunas.length > 0 ? availableKizunas : null;
  if (!list) {
    try {
      const cached = localStorage.getItem('kvr_kizunas_cache');
      if (cached) list = JSON.parse(cached);
    } catch {}
  }
  if (!Array.isArray(list)) return 0;

  let uKizunas = userKizunas;
  if (!uKizunas || Object.keys(uKizunas).length === 0) {
    try {
      const uKey = typeof getKizunasStorageKey === 'function' ? getKizunasStorageKey() : null;
      if (uKey) {
        const saved = localStorage.getItem(uKey);
        if (saved) uKizunas = JSON.parse(saved);
      }
    } catch {}
  }
  uKizunas = uKizunas || {};

  let cards = invCards;
  if (!cards && window.userInventoryCache && window.userInventoryCache.cards) {
    cards = window.userInventoryCache.cards;
  }
  if (!cards) return 0;

  let count = 0;
  for (const kizuna of list) {
    if (!kizuna || !kizuna.id) continue;
    const uK = uKizunas[kizuna.id] || {};
    if (uK.claimed) continue;
    const reqs = kizuna.cardIds || [];
    if (reqs.length === 0) continue;
    const allOwned = reqs.every(cId => cards[cId] && cards[cId] > 0);
    if (allOwned) count++;
  }
  return count;
}
window.getClaimableKizunasCount = getClaimableKizunasCount;

// Función para contar Kizunas pendientes de reclamar por grupo
function getClaimableKizunasCountByGroup(invCards = null) {
  let list = Array.isArray(availableKizunas) && availableKizunas.length > 0 ? availableKizunas : null;
  if (!list) {
    try {
      const cached = localStorage.getItem(KIZUNAS_CACHE_KEY);
      if (cached) list = JSON.parse(cached);
    } catch {}
  }
  if (!Array.isArray(list)) return {};

  let uKizunas = userKizunas;
  if (!uKizunas || Object.keys(uKizunas).length === 0) {
    try {
      const uKey = typeof getKizunasStorageKey === 'function' ? getKizunasStorageKey() : null;
      if (uKey) {
        const saved = localStorage.getItem(uKey);
        if (saved) uKizunas = JSON.parse(saved);
      }
    } catch {}
  }
  uKizunas = uKizunas || {};

  let cards = invCards;
  if (!cards && window.userInventoryCache && window.userInventoryCache.cards) {
    cards = window.userInventoryCache.cards;
  }
  if (!cards) return {};

  const countsByGroup = {};
  for (const kizuna of list) {
    if (!kizuna || !kizuna.id) continue;
    let rawGroup = kizuna.group && String(kizuna.group).trim();
    if (!rawGroup || rawGroup.toLowerCase() === 'general') {
      rawGroup = 'Sin grupo';
    }
    if (!countsByGroup[rawGroup]) {
      countsByGroup[rawGroup] = 0;
    }
    const uK = uKizunas[kizuna.id] || {};
    if (uK.claimed) continue;
    const reqs = kizuna.cardIds || [];
    if (reqs.length === 0) continue;
    const allOwned = reqs.every(cId => cards[cId] && cards[cId] > 0);
    if (allOwned) {
      countsByGroup[rawGroup]++;
    }
  }
  return countsByGroup;
}
window.getClaimableKizunasCountByGroup = getClaimableKizunasCountByGroup;

// Actualizar badges en los grupos de Kizuna existentes en pantalla
function updateKizunaGroupBadges(invCards = null) {
  const groupElements = document.querySelectorAll('.kizuna-group');
  if (!groupElements || groupElements.length === 0) return;

  const countsByGroup = getClaimableKizunasCountByGroup(invCards);
  groupElements.forEach(groupEl => {
    const groupName = groupEl.getAttribute('data-group-name');
    const meta = groupEl.querySelector('.kizuna-group-meta');
    const counter = groupEl.querySelector('.kizuna-group-counter');
    if (!meta || !counter) return;

    let badge = meta.querySelector('.kizuna-group-notif');
    const count = countsByGroup[groupName] || 0;

    if (count > 0) {
      const text = count > 99 ? '99+' : String(count);
      if (!badge) {
        badge = document.createElement('span');
        badge.className = 'kizuna-group-notif notif-badge';
        badge.title = `${count} kizuna${count > 1 ? 's' : ''} por reclamar`;
        badge.textContent = text;
        meta.insertBefore(badge, counter);
      } else {
        if (badge.textContent !== text) badge.textContent = text;
        badge.title = `${count} kizuna${count > 1 ? 's' : ''} por reclamar`;
        if (badge.style.display !== 'inline-flex') badge.style.display = 'inline-flex';
      }
    } else {
      if (badge) badge.remove();
    }
  });
}
window.updateKizunaGroupBadges = updateKizunaGroupBadges;


// Calcular tiempo restante de cooldown / reseteo a las 06:00 AM
function getCooldownText(mission, userMission) {
  if (!userMission) return '';

  if (mission.category === 'daily') {
    if (isMissionClaimedInCurrentCycle(mission, userMission)) {
      const now = new Date();
      const next6am = new Date(now);
      if (now.getHours() >= 6) {
        next6am.setDate(next6am.getDate() + 1);
      }
      next6am.setHours(6, 0, 0, 0);
      const diff = next6am.getTime() - now.getTime();
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      return `🔄 Reinicia a las 06:00 (${hours}h ${mins}m)`;
    }
    return '';
  }

  if (mission.category === 'weekly') {
    if (isMissionClaimedInCurrentCycle(mission, userMission)) {
      const now = new Date();
      const nextMonday = new Date(now);
      nextMonday.setHours(nextMonday.getHours() - 6);
      const day = nextMonday.getDay();
      const daysUntilNextMonday = (8 - day) % 7 || 7;
      nextMonday.setDate(nextMonday.getDate() + daysUntilNextMonday);
      nextMonday.setHours(6, 0, 0, 0);
      const diff = nextMonday.getTime() - now.getTime();
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      return `🔄 Reinicia el lunes a las 06:00 (${days}d ${hours}h)`;
    }
    return '';
  }

  if (mission.repeatable && userMission.claimedAt && mission.cooldown) {
    const now = Date.now();
    const cooldownMs = (mission.cooldown || 0) * 1000;
    const timeSinceClaim = now - userMission.claimedAt;
    const timeRemaining = cooldownMs - timeSinceClaim;
    if (timeRemaining <= 0) return '';
    const hours = Math.floor(timeRemaining / (1000 * 60 * 60));
    const minutes = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));
    return hours > 0 ? `Disponible en ${hours}h ${minutes}m` : `Disponible en ${minutes}m`;
  }

  return '';
}

// Variable para evitar renderizados concurrentes
let isRenderingMissions = false;

// Renderizar misiones
async function renderMissions() {
  // Evitar renderizados concurrentes
  if (isRenderingMissions) {
    console.log('[MISSIONS] Renderizado ya en progreso, saltando...');
    return;
  }
  
  isRenderingMissions = true;
  
  try {
    // Verificar que al menos un contenedor existe
    if (!missionsFundamentalsContainer && !missionsFeaturedContainer && !missionsLimitedContainer) {
      console.warn('[MISSIONS] No se encontraron contenedores de misiones por categoría');
      return;
    }
  
  // Asegurar que las misiones estén cargadas
  if (availableMissions.length === 0) {
    if (missionsFundamentalsContainer) {
      missionsFundamentalsContainer.innerHTML = '<p class="missions-loading">Cargando misiones...</p>';
    }
    await loadMissions();
    
    if (availableMissions.length === 0) {
      if (missionsFundamentalsContainer) {
        missionsFundamentalsContainer.innerHTML = '<p class="missions-empty">No hay misiones disponibles</p>';
      }
      return;
    }
  }
  
  await loadUserMissionsState();
  
  // Limpiar todos los contenedores
  if (missionsFundamentalsContainer) missionsFundamentalsContainer.innerHTML = '';
  if (missionsDailyContainer) missionsDailyContainer.innerHTML = '';
  if (missionsWeeklyContainer) missionsWeeklyContainer.innerHTML = '';
  if (missionsFeaturedContainer) missionsFeaturedContainer.innerHTML = '';
  if (missionsLimitedContainer) missionsLimitedContainer.innerHTML = '';
  if (completedMissionsContainer) completedMissionsContainer.innerHTML = '';
  
  // Cargar datos una sola vez en paralelo antes del bucle para máxima velocidad
  await ensureMissionCatalogCache();
  const [stats, inv] = await Promise.all([
    window.kvrcards.getUserStats().catch(() => ({ ok: false })),
    window.kvrcards.getInventory().catch(() => ({ ok: false }))
  ]);
  
  let localProfile = null;
  try {
    const savedProf = localStorage.getItem('kvr_user_profile');
    if (savedProf) localProfile = JSON.parse(savedProf);
  } catch {}
  if (!localProfile && typeof userProfile !== 'undefined') {
    localProfile = userProfile;
  }
  
  const context = {
    stats,
    inv,
    allCards: missionCatalogCache.cards || [],
    profile: { ok: true, profile: localProfile || {} }
  };
  
  // Separar misiones por categoría
  const fundamentalsMissions = [];
  const dailyMissions = [];
  const weeklyMissions = [];
  const featuredMissions = [];
  const limitedMissions = [];
  const completedMissions = [];
  
  let hasStateChanged = false;
  const activeMissionsUser = getActiveMissionsUsername();
  
  for (const mission of availableMissions) {
    if (!isMissionVisibleForUser(mission, activeMissionsUser)) {
      continue;
    }

    let userMission = userMissions[mission.id];
    
    // Si no existe la misión en el estado del usuario, crear entrada nueva
    if (!userMission) {
      userMission = {};
      userMissions[mission.id] = userMission;
    }

    // Soporte para resetKey que permite reiniciar misiones remotamente si se desea
    if (mission.resetKey && userMission.lastResetKey !== mission.resetKey) {
      userMission.lastResetKey = mission.resetKey;
      userMission.completed = false;
      delete userMission.claimedAt;
      delete userMission.initialProgress;
      userMission.progressValue = 0;
      userMission.progress = 0;
      userMission.needsReset = true;
      hasStateChanged = true;
    }

    // Manejo de ciclo 06:00 AM para misiones diarias y semanales
    if (mission.category === 'daily' || mission.category === 'weekly') {
      const currentCycle = getCycleKeyForMission(mission);
      if (userMission.currentCycle !== currentCycle) {
        userMission.currentCycle = currentCycle;
        userMission.needsReset = true;
        userMission.completed = false;
        userMission.progressValue = 0;
        userMission.progress = 0;
        hasStateChanged = true;
      }
    }
    
    // Si es la primera vez que se ve esta misión O si es repetible/cíclica/relativa y fue reseteada, guardar el progreso inicial
    if (!userMission.initialProgress || (isRelativeMission(mission) && userMission.needsReset)) {
      
      if (stats.ok || (inv.ok && inv.cards)) {
        // Contar cartas únicas
        const uniqueCards = (inv.cards && typeof inv.cards === 'object')
          ? Object.keys(inv.cards).filter(cardId => inv.cards[cardId] > 0).length
          : 0;
        
        // Contar cartas por calidad
        const cardsByQuality = {};
        if (inv.cards && typeof inv.cards === 'object') {
          for (const cardId in inv.cards) {
            if (inv.cards[cardId] > 0) {
              const cardData = Array.isArray(context.allCards) ? context.allCards.find(c => c.id === cardId) : null;
              if (cardData) {
                const quality = (cardData.quality || cardData.calidad || 'Bronce').toLowerCase();
                cardsByQuality[`cards_${quality}`] = (cardsByQuality[`cards_${quality}`] || 0) + inv.cards[cardId];
              }
            }
          }
        }
        
        userMission.initialProgress = {
          packs_opened: stats.stats?.totalPacksOpened || 0,
          battles_won: stats.stats?.battlesWon || 0,
          battles_played: stats.stats?.battlesPlayed || 0,
          cards_obtained: stats.stats?.totalCardsObtained || 0,
          coins: inv.wallet?.coins || 0,
          unique_cards: uniqueCards,
          trades_completed: stats.stats?.tradesCompleted || 0,
          ...cardsByQuality
        };
        
        // Resetear progreso de misiones diarias completadas si es repetible
        if (mission.repeatable || mission.category === 'daily' || mission.category === 'weekly') {
          userMission.progress = { dailyMissionsCompleted: 0 };
          userMission.progressValue = 0;
        } else {
          const missionReqs = getMissionRequirements(mission);
          if (missionReqs.some(r => r.type === 'complete_daily_missions')) {
            if (typeof userMission.progress !== 'object' || !userMission.progress) {
              userMission.progress = { dailyMissionsCompleted: Number(userMission.progress) || 0 };
            }
            userMission.progress = { dailyMissionsCompleted: userMission.progress?.dailyMissionsCompleted || 0 };
          }
        }
        
        userMission.needsReset = false;
        userMissions[mission.id] = userMission;
        hasStateChanged = true;
        console.log('[MISSIONS] Inicializado progreso para:', mission.id, userMission.initialProgress);
      }
    }
    
    // SIEMPRE calcular el progreso actual de todos los requerimientos usando el contexto en memoria
    const reqsProgress = await checkMissionRequirementsProgress(mission, context);
    const isCompleted = reqsProgress.length > 0 && reqsProgress.every(r => r.isCompleted);
    const primaryReq = reqsProgress[0] || { progress: 0, target: 1 };
    
    // Para misiones relativas (startFromZero) que aún no han sido reclamadas, asegurar que no queden marcadas como completadas erróneamente
    if (isRelativeMission(mission) && !userMission.claimedAt) {
      if (userMission.completed && !isCompleted) {
        userMissions[mission.id] = { ...userMission, completed: false, progressValue: primaryReq.progress };
        userMissions[mission.id].progress = primaryReq.progress;
        hasStateChanged = true;
        userMission = userMissions[mission.id];
      }
    }
    
    // Actualizar estado de completado
    if (isCompleted && !userMission.completed) {
      userMissions[mission.id] = { ...userMission, completed: true, progressValue: primaryReq.progress };
      const missionReqs = getMissionRequirements(mission);
      if (missionReqs.some(r => r.type === 'complete_daily_missions')) {
        const dReq = reqsProgress.find(r => r.type === 'complete_daily_missions');
        userMissions[mission.id].progress = { dailyMissionsCompleted: dReq?.progress || 1 };
      } else {
        userMissions[mission.id].progress = primaryReq.progress;
      }
      hasStateChanged = true;
      userMission = userMissions[mission.id];
    } else if (!isCompleted && userMission.completed && !userMission.claimedAt && isRelativeMission(mission)) {
      // Corrección de misiones startFromZero que se hubieran marcado como completadas erróneamente sin haber sido reclamadas
      userMissions[mission.id] = { ...userMission, completed: false, progressValue: primaryReq.progress };
      userMissions[mission.id].progress = primaryReq.progress;
      hasStateChanged = true;
      userMission = userMissions[mission.id];
    }
    
    const isClaimedInCycle = (mission.category === 'daily' || mission.category === 'weekly') && isMissionClaimedInCurrentCycle(mission, userMission);
    const wasClaimedBefore = userMission.claimedAt && (!mission.repeatable) && mission.category !== 'daily' && mission.category !== 'weekly';
    const canClaim = canClaimMission(mission, userMission);
    const cooldownText = getCooldownText(mission, userMission);
    
    const missionCard = document.createElement('div');
    missionCard.className = 'mission-card';
    if (wasClaimedBefore || isClaimedInCycle) missionCard.classList.add('completed');
    if (mission.repeatable || mission.category === 'daily' || mission.category === 'weekly') missionCard.classList.add('repeatable');
    
    // Crear rewards HTML con nombres reales y cantidades dinámicas
    const rewardsHTML = (mission.rewards || []).map(reward => {
      const info = getRewardDisplayInfo(reward);
      const attrs = [];
      if (info.description) attrs.push(`data-title-desc="${escapeHtml(info.description)}"`);
      if (info.name) attrs.push(`data-title-name="${escapeHtml(info.name)}"`);
      if (info.gradient) attrs.push(`data-title-gradient="${escapeHtml(info.gradient)}"`);
      if (info.titleId) attrs.push(`data-title-id="${escapeHtml(info.titleId)}"`);
      if (info.type) attrs.push(`data-reward-type="${escapeHtml(info.type)}"`);
      return `<span class="mission-reward-item ${info.className}" ${attrs.join(' ')}>${info.text}</span>`;
    }).join('');

    const multipleReqs = reqsProgress.length > 1;
    const requirementsHTML = `
      <div class="mission-requirements-container" style="${multipleReqs ? 'display: flex; flex-direction: column; gap: 8px; margin-bottom: 15px;' : ''}">
        ${reqsProgress.map((reqItem) => `
          <div class="mission-requirement" style="${multipleReqs ? 'margin-bottom: 0; padding: 10px 12px;' : ''}">
            <div class="mission-req-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
              <span class="mission-req-desc" style="font-size: 13px; font-weight: 600; color: #cbd5e1;">${escapeHtml(reqItem.description)}</span>
              <span class="mission-req-text" style="font-size: 12px; font-weight: 700; color: ${reqItem.isCompleted ? '#10b981' : 'var(--gold)'}; margin-left: 8px; white-space: nowrap;">
                ${reqItem.progress} / ${reqItem.target}
              </span>
            </div>
            <div class="mission-progress-bar">
              <div class="mission-progress-fill" style="width: ${reqItem.percent}%; ${reqItem.isCompleted ? 'background: linear-gradient(90deg, #10b981 0%, #34d399 100%);' : ''}"></div>
            </div>
          </div>
        `).join('')}
      </div>
    `;
    
    missionCard.innerHTML = `
      <div class="mission-header">
        <h3 class="mission-title">${mission.title}</h3>
        ${(wasClaimedBefore || isClaimedInCycle) ? '<span class="mission-checkmark">✅</span>' : ''}
      </div>
      <p class="mission-description">${mission.description}</p>
      
      ${requirementsHTML}
      
      <div class="mission-rewards">
        <strong>Recompensas:</strong>
        <div class="mission-rewards-list">
          ${rewardsHTML}
        </div>
      </div>
      
      ${cooldownText ? `<p class="mission-cooldown">${cooldownText}</p>` : ''}
      
      <button 
        class="mission-claim-btn" 
        data-mission-id="${mission.id}"
        ${!canClaim ? 'disabled' : ''}
      >
        ${wasClaimedBefore ? 'Completada' : isClaimedInCycle ? '✅ Reclamada' : canClaim ? '🎁 Reclamar' : isCompleted ? 'En espera' : 'Incompleta'}
      </button>
    `;
    
    // Clasificar misiones por categoría
    // Las completadas no repetibles van al contenedor de completadas
    if (wasClaimedBefore && !mission.repeatable && mission.category !== 'daily' && mission.category !== 'weekly') {
      completedMissions.push(missionCard);
    } else {
      // Determinar categoría (por defecto 'fundamentals' si no tiene)
      const category = mission.category || 'fundamentals';
      
      switch (category) {
        case 'daily':
          dailyMissions.push(missionCard);
          break;
        case 'weekly':
          weeklyMissions.push(missionCard);
          break;
        case 'featured':
          featuredMissions.push(missionCard);
          break;
        case 'limited':
          limitedMissions.push(missionCard);
          break;
        case 'fundamentals':
        default:
          fundamentalsMissions.push(missionCard);
          break;
      }
    }
  }
  
  // Debug: verificar contenedores
  console.log('[MISSIONS] Contenedores disponibles:', {
    fundamentals: !!missionsFundamentalsContainer,
    daily: !!missionsDailyContainer,
    weekly: !!missionsWeeklyContainer,
    featured: !!missionsFeaturedContainer,
    limited: !!missionsLimitedContainer
  });
  console.log('[MISSIONS] Misiones clasificadas:', {
    fundamentals: fundamentalsMissions.length,
    daily: dailyMissions.length,
    weekly: weeklyMissions.length,
    featured: featuredMissions.length,
    limited: limitedMissions.length
  });
  
  // Renderizar misiones por categoría
  if (missionsFundamentalsContainer) {
    if (fundamentalsMissions.length > 0) {
      fundamentalsMissions.forEach(card => missionsFundamentalsContainer.appendChild(card));
    } else {
      missionsFundamentalsContainer.innerHTML = '<p class="missions-empty">No hay misiones fundamentales disponibles</p>';
    }
  }
  
  if (missionsDailyContainer) {
    if (dailyMissions.length > 0) {
      dailyMissions.forEach(card => missionsDailyContainer.appendChild(card));
    } else {
      missionsDailyContainer.innerHTML = '<p class="missions-empty">No hay misiones diarias disponibles</p>';
    }
  }
  
  if (missionsWeeklyContainer) {
    if (weeklyMissions.length > 0) {
      weeklyMissions.forEach(card => missionsWeeklyContainer.appendChild(card));
    } else {
      missionsWeeklyContainer.innerHTML = '<p class="missions-empty">No hay misiones semanales disponibles</p>';
    }
  }
  
  if (missionsFeaturedContainer) {
    if (featuredMissions.length > 0) {
      featuredMissions.forEach(card => missionsFeaturedContainer.appendChild(card));
    } else {
      missionsFeaturedContainer.innerHTML = '<p class="missions-empty">No hay misiones destacadas disponibles</p>';
    }
  }
  
  if (missionsLimitedContainer) {
    if (limitedMissions.length > 0) {
      limitedMissions.forEach(card => missionsLimitedContainer.appendChild(card));
    } else {
      missionsLimitedContainer.innerHTML = '<p class="missions-empty">No hay misiones limitadas disponibles</p>';
    }
  }
  
  // Renderizar misiones completadas
  if (completedMissions.length > 0) {
    completedMissions.forEach(card => completedMissionsContainer.appendChild(card));
    if (completedCount) completedCount.textContent = completedMissions.length;
    if (completedMissionsSection) completedMissionsSection.style.display = 'block';
  } else {
    if (completedMissionsSection) completedMissionsSection.style.display = 'none';
  }
  
    // Guardar estado de misiones en segundo plano una sola vez si ha cambiado
    if (hasStateChanged) {
      saveUserMissionsState().catch(console.error);
    }
    
    // Event listeners para botones de reclamar
    const claimButtons = document.querySelectorAll('.mission-claim-btn:not([disabled])');
    claimButtons.forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const missionId = btn.getAttribute('data-mission-id');
        if (!missionId || activeMissionClaims.has(missionId)) return;
        btn.disabled = true;
        btn.style.opacity = '0.6';
        btn.style.pointerEvents = 'none';
        btn.textContent = '⏳ Reclamando...';
        await claimMissionReward(missionId, btn);
      });
    });

    // Actualizar badges de subapartados de misiones
    updateMissionSubtabBadges();
  
  } finally {
    isRenderingMissions = false;
  }
}

// Mutex para evitar reclamos concurrentes de misiones
const activeMissionClaims = new Set();

// Reclamar recompensa de misión
async function claimMissionReward(missionId, btn = null) {
  if (!missionId || activeMissionClaims.has(missionId)) return;
  activeMissionClaims.add(missionId);

  const mission = availableMissions.find(m => m.id === missionId);
  if (!mission) {
    console.error('[MISSIONS] Misión no encontrada:', missionId);
    if (btn) {
      btn.disabled = false;
      btn.style.opacity = '1';
      btn.style.pointerEvents = 'auto';
    }
    activeMissionClaims.delete(missionId);
    return;
  }
  
  const userMission = userMissions[missionId];
  console.log('[MISSIONS] Estado de la misión:', missionId, userMission);
  console.log('[MISSIONS] Puede reclamar?', canClaimMission(mission, userMission));
  console.log('[MISSIONS] Objeto mission completo:', JSON.stringify(mission, null, 2));
  
  if (!canClaimMission(mission, userMission)) {
    if (btn) {
      btn.disabled = false;
      btn.style.opacity = '1';
      btn.style.pointerEvents = 'auto';
    }
    alert('❌ No puedes reclamar esta misión todavía');
    activeMissionClaims.delete(missionId);
    return;
  }
  
  console.log('[MISSIONS] Reclamando misión:', missionId);
  
  try {
    const claimedRewards = [];

    // Otorgar recompensas
    for (const reward of mission.rewards) {
      const type = normalizeRewardType(reward);
      switch (type) {
        case 'coins': {
          const coinsAmt = Number(reward.amount || reward.cantidad || reward.coins || reward.monedas || 0) || 0;
          if (coinsAmt <= 0) break;
          const result = await window.kvrcards.addCoins(coinsAmt);
          if (!result?.ok) throw new Error(result?.error || 'Error al añadir monedas');
          console.log(`[MISSIONS] ✅ +${coinsAmt} monedas`);
          claimedRewards.push({ ...reward, type: 'coins', amount: coinsAmt });
          break;
        }
          
        case 'kvr': {
          const kvrAmt = Number(reward.amount || reward.cantidad || reward.kvr || 0) || 0;
          if (kvrAmt <= 0) break;
          const result = await window.kvrcards.addKvR(kvrAmt);
          if (!result?.ok) throw new Error(result?.error || 'Error al añadir KvR');
          console.log(`[MISSIONS] ✅ +${kvrAmt} KvR`);
          claimedRewards.push({ ...reward, type: 'kvr', amount: kvrAmt });
          break;
        }

        case 'traits': {
          const traitsAmt = Number(reward.amount || reward.cantidad || reward.traits || reward.rasgos || 0) || 0;
          if (traitsAmt <= 0) break;
          if (window.kvrcards && typeof window.kvrcards.addTraits === 'function') {
            const result = await window.kvrcards.addTraits(traitsAmt);
            if (!result?.ok) console.warn('[MISSIONS] Error añadiendo rasgos:', result?.error);
          }
          console.log(`[MISSIONS] ✅ +${traitsAmt} rasgos`);
          claimedRewards.push({ ...reward, type: 'traits', amount: traitsAmt });
          break;
        }
          
        case 'pack': {
          const packAmount = Number(reward.amount || reward.cantidad || reward.quantity || reward.count || 1) || 1;
          const targetPackId = reward.packId || reward.id || reward.pack || reward.sobreId || reward.targetId;
          const result = await window.kvrcards.addPack(targetPackId, packAmount);
          if (!result?.ok) {
            console.warn(`[MISSIONS] ⚠️ No se pudo añadir sobre ${targetPackId}:`, result?.error);
          } else {
            console.log(`[MISSIONS] ✅ Sobre ${targetPackId} x${packAmount} añadido`);
            claimedRewards.push({ ...reward, type: 'pack', packId: targetPackId, amount: packAmount });
          }
          break;
        }
          
        case 'title': {
          let tId = String(reward.titleId || reward.id || reward.tituloId || reward.title || '').trim();
          let tName = '';
          if (typeof window.findTitleInCatalog === 'function') {
            const found = window.findTitleInCatalog(reward);
            if (found?.id) tId = found.id;
            if (found?.name) tName = found.name;
          }
          if (tId) {
            if (!userProfile.unlockedTitles || !Array.isArray(userProfile.unlockedTitles)) {
              userProfile.unlockedTitles = ['novato'];
            }
            if (!userProfile.unlockedTitles.includes(tId)) {
              userProfile.unlockedTitles.push(tId);
            }
            if (tName && !userProfile.unlockedTitles.includes(tName)) {
              userProfile.unlockedTitles.push(tName);
            }
            await saveUserProfile();
            if (typeof updateProfileDisplay === 'function') updateProfileDisplay();
            if (typeof updateTitleSelector === 'function') updateTitleSelector();
            console.log(`[MISSIONS] ✅ Título ${tName || tId} (${tId}) desbloqueado`);
          }
          claimedRewards.push(reward);
          break;
        }
          
        case 'card': {
          let targetCardId = reward.cardId || reward.id || reward.card || reward.cartaId || reward.targetId;
          const cardAmount = Number(reward.amount || reward.cantidad || reward.quantity || reward.count || 1) || 1;
          if (typeof window.findCardInCatalog === 'function') {
            const found = window.findCardInCatalog(reward);
            if (found?.id) targetCardId = found.id;
          }
          const result = await window.kvrcards.addCard(targetCardId, cardAmount);
          if (!result?.ok) {
            console.warn(`[MISSIONS] ⚠️ No se pudo añadir carta ${targetCardId}:`, result?.error);
          } else {
            console.log(`[MISSIONS] ✅ Carta ${targetCardId} x${cardAmount} añadida`);
            claimedRewards.push({ ...reward, type: 'card', cardId: targetCardId, amount: cardAmount });
          }
          break;
        }

        case 'background':
        case 'fondo': {
          const bgId = String(reward.backgroundId || reward.fondoId || reward.id || '').trim();
          if (bgId) {
            if (typeof window.unlockProfileBackground === 'function') {
              await window.unlockProfileBackground(bgId);
            } else if (typeof unlockProfileBackground === 'function') {
              await unlockProfileBackground(bgId);
            } else if (typeof userProfile !== 'undefined') {
              if (!Array.isArray(userProfile.unlockedBackgrounds)) userProfile.unlockedBackgrounds = ['default'];
              const altBgId = bgId.startsWith('fondo_') ? bgId.replace(/^fondo_/, '') : `fondo_${bgId}`;
              let updated = false;
              if (!userProfile.unlockedBackgrounds.includes(bgId)) { userProfile.unlockedBackgrounds.push(bgId); updated = true; }
              if (!userProfile.unlockedBackgrounds.includes(altBgId)) { userProfile.unlockedBackgrounds.push(altBgId); updated = true; }
              if (updated && typeof saveUserProfile === 'function') await saveUserProfile();
            }
            console.log(`[MISSIONS] ✅ Fondo ${bgId} desbloqueado`);
          }
          claimedRewards.push(reward);
          break;
        }
      }
    }
    
    // Incrementar contador de misiones diarias completadas si es una misión daily
    console.log('[MISSIONS] Misión reclamada - ID:', missionId, 'Categoría:', mission.category);
    if (mission.category === 'daily') {
      console.log('[MISSIONS] ✅ Es misión diaria, iniciando proceso de incremento...');
      
      // Incrementar contador en misiones normales que requieran 'complete_daily_missions'
      console.log('[MISSIONS] Paso 1: Buscando misiones normales con complete_daily_missions...');
      try {
        for (const m of availableMissions) {
          const reqs = getMissionRequirements(m);
          const hasDailyReq = reqs.some(r => r.type === 'complete_daily_missions');
          if (hasDailyReq) {
            console.log(`[MISSIONS] ✅ Misión ${m.id} requiere complete_daily_missions`);
            if (!userMissions[m.id]) {
              userMissions[m.id] = { progress: { dailyMissionsCompleted: 0 } };
            }
            if (typeof userMissions[m.id].progress !== 'object' || !userMissions[m.id].progress) {
              userMissions[m.id].progress = { dailyMissionsCompleted: Number(userMissions[m.id].progress) || 0 };
            }
            const currentCount = userMissions[m.id].progress.dailyMissionsCompleted || 0;
            userMissions[m.id].progress.dailyMissionsCompleted = currentCount + 1;
            console.log(`[MISSIONS] ✅ Incrementado contador daily en misión ${m.id}: ${userMissions[m.id].progress.dailyMissionsCompleted}`);
          }
        }
        console.log('[MISSIONS] Paso 2: Misiones normales procesadas');
      } catch (error) {
        console.error('[MISSIONS] ❌ Error en misiones normales:', error);
      }
      
      // Incrementar contador en misiones de EVOLUCIÓN de tipo complete_daily_missions
      console.log('[MISSIONS] Paso 3: Iniciando proceso de evoluciones...');
      try {
        // Cargar evoluciones si no están disponibles
        if (typeof availableEvolutions === 'undefined' || availableEvolutions.length === 0) {
          console.log('[EVOLUTIONS] Cargando evoluciones para verificar misiones...');
          await loadEvolutions();
        }
        
        // Cargar estado de evoluciones del usuario si no está disponible
        if (typeof userEvolutions === 'undefined' || !userEvolutions) {
          console.log('[EVOLUTIONS] Cargando estado de evoluciones del usuario...');
          await loadUserEvolutionsState();
        }
        
        if (typeof userEvolutions !== 'undefined' && typeof availableEvolutions !== 'undefined' && availableEvolutions.length > 0) {
          console.log('[EVOLUTIONS] Buscando evoluciones activas...');
          console.log('[EVOLUTIONS] Total evoluciones disponibles:', availableEvolutions.length);
        
        for (const evolution of availableEvolutions) {
          console.log(`[EVOLUTIONS] Verificando evolución ${evolution.id}...`);
          const evoProgress = userEvolutions[evolution.id];
          
          if (!evoProgress) {
            console.log(`[EVOLUTIONS] ❌ No hay progreso para ${evolution.id}`);
            continue;
          }
          if (!evoProgress.started) {
            console.log(`[EVOLUTIONS] ❌ ${evolution.id} no está iniciada`);
            continue;
          }
          if (evoProgress.claimedAt) {
            console.log(`[EVOLUTIONS] ❌ ${evolution.id} ya fue reclamada`);
            continue;
          }
          
          console.log(`[EVOLUTIONS] ✅ ${evolution.id} está activa, buscando misiones...`);
          
          for (const mission of evolution.missions) {
            console.log(`[EVOLUTIONS] Misión ${mission.id} - tipo: ${mission.type}`);
            if (mission.type === 'complete_daily_missions') {
              if (!evoProgress.dailyMissionsCount) evoProgress.dailyMissionsCount = 0;
              evoProgress.dailyMissionsCount++;
              console.log(`[EVOLUTIONS] ✅ Incrementado contador daily en ${evolution.id}.${mission.id}: ${evoProgress.dailyMissionsCount}`);
            }
          }
        }
        // Guardar progreso de evoluciones
        console.log('[EVOLUTIONS] Guardando progreso...');
        await saveUserEvolutionsState();
        console.log('[EVOLUTIONS] ✅ Progreso guardado');
        } else {
          console.log('[EVOLUTIONS] ❌ userEvolutions o availableEvolutions no están definidos');
        }
      } catch (error) {
        console.error('[EVOLUTIONS] ❌ Error al incrementar contador:', error);
      }
    } else {
      console.log('[MISSIONS] No es misión diaria, categoría:', mission.category);
    }
    
    // Actualizar estado de la misión
    const now = Date.now();
    let claimedCycle = null;
    if (mission.category === 'daily') {
      claimedCycle = getDailyCycleKey(now);
    } else if (mission.category === 'weekly') {
      claimedCycle = getWeeklyCycleKey(now);
    }

    userMissions[missionId] = {
      ...userMission,
      claimedAt: now,
      claimedCycle: claimedCycle,
      completed: true
    };

    if (typeof window.recordEvolutionMissionCompleted === 'function') {
      try {
        window.recordEvolutionMissionCompleted(missionId);
      } catch (evoMissionErr) {
        console.warn('[EVOLUTIONS] Error notificando misión completada:', evoMissionErr);
      }
    }
    
    // Si es repetible con cooldown estándar (no diaria ni semanal, que se rigen por ciclo 06:00 AM)
    if (mission.repeatable && mission.category !== 'daily' && mission.category !== 'weekly') {
      userMissions[missionId].completed = false;
      userMissions[missionId].needsReset = true;
      userMissions[missionId].progressValue = 0;
      const reqs = getMissionRequirements(mission);
      if (reqs.some(r => r.type === 'complete_daily_missions')) {
        userMissions[missionId].progress = { dailyMissionsCompleted: 0 };
      } else {
        userMissions[missionId].progress = 0;
      }
      // No borrar initialProgress aquí, se actualizará en el próximo render
    }
    
    // Verificar progreso de evoluciones
    if (typeof checkEvolutionMissions === 'function') {
      setTimeout(() => checkEvolutionMissions(true), 500);
    }

    // ✅ Mostrar HUD de recompensas INMEDIATAMENTE usando datos síncronos ya disponibles
    const hudItemsInstant = claimedRewards.map(reward => {
      const info = getRewardDisplayInfo(reward);
      const normType = normalizeRewardType(reward);
      return {
        ...reward,
        type: normType,
        name: info.name || String(reward?.name || 'Recompensa'),
        cleanName: info.cleanName || info.name,
        imageUrl: info.imageUrl || reward.imageUrl || '',
        gradient: info.gradient || reward.gradient || '',
        titleId: info.titleId || reward.titleId || reward.id,
        cardId: info.cardId || reward.cardId || reward.id,
        amount: info.amount || reward.amount || 1
      };
    });
    showRewardsClaimHUD(hudItemsInstant, 'RECOMPENSAS RECLAMADAS');

    // ⚡ Actualizar saldos (monedas, KvR, traits), inventario de sobres y colección en vivo
    Promise.all([
      typeof renderWallet === 'function' ? renderWallet() : Promise.resolve(),
      typeof renderOwnedPacks === 'function' ? renderOwnedPacks() : Promise.resolve(),
      typeof renderCollection === 'function' ? renderCollection() : Promise.resolve(),
      typeof updateProfileDisplay === 'function' ? updateProfileDisplay() : Promise.resolve(),
      typeof updateTitleSelector === 'function' ? updateTitleSelector() : Promise.resolve(),
      typeof updateMissionsProgress === 'function' ? updateMissionsProgress() : Promise.resolve()
    ]).catch(e => console.warn('[MISSIONS] Error refrescando interfaces tras reclamar:', e));

    // Guardar y re-renderizar en segundo plano sin bloquear el HUD
    saveUserMissionsState().catch(e => console.warn('[MISSIONS] Error guardando estado:', e));
    renderMissions().catch(e => console.warn('[MISSIONS] Error re-renderizando misiones:', e));
    if (typeof window.updateGlobalNotificationBadges === 'function') {
      window.updateGlobalNotificationBadges();
    }

  } catch (error) {
    console.error('[MISSIONS] Error al reclamar recompensa:', error);
    if (btn) {
      btn.disabled = false;
      btn.style.opacity = '1';
      btn.style.pointerEvents = 'auto';
      btn.textContent = '🎁 Reclamar';
    }
    alert('❌ Error al reclamar la recompensa');
  } finally {
    activeMissionClaims.delete(missionId);
  }
}

// Refrescar misiones desde remoto
async function refreshMissions() {
  // Borrar caché y recargar
  localStorage.removeItem(MISSIONS_CACHE_KEY);
  await loadMissions();
  await renderMissions();
  alert('✅ Misiones actualizadas');
}

// ============================================
// SISTEMA DE KIZUNAS
// ============================================

// Cargar Kizunas desde GitHub o caché local instantáneo
async function loadKizunas() {
  console.log('[KIZUNAS] Cargando kizunas...');
  
  // 1. Cargar caché inmediatamente
  const cachedKizunas = localStorage.getItem(KIZUNAS_CACHE_KEY);
  if (cachedKizunas) {
    try {
      const parsed = JSON.parse(cachedKizunas);
      if (Array.isArray(parsed) && parsed.length > 0) {
        availableKizunas = parsed;
        console.log('[KIZUNAS] ✅ Kizunas cargados desde caché:', availableKizunas.length);
      }
    } catch (e) {
      console.warn('[KIZUNAS] Error leyendo caché de kizunas:', e);
    }
  }
  
  // 2. Fetch remoto con timeout de 3 segundos
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3000);
    const response = await fetch(KIZUNAS_REMOTE_URL + '?t=' + Date.now(), { signal: controller.signal });
    clearTimeout(timeoutId);
    
    if (response.ok) {
      const data = await response.json();
      if (Array.isArray(data) && data.length > 0) {
        availableKizunas = data;
        localStorage.setItem(KIZUNAS_CACHE_KEY, JSON.stringify(data));
        localStorage.setItem(KIZUNAS_CACHE_TIME_KEY, Date.now().toString());
        console.log('[KIZUNAS] ✅ Kizunas actualizados desde GitHub:', availableKizunas.length);
        return;
      }
    }
  } catch (error) {
    console.warn('[KIZUNAS] ⚠️ No se pudo conectar con GitHub, usando datos locales/caché:', error?.message || error);
  }
  
  // 3. Fallback si availableKizunas sigue vacío
  if (availableKizunas.length === 0) {
    try {
      const fallback = await fetch('seeds/kizunas.json');
      if (fallback.ok) {
        availableKizunas = await fallback.json();
        console.log('[KIZUNAS] ✅ Kizunas cargados desde seeds locales:', availableKizunas.length);
      }
    } catch {}
  }
}

// Cargar estado de Kizunas del usuario aislado por cuenta
function getKizunasStorageKey() {
  try { localStorage.removeItem('kvr_user_kizunas'); } catch {} // Eliminar clave legacy compartida
  const user = (typeof currentUser === 'string' && currentUser.trim()) 
    ? currentUser.trim().toLowerCase() 
    : (localStorage.getItem('kvrUsername') || '').trim().toLowerCase();
  return user ? `kvr_user_kizunas_${user}` : null;
}

async function loadUserKizunasState() {
  try { localStorage.removeItem('kvr_user_kizunas'); } catch {}
  const user = (typeof currentUser === 'string' && currentUser.trim()) 
    ? currentUser.trim() 
    : (localStorage.getItem('kvrUsername') || '').trim();
  
  if (!user) {
    userKizunas = {};
    return userKizunas;
  }

  // 1. Intentar cargar desde backend Electron (aislamiento total por cuenta)
  if (window.kvrcards && typeof window.kvrcards.getKizunasState === 'function') {
    try {
      const result = await window.kvrcards.getKizunasState();
      if (result && result.ok && result.kizunas && typeof result.kizunas === 'object') {
        const backendKizunas = result.kizunas;
        const backendHasData = Object.keys(backendKizunas).length > 0;
        
        if (backendHasData) {
          userKizunas = { ...backendKizunas };
          const key = getKizunasStorageKey();
          if (key) {
            try { localStorage.setItem(key, JSON.stringify(userKizunas)); } catch {}
          }
          console.log('[KIZUNAS] Estado cargado desde backend para:', user, 'Total reclamados:', Object.keys(userKizunas).length);
          return userKizunas;
        }

        // Si el backend aún no tiene datos para este usuario, verificar si hay datos locales de este usuario específico
        const key = getKizunasStorageKey();
        if (key) {
          const saved = localStorage.getItem(key);
          if (saved) {
            try {
              const parsed = JSON.parse(saved);
              if (parsed && typeof parsed === 'object' && Object.keys(parsed).length > 0) {
                userKizunas = { ...parsed };
                if (window.kvrcards && typeof window.kvrcards.saveKizunasState === 'function') {
                  window.kvrcards.saveKizunasState(userKizunas).catch(() => {});
                }
                return userKizunas;
              }
            } catch (e) {}
          }
        }

        userKizunas = {};
        return userKizunas;
      }
    } catch (error) {
      console.warn('[KIZUNAS] Error al cargar estado desde backend:', error);
      userKizunas = {};
    }
  }

  // 2. Fallback a localStorage con clave por usuario (NUNCA usar clave global sin usuario)
  const key = getKizunasStorageKey();
  if (key) {
    const saved = localStorage.getItem(key);
    if (saved) {
      try {
        userKizunas = JSON.parse(saved);
        return userKizunas;
      } catch (error) {
        console.error('[KIZUNAS] Error al parsear estado local:', error);
      }
    }
  }

  userKizunas = {};
  return userKizunas;
}

// Guardar estado de Kizunas del usuario
async function saveUserKizunasState() {
  const key = getKizunasStorageKey();
  if (key) {
    try {
      localStorage.setItem(key, JSON.stringify(userKizunas || {}));
    } catch {}
  }
  if (window.kvrcards && typeof window.kvrcards.saveKizunasState === 'function') {
    try {
      await window.kvrcards.saveKizunasState(userKizunas || {});
    } catch (e) {
      console.warn('[KIZUNAS] Error al persistir estado en backend:', e);
    }
  }
}

// Verificar si un Kizuna está completo
async function checkKizunaComplete(kizuna) {
  try {
    const inv = await window.kvrcards.getInventory();
    if (!inv.ok) return false;
    
    // Verificar que el usuario tenga todas las cartas requeridas
    for (const cardId of kizuna.cardIds) {
      if (!inv.cards[cardId] || inv.cards[cardId] <= 0) {
        return false;
      }
    }
    
    return true;
  } catch (error) {
    console.error('[KIZUNAS] Error al verificar kizuna:', error);
    return false;
  }
}

// ==================== FILTROS Y BÚSQUEDA DE KIZUNAS ====================
let kizunaSearchGroupText = '';
let kizunaSearchCardText = '';
let kizunaFilter1 = { type: 'none', value: null };
let kizunaFilter2 = { type: 'none', value: null };
let kizunaRewardFilter = 'none'; // 'none' | 'buff' | 'title'
let kizunaFiltersInitialized = false;

function checkCardMatchesKizunaFilter(card, filterObj) {
  if (!filterObj || filterObj.type === 'none') return true;
  if (!card) return false;

  if (filterObj.type === 'quality') {
    if (String(filterObj.value).toLowerCase() === 'especiales') {
      return typeof isCardSpecialQuality === 'function'
        ? isCardSpecialQuality(card)
        : (typeof isSpecialQuality === 'function' ? isSpecialQuality(card.quality || card.calidad || card.calidadId) : false);
    }
    const cardQ = (card.quality || card.calidad || card.calidadId || '').toLowerCase().trim();
    const targetQ = String(filterObj.value || '').toLowerCase().trim();
    const normalize = (s) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    return normalize(cardQ) === normalize(targetQ);
  }

  if (filterObj.type === 'media') {
    const cardMedia = Number(card.media) || 0;
    const targetMedia = Number(filterObj.value) || 0;
    return cardMedia >= targetMedia;
  }

  if (filterObj.type === 'procedencia') {
    const cardProc = (card.procedencia || '').toLowerCase().trim();
    const targetProc = String(filterObj.value || '').toLowerCase().trim();
    return cardProc === targetProc;
  }

  if (filterObj.type === 'owner') {
    const cardOwner = (card.owner || '').toLowerCase().trim();
    const targetOwner = String(filterObj.value || '').toLowerCase().trim();
    return cardOwner === targetOwner;
  }

  return true;
}

function checkKizunaMatchesFilters(kizuna, allCards) {
  const kizunaCards = (kizuna.cardIds || []).map(cardId => {
    const baseId = String(cardId).replace(/_notrait.*$/, '').trim();
    return Array.isArray(allCards) ? (allCards.find(c => c.id === cardId || c.id === baseId) || { id: cardId, name: cardId }) : { id: cardId, name: cardId };
  });

  // 1. Buscador por carta
  if (kizunaSearchCardText) {
    const cardQuery = kizunaSearchCardText.toLowerCase().trim();
    const matchesCard = kizunaCards.some(c => {
      const idMatch = c.id && String(c.id).toLowerCase().includes(cardQuery);
      const nameMatch = c.name && String(c.name).toLowerCase().includes(cardQuery);
      return idMatch || nameMatch;
    });
    if (!matchesCard) return false;
  }

  // 2. Filtro 1 (Calidad, Media, Procedencia, Owner)
  if (kizunaFilter1.type !== 'none') {
    const matchesF1 = kizunaCards.some(c => checkCardMatchesKizunaFilter(c, kizunaFilter1));
    if (!matchesF1) return false;
  }

  // 3. Filtro 2 (Calidad, Media, Procedencia, Owner)
  if (kizunaFilter2.type !== 'none') {
    const matchesF2 = kizunaCards.some(c => checkCardMatchesKizunaFilter(c, kizunaFilter2));
    if (!matchesF2) return false;
  }

  // 4. Filtro Especial de Recompensa
  if (kizunaRewardFilter === 'buff') {
    const hasBuff = (kizuna.rewards || []).some(r => String(r.type || '').toLowerCase() === 'buff');
    if (!hasBuff) return false;
  } else if (kizunaRewardFilter === 'title') {
    const hasTitle = (kizuna.rewards || []).some(r => String(r.type || '').toLowerCase() === 'title');
    if (!hasTitle) return false;
  }

  return true;
}

function updateKizunaFilter1ButtonText() {
  const btn = document.getElementById('kizuna-filter-1-btn');
  if (!btn) return;
  if (kizunaFilter1.type === 'none') {
    btn.textContent = 'Filtro: ---- ▼';
  } else if (kizunaFilter1.type === 'quality') {
    btn.textContent = `Filtro: ${kizunaFilter1.value} ▼`;
  } else if (kizunaFilter1.type === 'media') {
    btn.textContent = `Filtro: Media ≥ ${kizunaFilter1.value} ▼`;
  } else if (kizunaFilter1.type === 'procedencia') {
    btn.textContent = `Filtro: ${kizunaFilter1.value} ▼`;
  } else if (kizunaFilter1.type === 'owner') {
    btn.textContent = `Filtro: ${kizunaFilter1.value} ▼`;
  }
}

function updateKizunaFilter2ButtonText() {
  const btn = document.getElementById('kizuna-filter-2-btn');
  if (!btn) return;
  if (kizunaFilter2.type === 'none') {
    btn.textContent = 'Filtro 2: ---- ▼';
  } else if (kizunaFilter2.type === 'quality') {
    btn.textContent = `Filtro 2: ${kizunaFilter2.value} ▼`;
  } else if (kizunaFilter2.type === 'media') {
    btn.textContent = `Filtro 2: Media ≥ ${kizunaFilter2.value} ▼`;
  } else if (kizunaFilter2.type === 'procedencia') {
    btn.textContent = `Filtro 2: ${kizunaFilter2.value} ▼`;
  } else if (kizunaFilter2.type === 'owner') {
    btn.textContent = `Filtro 2: ${kizunaFilter2.value} ▼`;
  }
}

function updateKizunaRewardFilterButtonText() {
  const btn = document.getElementById('kizuna-filter-reward-btn');
  if (!btn) return;
  if (kizunaRewardFilter === 'none') {
    btn.textContent = 'Recompensa: ---- ▼';
  } else if (kizunaRewardFilter === 'buff') {
    btn.textContent = 'Recompensa: Contiene buff ▼';
  } else if (kizunaRewardFilter === 'title') {
    btn.textContent = 'Recompensa: Contiene título ▼';
  }
}

function populateKizunaFilterOptions(containerId, isFilter2, allCards) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = '';

  const dynamicQualities = (window.dynamicFilterQualities && Array.isArray(window.dynamicFilterQualities) && window.dynamicFilterQualities.length > 0)
    ? window.dynamicFilterQualities
    : ['Bronce', 'Plata', 'Oro', 'Especiales', 'Icono', 'Heroe', 'Icono Prime', 'Icono Super Prime', 'Evo'];
  
  const procedencias = Array.from(new Set((allCards || []).map(c => c.procedencia).filter(Boolean))).sort((a, b) => a.localeCompare(b));
  const owners = Array.from(new Set((allCards || []).map(c => c.owner).filter(Boolean))).sort((a, b) => a.localeCompare(b));

  // 1. Opción "----" (Resetear)
  const noneOption = document.createElement('div');
  noneOption.className = 'filter-option';
  noneOption.textContent = '----';
  noneOption.addEventListener('click', (e) => {
    e.stopPropagation();
    if (isFilter2) {
      kizunaFilter2 = { type: 'none', value: null };
      updateKizunaFilter2ButtonText();
    } else {
      kizunaFilter1 = { type: 'none', value: null };
      updateKizunaFilter1ButtonText();
    }
    container.classList.remove('show');
    renderKizunas();
  });
  container.appendChild(noneOption);

  // 2. Calidad ▶
  const qualityOption = document.createElement('div');
  qualityOption.className = 'filter-option submenu-trigger';
  qualityOption.innerHTML = 'Calidad ▶';
  const qualitySubmenu = document.createElement('div');
  qualitySubmenu.className = 'submenu';
  dynamicQualities.forEach(q => {
    const opt = document.createElement('div');
    opt.className = 'submenu-option';
    opt.textContent = q === 'Heroe' ? 'Héroe' : q;
    opt.addEventListener('click', (e) => {
      e.stopPropagation();
      const val = q === 'Heroe' ? 'Héroe' : q;
      if (isFilter2) {
        kizunaFilter2 = { type: 'quality', value: val };
        updateKizunaFilter2ButtonText();
      } else {
        kizunaFilter1 = { type: 'quality', value: val };
        updateKizunaFilter1ButtonText();
      }
      container.classList.remove('show');
      renderKizunas();
    });
    qualitySubmenu.appendChild(opt);
  });
  qualityOption.appendChild(qualitySubmenu);
  container.appendChild(qualityOption);

  // 3. Media ▶
  const mediaOption = document.createElement('div');
  mediaOption.className = 'filter-option submenu-trigger';
  mediaOption.innerHTML = 'Media ▶';
  const mediaSubmenu = document.createElement('div');
  mediaSubmenu.className = 'submenu';
  const mediaInputDiv = document.createElement('div');
  mediaInputDiv.className = 'submenu-input';
  
  const input = document.createElement('input');
  input.type = 'number';
  input.placeholder = 'Ej: 85';
  input.min = '0';
  input.max = '100';
  input.style.width = '70px';
  input.style.padding = '4px 6px';
  input.style.background = '#111827';
  input.style.color = '#fff';
  input.style.border = '1px solid #374151';
  input.style.borderRadius = '4px';

  const applyBtn = document.createElement('button');
  applyBtn.textContent = 'Aplicar';
  applyBtn.style.background = '#10b981';
  applyBtn.style.color = '#fff';
  applyBtn.style.border = 'none';
  applyBtn.style.borderRadius = '4px';
  applyBtn.style.padding = '4px 8px';
  applyBtn.style.cursor = 'pointer';
  applyBtn.style.fontWeight = 'bold';

  const handleMediaApply = (e) => {
    e.stopPropagation();
    const mediaVal = parseInt(input.value);
    if (isNaN(mediaVal) || mediaVal < 0) {
      alert('Introduce un número válido para la media');
      return;
    }
    if (isFilter2) {
      kizunaFilter2 = { type: 'media', value: mediaVal };
      updateKizunaFilter2ButtonText();
    } else {
      kizunaFilter1 = { type: 'media', value: mediaVal };
      updateKizunaFilter1ButtonText();
    }
    container.classList.remove('show');
    renderKizunas();
  };
  applyBtn.addEventListener('click', handleMediaApply);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleMediaApply(e);
  });
  input.addEventListener('click', (e) => e.stopPropagation());

  mediaInputDiv.appendChild(input);
  mediaInputDiv.appendChild(applyBtn);
  mediaSubmenu.appendChild(mediaInputDiv);
  mediaOption.appendChild(mediaSubmenu);
  container.appendChild(mediaOption);

  // 4. Procedencia ▶
  const procOption = document.createElement('div');
  procOption.className = 'filter-option submenu-trigger';
  procOption.innerHTML = 'Procedencia ▶';
  const procSubmenu = document.createElement('div');
  procSubmenu.className = 'submenu';
  if (procedencias.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'submenu-option';
    empty.textContent = 'Sin procedencias';
    procSubmenu.appendChild(empty);
  } else {
    procedencias.forEach(p => {
      const opt = document.createElement('div');
      opt.className = 'submenu-option';
      opt.textContent = p;
      opt.addEventListener('click', (e) => {
        e.stopPropagation();
        if (isFilter2) {
          kizunaFilter2 = { type: 'procedencia', value: p };
          updateKizunaFilter2ButtonText();
        } else {
          kizunaFilter1 = { type: 'procedencia', value: p };
          updateKizunaFilter1ButtonText();
        }
        container.classList.remove('show');
        renderKizunas();
      });
      procSubmenu.appendChild(opt);
    });
  }
  procOption.appendChild(procSubmenu);
  container.appendChild(procOption);

  // 5. Owner ▶
  const ownerOption = document.createElement('div');
  ownerOption.className = 'filter-option submenu-trigger';
  ownerOption.innerHTML = 'Owner ▶';
  const ownerSubmenu = document.createElement('div');
  ownerSubmenu.className = 'submenu';
  if (owners.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'submenu-option';
    empty.textContent = 'Sin owners';
    ownerSubmenu.appendChild(empty);
  } else {
    owners.forEach(o => {
      const opt = document.createElement('div');
      opt.className = 'submenu-option';
      opt.textContent = o;
      opt.addEventListener('click', (e) => {
        e.stopPropagation();
        if (isFilter2) {
          kizunaFilter2 = { type: 'owner', value: o };
          updateKizunaFilter2ButtonText();
        } else {
          kizunaFilter1 = { type: 'owner', value: o };
          updateKizunaFilter1ButtonText();
        }
        container.classList.remove('show');
        renderKizunas();
      });
      ownerSubmenu.appendChild(opt);
    });
  }
  ownerOption.appendChild(ownerSubmenu);
  container.appendChild(ownerOption);
}

function populateKizunaRewardFilterOptions() {
  const container = document.getElementById('kizuna-filter-reward-options');
  if (!container) return;
  container.innerHTML = '';

  const options = [
    { label: '----', value: 'none' },
    { label: 'Contiene buff', value: 'buff' },
    { label: 'Contiene título', value: 'title' }
  ];

  options.forEach(opt => {
    const el = document.createElement('div');
    el.className = 'filter-option';
    el.textContent = opt.label;
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      kizunaRewardFilter = opt.value;
      updateKizunaRewardFilterButtonText();
      container.classList.remove('show');
      renderKizunas();
    });
    container.appendChild(el);
  });
}

function initKizunaFilters(allCards) {
  const searchGroupInput = document.getElementById('kizuna-search-group');
  const searchCardInput = document.getElementById('kizuna-search-card');
  const f1Btn = document.getElementById('kizuna-filter-1-btn');
  const f1Options = document.getElementById('kizuna-filter-1-options');
  const f2Btn = document.getElementById('kizuna-filter-2-btn');
  const f2Options = document.getElementById('kizuna-filter-2-options');
  const rewBtn = document.getElementById('kizuna-filter-reward-btn');
  const rewOptions = document.getElementById('kizuna-filter-reward-options');

  if (!f1Btn || !f2Btn || !rewBtn) return;

  populateKizunaFilterOptions('kizuna-filter-1-options', false, allCards);
  populateKizunaFilterOptions('kizuna-filter-2-options', true, allCards);
  populateKizunaRewardFilterOptions();

  if (kizunaFiltersInitialized) return;
  kizunaFiltersInitialized = true;

  // Buscador por grupo
  searchGroupInput?.addEventListener('input', (e) => {
    kizunaSearchGroupText = e.target.value.trim().toLowerCase();
    renderKizunas();
  });

  // Buscador por carta
  searchCardInput?.addEventListener('input', (e) => {
    kizunaSearchCardText = e.target.value.trim().toLowerCase();
    renderKizunas();
  });

  // Toggle Dropdowns
  f1Btn.addEventListener('click', (e) => {
    e.stopPropagation();
    f2Options?.classList.remove('show');
    rewOptions?.classList.remove('show');
    f1Options?.classList.toggle('show');
  });

  f2Btn.addEventListener('click', (e) => {
    e.stopPropagation();
    f1Options?.classList.remove('show');
    rewOptions?.classList.remove('show');
    f2Options?.classList.toggle('show');
  });

  rewBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    f1Options?.classList.remove('show');
    f2Options?.classList.remove('show');
    rewOptions?.classList.toggle('show');
  });

  document.addEventListener('click', (e) => {
    if (!f1Btn.contains(e.target) && !f1Options?.contains(e.target)) {
      f1Options?.classList.remove('show');
    }
    if (!f2Btn.contains(e.target) && !f2Options?.contains(e.target)) {
      f2Options?.classList.remove('show');
    }
    if (!rewBtn.contains(e.target) && !rewOptions?.contains(e.target)) {
      rewOptions?.classList.remove('show');
    }
  });
}

// Variable para evitar renderizados concurrentes de kizunas
let isRenderingKizunas = false;

// Seguimiento de grupos abiertos para mantener el estado desplegado
const openKizunaGroups = new Set();

// Renderizar Kizunas agrupados por categorías dinámicas
async function renderKizunas() {
  if (!kizunasContainer) return;
  
  if (isRenderingKizunas) {
    console.log('[KIZUNAS] Renderizado ya en progreso, saltando...');
    return;
  }
  isRenderingKizunas = true;
  
  try {
    if (availableKizunas.length === 0) {
      const cached = localStorage.getItem(KIZUNAS_CACHE_KEY);
      if (cached) {
        try {
          const parsed = JSON.parse(cached);
          if (Array.isArray(parsed) && parsed.length > 0) {
            availableKizunas = parsed;
          }
        } catch {}
      }
      
      if (availableKizunas.length === 0) {
        kizunasContainer.innerHTML = '<p class="missions-loading">Cargando kizunas...</p>';
        await loadKizunas();
        
        if (availableKizunas.length === 0) {
          kizunasContainer.innerHTML = '<p class="missions-empty">No hay kizunas disponibles</p>';
          return;
        }
      }
    }
    
    await loadUserKizunasState();
    kizunasContainer.innerHTML = '';
    
    await ensureMissionCatalogCache();
    const [inv, allCards] = await Promise.all([
      window.kvrcards.getInventory().catch(() => ({ ok: false })),
      (Array.isArray(missionCatalogCache.cards) && missionCatalogCache.cards.length > 0) ? Promise.resolve(missionCatalogCache.cards) : window.kvrcards.getAllCards().catch(() => [])
    ]);

    // Inicializar o actualizar opciones de filtros de Kizunas
    initKizunaFilters(allCards);
    
    // Deduplicar kizunas por ID
    const uniqueKizunas = [];
    const seenIds = new Set();
    for (const k of availableKizunas) {
      if (k && k.id && !seenIds.has(k.id)) {
        seenIds.add(k.id);
        uniqueKizunas.push(k);
      }
    }
    
    // 1. Agrupar kizunas dinámicamente según su propiedad "group"
    const groupsMap = new Map();
    for (const kizuna of uniqueKizunas) {
      let rawGroup = kizuna.group && String(kizuna.group).trim();
      if (!rawGroup || rawGroup.toLowerCase() === 'general') {
        rawGroup = 'Sin grupo';
      }
      if (!groupsMap.has(rawGroup)) {
        groupsMap.set(rawGroup, []);
      }
      groupsMap.get(rawGroup).push(kizuna);
    }
    
    let renderedGroupsCount = 0;

    // 2. Renderizar cada grupo con su cabecera desplegable y contador X/Y
    for (const [groupName, groupKizunas] of groupsMap.entries()) {
      // Filtrar por nombre de grupo si se ha introducido búsqueda por grupo
      if (kizunaSearchGroupText) {
        if (!groupName.toLowerCase().includes(kizunaSearchGroupText)) {
          continue;
        }
      }

      // Filtrar kizunas de este grupo que coincidan con los filtros activos (carta, calidad, media, procedencia, owner, recompensa)
      const matchingKizunas = groupKizunas.filter(k => checkKizunaMatchesFilters(k, allCards));

      // Si ningún kizuna de este grupo coincide, ocultar el grupo
      if (matchingKizunas.length === 0) {
        continue;
      }

      renderedGroupsCount++;

      let activeCount = 0;
      let claimableCount = 0;
      const cardsElements = [];
      
      for (const kizuna of matchingKizunas) {
        // Comprobar si el usuario tiene todas las cartas requeridas
        let isComplete = true;
        if (inv.ok && inv.cards) {
          for (const cardId of (kizuna.cardIds || [])) {
            if (!inv.cards[cardId] || inv.cards[cardId] <= 0) {
              isComplete = false;
              break;
            }
          }
        } else {
          isComplete = false;
        }
        
        const userKizuna = userKizunas[kizuna.id] || {};
        const hasClaimedReward = userKizuna.claimed || false;
        const canClaim = isComplete && !hasClaimedReward;
        const isActive = isComplete || hasClaimedReward;
        if (isActive) {
          activeCount++;
        }
        if (canClaim) {
          claimableCount++;
        }
        
        const kizunaCard = document.createElement('div');
        kizunaCard.className = 'kizuna-card';
        if (hasClaimedReward) kizunaCard.classList.add('claimed');
        if (isComplete && !hasClaimedReward) kizunaCard.classList.add('complete');
        
        // Crear HTML de las cartas requeridas
        const cardsHTML = (kizuna.cardIds || []).map(cardId => {
          const hasCard = inv.ok && inv.cards && inv.cards[cardId] && inv.cards[cardId] > 0;
          const cardData = Array.isArray(allCards) ? (allCards.find(c => c.id === cardId) || { name: cardId, imageUrl: '' }) : { name: cardId, imageUrl: '' };
          const cardClass = hasCard ? 'owned' : 'missing';
          
          const fallbackPlaceholder = 'data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22140%22><rect width=%22100%25%22 height=%22100%25%22 fill=%22%231f2937%22/><text x=%2250%25%22 y=%2250%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%239ca3af%22 font-family=%22Arial%22 font-size=%2214%22>?</text></svg>';
          const imageUrl = cardData.imageUrl ? 
            (cardData.imageUrl.startsWith('http') ? cardData.imageUrl : `cards/${cardData.imageUrl}`) : 
            fallbackPlaceholder;
          
          return `<div class="kizuna-card-slot ${cardClass}">
            <img src="${imageUrl}" alt="${cardData.name}" class="kizuna-card-img" onerror="this.onerror=null; this.src='${fallbackPlaceholder}';">
            <p class="kizuna-card-name">${cardData.name}</p>
          </div>`;
        }).join('');
        
        // Crear rewards HTML con nombres reales y cantidades dinámicas
        const rewardsHTML = (kizuna.rewards || []).map(reward => {
          const info = getRewardDisplayInfo(reward);
          const attrs = [];
          if (info.description) attrs.push(`data-title-desc="${escapeHtml(info.description)}"`);
          if (info.name) attrs.push(`data-title-name="${escapeHtml(info.name)}"`);
          if (info.gradient) attrs.push(`data-title-gradient="${escapeHtml(info.gradient)}"`);
          if (info.titleId) attrs.push(`data-title-id="${escapeHtml(info.titleId)}"`);
          if (info.type) attrs.push(`data-reward-type="${escapeHtml(info.type)}"`);
          return `<span class="kizuna-reward-item ${info.className}" ${attrs.join(' ')}>${info.text}</span>`;
        }).join('');
        
        kizunaCard.innerHTML = `
          <div class="kizuna-header">
            <h3 class="kizuna-title">${kizuna.title}</h3>
            ${hasClaimedReward ? '<span class="kizuna-checkmark">✅</span>' : ''}
          </div>
          <p class="kizuna-description">${kizuna.description}</p>
          
          <div class="kizuna-cards-container">
            ${cardsHTML}
          </div>
          
          <div class="kizuna-rewards">
            <strong>Recompensa:</strong>
            <div class="kizuna-rewards-list">
              ${rewardsHTML}
            </div>
          </div>
          
          <div class="kizuna-status">
            ${isComplete ? '<p class="kizuna-claimed-text">✅ Kizuna Activo</p>' : '<p class="kizuna-incomplete-text">❌ Kizuna Inactivo</p>'}
            ${hasClaimedReward ? '<p class="kizuna-claimed-text" style="margin-top: 5px;">🎁 Recompensa reclamada</p>' : ''}
          </div>
          
          <button 
            class="kizuna-claim-btn" 
            data-kizuna-id="${kizuna.id}"
            ${!canClaim ? 'disabled' : ''}
          >
            ${hasClaimedReward ? 'Reclamada' : canClaim ? '🎁 Reclamar' : 'Incompleto'}
          </button>
        `;
        
        cardsElements.push(kizunaCard);
      }
      
      const totalCount = matchingKizunas.length;
      const isGroupOpen = openKizunaGroups.has(groupName);
      const counterClass = activeCount === totalCount ? 'completed' : (activeCount > 0 ? 'partial' : '');
      
      const groupEl = document.createElement('div');
      groupEl.className = `kizuna-group ${isGroupOpen ? 'is-open' : ''}`;
      groupEl.setAttribute('data-group-name', groupName);
      
      const claimableBadgeHTML = claimableCount > 0
        ? `<span class="kizuna-group-notif notif-badge" title="${claimableCount} kizuna${claimableCount > 1 ? 's' : ''} por reclamar">${claimableCount > 99 ? '99+' : claimableCount}</span>`
        : '';

      groupEl.innerHTML = `
        <div class="kizuna-group-header">
          <div class="kizuna-group-title-wrap">
            <h3 class="kizuna-group-title">${escapeHtml(groupName)}</h3>
          </div>
          <div class="kizuna-group-meta">
            ${claimableBadgeHTML}
            <span class="kizuna-group-counter ${counterClass}">
              ${activeCount}/${totalCount}
            </span>
            <span class="kizuna-group-arrow">▼</span>
          </div>
        </div>
        <div class="kizuna-group-body"></div>
      `;
      
      const groupBody = groupEl.querySelector('.kizuna-group-body');
      cardsElements.forEach(cardEl => groupBody.appendChild(cardEl));
      
      const groupHeader = groupEl.querySelector('.kizuna-group-header');
      groupHeader.addEventListener('click', () => {
        const isOpen = groupEl.classList.toggle('is-open');
        if (isOpen) {
          openKizunaGroups.add(groupName);
        } else {
          openKizunaGroups.delete(groupName);
        }
      });
      
      kizunasContainer.appendChild(groupEl);
    }

    if (renderedGroupsCount === 0) {
      kizunasContainer.innerHTML = `
        <div class="kizuna-empty" style="text-align: center; padding: 40px; color: #9ca3af; font-size: 15px;">
          🔍 No se encontraron Kizunas con los filtros seleccionados
        </div>
      `;
    }
    
    // Event listeners para botones de reclamar
    const claimButtons = document.querySelectorAll('.kizuna-claim-btn:not([disabled])');
    claimButtons.forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const kizunaId = btn.getAttribute('data-kizuna-id');
        if (!kizunaId || activeKizunaClaims.has(kizunaId)) return;

        // Deshabilitar botón inmediatamente para feedback visual instantáneo y evitar spam
        btn.disabled = true;
        btn.style.opacity = '0.6';
        btn.style.pointerEvents = 'none';
        btn.textContent = '⏳ Reclamando...';

        await claimKizunaReward(kizunaId, btn);
      });
    });
  } finally {
    isRenderingKizunas = false;
  }
}

// Mutex para evitar reclamos concurrentes de Kizunas
const activeKizunaClaims = new Set();

// Reclamar recompensa de Kizuna
async function claimKizunaReward(kizunaId, btn = null) {
  if (!kizunaId || activeKizunaClaims.has(kizunaId)) {
    console.warn('[KIZUNAS] Reclamo ya en proceso o bloqueado para:', kizunaId);
    return;
  }

  await loadUserKizunasState();
  const userKizuna = userKizunas[kizunaId] || {};
  if (userKizuna.claimed) {
    if (btn) {
      btn.disabled = true;
      btn.style.opacity = '0.6';
      btn.textContent = 'Reclamada';
    }
    alert('❌ Ya has reclamado esta recompensa');
    return;
  }

  const kizuna = availableKizunas.find(k => k.id === kizunaId);
  if (!kizuna) {
    console.error('[KIZUNAS] Kizuna no encontrado:', kizunaId);
    if (btn) {
      btn.disabled = false;
      btn.style.opacity = '1';
      btn.style.pointerEvents = 'auto';
      btn.textContent = '🎁 Reclamar';
    }
    return;
  }

  // Activar bloqueo de concurrencia de inmediato
  activeKizunaClaims.add(kizunaId);

  try {
    const isComplete = await checkKizunaComplete(kizuna);
    if (!isComplete) {
      if (btn) {
        btn.disabled = false;
        btn.style.opacity = '1';
        btn.style.pointerEvents = 'auto';
        btn.textContent = '🎁 Reclamar';
      }
      alert('❌ Este Kizuna no está completo');
      return;
    }

    // ⚡ 1. MARCAR COMO RECLAMADO DE INMEDIATO EN EL ESTADO LOCAL Y GUARDAR
    // Esto garantiza que ningún click posterior o re-evaluación pueda duplicar recompensas
    userKizunas[kizunaId] = {
      ...userKizuna,
      claimed: true,
      claimedAt: Date.now()
    };
    await saveUserKizunasState();

    if (btn) {
      btn.disabled = true;
      btn.style.opacity = '0.6';
      btn.textContent = 'Reclamada';
    }

    console.log('[KIZUNAS] Reclamando kizuna:', kizunaId);

    // ⚡ 2. PREPARAR ITEMS Y MOSTRAR HUD DE RECOMPENSAS AL INSTANTE (cero delay)
    const rawRewards = Array.isArray(kizuna.rewards) ? kizuna.rewards : [];
    const hudItemsInstant = rawRewards.map(reward => {
      const info = getRewardDisplayInfo(reward);
      const normType = normalizeRewardType(reward);
      return {
        ...reward,
        type: normType,
        name: info.name || String(reward?.name || 'Recompensa'),
        cleanName: info.cleanName || info.name,
        imageUrl: info.imageUrl || reward.imageUrl || '',
        gradient: info.gradient || reward.gradient || '',
        titleId: info.titleId || reward.titleId || reward.id,
        cardId: info.cardId || reward.cardId || reward.id,
        amount: info.amount || reward.amount || 1
      };
    });
    showRewardsClaimHUD(hudItemsInstant, 'RECOMPENSAS RECLAMADAS');

    // ⚡ 3. OTORGAR RECOMPENSAS EN PARALELO (sin demoras secuenciales de IPC)
    const rewardPromises = [];
    let profileNeedsSave = false;

    for (const reward of rawRewards) {
      const type = normalizeRewardType(reward);
      switch (type) {
        case 'coins': {
          const coinsAmt = Number(reward.amount || reward.cantidad || reward.coins || 0) || 0;
          if (coinsAmt > 0 && window.kvrcards?.addCoins) {
            rewardPromises.push(
              window.kvrcards.addCoins(coinsAmt).catch(err => console.warn('[KIZUNAS] Error añadiendo monedas:', err))
            );
          }
          break;
        }
        case 'kvr': {
          const kvrAmt = Number(reward.amount || reward.cantidad || reward.kvr || 0) || 0;
          if (kvrAmt > 0 && window.kvrcards?.addKvR) {
            rewardPromises.push(
              window.kvrcards.addKvR(kvrAmt).catch(err => console.warn('[KIZUNAS] Error añadiendo KvR:', err))
            );
          }
          break;
        }
        case 'pack': {
          const packAmount = Number(reward.amount || reward.cantidad || reward.quantity || reward.count || 1) || 1;
          const packId = reward.packId || reward.id;
          if (packId && window.kvrcards?.addPack) {
            rewardPromises.push(
              window.kvrcards.addPack(packId, packAmount).catch(err => console.warn(`[KIZUNAS] Error añadiendo sobre ${packId}:`, err))
            );
          }
          break;
        }
        case 'title': {
          let tId = String(reward.titleId || reward.id || '').trim();
          let tName = '';
          if (typeof window.findTitleInCatalog === 'function') {
            const found = window.findTitleInCatalog(reward);
            if (found?.id) tId = found.id;
            if (found?.name) tName = found.name;
          }
          if (tId) {
            if (!userProfile.unlockedTitles || !Array.isArray(userProfile.unlockedTitles)) {
              userProfile.unlockedTitles = ['novato'];
            }
            if (!userProfile.unlockedTitles.includes(tId)) {
              userProfile.unlockedTitles.push(tId);
              profileNeedsSave = true;
            }
            if (tName && !userProfile.unlockedTitles.includes(tName)) {
              userProfile.unlockedTitles.push(tName);
              profileNeedsSave = true;
            }
          }
          break;
        }
        case 'card': {
          let cardId = reward.cardId || reward.id;
          if (typeof window.findCardInCatalog === 'function') {
            const found = window.findCardInCatalog(reward);
            if (found?.id) cardId = found.id;
          }
          if (cardId && window.kvrcards?.addCard) {
            rewardPromises.push(
              window.kvrcards.addCard(cardId).catch(err => console.warn(`[KIZUNAS] Error añadiendo carta ${cardId}:`, err))
            );
          }
          break;
        }
        case 'background':
        case 'fondo': {
          const bgId = String(reward.backgroundId || reward.fondoId || reward.id || '').trim();
          if (bgId) {
            if (typeof window.unlockProfileBackground === 'function') {
              rewardPromises.push(window.unlockProfileBackground(bgId).catch(console.warn));
            } else if (typeof unlockProfileBackground === 'function') {
              rewardPromises.push(unlockProfileBackground(bgId).catch(console.warn));
            } else if (typeof userProfile !== 'undefined') {
              if (!Array.isArray(userProfile.unlockedBackgrounds)) userProfile.unlockedBackgrounds = ['default'];
              if (!userProfile.unlockedBackgrounds.includes(bgId)) {
                userProfile.unlockedBackgrounds.push(bgId);
                profileNeedsSave = true;
              }
            }
          }
          break;
        }
        case 'buff': {
          console.log(`[KIZUNAS] ✅ Buff de Kizuna activo: ${reward.name || 'Buff Kizuna'}`);
          break;
        }
      }
    }

    if (profileNeedsSave && typeof saveUserProfile === 'function') {
      rewardPromises.push(saveUserProfile().catch(console.warn));
    }

    // Esperar a que se procesen todas las recompensas en paralelo
    await Promise.all(rewardPromises);

    // ⚡ 4. ACTUALIZAR INTERFACES EN SEGUNDO PLANO
    Promise.all([
      renderKizunas(),
      typeof renderWallet === 'function' ? renderWallet() : Promise.resolve(),
      typeof renderOwnedPacks === 'function' ? renderOwnedPacks() : Promise.resolve(),
      typeof renderCollection === 'function' ? renderCollection() : Promise.resolve(),
      typeof updateProfileDisplay === 'function' ? updateProfileDisplay() : Promise.resolve(),
      typeof updateMissionsProgress === 'function' ? updateMissionsProgress() : Promise.resolve()
    ]).then(() => {
      if (typeof window.updateGlobalNotificationBadges === 'function') {
        window.updateGlobalNotificationBadges();
      }
    }).catch(e => console.warn('[KIZUNAS] Error actualizando UI:', e));

  } catch (error) {
    console.error('[KIZUNAS] Error al reclamar recompensa:', error);
    // En caso de fallo grave, revertir el estado de reclamado
    if (userKizunas[kizunaId]) {
      delete userKizunas[kizunaId].claimed;
      delete userKizunas[kizunaId].claimedAt;
      await saveUserKizunasState();
    }
    if (btn) {
      btn.disabled = false;
      btn.style.opacity = '1';
      btn.style.pointerEvents = 'auto';
      btn.textContent = '🎁 Reclamar';
    }
    alert('❌ Error al reclamar la recompensa: ' + (error.message || error));
  } finally {
    activeKizunaClaims.delete(kizunaId);
  }
}

// Refrescar Kizunas desde remoto
async function refreshKizunas() {
  localStorage.removeItem(KIZUNAS_CACHE_KEY);
  await loadKizunas();
  await renderKizunas();
  alert('✅ Kizunas actualizados');
}

// Actualizar progreso de kizunas (sin alertas)
async function updateKizunasProgress() {
  if (availableKizunas.length === 0 || !kizunasContainer) return;
  await renderKizunas();
}

// Completar misión de login
async function completeLoginMission() {
  if (availableMissions.length === 0) {
    await loadMissions();
  }
  
  if (!currentUser) return;
  
  await loadUserMissionsState();
  
  // Buscar misión de login
  const loginMission = availableMissions.find(m => {
    const reqs = getMissionRequirements(m);
    return reqs.some(r => r.type === 'login');
  });
  if (!loginMission) return;
  
  const userMission = userMissions[loginMission.id] || {};
  
  // Si es diaria o semanal, verificar si ya fue reclamada en el ciclo actual (06:00 AM)
  if (loginMission.category === 'daily' || loginMission.category === 'weekly') {
    if (isMissionClaimedInCurrentCycle(loginMission, userMission)) {
      console.log('[MISSIONS] Misión de login ya reclamada en el ciclo actual');
      return;
    }
  } else if (loginMission.repeatable && userMission.claimedAt) {
    const now = Date.now();
    const cooldownMs = (loginMission.cooldown || 0) * 1000;
    const timeSinceClaim = now - userMission.claimedAt;
    
    // Si está en cooldown, no hacer nada
    if (cooldownMs > 0 && timeSinceClaim < cooldownMs) {
      console.log('[MISSIONS] Misión de login en cooldown');
      return;
    }
  }
  
  // Si no es repetible y ya fue completada (y no es cíclica), no hacer nada
  if (!loginMission.repeatable && userMission.completed && loginMission.category !== 'daily' && loginMission.category !== 'weekly') {
    return;
  }
  
  // Marcar como completada
  userMissions[loginMission.id] = { ...userMission, completed: true, progress: 1, progressValue: 1 };
  await saveUserMissionsState();
  console.log('[MISSIONS] Misión de login completada');
}

// Actualizar progreso de misiones (sin renderizar si no es necesario)
async function updateMissionsProgress() {
  if (availableMissions.length === 0 || !currentUser) return;
  
  await loadUserMissionsState();
  
  let hasChanges = false;
  const activeMissionsUser = getActiveMissionsUsername();
  
  for (const mission of availableMissions) {
    if (!isMissionVisibleForUser(mission, activeMissionsUser)) continue;

    if (!userMissions[mission.id]) {
      userMissions[mission.id] = {};
    }
    const userMission = userMissions[mission.id];

    // Soporte para resetKey que permite reiniciar misiones remotamente si se desea
    if (mission.resetKey && userMission.lastResetKey !== mission.resetKey) {
      userMission.lastResetKey = mission.resetKey;
      userMission.completed = false;
      delete userMission.claimedAt;
      delete userMission.initialProgress;
      userMission.progressValue = 0;
      userMission.progress = 0;
      userMission.needsReset = true;
      hasChanges = true;
    }
    
    // Manejo de ciclo 06:00 AM para misiones diarias y semanales
    if (mission.category === 'daily' || mission.category === 'weekly') {
      const currentCycle = getCycleKeyForMission(mission);
      if (userMission.currentCycle !== currentCycle) {
        userMission.currentCycle = currentCycle;
        userMission.needsReset = true;
        userMission.completed = false;
        userMission.progressValue = 0;
        userMission.progress = 0;
        hasChanges = true;
      }
      if (isMissionClaimedInCurrentCycle(mission, userMission)) {
        continue;
      }
    } else {
      // Si ya fue reclamada y no es repetible, saltar
      if (!mission.repeatable && userMission.claimedAt) continue;
      
      // Si es repetible, verificar cooldown
      if (mission.repeatable && userMission.claimedAt) {
        const now = Date.now();
        const cooldownMs = (mission.cooldown || 0) * 1000;
        const timeSinceClaim = now - userMission.claimedAt;
        if (cooldownMs > 0 && timeSinceClaim < cooldownMs) continue;
      }
    }
    
    const reqsProgress = await checkMissionRequirementsProgress(mission);
    const isCompleted = reqsProgress.length > 0 && reqsProgress.every(r => r.isCompleted);
    const primaryReq = reqsProgress[0] || { progress: 0, target: 1 };
    const reqs = getMissionRequirements(mission);
    const hasDaily = reqs.some(r => r.type === 'complete_daily_missions');
    
    const currentProgressValue = userMission.progressValue || 0;
    
    // Actualizar si cambió el estado
    if (isCompleted && !userMission.completed) {
      userMissions[mission.id] = { 
        ...userMission, 
        completed: true, 
        progressValue: primaryReq.progress 
      };
      if (hasDaily) {
        const dReq = reqsProgress.find(r => r.type === 'complete_daily_missions');
        userMissions[mission.id].progress = { dailyMissionsCompleted: dReq?.progress || 1 };
      } else if (typeof userMissions[mission.id].progress === 'object' && userMissions[mission.id].progress !== null) {
        userMissions[mission.id].progressValue = primaryReq.progress;
      } else {
        userMissions[mission.id].progress = primaryReq.progress;
      }
      hasChanges = true;
    } else if (!isCompleted && userMission.completed && !userMission.claimedAt && isRelativeMission(mission)) {
      userMissions[mission.id] = { 
        ...userMission, 
        completed: false, 
        progressValue: primaryReq.progress 
      };
      if (typeof userMissions[mission.id].progress === 'object' && userMissions[mission.id].progress !== null) {
        userMissions[mission.id].progressValue = primaryReq.progress;
      } else {
        userMissions[mission.id].progress = primaryReq.progress;
      }
      hasChanges = true;
    } else if (currentProgressValue !== primaryReq.progress) {
      userMissions[mission.id] = { 
        ...userMission, 
        progressValue: primaryReq.progress 
      };
      if (hasDaily) {
        const dReq = reqsProgress.find(r => r.type === 'complete_daily_missions');
        userMissions[mission.id].progress = { dailyMissionsCompleted: dReq?.progress || 0 };
      } else if (typeof userMissions[mission.id].progress === 'object' && userMissions[mission.id].progress !== null) {
        userMissions[mission.id].progressValue = primaryReq.progress;
      } else {
        userMissions[mission.id].progress = primaryReq.progress;
      }
      hasChanges = true;
    }
  }
  
  if (hasChanges) {
    await saveUserMissionsState();
    console.log('[MISSIONS] Progreso actualizado');
    
    // Forzar actualización visual inmediata si la pestaña de misiones está activa
    if (typeof sections !== 'undefined' && sections.missions?.style.display === 'block') {
      await renderMissions();
    }

    if (typeof window.updateGlobalNotificationBadges === 'function') {
      window.updateGlobalNotificationBadges();
    }
  }
}

// --- FUNCIONES GLOBALES PARA REGISTRO DE EVENTOS EN MISIONES ---
window.recordGenericMissionProgress = async function(reqType, amount = 1, context = {}) {
  if (!Array.isArray(availableMissions) || availableMissions.length === 0) {
    if (typeof loadMissions === 'function') {
      try {
        await loadMissions();
      } catch (e) {
        console.warn('[MISSIONS] Error loading missions in recordGenericMissionProgress:', e);
      }
    }
  }
  if (!Array.isArray(availableMissions) || availableMissions.length === 0) return;
  await loadUserMissionsState();
  let updated = false;

  for (const mission of availableMissions) {
    if (!isMissionVisibleForUser(mission)) continue;
    const userMission = userMissions[mission.id] || {};

    let currentCycle = null;
    if (mission.category === 'daily' || mission.category === 'weekly') {
      currentCycle = typeof getCycleKeyForMission === 'function' ? getCycleKeyForMission(mission) : null;
      if (currentCycle && userMission.currentCycle !== currentCycle) {
        userMission.currentCycle = currentCycle;
        userMission.needsReset = true;
        userMission.completed = false;
        userMission.progressValue = 0;
        userMission.progress = 0;
      }
      if (isMissionClaimedInCurrentCycle(mission, userMission)) continue;
    } else if (!mission.repeatable && userMission.claimedAt) {
      continue;
    }

    const reqs = getMissionRequirements(mission);
    const targetReq = reqs.find(r => {
      if (r.type === reqType || ((reqType === 'win_event_battle' || reqType === 'event_battle_won') && (r.type === 'win_event_battle' || r.type === 'event_battle_won'))) {
        if (reqType === 'win_event_battle' || reqType === 'event_battle_won') {
          if (r.battleId && context?.battleId) {
            const rBid = String(r.battleId).toLowerCase().trim();
            const cBid = String(context.battleId).toLowerCase().trim();
            if (!(cBid === rBid || cBid === 'evento_' + rBid || ('evento_' + cBid) === rBid || cBid.includes(rBid) || rBid.includes(cBid))) {
              return false;
            }
          }
          if (r.opponent && context?.opponent) {
            const rOpp = String(r.opponent).toLowerCase().trim();
            const cOpp = String(context.opponent).toLowerCase().trim();
            if (!cOpp.includes(rOpp) && !rOpp.includes(cOpp)) {
              return false;
            }
          }
          return true;
        }
        return true;
      }
      if (reqType === 'rounds_won_with_stat' || reqType === 'win_rounds_with_stat') {
        if (r.type === 'rounds_won_with_stat' || r.type === 'win_rounds_with_stat') {
          const reqStat = r.stat || r.statRequired || r.statType;
          if (reqStat && context?.stat) {
            const normReq = String(reqStat).toLowerCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
            const normCtx = String(context.stat).toLowerCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
            return normReq === normCtx;
          }
          return true;
        }
        return false;
      }
      if (reqType === 'win_special_event_level' || reqType === 'complete_special_event_level' || reqType === 'special_event_level') {
        const isSpecialType = (r.type === 'win_special_event_level' || r.type === 'complete_special_event_level' || r.type === 'special_event_level');
        if (isSpecialType) {
          const targetLid = r.levelId || r.battleId || r.id;
          if (targetLid) {
            if (!context?.levelId) return false;
            const rLid = String(targetLid).toLowerCase().trim();
            const cLid = String(context.levelId).toLowerCase().trim();
            if (cLid !== rLid && cLid !== ('special_level_' + rLid) && ('special_level_' + cLid) !== rLid) {
              return false;
            }
          }
          if (r.levelNumber !== undefined && context?.levelNumber !== undefined) {
            if (Number(r.levelNumber) !== Number(context.levelNumber)) {
              return false;
            }
          }
          if (r.worldId) {
            if (!context?.worldId) return false;
            const rWid = String(r.worldId).toLowerCase().trim();
            const cWid = String(context.worldId).toLowerCase().trim();
            if (cWid !== rWid && cWid !== ('special_world_' + rWid) && ('special_world_' + cWid) !== rWid) {
              return false;
            }
          }
          if (r.eventId) {
            if (!context?.eventId) return false;
            const rEid = String(r.eventId).toLowerCase().trim();
            const cEid = String(context.eventId).toLowerCase().trim();
            if (cEid !== rEid) {
              return false;
            }
          }
          return true;
        }
        return false;
      }
      if (reqType === 'complete_trade' && (r.type === 'trade' || r.type === 'intercambio')) return true;
      if (reqType === 'trade' && (r.type === 'complete_trade' || r.type === 'intercambio')) return true;
      return false;
    });

    if (targetReq) {
      const targetAmount = Number(targetReq.amount || targetReq.target || 1);
      let effectiveReqType = targetReq.type || reqType;
      const targetSpecialLid = targetReq.levelId || targetReq.battleId || targetReq.id;
      if ((reqType === 'win_event_battle' || reqType === 'event_battle_won') && targetReq.battleId) {
        effectiveReqType = `event_battle_${targetReq.battleId}`;
      } else if ((reqType === 'win_special_event_level' || reqType === 'complete_special_event_level' || reqType === 'special_event_level') && targetSpecialLid) {
        effectiveReqType = `special_level_${targetSpecialLid}`;
      } else if ((reqType === 'rounds_won_with_stat' || reqType === 'win_rounds_with_stat') && (targetReq.stat || targetReq.statRequired)) {
        const normStat = String(targetReq.stat || targetReq.statRequired).toLowerCase().trim().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        effectiveReqType = `rounds_won_stat_${normStat}`;
      }
      
      const currentVal = (typeof userMission.progress === 'object' && userMission.progress !== null)
        ? (Number(userMission.progress[effectiveReqType]) || 0)
        : (typeof userMission.progress === 'number' ? userMission.progress : 0);
      const newVal = currentVal + amount;
      
      if (typeof userMission.progress !== 'object' || userMission.progress === null) {
        userMission.progress = {};
      }
      userMission.progress[effectiveReqType] = newVal;
      if (!targetSpecialLid) {
        userMission.progress[reqType] = newVal;
        if (targetReq.type) {
          userMission.progress[targetReq.type] = newVal;
        }
      }
      userMission.progressValue = newVal;
      if (currentCycle) {
        userMission.currentCycle = currentCycle;
      }
      
      if (newVal >= targetAmount) {
        userMission.completed = true;
      }
      userMissions[mission.id] = userMission;
      updated = true;
      console.log(`[MISSIONS] Evento registrado (${reqType}) para ${mission.id}: ${newVal}/${targetAmount}`);
    }
  }

  if (updated) {
    await saveUserMissionsState();
    if (typeof sections !== 'undefined' && sections.missions?.style.display === 'block') {
      await renderMissions();
    }
    if (typeof window.updateGlobalNotificationBadges === 'function') {
      window.updateGlobalNotificationBadges();
    }
  }
};

window.recordMissionRoundWon = function(amount = 1, stat = null) {
  window.recordGenericMissionProgress('rounds_won', amount);
  if (stat) {
    window.recordGenericMissionProgress('rounds_won_with_stat', amount, { stat: stat });
    window.recordGenericMissionProgress('win_rounds_with_stat', amount, { stat: stat });
  }
};

window.recordInfiniteLevelPlayed = function(amount = 1) {
  window.recordGenericMissionProgress('play_infinite_levels', amount);
};

window.recordTradeCompleted = function(amount = 1) {
  window.recordGenericMissionProgress('complete_trade', amount);
};

// Buscar cartas en el selector
