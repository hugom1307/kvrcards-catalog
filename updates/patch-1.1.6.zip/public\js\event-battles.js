// ==========================================================================
// SISTEMA DE BATALLAS DE EVENTO (event-battles.js)
// ==========================================================================

(function () {
  'use strict';

  const REMOTE_CONFIG_URLS = [
    `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/event-battles.json?t=${Date.now()}`,
    `https://hugom1307.github.io/kvrcards-catalog/event-battles.json?t=${Date.now()}`
  ];

  const DEFAULT_EVENT_BATTLES_CONFIG = {
    version: 1,
    events: [
      {
        id: 'evento_desafio_shinobi',
        name: 'Desafio de Maestros Shinobi',
        description: 'Supera las pruebas de los legendarios comandantes de la niebla y el rayo para obtener valiosas recompensas.',
        backgroundImage: 'https://hugom1307.github.io/kvrcards-catalog/image/fondos/fondo_ronan_hatake.png',
        battles: [
          {
            id: 'evento_combate_1',
            name: 'Fase 1: Guardian de la Niebla',
            description: 'Enfrentate a la vanguardia tactica y demuestra tu temple.',
            image: 'https://hugom1307.github.io/kvrcards-catalog/image/botsoffline/doman.png',
            maxAttempts: 3,
            dailyReset: true,
            rewards: [
              { type: 'coins', amount: 600 },
              { type: 'kvr', amount: 30, probability: 50 },
              { type: 'traits', amount: 2, probability: 25 }
            ]
          },
          {
            id: 'evento_combate_2',
            name: 'Fase 2: El Trueno Carmesi',
            description: 'Combate definitivo contra el maestro del rayo.',
            image: 'https://hugom1307.github.io/kvrcards-catalog/image/botsoffline/zion.png',
            maxAttempts: 1,
            dailyReset: true,
            rewards: [
              { type: 'coins', amount: 1800 },
              { type: 'kvr', amount: 100 },
              { type: 'pack', packId: 'sobre_oro', amount: 1, probability: 40 }
            ]
          }
        ]
      }
    ]
  };

  let cachedEventsConfig = null;
  let activeEventIndex = 0;

  function safeParseJson(rawText) {
    if (typeof rawText !== 'string') return rawText;
    try {
      return JSON.parse(rawText);
    } catch (err) {
      let cleaned = rawText.replace(/^\uFEFF/, '');
      cleaned = cleaned.replace(/\/\*[\s\S]*?\*\/|([^\\:]|^)\/\/.*$/gm, '$1');
      let prev;
      do {
        prev = cleaned;
        cleaned = cleaned.replace(/,\s*([\]}])/g, '$1');
        cleaned = cleaned.replace(/,\s*,/g, ',');
      } while (cleaned !== prev);
      return JSON.parse(cleaned);
    }
  }

  function getActiveUsername() {
    if (typeof currentUser === 'string' && currentUser.trim()) {
      return currentUser.trim();
    }
    return localStorage.getItem('kvrUsername') || 'guest';
  }

  function getEventCycleDay(date = new Date()) {
    const d = new Date(date);
    if (d.getHours() < 6) {
      d.setDate(d.getDate() - 1);
    }
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  function getAttemptsStorageKey() {
    const user = getActiveUsername();
    return `kvr_event_battles_attempts_${user}`;
  }

  function loadUserAttemptsMap() {
    try {
      const raw = localStorage.getItem(getAttemptsStorageKey());
      if (raw) return JSON.parse(raw) || {};
    } catch (e) {
      console.warn('[EVENT-BATTLES] Error cargando intentos:', e);
    }
    return {};
  }

  function saveUserAttemptsMap(map) {
    try {
      localStorage.setItem(getAttemptsStorageKey(), JSON.stringify(map || {}));
    } catch (e) {
      console.warn('[EVENT-BATTLES] Error guardando intentos:', e);
    }
  }

  function getBattleAttemptsStatus(battle) {
    const battleId = battle.id;
    const isDaily = Boolean(battle.dailyReset ?? battle.reseteoDiario ?? true);
    const maxRaw = battle.maxAttempts ?? battle.intentos ?? battle.veces ?? 0;
    const maxAttempts = Number(maxRaw) || 0;

    const map = loadUserAttemptsMap();
    const record = map[battleId] || { count: 0, cycle: '', totalCount: 0 };
    const currentCycle = getEventCycleDay();

    let usedAttempts = 0;
    if (isDaily) {
      if (record.cycle === currentCycle) {
        usedAttempts = Number(record.count) || 0;
      } else {
        usedAttempts = 0;
      }
    } else {
      usedAttempts = Number(record.totalCount ?? record.count) || 0;
    }

    const hasLimit = maxAttempts > 0;
    const remaining = hasLimit ? Math.max(0, maxAttempts - usedAttempts) : Infinity;
    const isExhausted = hasLimit && remaining <= 0;

    return {
      used: usedAttempts,
      max: maxAttempts,
      remaining: remaining,
      hasLimit: hasLimit,
      isExhausted: isExhausted,
      isDaily: isDaily
    };
  }

  function recordBattleAttemptCompletion(battleId) {
    if (!battleId) return;
    const map = loadUserAttemptsMap();
    const currentCycle = getEventCycleDay();
    const record = map[battleId] || { count: 0, cycle: '', totalCount: 0 };

    if (record.cycle === currentCycle) {
      record.count = (Number(record.count) || 0) + 1;
    } else {
      record.count = 1;
      record.cycle = currentCycle;
    }
    record.totalCount = (Number(record.totalCount) || 0) + 1;
    record.lastPlayedAt = Date.now();

    map[battleId] = record;
    saveUserAttemptsMap(map);
    console.log(`[EVENT-BATTLES] Intento registrado para ${battleId}:`, record);
  }

  async function loadEventBattlesConfig(forceRefresh = false) {
    if (!forceRefresh && cachedEventsConfig) {
      return cachedEventsConfig;
    }

    for (const url of REMOTE_CONFIG_URLS) {
      try {
        const resp = await fetch(url, { cache: 'no-store' });
        if (resp.ok) {
          const text = await resp.text();
          const parsed = safeParseJson(text);
          const rawEvents = parsed?.events || parsed?.eventos || (Array.isArray(parsed) ? parsed : (parsed?.battles || parsed?.combates ? [parsed] : null));
          if (Array.isArray(rawEvents) && rawEvents.length > 0) {
            console.log(`[EVENT-BATTLES] Configuracion cargada desde ${url} (${rawEvents.length} eventos)`);
            cachedEventsConfig = {
              version: parsed.version || 1,
              events: rawEvents
            };
            return cachedEventsConfig;
          }
        }
      } catch (err) {
        console.warn(`[EVENT-BATTLES] No se pudo cargar desde ${url}:`, err.message);
      }
    }

    console.log('[EVENT-BATTLES] Usando configuracion por defecto de respaldo');
    cachedEventsConfig = DEFAULT_EVENT_BATTLES_CONFIG;
    return cachedEventsConfig;
  }

  function normalizeBattle(b, index) {
    return {
      id: String(b.id || `evento_combate_${index + 1}`).trim(),
      name: b.name || b.nombre || b.titulo || `Combate ${index + 1}`,
      description: b.description || b.descripcion || '',
      image: b.image || b.imagen || b.buttonImage || './assets/botones/eventos.png',
      maxAttempts: Number(b.maxAttempts ?? b.intentos ?? b.veces ?? 0),
      dailyReset: Boolean(b.dailyReset ?? b.reseteoDiario ?? true),
      rewards: Array.isArray(b.rewards || b.recompensas) ? (b.rewards || b.recompensas) : []
    };
  }

  function normalizeEvent(e, index) {
    const rawBattles = e.battles || e.combates || [];
    return {
      id: String(e.id || `evento_${index + 1}`).trim(),
      name: e.name || e.nombre || e.titulo || `Evento ${index + 1}`,
      description: e.description || e.descripcion || '',
      backgroundImage: e.backgroundImage || e.fondo || e.background || '',
      battles: Array.isArray(rawBattles) ? rawBattles.map(normalizeBattle) : []
    };
  }

  function renderTabs(events) {
    const container = document.getElementById('event-tabs-container');
    if (!container) return;

    if (!Array.isArray(events) || events.length <= 1) {
      container.innerHTML = '';
      return;
    }

    container.innerHTML = '';
    events.forEach((ev, idx) => {
      const tabBtn = document.createElement('button');
      tabBtn.type = 'button';
      tabBtn.className = `event-tab-btn ${idx === activeEventIndex ? 'active' : ''}`;
      tabBtn.textContent = String(idx + 1);
      tabBtn.title = ev.name || `Evento ${idx + 1}`;
      tabBtn.addEventListener('click', () => {
        activeEventIndex = idx;
        renderActiveEvent();
      });
      container.appendChild(tabBtn);
    });
  }

  function renderActiveEvent() {
    if (!cachedEventsConfig || !Array.isArray(cachedEventsConfig.events)) return;
    const events = cachedEventsConfig.events;
    if (activeEventIndex >= events.length) activeEventIndex = 0;

    const currentRaw = events[activeEventIndex];
    const currentEvent = normalizeEvent(currentRaw, activeEventIndex);

    renderTabs(events);

    const panel = document.getElementById('event-battles-panel');
    if (panel) {
      if (currentEvent.backgroundImage && currentEvent.backgroundImage.trim()) {
        panel.style.setProperty('--event-panel-bg', `url("${currentEvent.backgroundImage.trim()}")`);
      } else {
        panel.style.setProperty('--event-panel-bg', 'none');
      }
    }

    const titleEl = document.getElementById('event-panel-title');
    if (titleEl) {
      titleEl.textContent = currentEvent.name;
    }

    const descEl = document.getElementById('event-panel-desc');
    if (descEl) {
      descEl.textContent = currentEvent.description;
    }

    const grid = document.getElementById('event-battles-grid');
    if (!grid) return;

    const battles = currentEvent.battles;
    grid.setAttribute('data-count', String(Math.min(battles.length, 3)));
    grid.innerHTML = '';

    if (battles.length === 0) {
      grid.innerHTML = '<div class="event-battles-empty">No hay combates disponibles en este evento en este momento.</div>';
      return;
    }

    battles.forEach((battle) => {
      const status = getBattleAttemptsStatus(battle);
      const card = document.createElement('div');
      card.className = 'event-battle-card';

      let badgeClass = 'event-battle-badge-attempts';
      let badgeText = '';

      if (!status.hasLimit) {
        badgeText = 'Ilimitado';
      } else if (status.isExhausted) {
        badgeClass += ' exhausted';
        badgeText = 'Agotado (0/' + status.max + ')';
      } else {
        if (status.remaining === 1) badgeClass += ' warning';
        badgeText = `Intentos: ${status.remaining}/${status.max}`;
      }

      const resetIndicatorHtml = status.isDaily
        ? '<span class="event-battle-reset-indicator">Reseteo diario: 06:00</span>'
        : '<span class="event-battle-reset-indicator">Un solo intento permanente</span>';

      card.innerHTML = `
        <div class="event-battle-card-top">
          <div class="event-battle-meta-bar">
            <span class="${badgeClass}">${badgeText}</span>
            ${resetIndicatorHtml}
          </div>
          <h3 class="event-battle-name">${escapeHtml(battle.name)}</h3>
          <p class="event-battle-desc">${escapeHtml(battle.description)}</p>
        </div>

        <div class="event-battle-btn-wrapper">
          <button type="button" class="event-battle-action-btn" ${status.isExhausted ? 'disabled' : ''} data-battle-id="${escapeHtml(battle.id)}">
            <img src="${escapeHtml(battle.image)}" alt="${escapeHtml(battle.name)}" class="event-battle-img" onerror="this.src='./assets/botones/eventos.png';" />
            <div class="event-battle-overlay-label">
              <span>${status.isExhausted ? 'Sin intentos restantes' : 'Desafiar al Rival'}</span>
              <span class="event-battle-overlay-action">${status.isExhausted ? 'Bloqueado' : 'Entrar'}</span>
            </div>
          </button>
        </div>

        <div class="event-battle-bottom-actions">
          <button type="button" class="event-rewards-view-btn" data-rewards-id="${escapeHtml(battle.id)}">
            Ver Recompensas
          </button>
        </div>
      `;

      const actionBtn = card.querySelector('.event-battle-action-btn');
      if (actionBtn && !status.isExhausted) {
        actionBtn.addEventListener('click', () => {
          startEventBattleFlow(battle);
        });
      }

      const rewardsBtn = card.querySelector('.event-rewards-view-btn');
      if (rewardsBtn) {
        rewardsBtn.addEventListener('click', () => {
          openEventRewardsModal(battle);
        });
      }

      grid.appendChild(card);
    });
  }

  function startEventBattleFlow(battle) {
    const status = getBattleAttemptsStatus(battle);
    if (status.isExhausted) {
      const msg = status.isDaily
        ? 'Has agotado tus intentos diarios para este combate. Vuelve a intentarlo mañana a las 06:00.'
        : 'Has agotado los intentos permitidos para este combate especial.';
      alert(msg);
      return;
    }

    console.log('[EVENT-BATTLES] Iniciando flujo de batalla para ID:', battle.id);

    window.selectedDifficulty = battle.id;
    window.currentEventBattle = battle;
    window.isEventBattle = true;
    window.isInfiniteModeTeamBuilding = false;

    const panel = document.getElementById('event-battles-panel');
    if (panel) panel.style.display = 'none';

    const teamBuilder = document.getElementById('team-builder');
    if (teamBuilder) teamBuilder.style.display = 'block';

    if (typeof updateTeamBuilderModeUI === 'function') {
      updateTeamBuilderModeUI();
    }
    if (typeof loadTeamBuilderInventory === 'function') {
      loadTeamBuilderInventory();
    }

    setTimeout(() => {
      if (typeof setupContinueButton === 'function') {
        setupContinueButton();
      }
    }, 400);
  }

  function resolveRewardDisplayInfo(reward) {
    const type = String(reward.type || reward.tipo || '').toLowerCase().trim();
    const amount = Number(reward.amount || reward.cantidad || 1);
    let name = reward.name || reward.nombre || '';
    let icon = './coin.png';

    if (type === 'coins') {
      name = name || 'Monedas Coins';
      icon = './coin.png';
    } else if (type === 'kvr') {
      name = name || 'Monedas KvR';
      icon = './kvr.png';
    } else if (type === 'traits' || type === 'trait') {
      name = name || 'Puntos de Traits';
      icon = './trait.png';
    } else if (type === 'pack' || type === 'packs') {
      const packId = reward.packId || reward.id || '';
      name = name || `Sobre: ${packId.replace(/_/g, ' ')}`;
      icon = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${packId}.png`;
    } else if (type === 'card' || type === 'carta') {
      const cardId = reward.cardId || reward.id || '';
      name = name || `Carta: ${cardId.replace(/_/g, ' ')}`;
      icon = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${cardId}.png`;
    } else if (type === 'title' || type === 'titulo') {
      name = name || `Titulo: ${reward.titleId || reward.id || ''}`;
      icon = './icon-especiales.png';
    } else {
      name = name || 'Recompensa especial';
      icon = './icon-especiales.png';
    }

    const rawProb = reward.probability ?? reward.prob ?? reward.probabilidad;
    let prob = null;
    let isGuaranteed = true;

    if (rawProb !== undefined && rawProb !== null) {
      let p = Number(rawProb);
      if (p <= 1 && p > 0) p = p * 100;
      if (p < 100) {
        prob = p;
        isGuaranteed = false;
      }
    }

    return {
      type,
      name,
      amount,
      icon,
      isGuaranteed,
      probability: prob
    };
  }

  function openEventRewardsModal(battle) {
    const modal = document.getElementById('event-rewards-modal');
    if (!modal) return;

    const titleEl = document.getElementById('event-rewards-modal-title');
    if (titleEl) {
      titleEl.textContent = `Recompensas: ${battle.name}`;
    }

    const listContainer = document.getElementById('event-rewards-modal-list');
    if (!listContainer) return;
    listContainer.innerHTML = '';

    const rewards = battle.rewards || [];
    if (rewards.length === 0) {
      listContainer.innerHTML = '<div class="event-battles-empty">No hay recompensas configuradas para este combate.</div>';
    } else {
      rewards.forEach((r) => {
        const info = resolveRewardDisplayInfo(r);
        const row = document.createElement('div');
        row.className = 'event-reward-row';

        const chanceBadgeHtml = info.isGuaranteed
          ? '<span class="event-reward-chance-pill guaranteed">100% Asegurada</span>'
          : `<span class="event-reward-chance-pill probabilistic">${info.probability}% Probabilidad</span>`;

        row.innerHTML = `
          <div class="event-reward-info-left">
            <div class="event-reward-icon-box">
              <img src="${escapeHtml(info.icon)}" alt="${escapeHtml(info.name)}" class="event-reward-icon-img" onerror="this.src='./icon-especiales.png';" />
            </div>
            <div class="event-reward-name-amount">
              <span class="event-reward-name">${escapeHtml(info.name)}</span>
              <span class="event-reward-amount">Cantidad: x${info.amount.toLocaleString('es-ES')}</span>
            </div>
          </div>
          ${chanceBadgeHtml}
        `;
        listContainer.appendChild(row);
      });
    }

    modal.style.display = 'flex';
  }

  function closeEventRewardsModal() {
    const modal = document.getElementById('event-rewards-modal');
    if (modal) modal.style.display = 'none';
  }

  function rollEventBattleRewards(rewardsList) {
    if (!Array.isArray(rewardsList) || rewardsList.length === 0) return [];
    const granted = [];

    rewardsList.forEach((r) => {
      const rawProb = r.probability ?? r.prob ?? r.probabilidad;
      let prob = 100;

      if (rawProb !== undefined && rawProb !== null) {
        let p = Number(rawProb);
        if (p <= 1 && p > 0) p = p * 100;
        prob = p;
      }

      if (prob >= 100) {
        granted.push(r);
      } else {
        const roll = Math.random() * 100;
        if (roll <= prob) {
          granted.push(r);
        }
      }
    });

    return granted;
  }

  async function openEventBattlesPanel() {
    window.isEventBattle = false;
    window.currentEventBattle = null;

    const typeSelection = document.getElementById('game-type-selection');
    if (typeSelection) typeSelection.style.display = 'none';

    const panel = document.getElementById('event-battles-panel');
    if (panel) panel.style.display = 'block';

    await loadEventBattlesConfig(true);
    renderActiveEvent();
  }

  function closeEventBattlesPanel() {
    const panel = document.getElementById('event-battles-panel');
    if (panel) panel.style.display = 'none';

    const typeSelection = document.getElementById('game-type-selection');
    if (typeSelection) typeSelection.style.display = 'block';
  }

  function escapeHtml(str) {
    if (typeof str !== 'string') return String(str ?? '');
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Hooking del boton volver de team builder
  if (typeof window.backToDifficultySelection === 'function') {
    const prevBack = window.backToDifficultySelection;
    window.backToDifficultySelection = function () {
      if (window.isEventBattle) {
        window.isEventBattle = false;
        const teamBuilder = document.getElementById('team-builder');
        if (teamBuilder) teamBuilder.style.display = 'none';
        openEventBattlesPanel();
        return;
      }
      return prevBack.apply(this, arguments);
    };
  }

  // Exponer API global
  window.openEventBattlesPanel = openEventBattlesPanel;
  window.closeEventBattlesPanel = closeEventBattlesPanel;
  window.closeEventRewardsModal = closeEventRewardsModal;
  window.recordBattleAttemptCompletion = recordBattleAttemptCompletion;
  window.rollEventBattleRewards = rollEventBattleRewards;
  window.loadEventBattlesConfig = loadEventBattlesConfig;
})();
