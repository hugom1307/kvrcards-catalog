async function getPrestigeConfig() {
  if (prestigeConfigCache) return prestigeConfigCache;

  try {
    const remoteRes = await fetch(REMOTE_PRESTIGE_CONFIG_URL, { cache: 'no-store' });
    if (remoteRes.ok) {
      const remoteConfig = await remoteRes.json();
      if (remoteConfig && (Array.isArray(remoteConfig) || Array.isArray(remoteConfig.levels) || Array.isArray(remoteConfig?.default?.levels) || Array.isArray(remoteConfig?.cards))) {
        prestigeConfigCache = remoteConfig;
        return prestigeConfigCache;
      }
    }
  } catch (e) {
    console.warn('[PRESTIGE] No se pudo cargar config remota:', e?.message || e);
  }

  try {
    const localRes = await fetch('./prestige-config.json', { cache: 'no-store' });
    if (localRes.ok) {
      const localConfig = await localRes.json();
      if (localConfig && (Array.isArray(localConfig) || Array.isArray(localConfig.levels) || Array.isArray(localConfig?.default?.levels) || Array.isArray(localConfig?.cards))) {
        prestigeConfigCache = localConfig;
        return prestigeConfigCache;
      }
    }
  } catch (e) {
    console.warn('[PRESTIGE] No se pudo cargar config local:', e?.message || e);
  }

  prestigeConfigCache = defaultPrestigeConfig;
  return prestigeConfigCache;
}

function matchPrestigeCardEntry(entry, card) {
  if (!entry) return false;
  const entryId = String(entry.cardId || entry.id || '').trim().toLowerCase();
  if (!entryId || entryId === 'default') return false;
  const cId = String(card?.id || '').trim().toLowerCase();
  if (entryId === cId) return true;
  const SUFFIX_REGEX = /_(?:icono|heroe|oro|plata|bronce|especial|comun|evo|prime|iconoprime|iconosuperprime|superprime|legendaria)$/i;
  const entryStripped = entryId.replace(SUFFIX_REGEX, '');
  const cStripped = cId.replace(SUFFIX_REGEX, '');
  if (entryStripped === cStripped || entryStripped === cId || entryId === cStripped) return true;
  const entryName = String(entry.name || '').trim().toLowerCase();
  const cName = String(card?.name || card?.nombre || '').trim().toLowerCase();
  if (entryName && cName && entryName === cName) return true;
  return false;
}

function resolvePrestigeProfile(config, card) {
  const root = config || defaultPrestigeConfig;
  const cardId = String(card?.id || '').trim();

  // 1. Si la configuración es directamente un Array [ { cardId, levels }, ... ]
  if (Array.isArray(root)) {
    const foundCard = root.find(entry => matchPrestigeCardEntry(entry, card));
    if (foundCard && Array.isArray(foundCard.levels)) {
      return {
        xpRules: foundCard.xpRules || defaultPrestigeConfig.xpRules,
        levels: foundCard.levels
      };
    }
    const defaultEntry = root.find(entry => entry && (String(entry.cardId || entry.id || '').toLowerCase() === 'default' || !entry.cardId));
    if (defaultEntry && Array.isArray(defaultEntry.levels)) {
      return {
        xpRules: defaultEntry.xpRules || defaultPrestigeConfig.xpRules,
        levels: defaultEntry.levels
      };
    }
  }

  // 2. Si root.cards es un Array [ { cardId, levels }, ... ]
  if (root?.cards && Array.isArray(root.cards)) {
    const foundCard = root.cards.find(entry => matchPrestigeCardEntry(entry, card));
    if (foundCard && Array.isArray(foundCard.levels)) {
      return {
        xpRules: foundCard.xpRules || root?.default?.xpRules || root?.xpRules || defaultPrestigeConfig.xpRules,
        levels: foundCard.levels
      };
    }
  }

  // 3. Si root.cards es un Objeto { "card_id": { levels: [...] } }
  const cardProfile = (cardId && root?.cards && typeof root.cards === 'object' && !Array.isArray(root.cards))
    ? root.cards[cardId]
    : null;

  if (cardProfile && Array.isArray(cardProfile.levels)) {
    return {
      xpRules: cardProfile.xpRules || root?.default?.xpRules || root?.xpRules || defaultPrestigeConfig.xpRules,
      levels: cardProfile.levels
    };
  }

  // 4. Si tiene bloque "default" con levels
  if (root?.default && Array.isArray(root.default.levels)) {
    return {
      xpRules: root.default.xpRules || root.xpRules || defaultPrestigeConfig.xpRules,
      levels: root.default.levels
    };
  }

  // 5. Si root tiene levels directamente en la raíz
  if (Array.isArray(root.levels)) {
    return {
      xpRules: root.xpRules || defaultPrestigeConfig.xpRules,
      levels: root.levels
    };
  }

  return {
    xpRules: defaultPrestigeConfig.xpRules,
    levels: defaultPrestigeConfig.levels
  };
}

function getPrestigeThresholds(levels) {
  const raw = Array.isArray(levels)
    ? levels
        .map(l => Number(l?.xpRequired) || 0)
        .filter(v => v > 0)
    : [];
  return raw.length > 0 ? raw : [...PRESTIGE_XP_THRESHOLDS];
}

function getPrestigeClaimKey(cardId, prestigeLevel) {
  const safeCardId = String(cardId || 'unknown_card').trim() || 'unknown_card';
  return `prestige_claim_${safeCardId}_${prestigeLevel}`;
}

function getPrestigeMissionClaimKey(cardId, missionId) {
  const safeCardId = String(cardId || 'unknown_card').trim() || 'unknown_card';
  const safeMissionId = String(missionId || 'unknown_mission').trim() || 'unknown_mission';
  return `prestige_mission_claim_${safeCardId}_${safeMissionId}`;
}

function normalizePrestigeCardId(cardId) {
  return String(cardId || '').trim();
}

function loadPrestigeProgressStore() {
  try {
    const raw = localStorage.getItem(PRESTIGE_PROGRESS_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

function savePrestigeProgressStore(store) {
  try {
    localStorage.setItem(PRESTIGE_PROGRESS_STORAGE_KEY, JSON.stringify(store || {}));
  } catch {}
}

function getPrestigeProgressEntry(cardId, createIfMissing = false) {
  const normalizedId = normalizePrestigeCardId(cardId);
  if (!normalizedId) {
    return { cardId: '', battlesPlayed: 0, battlesWon: 0, battleXp: 0, missionXp: 0 };
  }

  const store = loadPrestigeProgressStore();
  const existing = (store[normalizedId] && typeof store[normalizedId] === 'object')
    ? store[normalizedId]
    : null;

  if (!existing && createIfMissing) {
    store[normalizedId] = {
      battlesPlayed: 0,
      battlesWon: 0,
      battleXp: 0,
      missionXp: 0,
      updatedAt: Date.now()
    };
    savePrestigeProgressStore(store);
  }

  const current = store[normalizedId] || existing || {};
  return {
    cardId: normalizedId,
    battlesPlayed: Math.max(0, Number(current.battlesPlayed) || 0),
    battlesWon: Math.max(0, Number(current.battlesWon) || 0),
    battleXp: Math.max(0, Number(current.battleXp) || 0),
    missionXp: Math.max(0, Number(current.missionXp) || 0)
  };
}

function parseMissionTargetValue(mission) {
  const directTarget = Number(mission?.target ?? mission?.goal ?? mission?.required ?? mission?.count ?? mission?.value);
  if (Number.isFinite(directTarget) && directTarget > 0) return Math.floor(directTarget);

  const text = String(mission?.name || mission?.text || mission?.description || '');
  const numberMatch = text.match(/(\d+)/);
  if (numberMatch) {
    const parsed = Number(numberMatch[1]);
    if (Number.isFinite(parsed) && parsed > 0) return Math.floor(parsed);
  }

  return 1;
}

function resolveMissionMetric(mission) {
  const missionType = String(mission?.type || mission?.metric || mission?.action || '').toLowerCase();
  const missionText = String(mission?.name || mission?.text || mission?.description || '').toLowerCase();

  if (missionType.includes('win') || missionType.includes('victory') || missionType.includes('gan')) return 'wins';
  if (missionType.includes('battle') || missionType.includes('play') || missionType.includes('jugar')) return 'played';

  if (/(ganar|gana|victoria)/.test(missionText)) return 'wins';
  if (/(jugar|juega|batalla|partida)/.test(missionText)) return 'played';

  return null;
}

function getMissionProgressForCard(mission, cardProgress) {
  const metric = resolveMissionMetric(mission);
  const target = parseMissionTargetValue(mission);

  if (metric === 'wins') {
    const current = Math.max(0, Number(cardProgress?.battlesWon) || 0);
    return { current, target, metric };
  }

  if (metric === 'played') {
    const current = Math.max(0, Number(cardProgress?.battlesPlayed) || 0);
    return { current, target, metric };
  }

  return null;
}

function getEquippedBaseCardIdsForPrestige() {
  const teamFromIndex = Array.isArray(window.allTeams)
    ? window.allTeams[window.currentTeamIndex || 0]
    : null;
  const sourceTeam = Array.isArray(window.selectedTeam) && window.selectedTeam.length > 0
    ? window.selectedTeam
    : (Array.isArray(teamFromIndex) ? teamFromIndex : []);
  const ids = new Set();

  sourceTeam.forEach((teamCardId) => {
    if (!teamCardId) return;
    let baseId = String(teamCardId);

    if (baseId.includes('_notrait')) {
      baseId = baseId.split('_notrait')[0];
    } else if (baseId.includes('trait_')) {
      const traitData = cardTraitsMap?.[baseId];
      baseId = String(traitData?.cardId || baseId);
    }

    const normalized = normalizePrestigeCardId(baseId);
    if (normalized) ids.add(normalized);
  });

  return Array.from(ids);
}

function setBattlePrestigeEligibleCardIds() {
  if (!window.battleState) return;
  window.battleState.prestigeEligibleCardIds = getEquippedBaseCardIdsForPrestige();
}

async function recordPrestigeBattleOutcome(didWin) {
  const eligibleIds = Array.isArray(window.battleState?.prestigeEligibleCardIds)
    ? window.battleState.prestigeEligibleCardIds
    : getEquippedBaseCardIdsForPrestige();

  if (!Array.isArray(eligibleIds) || eligibleIds.length === 0) return;

  const cfg = await getPrestigeConfig();
  const store = loadPrestigeProgressStore();

  eligibleIds.forEach((cardId) => {
    const normalizedId = normalizePrestigeCardId(cardId);
    if (!normalizedId) return;

    const profile = resolvePrestigeProfile(cfg, { id: normalizedId });
    const xpRules = profile?.xpRules || defaultPrestigeConfig.xpRules;
    const playedXp = Math.max(0, Number(xpRules?.battlePlayed) || 0);
    const winBonusXp = didWin ? Math.max(0, Number(xpRules?.battleWinBonus) || 0) : 0;
    const gainedXp = playedXp + winBonusXp;

    const current = store[normalizedId] && typeof store[normalizedId] === 'object'
      ? store[normalizedId]
      : { battlesPlayed: 0, battlesWon: 0, battleXp: 0, missionXp: 0 };

    current.battlesPlayed = Math.max(0, Number(current.battlesPlayed) || 0) + 1;
    if (didWin) current.battlesWon = Math.max(0, Number(current.battlesWon) || 0) + 1;
    current.battleXp = Math.max(0, Number(current.battleXp) || 0) + gainedXp;
    current.missionXp = Math.max(0, Number(current.missionXp) || 0);
    current.updatedAt = Date.now();

    store[normalizedId] = current;
  });

  savePrestigeProgressStore(store);
}

function getRewardName(reward) {
  return String(
    reward?.name || reward?.title || reward?.label || reward?.text || 'Recompensa'
  );
}

const CARD_QUALITY_SUFFIX_REGEX = /_(?:icono|heroe|oro|plata|bronce|especial|comun|evo|prime|iconoprime|iconosuperprime|superprime|legendaria)$/i;

function normalizePrestigeAssetUrl(url) {
  if (!url || typeof url !== 'string') return url;
  return url.replace(/^https?:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/main\/(.*)$/i, 'https://$1.github.io/$2/$3');
}

function findCardInCatalog(cardIdOrReward, allCards = null) {
  const cards = (Array.isArray(allCards) && allCards.length > 0)
    ? allCards
    : ((Array.isArray(rewardHudCatalogCache.cards) && rewardHudCatalogCache.cards.length > 0)
      ? rewardHudCatalogCache.cards
      : (Array.isArray(window.allCardsCache) && window.allCardsCache.length > 0
        ? window.allCardsCache
        : (Array.isArray(window.availableCards) ? window.availableCards : [])));

  if (!cards || cards.length === 0) return null;

  let rawId = '';
  let rawName = '';
  if (typeof cardIdOrReward === 'string') {
    rawId = cardIdOrReward.trim();
  } else if (cardIdOrReward && typeof cardIdOrReward === 'object') {
    rawId = String(cardIdOrReward.cardId || cardIdOrReward.id || cardIdOrReward.card || cardIdOrReward.card_id || '').trim();
    rawName = String(cardIdOrReward.name || cardIdOrReward.title || cardIdOrReward.label || cardIdOrReward.nombre || '').trim();
  }

  const cleanReqName = rawName.replace(/^(?:🃏|\s)*(?:carta)\s*:\s*/i, '').trim().toLowerCase();
  const lowerId = rawId.toLowerCase();
  const withoutSuffix = lowerId.replace(CARD_QUALITY_SUFFIX_REGEX, '');

  // 1. Coincidencia exacta por ID
  if (lowerId) {
    let found = cards.find(c => c && String(c.id || '').toLowerCase() === lowerId);
    if (found) return found;

    // 2. Coincidencia quitando sufijo de calidad (ej: kinan_hatake_icono -> kinan_hatake)
    if (withoutSuffix && withoutSuffix !== lowerId) {
      found = cards.find(c => c && String(c.id || '').toLowerCase() === withoutSuffix);
      if (found) return found;
    }

    // 3. Coincidencia si la carta en catálogo tiene sufijo pero el ID no
    found = cards.find(c => {
      if (!c) return false;
      const cId = String(c.id || '').toLowerCase();
      const cWithoutSuffix = cId.replace(CARD_QUALITY_SUFFIX_REGEX, '');
      return cWithoutSuffix === lowerId || cWithoutSuffix === withoutSuffix;
    });
    if (found) return found;
  }

  // 4. Coincidencia por nombre limpio
  if (cleanReqName) {
    let found = cards.find(c => c && String(c.name || c.nombre || '').trim().toLowerCase() === cleanReqName);
    if (found) return found;

    found = cards.find(c => {
      const cName = String(c?.name || c?.nombre || '').trim().toLowerCase();
      return cName && (cleanReqName.includes(cName) || cName.includes(cleanReqName));
    });
    if (found) return found;
  }

  // 5. Coincidencia ID a nombre (ej: "kinan_hatake" -> "kinan hatake")
  if (withoutSuffix) {
    const idAsName = withoutSuffix.replace(/_/g, ' ').trim();
    const found = cards.find(c => {
      const cName = String(c?.name || c?.nombre || '').trim().toLowerCase();
      return cName === idAsName;
    });
    if (found) return found;
  }

  return null;
}
window.findCardInCatalog = findCardInCatalog;

function getCardQualityCategory(cardOrId) {
  let cardObj = null;
  let id = '';
  if (cardOrId && typeof cardOrId === 'object') {
    cardObj = cardOrId;
    id = String(cardOrId.id || cardOrId.cardId || cardOrId.card || cardOrId.card_id || '').trim();
  } else if (typeof cardOrId === 'string') {
    id = cardOrId.trim();
  }

  const lowerId = id.toLowerCase();
  if (lowerId.endsWith('_bronce') || lowerId === 'bronce') return 'bronce';
  if (lowerId.endsWith('_plata') || lowerId === 'plata') return 'plata';
  if (lowerId.endsWith('_oro') || lowerId === 'oro') return 'oro';

  let rawQuality = String(cardObj?.calidad || cardObj?.quality || cardObj?.calidadId || '').toLowerCase().trim();
  if (rawQuality.includes('bronce')) return 'bronce';
  if (rawQuality.includes('plata')) return 'plata';
  if (rawQuality.includes('oro')) return 'oro';

  if (id && typeof findCardInCatalog === 'function') {
    const found = findCardInCatalog(id);
    if (found) {
      const fQuality = String(found.calidad || found.quality || found.calidadId || '').toLowerCase().trim();
      const fId = String(found.id || '').toLowerCase().trim();
      if (fQuality.includes('bronce') || fId.endsWith('_bronce')) return 'bronce';
      if (fQuality.includes('plata') || fId.endsWith('_plata')) return 'plata';
      if (fQuality.includes('oro') || fId.endsWith('_oro')) return 'oro';
      if (fQuality) return fQuality;
    }
  }

  return rawQuality || 'otro';
}
window.getCardQualityCategory = getCardQualityCategory;

function getDuplicatePrestigeXp(cardOrId, xpRules = null) {
  const rules = xpRules || (typeof defaultPrestigeConfig !== 'undefined' ? defaultPrestigeConfig.xpRules : null) || {};
  const quality = getCardQualityCategory(cardOrId);
  if (quality === 'bronce') {
    const bronzeVal = Number(rules?.duplicateBronce ?? rules?.duplicateBronze);
    return Number.isFinite(bronzeVal) && bronzeVal >= 0 ? bronzeVal : 100;
  }
  if (quality === 'plata') {
    const silverVal = Number(rules?.duplicatePlata ?? rules?.duplicateSilver);
    return Number.isFinite(silverVal) && silverVal >= 0 ? silverVal : 250;
  }
  const defaultVal = Number(rules?.duplicateFromPackOrTrade);
  return Number.isFinite(defaultVal) && defaultVal >= 0 ? defaultVal : 500;
}
window.getDuplicatePrestigeXp = getDuplicatePrestigeXp;

function findTitleInCatalog(titleIdOrReward, allTitles = null) {
  const titles = (Array.isArray(allTitles) && allTitles.length > 0)
    ? allTitles
    : ((Array.isArray(rewardHudCatalogCache.titles) && rewardHudCatalogCache.titles.length > 0)
      ? rewardHudCatalogCache.titles
      : (Array.isArray(window.availableTitles) && window.availableTitles.length > 0
        ? window.availableTitles
        : []));

  let rawId = '';
  let rawName = '';
  if (typeof titleIdOrReward === 'string') {
    rawId = titleIdOrReward.trim();
  } else if (titleIdOrReward && typeof titleIdOrReward === 'object') {
    rawId = String(titleIdOrReward.titleId || titleIdOrReward.id || titleIdOrReward.title || '').trim();
    rawName = stripRewardTitleName(titleIdOrReward.name || titleIdOrReward.title || titleIdOrReward.label || '');
  }

  const normalizeStr = s => String(s || '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const normId = normalizeStr(rawId);
  const normName = normalizeStr(rawName);

  if (!titles || titles.length === 0) return null;

  // 1. Coincidencia exacta por ID normalizado
  if (normId) {
    let found = titles.find(t => t && normalizeStr(t.id) === normId);
    if (found) return found;
  }

  // 2. Coincidencia por nombre
  if (normName) {
    let found = titles.find(t => t && (normalizeStr(t.name) === normName || normalizeStr(t.titulo) === normName));
    if (found) return found;
  }

  // 3. Coincidencia ID contra nombre (ej: "dueño_electrones" -> "dueno electrones")
  if (normId) {
    const idWords = normId.replace(/_/g, ' ');
    let found = titles.find(t => {
      const tNorm = normalizeStr(t?.name || t?.titulo);
      return tNorm === idWords || tNorm.includes(idWords) || idWords.includes(tNorm);
    });
    if (found) return found;
  }

  return null;
}
window.findTitleInCatalog = findTitleInCatalog;

function resolveRewardTitleGradient(titleId, titleName, reward = null) {
  if (reward?.gradient) return reward.gradient;
  const found = findTitleInCatalog(reward || { titleId, name: titleName });
  if (found?.gradient) return found.gradient;
  return 'linear-gradient(135deg, #fef3c7 0%, #facc15 50%, #d4af37 100%)';
}

function resolveRewardCardImage(reward, allCards = null) {
  const explicit = reward?.imageUrl || reward?.iconUrl || reward?.image || reward?.icon || reward?.img;
  if (explicit && typeof explicit === 'string' && !explicit.includes('default-card') && !explicit.includes('icon-especiales')) {
    return normalizePrestigeAssetUrl(explicit);
  }

  const card = findCardInCatalog(reward, allCards);
  if (card) {
    const img = card.imageUrl || card.image || card.imagen;
    if (img && typeof img === 'string') {
      return normalizePrestigeAssetUrl(img);
    }
  }

  if (explicit && typeof explicit === 'string' && !explicit.includes('default-card')) {
    return normalizePrestigeAssetUrl(explicit);
  }

  return '';
}

function stripRewardTitleName(rawText) {
  if (typeof window.stripTitleFormatting === 'function') {
    return window.stripTitleFormatting(rawText);
  }
  if (!rawText) return '';
  let str = String(rawText);
  str = str.replace(/^(?:🏆|🃏|🎖️|🥇|🥈|🥉|\s)*(?:título|titulo)\s*:\s*/i, '');
  const emojiRegex = /(?:\p{Extended_Pictographic}|\p{Emoji_Presentation})(?:(?:\uFE0F|\uFE0E)|(?:\uD83C[\uDFFB-\uDFFF])|(?:\u200D(?:\p{Extended_Pictographic}|\p{Emoji_Presentation}))*)*/gu;
  str = str.replace(emojiRegex, '');
  str = str.replace(/^["'«»“”]+|["'«»“”]+$/g, '');
  return str.trim();
}

function getRewardImage(reward) {
  const type = String(reward?.type || reward?.tipo || '').toLowerCase();
  const name = String(reward?.name || reward?.title || reward?.label || '').toLowerCase();

  if (type === 'title' || type === 'titulo' || type === 'título' || reward?.titleId || name.includes('título') || name.includes('titulo')) {
    return ''; // Los títulos no llevan imagen
  }

  if (type === 'buff' || name.includes('buff') || reward?.stats) {
    return ''; // Los buffs llevan emoji de rayo ⚡
  }

  if (type === 'card' || type === 'carta' || reward?.cardId || name.includes('carta') || name.includes('card')) {
    const cardImg = resolveRewardCardImage(reward);
    if (cardImg) return cardImg;
  }

  const explicit = reward?.imageUrl || reward?.iconUrl || reward?.image || reward?.icon || reward?.img;
  if (explicit && !explicit.includes('default-card.png')) return String(explicit);

  if (type === 'infinite-coins' || type === 'infinite-coin' || name.includes('infinite-coin') || name.includes('infinite coin')) return './infinite-coin.png';
  if (type === 'infinite-cardpoints' || type === 'infinite-cardpoint' || name.includes('infinite-cardpoint') || name.includes('infinite cardpoint')) return './infinite-cardpoint.png';
  if (type === 'traits' || type === 'trait' || name.includes('trait')) return './trait.png';
  if (type === 'coins' || (!name.includes('infinite') && (name.includes('coin') || name.includes('moneda')))) return './coin.png';
  if (type === 'kvr' || name.includes('kvr')) return './kvr.png';
  if (type === 'pack' || name.includes('sobre') || name.includes('pack')) return './icon-especiales.png';

  return './icon-especiales.png';
}

const rewardHudCatalogCache = {
  cards: null,
  packs: null,
  titles: null
};

async function ensureRewardHudCatalogCache() {
  try {
    if (!Array.isArray(rewardHudCatalogCache.cards) || rewardHudCatalogCache.cards.length === 0) {
      if (typeof window.kvrcards?.getAllCards === 'function') {
        const res = await window.kvrcards.getAllCards();
        rewardHudCatalogCache.cards = Array.isArray(res) ? res : (Array.isArray(res?.cards) ? res.cards : (res ? Object.values(res) : []));
      }
    }
  } catch {
    rewardHudCatalogCache.cards = rewardHudCatalogCache.cards || [];
  }
  try {
    if (!Array.isArray(rewardHudCatalogCache.packs) || rewardHudCatalogCache.packs.length === 0) {
      if (typeof window.kvrcards?.getAllPacks === 'function') {
        const pRes = await window.kvrcards.getAllPacks();
        rewardHudCatalogCache.packs = Array.isArray(pRes) ? pRes : (Array.isArray(pRes?.packs) ? pRes.packs : (pRes ? Object.values(pRes) : []));
      }
    }
  } catch {
    rewardHudCatalogCache.packs = rewardHudCatalogCache.packs || [];
  }
  try {
    if (!Array.isArray(rewardHudCatalogCache.titles) || rewardHudCatalogCache.titles.length === 0) {
      if (typeof window.kvrcards?.getTitles === 'function') {
        const tRes = await window.kvrcards.getTitles();
        if (tRes && tRes.ok && Array.isArray(tRes.titles) && tRes.titles.length > 0) {
          rewardHudCatalogCache.titles = tRes.titles;
        }
      }
      if ((!rewardHudCatalogCache.titles || rewardHudCatalogCache.titles.length === 0) && Array.isArray(window.availableTitles) && window.availableTitles.length > 0) {
        rewardHudCatalogCache.titles = window.availableTitles;
      }
      if ((!rewardHudCatalogCache.titles || rewardHudCatalogCache.titles.length === 0) && typeof window.loadTitles === 'function') {
        const loaded = await window.loadTitles().catch(() => null);
        if (Array.isArray(loaded) && loaded.length > 0) {
          rewardHudCatalogCache.titles = loaded;
        }
      }
    }
  } catch {
    rewardHudCatalogCache.titles = rewardHudCatalogCache.titles || (Array.isArray(window.availableTitles) ? window.availableTitles : []);
  }
  try {
    if ((!Array.isArray(window.availableBackgrounds) || window.availableBackgrounds.length === 0) && typeof window.loadBackgrounds === 'function') {
      await window.loadBackgrounds();
    }
  } catch {}
}


function extractPrestigeLevelRewards(level) {
  if (!level) return [];
  const raw = level.rewards ?? level.reward ?? level.recompensas ?? level.recompensa;
  if (!raw) return [];
  if (Array.isArray(raw)) return raw;
  if (typeof raw === 'object') return [raw];
  return [];
}

function normalizePrestigeRewardItem(reward) {
  if (!reward) return null;
  if (typeof reward === 'string') {
    const text = reward.trim().toLowerCase();
    const num = Number((text.match(/(\d+)/) || [])[1]) || 1;
    if (text.includes('coin') || text.includes('moneda')) return { type: 'coins', amount: num, name: `${num} Coins` };
    if (text.includes('kvr')) return { type: 'kvr', amount: num, name: `${num} KvR` };
    if (text.includes('sobre') || text.includes('pack')) return { type: 'pack', packId: text.replace(/\d+/g, '').trim(), amount: num };
    if (text.includes('fondo') || text.includes('background')) return { type: 'background', backgroundId: text.replace(/\d+/g, '').trim() };
    if (text.includes('trait') || text.includes('rasgo')) return { type: 'traits', amount: num, name: `${num} Traits` };
    return { type: 'coins', amount: num, name: reward };
  }

  let type = String(reward.type || reward.tipo || reward.rewardType || reward.categoria || '').toLowerCase().trim();
  if (type === 'trait') type = 'traits';
  if (type === 'coin') type = 'coins';
  let amount = Number(reward.amount || reward.cantidad || reward.quantity || reward.count || reward.valor || 0);
  const rawName = String(reward.name || reward.nombre || reward.title || reward.label || reward.id || '').trim();

  if (!type) {
    const lower = rawName.toLowerCase();
    if (lower.includes('coin') || lower.includes('moneda')) type = 'coins';
    else if (lower.includes('kvr')) type = 'kvr';
    else if (lower.includes('sobre') || lower.includes('pack')) type = 'pack';
    else if (lower.includes('carta') || lower.includes('card')) type = 'card';
    else if (lower.includes('título') || lower.includes('titulo') || lower.includes('title')) type = 'title';
    else if (lower.includes('fondo') || lower.includes('background')) type = 'background';
    else if (lower.includes('trait') || lower.includes('rasgo')) type = 'traits';
    else if (reward.packId || reward.pack) type = 'pack';
    else if (reward.cardId || reward.card) type = 'card';
    else if (reward.titleId || reward.title) type = 'title';
    else if (reward.backgroundId || reward.fondoId) type = 'background';
  }

  if (!amount || amount <= 0) {
    const match = rawName.match(/(\d+)/);
    if (match) amount = Number(match[1]);
    else amount = 1;
  }

  const packId = String(reward.packId || reward.pack || (type === 'pack' ? (reward.id || rawName) : '')).trim();
  const cardId = String(reward.cardId || reward.card || (type === 'card' ? (reward.id || rawName) : '')).trim();
  const titleId = String(reward.titleId || reward.title || (type === 'title' ? (reward.id || rawName) : '')).trim();
  const backgroundId = String(reward.backgroundId || reward.fondoId || (type === 'background' ? (reward.id || rawName) : '')).trim();

  return {
    ...reward,
    type,
    amount,
    packId,
    cardId,
    titleId,
    backgroundId,
    name: rawName || reward.name
  };
}

async function buildRewardsHudItems(rawRewards = []) {
  await ensureRewardHudCatalogCache();
  const allCards = Array.isArray(rewardHudCatalogCache.cards) ? rewardHudCatalogCache.cards : [];
  const allPacks = Array.isArray(rewardHudCatalogCache.packs) ? rewardHudCatalogCache.packs : [];
  const allTitles = Array.isArray(rewardHudCatalogCache.titles) ? rewardHudCatalogCache.titles : (Array.isArray(window.availableTitles) ? window.availableTitles : []);
  const allBackgrounds = Array.isArray(window.availableBackgrounds) ? window.availableBackgrounds : [];

  const list = (Array.isArray(rawRewards) ? rawRewards : [rawRewards])
    .map(normalizePrestigeRewardItem)
    .filter(Boolean);

  return list.map((reward) => {
    const type = String(reward?.type || '').toLowerCase();
    const amount = Number(reward?.amount || reward?.cantidad || reward?.quantity || 1);

    if (type === 'coins') {
      return {
        type,
        name: `${Number(reward.amount || 0).toLocaleString('es-ES')} Coins`,
        imageUrl: './coin.png',
        amount: amount
      };
    }

    if (type === 'kvr') {
      return {
        type,
        name: `${Number(reward.amount || 0).toLocaleString('es-ES')} KvR`,
        imageUrl: './kvr.png',
        amount: amount
      };
    }

    if (type === 'traits' || type === 'trait') {
      return {
        type: 'traits',
        name: `${Number(reward.amount || 0).toLocaleString('es-ES')} Traits`,
        imageUrl: './trait.png',
        amount: amount
      };
    }

    if (type === 'infinite-coins' || type === 'infinite-coin') {
      return {
        type: 'infinite-coins',
        name: `${Number(reward.amount || 0).toLocaleString('es-ES')} Infinite Coins`,
        imageUrl: './infinite-coin.png',
        amount: amount
      };
    }

    if (type === 'infinite-cardpoints' || type === 'infinite-cardpoint') {
      return {
        type: 'infinite-cardpoints',
        name: `${Number(reward.amount || 0).toLocaleString('es-ES')} Infinite Card Points`,
        imageUrl: './infinite-cardpoint.png',
        amount: amount
      };
    }

    if (type === 'pack' || type === 'packs') {
      const packId = reward.packId || reward.id;
      const pack = allPacks.find(p => p.id === packId || String(p.id).toLowerCase() === String(packId).toLowerCase());
      const rawName = pack?.name || String(reward.packId || '').replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
      const baseName = rawName.replace(/^(?:sobre|pack)\s+/i, '').trim();
      const displayName = amount > 1 ? `${amount} Sobres ${baseName}` : `Sobre ${baseName}`;
      let packImg = pack?.imageUrl || pack?.image || reward?.imageUrl || reward?.iconUrl || '';
      if (!packImg) {
        const lower = String(reward.packId || '').toLowerCase();
        if (lower.includes('bronce') || lower.includes('bronze')) packImg = './icon-bronce.png';
        else if (lower.includes('plata') || lower.includes('silver')) packImg = './icon-plata.png';
        else if (lower.includes('oro') || lower.includes('gold')) packImg = './icon-oro.png';
        else if (lower.includes('heroe') || lower.includes('hero')) packImg = './icon-heroe.png';
        else if (lower.includes('icono') || lower.includes('icon')) packImg = './icon-icono.png';
        else packImg = './icon-especiales.png';
      }
      return {
        type,
        name: displayName,
        imageUrl: packImg,
        amount: amount
      };
    }

    if (type === 'card') {
      const rawCardId = String(reward.cardId || reward.id || reward.card || reward.card_id || '').trim();
      const card = findCardInCatalog(reward, allCards);
      const targetCardId = card?.id || rawCardId;
      const cardName = card?.name || card?.nombre || reward.name || rawCardId;
      const cleanCardName = String(cardName).replace(/^(?:🃏|\s)*(?:carta)\s*:\s*/i, '').trim();
      const displayName = amount > 1 ? `${amount}x Carta: ${cleanCardName}` : `Carta: ${cleanCardName}`;
      const cardImg = (reward.imageUrl && !reward.imageUrl.includes('default-card') && !reward.imageUrl.includes('icon-especiales'))
        ? normalizePrestigeAssetUrl(reward.imageUrl)
        : (card?.imageUrl ? normalizePrestigeAssetUrl(card.imageUrl) : (card?.image || card?.imagen || resolveRewardCardImage(reward, allCards)));
      return {
        type: 'card',
        name: displayName,
        cleanName: cleanCardName,
        imageUrl: cardImg || './icon-especiales.png',
        cardId: targetCardId,
        rawCardId: rawCardId,
        card,
        quality: card?.calidad || card?.quality || 'oro',
        amount: amount
      };
    }

    if (type === 'title') {
      const rawTitleId = String(reward.titleId || reward.id || reward.title || '').trim();
      const title = findTitleInCatalog(reward, allTitles);
      const targetTitleId = title?.id || rawTitleId;
      const rawName = title?.name || title?.titulo || reward.name || String(rawTitleId || '').replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
      const cleanName = stripRewardTitleName(rawName);
      const gradient = title?.gradient || reward?.gradient || resolveRewardTitleGradient(rawTitleId, cleanName, reward);
      return {
        type: 'title',
        name: cleanName,
        cleanTitle: cleanName,
        titleId: targetTitleId,
        rawTitleId: rawTitleId,
        gradient: gradient,
        titleObj: title,
        amount: 1
      };
    }

    if (type === 'background' || type === 'fondo') {
      const bgId = String(reward.backgroundId || reward.fondoId || reward.id || '').trim();
      const bg = allBackgrounds.find(b => b.id === bgId || String(b.id).toLowerCase() === bgId.toLowerCase());
      const bgName = bg?.nombre || bg?.name || reward.name || bgId;
      const bgImg = bg?.imagen || bg?.image || bg?.imageUrl || reward?.imageUrl || './assets/backgrounds/bg_default.jpg';
      return {
        type: 'background',
        name: `Fondo: ${bgName}`,
        imageUrl: bgImg,
        amount: 1
      };
    }

    if (type === 'buff') {
      const buffName = reward.name || 'Buff Kizuna';
      const statsObj = reward.stats || reward.efecto || {};
      const statParts = [];
      for (const [sKey, sVal] of Object.entries(statsObj)) {
        const sName = sKey.charAt(0).toUpperCase() + sKey.slice(1);
        statParts.push(`+${sVal}% ${sName}`);
      }
      const desc = reward.description || (statParts.length > 0 ? statParts.join(', ') : 'Buff exclusivo');
      return {
        type: 'buff',
        name: buffName,
        cleanName: buffName,
        description: desc,
        emoji: '⚡',
        imageUrl: '',
        amount: 1
      };
    }

    return {
      type,
      name: getRewardName(reward),
      imageUrl: getRewardImage(reward),
      amount: amount
    };
  });
}

function ensureRewardsClaimHud() {
  let overlay = document.getElementById('rewards-claim-overlay');
  if (overlay) return overlay;

  overlay = document.createElement('div');
  overlay.id = 'rewards-claim-overlay';
  overlay.className = 'rewards-claim-overlay';
  overlay.innerHTML = `
    <div class="rewards-claim-modal" role="dialog" aria-modal="true" aria-label="Recompensas reclamadas">
      <h2 class="rewards-claim-title">RECOMPENSAS RECLAMADAS</h2>
      <div class="rewards-claim-grid"></div>
      <div class="rewards-claim-selected">Haz clic en una recompensa para ver su nombre.</div>
      <button type="button" class="rewards-claim-close">Continuar</button>
    </div>
  `;

  const closeBtn = overlay.querySelector('.rewards-claim-close');
  closeBtn?.addEventListener('click', () => {
    overlay.classList.remove('show');
  });

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) overlay.classList.remove('show');
  });

  document.body.appendChild(overlay);
  return overlay;
}

function showRewardsClaimHUD(rewards, titleText = 'RECOMPENSAS RECLAMADAS') {
  const normalizedRewards = Array.isArray(rewards) && rewards.length > 0
    ? rewards
    : [{ name: 'Recompensa' }];

  const overlay = ensureRewardsClaimHud();
  const title = overlay.querySelector('.rewards-claim-title');
  const grid = overlay.querySelector('.rewards-claim-grid');
  const selected = overlay.querySelector('.rewards-claim-selected');

  if (title) title.textContent = String(titleText || 'RECOMPENSAS RECLAMADAS');
  if (selected) selected.textContent = 'Haz clic en una recompensa para ver su nombre.';

  if (grid) {
    grid.innerHTML = '';
    normalizedRewards.forEach((reward, idx) => {
      const rawType = String(reward.type || reward.tipo || '').toLowerCase();
      const rawName = String(reward.name || reward.title || reward.label || reward.text || 'Recompensa');
      const amount = Number(reward.amount || reward.cantidad || reward.quantity || 1);

      const isTitle = rawType === 'title' || rawType === 'titulo' || rawType === 'título'
        || Boolean(reward.titleId)
        || /^(?:🏆|\s)*(?:título|titulo)\s*:/i.test(rawName);

      const isCard = !isTitle && (rawType === 'card' || rawType === 'carta'
        || Boolean(reward.cardId)
        || /^(?:🃏|\s)*(?:carta)\s*:/i.test(rawName));

      const isBuff = !isTitle && !isCard && (
        rawType === 'buff'
        || Boolean(reward.stats)
        || /^(?:⚡|\s)*(?:buff)\s*:/i.test(rawName)
        || rawName.toLowerCase().includes('buff')
      );

      const card = document.createElement('button');
      card.type = 'button';
      card.style.animationDelay = `${idx * 60}ms`;

      if (isTitle) {
        // ==================== TÍTULO ====================
        // Sin emoji ni imagen, recuadro rectangular, nombre centrado con gradiente
        card.className = 'rewards-claim-item rewards-claim-item-title';
        const cleanTitle = stripRewardTitleName(reward.cleanTitle || reward.cleanName || rawName);
        const titleId = reward.titleId || reward.id || '';
        const gradient = resolveRewardTitleGradient(titleId, cleanTitle, reward);

        card.innerHTML = `
          <div class="rewards-claim-title-inner">
            <span class="rewards-claim-title-text" style="background-image: ${gradient};">${escapeHtml(cleanTitle)}</span>
          </div>
        `;

        card.addEventListener('click', () => {
          if (selected) selected.textContent = `Título: ${cleanTitle}`;
        });

      } else if (isCard) {
        // ==================== CARTA ====================
        // Imagen propia de la carta, recuadro adaptado a carta
        card.className = 'rewards-claim-item rewards-claim-item-card';
        const cleanCardName = String(reward.cleanName || rawName).replace(/^(?:🃏|\s)*(?:carta)\s*:\s*/i, '').trim();
        const displayName = amount > 1 ? `${amount}x Carta: ${cleanCardName}` : `Carta: ${cleanCardName}`;

        let cardImage = (reward.imageUrl && !reward.imageUrl.includes('default-card') && !reward.imageUrl.includes('icon-especiales'))
          ? reward.imageUrl
          : resolveRewardCardImage(reward);

        const badgeHtml = (amount > 1)
          ? `<div class="reward-amount-badge">${amount}</div>`
          : '';

        card.innerHTML = `<img src="${cardImage || './icon-especiales.png'}" alt="${cleanCardName}">${badgeHtml}`;

        // Si la imagen aún no estaba en caché síncrono, resolverla asíncronamente
        if (!cardImage && window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
          window.kvrcards.getAllCards().then(res => {
            const cards = Array.isArray(res) ? res : (Array.isArray(res?.cards) ? res.cards : (res ? Object.values(res) : []));
            rewardHudCatalogCache.cards = cards;
            const asyncImage = resolveRewardCardImage(reward, cards);
            if (asyncImage) {
              const imgEl = card.querySelector('img');
              if (imgEl) imgEl.src = asyncImage;
            }
          }).catch(() => {});
        }

        card.addEventListener('click', () => {
          if (selected) selected.textContent = displayName;
        });

      } else if (isBuff) {
        // ==================== BUFF DE KIZUNA ====================
        // Emoji de rayo ⚡ en lugar de imagen estática
        card.className = 'rewards-claim-item rewards-claim-item-buff';
        const cleanBuffName = String(reward.cleanName || reward.name || rawName).replace(/^(?:⚡|\s)*(?:buff)\s*:\s*/i, '').trim();
        const buffDesc = reward.description || reward.desc || '';
        const displayName = `⚡ Buff: ${cleanBuffName}`;

        card.innerHTML = `
          <div class="rewards-claim-buff-inner">
            <span class="rewards-claim-buff-emoji">⚡</span>
            <span class="rewards-claim-buff-label">${escapeHtml(cleanBuffName)}</span>
          </div>
        `;

        card.addEventListener('click', () => {
          if (selected) {
            selected.textContent = buffDesc ? `${displayName} (${buffDesc})` : displayName;
          }
        });

      } else {
        // ==================== OTRAS RECOMPENSAS ====================
        card.className = 'rewards-claim-item';
        const image = getRewardImage(reward);
        const isCurrency = rawType === 'coins' || rawType === 'kvr' || rawName.toLowerCase().includes('coin') || rawName.toLowerCase().includes('kvr');

        const badgeHtml = (amount > 1 && !isCurrency)
          ? `<div class="reward-amount-badge">${amount}</div>`
          : '';

        card.innerHTML = `<img src="${image}" alt="${rawName}">${badgeHtml}`;
        card.addEventListener('click', () => {
          if (selected) selected.textContent = rawName;
        });
      }

      grid.appendChild(card);
    });
  }

  // Forzar reflow para que la animación siempre dispare desde cero
  overlay.classList.remove('show');
  void overlay.offsetHeight;
  requestAnimationFrame(() => {
    overlay.classList.add('show');
  });
}

window.showRewardsClaimHUD = showRewardsClaimHUD;

async function showUnifiedRewardsHUD(claimedRewards, title = 'RECOMPENSAS RECLAMADAS') {
  if (!Array.isArray(claimedRewards) || claimedRewards.length === 0) {
    console.warn('[REWARDS] No hay recompensas para mostrar en el HUD');
    return;
  }
  try {
    const hudRewards = await buildRewardsHudItems(claimedRewards);
    showRewardsClaimHUD(hudRewards, title);
  } catch (error) {
    console.error('[REWARDS] Error al mostrar HUD de recompensas unificado:', error);
  }
}
window.showUnifiedRewardsHUD = showUnifiedRewardsHUD;

async function grantPrestigeRewards(rewards = []) {
  const normRewards = (Array.isArray(rewards) ? rewards : [rewards])
    .map(normalizePrestigeRewardItem)
    .filter(Boolean);

  if (normRewards.length === 0) return;

  await ensureRewardHudCatalogCache();
  const allCards = Array.isArray(rewardHudCatalogCache.cards) ? rewardHudCatalogCache.cards : [];
  const allTitles = Array.isArray(rewardHudCatalogCache.titles) ? rewardHudCatalogCache.titles : (Array.isArray(window.availableTitles) ? window.availableTitles : []);

  let walletUpdated = false;
  let collectionUpdated = false;
  let titlesUpdated = false;

  for (const reward of normRewards) {
    const type = String(reward?.type || '').toLowerCase();
    const amount = Number(reward?.amount || reward?.cantidad || reward?.quantity || reward?.count || 1) || 1;

    try {
      if (type === 'coins') {
        if (window.kvrcards?.addCoins) {
          const res = await window.kvrcards.addCoins(amount);
          if (res?.ok) walletUpdated = true;
        } else if (window.userProfile) {
          window.userProfile.coins = (Number(window.userProfile.coins) || 0) + amount;
          walletUpdated = true;
          if (typeof saveUserProfile === 'function') await saveUserProfile();
        }
        console.log(`[PRESTIGE] [OK] +${amount} Coins otorgadas`);

      } else if (type === 'kvr') {
        if (window.kvrcards?.addKvR) {
          const res = await window.kvrcards.addKvR(amount);
          if (res?.ok) walletUpdated = true;
        } else if (window.userProfile) {
          window.userProfile.kvr = (Number(window.userProfile.kvr) || 0) + amount;
          walletUpdated = true;
          if (typeof saveUserProfile === 'function') await saveUserProfile();
        }
        console.log(`[PRESTIGE] [OK] +${amount} KvR otorgados`);

      } else if (type === 'traits' || type === 'trait') {
        let traitGiven = false;
        if (window.kvrcards?.addTraits) {
          const res = await window.kvrcards.addTraits(amount);
          if (res?.ok) {
            walletUpdated = true;
            traitGiven = true;
          }
        }
        if (!traitGiven && window.kvrcards?.debugModifyTraits) {
          const res = await window.kvrcards.debugModifyTraits(amount);
          if (res?.ok) {
            walletUpdated = true;
            traitGiven = true;
          }
        }
        if (!traitGiven) {
          if (window.userProfile) {
            window.userProfile.traits = (Number(window.userProfile.traits) || 0) + amount;
            walletUpdated = true;
            traitGiven = true;
            if (typeof saveUserProfile === 'function') await saveUserProfile();
          }
          try {
            const cur = Number(localStorage.getItem('kvr_wallet_traits')) || 0;
            localStorage.setItem('kvr_wallet_traits', String(cur + amount));
            walletUpdated = true;
            traitGiven = true;
          } catch {}
        }
        console.log(`[PRESTIGE] [OK] +${amount} Traits otorgados`);

      } else if (type === 'infinite-coins' || type === 'infinite-coin') {
        if (typeof window.infiniteAddCurrency === 'function') {
          window.infiniteAddCurrency('infinite-coins', amount);
        }
        console.log(`[PRESTIGE] [OK] +${amount} Infinite Coins otorgadas`);

      } else if (type === 'infinite-cardpoints' || type === 'infinite-cardpoint') {
        if (typeof window.infiniteAddCurrency === 'function') {
          window.infiniteAddCurrency('infinite-cardpoints', amount);
        }
        console.log(`[PRESTIGE] [OK] +${amount} Infinite Cardpoints otorgados`);

      } else if (type === 'pack' || type === 'packs') {
        const packId = String(reward?.packId || reward?.id || '').trim();
        if (packId) {
          if (window.kvrcards?.addPack) {
            const res = await window.kvrcards.addPack(packId, amount);
            if (res?.ok) walletUpdated = true;
          }
          console.log(`[PRESTIGE] [OK] Sobre ${packId} x${amount} otorgado`);
        }

      } else if (type === 'card') {
        const matchedCard = findCardInCatalog(reward, allCards);
        const cardId = matchedCard?.id || String(reward?.cardId || reward?.id || '').trim();
        if (cardId) {
          if (window.kvrcards?.addCard) {
            for (let i = 0; i < amount; i++) {
              await window.kvrcards.addCard(cardId);
            }
            collectionUpdated = true;
          } else {
            try {
              const stored = localStorage.getItem('kvr_owned_cards') || '{}';
              const inv = JSON.parse(stored);
              inv[cardId] = (inv[cardId] || 0) + amount;
              localStorage.setItem('kvr_owned_cards', JSON.stringify(inv));
              collectionUpdated = true;
            } catch {}
          }
          console.log(`[PRESTIGE] [OK] Carta ${cardId} (original: ${reward.cardId || cardId}) x${amount} otorgada`);
        }

      } else if (type === 'title') {
        const matchedTitle = findTitleInCatalog(reward, allTitles);
        const tId = matchedTitle?.id || String(reward?.titleId || reward?.id || '').trim();
        const tName = matchedTitle?.name || String(reward?.name || '').trim();

        let prof = window.userProfile;
        if (!prof && typeof userProfile !== 'undefined') prof = userProfile;
        if (!prof) {
          try {
            const stored = localStorage.getItem('kvr_user_profile') || localStorage.getItem('userProfile');
            if (stored) prof = JSON.parse(stored);
          } catch {}
        }
        if (!prof) prof = {};
        if (!Array.isArray(prof.unlockedTitles)) prof.unlockedTitles = ['novato'];

        let added = false;
        if (tId && !prof.unlockedTitles.includes(tId)) {
          prof.unlockedTitles.push(tId);
          added = true;
        }
        if (tName && !prof.unlockedTitles.includes(tName)) {
          prof.unlockedTitles.push(tName);
          added = true;
        }

        window.userProfile = prof;
        if (typeof userProfile !== 'undefined') userProfile = prof;

        try {
          if (typeof saveUserProfile === 'function') {
            await saveUserProfile();
          } else if (typeof window.saveUserProfile === 'function') {
            await window.saveUserProfile();
          } else {
            localStorage.setItem('kvr_user_profile', JSON.stringify(prof));
          }
          titlesUpdated = true;
          console.log(`[PRESTIGE] [OK] Título "${tName || tId}" (ID: ${tId}) desbloqueado con éxito`);
        } catch (e) {
          console.warn('[PRESTIGE] Error guardando título:', e);
        }

      } else if (type === 'background' || type === 'fondo') {
        const bgId = String(reward?.backgroundId || reward?.fondoId || reward?.id || '').trim();
        if (bgId) {
          if (typeof window.unlockProfileBackground === 'function') {
            await window.unlockProfileBackground(bgId);
          } else if (typeof unlockProfileBackground === 'function') {
            await unlockProfileBackground(bgId);
          } else if (window.userProfile) {
            if (!Array.isArray(window.userProfile.unlockedBackgrounds)) window.userProfile.unlockedBackgrounds = ['default'];
            if (!window.userProfile.unlockedBackgrounds.includes(bgId)) {
              window.userProfile.unlockedBackgrounds.push(bgId);
              if (typeof saveUserProfile === 'function') await saveUserProfile();
            }
          }
          console.log(`[PRESTIGE] [OK] Fondo de perfil ${bgId} desbloqueado`);
        }
      }
    } catch (err) {
      console.warn('[PRESTIGE] Error al otorgar recompensa:', reward, err);
    }
  }

  if (walletUpdated) {
    if (typeof renderWallet === 'function') renderWallet().catch(() => {});
    if (typeof renderOwnedPacks === 'function') renderOwnedPacks().catch(() => {});
    if (typeof renderTraitsPanel === 'function') renderTraitsPanel();
    if (typeof window.renderTraitsPanel === 'function') window.renderTraitsPanel();
  }
  if (collectionUpdated) {
    if (typeof renderCollection === 'function') renderCollection().catch(() => {});
  }
  if (titlesUpdated) {
    if (typeof updateProfileDisplay === 'function') updateProfileDisplay();
    if (typeof updateTitleSelector === 'function') updateTitleSelector();
    if (typeof renderTitles === 'function') renderTitles();
  }
}
window.grantPrestigeRewards = grantPrestigeRewards;

function renderPrestigeMissionsAndRewards(prestigePanel, prestigeData, config, card) {
  if (!prestigePanel) return;
  const missionsContainer = prestigePanel.querySelector('.inventory-prestige-missions-list');
  const giftsContainer = prestigePanel.querySelector('.inventory-prestige-gifts');
  const profile = resolvePrestigeProfile(config, card);
  const levels = Array.isArray(profile?.levels) ? profile.levels : [];
  const numericLevel = Math.max(0, Number(prestigeData?.level) || 0);
  const currentPrestigeForMissions = Math.max(1, numericLevel <= 0 ? 1 : numericLevel);
  const missionLevels = levels
    .filter((lvl) => (Number(lvl?.prestige) || 0) <= currentPrestigeForMissions)
    .sort((a, b) => (Number(a?.prestige) || 0) - (Number(b?.prestige) || 0));

  if (missionLevels.length === 0 && levels.length > 0) {
    missionLevels.push(levels[0]);
  }

  const refreshPrestigePanel = () => {
    const thresholds = getPrestigeThresholds(levels);
    const updatedPrestigeData = getInventoryPrestigeData(0, thresholds, card?.id);

    const currentLabel = prestigePanel.querySelector('.inventory-prestige-current-label');
    if (currentLabel) currentLabel.textContent = `Prestigio ${updatedPrestigeData.level}`;

    const xpLabel = prestigePanel.querySelector('.inventory-prestige-progress-header span:last-child');
    if (xpLabel) xpLabel.textContent = `${updatedPrestigeData.xp.toLocaleString('es-ES')} XP`;

    const fillLarge = prestigePanel.querySelector('.inventory-prestige-progress-fill');
    if (fillLarge) fillLarge.style.width = `${updatedPrestigeData.progress}%`;

    const fillTop = document.querySelector('.inventory-card-meta .inventory-prestige-bar-fill');
    if (fillTop) fillTop.style.width = `${updatedPrestigeData.progress}%`;

    const metaValue = document.querySelector('.inventory-card-meta-row.inventory-prestige-block .inventory-card-meta-value');
    if (metaValue) metaValue.textContent = `Prestigio ${updatedPrestigeData.level}`;

    const thresholdsText = prestigePanel.querySelector('.inventory-prestige-thresholds');
    if (thresholdsText) thresholdsText.textContent = `${updatedPrestigeData.thresholds.join(' | ')} XP`;

    renderPrestigeMissionsAndRewards(prestigePanel, updatedPrestigeData, config, card);
  };

  if (missionsContainer) {
    const stackedMissions = missionLevels.flatMap((lvl) => {
      const sourcePrestige = Number(lvl?.prestige) || 1;
      const levelMissions = Array.isArray(lvl?.missions) ? lvl.missions : [];
      return levelMissions.map((mission, idx) => ({
        mission,
        sourcePrestige,
        idx
      }));
    });

    if (stackedMissions.length === 0) {
      missionsContainer.classList.remove('stacked-scroll');
      missionsContainer.innerHTML = '<div class="inventory-prestige-mission-item">Sin misiones configuradas para este prestigio.</div>';
    } else {
      const cardProgress = getPrestigeProgressEntry(card?.id, false);
      const missionRows = stackedMissions
        .map(({ mission: m, sourcePrestige, idx }) => {
          const missionName = String(m?.name || m?.text || 'Mision sin nombre');
          const missionXp = Math.max(0, Number(m?.xp) || 0);
          const baseMissionId = String(m?.id || `mission_${idx + 1}`);
          const missionKey = `p${sourcePrestige}_${baseMissionId}`;
          const legacyClaimKey = m?.id ? getPrestigeMissionClaimKey(card?.id, String(m.id)) : '';
          const claimKey = getPrestigeMissionClaimKey(card?.id, missionKey);
          const claimed = (() => {
            try {
              return localStorage.getItem(claimKey) === '1' || (!!legacyClaimKey && localStorage.getItem(legacyClaimKey) === '1');
            } catch {
              return false;
            }
          })();
          const missionProgress = getMissionProgressForCard(m, cardProgress);
          if (!missionProgress) {
            const keepVisible = sourcePrestige === currentPrestigeForMissions;
            if (!keepVisible) return '';
            return `
              <div class="inventory-prestige-mission-item">
                <span><span class="inventory-prestige-mission-level">P${sourcePrestige}</span>${missionName}</span>
                <span class="inventory-prestige-mission-counter">Sin progreso</span>
              </div>
            `;
          }

          const current = Math.min(missionProgress.current, missionProgress.target);
          const completed = current >= missionProgress.target;
          const canClaim = completed && !claimed;
          const keepVisible = sourcePrestige === currentPrestigeForMissions || !completed || !claimed;
          if (!keepVisible) return '';

          const statusText = claimed
            ? 'Reclamada'
            : (canClaim ? `Reclamar +${missionXp} XP` : `${current}/${missionProgress.target}`);

          return `
            <div class="inventory-prestige-mission-item">
              <span><span class="inventory-prestige-mission-level">P${sourcePrestige}</span>${missionName}${missionXp > 0 ? ` (+${missionXp} XP)` : ''}</span>
              ${canClaim
                ? `<button type="button" class="inventory-prestige-mission-claim" data-mission-id="${missionKey}" data-legacy-claim-key="${legacyClaimKey}" data-mission-xp="${missionXp}">${statusText}</button>`
                : `<span class="inventory-prestige-mission-counter ${claimed ? 'claimed' : ''}">${statusText}</span>`}
            </div>
          `;
        })
        .filter(Boolean);

      if (missionRows.length === 0) {
        missionsContainer.classList.remove('stacked-scroll');
        missionsContainer.innerHTML = '<div class="inventory-prestige-mission-item">No hay misiones pendientes en prestigios anteriores.</div>';
      } else {
        missionsContainer.classList.toggle('stacked-scroll', missionRows.length > 5);
        missionsContainer.innerHTML = missionRows.join('');
      }

      missionsContainer.querySelectorAll('.inventory-prestige-mission-claim').forEach((claimBtn) => {
        claimBtn.addEventListener('click', () => {
          const missionId = String(claimBtn.getAttribute('data-mission-id') || '').trim();
          const legacyClaimKey = String(claimBtn.getAttribute('data-legacy-claim-key') || '').trim();
          const missionXp = Math.max(0, Number(claimBtn.getAttribute('data-mission-xp')) || 0);
          if (!missionId || !card?.id) return;

          const claimKey = getPrestigeMissionClaimKey(card.id, missionId);
          try {
            if (localStorage.getItem(claimKey) === '1' || (!!legacyClaimKey && localStorage.getItem(legacyClaimKey) === '1')) return;
            localStorage.setItem(claimKey, '1');
            if (legacyClaimKey) localStorage.setItem(legacyClaimKey, '1');
          } catch {
            return;
          }

          const store = loadPrestigeProgressStore();
          const cardId = normalizePrestigeCardId(card.id);
          if (!cardId) return;

          const current = store[cardId] && typeof store[cardId] === 'object'
            ? store[cardId]
            : { battlesPlayed: 0, battlesWon: 0, battleXp: 0, missionXp: 0 };

          current.battlesPlayed = Math.max(0, Number(current.battlesPlayed) || 0);
          current.battlesWon = Math.max(0, Number(current.battlesWon) || 0);
          current.battleXp = Math.max(0, Number(current.battleXp) || 0);
          current.missionXp = Math.max(0, Number(current.missionXp) || 0) + missionXp;
          current.updatedAt = Date.now();
          store[cardId] = current;
          savePrestigeProgressStore(store);

          refreshPrestigePanel();
        });
      });
    }
  }

  if (giftsContainer) {
    const closeGiftPreviewBubble = () => {
      giftsContainer.querySelectorAll('.inventory-prestige-gift-bubble').forEach((bubble) => bubble.remove());
      giftsContainer.dataset.previewPrestige = '';
    };

    if (window.__inventoryPrestigeGiftPreviewVisibilityHandler) {
      document.removeEventListener('visibilitychange', window.__inventoryPrestigeGiftPreviewVisibilityHandler);
    }
    window.__inventoryPrestigeGiftPreviewVisibilityHandler = () => {
      if (document.hidden) closeGiftPreviewBubble();
    };
    document.addEventListener('visibilitychange', window.__inventoryPrestigeGiftPreviewVisibilityHandler);

    let hoverTimeout = null;

    const renderGiftPreviewBubble = async (targetBtn, prestige, rawRewards = [], options = {}) => {
      if (!targetBtn || !giftsContainer) return;
      const claimedPreview = options?.claimed === true;
      const unlocked = options?.unlocked === true;

      closeGiftPreviewBubble();

      const bubble = document.createElement('div');
      bubble.className = 'inventory-prestige-gift-bubble';
      if (claimedPreview) bubble.classList.add('claimed-preview');
      else if (unlocked) bubble.classList.add('unlocked-preview');

      const bubbleTitle = document.createElement('div');
      bubbleTitle.className = 'inventory-prestige-gift-bubble-title';
      bubbleTitle.textContent = claimedPreview
        ? `Recompensa reclamada - Prestigio ${prestige}`
        : (unlocked ? `🎁 ¡Prestigio ${prestige} Desbloqueado! (Clic para reclamar)` : `Recompensas Prestigio ${prestige}`);
      bubble.appendChild(bubbleTitle);

      const bubbleGrid = document.createElement('div');
      bubbleGrid.className = 'inventory-prestige-gift-bubble-grid';

      const normRewards = (Array.isArray(rawRewards) ? rawRewards : [rawRewards])
        .map(normalizePrestigeRewardItem)
        .filter(Boolean);

      const items = await buildRewardsHudItems(normRewards);
      if (items.length === 0) {
        const emptyItem = document.createElement('div');
        emptyItem.className = 'inventory-prestige-gift-bubble-empty';
        emptyItem.textContent = 'Sin recompensas configuradas';
        bubbleGrid.appendChild(emptyItem);
      } else {
        items.forEach((item) => {
          const rewardBox = document.createElement('div');
          rewardBox.className = 'inventory-prestige-gift-bubble-item';

          if (item.type === 'title') {
            rewardBox.classList.add('inventory-prestige-gift-bubble-item-title');

            const crownEl = document.createElement('span');
            crownEl.className = 'inventory-prestige-gift-bubble-crown';
            crownEl.textContent = '👑';
            rewardBox.appendChild(crownEl);

            const infoWrap = document.createElement('div');
            infoWrap.className = 'inventory-prestige-gift-bubble-info inventory-prestige-gift-bubble-info-title';

            const typeTag = document.createElement('span');
            typeTag.className = 'inventory-prestige-gift-bubble-type-tag';
            typeTag.textContent = 'Título: ';
            infoWrap.appendChild(typeTag);

            const titleName = item.cleanTitle || String(item.name || 'Título').replace(/^Título:\s*/i, '');
            const nameSpan = document.createElement('span');
            nameSpan.className = 'inventory-prestige-gift-bubble-name inventory-prestige-gift-bubble-title-text';
            nameSpan.style.backgroundImage = item.gradient || 'linear-gradient(135deg, #fef3c7 0%, #facc15 50%, #d4af37 100%)';
            nameSpan.style.webkitBackgroundClip = 'text';
            nameSpan.style.backgroundClip = 'text';
            nameSpan.style.color = 'transparent';
            nameSpan.style.fontWeight = '800';
            nameSpan.textContent = titleName;
            infoWrap.appendChild(nameSpan);

            rewardBox.appendChild(infoWrap);

          } else if (item.type === 'card') {
            rewardBox.classList.add('inventory-prestige-gift-bubble-item-card');

            const rewardImg = document.createElement('img');
            rewardImg.className = 'inventory-prestige-gift-bubble-card-img';
            const cardImgSrc = (item.imageUrl && !item.imageUrl.includes('default-card'))
              ? item.imageUrl
              : (resolveRewardCardImage(item) || './icon-especiales.png');
            rewardImg.src = cardImgSrc;
            rewardImg.alt = String(item?.cleanName || item?.name || 'Carta');
            rewardBox.appendChild(rewardImg);

            const infoWrap = document.createElement('div');
            infoWrap.className = 'inventory-prestige-gift-bubble-info';

            const nameSpan = document.createElement('span');
            nameSpan.className = 'inventory-prestige-gift-bubble-name';
            const cleanName = item?.cleanName || String(item?.name || 'Carta').replace(/^(?:\d+x\s*)?Carta:\s*/i, '');
            const displayName = item?.amount > 1 ? `${item.amount}x Carta: ${cleanName}` : `Carta: ${cleanName}`;
            nameSpan.textContent = displayName;
            infoWrap.appendChild(nameSpan);

            const quality = item?.quality || item?.card?.calidad || item?.card?.quality;
            if (quality) {
              const qBadge = document.createElement('span');
              qBadge.className = `inventory-prestige-gift-bubble-quality-badge quality-${String(quality).toLowerCase()}`;
              qBadge.textContent = String(quality).toUpperCase();
              infoWrap.appendChild(qBadge);
            }

            rewardBox.appendChild(infoWrap);

          } else if (item.type === 'buff') {
            rewardBox.classList.add('inventory-prestige-gift-bubble-item-buff');

            const buffIcon = document.createElement('span');
            buffIcon.className = 'inventory-prestige-gift-bubble-crown';
            buffIcon.textContent = '⚡';
            rewardBox.appendChild(buffIcon);

            const infoWrap = document.createElement('div');
            infoWrap.className = 'inventory-prestige-gift-bubble-info';

            const nameSpan = document.createElement('span');
            nameSpan.className = 'inventory-prestige-gift-bubble-name';
            nameSpan.textContent = String(item?.name || 'Buff');
            infoWrap.appendChild(nameSpan);

            rewardBox.appendChild(infoWrap);

          } else {
            const rewardImg = document.createElement('img');
            rewardImg.src = String(item?.imageUrl || (item.type === 'kvr' ? './kvr.png' : './coin.png'));
            rewardImg.alt = String(item?.name || 'Recompensa');
            rewardBox.appendChild(rewardImg);

            const infoWrap = document.createElement('div');
            infoWrap.className = 'inventory-prestige-gift-bubble-info';

            const nameSpan = document.createElement('span');
            nameSpan.className = 'inventory-prestige-gift-bubble-name';
            nameSpan.textContent = String(item?.name || 'Recompensa');
            infoWrap.appendChild(nameSpan);

            rewardBox.appendChild(infoWrap);
          }

          bubbleGrid.appendChild(rewardBox);
        });
      }

      bubble.appendChild(bubbleGrid);
      giftsContainer.appendChild(bubble);

      const targetRect = targetBtn.getBoundingClientRect();
      const giftsRect = giftsContainer.getBoundingClientRect();
      const targetCenter = (targetRect.left - giftsRect.left) + (targetRect.width / 2);

      bubble.style.left = `${targetCenter}px`;

      const halfWidth = bubble.offsetWidth / 2;
      const minCenter = Math.max(halfWidth + 8, 8);
      const maxCenter = Math.max(minCenter, giftsRect.width - halfWidth - 8);
      const clampedCenter = Math.max(minCenter, Math.min(targetCenter, maxCenter));
      bubble.style.left = `${clampedCenter}px`;
      giftsContainer.dataset.previewPrestige = String(prestige);

      requestAnimationFrame(() => {
        bubble.classList.add('show');
      });
    };

    const total = Math.max(1, levels.length);
    giftsContainer.innerHTML = levels.map((lvl, idx) => {
      const prestige = Number(lvl?.prestige) || idx + 1;
      const unlocked = prestigeData.xp >= (Number(lvl?.xpRequired) || 0);
      const claimed = (() => {
        try {
          return localStorage.getItem(getPrestigeClaimKey(card?.id, prestige)) === '1';
        } catch {
          return false;
        }
      })();
      const left = ((idx + 1) / total) * 100;
      const stateClass = claimed ? 'claimed' : (unlocked ? 'unlocked' : 'locked');
      return `<button type="button" class="inventory-prestige-gift ${stateClass}" data-prestige="${prestige}" style="left:${left}%;" title="Prestigio ${prestige}">🎁</button>`;
    }).join('');

    giftsContainer.querySelectorAll('.inventory-prestige-gift').forEach((btn) => {
      const prestige = Number(btn.getAttribute('data-prestige')) || 0;
      const level = levels.find(l => Number(l?.prestige) === prestige);
      if (!level) return;

      const xpRequired = Number(level?.xpRequired) || 0;
      const rawRewards = extractPrestigeLevelRewards(level);
      const unlocked = prestigeData.xp >= xpRequired;

      const isClaimed = () => {
        try {
          return localStorage.getItem(getPrestigeClaimKey(card?.id, prestige)) === '1';
        } catch {
          return false;
        }
      };

      // Hover: al pasar el ratón por encima del regalo sale el recuadro con las recompensas
      btn.addEventListener('mouseenter', () => {
        clearTimeout(hoverTimeout);
        renderGiftPreviewBubble(btn, prestige, rawRewards, {
          claimed: isClaimed(),
          unlocked
        });
      });

      btn.addEventListener('mouseleave', () => {
        clearTimeout(hoverTimeout);
        hoverTimeout = setTimeout(() => {
          const cur = Number(giftsContainer.dataset.previewPrestige || 0);
          if (cur === prestige) {
            closeGiftPreviewBubble();
          }
        }, 150);
      });

      btn.addEventListener('click', async () => {
        const alreadyClaimed = isClaimed();

        if (unlocked && !alreadyClaimed) {
          closeGiftPreviewBubble();

          try {
            const key = getPrestigeClaimKey(card?.id, prestige);
            localStorage.setItem(key, '1');
            btn.classList.remove('unlocked');
            btn.classList.add('claimed');
          } catch {}

          // ✅ Mostrar HUD INMEDIATAMENTE: buildRewardsHudItems usa caché en memoria, no hace fetch
          buildRewardsHudItems(rawRewards).then(hudRewards => {
            showRewardsClaimHUD(hudRewards, 'RECOMPENSAS RECLAMADAS');
          }).catch(() => {
            // Fallback síncrono si falla el caché
            showRewardsClaimHUD(rawRewards.map(r => ({
              ...r,
              name: String(r.name || (r.amount && `${r.amount} ${r.type}`) || 'Recompensa'),
              amount: Number(r.amount || 1)
            })), 'RECOMPENSAS RECLAMADAS');
          });
          // Otorgar recompensas en background
          grantPrestigeRewards(rawRewards).catch(e => console.warn('[PRESTIGE] Error otorgando recompensas:', e));
          return;
        }

        const currentPreviewPrestige = Number(giftsContainer.dataset.previewPrestige || 0);
        if (currentPreviewPrestige === prestige) {
          closeGiftPreviewBubble();
          return;
        }

        try {
          await renderGiftPreviewBubble(btn, prestige, rawRewards, {
            claimed: alreadyClaimed,
            unlocked
          });
        } catch {}
      });
    });
  }
}

async function applyDuplicatePrestigeXp(receivedCardsCount = {}, inventoryBefore = {}) {
  const entries = Object.entries(receivedCardsCount || {}).filter(([cardId, qty]) => String(cardId).trim() && Number(qty) > 0);
  if (entries.length === 0) return;

  try {
    if (typeof ensureRewardHudCatalogCache === 'function') {
      await ensureRewardHudCatalogCache();
    }
  } catch (_) {}

  const cfg = await getPrestigeConfig();
  const store = loadPrestigeProgressStore();
  let anyApplied = false;

  entries.forEach(([rawCardId, qtyRaw]) => {
    const cardId = normalizePrestigeCardId(rawCardId);
    const gained = Math.max(0, Number(qtyRaw) || 0);
    if (!cardId || gained <= 0) return;

    const beforeCount = Math.max(0, Number((inventoryBefore || {})[cardId]) || 0);
    const afterCount = beforeCount + gained;

    const duplicatesBefore = Math.max(0, beforeCount - 1);
    const duplicatesAfter = Math.max(0, afterCount - 1);
    const newDuplicates = Math.max(0, duplicatesAfter - duplicatesBefore);
    if (newDuplicates <= 0) return;

    const profile = resolvePrestigeProfile(cfg, { id: cardId });
    const xpRules = profile?.xpRules || defaultPrestigeConfig.xpRules;
    const duplicateXpPerCopy = getDuplicatePrestigeXp({ id: cardId }, xpRules);
    if (duplicateXpPerCopy <= 0) return;

    const current = store[cardId] && typeof store[cardId] === 'object'
      ? store[cardId]
      : { battlesPlayed: 0, battlesWon: 0, battleXp: 0, missionXp: 0 };

    current.battlesPlayed = Math.max(0, Number(current.battlesPlayed) || 0);
    current.battlesWon = Math.max(0, Number(current.battlesWon) || 0);
    current.missionXp = Math.max(0, Number(current.missionXp) || 0);
    current.battleXp = Math.max(0, Number(current.battleXp) || 0) + (newDuplicates * duplicateXpPerCopy);
    current.updatedAt = Date.now();

    store[cardId] = current;
    anyApplied = true;
  });

  if (anyApplied) {
    savePrestigeProgressStore(store);
  }
}

function getInventoryPrestigeData(inventoryCount, thresholds = PRESTIGE_XP_THRESHOLDS, cardId = null) {
  const baseXp = 0;
  const cardProgress = cardId ? getPrestigeProgressEntry(cardId, false) : null;
  const xp = baseXp
    + Math.max(0, Number(cardProgress?.battleXp) || 0)
    + Math.max(0, Number(cardProgress?.missionXp) || 0);

  const validThresholds = Array.isArray(thresholds) && thresholds.length > 0
    ? thresholds.map(v => Number(v) || 0).filter(v => v > 0)
    : [...PRESTIGE_XP_THRESHOLDS];

  let level = 0;
  for (let i = 0; i < validThresholds.length; i += 1) {
    if (xp >= validThresholds[i]) level = i + 1;
  }

  const segmentCount = Math.max(1, validThresholds.length);
  let progress = 0;
  if (xp >= validThresholds[segmentCount - 1]) {
    progress = 100;
  } else {
    let prev = 0;
    for (let i = 0; i < segmentCount; i += 1) {
      const current = validThresholds[i];
      if (xp < current) {
        const segmentRange = Math.max(1, current - prev);
        const segmentProgress = Math.max(0, Math.min(1, (xp - prev) / segmentRange));
        progress = ((i + segmentProgress) / segmentCount) * 100;
        break;
      }
      prev = current;
    }
  }

  return {
    level,
    progress,
    xp,
    thresholds: validThresholds,
    baseXp,
    battlesPlayed: Math.max(0, Number(cardProgress?.battlesPlayed) || 0),
    battlesWon: Math.max(0, Number(cardProgress?.battlesWon) || 0)
  };
}
