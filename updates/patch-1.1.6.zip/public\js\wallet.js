async function renderWallet() {
  if (!isElectron) return;
  try {
    const inv = await window.kvrcards.getInventory();
    const w = (inv && inv.ok && inv.wallet) ? inv.wallet : { coins: 0, kvr: 0, traits: 0 };
    if (wCoins) wCoins.textContent = String(w.coins || 0);
    if (wKvr) wKvr.textContent = String(w.kvr || 0);
    const traitsAmt = Math.max(0, Math.floor(Number(w.traits) || 0));
    const tbVal = document.getElementById('traits-balance-value');
    if (tbVal) tbVal.textContent = String(traitsAmt);
    const tmTraits = document.getElementById('trade-my-traits-wallet');
    if (tmTraits) tmTraits.textContent = String(traitsAmt);
    const wTraitsAmt = document.getElementById('wallet-traits-amt');
    if (wTraitsAmt) wTraitsAmt.textContent = String(traitsAmt);
    if (window.userProfile) {
      window.userProfile.traits = traitsAmt;
    }
    localStorage.setItem('kvr_wallet_traits', String(traitsAmt));
    localStorage.setItem('INFINITE_CURRENCY_COINS', String(Math.max(0, Math.floor(Number(w['infinite-coins']) || 0))));
    localStorage.setItem('INFINITE_CURRENCY_CARDPOINTS', String(Math.max(0, Math.floor(Number(w['infinite-cardpoints']) || 0))));
    if (wCoinsIcon && !wCoinsIcon.src) wCoinsIcon.src = './coin.png';
    if (wKvrIcon && !wKvrIcon.src) wKvrIcon.src = './kvr.png';
  } catch {}
}

const DEFAULT_PACK_OPENING_COLORS = ['#6d28d9', '#5b21b6', '#4c1d95'];

