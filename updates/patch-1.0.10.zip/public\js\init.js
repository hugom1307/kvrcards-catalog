
// ==================== END RANKINGS ====================

// ==================== SEGURIDAD DEVTOOLS & INSPECCIÓN ====================
// Bloquear menú contextual / inspeccionar elemento si no es administrador
window.addEventListener('contextmenu', (e) => {
  if (!window.currentUserIsAdmin) {
    e.preventDefault();
    return false;
  }
}, true);

// Bloquear atajos de DevTools (F12, Ctrl+Shift+I/J/C, Ctrl+U) si no es administrador
window.addEventListener('keydown', (e) => {
  const isDevToolsKey =
    e.key === 'F12' ||
    ((e.ctrlKey || e.metaKey) && e.shiftKey && ['I', 'J', 'C', 'i', 'j', 'c'].includes(e.key)) ||
    ((e.ctrlKey || e.metaKey) && (e.key === 'U' || e.key === 'u'));

  if (isDevToolsKey && !window.currentUserIsAdmin) {
    e.preventDefault();
    e.stopPropagation();
    return false;
  }
}, true);

// ==================== FIX FOCUS UNIVERSAL ====================
// Función para asegurar focus en inputs de manera limpia
function forceFocusOnInput(input) {
  if (!input) return;
  try {
    input.style.pointerEvents = 'auto';
    input.style.cursor = 'text';
    input.tabIndex = 0;
    input.focus();
  } catch (e) {}
}

// Aplicar propiedades básicas a inputs existentes sin listeners invasivos
function applyUniversalInputFix() {
  const allInputs = document.querySelectorAll('input, textarea');
  allInputs.forEach(input => {
    if (input.dataset.focusFixApplied) return;
    input.dataset.focusFixApplied = 'true';
    input.style.pointerEvents = 'auto';
  });
}

let dynamicFilterQualities = ['Bronce', 'Plata', 'Oro', 'Especiales', 'Icono', 'Heroe', 'Icono Prime', 'Icono Super Prime', 'Evo'];
async function refreshFilterQualities() {
  try {
    if (window.kvrcards && window.kvrcards.getQualities) {
      const qs = await window.kvrcards.getQualities();
      if (Array.isArray(qs) && qs.length > 0) {
        window.appQualities = qs;
        window.appQualitiesCache = qs;
        // Ordenar calidades estrictamente por el atributo order (1, 2, 3...)
        const sorted = [...qs].sort((a, b) => (Number(a.order) || 0) - (Number(b.order) || 0));
        const list = sorted.map(q => q.name || q.nombre || q.id);
        // Insertar 'Especiales' directamente debajo de Oro (posición 3)
        const oroIdx = list.findIndex(n => String(n).toLowerCase() === 'oro');
        if (oroIdx !== -1) {
          list.splice(oroIdx + 1, 0, 'Especiales');
        } else {
          list.splice(3, 0, 'Especiales');
        }
        dynamicFilterQualities = list;
        window.dynamicFilterQualities = dynamicFilterQualities;
      }
    }
  } catch {}
}
window.refreshFilterQualities = refreshFilterQualities;
window.dynamicFilterQualities = dynamicFilterQualities;

// Función para inicializar event listeners (previene duplicación)
function initializeEventListeners() {
  if (listenersInitialized) return;
  listenersInitialized = true;

  // APLICAR FIX UNIVERSAL DE FOCUS
  applyUniversalInputFix();

  // Auth Modal
  authTabLogin?.addEventListener('click', () => switchAuthTab('login'));
  authTabRegister?.addEventListener('click', () => switchAuthTab('register'));
  loginSubmit?.addEventListener('click', handleLogin);
  registerSubmit?.addEventListener('click', handleRegister);
  loginPassword?.addEventListener('keypress', (e) => { if (e.key === 'Enter') handleLogin(); });
  registerPasswordConfirm?.addEventListener('keypress', (e) => { if (e.key === 'Enter') handleRegister(); });

  // Profile
  changeAvatarBtn?.addEventListener('click', () => avatarInput?.click());
  avatarInput?.addEventListener('change', handleAvatarChange);
  hudLogout?.addEventListener('click', handleLogout);
  console.log('[PROFILE] hudViewProfile element:', hudViewProfile);
  hudViewProfile?.addEventListener('click', () => {
    console.log('[PROFILE] Ver Perfil clicked!');
    showProfileModal();
  });
  
  // Profile modal
  profileClose?.addEventListener('click', () => profileModal?.classList.remove('show'));
  profileModal?.addEventListener('click', (e) => {
    if (e.target === profileModal) profileModal.classList.remove('show');
  });
  editProfileBtn?.addEventListener('click', async () => {
    profileView.style.display = 'none';
    profileEdit.style.display = 'flex';
    updateTitleSelector(); // Actualizar selector de títulos
    await updateShowcaseEdit(); // Actualizar showcase en modo edición
  });
  cancelEditBtn?.addEventListener('click', async () => {
    profileView.style.display = 'flex';
    profileEdit.style.display = 'none';
    await updateShowcaseDisplay(); // Restaurar showcase en modo vista
  });
  saveProfileBtn?.addEventListener('click', handleSaveProfile);
  editDescription?.addEventListener('input', () => {
    const count = editDescription.value.length;
    if (descriptionCharCount) descriptionCharCount.textContent = count;
  });
  
  // Showcase event listeners - se agregan dinámicamente cuando se abre el modal
  const editSlots = document.querySelectorAll('.showcase-edit-slot');
  if (editSlots && editSlots.length > 0) {
    editSlots.forEach((slot, index) => {
      slot.addEventListener('click', () => openCardSelector(index));
    });
  }
  
  const selectorModal = document.getElementById('card-selector-modal');
  const selectorClose = document.getElementById('card-selector-close');
  const selectorSearch = document.getElementById('card-selector-search');
  
  selectorClose?.addEventListener('click', () => {
    if (selectorModal) selectorModal.style.display = 'none';
    currentShowcaseSlot = null;
  });
  
  selectorModal?.addEventListener('click', (e) => {
    if (e.target === selectorModal) {
      selectorModal.style.display = 'none';
      currentShowcaseSlot = null;
    }
  });
  
  selectorSearch?.addEventListener('input', (e) => {
    filterCardSelector(e.target.value);
  });
  
  // Card zoom event listeners
  cardZoomClose?.addEventListener('click', closeCardZoom);
  
  cardZoomModal?.addEventListener('click', (e) => {
    if (e.target === cardZoomModal || e.target === cardZoomImage) {
      closeCardZoom();
    }
  });
  
  // Cerrar zoom con tecla ESC
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && cardZoomModal?.style.display === 'flex') {
      closeCardZoom();
    }
  });
  
  // Missions event listeners
  refreshMissionsBtn?.addEventListener('click', refreshMissions);
  
  // Kizunas event listeners
  refreshKizunasBtn?.addEventListener('click', refreshKizunas);
  
  // Debug mode event listeners
  hudDebugBtn?.addEventListener('click', () => {
    if (!window.currentUserIsAdmin) {
      console.warn('[SECURITY] Acceso al modo debug denegado: solo cuentas con rango de Administrador');
      return;
    }
    hudPanel?.classList.remove('show');
    debugModal?.classList.add('show');
    if (typeof populateDebugEvolutionsSelect === 'function') {
      populateDebugEvolutionsSelect();
    }
  });
  closeDebugBtn?.addEventListener('click', () => {
    debugModal?.classList.remove('show');
  });
  
  // Pestañas del debug
  document.querySelectorAll('.debug-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      const tabName = tab.dataset.debugTab;
      document.querySelectorAll('.debug-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      document.querySelectorAll('.debug-content').forEach(c => c.classList.remove('active'));
      document.getElementById(`debug-${tabName}`)?.classList.add('active');
      if (tabName === 'evolutions' && typeof populateDebugEvolutionsSelect === 'function') {
        populateDebugEvolutionsSelect();
      }
      if (tabName === 'traits' && typeof initDebugTraits === 'function') {
        initDebugTraits();
      }
    });
  });
  
  // Debug: Cartas
  const debugCardSearch = document.getElementById('debug-card-search');
  const debugCardResults = document.getElementById('debug-card-results');
  debugCardSearch?.addEventListener('input', async () => {
    const searchText = debugCardSearch.value.toLowerCase().trim();
    if (!searchText || searchText.length < 2) {
      debugCardResults.innerHTML = '';
      return;
    }
    
    const allCards = await window.kvrcards.getAllCards();
    if (!allCards) return;
    
    const matches = allCards.filter(card => 
      card.id.toLowerCase().includes(searchText) || 
      card.name.toLowerCase().includes(searchText)
    ).slice(0, 5);
    
    debugCardResults.innerHTML = matches.map(card => `
      <div class="debug-result-item" data-card-id="${card.id}">
        <img src="${card.imageUrl || card.image}" alt="${card.name}" style="width: 50px; height: 70px; object-fit: cover;" />
        <div>
          <strong>${card.name}</strong>
          <small>${card.id}</small>
        </div>
      </div>
    `).join('');
  });
  
  // Variable para guardar la carta seleccionada
  let selectedDebugCard = null;
  
  // Delegar click en los resultados de búsqueda de cartas
  debugCardResults?.addEventListener('click', (e) => {
    const item = e.target.closest('.debug-result-item');
    if (item) {
      // Quitar selección anterior
      document.querySelectorAll('#debug-card-results .debug-result-item').forEach(i => {
        i.style.border = '1px solid #374151';
        i.style.background = '';
      });
      // Marcar como seleccionado
      item.style.border = '2px solid var(--gold)';
      item.style.background = 'rgba(212, 175, 55, 0.1)';
      selectedDebugCard = item.dataset.cardId;
    }
  });
  
  // Botón para añadir TODAS las cartas del catálogo
  document.getElementById('debug-add-all-cards')?.addEventListener('click', async () => {
    const confirmAdd = confirm('⚠️ Esto añadirá TODAS las cartas del catálogo (1 de cada) a tu inventario.\n\n¿Estás seguro?');
    if (!confirmAdd) return;
    
    try {
      const btn = document.getElementById('debug-add-all-cards');
      btn.disabled = true;
      btn.textContent = 'Cargando cartas...';
      
      // Cargar todas las cartas del catálogo
      const allCardsData = await window.kvrcards.getAllCards();
      const cardsList = Array.isArray(allCardsData) ? allCardsData : (allCardsData.ok && Array.isArray(allCardsData.cards) ? allCardsData.cards : []);
      
      if (cardsList.length === 0) {
        alert('❌ No se pudo cargar el catálogo de cartas');
        btn.disabled = false;
        btn.textContent = '⚡ Añadir Todas las Cartas del Catálogo';
        return;
      }
      
      btn.textContent = `Añadiendo ${cardsList.length} cartas...`;
      
      // Añadir cada carta (1 de cada) - skipConfirm = true para evitar confirmaciones múltiples
      let added = 0;
      for (const card of cardsList) {
        await debugAddCard(card.id, 1, true);
        added++;
        if (added % 10 === 0) {
          btn.textContent = `Añadiendo... ${added}/${cardsList.length}`;
        }
      }
      
      // Renderizar colección una vez al final
      await renderCollection();
      
      btn.textContent = '✅ Completado!';
      setTimeout(() => {
        btn.disabled = false;
        btn.textContent = '⚡ Añadir Todas las Cartas del Catálogo';
      }, 2000);
      
      alert(`✅ Se añadieron ${added} cartas al inventario correctamente!`);
      
    } catch (error) {
      console.error('[DEBUG] Error añadiendo todas las cartas:', error);
      alert('❌ Error al añadir cartas: ' + error.message);
      const btn = document.getElementById('debug-add-all-cards');
      btn.disabled = false;
      btn.textContent = '⚡ Añadir Todas las Cartas del Catálogo';
    }
  });
  
  document.getElementById('debug-add-card')?.addEventListener('click', async () => {
    if (!selectedDebugCard) {
      alert('⚠️ Busca y selecciona una carta primero');
      return;
    }
    const quantity = parseInt(document.getElementById('debug-card-quantity')?.value || 1);
    await debugAddCard(selectedDebugCard, quantity);
  });
  
  document.getElementById('debug-remove-card')?.addEventListener('click', async () => {
    if (!selectedDebugCard) {
      alert('⚠️ Busca y selecciona una carta primero');
      return;
    }
    const quantity = parseInt(document.getElementById('debug-card-quantity')?.value || 1);
    await debugRemoveCard(selectedDebugCard, quantity);
  });
  
  // Debug: Sobres
  const debugPackSearch = document.getElementById('debug-pack-search');
  const debugPackResults = document.getElementById('debug-pack-results');
  debugPackSearch?.addEventListener('input', async () => {
    const searchText = debugPackSearch.value.toLowerCase().trim();
    if (!searchText || searchText.length < 2) {
      debugPackResults.innerHTML = '';
      return;
    }
    
    const allPacks = await window.kvrcards.getAllPacks();
    if (!allPacks) return;
    
    const matches = allPacks.filter(pack => 
      pack.id.toLowerCase().includes(searchText) || 
      pack.name.toLowerCase().includes(searchText)
    ).slice(0, 5);
    
    debugPackResults.innerHTML = matches.map(pack => `
      <div class="debug-result-item" data-pack-id="${pack.id}">
        <img src="${pack.imageUrl || pack.image}" alt="${pack.name}" style="width: 60px; height: 80px; object-fit: cover;" />
        <div>
          <strong>${pack.name}</strong>
          <small>${pack.id}</small>
        </div>
      </div>
    `).join('');
  });
  
  // Variable para guardar el sobre seleccionado
  let selectedDebugPack = null;
  
  // Delegar click en los resultados de búsqueda de sobres
  debugPackResults?.addEventListener('click', (e) => {
    const item = e.target.closest('.debug-result-item');
    if (item) {
      // Quitar selección anterior
      document.querySelectorAll('#debug-pack-results .debug-result-item').forEach(i => {
        i.style.border = '1px solid #374151';
        i.style.background = '';
      });
      // Marcar como seleccionado
      item.style.border = '2px solid var(--gold)';
      item.style.background = 'rgba(212, 175, 55, 0.1)';
      selectedDebugPack = item.dataset.packId;
    }
  });
  
  document.getElementById('debug-add-pack')?.addEventListener('click', async () => {
    if (!selectedDebugPack) {
      alert('⚠️ Busca y selecciona un sobre primero');
      return;
    }
    const quantity = parseInt(document.getElementById('debug-pack-quantity').value) || 1;
    await debugAddPack(selectedDebugPack, quantity);
  });
  
  document.getElementById('debug-remove-pack')?.addEventListener('click', async () => {
    if (!selectedDebugPack) {
      alert('⚠️ Busca y selecciona un sobre primero');
      return;
    }
    const quantity = parseInt(document.getElementById('debug-pack-quantity').value) || 1;
    await debugRemovePack(selectedDebugPack, quantity);
  });
  
  // Debug: Poderes
  const debugPowerSearch = document.getElementById('debug-power-search');
  const debugPowerResults = document.getElementById('debug-power-results');
  debugPowerSearch?.addEventListener('input', () => {
    const searchText = debugPowerSearch.value.toLowerCase().trim();
    if (!searchText || searchText.length < 2) {
      debugPowerResults.innerHTML = '';
      return;
    }
    
    const matches = availablePowers.filter(power => 
      power.id.toLowerCase().includes(searchText) || 
      power.name.toLowerCase().includes(searchText)
    ).slice(0, 8);
    
    debugPowerResults.innerHTML = matches.map(power => `
      <div class="debug-result-item" data-power-id="${power.id}">
        <img src="${power.imageUrl}" alt="${power.name}" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover;" />
        <div>
          <strong>${power.name}</strong>
          <small>${power.id}</small>
          <span style="display: block; font-size: 10px; color: #94a3b8;">${power.permanent ? '♾️ Permanente' : '⚡ Consumible'}</span>
        </div>
      </div>
    `).join('');
  });
  
  // Variable para guardar el poder seleccionado
  let selectedDebugPower = null;
  
  // Delegar click en los resultados de búsqueda de poderes
  debugPowerResults?.addEventListener('click', (e) => {
    const item = e.target.closest('.debug-result-item');
    if (item) {
      // Quitar selección anterior
      document.querySelectorAll('#debug-power-results .debug-result-item').forEach(i => {
        i.style.border = '1px solid #374151';
        i.style.background = '';
      });
      // Marcar como seleccionado
      item.style.border = '2px solid #fbbf24';
      item.style.background = 'rgba(251, 191, 36, 0.1)';
      selectedDebugPower = item.dataset.powerId;
    }
  });
  
  // Toggle tipo de poder (permanente/consumible)
  document.querySelectorAll('input[name="power-type"]').forEach(radio => {
    radio.addEventListener('change', () => {
      const usesContainer = document.getElementById('debug-power-uses-container');
      if (radio.value === 'permanent') {
        usesContainer.classList.add('hidden');
      } else {
        usesContainer.classList.remove('hidden');
      }
    });
  });
  
  document.getElementById('debug-add-power')?.addEventListener('click', async () => {
    if (!selectedDebugPower) {
      alert('⚠️ Busca y selecciona un poder primero');
      return;
    }
    const isPermanent = document.querySelector('input[name="power-type"]:checked')?.value === 'permanent';
    const uses = isPermanent ? 1 : parseInt(document.getElementById('debug-power-uses')?.value || 1);
    await debugAddPower(selectedDebugPower, isPermanent, uses);
  });
  
  document.getElementById('debug-remove-power')?.addEventListener('click', async () => {
    if (!selectedDebugPower) {
      alert('⚠️ Busca y selecciona un poder primero');
      return;
    }
    await debugRemovePower(selectedDebugPower);
  });

  // Debug: Prestigios
  const debugPrestigeCardSearch = document.getElementById('debug-prestige-card-search');
  const debugPrestigeCardResults = document.getElementById('debug-prestige-card-results');
  const debugPrestigeSelectedCardLabel = document.getElementById('debug-prestige-selected-card');
  let selectedDebugPrestigeCard = null;

  const refreshDebugPrestigeSelectionLabel = () => {
    if (!debugPrestigeSelectedCardLabel) return;
    if (!selectedDebugPrestigeCard) {
      debugPrestigeSelectedCardLabel.textContent = 'Ninguna carta seleccionada';
      return;
    }

    const progress = getPrestigeProgressEntry(selectedDebugPrestigeCard.id, false);
    const totalXp = Math.max(0, Number(progress.battleXp) || 0) + Math.max(0, Number(progress.missionXp) || 0);
    debugPrestigeSelectedCardLabel.textContent = `${selectedDebugPrestigeCard.name} (${selectedDebugPrestigeCard.id}) | XP actual: ${totalXp.toLocaleString('es-ES')}`;
  };

  debugPrestigeCardSearch?.addEventListener('input', async () => {
    const searchText = String(debugPrestigeCardSearch.value || '').toLowerCase().trim();
    if (!searchText || searchText.length < 2) {
      debugPrestigeCardResults.innerHTML = '';
      return;
    }

    const allCards = await window.kvrcards.getAllCards();
    if (!Array.isArray(allCards)) return;

    const matches = allCards.filter(card =>
      String(card.id || '').toLowerCase().includes(searchText) ||
      String(card.name || card.nombre || '').toLowerCase().includes(searchText)
    ).slice(0, 8);

    debugPrestigeCardResults.innerHTML = matches.map((card) => `
      <div class="debug-result-item" data-card-id="${card.id}" data-card-name="${card.name || card.nombre || card.id}">
        <img src="${card.imageUrl || card.image || card.imagen || ''}" alt="${card.name || card.nombre || card.id}" style="width: 50px; height: 70px; object-fit: cover;" />
        <div>
          <strong>${card.name || card.nombre || card.id}</strong>
          <small>${card.id}</small>
        </div>
      </div>
    `).join('');
  });

  debugPrestigeCardResults?.addEventListener('click', (e) => {
    const item = e.target.closest('.debug-result-item');
    if (!item) return;

    document.querySelectorAll('#debug-prestige-card-results .debug-result-item').forEach(i => {
      i.style.border = '1px solid #374151';
      i.style.background = '';
    });

    item.style.border = '2px solid var(--gold)';
    item.style.background = 'rgba(212, 175, 55, 0.1)';

    selectedDebugPrestigeCard = {
      id: item.dataset.cardId,
      name: item.dataset.cardName
    };
    refreshDebugPrestigeSelectionLabel();
  });

  document.getElementById('debug-add-prestige-xp')?.addEventListener('click', async () => {
    if (!selectedDebugPrestigeCard) {
      alert('⚠️ Selecciona una carta primero');
      return;
    }
    const amount = Math.max(1, parseInt(document.getElementById('debug-prestige-xp-amount')?.value || 0, 10) || 0);
    if (!confirm(`¿Añadir ${amount} XP de prestigio a ${selectedDebugPrestigeCard.name}?`)) return;
    await debugAdjustPrestigeXP(selectedDebugPrestigeCard.id, amount);
    refreshDebugPrestigeSelectionLabel();
    alert(`✅ Añadidos ${amount} XP de prestigio a ${selectedDebugPrestigeCard.name}`);
  });

  document.getElementById('debug-remove-prestige-xp')?.addEventListener('click', async () => {
    if (!selectedDebugPrestigeCard) {
      alert('⚠️ Selecciona una carta primero');
      return;
    }
    const amount = Math.max(1, parseInt(document.getElementById('debug-prestige-xp-amount')?.value || 0, 10) || 0);
    if (!confirm(`¿Quitar ${amount} XP de prestigio a ${selectedDebugPrestigeCard.name}?`)) return;
    await debugAdjustPrestigeXP(selectedDebugPrestigeCard.id, -amount);
    refreshDebugPrestigeSelectionLabel();
    alert(`✅ Quitados ${amount} XP de prestigio a ${selectedDebugPrestigeCard.name}`);
  });

  document.getElementById('debug-reset-all-prestige')?.addEventListener('click', debugResetAllPrestige);
  document.getElementById('debug-complete-all-prestige')?.addEventListener('click', debugCompleteAllPrestige);
  
  // Debug: Añadir poderes por defecto
  document.getElementById('debug-add-default-powers')?.addEventListener('click', async () => {
    if (!confirm('¿Añadir los 3 poderes por defecto (RESERVA, POWER UP, NERF) como permanentes?')) return;
    
    try {
      const defaultPowers = ['reserva', 'powerup', 'nerf'];
      let addedCount = 0;
      let alreadyOwnedCount = 0;
      
      for (const powerId of defaultPowers) {
        const result = await window.kvrcards.addPower(powerId);
        if (result.ok) {
          addedCount++;
        } else if (result.alreadyOwned) {
          alreadyOwnedCount++;
        }
      }
      
      // Recargar inventario de poderes
      await loadPowers();
      
      if (addedCount > 0) {
        alert(`✅ ${addedCount} poder(es) añadido(s) correctamente.\n${alreadyOwnedCount > 0 ? `⚠️ ${alreadyOwnedCount} ya estaban en tu inventario.` : ''}`);
      } else if (alreadyOwnedCount === 3) {
        alert('ℹ️ Ya tienes todos los poderes por defecto.');
      }
    } catch (e) {
      console.error('[DEBUG] Error añadiendo poderes por defecto:', e);
      alert('❌ Error: ' + e.message);
    }
  });
  
  // Debug: Forzar sincronización de poderes con R2
  document.getElementById('debug-force-sync-powers')?.addEventListener('click', async () => {
    if (!confirm('☁️ ¿Sincronizar tu inventario completo (incluyendo poderes) con R2 (Cloudflare)?')) return;
    
    try {
      console.log('[DEBUG] Forzando sincronización con R2...');
      
      // Forzar sincronización del inventario completo a R2
      const syncResult = await window.kvrcards.syncInventoryRemote();
      
      if (syncResult && syncResult.ok) {
        alert('Inventario sincronizado correctamente con R2 (Cloudflare).\n\n' +
              'Tus poderes y todo tu inventario están ahora guardados remotamente.\n\n' +
              'Puedes ver tu inventario completo en el servidor web de inventario remoto.');
      } else {
        alert('Error al sincronizar con R2: ' + (syncResult?.error || 'Error desconocido'));
      }
    } catch (e) {
      console.error('[DEBUG] Error forzando sincronización:', e);
      alert('❌ Error: ' + e.message);
    }
  });
  
  // Debug: Monedas
  document.getElementById('debug-add-coins')?.addEventListener('click', async () => {
    const amount = parseInt(document.getElementById('debug-coins-amount').value) || 0;
    await debugModifyCoins(amount);
  });
  
  document.getElementById('debug-remove-coins')?.addEventListener('click', async () => {
    const amount = parseInt(document.getElementById('debug-coins-amount').value) || 0;
    await debugModifyCoins(-amount);
  });
  
  document.getElementById('debug-add-kvr')?.addEventListener('click', async () => {
    const amount = parseInt(document.getElementById('debug-kvr-amount').value) || 0;
    await debugModifyKVR(amount);
  });
  
  document.getElementById('debug-remove-kvr')?.addEventListener('click', async () => {
    const amount = parseInt(document.getElementById('debug-kvr-amount').value) || 0;
    await debugModifyKVR(-amount);
  });

  // Debug: Traits
  document.getElementById('debug-add-traits')?.addEventListener('click', async () => {
    const amount = parseInt(document.getElementById('debug-traits-amount').value) || 0;
    await debugModifyTraits(amount);
  });
  
  document.getElementById('debug-remove-traits')?.addEventListener('click', async () => {
    const amount = parseInt(document.getElementById('debug-traits-amount').value) || 0;
    await debugModifyTraits(-amount);
  });

  // Debug: Infinite Currencies
  document.getElementById('debug-add-infinite-coins')?.addEventListener('click', async () => {
    const amount = parseInt(document.getElementById('debug-infinite-coins-amount').value) || 0;
    await debugModifyInfiniteCoins(amount);
  });

  document.getElementById('debug-remove-infinite-coins')?.addEventListener('click', async () => {
    const amount = parseInt(document.getElementById('debug-infinite-coins-amount').value) || 0;
    await debugModifyInfiniteCoins(-amount);
  });

  document.getElementById('debug-add-infinite-cardpoints')?.addEventListener('click', async () => {
    const amount = parseInt(document.getElementById('debug-infinite-cardpoints-amount').value) || 0;
    await debugModifyInfiniteCardpoints(amount);
  });

  document.getElementById('debug-remove-infinite-cardpoints')?.addEventListener('click', async () => {
    const amount = parseInt(document.getElementById('debug-infinite-cardpoints-amount').value) || 0;
    await debugModifyInfiniteCardpoints(-amount);
  });
  
  // Debug: Coleccionables
  document.getElementById('debug-reset-missions')?.addEventListener('click', debugResetMissions);
  document.getElementById('debug-complete-missions')?.addEventListener('click', debugCompleteMissions);
  document.getElementById('debug-reset-kizunas')?.addEventListener('click', debugResetKizunas);
  document.getElementById('debug-complete-kizunas')?.addEventListener('click', debugCompleteKizunas);
  document.getElementById('debug-reset-titles')?.addEventListener('click', debugResetTitles);
  document.getElementById('debug-unlock-all-titles')?.addEventListener('click', debugUnlockAllTitles);
  document.getElementById('debug-reset-all')?.addEventListener('click', debugResetAll);
  
  // Debug: Coleccionables - Evoluciones
  document.getElementById('debug-collectibles-complete-evo-phase')?.addEventListener('click', debugCompleteAllActiveEvolutionPhases);
  document.getElementById('debug-collectibles-complete-all-evos')?.addEventListener('click', debugCompleteAllEvolutions);
  document.getElementById('debug-collectibles-reset-evos')?.addEventListener('click', debugResetAllEvolutions);

  // Debug: Pestaña Evoluciones
  document.getElementById('debug-evolution-select')?.addEventListener('change', updateDebugEvolutionInfo);
  document.getElementById('debug-evo-complete-missions')?.addEventListener('click', () => {
    const evoId = document.getElementById('debug-evolution-select')?.value;
    debugCompleteEvolutionMissions(evoId);
  });
  document.getElementById('debug-evo-advance-phase')?.addEventListener('click', () => {
    const evoId = document.getElementById('debug-evolution-select')?.value;
    debugAdvanceEvolutionPhase(evoId);
  });
  document.getElementById('debug-evo-complete-full')?.addEventListener('click', () => {
    const evoId = document.getElementById('debug-evolution-select')?.value;
    debugCompleteFullEvolution(evoId);
  });
  document.getElementById('debug-evo-reset')?.addEventListener('click', () => {
    const evoId = document.getElementById('debug-evolution-select')?.value;
    debugResetEvolution(evoId);
  });
  document.getElementById('debug-evo-complete-all-active')?.addEventListener('click', debugCompleteAllActiveEvolutionPhases);
  document.getElementById('debug-evo-complete-all')?.addEventListener('click', debugCompleteAllEvolutions);
  document.getElementById('debug-evo-reset-all')?.addEventListener('click', debugResetAllEvolutions);
  
  // Toggle de misiones completadas
  toggleCompletedBtn?.addEventListener('click', () => {
    const isExpanded = completedMissionsContainer.style.display === 'block';
    completedMissionsContainer.style.display = isExpanded ? 'none' : 'block';
    if (toggleCompletedIcon) {
      if (isExpanded) {
        toggleCompletedIcon.classList.remove('expanded');
      } else {
        toggleCompletedIcon.classList.add('expanded');
      }
    }
  });

  // Rankings event listeners
  rankingsToggle?.addEventListener('click', openRankingsModal);
  closeRankingsBtn?.addEventListener('click', closeRankingsModal);
  
  // Cerrar modal al hacer click fuera
  rankingsModal?.addEventListener('click', (e) => {
    if (e.target === rankingsModal) {
      closeRankingsModal();
    }
  });
  
  // Tabs de período
  document.querySelectorAll('.rankings-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      switchRankingPeriod(tab.dataset.period);
    });
  });
  
  // Botones de categoría
  document.querySelectorAll('.rankings-category').forEach(btn => {
    btn.addEventListener('click', () => {
      switchRankingCategory(btn.dataset.category);
    });
  });

  // Friends event listeners
  const friendsToggle = document.getElementById('friends-btn');
  const closeFriendsBtn = document.getElementById('close-friends');
  const friendsModal = document.getElementById('friends-modal');
  
  friendsToggle?.addEventListener('click', openFriendsModal);
  closeFriendsBtn?.addEventListener('click', closeFriendsModal);
  
  // Cerrar modal de amigos al hacer click fuera
  friendsModal?.addEventListener('click', (e) => {
    if (e.target === friendsModal) {
      closeFriendsModal();
    }
  });
  
  // Tabs de amigos
  document.querySelectorAll('.friends-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      switchFriendsTab(tab.dataset.tab);
    });
  });
  
  // Búsqueda de usuarios
  document.getElementById('friends-search-btn')?.addEventListener('click', searchUsers);
  document.getElementById('friends-search-input')?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      searchUsers();
    }
  });
  
  // Exportar funciones de amigos al window para acceso desde HTML
  window.openFriendsModal = openFriendsModal;
  window.closeFriendsModal = closeFriendsModal;
  window.switchFriendsTab = switchFriendsTab;
  window.loadFriendsList = loadFriendsList;
  window.loadFriendRequests = loadFriendRequests;
  window.searchUsers = searchUsers;

  // ========================================
  // TRADES SYSTEM
  // ========================================
  
  let currentTradeId = null;
  let currentTradeData = null;
  let tradeInventoryBeforeComplete = null;
  let tradeUpdateInterval = null;
  let randomMatchCheckInterval = null;
  let tradePendingCheckInterval = null;
  let selectedSlot = null;
  let myTradeOffer = { cards: {}, packs: {}, coins: 0, traits: 0, cardTraits: {} };
  let forceGreenButton = false; // Flag para forzar botón verde ignorando servidor
  let cachedTradeCatalog = null;
  let lastRenderedOtherOfferJson = null;

  async function getCachedTradeCatalog() {
    if (cachedTradeCatalog) return cachedTradeCatalog;
    try {
      const [allCards, allPacks, traitsResp] = await Promise.all([
        kvrcards.getAllCards(),
        kvrcards.getAllPacks(),
        fetch('https://hugom1307.github.io/kvrcards-catalog/traits.json').then(r => r.json()).catch(() => ({ traits: [] }))
      ]);
      cachedTradeCatalog = {
        allCards: allCards || [],
        allPacks: allPacks || [],
        traitsResp: traitsResp || { traits: [] },
        cardMap: new Map((allCards || []).map(c => [c.id, c])),
        packMap: new Map((allPacks || []).map(p => [p.id, p])),
        traitsMap: new Map(((traitsResp && traitsResp.traits) || []).map(t => [t.id, t]))
      };
    } catch (e) {
      console.error('[TRADES] Error loading catalog for trade:', e);
      return {
        allCards: [],
        allPacks: [],
        traitsResp: { traits: [] },
        cardMap: new Map(),
        packMap: new Map(),
        traitsMap: new Map()
      };
    }
    return cachedTradeCatalog;
  }
  
  const tradesToggle = document.getElementById('trade-btn');
  const tradesModal = document.getElementById('trades-modal');
  const closeTradesBtn = document.getElementById('close-trades');
  const tradeSelectionView = document.getElementById('trade-selection-view');
  const friendSelectionView = document.getElementById('friend-selection-view');
  const randomSearchView = document.getElementById('random-search-view');
  const activeTradeView = document.getElementById('active-trade-view');
  const itemSelectorModal = document.getElementById('item-selector-modal');
  
  // ---- NOTIFICATION BADGES SYSTEM ----
  function setNotificationBadge(target, count) {
    const el = typeof target === 'string' ? document.querySelector(target) : target;
    if (!el) return;
    
    let badge = el.querySelector('.notif-badge');
    const numericCount = Number(count) || 0;
    
    if (numericCount > 0) {
      const text = numericCount > 99 ? '99+' : String(numericCount);
      if (!badge) {
        badge = document.createElement('div');
        badge.className = 'notif-badge';
        badge.textContent = text;
        badge.style.display = 'flex';
        el.appendChild(badge);
      } else {
        if (badge.textContent !== text) badge.textContent = text;
        if (badge.style.display !== 'flex') badge.style.display = 'flex';
      }
    } else {
      if (badge) {
        badge.remove();
      }
    }
  }

  async function updateGlobalNotificationBadges() {
    if (typeof document !== 'undefined' && document.hidden) return;
    try {
      // 1. Mis Sobres: contar total de sobres disponibles para abrir
      let totalPacksCount = 0;
      let userCards = null;
      if (window.kvrcards && typeof window.kvrcards.getInventory === 'function') {
        try {
          const inv = await window.kvrcards.getInventory();
          if (inv && inv.ok) {
            if (inv.packs) {
              totalPacksCount = Object.values(inv.packs).reduce((sum, qty) => sum + (Number(qty) > 0 ? Number(qty) : 0), 0);
            }
            if (inv.cards) {
              userCards = inv.cards;
              window.userInventoryCache = window.userInventoryCache || {};
              window.userInventoryCache.cards = inv.cards;
            }
          }
        } catch (e) {
          console.warn('[NOTIF] Error fetching packs for badge:', e);
        }
      }
      setNotificationBadge('.menu-card-mypacks', totalPacksCount);

      // 1.2 Coleccionables: Misiones, Kizunas y Evoluciones por reclamar
      let missionsCount = 0;
      let kizunasCount = 0;
      let evolutionsCount = 0;

      if (typeof window.getClaimableMissionsCount === 'function') {
        try {
          missionsCount = window.getClaimableMissionsCount();
        } catch (e) {
          console.warn('[NOTIF] Error counting claimable missions:', e);
        }
      }
      if (typeof window.getClaimableKizunasCount === 'function') {
        try {
          kizunasCount = window.getClaimableKizunasCount(userCards);
        } catch (e) {
          console.warn('[NOTIF] Error counting claimable kizunas:', e);
        }
      }
      if (typeof window.getClaimableEvolutionsCount === 'function') {
        try {
          evolutionsCount = window.getClaimableEvolutionsCount();
        } catch (e) {
          console.warn('[NOTIF] Error counting claimable evolutions:', e);
        }
      }

      const totalCollectibles = missionsCount + kizunasCount + evolutionsCount;

      // Badge exterior del menú principal (Coleccionables)
      setNotificationBadge('.menu-card-missions', totalCollectibles);

      // Badges interiores encima de cada botón de Coleccionables
      setNotificationBadge('.collectible-tab[data-tab="missions"]', missionsCount);
      setNotificationBadge('.collectible-tab[data-tab="kizuna"]', kizunasCount);
      setNotificationBadge('.collectible-tab[data-tab="evolutions"]', evolutionsCount);

      // Badges de subapartados de misiones (Fundamentos, Diarias, Semanales, Destacadas, Limitadas)
      if (typeof window.updateMissionSubtabBadges === 'function') {
        window.updateMissionSubtabBadges();
      } else if (typeof window.getClaimableMissionsCountsByCategory === 'function') {
        const subCounts = window.getClaimableMissionsCountsByCategory();
        setNotificationBadge('.mission-subtab[data-subtab="fundamentals"]', subCounts.fundamentals);
        setNotificationBadge('.mission-subtab[data-subtab="daily"]', subCounts.daily);
        setNotificationBadge('.mission-subtab[data-subtab="weekly"]', subCounts.weekly);
        setNotificationBadge('.mission-subtab[data-subtab="featured"]', subCounts.featured);
        setNotificationBadge('.mission-subtab[data-subtab="limited"]', subCounts.limited);
      }

      // Badges de grupos de Kizuna (a la izquierda de X/X completados)
      if (typeof window.updateKizunaGroupBadges === 'function') {
        window.updateKizunaGroupBadges(userCards);
      }

      // 2. Trades: contar solicitudes pendientes de trade recibidas (solo si hay usuario)
      let pendingTradesCount = 0;
      if (window.kvrcards && typeof window.kvrcards.tradesGetPending === 'function' && window.userProfile?.username) {
        try {
          const res = await window.kvrcards.tradesGetPending();
          if (res && res.ok && Array.isArray(res.pending)) {
            pendingTradesCount = res.pending.length;
          }
        } catch (e) {
          console.warn('[NOTIF] Error fetching pending trades for badge:', e);
        }
      }
      setNotificationBadge('#trades-menu-btn', pendingTradesCount);
      setNotificationBadge('.menu-card-trades', pendingTradesCount);

      // 3. Amigos: solicitudes de amistad pendientes (solo si hay usuario)
      let friendRequestsCount = 0;
      if (window.kvrcards && typeof window.kvrcards.friendsGetRequests === 'function' && window.userProfile?.username) {
        try {
          const reqs = await window.kvrcards.friendsGetRequests();
          if (reqs && reqs.ok && Array.isArray(reqs.requests)) {
            friendRequestsCount = reqs.requests.length;
          }
        } catch (e) {
          console.warn('[NOTIF] Error fetching friend requests for badge:', e);
        }
      }
      setNotificationBadge('#friends-menu-btn', friendRequestsCount);
      setNotificationBadge('.menu-card-friends', friendRequestsCount);

      // 4. Batalla / Jugar: solicitudes de combate recibidas
      let battleRequestsCount = 0;
      const battleList = document.getElementById('battle-requests-list');
      if (battleList) {
        battleRequestsCount = battleList.querySelectorAll('.friend-battle-item').length;
      }
      setNotificationBadge('.menu-card-play', battleRequestsCount);

    } catch (err) {
      console.error('[NOTIF] Error in updateGlobalNotificationBadges:', err);
    }
  }

  window.updateGlobalNotificationBadges = updateGlobalNotificationBadges;
  window.setNotificationBadge = setNotificationBadge;

  // Iniciar verificación periódica de notificaciones globales (cada 25s para no saturar)
  function startPendingTradesCheck() {
    if (tradePendingCheckInterval) return;
    tradePendingCheckInterval = setInterval(updateGlobalNotificationBadges, 25000);
    updateGlobalNotificationBadges(); // Verificar inmediatamente
  }
  
  // Detener verificación
  function stopPendingTradesCheck() {
    if (tradePendingCheckInterval) {
      clearInterval(tradePendingCheckInterval);
      tradePendingCheckInterval = null;
    }
  }

  window.startPendingTradesCheck = startPendingTradesCheck;
  window.stopPendingTradesCheck = stopPendingTradesCheck;
    
  // Resetear interfaz visual de la sala de trade
  function resetTradeUI() {
    for (let i = 1; i <= 3; i++) {
      const mySlot = document.getElementById(`my-slot-${i}`);
      if (mySlot) {
        mySlot.innerHTML = '<div class="trade-slot-empty">+ Añadir Item</div>';
        delete mySlot.dataset.itemType;
        delete mySlot.dataset.itemId;
        mySlot.style.transition = '';
        mySlot.style.transform = '';
        mySlot.style.boxShadow = '';
        mySlot.style.opacity = '1';
      }
      const otherSlot = document.getElementById(`other-slot-${i}`);
      if (otherSlot) {
        otherSlot.innerHTML = '<div class="trade-slot-empty">Esperando item...</div>';
        otherSlot.style.transition = '';
        otherSlot.style.transform = '';
        otherSlot.style.boxShadow = '';
        otherSlot.style.opacity = '1';
      }
    }
    
    const myCoinsInput = document.getElementById('my-coins-input');
    if (myCoinsInput) myCoinsInput.value = 0;
    const myTraitsInput = document.getElementById('my-traits-input');
    if (myTraitsInput) myTraitsInput.value = 0;
    
    const otherCoinsDisplay = document.getElementById('other-coins-display');
    if (otherCoinsDisplay) otherCoinsDisplay.textContent = '0';
    const otherTraitsDisplay = document.getElementById('other-traits-display');
    if (otherTraitsDisplay) otherTraitsDisplay.textContent = '0';
    
    const tradeStatus = document.getElementById('trade-status');
    if (tradeStatus) {
      tradeStatus.textContent = 'Configura tu oferta y pulsa Confirmar';
      tradeStatus.style.color = '#94a3b8';
    }
    
    const confirmBtn = document.getElementById('confirm-trade-btn');
    if (confirmBtn) {
      confirmBtn.innerHTML = '<span class="confirm-icon">✓</span><span>Confirmar</span>';
      confirmBtn.style.background = '';
      confirmBtn.disabled = false;
    }
  }

  // Abrir modal de trades
  function openTradesModal() {
    closeItemSelector();
    tradesModal?.classList.add('show');
    if (!currentTradeId) {
      showTradeSelectionView();
      resetTradeUI();
    }
  }
  
  // Cerrar modal de trades
  function closeTradesModal() {
    closeItemSelector();
    tradesModal?.classList.remove('show');
    cleanupTrade(true);
    showTradeSelectionView();
  }
  
  // Limpiar estado del trade
  function cleanupTrade(shouldCancelOnServer = true) {
    closeItemSelector();
    if (tradeUpdateInterval) {
      clearInterval(tradeUpdateInterval);
      tradeUpdateInterval = null;
    }
    if (randomMatchCheckInterval) {
      clearInterval(randomMatchCheckInterval);
      randomMatchCheckInterval = null;
    }
    if (currentTradeId && shouldCancelOnServer && currentTradeData?.status !== 'completed') {
      kvrcards.tradesCancelTrade(currentTradeId).catch(() => {});
    }
    currentTradeId = null;
    currentTradeData = null;
    tradeInventoryBeforeComplete = null;
    cachedTradeCatalog = null;
    lastRenderedOtherOfferJson = null;
    myTradeOffer = { cards: {}, packs: {}, coins: 0, traits: 0, cardTraits: {} };
    selectedSlot = null;
    forceGreenButton = false;
    resetTradeUI();
  }
  
  // Mostrar vista de selección
  function showTradeSelectionView() {
    tradeSelectionView.style.display = 'flex';
    friendSelectionView.style.display = 'none';
    randomSearchView.style.display = 'none';
    activeTradeView.style.display = 'none';
    
    // Actualizar contador de solicitudes pendientes
    updatePendingRequestsCount();
  }
  
  // Mostrar vista de selección de amigo
  async function showFriendSelectionView() {
    tradeSelectionView.style.display = 'none';
    friendSelectionView.style.display = 'block';
    randomSearchView.style.display = 'none';
    activeTradeView.style.display = 'none';
    
    // Mostrar tab de amigos por defecto
    showFriendsTab();
    
    // Cargar lista de amigos
    loadFriendsListForTrade();
    
    // Cargar solicitudes pendientes
    loadPendingRequests();
  }
  
  // Mostrar tab de amigos
  function showFriendsTab() {
    document.querySelectorAll('.friend-tab').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.tab === 'friends');
    });
    document.getElementById('friends-tab-content').style.display = 'block';
    document.getElementById('requests-tab-content').style.display = 'none';
  }
  
  // Mostrar tab de solicitudes
  function showRequestsTab() {
    document.querySelectorAll('.friend-tab').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.tab === 'requests');
    });
    document.getElementById('friends-tab-content').style.display = 'none';
    document.getElementById('requests-tab-content').style.display = 'block';
  }
  
  // Cargar lista de amigos para trades
  async function loadFriendsListForTrade() {
    const listDiv = document.getElementById('friend-selection-list');
    listDiv.innerHTML = '<div class="friends-loading">Cargando amigos...</div>';
    
    try {
      const res = await kvrcards.friendsGetFriendsList();
      if (res.ok && res.friends && res.friends.length > 0) {
        listDiv.innerHTML = '';
        res.friends.forEach(friend => {
          const card = createFriendCard(friend, 'trade-request');
          listDiv.appendChild(card);
        });
      } else {
        listDiv.innerHTML = '<div class="friends-empty">No tienes amigos para tradear. ¡Añade algunos primero!</div>';
      }
    } catch (e) {
      listDiv.innerHTML = '<div class="friends-error">Error cargando amigos</div>';
    }
  }
  
  // Cargar solicitudes pendientes
  async function loadPendingRequests() {
    const listDiv = document.getElementById('pending-requests-list');
    listDiv.innerHTML = '<div class="pending-requests-loading">Cargando solicitudes...</div>';
    
    try {
      const res = await kvrcards.tradesGetPending();
      console.log('[TRADES] Pending requests:', res);
      
      // Actualizar badge
      const count = (res && res.requests) ? res.requests.length : 0;
      const badge = document.getElementById('pending-count-badge');
      if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'inline-block' : 'none';
      }
      
      if (res && res.requests && res.requests.length > 0) {
        listDiv.innerHTML = '';
        
        for (const request of res.requests) {
          const itemDiv = document.createElement('div');
          itemDiv.className = 'pending-request-item';
          
          // Obtener avatar optimizado sin descargar inventarios completos
          const serverBase = window.KVR_SERVER_URL || 'https://kvrcards-server.onrender.com';
          const avatarUrl = request.trade?.avatars?.[request.from] 
            || `${serverBase}/api/avatar/${encodeURIComponent(request.from)}`;
          
          const timeAgo = getTimeAgo(request.createdAt);
          
          itemDiv.innerHTML = `
            <div class="pending-request-info">
              <img src="${avatarUrl}" class="pending-request-avatar" alt="${request.from}">
              <div class="pending-request-details">
                <h4>${request.from}</h4>
                <p>Solicitud enviada ${timeAgo}</p>
              </div>
            </div>
            <div class="pending-request-actions">
              <button class="accept-request-btn" data-trade-id="${request.tradeId}" data-username="${request.from}">
                ✓ Aceptar
              </button>
              <button class="reject-request-btn" data-trade-id="${request.tradeId}">
                ✗ Rechazar
              </button>
            </div>
          `;
          
          listDiv.appendChild(itemDiv);
        }
        
        // Añadir event listeners a los botones
        document.querySelectorAll('.accept-request-btn').forEach(btn => {
          btn.addEventListener('click', () => acceptTradeRequest(btn.dataset.tradeId, btn.dataset.username));
        });
        
        document.querySelectorAll('.reject-request-btn').forEach(btn => {
          btn.addEventListener('click', () => rejectTradeRequest(btn.dataset.tradeId));
        });
        
      } else {
        listDiv.innerHTML = '<div class="pending-requests-empty">No tienes solicitudes pendientes</div>';
      }
    } catch (e) {
      console.error('[TRADES] Error loading pending requests:', e);
      listDiv.innerHTML = '<div class="pending-requests-empty">Error cargando solicitudes</div>';
    }
  }
  
  // Enviar solicitud de trade a amigo
  async function sendTradeRequest(username) {
    try {
      console.log('[TRADES] Sending request to:', username);
      const res = await kvrcards.tradesSendRequest(username);
      console.log('[TRADES] Response:', res);
      
      if (res && res.ok && res.tradeId) {
        currentTradeId = res.tradeId;
        currentTradeData = res.trade;
        
        // Mostrar vista de espera similar al trade aleatorio
        showWaitingForAcceptanceView(username);
        
        // Empezar a hacer polling para detectar cuando se acepta
        startTradeAcceptancePolling();
      } else {
        const errorMsg = res ? (res.error || 'Respuesta inesperada del servidor') : 'Sin respuesta del servidor';
        alert('Error enviando solicitud de trade: ' + errorMsg);
        console.error('[TRADES] Error details:', res);
      }
    } catch (e) {
      console.error('[TRADES] Exception:', e);
      alert('Error de conexión: ' + e.message);
    }
  }
  
  // Mostrar vista de espera de aceptación
  function showWaitingForAcceptanceView(username) {
    tradeSelectionView.style.display = 'none';
    friendSelectionView.style.display = 'none';
    randomSearchView.style.display = 'block'; // Reutilizamos la vista de búsqueda aleatoria
    activeTradeView.style.display = 'none';
    
    // Actualizar el texto para indicar que está esperando aceptación
    const searchContent = document.querySelector('.random-search-content');
    if (searchContent) {
      const h3 = searchContent.querySelector('h3');
      const p = searchContent.querySelector('p');
      if (h3) h3.textContent = `Esperando a ${username}...`;
      if (p) p.textContent = 'El trade se abrirá automáticamente cuando acepte tu solicitud';
    }
  }
  
  // Polling para detectar cuando se acepta el trade
  function startTradeAcceptancePolling() {
    if (randomMatchCheckInterval) clearInterval(randomMatchCheckInterval);
    
    randomMatchCheckInterval = setInterval(async () => {
      if (!currentTradeId) {
        clearInterval(randomMatchCheckInterval);
        randomMatchCheckInterval = null;
        return;
      }
      
      try {
        const statusRes = await kvrcards.tradesGetStatus(currentTradeId);
        console.log('[TRADES] Acceptance polling status:', statusRes);
        
        if (!statusRes || !statusRes.ok || !statusRes.trade) {
          clearInterval(randomMatchCheckInterval);
          randomMatchCheckInterval = null;
          cleanupTrade(false);
          alert('La solicitud de trade fue cancelada o rechazada.');
          showTradeSelectionView();
          return;
        }
        
        if (statusRes.trade.status === 'active') {
          clearInterval(randomMatchCheckInterval);
          randomMatchCheckInterval = null;
          
          currentTradeData = statusRes.trade;
          console.log('[TRADES] Trade accepted! Opening trade view...');
          
          showActiveTradeView();
          startTradePolling();
        } else if (statusRes.trade.status === 'cancelled') {
          clearInterval(randomMatchCheckInterval);
          randomMatchCheckInterval = null;
          cleanupTrade(false);
          alert('La solicitud de trade fue rechazada o cancelada.');
          showTradeSelectionView();
        }
      } catch (e) {
        console.error('[TRADES] Error polling acceptance:', e);
      }
    }, 2000);
  }
  
  // Actualizar contador de solicitudes pendientes
  async function updatePendingRequestsCount() {
    try {
      const res = await kvrcards.tradesGetPending();
      const count = (res && res.requests) ? res.requests.length : 0;
      const badge = document.getElementById('pending-count-badge');
      if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'inline-block' : 'none';
      }
    } catch (e) {
      console.error('[TRADES] Error updating pending count:', e);
    }
  }
  
  // Cargar solicitudes pendientes (ahora se llama desde showFriendSelectionView)
  async function loadPendingRequests() {
    const listDiv = document.getElementById('pending-requests-list');
    listDiv.innerHTML = '<div class="pending-requests-loading">Cargando solicitudes...</div>';
    
    try {
      const res = await kvrcards.tradesGetPending();
      console.log('[TRADES] Pending requests:', res);
      
      // Actualizar badge
      const count = (res && res.requests) ? res.requests.length : 0;
      const badge = document.getElementById('pending-count-badge');
      if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'inline-block' : 'none';
      }
      
      if (res && res.requests && res.requests.length > 0) {
        listDiv.innerHTML = '';
        
        for (const request of res.requests) {
          const itemDiv = document.createElement('div');
          itemDiv.className = 'pending-request-item';
          
          // Usar avatar por defecto para no descargar inventarios completos ni consumir ancho de banda
          const avatarUrl = 'default-avatar.png';
          
          const timeAgo = getTimeAgo(request.createdAt);
          
          itemDiv.innerHTML = `
            <div class="pending-request-info">
              <img src="${avatarUrl}" class="pending-request-avatar" alt="${request.from}">
              <div class="pending-request-details">
                <h4>${request.from}</h4>
                <p>Solicitud enviada ${timeAgo}</p>
              </div>
            </div>
            <div class="pending-request-actions">
              <button class="accept-request-btn" data-trade-id="${request.tradeId}" data-username="${request.from}">
                ✓ Aceptar
              </button>
              <button class="reject-request-btn" data-trade-id="${request.tradeId}">
                ✗ Rechazar
              </button>
            </div>
          `;
          
          listDiv.appendChild(itemDiv);
        }
        
        // Añadir event listeners a los botones
        document.querySelectorAll('.accept-request-btn').forEach(btn => {
          btn.addEventListener('click', () => acceptTradeRequest(btn.dataset.tradeId, btn.dataset.username));
        });
        
        document.querySelectorAll('.reject-request-btn').forEach(btn => {
          btn.addEventListener('click', () => rejectTradeRequest(btn.dataset.tradeId));
        });
        
      } else {
        listDiv.innerHTML = '<div class="pending-requests-empty">No tienes solicitudes pendientes</div>';
      }
    } catch (e) {
      console.error('[TRADES] Error loading pending requests:', e);
      listDiv.innerHTML = '<div class="pending-requests-empty">Error cargando solicitudes</div>';
    }
  }
  
  // Aceptar solicitud de trade
  async function acceptTradeRequest(tradeId, username) {
    try {
      console.log('[TRADES] Accepting request:', tradeId);
      const res = await kvrcards.tradesAcceptRequest(tradeId);
      
      if (res && res.ok) {
        // Abrir el trade activo
        currentTradeId = tradeId;
        currentTradeData = res.trade;
        showActiveTradeView();
        startTradePolling();
      } else {
        alert('Error aceptando solicitud: ' + (res.error || 'Error desconocido'));
      }
    } catch (e) {
      console.error('[TRADES] Error accepting request:', e);
      alert('Error de conexión: ' + e.message);
    }
  }
  
  // Rechazar solicitud de trade
  async function rejectTradeRequest(tradeId) {
    try {
      console.log('[TRADES] Rejecting request:', tradeId);
      const res = await kvrcards.tradesRejectRequest(tradeId);
      
      if (res && res.ok) {
        // Recargar la lista de solicitudes
        loadPendingRequests();
      } else {
        alert('Error rechazando solicitud: ' + (res.error || 'Error desconocido'));
      }
    } catch (e) {
      console.error('[TRADES] Error rejecting request:', e);
      alert('Error de conexión: ' + e.message);
    }
  }
  
  // Función auxiliar para calcular "hace cuánto tiempo"
  function getTimeAgo(timestamp) {
    if (!timestamp) return 'hace un momento';
    
    const now = Date.now();
    const diff = now - timestamp;
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `hace ${days} día${days !== 1 ? 's' : ''}`;
    if (hours > 0) return `hace ${hours} hora${hours !== 1 ? 's' : ''}`;
    if (minutes > 0) return `hace ${minutes} minuto${minutes !== 1 ? 's' : ''}`;
    return 'hace un momento';
  }
  
  // Iniciar búsqueda aleatoria
  async function startRandomTrade() {
    tradeSelectionView.style.display = 'none';
    friendSelectionView.style.display = 'none';
    randomSearchView.style.display = 'block';
    activeTradeView.style.display = 'none';
    
    // Restaurar texto original de búsqueda aleatoria
    const searchContent = document.querySelector('.random-search-content');
    if (searchContent) {
      const h3 = searchContent.querySelector('h3');
      const p = searchContent.querySelector('p');
      if (h3) h3.textContent = 'Buscando usuario...';
      if (p) p.textContent = 'Esperando a que otro jugador se una';
    }
    
    try {
      console.log('[TRADES] Joining random queue...');
      const res = await kvrcards.tradesJoinRandomQueue();
      console.log('[TRADES] Queue response:', res);
      
      if (res && res.ok) {
        if (res.status === 'matched' && res.tradeId) {
          // Emparejado inmediatamente
          console.log('[TRADES] Matched immediately!');
          currentTradeId = res.tradeId;
          currentTradeData = res.trade;
          showActiveTradeView();
          startTradePolling();
        } else {
          // En cola, empezar a revisar
          console.log('[TRADES] In queue, starting polling...');
          startRandomMatchChecking();
        }
      } else {
        const errorMsg = res ? (res.error || 'Respuesta inesperada') : 'Sin respuesta del servidor';
        alert('Error uniéndose a la cola: ' + errorMsg);
        console.error('[TRADES] Queue error:', res);
        showTradeSelectionView();
      }
    } catch (e) {
      console.error('[TRADES] Exception joining queue:', e);
      alert('Error de conexión: ' + e.message);
      showTradeSelectionView();
    }
  }
  
  // Revisar si hay match aleatorio
  function startRandomMatchChecking() {
    let attempts = 0;
    const maxAttempts = 60; // 2 minutos máximo (60 * 2s)
    
    randomMatchCheckInterval = setInterval(async () => {
      attempts++;
      
      try {
        console.log('[TRADES] Checking for match... Attempt:', attempts);
        const res = await kvrcards.tradesCheckRandomMatch();
        console.log('[TRADES] Match check response:', res);
        
        if (res && res.matched && res.tradeId) {
          console.log('[TRADES] Match found!');
          clearInterval(randomMatchCheckInterval);
          randomMatchCheckInterval = null;
          currentTradeId = res.tradeId;
          currentTradeData = res.trade;
          showActiveTradeView();
          startTradePolling();
        } else if (attempts >= maxAttempts) {
          console.log('[TRADES] Timeout - no match found');
          clearInterval(randomMatchCheckInterval);
          randomMatchCheckInterval = null;
          alert('No se encontró otro jugador. Intenta de nuevo más tarde.');
          showTradeSelectionView();
        }
      } catch (e) {
        console.error('[TRADES] Error checking match:', e);
        if (attempts >= maxAttempts) {
          clearInterval(randomMatchCheckInterval);
          randomMatchCheckInterval = null;
          alert('Error de conexión buscando emparejamiento.');
          showTradeSelectionView();
        }
      }
    }, 2000);
  }
  
  // Mostrar vista de trade activo
  async function showActiveTradeView() {
    // Verificar que el trade esté en estado 'active'
    if (!currentTradeData || currentTradeData.status !== 'active') {
      console.log('[TRADES] Trade is not active yet, status:', currentTradeData?.status);
      return;
    }
    
    tradeSelectionView.style.display = 'none';
    friendSelectionView.style.display = 'none';
    randomSearchView.style.display = 'none';
    activeTradeView.style.display = 'block';
    
    console.log('========== TRADE VIEW DEBUG ==========');
    console.log('[TRADES] currentTradeData:', JSON.stringify(currentTradeData, null, 2));
    
    // Obtener perfil del usuario actual
    const myProfileResponse = await kvrcards.getProfile();
    console.log('[TRADES] My profile response:', JSON.stringify(myProfileResponse, null, 2));
    
    const myUsername = myProfileResponse.ok && myProfileResponse.profile ? myProfileResponse.profile.username : null;
    
    if (!myUsername) {
      console.error('[TRADES] ERROR: Could not get my username!');
      alert('Error: no se pudo obtener tu nombre de usuario');
      closeTradesModal();
      return;
    }
    
    console.log('[TRADES] ✓ My username is:', myUsername);
    
    // Determinar el otro usuario
    const participants = currentTradeData.participants || [];
    console.log('[TRADES] ✓ All participants array:', JSON.stringify(participants));
    console.log('[TRADES] ✓ Participants length:', participants.length);
    
    // Log cada participant
    participants.forEach((p, idx) => {
      console.log(`[TRADES] Participant ${idx}: "${p}" (type: ${typeof p})`);
      console.log(`[TRADES] Comparing "${p}" === "${myUsername}": ${p === myUsername}`);
      console.log(`[TRADES] Comparing "${p.toLowerCase()}" === "${myUsername.toLowerCase()}": ${p.toLowerCase() === myUsername.toLowerCase()}`);
    });
    
    // Buscar al otro usuario
    const otherUsername = participants.find(p => {
      const isMe = p.toLowerCase() === myUsername.toLowerCase();
      console.log(`[TRADES] Testing participant "${p}": isMe=${isMe}`);
      return !isMe;
    });
    
    if (!otherUsername) {
      console.error('[TRADES] ERROR: Could not find other participant!');
      console.error('[TRADES] My username:', myUsername);
      console.error('[TRADES] Participants:', participants);
      alert('Error: no se pudo identificar al otro jugador');
      closeTradesModal();
      return;
    }
    
    console.log('[TRADES] ✓ Other username is:', otherUsername);
    console.log('[TRADES] ✓ Trade setup: I am "' + myUsername + '" trading with "' + otherUsername + '"');
    console.log('========================================');
    
    // Establecer info de jugadores
    document.getElementById('trade-my-username').textContent = myUsername;
    document.getElementById('trade-other-username').textContent = otherUsername;
    
    // Cargar avatares (optimizado: sin descargar inventarios completos)
    try {
      // Mi avatar - usar el perfil local
      const mySavedAvatar = (typeof userAvatar !== 'undefined' && userAvatar) 
        || (myProfileResponse?.ok && myProfileResponse?.profile?.profileImage) 
        || (typeof currentUser === 'string' ? localStorage.getItem('kvrAvatar_' + currentUser) : '');
      const myAvatar = document.getElementById('trade-my-avatar');
      if (myAvatar) {
        if (mySavedAvatar) {
          myAvatar.src = mySavedAvatar;
          myAvatar.style.display = 'block';
        } else {
          myAvatar.src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(myUsername)}`;
          myAvatar.style.display = 'block';
        }
      }
      
      // Avatar del otro usuario - URL directa optimizada con caché
      const serverBase = window.KVR_SERVER_URL || 'https://kvrcards-server.onrender.com';
      const otherAvatarUrl = currentTradeData?.avatars?.[otherUsername] 
        || `${serverBase}/api/avatar/${encodeURIComponent(otherUsername)}`;
      const otherAvatar = document.getElementById('trade-other-avatar');
      
      if (otherAvatar) {
        otherAvatar.src = otherAvatarUrl;
        otherAvatar.style.display = 'block';
        otherAvatar.onerror = () => {
          otherAvatar.src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(otherUsername)}`;
        };
      }
    } catch (e) {
      console.error('[TRADES] Error loading avatars:', e);
    }
    
    // Cargar y mostrar wallet del usuario
    try {
      const inv = await kvrcards.getInventory();
      if (inv && inv.ok && inv.wallet) {
        const myWalletCoins = inv.wallet.coins || 0;
        const myWalletTraits = inv.wallet.traits || 0;
        const walletCoinsDisplay = document.getElementById('trade-my-wallet');
        const walletTraitsDisplay = document.getElementById('trade-my-traits-wallet');
        if (walletCoinsDisplay) walletCoinsDisplay.textContent = myWalletCoins;
        if (walletTraitsDisplay) walletTraitsDisplay.textContent = myWalletTraits;
        console.log('[TRADES] My wallet balances:', { coins: myWalletCoins, traits: myWalletTraits });
      }
    } catch (e) {
      console.error('[TRADES] Error loading wallet:', e);
    }
    
    // Resetear slots (ahora async)
    await resetTradeSlots();
    
    // Configurar listeners de slots
    setupTradeSlotListeners();
    
    // Iniciar polling para sincronizar ofertas
    startTradePolling();
  }
  
  // Resetear slots de trade
  async function resetTradeSlots() {
    myTradeOffer = { cards: {}, packs: {}, coins: 0, traits: 0, cardTraits: {} };
    const coinsInput = document.getElementById('my-coins-input');
    const traitsInput = document.getElementById('my-traits-input');
    if (coinsInput) coinsInput.value = '0';
    if (traitsInput) traitsInput.value = '0';
    
    for (let i = 1; i <= 3; i++) {
      const slot = document.getElementById(`my-slot-${i}`);
      if (slot) {
        slot.innerHTML = '<div class="trade-slot-empty">+ Añadir Item</div>';
        slot.dataset.itemType = '';
        slot.dataset.itemId = '';
      }
    }
    
    // Activar flag para forzar botón verde
    forceGreenButton = true;
    
    // Resetear confirmación en el servidor si hay un trade activo
    if (currentTradeId && currentTradeData) {
      try {
        const profileResponse = await kvrcards.getProfile();
        const myUsername = profileResponse.ok && profileResponse.profile ? profileResponse.profile.username : null;
        
        if (myUsername && currentTradeData.offers) {
          let myOfferKey = myUsername;
          if (!currentTradeData.offers[myUsername]) {
            myOfferKey = Object.keys(currentTradeData.offers).find(k => k.toLowerCase() === myUsername.toLowerCase());
          }
          
          if (myOfferKey && currentTradeData.offers[myOfferKey] && currentTradeData.offers[myOfferKey].confirmed === true) {
            console.log('[TRADES] Canceling previous confirmation on trade init');
            await kvrcards.tradesCancelConfirm(currentTradeId);
          }
          
          if (myOfferKey && currentTradeData.offers[myOfferKey]) {
            currentTradeData.offers[myOfferKey].confirmed = false;
          }
        }
      } catch (e) {
        console.error('[TRADES] Error resetting confirmation:', e);
      }
    }
    
    const btn = document.getElementById('confirm-trade-btn');
    if (btn) {
      btn.innerHTML = '<span class="confirm-icon">✓</span><span>Confirmar</span>';
      btn.style.background = '';
      btn.disabled = false;
    }
  }
  
  // Configurar listeners de slots
  function setupTradeSlotListeners() {
    // Slots de items 1..3
    for (let i = 1; i <= 3; i++) {
      const slot = document.getElementById(`my-slot-${i}`);
      if (!slot) continue;
      
      slot.onclick = (e) => {
        if (e.target.classList.contains('trade-slot-remove')) return;
        if (!slot.dataset.itemType || !slot.dataset.itemId) {
          openItemSelector(i);
        }
      };
      
      slot.oncontextmenu = (e) => e.preventDefault();
    }
    
    // Input de monedas
    const coinsInput = document.getElementById('my-coins-input');
    if (coinsInput) {
      coinsInput.oninput = async () => {
        let value = parseInt(coinsInput.value) || 0;
        try {
          const inv = await kvrcards.getInventory();
          if (inv && inv.ok && inv.wallet) {
            const maxCoins = inv.wallet.coins || 0;
            if (value > maxCoins) {
              value = maxCoins;
              coinsInput.value = maxCoins;
            }
            if (value < 0) {
              value = 0;
              coinsInput.value = 0;
            }
          }
        } catch (e) {
          console.error('[TRADES] Error validating coins:', e);
        }
        
        myTradeOffer.coins = value;
        updateTradeOffer();
      };
    }

    // Input de traits (tokens)
    const traitsInput = document.getElementById('my-traits-input');
    if (traitsInput) {
      traitsInput.oninput = async () => {
        let value = parseInt(traitsInput.value) || 0;
        try {
          const inv = await kvrcards.getInventory();
          if (inv && inv.ok && inv.wallet) {
            const maxTraits = inv.wallet.traits || 0;
            if (value > maxTraits) {
              value = maxTraits;
              traitsInput.value = maxTraits;
            }
            if (value < 0) {
              value = 0;
              traitsInput.value = 0;
            }
          }
        } catch (e) {
          console.error('[TRADES] Error validating traits currency:', e);
        }
        
        myTradeOffer.traits = value;
        updateTradeOffer();
      };
    }
  }
  
  // Quitar item de un slot
  async function removeItemFromSlot(slotNumber) {
    const slot = document.getElementById(`my-slot-${slotNumber}`);
    if (!slot || !slot.dataset.itemType || !slot.dataset.itemId) return;
    
    const itemType = slot.dataset.itemType;
    const itemId = slot.dataset.itemId;
    
    slot.innerHTML = '<div class="trade-slot-empty">+ Añadir Item</div>';
    slot.dataset.itemType = '';
    slot.dataset.itemId = '';
    
    if (itemType === 'cards') {
      if (myTradeOffer.cards[itemId]) {
        myTradeOffer.cards[itemId]--;
        if (myTradeOffer.cards[itemId] <= 0) {
          delete myTradeOffer.cards[itemId];
        }
      }
    } else if (itemType === 'traitCard') {
      if (myTradeOffer.cardTraits && myTradeOffer.cardTraits[itemId]) {
        delete myTradeOffer.cardTraits[itemId];
      }
    } else if (itemType === 'packs') {
      if (myTradeOffer.packs[itemId]) {
        myTradeOffer.packs[itemId]--;
        if (myTradeOffer.packs[itemId] <= 0) {
          delete myTradeOffer.packs[itemId];
        }
      }
    }
    
    await updateTradeOffer();
    
    if (itemSelectorModal.style.display === 'flex') {
      const activeTab = document.querySelector('.item-selector-tab.active');
      if (activeTab) {
        await loadItemSelectorContent(activeTab.dataset.type);
      }
    }
  }
  
  window.removeItemFromSlot = removeItemFromSlot;
  
  // Abrir selector de items
  async function openItemSelector(slotNumber) {
    selectedSlot = slotNumber;
    itemSelectorModal.style.display = 'flex';
    
    const searchInput = document.getElementById('item-selector-search-input');
    if (searchInput) {
      searchInput.value = '';
      searchInput.oninput = () => filterItems(searchInput.value);
    }
    
    // Cargar cartas normales por defecto
    await loadItemSelectorContent('cards');
  }
  
  function closeItemSelector() {
    itemSelectorModal.style.display = 'none';
    selectedSlot = null;
  }
  
  function filterItems(searchTerm) {
    const cards = document.querySelectorAll('.trade-item-card');
    const term = searchTerm.toLowerCase().trim();
    
    cards.forEach(card => {
      const name = card.querySelector('.item-name')?.textContent.toLowerCase() || '';
      const traitText = card.querySelector('.trade-item-trait-chip')?.textContent.toLowerCase() || '';
      if (name.includes(term) || traitText.includes(term)) {
        card.style.display = 'flex';
      } else {
        card.style.display = 'none';
      }
    });
  }
  
  // Obtener items ya usados en el trade
  function getUsedItems() {
    const used = { cards: {}, packs: {}, traitCards: {} };
    
    for (let i = 1; i <= 3; i++) {
      const slot = document.getElementById(`my-slot-${i}`);
      if (!slot) continue;
      const itemType = slot.dataset.itemType;
      const itemId = slot.dataset.itemId;
      
      if (itemType && itemId) {
        if (itemType === 'cards') {
          used.cards[itemId] = (used.cards[itemId] || 0) + 1;
        } else if (itemType === 'traitCard') {
          used.traitCards[itemId] = true;
        } else if (itemType === 'packs') {
          used.packs[itemId] = (used.packs[itemId] || 0) + 1;
        }
      }
    }
    
    return used;
  }
  
  // Cargar contenido del selector
  async function loadItemSelectorContent(type) {
    const listDiv = document.getElementById('item-selector-list');
    if (!listDiv) return;
    listDiv.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:30px;font-weight:700;">Cargando inventario...</div>';
    
    const usedItems = getUsedItems();

    // Cargar calidades para verificar tradeable en todas las pestañas de cartas
    let qualitiesTradeMap = new Map();
    try {
      if (window.kvrcards && window.kvrcards.getQualities) {
        const qs = await window.kvrcards.getQualities();
        if (Array.isArray(qs)) {
          qs.forEach(q => {
            if (q && q.name) qualitiesTradeMap.set(q.name.toLowerCase(), q);
            if (q && q.id) qualitiesTradeMap.set(q.id.toLowerCase(), q);
          });
        }
      }
    } catch {}
    
    try {
      if (type === 'cards') {
        // Cargar cartas normales (sin trait)
        const [allCards, inv] = await Promise.all([
          kvrcards.getAllCards(),
          kvrcards.getInventory()
        ]);
        
        const counts = inv.ok ? (inv.cards || {}) : {};
        const cardTraits = inv.ok ? (inv.cardTraits || {}) : {};
        
        if (Object.keys(counts).length === 0) {
          listDiv.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:30px;font-weight:700;">No tienes cartas en tu inventario</div>';
          return;
        }
        
        listDiv.innerHTML = '';
        const cardMap = new Map(allCards.map(c => [c.id, c]));
        
        // Contar cuántas instancias con trait tiene cada cardId
        const traitInstancesByCardId = {};
        for (const [instId, tData] of Object.entries(cardTraits)) {
          const cId = tData.cardId || tData;
          traitInstancesByCardId[cId] = (traitInstancesByCardId[cId] || 0) + 1;
        }
        
        let renderedCount = 0;

        for (const [cardId, totalCount] of Object.entries(counts)) {
          const cardData = cardMap.get(cardId);
          const qObj = cardData?.calidad ? qualitiesTradeMap.get(cardData.calidad.toLowerCase()) : null;
          
          // FILTRO: No tradeables o Evos
          if (cardData && (cardData.tradeable === false || (qObj && qObj.tradeable === false) || cardData.calidad === 'Evo')) {
            continue;
          }
          
          // Copias limpias sin trait
          const traitCount = traitInstancesByCardId[cardId] || 0;
          const cleanTotal = Math.max(0, totalCount - traitCount);
          const usedCount = usedItems.cards[cardId] || 0;
          const availableCount = cleanTotal - usedCount;
          
          if (availableCount > 0) {
            renderedCount++;
            const card = document.createElement('div');
            card.className = 'trade-item-card';
            
            const imageUrl = cardData && cardData.imageUrl ? cardData.imageUrl : `uploads/${cardId}.png`;
            const cardName = cardData ? cardData.name : cardId;
            
            card.innerHTML = `
              <img src="${imageUrl}" alt="${cardName}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
              <div style="height:160px;display:none;align-items:center;justify-content:center;"><img src="./icon-oro.png" style="width:54px;height:auto;object-fit:contain;" alt="Carta"></div>
              <div class="item-name">${cardName}</div>
              <div class="item-count">Disponibles: ${availableCount}</div>
            `;
            card.onclick = () => selectItem('cards', cardId, cardName, imageUrl);
            listDiv.appendChild(card);
          }
        }
        
        if (renderedCount === 0) {
          listDiv.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:30px;font-weight:700;">No tienes cartas normales disponibles para tradear</div>';
        }
      } else if (type === 'traitCards') {
        // Cargar cartas que TIENEN un trait asignado (separadas como instancias únicas)
        const [tradeCat, inv] = await Promise.all([
          getCachedTradeCatalog(),
          kvrcards.getInventory()
        ]);
        
        const cardTraits = inv.ok ? (inv.cardTraits || {}) : {};
        const cardMap = tradeCat.cardMap;
        const traitsMap = tradeCat.traitsMap;
        
        const traitInstances = Object.entries(cardTraits);
        
        if (traitInstances.length === 0) {
          listDiv.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:30px;font-weight:700;">No tienes cartas con Traits asignados</div>';
          return;
        }
        
        listDiv.innerHTML = '';
        let renderedCount = 0;
        
        for (const [instanceId, tData] of traitInstances) {
          if (usedItems.traitCards[instanceId]) continue;
          
          const baseCardId = tData.cardId || tData;
          const traitId = tData.traitId || (typeof tData === 'string' ? tData : null);
          const cardData = cardMap.get(baseCardId);
          const qObj = cardData?.calidad ? qualitiesTradeMap.get(cardData.calidad.toLowerCase()) : null;
          if (cardData && (cardData.tradeable === false || (qObj && qObj.tradeable === false) || cardData.calidad === 'Evo')) {
            continue;
          }
          
          const traitInfo = traitsMap.get(traitId) || { name: traitId || 'Trait Asignado', imageUrl: '' };
          const imageUrl = cardData && cardData.imageUrl ? cardData.imageUrl : `uploads/${baseCardId}.png`;
          const cardName = cardData ? cardData.name : baseCardId;
          
          renderedCount++;
          const card = document.createElement('div');
          card.className = 'trade-item-card trade-item-card-trait';
          const traitIconSrc = traitInfo.imageUrl || 'trait.png';
          
          card.innerHTML = `
            <div class="trade-card-wrapper" style="height:205px;">
              <img src="${imageUrl}" alt="${cardName}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
              <div style="height:200px;display:none;align-items:center;justify-content:center;"><img src="trait.png" style="width:48px;height:48px;object-fit:contain;" /></div>
              <div class="trade-card-trait-icon" title="${traitInfo.name}">
                <img src="${traitIconSrc}" alt="${traitInfo.name}" onerror="this.src='trait.png'" />
              </div>
            </div>
            <div class="item-name">${cardName}</div>
            <div class="item-count" style="color:#38bdf8;font-weight:700;">${traitInfo.name}</div>
          `;
          
          card.onclick = () => selectItem('traitCard', instanceId, `${cardName} [${traitInfo.name}]`, imageUrl, {
            instanceId,
            cardId: baseCardId,
            traitId,
            traitName: traitInfo.name,
            traitImg: traitInfo.imageUrl
          });
          
          listDiv.appendChild(card);
        }
        
        if (renderedCount === 0) {
          listDiv.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:30px;font-weight:700;">Todas tus cartas con trait ya están en la oferta</div>';
        }
      } else {
        // Cargar sobres
        const [allPacks, inv] = await Promise.all([
          kvrcards.getAllPacks(),
          kvrcards.getInventory()
        ]);
        
        const packCounts = inv.ok ? (inv.packs || {}) : {};
        
        if (Object.keys(packCounts).length === 0) {
          listDiv.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:30px;font-weight:700;">No tienes sobres en tu inventario</div>';
          return;
        }
        
        listDiv.innerHTML = '';
        const packMap = new Map(allPacks.map(p => [p.id, p]));
        let renderedCount = 0;
        
        for (const [packId, count] of Object.entries(packCounts)) {
          const usedCount = usedItems.packs[packId] || 0;
          const availableCount = count - usedCount;
          
          if (availableCount > 0) {
            renderedCount++;
            const packData = packMap.get(packId);
            const card = document.createElement('div');
            card.className = 'trade-item-card';
            
            const imageUrl = packData && packData.imageUrl ? packData.imageUrl : `uploads/${packId}.png`;
            const packName = packData ? packData.name : packId;
            
            card.innerHTML = `
              <img src="${imageUrl}" alt="${packName}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" />
              <div style="height:200px;display:none;align-items:center;justify-content:center;"><img src="./sobre_oro.png" style="width:60px;height:auto;object-fit:contain;" alt="Sobre"></div>
              <div class="item-name">${packName}</div>
              <div class="item-count">Disponibles: ${availableCount}</div>
            `;
            card.onclick = () => selectItem('packs', packId, packName, imageUrl);
            listDiv.appendChild(card);
          }
        }
        
        if (renderedCount === 0) {
          listDiv.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:30px;font-weight:700;">No tienes más sobres disponibles</div>';
        }
      }
    } catch (e) {
      console.error('[TRADES] Error loading items:', e);
      listDiv.innerHTML = '<div style="color:#ef4444;text-align:center;padding:30px;font-weight:700;">Error cargando items del inventario</div>';
    }
  }
  
  // Seleccionar item
  async function selectItem(type, itemId, itemName, itemImage, extraData = null) {
    const slot = document.getElementById(`my-slot-${selectedSlot}`);
    const slotNumber = selectedSlot;
    if (!slot) return;
    
    if (type === 'traitCard' && extraData) {
      const traitIconSrc = extraData.traitImg || 'trait.png';
      slot.innerHTML = `
        <button class="trade-slot-remove" onclick="event.stopPropagation(); removeItemFromSlot(${slotNumber})">×</button>
        <div class="trade-card-wrapper">
          <img src="${itemImage}" style="max-width:90%;max-height:90%;object-fit:contain;" alt="${itemName}" />
          <div class="trade-card-trait-icon" title="${extraData.traitName}">
            <img src="${traitIconSrc}" alt="${extraData.traitName}" onerror="this.src='trait.png'" />
          </div>
        </div>
      `;
      slot.dataset.itemType = 'traitCard';
      slot.dataset.itemId = itemId;
      
      if (!myTradeOffer.cardTraits) myTradeOffer.cardTraits = {};
      myTradeOffer.cardTraits[itemId] = {
        cardId: extraData.cardId,
        traitId: extraData.traitId
      };
    } else if (itemImage) {
      const isPack = (type === 'packs');
      const maxW = isPack ? '60%' : '90%';
      const maxH = isPack ? '60%' : '90%';
      slot.innerHTML = `
        <button class="trade-slot-remove" onclick="event.stopPropagation(); removeItemFromSlot(${slotNumber})">×</button>
        <div class="trade-card-wrapper">
          <img src="${itemImage}" style="max-width:${maxW};max-height:${maxH};object-fit:contain;" alt="${itemName}" />
        </div>
      `;
      slot.dataset.itemType = type;
      slot.dataset.itemId = itemId;
      
      if (type === 'cards') {
        myTradeOffer.cards[itemId] = (myTradeOffer.cards[itemId] || 0) + 1;
      } else {
        myTradeOffer.packs[itemId] = (myTradeOffer.packs[itemId] || 0) + 1;
      }
    } else {
      slot.innerHTML = `
        <button class="trade-slot-remove" onclick="event.stopPropagation(); removeItemFromSlot(${slotNumber})">×</button>
        <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;height:100%;">
          <div style="font-size:32px;display:flex;align-items:center;justify-content:center;">${type === 'cards' ? '<img src="./icon-oro.png" style="width:36px;height:auto;object-fit:contain;" alt="Carta">' : '<img src="./sobre_oro.png" style="width:36px;height:auto;object-fit:contain;" alt="Sobre">'}</div>
          <div style="color:white;font-size:12px;text-align:center;font-weight:700;">${itemName}</div>
        </div>
      `;
      slot.dataset.itemType = type;
      slot.dataset.itemId = itemId;
      
      if (type === 'cards') {
        myTradeOffer.cards[itemId] = (myTradeOffer.cards[itemId] || 0) + 1;
      } else {
        myTradeOffer.packs[itemId] = (myTradeOffer.packs[itemId] || 0) + 1;
      }
    }
    
    closeItemSelector();
    await updateTradeOffer();
  }
  
  // Actualizar oferta en el servidor
  async function updateTradeOffer() {
    if (!currentTradeId) {
      console.error('[TRADES] Cannot update offer: no currentTradeId');
      return;
    }
    
    console.log('[TRADES] ========== UPDATING MY OFFER ==========');
    console.log('[TRADES] My offer payload:', JSON.stringify(myTradeOffer, null, 2));
    
    try {
      const res = await kvrcards.tradesUpdateOffer(
        currentTradeId,
        myTradeOffer.cards,
        myTradeOffer.packs,
        myTradeOffer.coins,
        myTradeOffer.traits || 0,
        myTradeOffer.cardTraits || {}
      );
      
      if (res.ok && res.trade) {
        currentTradeData = res.trade;
        await updateMySlots();
        await updateConfirmButton();
      } else {
        console.error('[TRADES] Failed to update offer:', res.error);
      }
    } catch (e) {
      console.error('[TRADES] Error updating offer:', e);
    }
  }
  
  // Actualizar visualización de mis slots
  async function updateMySlots() {
    if (!currentTradeData) return;
    
    try {
      const profileResponse = await kvrcards.getProfile();
      const myUsername = profileResponse.ok && profileResponse.profile ? profileResponse.profile.username : null;
      if (!myUsername) return;
      
      const myOffer = currentTradeData.offers[myUsername] || currentTradeData.offers[Object.keys(currentTradeData.offers).find(k => k.toLowerCase() === myUsername.toLowerCase())];
      if (!myOffer) return;
      
      for (let i = 1; i <= 3; i++) {
        const slot = document.getElementById(`my-slot-${i}`);
        if (slot) {
          slot.innerHTML = '<div class="trade-slot-empty">+ Añadir Item</div>';
          delete slot.dataset.itemType;
          delete slot.dataset.itemId;
        }
      }
      
      let slotIndex = 1;
      
      const tradeCat = await getCachedTradeCatalog();
      const cardMap = tradeCat.cardMap;
      const packMap = tradeCat.packMap;
      const traitsMap = tradeCat.traitsMap;
      
      // 1. Render trait cards
      for (const [instanceId, tData] of Object.entries(myOffer.cardTraits || {})) {
        if (slotIndex > 3) break;
        const slot = document.getElementById(`my-slot-${slotIndex}`);
        const baseCardId = tData.cardId;
        const cardData = cardMap.get(baseCardId);
        const traitInfo = traitsMap.get(tData.traitId) || { name: 'Trait' };
        const traitIconSrc = traitInfo.imageUrl || 'trait.png';
        const imageUrl = cardData && cardData.imageUrl ? cardData.imageUrl : `uploads/${baseCardId}.png`;
        const currentSlot = slotIndex;
        
        slot.innerHTML = `
          <button class="trade-slot-remove" onclick="event.stopPropagation(); removeItemFromSlot(${currentSlot})">×</button>
          <div class="trade-card-wrapper">
            <img src="${imageUrl}" style="max-width:90%;max-height:90%;object-fit:contain;" alt="${cardData ? cardData.name : baseCardId}" />
            <div class="trade-card-trait-icon" title="${traitInfo.name}">
              <img src="${traitIconSrc}" alt="${traitInfo.name}" onerror="this.src='trait.png'" />
            </div>
          </div>
        `;
        slot.dataset.itemType = 'traitCard';
        slot.dataset.itemId = instanceId;
        slotIndex++;
      }
      
      // 2. Render regular cards
      for (const [cardId, count] of Object.entries(myOffer.cards || {})) {
        for (let i = 0; i < count && slotIndex <= 3; i++) {
          const slot = document.getElementById(`my-slot-${slotIndex}`);
          const cardData = cardMap.get(cardId);
          const imageUrl = cardData && cardData.imageUrl ? cardData.imageUrl : `uploads/${cardId}.png`;
          const currentSlot = slotIndex;
          
          slot.innerHTML = `
            <button class="trade-slot-remove" onclick="event.stopPropagation(); removeItemFromSlot(${currentSlot})">×</button>
            <div style="position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center;padding:8px;">
              <img src="${imageUrl}" style="max-width:90%;max-height:90%;object-fit:contain;" alt="${cardData ? cardData.name : cardId}" />
            </div>
          `;
          slot.dataset.itemType = 'cards';
          slot.dataset.itemId = cardId;
          slotIndex++;
        }
      }
      
      // 3. Render packs
      for (const [packId, count] of Object.entries(myOffer.packs || {})) {
        for (let i = 0; i < count && slotIndex <= 3; i++) {
          const slot = document.getElementById(`my-slot-${slotIndex}`);
          const packData = packMap.get(packId);
          const imageUrl = packData && packData.imageUrl ? packData.imageUrl : `uploads/${packId}.png`;
          const currentSlot = slotIndex;
          
          slot.innerHTML = `
            <button class="trade-slot-remove" onclick="event.stopPropagation(); removeItemFromSlot(${currentSlot})">×</button>
            <div style="position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center;padding:8px;">
              <img src="${imageUrl}" style="max-width:60%;max-height:60%;object-fit:contain;" alt="${packData ? packData.name : packId}" />
            </div>
          `;
          slot.dataset.itemType = 'packs';
          slot.dataset.itemId = packId;
          slotIndex++;
        }
      }
      
      // Actualizar inputs de monedas y traits
      const coinsInput = document.getElementById('my-coins-input');
      if (coinsInput) coinsInput.value = myOffer.coins || 0;
      const traitsInput = document.getElementById('my-traits-input');
      if (traitsInput) traitsInput.value = myOffer.traits || 0;
      
    } catch (e) {
      console.error('[TRADES] Error updating my slots:', e);
    }
  }
  
  // Actualizar botón de confirmar
  async function updateConfirmButton() {
    const btn = document.getElementById('confirm-trade-btn');
    if (!btn) return;
    
    if (forceGreenButton) {
      btn.innerHTML = '<span class="confirm-icon">✓</span><span>Confirmar</span>';
      btn.style.background = '';
      btn.disabled = false;
      return;
    }
    
    let hasConfirmed = false;
    
    if (currentTradeData && currentTradeData.offers) {
      try {
        const profileResponse = await kvrcards.getProfile();
        const myUsername = profileResponse.ok && profileResponse.profile ? profileResponse.profile.username : null;
        
        if (myUsername) {
          const myOffer = currentTradeData.offers[myUsername] || currentTradeData.offers[Object.keys(currentTradeData.offers).find(k => k.toLowerCase() === myUsername.toLowerCase())];
          if (myOffer && myOffer.confirmed === true) {
            hasConfirmed = true;
          }
        }
      } catch (e) {
        console.error('[TRADES] Error checking confirmation status:', e);
      }
    }
    
    if (hasConfirmed) {
      btn.innerHTML = '<span class="confirm-icon">✕</span><span>Cancelar</span>';
      btn.style.background = 'linear-gradient(135deg, #dc2626 0%, #991b1b 100%)';
      btn.disabled = false;
    } else {
      btn.innerHTML = '<span class="confirm-icon">✓</span><span>Confirmar</span>';
      btn.style.background = '';
      btn.disabled = false;
    }
  }
  
  // Confirmar o cancelar trade
  async function confirmTrade() {
    if (!currentTradeId) return;
    
    let hasConfirmed = false;
    
    if (!forceGreenButton && currentTradeData && currentTradeData.offers) {
      try {
        const profileResponse = await kvrcards.getProfile();
        const myUsername = profileResponse.ok && profileResponse.profile ? profileResponse.profile.username : null;
        
        if (myUsername) {
          const myOffer = currentTradeData.offers[myUsername] || currentTradeData.offers[Object.keys(currentTradeData.offers).find(k => k.toLowerCase() === myUsername.toLowerCase())];
          if (myOffer && myOffer.confirmed === true) {
            hasConfirmed = true;
          }
        }
      } catch (e) {
        console.error('[TRADES] Error getting username:', e);
        return;
      }
    }
    
    if (hasConfirmed) {
      console.log('[TRADES] Canceling confirmation:', currentTradeId);
      try {
        const res = await kvrcards.tradesCancelConfirm(currentTradeId);
        if (res && res.ok) {
          forceGreenButton = true;
          if (res.trade) currentTradeData = res.trade;
          
          document.getElementById('trade-status').textContent = 'Has cancelado tu confirmación';
          document.getElementById('trade-status').style.color = '#fbbf24';
          
          await updateConfirmButton();
          await updateTradeDisplay();
        } else {
          alert('Error al cancelar: ' + (res?.error || 'No se pudo cancelar'));
        }
      } catch (e) {
        console.error('[TRADES] Error canceling confirmation:', e);
      }
      return;
    }
    
    console.log('[TRADES] Confirming trade:', currentTradeId);
    forceGreenButton = false;
    
    try {
      if (!tradeInventoryBeforeComplete) {
        try {
          const invBeforeTrade = await kvrcards.getInventory();
          if (invBeforeTrade?.ok) {
            tradeInventoryBeforeComplete = invBeforeTrade.cards || {};
          }
        } catch {}
      }

      const res = await kvrcards.tradesConfirmTrade(currentTradeId);
      console.log('[TRADES] Confirm response:', res);
      
      if (res.ok && res.trade) {
        currentTradeData = res.trade;
        
        if (res.trade.status === 'completed') {
          console.log('[TRADES] Trade is COMPLETED! Executing completion...');
          
          if (tradeUpdateInterval) {
            clearInterval(tradeUpdateInterval);
            tradeUpdateInterval = null;
          }
          
          document.getElementById('trade-status').textContent = '¡Trade completado! Actualizando inventarios...';
          document.getElementById('trade-status').style.color = '#10b981';
          
          await playTradeAnimation();

          try {
            const otherOfferCards = currentTradeData?.otherOfferCards || {};
            await applyDuplicatePrestigeXp(otherOfferCards, tradeInventoryBeforeComplete || {});
          } catch (e) {
            console.warn('[PRESTIGE] Warning on duplicate prestige XP:', e?.message || e);
          }
          
          // Recargar inventario desde el servidor
          await new Promise(resolve => setTimeout(resolve, 500));
          try {
            await kvrcards.inventoryReloadFromServer();
          } catch (e) {
            console.error('[TRADES] Error reloading from server:', e);
          }
          
          // Refrescar UI completa
          try {
            await Promise.all([
              renderCollection(), 
              renderOwnedPacks(),
              updateMissionsProgress(),
              updateKizunasProgress(), 
              renderWallet()
            ]);
          } catch (e) {
            console.error('[TRADES] Error refreshing UI:', e);
          }
          
          setTimeout(() => {
            alert('¡Trade completado con éxito! Tu inventario se ha actualizado.');
            cleanupTrade(false);
            closeTradesModal();
          }, 400);
          
        } else {
          document.getElementById('trade-status').textContent = 'Esperando confirmación del otro jugador...';
          document.getElementById('trade-status').style.color = '#fbbf24';
          await updateConfirmButton();
        }
      } else {
        alert('Error al confirmar: ' + (res.error || 'Desconocido'));
      }
    } catch (e) {
      console.error('[TRADES] Error confirming trade:', e);
      alert('Error confirmando trade: ' + e.message);
    }
  }
  
  // Cancelar trade y salir inmediatamente a la selección
  async function cancelTrade() {
    const tradeToCancel = currentTradeId;
    console.log('[TRADES] Canceling active trade:', tradeToCancel);
    
    // 1. Detener inmediatamente polling y cerrar selector si estaba abierto
    closeItemSelector();
    if (tradeUpdateInterval) {
      clearInterval(tradeUpdateInterval);
      tradeUpdateInterval = null;
    }
    
    // 2. Limpiar y regresar a la vista de selección
    cleanupTrade(false);
    showTradeSelectionView();
    alert('Has cancelado el trade.');
    
    // 3. Notificar al servidor en segundo plano
    if (tradeToCancel) {
      try {
        await kvrcards.tradesCancelTrade(tradeToCancel);
      } catch (e) {
        console.warn('[TRADES] Error canceling trade on server:', e);
      }
    }
  }
  
  // Animación del trade completado: los items de la izquierda pasan a la derecha y viceversa
  async function playTradeAnimation() {
    return new Promise((resolve) => {
      const mySlots = ['my-slot-1', 'my-slot-2', 'my-slot-3'];
      const otherSlots = ['other-slot-1', 'other-slot-2', 'other-slot-3'];
      
      const myCoins = document.getElementById('my-coins-input');
      const otherCoins = document.getElementById('other-coins-display');
      const myTraits = document.getElementById('my-traits-input');
      const otherTraits = document.getElementById('other-traits-display');
      
      // Guardar contenido HTML y valores de ambos lados ANTES de animar
      const mySlotContents = mySlots.map(id => {
        const el = document.getElementById(id);
        return el ? el.innerHTML : '<div class="trade-slot-empty">+ Añadir Item</div>';
      });
      const otherSlotContents = otherSlots.map(id => {
        const el = document.getElementById(id);
        return el ? el.innerHTML : '<div class="trade-slot-empty">Esperando item...</div>';
      });
      
      const myCoinsValue = myCoins ? (myCoins.value || '0') : '0';
      const otherCoinsValue = otherCoins ? (otherCoins.textContent || '0') : '0';
      const myTraitsValue = myTraits ? (myTraits.value || '0') : '0';
      const otherTraitsValue = otherTraits ? (otherTraits.textContent || '0') : '0';
      
      // PASO 1: Animar mis slots y divisas hacia la derecha (hacia el rival)
      mySlots.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
          el.style.transition = 'transform 0.75s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.45s ease';
          el.style.transform = 'translateX(450px) scale(0.85)';
          el.style.opacity = '0.05';
        }
      });
      
      // Animar slots y divisas del oponente hacia la izquierda (hacia mí)
      otherSlots.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
          el.style.transition = 'transform 0.75s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.45s ease';
          el.style.transform = 'translateX(-450px) scale(0.85)';
          el.style.opacity = '0.05';
        }
      });

      // PASO 2: En el cruce (750ms), intercambiar el contenido visual y valores
      setTimeout(() => {
        mySlots.forEach((id, index) => {
          const mySlot = document.getElementById(id);
          const otherSlot = document.getElementById(otherSlots[index]);
          
          if (mySlot && otherSlot) {
            // Lo del oponente ahora aparece en mis slots
            mySlot.innerHTML = otherSlotContents[index];
            otherSlot.innerHTML = mySlotContents[index];
            
            // Remover cualquier botón de eliminar que haya quedado
            mySlot.querySelectorAll('.trade-slot-remove').forEach(b => b.remove());
            otherSlot.querySelectorAll('.trade-slot-remove').forEach(b => b.remove());
            
            // Posicionar temporalmente en el lado contrario para entrar suavemente
            mySlot.style.transition = 'none';
            mySlot.style.transform = 'translateX(-50px) scale(0.9)';
            mySlot.style.opacity = '0.3';
            
            otherSlot.style.transition = 'none';
            otherSlot.style.transform = 'translateX(50px) scale(0.9)';
            otherSlot.style.opacity = '0.3';
          }
        });
        
        // Intercambiar divisas
        if (myCoins) myCoins.value = otherCoinsValue;
        if (otherCoins) otherCoins.textContent = myCoinsValue;
        if (myTraits) myTraits.value = otherTraitsValue;
        if (otherTraits) otherTraits.textContent = myTraitsValue;
        
        // Forzar reflow
        document.body.offsetHeight;
        
        // PASO 3: Acomodar suavemente a la posición final con brillo
        setTimeout(() => {
          [...mySlots, ...otherSlots].forEach(id => {
            const el = document.getElementById(id);
            if (el) {
              el.style.transition = 'all 0.5s cubic-bezier(0.16, 1, 0.3, 1)';
              el.style.transform = 'translateX(0) scale(1)';
              el.style.opacity = '1';
              el.style.boxShadow = '0 0 25px rgba(251, 191, 36, 0.6), inset 0 0 15px rgba(56, 189, 248, 0.4)';
            }
          });
        }, 50);
        
        // Finalizar promesa tras terminar el asentamiento
        setTimeout(() => {
          [...mySlots, ...otherSlots].forEach(id => {
            const el = document.getElementById(id);
            if (el) {
              el.style.transition = '';
              el.style.transform = '';
              el.style.boxShadow = '';
            }
          });
          resolve();
        }, 700);
      }, 750);
    });
  }

  // Fallback function for trade changes
  async function applyTradeChanges() {
    return true;
  }
  
  // Polling de trade activo
  function startTradePolling() {
    if (tradeUpdateInterval) clearInterval(tradeUpdateInterval);
    
    tradeUpdateInterval = setInterval(async () => {
      if (!currentTradeId) {
        clearInterval(tradeUpdateInterval);
        tradeUpdateInterval = null;
        return;
      }
      
      try {
        const statusRes = await kvrcards.tradesGetStatus(currentTradeId);
        
        // Si el trade ya no existe o da error (el rival canceló o salió)
        if (!statusRes || !statusRes.ok || !statusRes.trade) {
          clearInterval(tradeUpdateInterval);
          tradeUpdateInterval = null;
          cleanupTrade(false);
          showTradeSelectionView();
          alert('El trade ha sido cancelado o el rival ha salido.');
          return;
        }
        
        currentTradeData = statusRes.trade;
        
        if (statusRes.trade.status === 'completed') {
          clearInterval(tradeUpdateInterval);
          tradeUpdateInterval = null;
          document.getElementById('trade-status').textContent = '¡Trade completado!';
          document.getElementById('trade-status').style.color = '#10b981';
          
          if (typeof window.recordTradeCompleted === 'function') {
            try {
              window.recordTradeCompleted();
            } catch (tradeErr) {
              console.warn('[MISSIONS] Error registrando trade completado:', tradeErr);
            }
          }
          
          await playTradeAnimation();
          
          try {
            await kvrcards.inventoryReloadFromServer();
            await Promise.all([renderCollection(), renderOwnedPacks(), renderWallet()]);
          } catch {}
          
          setTimeout(() => {
            alert('¡Trade completado con éxito!');
            cleanupTrade(false);
            showTradeSelectionView();
          }, 400);
          return;
        }
        
        if (statusRes.trade.status === 'cancelled') {
          clearInterval(tradeUpdateInterval);
          tradeUpdateInterval = null;
          cleanupTrade(false);
          showTradeSelectionView();
          alert('El otro jugador ha cancelado o cerrado el trade.');
          return;
        }
        
        await updateTradeDisplay();
      } catch (e) {
        console.error('[TRADES] Error polling trade:', e);
      }
    }, 1500);
    
    setTimeout(() => updateTradeDisplay(), 300);
  }
  
  // Actualizar display del trade
  async function updateTradeDisplay() {
    if (!currentTradeData) return;
    
    try {
      const profileResponse = await kvrcards.getProfile();
      const myUsername = profileResponse.ok && profileResponse.profile ? profileResponse.profile.username : null;
      if (!myUsername) return;
      
      const participants = currentTradeData.participants || [];
      const otherUsername = participants.find(p => p.toLowerCase() !== myUsername.toLowerCase());
      if (!otherUsername) return;
      
      let otherOffer = currentTradeData.offers[otherUsername] || currentTradeData.offers[Object.keys(currentTradeData.offers).find(k => k.toLowerCase() === otherUsername.toLowerCase())];
      
      if (otherOffer) {
        // Actualizar monedas y traits del oponente
        const otherCoinsDisplay = document.getElementById('other-coins-display');
        if (otherCoinsDisplay) otherCoinsDisplay.textContent = otherOffer.coins || '0';
        const otherTraitsDisplay = document.getElementById('other-traits-display');
        if (otherTraitsDisplay) otherTraitsDisplay.textContent = otherOffer.traits || '0';
        
        const currentOfferJson = JSON.stringify(otherOffer);
        if (currentOfferJson === lastRenderedOtherOfferJson) {
          if (otherOffer.confirmed) {
            const statusEl = document.getElementById('trade-status');
            if (statusEl) {
              statusEl.textContent = 'El rival ha confirmado su oferta.';
              statusEl.style.color = '#38bdf8';
            }
          }
          await updateConfirmButton();
          return;
        }
        lastRenderedOtherOfferJson = currentOfferJson;

        // Limpiar slots del oponente
        for (let i = 1; i <= 3; i++) {
          const slot = document.getElementById(`other-slot-${i}`);
          if (slot) slot.innerHTML = '<div class="trade-slot-empty">Esperando item...</div>';
        }
        
        let slotIndex = 1;
        const tradeCat = await getCachedTradeCatalog();
        const cardMap = tradeCat.cardMap;
        const packMap = tradeCat.packMap;
        const traitsMap = tradeCat.traitsMap;
        
        // 1. Mostrar trait cards del oponente
        for (const [instanceId, tData] of Object.entries(otherOffer.cardTraits || {})) {
          if (slotIndex > 3) break;
          const slot = document.getElementById(`other-slot-${slotIndex}`);
          const baseCardId = tData.cardId;
          const cardData = cardMap.get(baseCardId);
          const traitInfo = traitsMap.get(tData.traitId) || { name: 'Trait' };
          const traitIconSrc = traitInfo.imageUrl || 'trait.png';
          const imageUrl = cardData && cardData.imageUrl ? cardData.imageUrl : `uploads/${baseCardId}.png`;
          
          slot.innerHTML = `
            <div class="trade-card-wrapper">
              <img src="${imageUrl}" style="max-width:90%;max-height:90%;object-fit:contain;" alt="${cardData ? cardData.name : baseCardId}" />
              <div class="trade-card-trait-icon" title="${traitInfo.name}">
                <img src="${traitIconSrc}" alt="${traitInfo.name}" onerror="this.src='trait.png'" />
              </div>
            </div>
          `;
          slotIndex++;
        }
        
        // 2. Mostrar cartas normales del oponente
        for (const [cardId, count] of Object.entries(otherOffer.cards || {})) {
          for (let i = 0; i < count && slotIndex <= 3; i++) {
            const slot = document.getElementById(`other-slot-${slotIndex}`);
            const cardData = cardMap.get(cardId);
            const imageUrl = cardData && cardData.imageUrl ? cardData.imageUrl : `uploads/${cardId}.png`;
            
            slot.innerHTML = `
              <div style="position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center;padding:8px;">
                <img src="${imageUrl}" alt="${cardData ? cardData.name : cardId}" style="max-width:90%;max-height:90%;object-fit:contain;" />
              </div>
            `;
            slotIndex++;
          }
        }
        
        // 3. Mostrar sobres del oponente
        for (const [packId, count] of Object.entries(otherOffer.packs || {})) {
          for (let i = 0; i < count && slotIndex <= 3; i++) {
            const slot = document.getElementById(`other-slot-${slotIndex}`);
            const packData = packMap.get(packId);
            const imageUrl = packData && packData.imageUrl ? packData.imageUrl : `uploads/${packId}.png`;
            
            slot.innerHTML = `
              <div style="position:relative;width:100%;height:100%;display:flex;align-items:center;justify-content:center;padding:8px;">
                <img src="${imageUrl}" alt="${packData ? packData.name : packId}" style="max-width:60%;max-height:60%;object-fit:contain;" />
              </div>
            `;
            slotIndex++;
          }
        }
        
        if (otherOffer.confirmed) {
          document.getElementById('trade-status').textContent = '¡El rival ha confirmado su oferta!';
          document.getElementById('trade-status').style.color = '#38bdf8';
        }
      }
      
      await updateConfirmButton();
      
    } catch (e) {
      console.error('[TRADES] Error in updateTradeDisplay:', e);
    }
  }
  
  // Event listeners para trades
  tradesToggle?.addEventListener('click', openTradesModal);
  closeTradesBtn?.addEventListener('click', () => {
    if (currentTradeId && activeTradeView.style.display !== 'none' && currentTradeData?.status !== 'completed') {
      if (confirm('¿Quieres salir y cancelar el trade actual?')) {
        cancelTrade();
        closeTradesModal();
      }
    } else {
      closeTradesModal();
    }
  });
  
  tradesModal?.addEventListener('click', (e) => {
    if (e.target === tradesModal) {
      if (currentTradeId && activeTradeView.style.display !== 'none' && currentTradeData?.status !== 'completed') {
        // Evitar cancelar o cerrar accidentalmente el trade al hacer click en el fondo durante la negociación
        return;
      }
      closeTradesModal();
    }
  });
  
  // Opciones de trade
  document.getElementById('friend-trade-option')?.querySelector('.trade-option-btn')?.addEventListener('click', showFriendSelectionView);
  document.getElementById('random-trade-option')?.querySelector('.trade-option-btn')?.addEventListener('click', startRandomTrade);
  
  // Tabs de amigos
  document.querySelectorAll('.friend-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      if (tab.dataset.tab === 'friends') {
        showFriendsTab();
      } else if (tab.dataset.tab === 'requests') {
        showRequestsTab();
      }
    });
  });
  
  // Botones de navegación
  document.getElementById('back-to-trade-selection')?.addEventListener('click', showTradeSelectionView);
  document.getElementById('back-from-random')?.addEventListener('click', () => {
    if (randomMatchCheckInterval) clearInterval(randomMatchCheckInterval);
    showTradeSelectionView();
  });
  
  // Item selector
  document.getElementById('close-item-selector')?.addEventListener('click', closeItemSelector);
  itemSelectorModal?.addEventListener('click', (e) => {
    if (e.target === itemSelectorModal) {
      closeItemSelector();
    }
  });
  document.querySelectorAll('.item-selector-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.item-selector-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      loadItemSelectorContent(tab.dataset.type);
    });
  });
  
  // Botones de trade activo
  document.getElementById('confirm-trade-btn')?.addEventListener('click', confirmTrade);
  document.getElementById('cancel-trade-btn')?.addEventListener('click', cancelTrade);
  
  // Exponer función globalmente para enviar solicitud de trade
  window.sendTradeRequestToFriend = sendTradeRequest;

  // Cancelar trade automáticamente si el jugador cierra la ventana o el juego
  window.addEventListener('beforeunload', () => {
    if (currentTradeId && currentTradeData?.status !== 'completed') {
      try {
        kvrcards.tradesCancelTrade(currentTradeId);
      } catch {}
    }
  });

  // User Profile Modal event listeners
  closeUserProfileBtn?.addEventListener('click', closeUserProfile);
  
  // Cerrar modal de perfil al hacer click fuera
  userProfileModal?.addEventListener('click', (e) => {
    if (e.target === userProfileModal) {
      closeUserProfile();
    }
  });

  // HUD interacciones
  hudToggle?.addEventListener('click', (e) => {
    e.stopPropagation(); // Evitar que el clic cierre el panel inmediatamente
    const show = !hudPanel.classList.contains('show');
    if (show) hudPanel.classList.add('show'); else hudPanel.classList.remove('show');
  });
  document.addEventListener('click', (e) => {
    if (!hudPanel || !hudToggle) return;
    if (!hudPanel.contains(e.target) && !hudToggle.contains(e.target)) {
      hudPanel.classList.remove('show');
    }
  });
  
  // Botón de ajustes
  settingsToggle?.addEventListener('click', () => {
    settingsModal?.classList.add('show');
    if (typeof loadRedeemedCodes === 'function') loadRedeemedCodes();
    if (typeof syncDisplaySettingsUI === 'function') syncDisplaySettingsUI();
  });
  
  // Cerrar modal de ajustes
  settingsClose?.addEventListener('click', () => {
    settingsModal?.classList.remove('show');
  });
  settingsModal?.addEventListener('click', (e) => {
    if (e.target === settingsModal) settingsModal.classList.remove('show');
  });
  
  // Pestañas de ajustes
  settingsTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const targetTab = tab.getAttribute('data-tab');
      
      // Remover active de todas las pestañas y paneles
      settingsTabs.forEach(t => t.classList.remove('active'));
      settingsPanels.forEach(p => p.classList.remove('active'));
      
      // Activar la pestaña clickeada y su panel
      tab.classList.add('active');
      document.getElementById(`settings-${targetTab}`)?.classList.add('active');
      
      // Si se abre la pestaña de códigos, cargar códigos canjeados
      if (targetTab === 'codigos') {
        loadRedeemedCodes();
      }
    });
  });
  
  // Códigos canjeables
  redeemCodeBtn?.addEventListener('click', handleRedeemCode);
  codeInput?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleRedeemCode();
  });
  
  // Guardar en la nube (Sistema)
  const saveToCloudBtn = document.getElementById('save-to-cloud-btn');
  saveToCloudBtn?.addEventListener('click', handleSaveToCloud);
  
  // Cargar desde la nube (Sistema)
  const loadFromCloudBtn = document.getElementById('load-from-cloud-btn');
  loadFromCloudBtn?.addEventListener('click', handleLoadFromCloud);
  
  // Funciones para actualizar opciones dinámicamente según vista
  function updateSortOptions() {
    if (!sortOptions) return;
    
    const sortNames = collectionViewType === 'cards' ? sortModeNames : powerSortModeNames;
    const sortKeys = Object.keys(sortNames);
    
    sortOptions.innerHTML = '';
    sortKeys.forEach(key => {
      const div = document.createElement('div');
      div.className = 'sort-option';
      div.setAttribute('data-sort', key);
      div.textContent = sortNames[key];
      if (key === currentSortMode) div.classList.add('active');
      
      div.addEventListener('click', () => {
        if (key !== currentSortMode) {
          currentSortMode = key;
          sortButton.textContent = `Ordenar por: ${sortNames[key]} ▼`;
          
          document.querySelectorAll('.sort-option').forEach(opt => opt.classList.remove('active'));
          div.classList.add('active');
          
          sortOptions.classList.remove('show');
          renderCollection();
        }
      });
      
      sortOptions.appendChild(div);
    });
  }
  
  function updateFilter2Options() {
    if (!filterOptions2) return;
    refreshFilterQualities();
    
    // Limpiar opciones existentes
    filterOptions2.innerHTML = '';
    
    // Opción "ninguno"
    const noneOption = document.createElement('div');
    noneOption.className = 'filter-option';
    noneOption.setAttribute('data-filter', 'none');
    noneOption.textContent = '----';
    noneOption.addEventListener('click', () => {
      currentFilterType2 = 'none';
      currentFilterValue2 = null;
      updateFilterButton2Text();
      filterOptions2.classList.remove('show');
      renderCollection();
    });
    filterOptions2.appendChild(noneOption);
    
    if (collectionViewType === 'cards') {
      // Filtro de calidad (Cartas)
      const qualityOption = document.createElement('div');
      qualityOption.className = 'filter-option submenu-trigger';
      qualityOption.setAttribute('data-filter', 'quality');
      qualityOption.innerHTML = 'Calidad ▶';
      
      const qualitySubmenu = document.createElement('div');
      qualitySubmenu.className = 'submenu quality-submenu';
      dynamicFilterQualities.forEach(q => {
        const option = document.createElement('div');
        option.className = 'submenu-option';
        option.setAttribute('data-quality', q);
        option.textContent = q === 'Heroe' ? 'Héroe' : q;
        option.addEventListener('click', (e) => {
          e.stopPropagation();
          currentFilterType2 = 'quality';
          currentFilterValue2 = q;
          updateFilterButton2Text();
          filterOptions2.classList.remove('show');
          renderCollection();
        });
        qualitySubmenu.appendChild(option);
      });
      
      qualityOption.appendChild(qualitySubmenu);
      filterOptions2.appendChild(qualityOption);
      
      // Filtro de media (Cartas)
      const mediaOption = document.createElement('div');
      mediaOption.className = 'filter-option submenu-trigger';
      mediaOption.setAttribute('data-filter', 'media');
      mediaOption.innerHTML = 'Media ▶';
      
      const mediaSubmenu = document.createElement('div');
      mediaSubmenu.className = 'submenu media-submenu';
      
      const mediaInputDiv = document.createElement('div');
      mediaInputDiv.className = 'submenu-input';
      
      const input = document.createElement('input');
      input.type = 'number';
      input.id = 'media-input-2-dynamic';
      input.placeholder = 'Ej: 85';
      input.min = '0';
      input.max = '100';
      
      const applyBtn = document.createElement('button');
      applyBtn.textContent = 'Aplicar';
      applyBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const mediaValue = parseInt(input.value);
        if (isNaN(mediaValue) || mediaValue < 0) {
          alert('Por favor, introduce un número válido para la media');
          return;
        }
        currentFilterType2 = 'media';
        currentFilterValue2 = mediaValue;
        updateFilterButton2Text();
        filterOptions2.classList.remove('show');
        input.value = '';
        renderCollection();
      });
      
      mediaInputDiv.appendChild(input);
      mediaInputDiv.appendChild(applyBtn);
      mediaSubmenu.appendChild(mediaInputDiv);
      mediaOption.appendChild(mediaSubmenu);
      filterOptions2.appendChild(mediaOption);

      // Filtro de procedencia (Cartas)
      const procedenciaOption = document.createElement('div');
      procedenciaOption.className = 'filter-option submenu-trigger';
      procedenciaOption.setAttribute('data-filter', 'procedencia');
      procedenciaOption.innerHTML = 'Procedencia ▶';

      const procedenciaSubmenu = document.createElement('div');
      procedenciaSubmenu.className = 'submenu quality-submenu';
      if (availableProcedencias.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'submenu-option';
        empty.textContent = 'Sin procedencias';
        procedenciaSubmenu.appendChild(empty);
      } else {
        availableProcedencias.forEach(item => {
          const option = document.createElement('div');
          option.className = 'submenu-option';
          option.textContent = item;
          option.addEventListener('click', (e) => {
            e.stopPropagation();
            currentFilterType2 = 'procedencia';
            currentFilterValue2 = item;
            updateFilterButton2Text();
            filterOptions2.classList.remove('show');
            renderCollection();
          });
          procedenciaSubmenu.appendChild(option);
        });
      }
      procedenciaOption.appendChild(procedenciaSubmenu);
      filterOptions2.appendChild(procedenciaOption);

      // Filtro de owner (Cartas)
      const ownerOption = document.createElement('div');
      ownerOption.className = 'filter-option submenu-trigger';
      ownerOption.setAttribute('data-filter', 'owner');
      ownerOption.innerHTML = 'Owner ▶';

      const ownerSubmenu = document.createElement('div');
      ownerSubmenu.className = 'submenu quality-submenu';
      if (availableOwners.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'submenu-option';
        empty.textContent = 'Sin owners';
        ownerSubmenu.appendChild(empty);
      } else {
        availableOwners.forEach(item => {
          const option = document.createElement('div');
          option.className = 'submenu-option';
          option.textContent = item;
          option.addEventListener('click', (e) => {
            e.stopPropagation();
            currentFilterType2 = 'owner';
            currentFilterValue2 = item;
            updateFilterButton2Text();
            filterOptions2.classList.remove('show');
            renderCollection();
          });
          ownerSubmenu.appendChild(option);
        });
      }
      ownerOption.appendChild(ownerSubmenu);
      filterOptions2.appendChild(ownerOption);
      
    } else {
      // Filtro de calidad (Poderes) - common, rare, epic, legendary
      const qualityOption = document.createElement('div');
      qualityOption.className = 'filter-option submenu-trigger';
      qualityOption.setAttribute('data-filter', 'quality');
      qualityOption.innerHTML = 'Calidad ▶';
      
      const qualitySubmenu = document.createElement('div');
      qualitySubmenu.className = 'submenu quality-submenu';
      const rarities = [
        { key: 'common', label: 'Común' },
        { key: 'rare', label: 'Raro' },
        { key: 'epic', label: 'Épico' },
        { key: 'legendary', label: 'Legendario' }
      ];
      
      rarities.forEach(r => {
        const option = document.createElement('div');
        option.className = 'submenu-option';
        option.setAttribute('data-quality', r.key);
        option.textContent = r.label;
        option.addEventListener('click', (e) => {
          e.stopPropagation();
          currentFilterType2 = 'quality';
          currentFilterValue2 = r.key;
          updateFilterButton2Text();
          filterOptions2.classList.remove('show');
          renderCollection();
        });
        qualitySubmenu.appendChild(option);
      });
      
      qualityOption.appendChild(qualitySubmenu);
      filterOptions2.appendChild(qualityOption);
      
      // Filtro de usos (Poderes)
      const usesOption = document.createElement('div');
      usesOption.className = 'filter-option submenu-trigger';
      usesOption.setAttribute('data-filter', 'uses');
      usesOption.innerHTML = 'Usos ▶';
      
      const usesSubmenu = document.createElement('div');
      usesSubmenu.className = 'submenu media-submenu';
      
      // Opción "Permanente"
      const permanentDiv = document.createElement('div');
      permanentDiv.className = 'submenu-option';
      permanentDiv.textContent = 'Permanente';
      permanentDiv.addEventListener('click', (e) => {
        e.stopPropagation();
        currentFilterType2 = 'uses';
        currentFilterValue2 = 'permanent';
        updateFilterButton2Text();
        filterOptions2.classList.remove('show');
        renderCollection();
      });
      usesSubmenu.appendChild(permanentDiv);
      
      // Input para número de usos
      const usesInputDiv = document.createElement('div');
      usesInputDiv.className = 'submenu-input';
      
      const input = document.createElement('input');
      input.type = 'number';
      input.id = 'uses-input-2-dynamic';
      input.placeholder = 'Usos mínimos';
      input.min = '0';
      
      const applyBtn = document.createElement('button');
      applyBtn.textContent = 'Aplicar';
      applyBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const usesValue = parseInt(input.value);
        if (isNaN(usesValue) || usesValue < 0) {
          alert('Por favor, introduce un número válido de usos');
          return;
        }
        currentFilterType2 = 'uses';
        currentFilterValue2 = usesValue;
        updateFilterButton2Text();
        filterOptions2.classList.remove('show');
        input.value = '';
        renderCollection();
      });
      
      usesInputDiv.appendChild(input);
      usesInputDiv.appendChild(applyBtn);
      usesSubmenu.appendChild(usesInputDiv);
      usesOption.appendChild(usesSubmenu);
      filterOptions2.appendChild(usesOption);
    }
  }
  
  function updateFilterOptions() {
    if (!filterOptions) return;
    refreshFilterQualities();
    
    // Limpiar opciones existentes
    filterOptions.innerHTML = '';
    
    // Opción "ninguno"
    const noneOption = document.createElement('div');
    noneOption.className = 'filter-option';
    noneOption.setAttribute('data-filter', 'none');
    noneOption.textContent = '----';
    noneOption.addEventListener('click', () => {
      currentFilterType = 'none';
      currentFilterValue = null;
      updateFilterButtonText();
      filterOptions.classList.remove('show');
      renderCollection();
    });
    filterOptions.appendChild(noneOption);
    
    if (collectionViewType === 'cards') {
      // Filtro de calidad (Cartas)
      const qualityOption = document.createElement('div');
      qualityOption.className = 'filter-option submenu-trigger';
      qualityOption.setAttribute('data-filter', 'quality');
      qualityOption.innerHTML = 'Calidad ▶';
      
      const qualitySubmenu = document.createElement('div');
      qualitySubmenu.className = 'submenu quality-submenu';
      dynamicFilterQualities.forEach(q => {
        const option = document.createElement('div');
        option.className = 'submenu-option';
        option.setAttribute('data-quality', q);
        option.textContent = q === 'Heroe' ? 'Héroe' : q;
        option.addEventListener('click', (e) => {
          e.stopPropagation();
          currentFilterType = 'quality';
          currentFilterValue = q;
          updateFilterButtonText();
          filterOptions.classList.remove('show');
          renderCollection();
        });
        qualitySubmenu.appendChild(option);
      });
      
      qualityOption.appendChild(qualitySubmenu);
      filterOptions.appendChild(qualityOption);
      
      // Filtro de media (Cartas)
      const mediaOption = document.createElement('div');
      mediaOption.className = 'filter-option submenu-trigger';
      mediaOption.setAttribute('data-filter', 'media');
      mediaOption.innerHTML = 'Media ▶';
      
      const mediaSubmenu = document.createElement('div');
      mediaSubmenu.className = 'submenu media-submenu';
      
      const mediaInputDiv = document.createElement('div');
      mediaInputDiv.className = 'submenu-input';
      
      const input = document.createElement('input');
      input.type = 'number';
      input.id = 'media-input-dynamic';
      input.placeholder = 'Ej: 85';
      input.min = '0';
      input.max = '100';
      
      const applyBtn = document.createElement('button');
      applyBtn.textContent = 'Aplicar';
      applyBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const mediaValue = parseInt(input.value);
        if (isNaN(mediaValue) || mediaValue < 0) {
          alert('Por favor, introduce un número válido para la media');
          return;
        }
        currentFilterType = 'media';
        currentFilterValue = mediaValue;
        updateFilterButtonText();
        filterOptions.classList.remove('show');
        input.value = '';
        renderCollection();
      });
      
      mediaInputDiv.appendChild(input);
      mediaInputDiv.appendChild(applyBtn);
      mediaSubmenu.appendChild(mediaInputDiv);
      mediaOption.appendChild(mediaSubmenu);
      filterOptions.appendChild(mediaOption);

      // Filtro de procedencia (Cartas)
      const procedenciaOption = document.createElement('div');
      procedenciaOption.className = 'filter-option submenu-trigger';
      procedenciaOption.setAttribute('data-filter', 'procedencia');
      procedenciaOption.innerHTML = 'Procedencia ▶';

      const procedenciaSubmenu = document.createElement('div');
      procedenciaSubmenu.className = 'submenu quality-submenu';
      if (availableProcedencias.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'submenu-option';
        empty.textContent = 'Sin procedencias';
        procedenciaSubmenu.appendChild(empty);
      } else {
        availableProcedencias.forEach(item => {
          const option = document.createElement('div');
          option.className = 'submenu-option';
          option.textContent = item;
          option.addEventListener('click', (e) => {
            e.stopPropagation();
            currentFilterType = 'procedencia';
            currentFilterValue = item;
            updateFilterButtonText();
            filterOptions.classList.remove('show');
            renderCollection();
          });
          procedenciaSubmenu.appendChild(option);
        });
      }
      procedenciaOption.appendChild(procedenciaSubmenu);
      filterOptions.appendChild(procedenciaOption);

      // Filtro de owner (Cartas)
      const ownerOption = document.createElement('div');
      ownerOption.className = 'filter-option submenu-trigger';
      ownerOption.setAttribute('data-filter', 'owner');
      ownerOption.innerHTML = 'Owner ▶';

      const ownerSubmenu = document.createElement('div');
      ownerSubmenu.className = 'submenu quality-submenu';
      if (availableOwners.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'submenu-option';
        empty.textContent = 'Sin owners';
        ownerSubmenu.appendChild(empty);
      } else {
        availableOwners.forEach(item => {
          const option = document.createElement('div');
          option.className = 'submenu-option';
          option.textContent = item;
          option.addEventListener('click', (e) => {
            e.stopPropagation();
            currentFilterType = 'owner';
            currentFilterValue = item;
            updateFilterButtonText();
            filterOptions.classList.remove('show');
            renderCollection();
          });
          ownerSubmenu.appendChild(option);
        });
      }
      ownerOption.appendChild(ownerSubmenu);
      filterOptions.appendChild(ownerOption);
      
    } else {
      // Filtro de calidad (Poderes) - common, rare, epic, legendary
      const qualityOption = document.createElement('div');
      qualityOption.className = 'filter-option submenu-trigger';
      qualityOption.setAttribute('data-filter', 'quality');
      qualityOption.innerHTML = 'Calidad ▶';
      
      const qualitySubmenu = document.createElement('div');
      qualitySubmenu.className = 'submenu quality-submenu';
      const rarities = [
        { key: 'common', label: 'Común' },
        { key: 'rare', label: 'Raro' },
        { key: 'epic', label: 'Épico' },
        { key: 'legendary', label: 'Legendario' }
      ];
      
      rarities.forEach(r => {
        const option = document.createElement('div');
        option.className = 'submenu-option';
        option.setAttribute('data-quality', r.key);
        option.textContent = r.label;
        option.addEventListener('click', (e) => {
          e.stopPropagation();
          currentFilterType = 'quality';
          currentFilterValue = r.key;
          updateFilterButtonText();
          filterOptions.classList.remove('show');
          renderCollection();
        });
        qualitySubmenu.appendChild(option);
      });
      
      qualityOption.appendChild(qualitySubmenu);
      filterOptions.appendChild(qualityOption);
      
      // Filtro de usos (Poderes)
      const usesOption = document.createElement('div');
      usesOption.className = 'filter-option submenu-trigger';
      usesOption.setAttribute('data-filter', 'uses');
      usesOption.innerHTML = 'Usos ▶';
      
      const usesSubmenu = document.createElement('div');
      usesSubmenu.className = 'submenu media-submenu';
      
      // Opción "Permanente"
      const permanentDiv = document.createElement('div');
      permanentDiv.className = 'submenu-option';
      permanentDiv.textContent = 'Permanente';
      permanentDiv.addEventListener('click', (e) => {
        e.stopPropagation();
        currentFilterType = 'uses';
        currentFilterValue = 'permanent';
        updateFilterButtonText();
        filterOptions.classList.remove('show');
        renderCollection();
      });
      usesSubmenu.appendChild(permanentDiv);
      
      // Input para número de usos
      const usesInputDiv = document.createElement('div');
      usesInputDiv.className = 'submenu-input';
      
      const input = document.createElement('input');
      input.type = 'number';
      input.id = 'uses-input-dynamic';
      input.placeholder = 'Usos mínimos';
      input.min = '0';
      
      const applyBtn = document.createElement('button');
      applyBtn.textContent = 'Aplicar';
      applyBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const usesValue = parseInt(input.value);
        if (isNaN(usesValue) || usesValue < 0) {
          alert('Por favor, introduce un número válido de usos');
          return;
        }
        currentFilterType = 'uses';
        currentFilterValue = usesValue;
        updateFilterButtonText();
        filterOptions.classList.remove('show');
        input.value = '';
        renderCollection();
      });
      
      usesInputDiv.appendChild(input);
      usesInputDiv.appendChild(applyBtn);
      usesSubmenu.appendChild(usesInputDiv);
      usesOption.appendChild(usesSubmenu);
      filterOptions.appendChild(usesOption);
    }
  }
  
async function handleResetUserAccount() {
  const confirm1 = confirm(
    "⚠️ ¿ESTÁS SEGURO DE QUE DESEAS REINICIAR TU CUENTA?\n\n" +
    "Esta acción restablecerá TODO tu progreso:\n" +
    "• Todas tus cartas y duplicados\n" +
    "• Todos tus sobres\n" +
    "• Monedas (Coins, KvR, Rasgos, etc.)\n" +
    "• Misiones completadas y reclamadas\n" +
    "• Kizunas y entregables\n" +
    "• Evoluciones iniciadas o completadas\n" +
    "• Códigos canjeados y bendiciones\n" +
    "• Prestigio de cartas\n\n" +
    "Tu cuenta quedará limpia como si estuvieras recién registrado.\n\n" +
    "¿Deseas continuar?"
  );
  if (!confirm1) return;

  const confirm2 = confirm(
    "🚨 ÚLTIMA ADVERTENCIA:\n\n" +
    "Esta acción es DEFINITIVA y NO se puede deshacer.\n\n" +
    "¿Confirmas definitivamente que deseas reiniciar toda tu cuenta de fábrica?"
  );
  if (!confirm2) return;

  const resetBtn = document.getElementById('btn-reset-account');
  const originalHtml = resetBtn ? resetBtn.innerHTML : '';
  if (resetBtn) {
    resetBtn.disabled = true;
    resetBtn.innerHTML = '<span>⏳</span> Reiniciando...';
  }

  try {
    // 1. Llamar al backend de Electron para restablecer memoria y archivos en disco
    if (window.kvrcards && typeof window.kvrcards.resetUserAccount === 'function') {
      const res = await window.kvrcards.resetUserAccount();
      if (res && res.ok === false) {
        throw new Error(res.error || 'No se pudo completar el reinicio en el servidor local.');
      }
    }

    // 2. Limpiar variables globales en memoria
    if (typeof userMissions !== 'undefined' && userMissions) {
      for (const k of Object.keys(userMissions)) delete userMissions[k];
    }
    if (typeof userKizunas !== 'undefined' && userKizunas) {
      for (const k of Object.keys(userKizunas)) delete userKizunas[k];
    }
    if (typeof userEvolutions !== 'undefined' && userEvolutions) {
      for (const k of Object.keys(userEvolutions)) delete userEvolutions[k];
    }
    if (typeof completedEventsList !== 'undefined' && Array.isArray(completedEventsList)) {
      completedEventsList.length = 0;
    }
    if (typeof deliverableCompletionsMap !== 'undefined' && deliverableCompletionsMap) {
      for (const k of Object.keys(deliverableCompletionsMap)) delete deliverableCompletionsMap[k];
    }
    if (typeof deliverableDailyCompletionsMap !== 'undefined' && deliverableDailyCompletionsMap) {
      for (const k of Object.keys(deliverableDailyCompletionsMap)) delete deliverableDailyCompletionsMap[k];
    }
    if (typeof cardTraitsMap !== 'undefined' && cardTraitsMap) {
      for (const k of Object.keys(cardTraitsMap)) delete cardTraitsMap[k];
    }
    if (typeof cardUpgradesMap !== 'undefined' && cardUpgradesMap) {
      for (const k of Object.keys(cardUpgradesMap)) delete cardUpgradesMap[k];
    }
    if (typeof savePrestigeProgressStore === 'function') {
      try { savePrestigeProgressStore({}); } catch {}
    }

    // 3. Limpiar almacenamiento LocalStorage por usuario
    const rawUser = (typeof currentUser === 'string' && currentUser.trim())
      ? currentUser.trim()
      : (localStorage.getItem('kvrUsername') || '').trim();
    const safeUser = rawUser.toLowerCase();

    const keysToRemove = [
      'kvr_user_missions',
      'kvr_user_kizunas',
      'kvr_user_evolutions',
      'kvr_user_evolutions_v2',
      'kvrcards_prestige_progress_v1',
      'INFINITE_CURRENCY_COINS',
      'INFINITE_CURRENCY_CARDPOINTS',
      'kvr_wallet_traits',
      'kvr_user_profile',
      'DELIVERABLES_COMPLETED_KEY'
    ];
    if (safeUser) {
      keysToRemove.push(
        `kvr_user_missions_${safeUser}`,
        `kvr_user_kizunas_${safeUser}`,
        `kvr_user_evolutions_${safeUser}`,
        `infinite_saved_team_${safeUser}`,
        `kvrProfile_${safeUser}`,
        `kvrProfile_${rawUser}`
      );
    }
    keysToRemove.forEach(k => {
      try { localStorage.removeItem(k); } catch {}
    });

    // 4. Restablecer perfil
    if (typeof userProfile !== 'undefined' && userProfile) {
      userProfile.title = 'Novato';
      userProfile.currentTitle = 'Novato';
      userProfile.unlockedTitles = ['novato'];
      userProfile.currentBackground = 'default';
      userProfile.unlockedBackgrounds = ['default'];
      userProfile.showcaseCards = [null, null, null];
    }

    // 5. Refrescar todas las pantallas visualmente
    if (typeof renderWallet === 'function') {
      try { await renderWallet(); } catch (errW) { console.warn('renderWallet err:', errW); }
    }
    if (typeof renderCollection === 'function') {
      try { await renderCollection(); } catch (errC) { console.warn('renderCollection err:', errC); }
    }
    if (typeof renderOwnedPacks === 'function') {
      try { await renderOwnedPacks(); } catch (errP) { console.warn('renderOwnedPacks err:', errP); }
    }
    if (typeof renderShop === 'function') {
      try { await renderShop(); } catch (errS) { console.warn('renderShop err:', errS); }
    }
    if (typeof loadUserMissionsState === 'function') {
      try { await loadUserMissionsState(); } catch {}
    }
    if (typeof renderMissions === 'function') {
      try { await renderMissions(); } catch {}
    }
    if (typeof loadUserKizunasState === 'function') {
      try { await loadUserKizunasState(); } catch {}
    }
    if (typeof renderKizunas === 'function') {
      try { await renderKizunas(); } catch {}
    }
    if (typeof loadUserEvolutionsState === 'function') {
      try { await loadUserEvolutionsState(); } catch {}
    }
    if (typeof renderEvolutions === 'function') {
      try { await renderEvolutions(); } catch {}
    }
    if (typeof loadUserProfile === 'function') {
      try { loadUserProfile(); } catch {}
    }
    if (typeof updateProfileUI === 'function') {
      try { updateProfileUI(); } catch {}
    }
    if (typeof updateProfileDisplay === 'function') {
      try { updateProfileDisplay(); } catch {}
    }
    if (typeof updateProfileStats === 'function') {
      try { await updateProfileStats(); } catch {}
    }
    if (typeof renderEventsList === 'function') {
      try { renderEventsList(); } catch {}
    }

    alert("✅ ¡Cuenta reiniciada con éxito!\n\nTu inventario, monedas, sobres, misiones, evoluciones, kizunas y códigos han quedado a cero como en una cuenta nueva.");
  } catch (error) {
    console.error('[ACCOUNT RESET] Error al reiniciar cuenta:', error);
    alert("❌ Error al reiniciar la cuenta: " + (error?.message || error));
  } finally {
    if (resetBtn) {
      resetBtn.disabled = false;
      resetBtn.innerHTML = originalHtml || '<span class="btn-reset-icon">🔄</span> Reiniciar Cuenta';
    }
  }
}
window.handleResetUserAccount = handleResetUserAccount;

  // Event listener para botón de vista completa
  document.getElementById('toggle-complete-collection')?.addEventListener('click', () => {
    showCompleteCollection = !showCompleteCollection;
    const btn = document.getElementById('toggle-complete-collection');
    btn.textContent = showCompleteCollection ? 'Ver mi colección' : 'Ver colección completa';
    renderCollection();
  });

  // Toggle entre Cartas y Poderes
  document.getElementById('toggle-view-type')?.addEventListener('click', () => {
    collectionViewType = collectionViewType === 'cards' ? 'powers' : 'cards';
    const btn = document.getElementById('toggle-view-type');
    btn.textContent = collectionViewType === 'cards' ? 'Cartas' : 'Poderes';
    
    // Actualizar opciones de ordenación según vista
    updateSortOptions();
    
    // Actualizar opciones de filtrado según vista
    updateFilterOptions();
    updateFilter2Options();
    
    // Actualizar placeholder del buscador
    if (collectionSearchInput) {
      collectionSearchInput.placeholder = collectionViewType === 'cards' ? 'Buscar carta...' : 'Buscar poder...';
      collectionSearchInput.value = ''; // Limpiar búsqueda al cambiar
    }
    
    // Resetear filtros al cambiar de vista
    currentSortMode = collectionViewType === 'cards' ? 'media' : 'obtained';
    currentFilterType = 'none';
    currentFilterValue = null;
    currentFilterType2 = 'none';
    currentFilterValue2 = null;
    
    // Actualizar textos de botones
    const sortNames = collectionViewType === 'cards' ? sortModeNames : powerSortModeNames;
    sortButton.textContent = `Ordenar por: ${sortNames[currentSortMode]} ▼`;
    updateFilterButtonText();
    updateFilterButton2Text();
    
    renderCollection();
  });
  
  // Sistema de filtros - botón de ordenación
  sortButton?.addEventListener('click', () => {
    sortOptions.classList.toggle('show');
  });
  
  document.addEventListener('click', (e) => {
    if (!sortButton?.contains(e.target) && !sortOptions?.contains(e.target)) {
      sortOptions?.classList.remove('show');
    }
  });
  
  // Las opciones de ordenación se crean dinámicamente en updateSortOptions()
  
  // Sistema de filtros avanzados - botón de filtrado
  filterButton?.addEventListener('click', async () => {
    await syncRemoteFilterOptionsIntoState();
    if (typeof refreshCollectionFilterMenus === 'function') refreshCollectionFilterMenus();
    filterOptions.classList.toggle('show');
  });
  
  document.addEventListener('click', (e) => {
    if (!filterButton?.contains(e.target) && !filterOptions?.contains(e.target)) {
      filterOptions?.classList.remove('show');
    }
  });
  
  // Las opciones de filtrado se crean dinámicamente en updateFilterOptions()
  
  // Buscador de colección
  collectionSearchInput?.addEventListener('input', () => {
    renderCollection();
  });
  
  // Inicializar opciones dinámicas por defecto (para cartas)
  updateSortOptions();
  updateFilterOptions();
  updateFilter2Options();
  refreshCollectionFilterMenus = () => {
    updateFilterOptions();
    updateFilter2Options();
  };
  syncRemoteFilterOptionsIntoState().then(() => {
    if (typeof refreshCollectionFilterMenus === 'function') refreshCollectionFilterMenus();
  }).catch(() => {});
  
  // Sistema de filtros avanzados - Filtro 2
  filterButton2?.addEventListener('click', async () => {
    await syncRemoteFilterOptionsIntoState();
    if (typeof refreshCollectionFilterMenus === 'function') refreshCollectionFilterMenus();
    if (!filterButton2.disabled) {
      filterOptions2.classList.toggle('show');
    }
  });
  
  document.addEventListener('click', (e) => {
    if (!filterButton2?.contains(e.target) && !filterOptions2?.contains(e.target)) {
      filterOptions2?.classList.remove('show');
    }
  });
  
  // Filtro 2 por "ninguno"
  document.querySelectorAll('#filter-options-2 .filter-option[data-filter="none"]').forEach(option => {
    option.addEventListener('click', () => {
      currentFilterType2 = 'none';
      currentFilterValue2 = null;
      updateFilterButton2Text();
      filterOptions2.classList.remove('show');
      renderCollection();
    });
  });
  
  // Filtros 2 de calidad
  document.querySelectorAll('#filter-options-2 .submenu-option[data-quality]').forEach(option => {
    option.addEventListener('click', (e) => {
      e.stopPropagation();
      const quality = option.getAttribute('data-quality');
      currentFilterType2 = 'quality';
      currentFilterValue2 = quality;
      updateFilterButton2Text();
      filterOptions2.classList.remove('show');
      renderCollection();
    });
  });
  
  // Filtro 2 de media
  applyMediaFilter2?.addEventListener('click', (e) => {
    e.stopPropagation();
    const mediaValue = parseInt(mediaInput2.value);
    if (isNaN(mediaValue) || mediaValue < 0) {
      alert('Por favor, introduce un número válido para la media');
      return;
    }
    currentFilterType2 = 'media';
    currentFilterValue2 = mediaValue;
    updateFilterButton2Text();
    filterOptions2.classList.remove('show');
    mediaInput2.value = '';
    renderCollection();
  });
  
  // Lightbox
  lightboxClose?.addEventListener('click', closeLightbox);
  lightbox?.addEventListener('click', (e) => { if (e.target === lightbox) closeLightbox(); });
  
  // Lightbox venta
  lightboxSell?.addEventListener('click', showSellModal);
  
  // Modal de compra
  buyCoinsBtn?.addEventListener('click', () => confirmBuy('coins'));
  buyKvrBtn?.addEventListener('click', () => confirmBuy('kvr'));
  buyCancelBtn?.addEventListener('click', () => buyModal?.classList.remove('show'));
  
  // Modal de venta
  sellConfirm?.addEventListener('click', confirmSell);
  sellCancel?.addEventListener('click', hideSellModal);
  
  // Barra de búsqueda de colección
  collectionSearchInput?.addEventListener('input', (e) => {
    collectionSearchText = e.target.value;
    renderCollection();
  });
  
  // Modal de detalles del sobre
  packDetailsClose?.addEventListener('click', hidePackDetails);
  packDetailsModal?.addEventListener('click', (e) => {
    if (e.target === packDetailsModal) hidePackDetails();
  });
  
  // Botones de guardar/vender todas las cartas del sobre
  saveAllBtn?.addEventListener('click', handleSaveAll);
  sellAllBtn?.addEventListener('click', handleSellAllPrompt);
  sellAllConfirm?.addEventListener('click', handleSellAllConfirm);
  sellAllCancel?.addEventListener('click', () => sellAllModal?.classList.remove('show'));
  sellAllModal?.addEventListener('click', (e) => {
    if (e.target === sellAllModal) sellAllModal.classList.remove('show');
  });
}

// Función para actualizar el texto del botón de filtro
// Inicialización
console.log('[INIT] Iniciando aplicación...');
// NO mostrar colección al inicio, el menú principal lo hará
console.log('[INIT] Vista inicial configurada');

initializeEventListeners();
console.log('[INIT] Event listeners inicializados');

initializeCollectiblesTabs();
console.log('[INIT] Pestañas de coleccionables inicializadas');

initializeFilters();
console.log('[INIT] Filtros inicializados');

if (typeof initCardRegistry === 'function') {
  initCardRegistry();
}

if (isElectron) {
  console.log('[INIT] Modo Electron detectado');
  
  initializeSyncCommand();
  console.log('[INIT] Comando sync inicializado');
  
  refreshFilterQualities();
  renderCollection();
  console.log('[INIT] Colección renderizada');
  
  renderOwnedPacks();
  console.log('[INIT] Sobres renderizados');
  
  renderShop();
  console.log('[INIT] Tienda renderizada');
  
  renderWallet();
  console.log('[INIT] Wallet renderizado');
  
  // Las vistas ya están ocultas por CSS por defecto
  // El menú principal está visible por CSS por defecto
  
  // Verificar autenticación (nuevo sistema)
  console.log('[INIT] Verificando autenticación...');
  checkAuthentication().then(authenticated => {
    console.log('[INIT] ✓ Autenticación:', authenticated ? 'OK' : 'Requiere login');
  }).catch(e => {
    console.error('[INIT] ✗ Error en autenticación:', e);
  });
  
  loadSavedTheme().then(() => {
    console.log('[INIT] Tema cargado');
  }).catch(e => {
    console.error('[INIT] Error cargando tema:', e);
  });
  
  initializeThemeSystem();
  console.log('[INIT] Sistema de temas inicializado');
  
  // Inicializar música de forma asíncrona sin bloquear
  console.log('[INIT] Iniciando sistema de música...');
  initializeMusicSystem().then(() => {
    console.log('[INIT] ✓ Sistema de música inicializado');
  }).catch(e => {
    console.error('[INIT] ✗ Error inicializando música:', e);
  });
  
  // Inicializar SFX de botones
  initializeButtonSFX();
  console.log('[INIT] SFX de botones inicializado');
  
  // Inicializar timer de rankings semanales
  startResetTimer();
  console.log('[INIT] Timer de rankings inicializado');
  
  console.log('[INIT] ✅ Aplicación lista');
} else {
  console.log('[INIT] Modo navegador (no Electron)');
}

// ==================== INICIALIZACIÓN ====================
// Cargar misiones, kizunas, evoluciones y traits al iniciar la aplicación
Promise.allSettled([
  (async () => {
    if (typeof loadMissions === 'function') await loadMissions();
    if (typeof loadUserMissionsState === 'function') await loadUserMissionsState();
  })(),
  (async () => {
    if (typeof loadKizunas === 'function') await loadKizunas();
    if (typeof loadUserKizunasState === 'function') await loadUserKizunasState();
  })(),
  (async () => {
    if (typeof loadEvolutions === 'function') await loadEvolutions();
    if (typeof loadUserEvolutionsState === 'function') await loadUserEvolutionsState();
  })(),
  (async () => {
    if (typeof window.ensureTraitsLoaded === 'function') await window.ensureTraitsLoaded();
  })()
]).then(() => {
  if (typeof updateGlobalNotificationBadges === 'function') updateGlobalNotificationBadges();
}).catch(() => {});

// Iniciar verificación periódica de notificaciones globales (badges de sobres, trades, amigos, batalla)
if (typeof startPendingTradesCheck === 'function') {
  startPendingTradesCheck();
} else if (typeof window !== 'undefined' && typeof window.startPendingTradesCheck === 'function') {
  window.startPendingTradesCheck();
}

