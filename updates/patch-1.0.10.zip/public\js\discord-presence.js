/**
 * public/js/discord-presence.js
 * 
 * Gestor unificado de Discord Rich Presence para KVRCards en el frontend.
 * Conecta los diferentes estados y modos del juego con Electron.
 */

(function() {
  'use strict';

  let currentActivity = {
    details: 'En los menus',
    state: 'Navegando por el juego',
    startTimestamp: Date.now()
  };

  function formatDifficulty(diff) {
    if (!diff) return 'Normal';
    const d = String(diff).toLowerCase().trim();
    const map = {
      'principiante': 'Principiante',
      'amateur': 'Amateur',
      'experimentado': 'Experimentado',
      'profesional': 'Profesional',
      'dios-antiguo': 'Dios Antiguo',
      'dios antiguo': 'Dios Antiguo',
      'inmo': 'INMO',
      'facil': 'Facil',
      'medio': 'Medio',
      'dificil': 'Dificil',
      'pesadilla': 'Pesadilla'
    };
    if (map[d]) return map[d];
    return d.charAt(0).toUpperCase() + d.slice(1);
  }

  function getOnlineUsername() {
    try {
      if (window.onlineState && window.onlineState.username) {
        return window.onlineState.username;
      }
      if (typeof getPlayerProfile === 'function') {
        const prof = getPlayerProfile();
        if (prof && prof.username) return prof.username;
      }
      const profUser = localStorage.getItem('kvr_user_profile');
      if (profUser) {
        const parsed = JSON.parse(profUser);
        if (parsed.username) return parsed.username;
      }
    } catch {}
    return 'Jugador';
  }

  function sendPresence(details, state, options = {}) {
    const isNewMajorMode = options.resetTimer || currentActivity.details !== details;
    const startTs = isNewMajorMode ? Date.now() : (currentActivity.startTimestamp || Date.now());

    currentActivity = {
      details: details || 'En los menus',
      state: state || 'Navegando por el juego',
      startTimestamp: startTs
    };

    if (window.kvrcards && typeof window.kvrcards.updateDiscordPresence === 'function') {
      try {
        window.kvrcards.updateDiscordPresence({
          details: currentActivity.details,
          state: currentActivity.state,
          startTimestamp: currentActivity.startTimestamp,
          largeImageKey: options.largeImageKey || 'kvrcards_logo',
          largeImageText: options.largeImageText || 'KVRCards',
          buttons: options.buttons || undefined
        });
      } catch (err) {
        console.warn('[DISCORD-PRESENCE] Error enviando presencia:', err);
      }
    }
  }

  // --- MÉTODOS PÚBLICOS DE PRESENCIA ---

  function setDiscordMenu() {
    sendPresence('En los menus', 'Navegando por el juego');
  }

  function setDiscordPacks(_packName) {
    sendPresence('Abriendo Sobres', 'En el apartado de mis sobres');
  }

  function setDiscordGambling(gameName) {
    const stateText = gameName ? String(gameName) : 'Seleccion de Juego';
    sendPresence('Gambleando', stateText);
  }

  function setDiscordInfinite(floor, trainerName) {
    const safeFloor = floor || (window.__infiniteBattleContext && window.__infiniteBattleContext.floor) || 1;
    let stateText = '';
    if (trainerName) {
      stateText = `Piso ${safeFloor} - vs ${trainerName}`;
    } else if (window.__infiniteBattleContext && window.__infiniteBattleContext.trainerName) {
      stateText = `Piso ${safeFloor} - vs ${window.__infiniteBattleContext.trainerName}`;
    } else {
      stateText = `Piso ${safeFloor}`;
    }
    sendPresence('Modo Infinito', stateText);
  }

  function setDiscordOfflineBattle(options = {}) {
    const isEvent = options.isEvent || window.isEventBattle;
    const rawMode = options.gameMode || window.selectedGameMode || 'clasico7v7';
    const trainer = options.trainer || (window.currentEventBattle && window.currentEventBattle.name) || (typeof getOpponentName === 'function' ? getOpponentName(window.selectedDifficulty) : 'Entrenador');
    const diff = formatDifficulty(options.difficulty || window.selectedDifficulty);

    let details = 'Batalla Offline (7v7 Clasico)';
    let state = `vs ${trainer} (${diff})`;

    if (isEvent) {
      details = 'Modo Evento';
      state = `vs ${trainer}`;
    } else if (rawMode === 'alternativo7v7' || rawMode === '7v7alternativo') {
      details = 'Batalla Offline (7v7 Alternativo)';
      state = `vs ${trainer} (${diff})`;
    } else {
      details = 'Batalla Offline (7v7 Clasico)';
      state = `vs ${trainer} (${diff})`;
    }

    sendPresence(details, state, { resetTimer: true });
  }

  function setDiscordOnlineBattle(options = {}) {
    const rawMode = options.gameMode || window.selectedGameMode || (window.onlineState && window.onlineState.opponentData && window.onlineState.opponentData.gameMode) || 'clasico7v7';
    const player1 = options.player1 || getOnlineUsername();
    const player2 = options.player2 || (window.onlineState && window.onlineState.opponentData && window.onlineState.opponentData.username) || (window.battleState && window.battleState.opponentName) || 'Rival';

    let details = 'Batalla Online (7v7 Clasico)';
    if (rawMode === 'eleccion_clasico' || rawMode === 'draft_clasico') {
      details = 'Batalla Online (Draft Clasico)';
    } else if (rawMode === 'eleccion_alternativo' || rawMode === 'draft_alternativo') {
      details = 'Batalla Online (Draft Alternativo)';
    } else if (rawMode === 'alternativo7v7' || rawMode === '7v7alternativo') {
      details = 'Batalla Online (7v7 Alternativo)';
    } else {
      details = 'Batalla Online (7v7 Clasico)';
    }

    const state = `${player1} vs ${player2}`;
    sendPresence(details, state, { resetTimer: true });
  }

  // Exportar al objeto global window
  window.DiscordPresence = {
    sendPresence,
    setMenu: setDiscordMenu,
    setPacks: setDiscordPacks,
    setGambling: setDiscordGambling,
    setInfinite: setDiscordInfinite,
    setOfflineBattle: setDiscordOfflineBattle,
    setOnlineBattle: setDiscordOnlineBattle
  };

  // Inicializar en los menús al cargar
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(setDiscordMenu, 1000);
    });
  } else {
    setTimeout(setDiscordMenu, 1000);
  }

  console.log('[DISCORD-PRESENCE] Módulo frontend cargado correctamente.');
})();
