// ==================== FRIENDS SYSTEM ====================

let currentFriendsTab = 'my-friends';

// Open friends modal
function openFriendsModal() {
  console.log('[FRIENDS] Abriendo modal de amigos');
  const friendsModal = document.getElementById('friends-modal');
  if (!friendsModal) {
    console.error('[FRIENDS] Modal no encontrado');
    return;
  }
  
  // Limpiar todas las listas para evitar mostrar datos de otra cuenta
  const friendsList = document.getElementById('friends-list');
  const requestsList = document.getElementById('requests-list');
  const searchResults = document.getElementById('search-results-list');
  
  if (friendsList) friendsList.innerHTML = '';
  if (requestsList) requestsList.innerHTML = '';
  if (searchResults) searchResults.innerHTML = '';
  
  friendsModal.classList.add('active');
  // Siempre recargar datos al abrir para reflejar cambios de cuenta
  currentFriendsTab = ''; // Reset para forzar recarga
  switchFriendsTab('my-friends');
}

// Close friends modal
function closeFriendsModal() {
  const friendsModal = document.getElementById('friends-modal');
  if (friendsModal) {
    friendsModal.classList.remove('active');
  }
}

// Switch between friend tabs
function switchFriendsTab(tab) {
  console.log('[FRIENDS] Cambiando a tab:', tab);
  currentFriendsTab = tab;
  
  // Update tab buttons
  document.querySelectorAll('.friends-tab').forEach(btn => {
    if (btn.dataset.tab === tab) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });
  
  // Update tab content
  document.querySelectorAll('.friends-tab-content').forEach(content => {
    content.classList.remove('active');
  });
  
  const tabContent = document.getElementById(`${tab}-tab`);
  if (tabContent) {
    tabContent.classList.add('active');
  } else {
    console.error('[FRIENDS] Tab content no encontrado:', `${tab}-tab`);
  }
  
  // Load data for the active tab
  console.log('[FRIENDS] Cargando datos para tab:', tab);
  if (tab === 'my-friends') {
    loadFriendsList();
  } else if (tab === 'add-friends') {
    // Auto-load all users
    searchUsers();
  } else if (tab === 'requests') {
    loadFriendRequests();
  }
}

// Load friends list
async function loadFriendsList() {
  console.log('[FRIENDS] loadFriendsList() llamada');
  
  const listEl = document.getElementById('friends-list');
  if (!listEl) {
    console.error('[FRIENDS] Elemento friends-list no encontrado en el DOM');
    return;
  }
  
  listEl.innerHTML = '<div class="friends-loading">Cargando amigos...</div>';
  
  try {
    const userId = localStorage.getItem('userId');
    
    console.log('[FRIENDS] Cargando amigos para userId:', userId);
    
    if (!userId) {
      listEl.innerHTML = '<div class="friends-empty">Inicia sesión para ver tus amigos</div>';
      return;
    }
    
    // Cargar desde servidor remoto
    const url = `https://kvrcards-server.onrender.com/api/friends/list/${userId}`;
    console.log('[FRIENDS] Llamando a:', url);
    
    const response = await fetch(url);
    console.log('[FRIENDS] Response status:', response.status);
    
    // Si es 404, el usuario no existe todavía - mostrar lista vacía
    if (response.status === 404) {
      console.log('[FRIENDS] Usuario no existe en servidor, mostrando lista vacía');
      listEl.innerHTML = '<div class="friends-empty">No tienes amigos añadidos todavía</div>';
      return;
    }
    
    const result = await response.json();
    console.log('[FRIENDS] Resultado:', result);
    
    if (!result.ok || !result.friends || result.friends.length === 0) {
      listEl.innerHTML = '<div class="friends-empty">No tienes amigos añadidos todavía</div>';
      return;
    }
    
    listEl.innerHTML = '';
    result.friends.forEach(friend => {
      const card = createFriendCard(friend, 'friend');
      listEl.appendChild(card);
    });
    
    console.log('[FRIENDS] Amigos cargados:', result.friends.length);
  } catch (e) {
    console.error('[FRIENDS] Error loading friends:', e);
    listEl.innerHTML = '<div class="friends-empty">Error al cargar amigos</div>';
  }
}

// Load friend requests
async function loadFriendRequests() {
  const listEl = document.getElementById('requests-list');
  listEl.innerHTML = '<div class="friends-loading">Cargando solicitudes...</div>';
  
  try {
    const userId = localStorage.getItem('userId');
    if (!userId) {
      listEl.innerHTML = '<div class="friends-empty">Inicia sesión para ver solicitudes</div>';
      return;
    }
    
    const response = await fetch(`https://kvrcards-server.onrender.com/api/friends/requests/${userId}`);
    
    // Si es 404, el usuario no existe todavía
    if (response.status === 404) {
      listEl.innerHTML = '<div class="friends-empty">No tienes solicitudes pendientes</div>';
      return;
    }
    
    const result = await response.json();
    
    if (!result.ok || !result.requests || result.requests.length === 0) {
      listEl.innerHTML = '<div class="friends-empty">No tienes solicitudes pendientes</div>';
      return;
    }
    
    listEl.innerHTML = '';
    result.requests.forEach(request => {
      const card = createFriendCard(request, 'request');
      listEl.appendChild(card);
    });
  } catch (e) {
    console.error('[FRIENDS] Error loading requests:', e);
    listEl.innerHTML = '<div class="friends-empty">Error al cargar solicitudes</div>';
  } finally {
    if (typeof updateGlobalNotificationBadges === 'function') {
      updateGlobalNotificationBadges();
    }
  }
}

// Search users
async function searchUsers() {
  const query = document.getElementById('friends-search-input').value.trim();
  const listEl = document.getElementById('search-results-list');
  
  listEl.innerHTML = '<div class="friends-loading">Buscando usuarios...</div>';
  
  try {
    const userId = localStorage.getItem('userId');
    const response = await fetch(`https://kvrcards-server.onrender.com/api/friends/search?q=${encodeURIComponent(query)}&user=${encodeURIComponent(userId || '')}`);
    const result = await response.json();
    
    if (!result.ok || !result.users || result.users.length === 0) {
      listEl.innerHTML = '<div class="friends-empty">No se encontraron usuarios</div>';
      return;
    }
    
    listEl.innerHTML = '';
    result.users.forEach(user => {
      const card = createFriendCard(user, 'search');
      listEl.appendChild(card);
    });
  } catch (e) {
    console.error('[FRIENDS] Error searching users:', e);
    listEl.innerHTML = '<div class="friends-empty">Error al buscar usuarios</div>';
  }
}

// Create friend card
function createFriendCard(user, type) {
  const card = document.createElement('div');
  card.className = 'friend-card';
  
  // Info (Avatar eliminado de la lista para ahorrar ancho de banda; solo visible en "Ver Perfil")
  const info = document.createElement('div');
  info.className = 'friend-info';
  
  const username = document.createElement('div');
  username.className = 'friend-username';
  username.textContent = user.username;
  info.appendChild(username);
  
  if (user.currentTitle) {
    const title = document.createElement('div');
    title.className = 'friend-title';
    title.textContent = user.currentTitle;
    if (typeof window.applyTitleStyle === 'function') {
      window.applyTitleStyle(title, user.currentTitle);
    }
    info.appendChild(title);
  }
  
  if (user.stats) {
    const stats = document.createElement('div');
    stats.className = 'friend-stats';
    stats.innerHTML = `<img src="./icon-oro.png" style="width:14px;height:14px;vertical-align:middle;"> ${user.stats.totalCardsObtained || 0} | <img src="./sobre_oro.png" style="width:14px;height:14px;vertical-align:middle;object-fit:contain;"> ${user.stats.totalPacksOpened || 0} | <img src="./coin.png" style="width:14px;height:14px;vertical-align:middle;"> ${user.stats.totalCoinsEarned || 0}`;
    info.appendChild(stats);
  }
  
  // Actions
  const actions = document.createElement('div');
  actions.className = 'friend-actions';
  
  // View profile button (always available)
  const viewBtn = document.createElement('button');
  viewBtn.className = 'friend-btn friend-btn-view';
  viewBtn.textContent = '👤 Ver Perfil';
  viewBtn.onclick = () => openUserProfile(user.username);
  actions.appendChild(viewBtn);
  
  // Type-specific buttons
  if (type === 'friend') {
    const removeBtn = document.createElement('button');
    removeBtn.className = 'friend-btn friend-btn-remove';
    removeBtn.textContent = '❌ Eliminar';
    removeBtn.onclick = async () => {
      if (confirm(`¿Eliminar a ${user.username} de tus amigos?`)) {
        const userId = localStorage.getItem('userId');
        const response = await fetch('https://kvrcards-server.onrender.com/api/friends/remove', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: userId, friendUsername: user.username })
        });
        const result = await response.json();
        if (result.ok) {
          alert('Amigo eliminado');
          loadFriendsList();
        } else {
          alert('Error al eliminar amigo: ' + (result.error || 'Desconocido'));
        }
      }
    };
    actions.appendChild(removeBtn);
  } else if (type === 'request') {
    const acceptBtn = document.createElement('button');
    acceptBtn.className = 'friend-btn friend-btn-accept';
    acceptBtn.textContent = '✅ Aceptar';
    acceptBtn.onclick = async () => {
      const userId = localStorage.getItem('userId');
      const response = await fetch('https://kvrcards-server.onrender.com/api/friends/accept', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: userId, friendUsername: user.username })
      });
      const result = await response.json();
      
      if (result.ok) {
        alert('Solicitud aceptada');
        loadFriendRequests();
        loadFriendsList();
      } else {
        alert('Error al aceptar solicitud: ' + (result.error || 'Desconocido'));
      }
    };
    actions.appendChild(acceptBtn);
    
    const rejectBtn = document.createElement('button');
    rejectBtn.className = 'friend-btn friend-btn-reject';
    rejectBtn.textContent = '❌ Rechazar';
    rejectBtn.onclick = async () => {
      const userId = localStorage.getItem('userId');
      const response = await fetch('https://kvrcards-server.onrender.com/api/friends/reject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: userId, friendUsername: user.username })
      });
      const result = await response.json();
      if (result.ok) {
        alert('Solicitud rechazada');
        loadFriendRequests();
      } else {
        alert('Error al rechazar solicitud: ' + (result.error || 'Desconocido'));
      }
    };
    actions.appendChild(rejectBtn);
  } else if (type === 'search') {
    if (user.isFriend) {
      const friendBtn = document.createElement('button');
      friendBtn.className = 'friend-btn friend-btn-pending';
      friendBtn.textContent = '✅ Amigos';
      friendBtn.disabled = true;
      actions.appendChild(friendBtn);
    } else if (user.requestSent) {
      const pendingBtn = document.createElement('button');
      pendingBtn.className = 'friend-btn friend-btn-pending';
      pendingBtn.textContent = '⏳ Solicitud enviada';
      pendingBtn.disabled = true;
      actions.appendChild(pendingBtn);
    } else if (user.requestReceived) {
      const respondBtn = document.createElement('button');
      respondBtn.className = 'friend-btn friend-btn-view';
      respondBtn.textContent = '📬 Ver solicitud';
      respondBtn.onclick = () => switchFriendsTab('requests');
      actions.appendChild(respondBtn);
    } else {
      const addBtn = document.createElement('button');
      addBtn.className = 'friend-btn friend-btn-add';
      addBtn.textContent = '➕ Añadir';
      addBtn.onclick = async () => {
        const userId = localStorage.getItem('userId');
        const response = await fetch('https://kvrcards-server.onrender.com/api/friends/send', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: userId, friendUsername: user.username })
        });
        const result = await response.json();
        if (result.ok) {
          alert('Solicitud de amistad enviada');
          searchUsers(); // Refresh results
        } else {
          alert('Error al enviar solicitud: ' + (result.error || 'Desconocido'));
        }
      };
      actions.appendChild(addBtn);
    }
  } else if (type === 'trade-request') {
    // Botón para enviar solicitud de trade
    const tradeBtn = document.createElement('button');
    tradeBtn.className = 'friend-btn friend-btn-add';
    tradeBtn.textContent = '🔄 Enviar Solicitud';
    tradeBtn.onclick = () => {
      if (window.sendTradeRequestToFriend) {
        window.sendTradeRequestToFriend(user.username);
      }
    };
    actions.appendChild(tradeBtn);
  }
  
  card.appendChild(info);
  card.appendChild(actions);
  
  return card;
}

// ==================== END FRIENDS SYSTEM ====================
