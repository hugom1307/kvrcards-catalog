/**
 * electron/modules/discord-rpc.js
 * 
 * Implementación nativa y ligera de Discord Rich Presence para KVRCards.
 * Funciona mediante Named Pipes en Windows (y domain sockets en Linux/macOS)
 * sin requerir dependencias externas de npm pesadas ni compilación C++.
 */

const net = require('net');
const path = require('path');
const fs = require('fs');
const { ipcMain, app } = require('electron');

const OPCODES = {
  HANDSHAKE: 0,
  FRAME: 1,
  CLOSE: 2,
  PING: 3,
  PONG: 4
};

function logRpc(msg) {
  const line = `[${new Date().toISOString()}] [DISCORD-RPC] ${msg}\n`;
  console.log(`[DISCORD-RPC] ${msg}`);
  try {
    const targets = [
      path.join(process.cwd(), 'discord-rpc.log'),
      path.join(__dirname, '..', '..', 'discord-rpc.log')
    ];
    if (app && typeof app.getPath === 'function') {
      try { targets.push(path.join(app.getPath('userData'), 'discord-rpc.log')); } catch {}
    }
    for (const t of targets) {
      try { fs.appendFileSync(t, line); } catch {}
    }
  } catch {}
}

class DiscordRpcManager {
  constructor() {
    this.clientId = '1553143643710296206';
    this.socket = null;
    this.isConnected = false;
    this.isReady = false;
    this.reconnectTimer = null;
    this.lastActivity = null;
    this.buffer = Buffer.alloc(0);
    this.defaultLargeImageKey = 'kvrcards_logo';
    this.defaultLargeImageText = 'KVRCards';
    this.currentPipeIndex = 0;
  }

  getPipePath(index = 0) {
    if (process.platform === 'win32') {
      return `\\\\?\\pipe\\discord-ipc-${index}`;
    }
    const env = process.env;
    const prefix = env.XDG_RUNTIME_DIR || env.TMPDIR || env.TMP || env.TEMP || '/tmp';
    return path.join(prefix, `discord-ipc-${index}`);
  }

  init(clientId) {
    if (clientId) this.clientId = clientId;
    logRpc(`Iniciando con Client ID: ${this.clientId}`);
    this.setupIpc();
    this.connect();

    if (app && typeof app.on === 'function') {
      app.on('before-quit', () => {
        this.destroy();
      });
    }
  }

  setupIpc() {
    if (ipcMain && typeof ipcMain.on === 'function') {
      ipcMain.on('discord:setPresence', (_event, activityData) => {
        logRpc(`Recibido discord:setPresence desde renderer: ${JSON.stringify(activityData)}`);
        this.setActivity(activityData);
      });

      ipcMain.on('discord:clearPresence', () => {
        logRpc('Recibido discord:clearPresence');
        this.clearActivity();
      });
    }
  }

  connect() {
    if (this.socket || this.isConnected) return;

    const pipePath = this.getPipePath(this.currentPipeIndex);
    logRpc(`Intentando conexión a pipe: ${pipePath}`);

    try {
      this.socket = net.connect(pipePath);
      this.buffer = Buffer.alloc(0);

      this.socket.on('connect', () => {
        this.isConnected = true;
        logRpc(`Conectado a ${pipePath}. Enviando HANDSHAKE con Client ID: ${this.clientId}...`);
        this.send(OPCODES.HANDSHAKE, {
          v: 1,
          client_id: this.clientId
        });
      });

      this.socket.on('data', (chunk) => {
        this.handleData(chunk);
      });

      this.socket.on('close', () => {
        logRpc('Conexión cerrada con Discord');
        this.cleanupSocket();
        this.scheduleReconnect();
      });

      this.socket.on('error', (err) => {
        logRpc(`Error en pipe ${pipePath}: ${err.message}`);
        this.cleanupSocket();
        if (this.currentPipeIndex < 3) {
          this.currentPipeIndex++;
          this.connect();
        } else {
          this.currentPipeIndex = 0;
          this.scheduleReconnect();
        }
      });
    } catch (err) {
      logRpc(`Excepción al conectar pipe: ${err.message}`);
      this.cleanupSocket();
      this.scheduleReconnect();
    }
  }

  cleanupSocket() {
    this.isConnected = false;
    this.isReady = false;
    if (this.socket) {
      try {
        this.socket.removeAllListeners();
        this.socket.destroy();
      } catch {}
      this.socket = null;
    }
  }

  scheduleReconnect(delay = 15000) {
    if (this.reconnectTimer) return;
    logRpc(`Programada reconexión en ${delay / 1000}s`);
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect();
    }, delay);
  }

  send(opcode, payload) {
    if (!this.socket || !this.isConnected) return;
    try {
      const json = JSON.stringify(payload);
      const len = Buffer.byteLength(json);
      const packet = Buffer.alloc(8 + len);
      packet.writeInt32LE(opcode, 0);
      packet.writeInt32LE(len, 4);
      packet.write(json, 8);
      this.socket.write(packet);
    } catch (err) {
      logRpc(`Error al enviar paquete: ${err.message}`);
    }
  }

  handleData(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);

    while (this.buffer.length >= 8) {
      const opcode = this.buffer.readInt32LE(0);
      const length = this.buffer.readInt32LE(4);

      if (this.buffer.length < 8 + length) {
        break;
      }

      const payloadJson = this.buffer.toString('utf8', 8, 8 + length);
      this.buffer = this.buffer.slice(8 + length);

      try {
        const message = JSON.parse(payloadJson);
        this.handleMessage(opcode, message);
      } catch (err) {
        logRpc(`Error parseando JSON de Discord: ${err.message}`);
      }
    }
  }

  handleMessage(_opcode, data) {
    if (data.cmd === 'DISPATCH' && data.evt === 'READY') {
      this.isReady = true;
      const username = data.data?.user?.username || 'Usuario';
      logRpc(`Conectado a Discord exitosamente. Sesión de: ${username}`);
      
      // Si teníamos una actividad guardada, aplicarla de inmediato; si no, enviar actividad por defecto inicial
      if (this.lastActivity) {
        this.sendActivity(this.lastActivity);
      } else {
        this.setActivity({
          details: 'En los menus',
          state: 'Navegando por el juego',
          startTimestamp: Math.floor(Date.now() / 1000)
        });
      }
    } else if (data.cmd === 'SET_ACTIVITY') {
      if (data.evt === 'ERROR') {
        logRpc(`Respuesta de Discord ERROR en SET_ACTIVITY: ${JSON.stringify(data.data)}`);
      } else {
        logRpc(`Actividad confirmada por Discord: details="${data.data?.details}", state="${data.data?.state}"`);
      }
    }
  }

  setActivity(activity) {
    if (!activity) {
      this.clearActivity();
      return;
    }

    const payload = {};

    if (activity.details && typeof activity.details === 'string') {
      payload.details = activity.details.trim().slice(0, 128);
    }
    if (activity.state && typeof activity.state === 'string') {
      payload.state = activity.state.trim().slice(0, 128);
    }

    // Cronómetro transcurrido
    if (activity.startTimestamp) {
      const ts = typeof activity.startTimestamp === 'number' 
        ? activity.startTimestamp 
        : Math.floor(Date.now() / 1000);
      payload.timestamps = {
        start: ts > 10000000000 ? Math.floor(ts / 1000) : ts
      };
    }

    // Assets de imágenes
    const largeKey = activity.largeImageKey || this.defaultLargeImageKey;
    const largeText = activity.largeImageText || this.defaultLargeImageText;
    payload.assets = {
      large_image: largeKey,
      large_text: largeText
    };

    if (activity.smallImageKey) {
      payload.assets.small_image = activity.smallImageKey;
      if (activity.smallImageText) {
        payload.assets.small_text = activity.smallImageText;
      }
    }

    // Botones (opcional)
    if (Array.isArray(activity.buttons) && activity.buttons.length > 0) {
      payload.buttons = activity.buttons
        .filter(b => b && b.label && b.url)
        .slice(0, 2)
        .map(b => ({
          label: String(b.label).slice(0, 32),
          url: String(b.url).slice(0, 512)
        }));
    }

    this.lastActivity = payload;

    if (this.isReady) {
      this.sendActivity(payload);
    } else if (!this.isConnected) {
      this.connect();
    }
  }

  sendActivity(activity) {
    const nonce = String(Date.now());
    logRpc(`Enviando SET_ACTIVITY a Discord: ${JSON.stringify(activity)}`);
    this.send(OPCODES.FRAME, {
      cmd: 'SET_ACTIVITY',
      args: {
        pid: process.pid,
        activity: activity
      },
      nonce: nonce
    });
  }

  clearActivity() {
    this.lastActivity = null;
    if (this.isReady) {
      this.send(OPCODES.FRAME, {
        cmd: 'SET_ACTIVITY',
        args: {
          pid: process.pid,
          activity: null
        },
        nonce: String(Date.now())
      });
    }
  }

  destroy() {
    logRpc('Destruyendo DiscordRpcManager...');
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.isConnected && this.socket) {
      try {
        this.send(OPCODES.CLOSE, {});
      } catch {}
    }
    this.cleanupSocket();
  }
}

const manager = new DiscordRpcManager();
module.exports = manager;
