function showCodeMessage(message, type) {
  if (!codeMessage) return;
  
  codeMessage.textContent = message;
  codeMessage.className = 'code-message';
  
  if (type === 'success') {
    codeMessage.classList.add('success');
  } else if (type === 'error') {
    codeMessage.classList.add('error');
  }
  
  // Ocultar mensaje después de 5 segundos
  setTimeout(() => {
    codeMessage.className = 'code-message';
  }, 5000);
}

async function loadRedeemedCodes() {
  if (!isElectron || !redeemedCodesList) return;
  
  const { ok, codes } = await window.kvrcards.getRedeemedCodes();
  
  if (!ok || !Array.isArray(codes) || codes.length === 0) {
    redeemedCodesList.innerHTML = '<p style="color: #6b7280; font-style: italic;">No has canjeado ningún código aún.</p>';
    return;
  }
  
  // Mostrar códigos canjeados con descripciones colapsables
  redeemedCodesList.innerHTML = '';
  codes.forEach(codeData => {
    const item = document.createElement('div');
    item.className = 'redeemed-code-item';
    
    const header = document.createElement('div');
    header.className = 'redeemed-code-header';
    header.innerHTML = `
      <div>
        <span class="code-name">${codeData.code}</span>
        <span class="code-date">Canjeado</span>
      </div>
      <span class="expand-icon">▼</span>
    `;
    
    const details = document.createElement('div');
    details.className = 'redeemed-code-details';
    details.style.display = 'none';
    
    // Descripción
    details.innerHTML = `<p class="code-description">${codeData.description}</p>`;
    
    // Recompensas si existen
    if (codeData.rewards) {
      const rewardsList = [];
      if (codeData.rewards.coins) rewardsList.push(`💰 ${codeData.rewards.coins} Coins`);
      if (codeData.rewards.kvr) rewardsList.push(`⭐ ${codeData.rewards.kvr} KvR`);
      const traitsCount = Number(codeData.rewards.traits || codeData.rewards.trait || 0);
      if (traitsCount > 0) rewardsList.push(`<img src="./trait.png" style="width:14px;height:14px;vertical-align:middle;object-fit:contain;"> ${traitsCount} Traits`);
      if (codeData.rewards.packs && codeData.rewards.packs.length > 0) {
        const totalPacks = codeData.rewards.packs.reduce((sum, p) => sum + (p.quantity || 1), 0);
        rewardsList.push(`<img src="./sobre_oro.png" style="width:14px;height:14px;vertical-align:middle;object-fit:contain;"> ${totalPacks} Sobres`);
      }
      if (codeData.rewards.cards && codeData.rewards.cards.length > 0) {
        const totalCards = codeData.rewards.cards.reduce((sum, c) => sum + (c.quantity || 1), 0);
        rewardsList.push(`🎴 ${totalCards} Cartas`);
      }
      
      if (rewardsList.length > 0) {
        details.innerHTML += `<div class="code-rewards">${rewardsList.join(' • ')}</div>`;
      }
    }
    
    // Toggle al hacer clic
    header.addEventListener('click', () => {
      const isExpanded = details.style.display === 'block';
      details.style.display = isExpanded ? 'none' : 'block';
      const icon = header.querySelector('.expand-icon');
      icon.textContent = isExpanded ? '▼' : '▲';
      item.classList.toggle('expanded', !isExpanded);
    });
    
    item.appendChild(header);
    item.appendChild(details);
    redeemedCodesList.appendChild(item);
  });
}

// ========== PERSONALIZACIÓN - TEMAS ==========

const defaultMenuButtonDesign = 'default';

// Colores por defecto
const defaultTheme = {
  primaryBg: '#0f172a',
  secondaryBg: '#111827',
  accent: '#d4af37'
};

// Estado del tema
let currentTheme = { ...defaultTheme };
let savedCustomTheme = null;
let cachedSettings = {};
let currentMenuButtonDesign = defaultMenuButtonDesign;

function normalizeMenuButtonDesign(value) {
  return String(value || '').toLowerCase() === 'alt' ? 'alt' : 'default';
}

function applyMenuButtonDesign(design) {
  const normalized = normalizeMenuButtonDesign(design);
  currentMenuButtonDesign = normalized;
  document.body.classList.toggle('menu-button-design-alt', normalized === 'alt');

  const selector = document.getElementById('menu-button-design');
  if (selector && selector.value !== normalized) {
    selector.value = normalized;
  }
}

async function saveCustomizationSettings(patch) {
  if (!isElectron) return { ok: false, error: 'No disponible fuera de Electron' };

  const nextSettings = { ...cachedSettings, ...patch };
  const result = await window.kvrcards.saveSettings(nextSettings);
  if (result.ok) {
    cachedSettings = nextSettings;
  }
  return result;
}

function isAutoSavePackCardsEnabled() {
  if (typeof cachedSettings?.autoSavePackCards === 'boolean') {
    return cachedSettings.autoSavePackCards;
  }
  return localStorage.getItem('kvr_auto_save_pack_cards') === 'true';
}
window.isAutoSavePackCardsEnabled = isAutoSavePackCardsEnabled;

// Cargar tema guardado al iniciar desde servidor remoto
async function loadSavedTheme() {
  if (!isElectron) return;
  
  try {
    const result = await window.kvrcards.getSettings();
    if (result.ok && result.settings) {
      cachedSettings = { ...result.settings };
      applyMenuButtonDesign(result.settings.menuButtonDesign || defaultMenuButtonDesign);

      // Sincronizar switch de autoguardado de cartas si está presente
      const autoSaveEl = document.getElementById('auto-save-pack-cards');
      if (autoSaveEl) {
        const isAuto = typeof result.settings.autoSavePackCards === 'boolean'
          ? result.settings.autoSavePackCards
          : (localStorage.getItem('kvr_auto_save_pack_cards') === 'true');
        autoSaveEl.checked = isAuto;
        localStorage.setItem('kvr_auto_save_pack_cards', isAuto ? 'true' : 'false');
      }

      // Sincronizar configuración de pantalla si está presente
      if (typeof syncDisplaySettingsUI === 'function') {
        syncDisplaySettingsUI(result.settings);
      }

      if (result.settings.theme) {
        const theme = result.settings.theme;
        savedCustomTheme = theme;
        currentTheme = { ...theme };
        applyTheme(currentTheme);
        
        // Marcar el tema personalizado como activo
        document.querySelector('.theme-option[data-theme="custom"]')?.classList.add('active');
        document.querySelector('.theme-option[data-theme="default"]')?.classList.remove('active');
        
        console.log('[THEME] Tema personalizado cargado desde remoto');
      }
    } else {
      applyMenuButtonDesign(defaultMenuButtonDesign);
    }
  } catch (e) {
    console.error('[THEME] Error cargando tema:', e);
  }
}

// Aplicar tema a la aplicación
function applyTheme(theme) {
  if (!theme || typeof theme !== 'object') {
    console.warn('[THEME] Tema inválido, usando default');
    theme = THEMES.default;
  }
  
  const root = document.documentElement;
  
  // Aplicar colores principales
  root.style.setProperty('--primary-bg', theme.primaryBg || '#1a1a2e');
  root.style.setProperty('--secondary-bg', theme.secondaryBg || '#16213e');
  root.style.setProperty('--gold', theme.accent || '#fbbf24');
  root.style.setProperty('--gold-hover', adjustBrightness(theme.accent || '#fbbf24', -10));
  
  // Actualizar fondos
  document.body.style.background = theme.primaryBg || '#1a1a2e';
  
  // Actualizar colores secundarios (cartas, sobres, etc)
  document.querySelectorAll('.card, .pack-card, .shop-item, .hud-panel, nav.menu').forEach(el => {
    el.style.background = theme.secondaryBg || '#16213e';
  });
  
  currentTheme = { ...theme };
}

// Ajustar brillo de un color
function adjustBrightness(hex, percent) {
  const num = parseInt(hex.replace('#', ''), 16);
  const r = Math.max(0, Math.min(255, ((num >> 16) & 0xff) + percent));
  const g = Math.max(0, Math.min(255, ((num >> 8) & 0xff) + percent));
  const b = Math.max(0, Math.min(255, (num & 0xff) + percent));
  return '#' + ((r << 16) | (g << 8) | b).toString(16).padStart(6, '0');
}

// ==================== CONFIGURACIÓN DE PANTALLA ====================
async function syncDisplaySettingsUI(settings) {
  const fullscreenToggle = document.getElementById('fullscreen-toggle');
  const windowModeOptions = document.getElementById('window-mode-options');
  const radioWindowed = document.getElementById('radio-mode-windowed');
  const radioBorderless = document.getElementById('radio-mode-borderless');
  if (!fullscreenToggle || !windowModeOptions) return;

  let isFull = true;
  let subMode = 'windowed-1080';

  if (isElectron && window.kvrcards?.getDisplayMode) {
    try {
      const modeData = await window.kvrcards.getDisplayMode();
      if (modeData && modeData.ok) {
        isFull = modeData.isFullScreen !== undefined ? modeData.isFullScreen : (modeData.mode === 'fullscreen');
        subMode = modeData.subMode || 'windowed-1080';
      }
    } catch (e) {
      isFull = (settings?.displayMode || localStorage.getItem('kvr_display_mode') || 'fullscreen') === 'fullscreen';
      subMode = settings?.windowSubMode || localStorage.getItem('kvr_window_submode') || 'windowed-1080';
    }
  } else {
    isFull = (settings?.displayMode || localStorage.getItem('kvr_display_mode') || 'fullscreen') === 'fullscreen';
    subMode = settings?.windowSubMode || localStorage.getItem('kvr_window_submode') || 'windowed-1080';
  }

  fullscreenToggle.checked = isFull;
  windowModeOptions.style.display = isFull ? 'none' : 'block';

  if (subMode === 'borderless') {
    if (radioBorderless) radioBorderless.checked = true;
  } else {
    if (radioWindowed) radioWindowed.checked = true;
  }

  const radios = document.querySelectorAll('input[name="window-submode"]');
  radios.forEach(radio => {
    const parentLabel = radio.closest('.display-radio-label');
    if (parentLabel) {
      if (radio.checked) parentLabel.classList.add('selected');
      else parentLabel.classList.remove('selected');
    }
  });
}
window.syncDisplaySettingsUI = syncDisplaySettingsUI;

async function initializeDisplaySettings() {
  const fullscreenToggle = document.getElementById('fullscreen-toggle');
  const windowModeOptions = document.getElementById('window-mode-options');
  const radioWindowed = document.getElementById('radio-mode-windowed');
  const radioBorderless = document.getElementById('radio-mode-borderless');
  const btnApply = document.getElementById('btn-apply-display-mode');
  const applyStatus = document.getElementById('display-apply-status');

  if (!fullscreenToggle || !windowModeOptions) return;

  function updateRadioVisuals() {
    const radios = document.querySelectorAll('input[name="window-submode"]');
    radios.forEach(radio => {
      const parentLabel = radio.closest('.display-radio-label');
      if (parentLabel) {
        if (radio.checked) {
          parentLabel.classList.add('selected');
        } else {
          parentLabel.classList.remove('selected');
        }
      }
    });
  }

  let statusTimeout = null;
  function showApplyStatus(msg = '✅ Modo aplicado correctamente') {
    if (!applyStatus) return;
    applyStatus.textContent = msg;
    applyStatus.style.display = 'inline-block';
    if (statusTimeout) clearTimeout(statusTimeout);
    statusTimeout = setTimeout(() => {
      applyStatus.style.display = 'none';
    }, 3000);
  }

  // Sincronizar estado inicial
  await syncDisplaySettingsUI(cachedSettings);

  // Escuchar cambios en los radios para actualizar estilos
  const radios = document.querySelectorAll('input[name="window-submode"]');
  radios.forEach(r => {
    r.addEventListener('change', updateRadioVisuals);
  });

  // Switch de Pantalla Completa
  fullscreenToggle.addEventListener('change', async () => {
    const wantsFullscreen = fullscreenToggle.checked;

    if (wantsFullscreen) {
      // Al activarlo: entra automáticamente a pantalla completa
      windowModeOptions.style.display = 'none';
      if (applyStatus) applyStatus.style.display = 'none';

      localStorage.setItem('kvr_display_mode', 'fullscreen');
      try {
        await saveCustomizationSettings({ displayMode: 'fullscreen' });
      } catch (e) {}

      if (isElectron && window.kvrcards?.setDisplayMode) {
        try {
          await window.kvrcards.setDisplayMode({ mode: 'fullscreen' });
        } catch (e) {
          console.error('[DISPLAY] Error activando pantalla completa:', e);
        }
      } else {
        try {
          if (!document.fullscreenElement) {
            await document.documentElement.requestFullscreen();
          }
        } catch (e) {}
      }
    } else {
      // Al desactivarlo: muestra las opciones debajo con el botón de aplicar
      windowModeOptions.style.display = 'block';
      updateRadioVisuals();
    }
  });

  // Botón "Aplicar" para modo ventana
  if (btnApply) {
    btnApply.addEventListener('click', async () => {
      const selectedSubMode = radioBorderless?.checked ? 'borderless' : 'windowed-1080';

      localStorage.setItem('kvr_display_mode', 'windowed');
      localStorage.setItem('kvr_window_submode', selectedSubMode);

      try {
        await saveCustomizationSettings({
          displayMode: 'windowed',
          windowSubMode: selectedSubMode
        });
      } catch (e) {}

      if (isElectron && window.kvrcards?.setDisplayMode) {
        try {
          await window.kvrcards.setDisplayMode({
            mode: 'windowed',
            subMode: selectedSubMode
          });
        } catch (e) {
          console.error('[DISPLAY] Error aplicando modo ventana:', e);
        }
      } else {
        try {
          if (document.fullscreenElement) {
            await document.exitFullscreen();
          }
        } catch (e) {}
      }

      showApplyStatus('✅ Modo de ventana aplicado');
    });
  }
}
window.initializeDisplaySettings = initializeDisplaySettings;

// Inicializar sistema de temas
function initializeThemeSystem() {
  const themeOptions = document.querySelectorAll('.theme-option');
  const customEditor = document.getElementById('custom-theme-editor');
  const menuButtonDesignSelect = document.getElementById('menu-button-design');
  
  const primaryColorInput = document.getElementById('primary-bg-color');
  const primaryHexInput = document.getElementById('primary-bg-hex');
  const secondaryColorInput = document.getElementById('secondary-bg-color');
  const secondaryHexInput = document.getElementById('secondary-bg-hex');
  const accentColorInput = document.getElementById('accent-color');
  const accentHexInput = document.getElementById('accent-hex');
  
  const revertBtn = document.getElementById('revert-theme-btn');
  const saveBtn = document.getElementById('save-theme-btn');

  applyMenuButtonDesign(cachedSettings.menuButtonDesign || currentMenuButtonDesign);

  if (menuButtonDesignSelect) {
    menuButtonDesignSelect.value = normalizeMenuButtonDesign(cachedSettings.menuButtonDesign || currentMenuButtonDesign);
    menuButtonDesignSelect.addEventListener('change', async () => {
      const design = normalizeMenuButtonDesign(menuButtonDesignSelect.value);
      applyMenuButtonDesign(design);

      try {
        const result = await saveCustomizationSettings({ menuButtonDesign: design });
        if (!result.ok) {
          console.error('[THEME] Error al guardar diseño de botones del menú:', result.error);
        }
      } catch (e) {
        console.error('[THEME] Error al guardar diseño de botones del menú:', e);
      }
    });
  }

  // Switch de autoguardado de cartas al abrir sobres
  const autoSaveCheckbox = document.getElementById('auto-save-pack-cards');
  if (autoSaveCheckbox) {
    const isAutoSave = typeof cachedSettings.autoSavePackCards === 'boolean'
      ? cachedSettings.autoSavePackCards
      : (localStorage.getItem('kvr_auto_save_pack_cards') === 'true');
    autoSaveCheckbox.checked = isAutoSave;

    autoSaveCheckbox.addEventListener('change', async () => {
      const enabled = autoSaveCheckbox.checked;
      localStorage.setItem('kvr_auto_save_pack_cards', enabled ? 'true' : 'false');
      try {
        await saveCustomizationSettings({ autoSavePackCards: enabled });
      } catch (e) {
        console.warn('[SETTINGS] Error guardando autoSavePackCards:', e);
      }
    });
  }

  // Inicializar configuración de pantalla
  initializeDisplaySettings();
  
  // Selector de tema
  themeOptions.forEach(option => {
    option.addEventListener('click', () => {
      const theme = option.dataset.theme;
      
      themeOptions.forEach(opt => opt.classList.remove('active'));
      option.classList.add('active');
      
      if (theme === 'custom') {
        customEditor.style.display = 'block';
        
        // Cargar valores del tema guardado o actual
        const themeToLoad = savedCustomTheme || currentTheme;
        primaryColorInput.value = themeToLoad.primaryBg;
        primaryHexInput.value = themeToLoad.primaryBg;
        secondaryColorInput.value = themeToLoad.secondaryBg;
        secondaryHexInput.value = themeToLoad.secondaryBg;
        accentColorInput.value = themeToLoad.accent;
        accentHexInput.value = themeToLoad.accent;
        
        updateLivePreview();
      } else {
        customEditor.style.display = 'none';
        applyTheme(defaultTheme);
        localStorage.setItem('activeTheme', 'default');
      }
    });
  });
  
  // Sincronizar color picker con input de texto
  function syncColorInputs(colorInput, hexInput) {
    colorInput.addEventListener('input', () => {
      hexInput.value = colorInput.value;
      updateLivePreview();
    });
    
    hexInput.addEventListener('input', () => {
      const value = hexInput.value;
      if (/^#[0-9A-Fa-f]{6}$/.test(value)) {
        colorInput.value = value;
        updateLivePreview();
      }
    });
  }
  
  syncColorInputs(primaryColorInput, primaryHexInput);
  syncColorInputs(secondaryColorInput, secondaryHexInput);
  syncColorInputs(accentColorInput, accentHexInput);
  
  // Actualizar vista previa en vivo
  function updateLivePreview() {
    const preview = document.getElementById('theme-live-preview');
    preview.style.setProperty('--preview-primary-bg', primaryColorInput.value);
    preview.style.setProperty('--preview-secondary-bg', secondaryColorInput.value);
    preview.style.setProperty('--preview-accent', accentColorInput.value);
  }
  
  // Revertir cambios
  revertBtn.addEventListener('click', () => {
    const themeToRevert = savedCustomTheme || defaultTheme;
    primaryColorInput.value = themeToRevert.primaryBg;
    primaryHexInput.value = themeToRevert.primaryBg;
    secondaryColorInput.value = themeToRevert.secondaryBg;
    secondaryHexInput.value = themeToRevert.secondaryBg;
    accentColorInput.value = themeToRevert.accent;
    accentHexInput.value = themeToRevert.accent;
    updateLivePreview();
  });
  
  // Guardar tema en servidor remoto
  saveBtn.addEventListener('click', async () => {
    const newTheme = {
      primaryBg: primaryColorInput.value,
      secondaryBg: secondaryColorInput.value,
      accent: accentColorInput.value
    };
    
    savedCustomTheme = { ...newTheme };
    
    try {
      const result = await saveCustomizationSettings({ theme: newTheme });
      if (result.ok) {
        applyTheme(newTheme);
        
        // Feedback visual
        saveBtn.textContent = '✓ Guardado';
        setTimeout(() => {
          saveBtn.textContent = '💾 Guardar Tema';
        }, 2000);
        console.log('[THEME] Tema guardado en remoto');
      } else {
        console.error('[THEME] Error al guardar tema:', result.error);
      }
    } catch (e) {
      console.error('[THEME] Error al guardar tema:', e);
    }
  });
}

// ========== SISTEMA DE MÚSICA - VARIABLES ==========
let backgroundMusic = null;
let currentTrack = 'none';
let musicEnabled = true;
let musicVolume = 0.5;
let musicReady = false;
let pendingMusicStart = false;
let customBattleMusicEnabled = true; // Música de batalla personalizada para modo offline y modo infinito (por defecto true)
const DEFAULT_TRACK = 'music/kvrcardsmenu1.mp3'; // Canción por defecto
const BATTLE_TRACK = 'music/battlesong.mp3'; // Canción de batalla
const BATTLE_INTRO_TRACK = 'music/introbatalla.mp3'; // Canción de intro de batalla (animación de cartas)

function isCustomBattleMusicEnabled() {
  const saved = localStorage.getItem('customBattleMusicEnabled');
  return saved === null ? true : saved === 'true';
}
window.isCustomBattleMusicEnabled = isCustomBattleMusicEnabled;

// ========== SISTEMA DE EFECTOS DE SONIDO (SFX) ==========
let sfxEnabled = true;
let sfxVolume = 1.0;
let battleIntroAudio = null; // Instancia de audio de la intro de batalla como SFX

// Rutas de los efectos de sonido
const SFX_PATHS = {
  battleIntro: 'music/introbatalla.mp3',        // Canción/Intro de batalla (animación de cartas)
  roulette: 'music/sfx/roulette.mp3',           // Sonido de ruleta girando
  cardSelect: 'music/sfx/cardSelect.mp3',       // Selección de carta
  powerActivate: 'music/sfx/powerActivate.mp3', // Activación de poder
  upgradeCard: 'music/sfx/mejorarCarta.mp3',    // Animación de mejora de carta (modo infinito)
  shopkeeperInteract: 'music/sfx/shopkeeperInteract.mp3', // Interacción con tiendero
  shopkeeperTyping: 'music/sfx/shopkeeperTyping.mp3',     // Tipeo de diálogo de tiendero
  statSelect: 'music/sfx/statSelect.mp3',       // Selección de estadística
  buttonClick: 'music/sfx/buttonClick.mp3',     // Click en botones del menú
  buttonHover: 'music/sfx/buttonHover.mp3',     // Hover sobre botones del menú
  packSplitWhoosh: 'music/sfx/woosh.mp3',       // Whoosh grave al iniciar split
  packArcaneHum: 'music/sfx/arcane hum.mp3',    // Zumbido mágico de fondo
  packSparkle: 'music/sfx/sparkle.mp3',         // Brillo al mostrar banners
  packChime: 'music/sfx/chime.mp3',             // Chime al mostrar banners
  packRiser: 'music/sfx/riser.mp3',             // Riser corto antes del reveal
  packImpact: 'music/sfx/impact.mp3',            // Impact al completar reveal
  cardsrunning: 'music/sfx/cardsrunning.mp3'    // Audio de Carrera de Cartas
};

// Pool de audio para efectos frecuentes (evita crear y destruir objetos Audio en cada movimiento de ratón)
const sfxPool = {};

// Función para reproducir efecto de sonido
function playSFX(sfxType, options = {}) {
  if (!sfxEnabled || !SFX_PATHS[sfxType]) return;

  const { volumeMultiplier = 1, loop = false } = options;
  
  try {
    let sfx;
    if (sfxType === 'buttonHover' || sfxType === 'buttonClick') {
      if (!sfxPool[sfxType]) {
        sfxPool[sfxType] = new Audio(SFX_PATHS[sfxType]);
      }
      sfx = sfxPool[sfxType];
      try { sfx.currentTime = 0; } catch {}
    } else {
      sfx = new Audio(SFX_PATHS[sfxType]);
    }
    sfx.volume = Math.max(0, Math.min(1, sfxVolume * volumeMultiplier));
    sfx.loop = loop;
    sfx.play().catch(() => {});
    return sfx;
  } catch (e) {
    console.error('[SFX] Error creando audio:', sfxType, e);
  }
}

function stopSFX(audio, fadeMs = 0) {
  if (!audio) return;

  if (fadeMs <= 0) {
    try {
      audio.pause();
      audio.currentTime = 0;
    } catch {}
    return;
  }

  const steps = 8;
  const startVolume = Number(audio.volume) || 0;
  const stepDuration = Math.max(20, Math.floor(fadeMs / steps));
  let currentStep = 0;

  const fadeInterval = setInterval(() => {
    currentStep += 1;
    const nextVolume = startVolume * (1 - currentStep / steps);
    audio.volume = Math.max(0, nextVolume);

    if (currentStep >= steps) {
      clearInterval(fadeInterval);
      try {
        audio.pause();
        audio.currentTime = 0;
      } catch {}
    }
  }, stepDuration);
}

// Cargar configuración de SFX
function loadSFXSettings() {
  const savedEnabled = localStorage.getItem('sfxEnabled');
  const savedVolume = localStorage.getItem('sfxVolume');
  
  if (savedEnabled !== null) sfxEnabled = savedEnabled === 'true';
  if (savedVolume !== null) sfxVolume = parseFloat(savedVolume);
}

// Inicializar SFX en botones del menú y UI usando delegación de eventos
function initializeButtonSFX() {
  // Cargar configuración de SFX primero
  loadSFXSettings();
  
  // Selectores de botones que deben tener SFX
  const buttonSelectors = '.menu-card, .menu-btn, .btn-primary, .difficulty-btn, .difficulty-card, .mode-card, .game-mode-card, .game-type-card, .game-back-btn, .back-to-menu-btn, .back-btn, button[data-view], button[data-difficulty], #abandon-battle-btn, #battle-return-menu-btn';
  
  // Usar delegación de eventos en el documento para capturar todos los clicks
  document.addEventListener('click', (e) => {
    const target = e.target.closest(buttonSelectors);
    if (target) {
      playSFX('buttonClick');
    }
  }, true); // useCapture = true para ejecutar antes que otros handlers
  
  // Usar delegación de eventos para mouseenter (hover)
  document.addEventListener('mouseover', (e) => {
    const target = e.target.closest(buttonSelectors);
    if (target && !target.hasAttribute('data-sfx-hover')) {
      target.setAttribute('data-sfx-hover', 'true');
      playSFX('buttonHover');
      // Remover atributo cuando el mouse salga
      target.addEventListener('mouseleave', () => {
        target.removeAttribute('data-sfx-hover');
      }, { once: true });
    }
  }, true);
  
  console.log('[SFX] Sistema de SFX de botones inicializado con delegación de eventos');
}

// Inicializar pestañas de coleccionables
function initializeCollectiblesTabs() {
  // Pestañas principales
  document.querySelectorAll('.collectible-tab').forEach(tab => {
    tab.addEventListener('click', async () => {
      const tabName = tab.dataset.tab;
      
      // Actualizar pestañas
      document.querySelectorAll('.collectible-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      // Mostrar contenido correspondiente
      document.querySelectorAll('.collectible-content').forEach(content => {
        content.classList.remove('active');
        content.style.display = 'none';
      });
      
      const targetContent = document.getElementById(`collectible-content-${tabName}`);
      if (targetContent) {
        targetContent.classList.add('active');
        targetContent.style.display = 'block';
      }
      
      // Cargar contenido según la pestaña
      if (tabName === 'kizuna') {
        renderKizunas();
        loadKizunas().then(() => renderKizunas()).catch(console.error);
      } else if (tabName === 'evolutions') {
        await initEvolutions();
      } else if (tabName === 'deliverables') {
        if (typeof initEvents === 'function') {
          await initEvents();
        }
      } else if (tabName === 'titles') {
        if (typeof renderTitlesCollectibleView === 'function') {
          await renderTitlesCollectibleView();
        }
      } else if (tabName === 'backgrounds') {
        if (typeof renderBackgroundsCollectibleView === 'function') {
          await renderBackgroundsCollectibleView();
        }
      }
    });
  });
  
  // Subpestañas de misiones
  document.querySelectorAll('.mission-subtab').forEach(tab => {
    tab.addEventListener('click', () => {
      const subtabName = tab.dataset.subtab;
      
      // Actualizar subpestañas
      document.querySelectorAll('.mission-subtab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      // Mostrar contenido correspondiente
      document.querySelectorAll('.missions-subcontent').forEach(content => {
        content.classList.remove('active');
        content.style.display = 'none';
      });
      
      const targetContent = document.getElementById(`missions-${subtabName}`);
      if (targetContent) {
        targetContent.classList.add('active');
        targetContent.style.display = 'block';
      }
    });
  });
  
  // Subpestañas de eventos
  document.querySelectorAll('.event-subtab').forEach(tab => {
    tab.addEventListener('click', () => {
      const subtabName = tab.dataset.subtab;
      
      // Actualizar subpestañas
      document.querySelectorAll('.event-subtab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      
      // Mostrar contenido correspondiente
      document.querySelectorAll('.events-subcontent').forEach(content => {
        content.classList.remove('active');
        content.style.display = 'none';
      });
      
      const targetContent = document.getElementById(`events-${subtabName}`);
      if (targetContent) {
        targetContent.classList.add('active');
        targetContent.style.display = 'block';
      }
    });
  });
  
  console.log('[INIT] Pestañas de coleccionables inicializadas');
}

// ========== SISTEMA DE MÚSICA - FUNCIONES ==========

// Función para iniciar música tras primera interacción
function startMusicAfterInteraction() {
  if (window.isIntroPlaying) return;
  if (backgroundMusic && !backgroundMusic.paused) {
    musicReady = true;
    pendingMusicStart = false;
    const statusEl = document.getElementById('music-status');
    if (statusEl) statusEl.style.display = 'none';
    return;
  }

  if (!musicReady && pendingMusicStart && musicEnabled && currentTrack !== 'none') {
    console.log('[MUSIC] Iniciando música tras interacción del usuario:', currentTrack);
    playBackgroundMusic(currentTrack);
    musicReady = true;
    pendingMusicStart = false;
    
    // Ocultar mensaje de status
    const statusEl = document.getElementById('music-status');
    if (statusEl) statusEl.style.display = 'none';
  }
}

// Inicializar sistema de música
async function initializeMusicSystem() {
  // Cargar configuración guardada
  const savedEnabled = localStorage.getItem('musicEnabled');
  const savedVolume = localStorage.getItem('musicVolume');
  const savedTrack = localStorage.getItem('musicTrack');
  
  if (savedEnabled !== null) musicEnabled = savedEnabled === 'true';
  if (savedVolume !== null) musicVolume = parseFloat(savedVolume);
  
  // Si es la primera vez o no hay track guardado, usar el default
  if (savedTrack !== null) {
    currentTrack = savedTrack;
  } else {
    currentTrack = DEFAULT_TRACK;
    localStorage.setItem('musicTrack', DEFAULT_TRACK);
  }
  
  // Configurar controles
  const musicToggle = document.getElementById('music-enabled');
  const volumeSlider = document.getElementById('music-volume');
  const volumeValue = document.getElementById('volume-value');
  const sfxVolumeSlider = document.getElementById('sfx-volume');
  const sfxVolumeValue = document.getElementById('sfx-volume-value');
  const refreshBtn = document.getElementById('refresh-music-btn');
  
  if (musicToggle) {
    musicToggle.checked = musicEnabled;
    musicToggle.addEventListener('change', (e) => {
      musicEnabled = e.target.checked;
      localStorage.setItem('musicEnabled', musicEnabled);
      
      if (musicEnabled && currentTrack !== 'none') {
        playBackgroundMusic(currentTrack);
      } else {
        stopBackgroundMusic();
      }
    });
  }

  // Toggle de música de batalla personalizada (offline e infinito)
  const customBattleMusicToggle = document.getElementById('custom-battle-music-enabled');
  if (customBattleMusicToggle) {
    customBattleMusicEnabled = isCustomBattleMusicEnabled();
    customBattleMusicToggle.checked = customBattleMusicEnabled;
    customBattleMusicToggle.addEventListener('change', (e) => {
      customBattleMusicEnabled = e.target.checked;
      localStorage.setItem('customBattleMusicEnabled', customBattleMusicEnabled ? 'true' : 'false');
      console.log('[SETTINGS] Música de batalla personalizada (offline/infinito):', customBattleMusicEnabled ? 'Activada' : 'Desactivada');
    });
  }
  
  if (volumeSlider) {
    volumeSlider.value = musicVolume * 100;
    volumeValue.textContent = Math.round(musicVolume * 100) + '%';
    
    volumeSlider.addEventListener('input', (e) => {
      musicVolume = e.target.value / 100;
      volumeValue.textContent = Math.round(musicVolume * 100) + '%';
      localStorage.setItem('musicVolume', musicVolume);
      
      if (backgroundMusic) {
        backgroundMusic.volume = musicVolume;
      }
    });
  }
  
  // Control de volumen de SFX
  if (sfxVolumeSlider) {
    sfxVolumeSlider.value = sfxVolume * 100;
    sfxVolumeValue.textContent = Math.round(sfxVolume * 100) + '%';
    
    sfxVolumeSlider.addEventListener('input', (e) => {
      sfxVolume = e.target.value / 100;
      sfxVolumeValue.textContent = Math.round(sfxVolume * 100) + '%';
      localStorage.setItem('sfxVolume', sfxVolume);
      if (battleIntroAudio) {
        battleIntroAudio.volume = Math.max(0, Math.min(1, sfxVolume * 0.9));
      }
    });
  }
  
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => loadMusicTracks());
  }
  
  // Configurar botón de carga de música
  const uploadBtn = document.getElementById('upload-music-btn');
  const uploadInput = document.getElementById('upload-music-input');
  
  if (uploadBtn && uploadInput) {
    uploadBtn.addEventListener('click', () => {
      uploadInput.click();
    });
    
    uploadInput.addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      // Validar que sea un archivo de audio
      const validTypes = ['audio/mpeg', 'audio/mp3', 'audio/ogg', 'audio/wav', 'audio/m4a', 'audio/x-m4a'];
      if (!validTypes.includes(file.type) && !file.name.match(/\.(mp3|ogg|wav|m4a)$/i)) {
        alert('⚠️ Por favor, selecciona un archivo de audio válido (MP3, OGG, WAV, M4A)');
        uploadInput.value = '';
        return;
      }
      
      // Mostrar indicador de carga
      uploadBtn.disabled = true;
      uploadBtn.textContent = '⏳ Cargando...';
      
      try {
        // Leer el archivo como ArrayBuffer
        const arrayBuffer = await file.arrayBuffer();
        
        // Subir al backend
        const result = await window.kvrcards.uploadMusicTrack({
          filename: file.name,
          buffer: Array.from(new Uint8Array(arrayBuffer))
        });
        
        if (result.ok) {
          console.log('[MUSIC] Archivo cargado exitosamente:', result.filename);
          
          // Recargar lista de música
          await loadMusicTracks();
          
          // Seleccionar automáticamente la nueva canción
          selectMusicTrack(result.path);
          
          // Feedback visual
          uploadBtn.textContent = '✓ ¡Cargado!';
          setTimeout(() => {
            uploadBtn.textContent = '📁 Cargar archivo de música';
            uploadBtn.disabled = false;
          }, 2000);
        } else {
          throw new Error(result.error || 'Error desconocido');
        }
      } catch (error) {
        console.error('[MUSIC] Error cargando archivo:', error);
        alert('❌ Error al cargar el archivo: ' + error.message);
        uploadBtn.textContent = '📁 Cargar archivo de música';
        uploadBtn.disabled = false;
      }
      
      // Limpiar input
      uploadInput.value = '';
    });
  }
  
  // Añadir listeners globales para iniciar música en primera interacción
  const startMusicEvents = ['click', 'keydown', 'touchstart'];
  startMusicEvents.forEach(event => {
    document.addEventListener(event, startMusicAfterInteraction, { once: true });
  });
  
  // Cargar lista de canciones (esto puede tardar, hacerlo sin bloquear)
  console.log('[MUSIC] Cargando tracks...');
  
  try {
    // Obtener tracks disponibles
    const { ok, tracks } = (typeof window.kvrcards?.getAvailableMusicTracks === 'function')
      ? await window.kvrcards.getAvailableMusicTracks()
      : { ok: false, tracks: [] };
    
    console.log('[MUSIC] Tracks disponibles:', tracks ? tracks.length : 0);
    console.log('[MUSIC] Música activada:', musicEnabled);
    console.log('[MUSIC] Track actual:', currentTrack);
    
    // Renderizar lista
    await loadMusicTracks();
    
    if (ok && tracks && tracks.length > 0) {
      if (currentTrack === DEFAULT_TRACK || currentTrack === 'none') {
        // Buscar si existe kvrcardsmenu1 con cualquier extensión
        const defaultTrack = tracks.find(t => 
          t.filename.toLowerCase().startsWith('kvrcardsmenu1')
        );
        
        console.log('[MUSIC] Buscando kvrcardsmenu1... encontrado:', !!defaultTrack);
        
        if (defaultTrack) {
          currentTrack = defaultTrack.path;
          localStorage.setItem('musicTrack', defaultTrack.path);
          console.log('[MUSIC] Track por defecto configurado:', currentTrack);
        } else {
          // Si no existe kvrcardsmenu1, usar la primera canción disponible
          currentTrack = tracks[0].path;
          localStorage.setItem('musicTrack', tracks[0].path);
          console.log('[MUSIC] Usando primera canción disponible:', currentTrack);
        }
      }
      
      // Actualizar UI para marcar la canción activa
      setTimeout(() => {
        const activeItem = document.querySelector(`[data-music="${currentTrack}"]`);
        if (activeItem) {
          document.querySelectorAll('.music-item').forEach(item => item.classList.remove('active'));
          activeItem.classList.add('active');
        }
      }, 100);
    }
    
    // Marcar que hay música pendiente de reproducir
    if (musicEnabled && currentTrack !== 'none') {
      pendingMusicStart = true;
      console.log('[MUSIC] Música preparada, esperando interacción del usuario...');
      
      // Intentar reproducir inmediatamente (puede fallar por políticas del navegador)
      setTimeout(() => {
        const result = playBackgroundMusic(currentTrack);
        
        // Si falló, mostrar mensaje
        if (!result) {
          const statusEl = document.getElementById('music-status');
          if (statusEl) {
            statusEl.style.display = 'flex';
            setTimeout(() => {
              if (!musicReady) {
                statusEl.style.display = 'none';
              }
            }, 10000); // Ocultar después de 10 segundos
          }
        }
      }, 500);
    }
  } catch (e) {
    console.error('[MUSIC] Error inicializando sistema de música:', e);
  }
}

function getSongFriendlyName(track) {
  const filename = (track?.filename || '').toLowerCase();
  if (filename === 'kvrcardsmenu1.mp3') return 'KVR Cards Clásica';
  if (filename === 'kvrcardsmenualternative.mp3') return 'KVR Cards Alternativa';
  if (filename === 'narutoroleplaymenu.mp3') return 'Naruto Roleplay';
  if (filename === 'battlesong.mp3') return 'Batalla Estándar';
  if (filename === 'classicbattlesong.mp3') return 'Batalla Clásica';
  if (filename === 'alternativebattlesong.mp3') return 'Batalla Alternativa';
  return track?.name || track?.filename || 'Pista de Audio';
}

// Cargar lista de canciones disponibles
async function loadMusicTracks() {
  const menuMusicList = document.getElementById('menu-music-list');
  const battleMusicList = document.getElementById('battle-music-list');
  const noMenuMusicMsg = document.getElementById('no-menu-music-message');
  const noBattleMusicMsg = document.getElementById('no-battle-music-message');
  
  if (!menuMusicList && !battleMusicList) return;
  
  let tracks = [];
  try {
    if (typeof isElectron !== 'undefined' && isElectron && window.kvrcards?.getAvailableMusicTracks) {
      const res = await window.kvrcards.getAvailableMusicTracks();
      tracks = res?.tracks || [];
    }
  } catch (e) {
    console.warn('[MUSIC] Error obteniendo tracks de Electron:', e);
  }

  if (!tracks || tracks.length === 0) {
    tracks = [
      { id: 'kvrcardsmenu1.mp3', name: 'KVR Cards Clásica', filename: 'kvrcardsmenu1.mp3', path: 'music/kvrcardsmenu1.mp3' },
      { id: 'kvrcardsmenualternative.mp3', name: 'KVR Cards Alternativa', filename: 'kvrcardsmenualternative.mp3', path: 'music/kvrcardsmenualternative.mp3' },
      { id: 'narutoroleplaymenu.mp3', name: 'Naruto Roleplay', filename: 'narutoroleplaymenu.mp3', path: 'music/narutoroleplaymenu.mp3' },
      { id: 'battlesong.mp3', name: 'Batalla Estándar', filename: 'battlesong.mp3', path: 'music/battlesong.mp3' },
      { id: 'classicbattlesong.mp3', name: 'Batalla Clásica', filename: 'classicbattlesong.mp3', path: 'music/classicbattlesong.mp3' },
      { id: 'alternativebattlesong.mp3', name: 'Batalla Alternativa', filename: 'alternativebattlesong.mp3', path: 'music/alternativebattlesong.mp3' }
    ];
  }
  
  // Cargar selecciones guardadas
  const savedMenuTrack = localStorage.getItem('menuMusicTrack') || DEFAULT_TRACK;
  const savedBattleTrack = localStorage.getItem('battleMusicTrack') || BATTLE_TRACK;
  
  // Canciones por defecto que no se pueden eliminar
  const defaultMenuSongs = ['kvrcardsmenu1.mp3', 'kvrcardsmenualternative.mp3', 'narutoroleplaymenu.mp3'];
  const defaultBattleSongs = ['battlesong.mp3', 'alternativebattlesong.mp3', 'classicbattlesong.mp3'];
  
  // Archivos SFX e internos que no deben aparecer en la lista de música seleccionable
  const sfxFiles = ['roulette.mp3', 'cardselect.mp3', 'poweractivate.mp3', 'statselect.mp3', 'buttonclick.mp3', 'buttonhover.mp3', 'cardsrunning.mp3', 'introbatalla.mp3'];
  
  // Filtrar tracks para música de menú (excluir battlesong y SFX/internos)
  const menuTracks = tracks ? tracks.filter(track => {
    const filename = track.filename.toLowerCase();
    return !sfxFiles.some(sfx => filename === sfx.toLowerCase()) && 
           !defaultBattleSongs.some(battle => filename === battle.toLowerCase());
  }) : [];
  
  // Filtrar tracks para música de batalla (solo battlesong y otras opcionales)
  const battleTracks = tracks ? tracks.filter(track => {
    const filename = track.filename.toLowerCase();
    return !sfxFiles.some(sfx => filename === sfx.toLowerCase()) &&
           (defaultBattleSongs.some(battle => filename === battle.toLowerCase()) || 
            !defaultMenuSongs.some(menu => filename === menu.toLowerCase()));
  }) : [];
  
  // Poblar lista de música de menú
  if (menuMusicList) {
    let menuHtml = `
      <button class="music-item ${savedMenuTrack === 'none' ? 'active' : ''}" data-music="none" data-music-type="menu">
        <span class="music-icon">🔇</span>
        <div class="music-info">
          <span class="music-name">Sin música</span>
          <span class="music-desc">Desactivar música de fondo</span>
        </div>
        <span class="playing-indicator">▶</span>
      </button>
    `;
    
    menuTracks.forEach(track => {
      const isActive = savedMenuTrack && track.path && (savedMenuTrack === track.path || savedMenuTrack.toLowerCase() === track.path.toLowerCase());
      const isDefault = defaultMenuSongs.some(def => track.filename.toLowerCase() === def.toLowerCase());
      
      menuHtml += `
        <div class="music-item-wrapper ${isActive ? 'active' : ''}" data-music="${track.path}">
          <button class="music-item ${isActive ? 'active' : ''}" data-music="${track.path}" data-music-type="menu">
            <span class="music-icon">🎵</span>
            <div class="music-info">
              <span class="music-name">${getSongFriendlyName(track)}</span>
              <span class="music-desc">${track.filename}</span>
            </div>
            <span class="playing-indicator">▶</span>
          </button>
          ${!isDefault ? `<button class="delete-music-btn" data-filename="${track.filename}" title="Eliminar esta canción">🗑️</button>` : ''}
        </div>
      `;
    });
    
    menuMusicList.innerHTML = menuHtml;
    if (noMenuMusicMsg) noMenuMusicMsg.style.display = menuTracks.length === 0 ? 'block' : 'none';
  }
  
  // Poblar lista de música de batalla
  if (battleMusicList) {
    let battleHtml = `
      <button class="music-item ${savedBattleTrack === 'none' ? 'active' : ''}" data-music="none" data-music-type="battle">
        <span class="music-icon">🔇</span>
        <div class="music-info">
          <span class="music-name">Sin música</span>
          <span class="music-desc">Desactivar música de batalla</span>
        </div>
        <span class="playing-indicator">▶</span>
      </button>
    `;
    
    battleTracks.forEach(track => {
      const isActive = savedBattleTrack && track.path && (savedBattleTrack === track.path || savedBattleTrack.toLowerCase() === track.path.toLowerCase());
      const isDefault = defaultBattleSongs.some(def => track.filename.toLowerCase() === def.toLowerCase());
      
      battleHtml += `
        <div class="music-item-wrapper ${isActive ? 'active' : ''}" data-music="${track.path}">
          <button class="music-item ${isActive ? 'active' : ''}" data-music="${track.path}" data-music-type="battle">
            <span class="music-icon">⚔️</span>
            <div class="music-info">
              <span class="music-name">${getSongFriendlyName(track)}</span>
              <span class="music-desc">${track.filename}</span>
            </div>
            <span class="playing-indicator">▶</span>
          </button>
          ${!isDefault ? `<button class="delete-music-btn" data-filename="${track.filename}" title="Eliminar esta canción">🗑️</button>` : ''}
        </div>
      `;
    });
    
    battleMusicList.innerHTML = battleHtml;
    if (noBattleMusicMsg) noBattleMusicMsg.style.display = battleTracks.length === 0 ? 'block' : 'none';
  }
  
  // Añadir event listeners para seleccionar música de menú
  if (menuMusicList) {
    menuMusicList.querySelectorAll('.music-item').forEach(item => {
      item.addEventListener('click', () => {
        const trackPath = item.dataset.music;
        
        // Remover clase active de todos los items de menú
        menuMusicList.querySelectorAll('.music-item, .music-item-wrapper').forEach(el => {
          el.classList.remove('active');
        });
        
        // Añadir clase active al item seleccionado
        item.classList.add('active');
        const wrapper = item.closest('.music-item-wrapper');
        if (wrapper) wrapper.classList.add('active');
        
        // Guardar en localStorage y actualizar
        localStorage.setItem('menuMusicTrack', trackPath);
        selectMusicTrack(trackPath);
      });
    });
  }
  
  // Añadir event listeners para seleccionar música de batalla
  if (battleMusicList) {
    battleMusicList.querySelectorAll('.music-item').forEach(item => {
      item.addEventListener('click', () => {
        const trackPath = item.dataset.music;
        
        // Remover clase active de todos los items de batalla
        battleMusicList.querySelectorAll('.music-item, .music-item-wrapper').forEach(el => {
          el.classList.remove('active');
        });
        
        // Añadir clase active al item seleccionado
        item.classList.add('active');
        const wrapper = item.closest('.music-item-wrapper');
        if (wrapper) wrapper.classList.add('active');
        
        // Guardar en localStorage
        localStorage.setItem('battleMusicTrack', trackPath);
        console.log('[MUSIC] Música de batalla seleccionada:', trackPath);
      });
    });
  }
  
  // Añadir event listeners para eliminar música
  const allDeleteButtons = document.querySelectorAll('.delete-music-btn');
  allDeleteButtons.forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation(); // Evitar que se active el click del item
      
      const filename = btn.dataset.filename;
      const confirmDelete = confirm(`¿Estás seguro de que quieres eliminar "${filename}"?`);
      
      if (confirmDelete) {
        await deleteMusicTrack(filename);
      }
    });
  });
}

// Seleccionar una canción
function selectMusicTrack(trackPath) {
  currentTrack = trackPath;
  localStorage.setItem('musicTrack', trackPath);
  
  // Actualizar UI
  document.querySelectorAll('.music-item').forEach(item => {
    item.classList.remove('active');
  });
  document.querySelector(`[data-music="${trackPath}"]`)?.classList.add('active');
  
  // Reproducir o detener (forzando reinicio al seleccionar manualmente en ajustes)
  if (musicEnabled) {
    if (trackPath === 'none') {
      stopBackgroundMusic();
    } else {
      playBackgroundMusic(trackPath, { forceRestart: true });
    }
  }
}

// Eliminar una canción
async function deleteMusicTrack(filename) {
  if (!isElectron) return;
  
  try {
    console.log('[MUSIC] Eliminando canción:', filename);
    
    const result = await window.kvrcards.deleteMusicTrack(filename);
    
    if (result.ok) {
      console.log('[MUSIC] Canción eliminada exitosamente');
      
      // Si la canción eliminada es la actual, detener música y cambiar a "none"
      if (currentTrack.includes(filename)) {
        stopBackgroundMusic();
        currentTrack = 'none';
        localStorage.setItem('musicTrack', 'none');
      }
      
      // Recargar lista
      await loadMusicTracks();
    } else {
      throw new Error(result.error || 'Error desconocido');
    }
  } catch (error) {
    console.error('[MUSIC] Error eliminando canción:', error);
    alert('❌ Error al eliminar la canción: ' + error.message);
  }
}

// Reproducir música de fondo
function playBackgroundMusic(trackPath, options = {}) {
  if (trackPath === 'none') {
    stopBackgroundMusic();
    currentTrack = 'none';
    return true;
  }

  if (!musicEnabled) {
    stopBackgroundMusic();
    currentTrack = trackPath;
    console.log('[MUSIC] Música desactivada en configuración:', trackPath);
    return false;
  }

  const normalizedTarget = String(trackPath || '').trim().toLowerCase().replace(/^\.\//, '').replace(/^\//, '');
  const normalizedCurrent = String(currentTrack || '').trim().toLowerCase().replace(/^\.\//, '').replace(/^\//, '');
  const currentSrc = backgroundMusic ? String(backgroundMusic.src || '').toLowerCase() : '';

  // Si la misma canción YA se está reproduciendo y no se fuerza reinicio, continuar sin reiniciar
  if (
    !options.forceRestart &&
    backgroundMusic && 
    !backgroundMusic.paused && 
    (normalizedCurrent === normalizedTarget || currentSrc.endsWith(normalizedTarget) || currentSrc.includes(normalizedTarget))
  ) {
    console.log('[MUSIC] Pista idéntica ya en reproducción continua, manteniendo posición:', trackPath);
    return true;
  }

  // Detener música actual si existe
  stopBackgroundMusic();
  
  currentTrack = trackPath;
  console.log('[MUSIC] Intentando reproducir:', trackPath);
  
  try {
    backgroundMusic = new Audio(trackPath);
    backgroundMusic.preload = 'auto';
    backgroundMusic.loop = true;

    // Garantizar reproducción en bucle continuo: si termina completa, reiniciar desde el principio
    backgroundMusic.addEventListener('ended', () => {
      console.log('[MUSIC] 🔁 Canción terminada completa. Reiniciando automáticamente en bucle:', trackPath);
      try {
        backgroundMusic.currentTime = 0;
        const loopPromise = backgroundMusic.play();
        if (loopPromise !== undefined) {
          loopPromise.catch(err => {
            console.warn('[MUSIC] Error al reiniciar canción en bucle:', err);
          });
        }
      } catch (err) {
        console.warn('[MUSIC] Excepción reiniciando en bucle:', err);
      }
    });

    // Calcular volumen suave pero audible
    let calculatedVolume = musicVolume;
    if (typeof options?.volumeMultiplier === 'number') {
      calculatedVolume = musicVolume * options.volumeMultiplier;
    } else if (trackPath === BATTLE_INTRO_TRACK || trackPath.includes('introbatalla.mp3')) {
      calculatedVolume = musicVolume * 0.85;
    } else if (
      trackPath === BATTLE_TRACK || 
      trackPath.includes('battlesong.mp3') ||
      window.__isCustomBattleTrack ||
      (window.battleState?.opponentSong && (trackPath === window.battleState.opponentSong || trackPath.includes(window.battleState.opponentSong)))
    ) {
      calculatedVolume = musicVolume * 0.75;
    }

    backgroundMusic.volume = Math.max(0, Math.min(1, calculatedVolume));
    console.log('[MUSIC] Configurado volumen:', backgroundMusic.volume, '(Base:', musicVolume, ')');

    backgroundMusic.addEventListener('error', (e) => {
      console.error('[MUSIC] ❌ Error de audio al cargar/reproducir:', trackPath, backgroundMusic.error);
      if (window.__isCustomBattleTrack && trackPath !== 'music/battlesong.mp3' && trackPath !== BATTLE_TRACK) {
        console.warn('[MUSIC] ⚠️ Fallo al reproducir música personalizada (offline/infinito). Usando música de batalla estándar.');
        window.__isCustomBattleTrack = false;
        const fallbackTrack = localStorage.getItem('battleMusicTrack') || 'music/battlesong.mp3';
        playBackgroundMusic(fallbackTrack);
      }
    });

    backgroundMusic.addEventListener('playing', () => {
      console.log('[MUSIC] ▶ Sonando audio correctamente:', trackPath, 'Volumen:', backgroundMusic.volume);
    });

    const playPromise = backgroundMusic.play();
    
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          console.log('[MUSIC] ✓ playPromise resuelto para:', trackPath);
          musicReady = true;
          pendingMusicStart = false;
          
          // Ocultar mensaje de status
          const statusEl = document.getElementById('music-status');
          if (statusEl) statusEl.style.display = 'none';
        })
        .catch(e => {
          console.warn('[MUSIC] ⚠ No se pudo reproducir automáticamente:', e.message);
          console.log('[MUSIC] Esperando interacción del usuario...');
          pendingMusicStart = true;
          return false;
        });
    }
    
    return true;
  } catch (e) {
    console.error('[MUSIC] ✗ Error creando audio:', e);
    return false;
  }
}

// Reproducir música/audio de intro de batalla (introbatalla.mp3) como SFX
function playBattleIntroMusic() {
  // Detener música de fondo previa para que no suenen dos cosas a la vez
  stopBackgroundMusic();
  stopBattleIntroMusic();

  if (!sfxEnabled) {
    console.log('[SFX] Efectos de sonido desactivados por usuario, no sonará intro');
    return null;
  }

  try {
    const sfxPath = SFX_PATHS.battleIntro || 'music/introbatalla.mp3';
    battleIntroAudio = new Audio(sfxPath);
    battleIntroAudio.preload = 'auto';
    battleIntroAudio.loop = true;
    battleIntroAudio.volume = Math.max(0, Math.min(1, sfxVolume * 0.9));

    console.log('[SFX] ▶ Reproduciendo intro de batalla con volumen SFX:', battleIntroAudio.volume, '(sfxVolume:', sfxVolume, ')');

    battleIntroAudio.addEventListener('error', (e) => {
      console.error('[SFX] ❌ Error cargando introbatalla:', sfxPath, battleIntroAudio.error);
    });

    const playPromise = battleIntroAudio.play();
    if (playPromise !== undefined) {
      playPromise
        .then(() => {
          console.log('[SFX] ✓ Intro de batalla sonando correctamente');
        })
        .catch(e => {
          console.warn('[SFX] ⚠ Error reproduciendo introbatalla:', e.message);
        });
    }

    return battleIntroAudio;
  } catch (err) {
    console.error('[SFX] ✗ Error creando audio de introbatalla:', err);
    return null;
  }
}

// Detener música de intro de batalla
function stopBattleIntroMusic() {
  if (battleIntroAudio) {
    try {
      battleIntroAudio.pause();
      battleIntroAudio.currentTime = 0;
    } catch {}
    battleIntroAudio = null;
    console.log('[SFX] ■ Intro de batalla detenida');
  }
}

// Detener música de fondo
function stopBackgroundMusic() {
  if (backgroundMusic) {
    backgroundMusic.pause();
    backgroundMusic.currentTime = 0;
    backgroundMusic = null;
  }
}

// Volver a música de fondo del menú (respeta configuración actual del usuario)
function resumeMenuMusic() {
  if (!musicEnabled) {
    stopBackgroundMusic();
    return;
  }

  const savedMenuTrack = localStorage.getItem('menuMusicTrack') || DEFAULT_TRACK;
  if (savedMenuTrack === 'none') {
    stopBackgroundMusic();
    return;
  }

  const normCurrent = String(currentTrack || '').toLowerCase();
  const srcCurrent = backgroundMusic ? String(backgroundMusic.src || '').toLowerCase() : '';
  const isBattleOrIntro = (
    normCurrent.includes('battlesong') || 
    normCurrent.includes('introbatalla') || 
    srcCurrent.includes('battlesong') || 
    srcCurrent.includes('introbatalla') ||
    window.__isCustomBattleTrack ||
    (window.battleState?.opponentSong && (normCurrent === String(window.battleState.opponentSong).toLowerCase() || srcCurrent.includes(String(window.battleState.opponentSong).toLowerCase())))
  );

  window.__isCustomBattleTrack = false;

  // Si ya estamos en el menú y la música del menú ya se está reproduciendo continuamente, NO reiniciar
  if (!isBattleOrIntro && backgroundMusic && !backgroundMusic.paused) {
    console.log('[MUSIC] Música del menú ya se está reproduciendo continuamente, manteniendo reproducción.');
    return;
  }

  playBackgroundMusic(savedMenuTrack);
}

window.playBattleIntroMusic = playBattleIntroMusic;
window.stopBattleIntroMusic = stopBattleIntroMusic;
window.playBackgroundMusic = playBackgroundMusic;
window.stopBackgroundMusic = stopBackgroundMusic;
window.resumeMenuMusic = resumeMenuMusic;

// ===========================
// CLOUD BACKUP & RECOVERY
// ===========================

// Guardar en la nube (Copia de seguridad completa)
async function handleSaveToCloud() {
  if (!currentUser) {
    alert('No hay sesion activa');
    return;
  }
  
  const confirm = window.confirm(
    'Deseas crear una copia de seguridad completa en la nube?\n\n' +
    'Se guardara el 100% de tu progreso:\n' +
    '- Cartas, sobres y mejoras\n' +
    '- Monedas, KvR Coins y Puntos Infinitos\n' +
    '- Rasgos y poderes\n' +
    '- Misiones, entregables y codigos\n' +
    '- Foto de perfil, titulos, fondos y cartas destacadas\n' +
    '- Ajustes y configuracion\n\n' +
    'Podras recuperarlo en cualquier momento o dispositivo iniciando sesion con tu cuenta.'
  );
  
  if (!confirm) return;
  
  console.log('[CLOUD] Guardando copia de seguridad en la nube...');
  
  try {
    const result = await window.kvrcards.cloudUpload(currentUser, currentUserPassword);
    
    if (result.ok) {
      const time = new Date(result.lastSync || Date.now()).toLocaleString('es-ES');
      const lastSyncEl = document.getElementById('last-sync-time');
      if (lastSyncEl) lastSyncEl.textContent = time;
      
      alert('Copia de seguridad guardada correctamente en la nube.\nFecha: ' + time);
    } else {
      alert('Error al guardar en la nube: ' + (result.error || 'Error desconocido'));
    }
  } catch (e) {
    console.error('[CLOUD] Error guardando copia en la nube:', e);
    alert('Error al conectar con el servidor remoto');
  }
}

// Cargar desde la nube
async function handleLoadFromCloud() {
  if (!currentUser) {
    alert('No hay sesion activa');
    return;
  }
  
  try {
    await downloadFromCloud();
  } catch (e) {
    console.error('[CLOUD] Error descargando desde la nube:', e);
    alert('Error al descargar desde la nube: ' + (e.message || 'Error desconocido'));
  }
}

