// ============================================
// SISTEMA DE EVOLUCIONES
// ============================================

var EVOLUTIONS_REMOTE_URL = 'https://hugom1307.github.io/kvrcards-catalog/evolutions.json';
var EVOLUTIONS_CACHE_KEY = 'kvr_evolutions_cache';
var EVOLUTIONS_CACHE_TIME_KEY = 'kvr_evolutions_cache_time';
var EVOLUTIONS_CACHE_DURATION = 10 * 60 * 1000;
var USER_EVOLUTIONS_KEY = 'kvr_user_evolutions_v2'; // Cambiado para evitar conflictos

var availableEvolutions = [];
var userEvolutions = {};
var allCardsCache = [];

function getActiveEvolutionsUsername() {
  if (typeof currentUser === 'string' && currentUser.trim()) {
    return currentUser.trim();
  }
  if (typeof currentUsername === 'string' && currentUsername.trim()) {
    return currentUsername.trim();
  }
  try {
    const raw = localStorage.getItem('kvr_user') || localStorage.getItem('kvr_username') || localStorage.getItem('currentUser');
    if (raw) {
      if (raw.startsWith('{')) {
        const parsed = JSON.parse(raw);
        if (parsed && parsed.username) return parsed.username.trim();
      }
      return raw.trim();
    }
  } catch (e) {}
  return '';
}

function isEvolutionVisibleForUser(evolution, username) {
  if (!evolution || !evolution.visibleOnly) return true;
  const list = Array.isArray(evolution.visibleOnly)
    ? evolution.visibleOnly
    : [evolution.visibleOnly];
  if (list.length === 0) return true;
  const current = (username || getActiveEvolutionsUsername() || '').toLowerCase().trim();
  return list.some(u => String(u).toLowerCase().trim() === current);
}

function getEvolutionRepeatConfig(evolution) {
  if (!evolution) return { isRepeatable: false, maxCompletions: 0 };
  let isRepeatable = false;
  let maxCompletions = 0;

  if (typeof evolution.repeatable === 'number') {
    isRepeatable = true;
    maxCompletions = evolution.repeatable;
  } else if (Boolean(evolution.repeatable)) {
    isRepeatable = true;
    maxCompletions = Number(evolution.maxCompletions) || 0;
  }
  return { isRepeatable, maxCompletions };
}

function getRequiredCardsList(item) {
  if (!item) return [];
  const rawList = item.cardsFrom || item.cardsRequired;
  if (Array.isArray(rawList) && rawList.length > 0) {
    return rawList.map(entry => {
      if (typeof entry === 'string') {
        const trimmed = entry.trim();
        return trimmed ? { id: trimmed, amount: 1 } : null;
      }
      if (entry && typeof entry === 'object') {
        const id = String(entry.id || entry.cardId || entry.cardFrom || '').trim();
        const amount = Number(entry.amount || entry.count || entry.quantity || 1);
        return id ? { id, amount: Math.max(1, amount) } : null;
      }
      return null;
    }).filter(Boolean);
  }
  if (item.cardFrom) {
    const amount = Number(item.cardFromCount || item.count || 1);
    const id = String(item.cardFrom).trim();
    return id ? [{ id, amount: Math.max(1, amount) }] : [];
  }
  return [];
}

function getRewardOptionsList(item, fallbackTo = null) {
  if (!item) return fallbackTo ? [String(fallbackTo).trim()] : [];
  const rawOptions = item.cardToOptions || item.rewardOptions || item.targetCardOptions;
  if (Array.isArray(rawOptions) && rawOptions.length > 0) {
    return rawOptions.map(opt => {
      if (typeof opt === 'string') return opt.trim();
      if (opt && typeof opt === 'object') return String(opt.id || opt.cardId || opt.cardTo || '').trim();
      return null;
    }).filter(Boolean);
  }
  if (item.cardTo) {
    return [String(item.cardTo).trim()];
  }
  if (fallbackTo) {
    return [String(fallbackTo).trim()];
  }
  return [];
}

async function loadEvolutions(force = false) {
  console.log('[EVOLUTIONS] Cargando evoluciones... (force=' + force + ')');
  
  if (!force) {
    const cachedEvolutions = localStorage.getItem(EVOLUTIONS_CACHE_KEY);
    const cachedTime = localStorage.getItem(EVOLUTIONS_CACHE_TIME_KEY);
    
    if (cachedEvolutions && cachedTime) {
      const elapsed = Date.now() - parseInt(cachedTime);
      if (elapsed < EVOLUTIONS_CACHE_DURATION) {
        try {
          const parsed = JSON.parse(cachedEvolutions);
          // IMPORTANTE: Solo usar caché si es un arreglo con elementos
          if (Array.isArray(parsed) && parsed.length > 0) {
            availableEvolutions = parsed;
            window.availableEvolutions = availableEvolutions;
            console.log('[EVOLUTIONS] Cargadas desde caché:', availableEvolutions.length);
            return;
          }
        } catch (e) {
          console.warn('[EVOLUTIONS] Error al parsear caché:', e);
        }
      }
    }
  }
  
  let loaded = false;

  // 1. Intentar a través de Electron IPC
  if (window.kvrcards && typeof window.kvrcards.loadEvolutions === 'function') {
    try {
      console.log('[EVOLUTIONS] Cargando via Electron IPC...');
      const result = await window.kvrcards.loadEvolutions();
      
      if (result && result.ok && Array.isArray(result.evolutions) && result.evolutions.length > 0) {
        availableEvolutions = result.evolutions;
        window.availableEvolutions = availableEvolutions;
        localStorage.setItem(EVOLUTIONS_CACHE_KEY, JSON.stringify(availableEvolutions));
        localStorage.setItem(EVOLUTIONS_CACHE_TIME_KEY, Date.now().toString());
        console.log('[EVOLUTIONS] Cargadas desde Electron IPC:', availableEvolutions.length);
        console.log('[EVOLUTIONS] Evoluciones:', availableEvolutions.map(e => e.id).join(', '));
        loaded = true;
      } else {
        console.warn('[EVOLUTIONS] Electron IPC retornó vacío o error:', result?.error);
      }
    } catch (error) {
      console.warn('[EVOLUTIONS] Error llamando a IPC loadEvolutions:', error);
    }
  }

  // 2. Si IPC no cargó evoluciones o no está disponible, intentar fetch directo desde el navegador
  if (!loaded) {
    const urls = [
      `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/evolutions.json?t=${Date.now()}`,
      `https://hugom1307.github.io/kvrcards-catalog/evolutions.json?t=${Date.now()}`,
      `./game-data/evolutions.json?t=${Date.now()}`
    ];
    for (const url of urls) {
      try {
        console.log('[EVOLUTIONS] Intentando fetch directo a:', url);
        const res = await fetch(url, { cache: 'no-store' });
        if (res.ok) {
          const json = await res.json();
          const list = Array.isArray(json) ? json : (Array.isArray(json?.evolutions) ? json.evolutions : []);
          if (list.length > 0) {
            availableEvolutions = list;
            window.availableEvolutions = availableEvolutions;
            localStorage.setItem(EVOLUTIONS_CACHE_KEY, JSON.stringify(availableEvolutions));
            localStorage.setItem(EVOLUTIONS_CACHE_TIME_KEY, Date.now().toString());
            console.log(`[EVOLUTIONS] Cargadas exitosamente por fetch directo (${url}):`, availableEvolutions.length);
            console.log('[EVOLUTIONS] Evoluciones:', availableEvolutions.map(e => e.id).join(', '));
            loaded = true;
            break;
          }
        }
      } catch (fErr) {
        console.warn('[EVOLUTIONS] Error en fetch directo a ' + url + ':', fErr);
      }
    }
  }

  if (!loaded && availableEvolutions.length === 0) {
    console.error('[EVOLUTIONS] No se pudieron cargar las evoluciones desde ninguna fuente');
  }
}

async function loadUserEvolutionsState() {
  console.log('[EVOLUTIONS] Cargando estado desde archivo...');
  
  try {
    const result = await window.kvrcards.loadEvolutionState();
    console.log('[EVOLUTIONS] Resultado de carga:', result);
    
    if (result.ok && result.data && typeof result.data === 'object' && !Array.isArray(result.data)) {
      userEvolutions = result.data;
      console.log('[EVOLUTIONS] Estado cargado correctamente:', Object.keys(userEvolutions));
    } else {
      console.log('[EVOLUTIONS] No hay estado guardado o es inválido, inicializando vacío');
      userEvolutions = {};
    }
  } catch (error) {
    console.error('[EVOLUTIONS] Error al cargar estado:', error);
    userEvolutions = {};
  }
}

async function saveUserEvolutionsState() {
  console.log('[EVOLUTIONS] Guardando estado:', userEvolutions);
  
  // Verificar que userEvolutions sea un objeto válido
  if (!userEvolutions || typeof userEvolutions !== 'object' || Array.isArray(userEvolutions)) {
    console.error('[EVOLUTIONS] ERROR: userEvolutions no es un objeto válido:', typeof userEvolutions);
    userEvolutions = {};
  }
  
  try {
    const result = await window.kvrcards.saveEvolutionState(userEvolutions);
    if (result.ok) {
      console.log('[EVOLUTIONS] Estado guardado correctamente en archivo');
    } else {
      console.error('[EVOLUTIONS] Error al guardar estado:', result.error);
    }
  } catch (error) {
    console.error('[EVOLUTIONS] Error al guardar estado:', error);
  }
}

function getEvolutionProgress(evolutionId) {
  const progress = userEvolutions[evolutionId];
  return progress || {
    started: false,
    cardId: null,
    cardsConsumed: [],
    targetCardTo: null,
    selectedRewardVariant: null,
    selectedCardOption: null,
    currentPhase: 1,
    totalPhases: 1,
    missionsCompleted: {},
    missionsProgress: {},
    startedAt: null,
    claimedAt: null,
    completionsCount: 0
  };
}

function getEvolutionPhases(evolution, progress = {}) {
  // 1. Si el usuario ya inicio y guardo la opcion elegida con sus propias fases:
  if (progress?.selectedCardOption?.phases && Array.isArray(progress.selectedCardOption.phases) && progress.selectedCardOption.phases.length > 0) {
    return progress.selectedCardOption.phases;
  }

  // 2. Si la opcion elegida tiene misiones propias (fase unica personalizada):
  if (progress?.selectedCardOption?.missions && Array.isArray(progress.selectedCardOption.missions) && progress.selectedCardOption.missions.length > 0) {
    return [{
      phase: 1,
      name: progress.selectedCardOption.name || evolution?.name || 'Fase 1',
      cardFrom: progress.selectedCardOption.cardFrom,
      cardsFrom: progress.selectedCardOption.cardsFrom || progress.selectedCardOption.cardsRequired,
      cardTo: progress.selectedCardOption.cardTo,
      cardToOptions: progress.selectedCardOption.cardToOptions || progress.selectedCardOption.rewardOptions,
      missions: progress.selectedCardOption.missions
    }];
  }

  // 3. Si el usuario ya inicio con un cardId (o selectedCardFrom), buscar en cardOptions si esa carta tiene fases o misiones propias:
  const activeCardId = progress?.selectedCardFrom || progress?.cardId;
  if (activeCardId && Array.isArray(evolution?.cardOptions)) {
    const matchedOpt = evolution.cardOptions.find(opt => {
      if (!opt) return false;
      if (opt.cardFrom === activeCardId || String(opt.cardFrom).toLowerCase() === String(activeCardId).toLowerCase()) return true;
      const reqList = getRequiredCardsList(opt);
      return reqList.some(r => r.id === activeCardId || String(r.id).toLowerCase() === String(activeCardId).toLowerCase());
    });
    if (matchedOpt) {
      if (Array.isArray(matchedOpt.phases) && matchedOpt.phases.length > 0) {
        return matchedOpt.phases;
      }
      if (Array.isArray(matchedOpt.missions) && matchedOpt.missions.length > 0) {
        return [{
          phase: 1,
          name: matchedOpt.name || evolution?.name || 'Fase 1',
          cardFrom: matchedOpt.cardFrom,
          cardsFrom: matchedOpt.cardsFrom || matchedOpt.cardsRequired,
          cardTo: matchedOpt.cardTo,
          cardToOptions: matchedOpt.cardToOptions || matchedOpt.rewardOptions,
          missions: matchedOpt.missions
        }];
      }
    }
  }

  // 4. Fases a nivel raiz de la evolucion (si las hay):
  if (Array.isArray(evolution?.phases) && evolution.phases.length > 0) {
    return evolution.phases;
  }

  // 5. Fallback estandar a nivel raiz:
  return [{
    phase: 1,
    name: evolution?.name || 'Fase 1',
    cardFrom: evolution?.cardFrom,
    cardsFrom: evolution?.cardsFrom || evolution?.cardsRequired,
    cardTo: evolution?.cardTo,
    cardToOptions: evolution?.cardToOptions || evolution?.rewardOptions,
    missions: Array.isArray(evolution?.missions) ? evolution.missions : []
  }];
}

function getCurrentPhaseData(evolution, progress = {}) {
  const phases = getEvolutionPhases(evolution, progress);
  const currentPhaseNum = Math.max(1, Math.min(progress.currentPhase || 1, phases.length));
  const phaseIndex = currentPhaseNum - 1;
  const phase = phases[phaseIndex] || phases[0] || {};

  let requiredCards = getRequiredCardsList(phase);
  if (requiredCards.length === 0) {
    requiredCards = getRequiredCardsList(evolution);
  }
  let rewardOptions = getRewardOptionsList(phase, evolution.cardTo);

  let cardFromId = requiredCards[0]?.id || phase.cardFrom || evolution.cardFrom;
  let cardToId = rewardOptions[0] || phase.cardTo || evolution.cardTo;

  if (progress.started) {
    if (progress.cardId) cardFromId = progress.cardId;
    if (progress.targetCardTo) cardToId = progress.targetCardTo;
    if (progress.selectedRewardVariant) cardToId = progress.selectedRewardVariant;
  } else if (!cardFromId && Array.isArray(evolution.cardOptions) && evolution.cardOptions.length > 0) {
    const firstOpt = evolution.cardOptions[0];
    const optReqs = getRequiredCardsList(firstOpt);
    cardFromId = optReqs[0]?.id || firstOpt.cardFrom;
    const optRewards = getRewardOptionsList(firstOpt);
    if (Array.isArray(firstOpt.phases) && firstOpt.phases.length > 0) {
      cardToId = firstOpt.phases[0].cardTo;
    } else if (firstOpt.phaseRewards && firstOpt.phaseRewards.length > 0) {
      cardToId = firstOpt.phaseRewards[0];
    } else if (optRewards.length > 0) {
      cardToId = optRewards[0];
    } else {
      cardToId = firstOpt.cardTo;
    }
  }

  return {
    phaseIndex,
    phaseNumber: currentPhaseNum,
    totalPhases: phases.length,
    phaseName: phase.name || `Fase ${currentPhaseNum}`,
    cardFrom: cardFromId,
    cardTo: cardToId,
    requiredCards,
    rewardOptions,
    missions: Array.isArray(phase.missions) ? phase.missions : []
  };
}

async function renderEvolutions() {
  console.log('[EVOLUTIONS] Renderizando...');
  
  const featuredContainer = document.getElementById('evolutions-featured');
  const eventContainer = document.getElementById('evolutions-event');
  
  if (!featuredContainer || !eventContainer) return;
  
  featuredContainer.innerHTML = '';
  eventContainer.innerHTML = '';
  
  if (availableEvolutions.length === 0) {
    featuredContainer.innerHTML = '<p class="info-message">No hay evoluciones destacadas disponibles</p>';
    eventContainer.innerHTML = '<p class="info-message">No hay evoluciones de evento disponibles</p>';
    return;
  }
  
  for (const evolution of availableEvolutions) {
    if (!isEvolutionVisibleForUser(evolution)) continue;

    const card = createEvolutionCard(evolution);
    if (!card) continue;

    if (evolution.type === 'featured') {
      featuredContainer.appendChild(card);
    } else if (evolution.type === 'event') {
      eventContainer.appendChild(card);
    }
  }
}

function createEvolutionCard(evolution) {
  if (!isEvolutionVisibleForUser(evolution)) return null;

  const progress = getEvolutionProgress(evolution.id);
  const phaseInfo = getCurrentPhaseData(evolution, progress);

  let cardFromObj = allCardsCache?.find(c => c && (c.id === phaseInfo.cardFrom || String(c.id).toLowerCase() === String(phaseInfo.cardFrom).toLowerCase()));
  let cardToObj = allCardsCache?.find(c => c && (c.id === phaseInfo.cardTo || String(c.id).toLowerCase() === String(phaseInfo.cardTo).toLowerCase()));

  // Fallback si es multi-carta antes de iniciar
  if (!cardFromObj && !progress.started && Array.isArray(evolution.cardOptions)) {
    for (const opt of evolution.cardOptions) {
      const optReqs = getRequiredCardsList(opt);
      const optCardFromId = optReqs[0]?.id || opt.cardFrom;
      const cF = allCardsCache?.find(c => c && (c.id === optCardFromId || String(c.id).toLowerCase() === String(optCardFromId).toLowerCase()));
      if (cF) {
        cardFromObj = cF;
        const targetId = opt.phaseRewards ? opt.phaseRewards[opt.phaseRewards.length - 1] : (getRewardOptionsList(opt)[0] || opt.cardTo);
        cardToObj = allCardsCache?.find(c => c && (c.id === targetId || String(c.id).toLowerCase() === String(targetId).toLowerCase()));
        break;
      }
    }
  }

  const repeatConfig = getEvolutionRepeatConfig(evolution);
  const isRepeatable = repeatConfig.isRepeatable;
  const maxCompletions = repeatConfig.maxCompletions;
  const completionsCount = Number(progress.completionsCount) || 0;
  const isCompletelyFinished = progress.claimedAt && (!isRepeatable || (maxCompletions > 0 && completionsCount >= maxCompletions));

  const totalMissions = phaseInfo.missions.length;
  const completedMissions = phaseInfo.missions.filter(m => progress.missionsCompleted && progress.missionsCompleted[m.id]).length;
  const progressPercent = totalMissions > 0 ? (completedMissions / totalMissions) * 100 : 0;

  let status = 'locked';
  let statusText = 'Bloqueado';
  let buttonText = 'Iniciar Evolución';
  let buttonClass = 'start';
  let buttonDisabled = false;

  if (isCompletelyFinished) {
    status = 'completed';
    statusText = maxCompletions > 0 ? `Completado (${completionsCount}/${maxCompletions})` : 'Completado';
    buttonText = 'Evolución Reclamada';
    buttonDisabled = true;
  } else if (progress.started) {
    status = 'in-progress';
    const isLastPhase = phaseInfo.phaseNumber >= phaseInfo.totalPhases;
    statusText = `En Progreso (${completedMissions}/${totalMissions})`;

    if (completedMissions === totalMissions && totalMissions > 0) {
      status = 'claimable';
      if (isLastPhase) {
        statusText = '¡Listo para Reclamar!';
        buttonText = 'Reclamar Evolución';
      } else {
        statusText = `¡Fase ${phaseInfo.phaseNumber} Completada!`;
        buttonText = `Completar Fase ${phaseInfo.phaseNumber}`;
      }
      buttonClass = 'claim';
    } else {
      buttonText = 'Continuar';
      buttonClass = 'start';
    }
  } else if (completionsCount > 0 && isRepeatable) {
    statusText = maxCompletions > 0 ? `Repetible (${completionsCount}/${maxCompletions})` : `Repetible (${completionsCount} veces)`;
    buttonText = 'Reiniciar Evolución';
  }

  const hasMultiReqs = !progress.started && phaseInfo.requiredCards && phaseInfo.requiredCards.length > 1;
  const hasRewardVariants = !progress.started && phaseInfo.rewardOptions && phaseInfo.rewardOptions.length > 1;

  const card = document.createElement('div');
  card.className = `evolution-card ${status}`;
  card.innerHTML = `
    <div class="evolution-card-header">
      <div class="evolution-badges-container">
        ${phaseInfo.totalPhases > 1 ? `<span class="evolution-phase-badge">Fase ${phaseInfo.phaseNumber}/${phaseInfo.totalPhases}</span>` : ''}
        ${isRepeatable ? `<span class="evolution-repeatable-badge">Repetible ${maxCompletions > 0 ? `(${completionsCount}/${maxCompletions})` : ''}</span>` : ''}
        ${hasMultiReqs ? `<span class="evolution-branch-badge">Requisito Multiple (${phaseInfo.requiredCards.length} cartas)</span>` : ''}
        ${hasRewardVariants ? `<span class="evolution-branch-badge">Recompensa a Elegir (${phaseInfo.rewardOptions.length})</span>` : ''}
        ${Array.isArray(evolution.cardOptions) && evolution.cardOptions.length > 1 ? `<span class="evolution-branch-badge">Opciones Multi-Carta</span>` : ''}
      </div>
      <h4 class="evolution-name">${evolution.name}</h4>
      <p class="evolution-card-name">${progress.started ? (cardFromObj?.name || 'Carta activa') : (hasMultiReqs ? `${phaseInfo.requiredCards.length} cartas requeridas` : (Array.isArray(evolution.cardOptions) ? `${evolution.cardOptions.length} cartas elegibles` : (cardFromObj?.name || phaseInfo.phaseName)))}</p>
    </div>
    
    <div class="evolution-display">
      <div class="evolution-card-preview-wrap">
        ${hasMultiReqs ? `
          <div class="evolution-multicard-stack">
            ${phaseInfo.requiredCards.slice(0, 3).map(req => {
              const cObj = allCardsCache?.find(c => c && (c.id === req.id || String(c.id).toLowerCase() === String(req.id).toLowerCase()));
              return `
                <div class="evolution-multicard-item" title="${cObj?.name || req.id} (x${req.amount})">
                  <img src="${cObj?.imageUrl || './assets/default-card.png'}" class="evolution-multicard-mini-img" alt="${cObj?.name || req.id}">
                  <span class="evolution-mini-count">x${req.amount}</span>
                </div>
              `;
            }).join('')}
            ${phaseInfo.requiredCards.length > 3 ? `<span class="evolution-multicard-more">+${phaseInfo.requiredCards.length - 3}</span>` : ''}
          </div>
          <span class="evolution-mini-label">${phaseInfo.requiredCards.length} cartas requeridas</span>
        ` : `
          <img src="${cardFromObj?.imageUrl || './assets/default-card.png'}" 
               alt="${cardFromObj?.name || 'Carta Base'}" 
               class="evolution-card-img"
               onclick="openLightbox('${cardFromObj?.imageUrl || './assets/default-card.png'}')">
          <span class="evolution-mini-label">${cardFromObj?.name || 'Base'}</span>
        `}
      </div>
      <span class="evolution-arrow">→</span>
      <div class="evolution-card-preview-wrap">
        ${hasRewardVariants ? `
          <div class="evolution-variant-preview-box">
            <img src="${cardToObj?.imageUrl || './assets/default-card.png'}" 
                 alt="${cardToObj?.name || 'Variante'}" 
                 class="evolution-card-img"
                 onclick="openLightbox('${cardToObj?.imageUrl || './assets/default-card.png'}')">
            <div class="evolution-variant-tag">Variante a elegir</div>
          </div>
          <span class="evolution-mini-label">${phaseInfo.rewardOptions.length} opciones disponibles</span>
        ` : `
          <img src="${cardToObj?.imageUrl || './assets/default-card.png'}" 
               alt="${cardToObj?.name || 'Carta Destino'}" 
               class="evolution-card-img"
               onclick="openLightbox('${cardToObj?.imageUrl || './assets/default-card.png'}')">
          <span class="evolution-mini-label">${cardToObj?.name || 'Evolución'}</span>
        `}
      </div>
    </div>
    
    <div class="evolution-status ${status}">${statusText}</div>
    
    ${progress.started && !progress.claimedAt ? `
      <div class="evolution-progress">
        <div class="progress-header">
          <p class="progress-title">${phaseInfo.phaseName} - Misiones</p>
          <span class="progress-count">${completedMissions}/${totalMissions}</span>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width: ${progressPercent}%"></div>
        </div>
      </div>
      
      <div class="evolution-missions">
        ${phaseInfo.missions.map(mission => {
          const targetAmount = mission.target || 
            (Array.isArray(mission.requirements) ? mission.requirements[0]?.amount : null) || 
            (Array.isArray(mission.requirement) ? mission.requirement[0]?.amount : null) || 
            mission.requirement?.amount || 1;
          const missionProgress = progress.missionsProgress?.[mission.id] || { current: 0, target: targetAmount };
          const displayTarget = missionProgress.target || targetAmount;
          const isCompleted = Boolean(progress.missionsCompleted?.[mission.id] || (missionProgress.current || 0) >= displayTarget);
          const progressText = `${Math.min(missionProgress.current || 0, displayTarget)}/${displayTarget}`;
          return `
            <div class="evolution-mission-item">
              <div class="mission-checkbox ${isCompleted ? 'completed' : ''}"></div>
              <span class="mission-text ${isCompleted ? 'completed' : ''}">${mission.description}</span>
              <span class="mission-progress ${isCompleted ? 'completed' : ''}">${progressText}</span>
            </div>
          `;
        }).join('')}
      </div>
    ` : ''}
    
    <div class="evolution-action">
      <button class="evolution-btn ${buttonClass}" 
              data-evolution-id="${evolution.id}"
              ${buttonDisabled ? 'disabled' : ''}>
        ${buttonText}
      </button>
    </div>
  `;
  
  const button = card.querySelector('.evolution-btn');
  button.addEventListener('click', () => handleEvolutionAction(evolution, progress));
  
  return card;
}

async function handleEvolutionAction(evolution, progress) {
  const repeatConfig = getEvolutionRepeatConfig(evolution);
  const isRepeatable = repeatConfig.isRepeatable;
  const maxCompletions = repeatConfig.maxCompletions;
  const completionsCount = Number(progress.completionsCount) || 0;
  const isCompletelyFinished = progress.claimedAt && (!isRepeatable || (maxCompletions > 0 && completionsCount >= maxCompletions));

  if (isCompletelyFinished) return;
  
  const phaseInfo = getCurrentPhaseData(evolution, progress);
  const totalMissions = phaseInfo.missions.length;
  const completedMissions = phaseInfo.missions.filter(m => progress.missionsCompleted && progress.missionsCompleted[m.id]).length;
  
  if (!progress.started) {
    await openCardSelectionModal(evolution);
  } else if (completedMissions === totalMissions && totalMissions > 0) {
    await claimEvolution(evolution, progress);
  } else {
    alert(`Progreso de ${phaseInfo.phaseName}: ${completedMissions}/${totalMissions} misiones completadas.`);
  }
}

function renderDirectEvolutionConfirmation(evolution, cardOption, userCards, modal, inventoryContainer, onBack = null) {
  const reqList = getRequiredCardsList(cardOption || evolution);
  const defaultPhases = getEvolutionPhases(evolution, { selectedCardOption: cardOption });
  const firstPhase = defaultPhases[0] || {};
  
  if (reqList.length === 0) {
    const fId = cardOption?.cardFrom || firstPhase.cardFrom || evolution.cardFrom;
    if (fId) reqList.push({ id: fId, amount: 1 });
  }

  const rewardList = getRewardOptionsList(cardOption || firstPhase, evolution.cardTo);
  if (rewardList.length === 0 && evolution.cardTo) {
    rewardList.push(evolution.cardTo);
  }

  const allReqsMet = reqList.every(r => (userCards[r.id] || 0) >= r.amount);
  let selectedVariant = rewardList.length === 1 ? rewardList[0] : null;

  function renderView() {
    inventoryContainer.innerHTML = `
      <div class="evolution-confirmation-panel" style="width: 100%; display: flex; flex-direction: column; gap: 20px;">
        ${onBack ? `
          <div style="margin-bottom: -10px;">
            <button id="evo-btn-back" class="btn-cancel" style="padding: 6px 14px; font-size: 13px; cursor: pointer; border-radius: 6px; border: 1px solid #475569; background: #1e293b; color: #cbd5e1;">&larr; Volver a opciones</button>
          </div>
        ` : ''}

        <div class="evo-section-reqs">
          <h4 style="color: #f1f5f9; font-size: 16px; margin: 0 0 10px 0; display: flex; align-items: center; justify-content: space-between;">
            <span>Cartas Requeridas para Iniciar</span>
            <span style="font-size: 12px; color: ${allReqsMet ? '#4ade80' : '#f87171'};">${allReqsMet ? 'Requisitos cumplidos' : 'Faltan cartas'}</span>
          </h4>
          <div class="evolution-requirements-checklist">
            ${reqList.map(req => {
              const cardObj = allCardsCache.find(c => c && (c.id === req.id || String(c.id).toLowerCase() === String(req.id).toLowerCase()));
              const ownedCount = userCards[req.id] || 0;
              const isMet = ownedCount >= req.amount;
              return `
                <div class="req-item-card ${isMet ? 'met' : 'missing'}">
                  <img src="${cardObj?.imageUrl || './assets/default-card.png'}" alt="${cardObj?.name || req.id}" class="req-item-img">
                  <div class="req-item-info">
                    <p class="req-item-name">${cardObj?.name || req.id}</p>
                    <p class="req-item-counts">Posees: <strong>${ownedCount}</strong> / Necesitas: <strong>${req.amount}</strong></p>
                    <span class="req-item-status ${isMet ? 'valid' : 'missing'}">${isMet ? '[Completado]' : '[Falta]'}</span>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        ${rewardList.length > 1 ? `
          <div class="evo-section-rewards">
            <h4 style="color: #f1f5f9; font-size: 16px; margin: 0 0 6px 0;">
              Elige tu Recompensa Final (Excluyente)
            </h4>
            <div class="evolution-variant-disclaimer">
              Atencion: Al comenzar la evolucion estas obligado a escoger una de estas variantes, descartando la posibilidad de obtener la otra para esta evolucion.
            </div>
            <div class="evolution-reward-variants-container">
              ${rewardList.map(variantId => {
                const vCard = allCardsCache.find(c => c && (c.id === variantId || String(c.id).toLowerCase() === String(variantId).toLowerCase()));
                const isSelected = selectedVariant === variantId;
                return `
                  <div class="evolution-reward-variant-card ${isSelected ? 'selected' : ''}" data-variant-id="${variantId}">
                    <div class="variant-card-radio">${isSelected ? '●' : '○'}</div>
                    <img src="${vCard?.imageUrl || './assets/default-card.png'}" alt="${vCard?.name || variantId}">
                    <p class="variant-name">${vCard?.name || variantId}</p>
                    <p class="variant-media">Media: ${vCard?.media || vCard?.stats?.media || '??'}</p>
                    <span class="variant-selection-badge">${isSelected ? 'Seleccionada' : 'Click para elegir'}</span>
                  </div>
                `;
              }).join('')}
            </div>
          </div>
        ` : `
          <div class="evo-section-single-reward" style="background: rgba(15, 23, 42, 0.6); padding: 12px 16px; border-radius: 8px; border: 1px solid #334155; display: flex; align-items: center; gap: 15px;">
            ${(() => {
              const rId = rewardList[0];
              const rCard = allCardsCache.find(c => c && (c.id === rId || String(c.id).toLowerCase() === String(rId).toLowerCase()));
              return `
                <img src="${rCard?.imageUrl || './assets/default-card.png'}" style="width: 50px; height: 70px; object-fit: cover; border-radius: 6px;" alt="${rCard?.name || rId}">
                <div>
                  <p style="color: #94a3b8; font-size: 12px; margin: 0;">Recompensa al completar:</p>
                  <p style="color: white; font-weight: 700; font-size: 15px; margin: 3px 0 0 0;">${rCard?.name || rId}</p>
                </div>
              `;
            })()}
          </div>
        `}

        <div class="evo-section-actions" style="display: flex; flex-direction: column; gap: 10px; margin-top: 5px;">
          ${reqList.length > 1 ? `
            <p style="color: #fbbf24; font-size: 12px; margin: 0; text-align: center;">
              Aviso: Al completar la evolucion se eliminaran todas las cartas requeridas consumidas (${reqList.map(r => `${r.amount}x ${allCardsCache.find(c => c.id === r.id)?.name || r.id}`).join(', ')}).
            </p>
          ` : ''}

          <button id="evo-btn-confirm-start" 
                  class="evolution-btn start" 
                  style="width: 100%; padding: 12px; font-size: 15px; font-weight: 700;"
                  ${(!allReqsMet || (rewardList.length > 1 && !selectedVariant)) ? 'disabled' : ''}>
            ${!allReqsMet 
              ? 'No tienes las cartas requeridas' 
              : (rewardList.length > 1 && !selectedVariant 
                ? 'Debes elegir una recompensa' 
                : 'Confirmar e Iniciar Evolucion')}
          </button>
        </div>
      </div>
    `;

    if (onBack) {
      const backBtn = inventoryContainer.querySelector('#evo-btn-back');
      if (backBtn) backBtn.addEventListener('click', onBack);
    }

    if (rewardList.length > 1) {
      inventoryContainer.querySelectorAll('.evolution-reward-variant-card').forEach(vCardEl => {
        vCardEl.addEventListener('click', () => {
          selectedVariant = vCardEl.getAttribute('data-variant-id');
          renderView();
        });
      });
    }

    const startBtn = inventoryContainer.querySelector('#evo-btn-confirm-start');
    if (startBtn && !startBtn.disabled) {
      startBtn.addEventListener('click', () => {
        const primaryCardId = reqList[0]?.id || cardOption?.cardFrom || evolution.cardFrom;
        startEvolution(evolution, primaryCardId, cardOption, false, selectedVariant, reqList);
        modal.style.display = 'none';
      });
    }
  }

  renderView();
}

function renderCardOptionsSelection(evolution, cardOptions, userCards, modal, inventoryContainer) {
  const defaultPhases = getEvolutionPhases(evolution);
  const firstPhase = defaultPhases[0] || {};

  const optionCards = [];
  for (let idx = 0; idx < cardOptions.length; idx++) {
    const opt = cardOptions[idx];
    const reqList = getRequiredCardsList(opt);
    if (reqList.length === 0 && opt.cardFrom) {
      reqList.push({ id: opt.cardFrom, amount: 1 });
    }

    const hasAllReqs = reqList.length > 0 && reqList.every(r => (userCards[r.id] || 0) >= r.amount);
    const primaryId = reqList[0]?.id || opt.cardFrom;
    const baseCard = allCardsCache.find(c => c && (c.id === primaryId || String(c.id).toLowerCase() === String(primaryId).toLowerCase()));

    const optPhases = (Array.isArray(opt.phases) && opt.phases.length > 0)
      ? opt.phases
      : (Array.isArray(opt.missions) && opt.missions.length > 0
        ? [{ phase: 1, name: opt.name || 'Fase 1', cardFrom: opt.cardFrom, cardTo: opt.cardTo, missions: opt.missions }]
        : defaultPhases);

    const rewardOptions = getRewardOptionsList(opt);
    let finalTargetId = rewardOptions[0] || (optPhases.length > 0 ? optPhases[optPhases.length - 1].cardTo : (opt.cardTo || firstPhase.cardTo));
    const targetCard = allCardsCache.find(c => c && (c.id === finalTargetId || String(c.id).toLowerCase() === String(finalTargetId).toLowerCase()));

    optionCards.push({
      optIndex: idx,
      opt,
      reqList,
      hasAllReqs,
      baseCard,
      targetCard,
      rewardOptions,
      totalPhases: optPhases.length || 1
    });
  }

  const anyAvailable = optionCards.some(o => o.hasAllReqs);

  inventoryContainer.innerHTML = `
    <div style="width: 100%; display: flex; flex-direction: column; gap: 15px;">
      <p style="color: #94a3b8; font-size: 13px; margin: 0 0 10px 0; text-align: center;">
        Esta evolucion ofrece diferentes rutas. Selecciona la opcion que deseas desarrollar:
      </p>
      <div class="evolution-card-inventory">
        ${optionCards.map(item => {
          const reqText = item.reqList.map(r => {
            const cObj = allCardsCache.find(c => c && c.id === r.id);
            const owned = userCards[r.id] || 0;
            return `${cObj?.name || r.id} (${owned}/${r.amount})`;
          }).join(', ');

          return `
            <div class="evolution-inventory-card ${item.hasAllReqs ? '' : 'disabled-card'}" 
                 data-option-index="${item.optIndex}"
                 style="${item.hasAllReqs ? '' : 'opacity: 0.55; filter: grayscale(0.6);'}">
              <img src="${item.baseCard?.imageUrl || './assets/default-card.png'}" alt="${item.baseCard?.name || 'Carta'}">
              <p class="inv-card-name" style="color: white; font-weight: 600; margin: 5px 0 2px 0;">${item.baseCard?.name || item.opt.name || 'Opcion'}</p>
              <p class="card-media" style="color: #cbd5e1; font-size: 13px; margin: 2px 0;">Media: ${item.baseCard?.media || item.baseCard?.stats?.media || '??'}</p>
              <p class="card-count" style="color: ${item.hasAllReqs ? '#4ade80' : '#f87171'}; font-size: 11px; margin: 2px 0;">
                ${item.hasAllReqs ? '[Requisitos OK]' : '[Faltan cartas]'}
              </p>
              <p style="color: #94a3b8; font-size: 10px; margin: 2px 0;">${reqText}</p>
              ${item.totalPhases > 1 ? `<span style="display:inline-block; margin-top:4px; font-size:10px; font-weight:bold; color:#a78bfa; background:rgba(139,92,246,0.25); border:1px solid #8b5cf6; padding:2px 8px; border-radius:10px;">${item.totalPhases} Fases</span>` : ''}
              ${item.rewardOptions.length > 1 ? `
                <div class="card-option-reward-preview" style="font-size: 11px; color: #a78bfa; font-weight: 600; margin-top: 4px;">
                  ${item.rewardOptions.length} variantes de recompensa
                </div>
              ` : (item.targetCard ? `
                <div class="card-option-reward-preview" style="font-size: 11px; color: #38bdf8; font-weight: 600; margin-top: 4px;">
                  Evoluciona a:<br>-&gt; ${item.targetCard.name}
                </div>
              ` : '')}
            </div>
          `;
        }).join('')}
      </div>
      ${!anyAvailable ? `
        <div style="background: rgba(239, 68, 68, 0.15); border: 1px solid #ef4444; border-radius: 8px; padding: 12px; text-align: center; color: #fca5a5; font-size: 13px;">
          No posees las cartas requeridas para iniciar ninguna de las opciones disponibles.
        </div>
      ` : ''}
    </div>
  `;

  inventoryContainer.querySelectorAll('.evolution-inventory-card').forEach(cardEl => {
    const optIndex = parseInt(cardEl.getAttribute('data-option-index'), 10);
    const chosenItem = optionCards[optIndex];
    if (!chosenItem || !chosenItem.hasAllReqs) return;

    cardEl.addEventListener('click', () => {
      renderDirectEvolutionConfirmation(
        evolution,
        chosenItem.opt,
        userCards,
        modal,
        inventoryContainer,
        () => renderCardOptionsSelection(evolution, cardOptions, userCards, modal, inventoryContainer)
      );
    });
  });
}

async function openCardSelectionModal(evolution) {
  const modal = document.getElementById('evolution-card-select-modal');
  const inventoryContainer = document.getElementById('evolution-card-inventory');
  const closeBtn = document.getElementById('evolution-select-close');
  
  if (!modal || !inventoryContainer) return;
  
  const inv = await window.kvrcards.getInventory();
  if (!inv || !inv.ok) {
    alert('Error al cargar el inventario');
    return;
  }

  // Si allCardsCache no esta listo, cargarlo
  if (!Array.isArray(allCardsCache) || allCardsCache.length === 0) {
    if (typeof window.kvrcards?.getAllCards === 'function') {
      const raw = await window.kvrcards.getAllCards();
      allCardsCache = Array.isArray(raw) ? raw : (raw?.cards || []);
      window.allCardsCache = allCardsCache;
    }
  }

  const userCards = inv.cards || {};

  // Caso 1: La evolucion tiene cardOptions (rutas distintas)
  if (Array.isArray(evolution.cardOptions) && evolution.cardOptions.length > 0) {
    renderCardOptionsSelection(evolution, evolution.cardOptions, userCards, modal, inventoryContainer);
    modal.style.display = 'flex';
    closeBtn.onclick = () => modal.style.display = 'none';
    modal.onclick = (e) => {
      if (e.target === modal) modal.style.display = 'none';
    };
    return;
  }

  // Caso 2: Evolucion directa
  renderDirectEvolutionConfirmation(evolution, null, userCards, modal, inventoryContainer);
  modal.style.display = 'flex';
  closeBtn.onclick = () => modal.style.display = 'none';
  modal.onclick = (e) => {
    if (e.target === modal) modal.style.display = 'none';
  };
}

function startEvolution(evolution, cardId, cardOption = null, silent = false, selectedRewardVariant = null, requiredCardsList = null) {
  console.log('[EVOLUTIONS] Iniciando evolucion:', evolution.id, 'con carta:', cardId, 'opcion:', cardOption);
  
  if (userEvolutions[evolution.id]?.started && !userEvolutions[evolution.id]?.claimedAt) {
    if (!silent) alert('Ya has iniciado esta evolucion');
    return;
  }

  const phases = getEvolutionPhases(evolution, { selectedCardOption: cardOption, cardId: cardId });
  const firstPhase = phases[0] || {};
  
  // Normalizar lista de cartas requeridas
  let reqs = requiredCardsList;
  if (!reqs || !Array.isArray(reqs) || reqs.length === 0) {
    reqs = getRequiredCardsList(firstPhase);
    if (reqs.length === 0 && cardOption) {
      reqs = getRequiredCardsList(cardOption);
    }
    if (reqs.length === 0) {
      reqs = getRequiredCardsList(evolution);
    }
    if (reqs.length === 0 && cardId) {
      reqs = [{ id: cardId, amount: 1 }];
    }
  }

  // Determinar recompensa final elegida
  const availableRewards = getRewardOptionsList(cardOption || firstPhase, evolution.cardTo);
  let targetCardTo = selectedRewardVariant;
  if (!targetCardTo) {
    if (availableRewards.length > 0) {
      targetCardTo = availableRewards[0];
    } else {
      targetCardTo = firstPhase.cardTo || (cardOption && cardOption.cardTo) || evolution.cardTo;
    }
  }

  const missionsCompleted = {};
  const missionsProgress = {};
  (firstPhase.missions || []).forEach(mission => {
    missionsCompleted[mission.id] = false;
    const targetValue = mission.target || 
      (Array.isArray(mission.requirements) ? mission.requirements[0]?.amount : null) || 
      (Array.isArray(mission.requirement) ? mission.requirement[0]?.amount : null) || 
      mission.requirement?.amount || 1;
    missionsProgress[mission.id] = {
      current: 0,
      target: targetValue,
      completed: false
    };
  });

  const previousCompletions = userEvolutions[evolution.id]?.completionsCount || 0;
  const primaryCardId = cardId || reqs[0]?.id || null;

  const evolutionState = {
    started: true,
    cardId: primaryCardId,
    selectedCardFrom: primaryCardId,
    cardsConsumed: reqs.map(r => ({ id: r.id, amount: r.amount || 1 })),
    targetCardTo: targetCardTo,
    selectedRewardVariant: targetCardTo,
    selectedCardOption: cardOption,
    currentPhase: 1,
    totalPhases: phases.length,
    missionsCompleted: missionsCompleted,
    missionsProgress: missionsProgress,
    startedAt: Date.now(),
    claimedAt: null,
    completionsCount: previousCompletions
  };

  userEvolutions[evolution.id] = evolutionState;
  saveUserEvolutionsState();
  renderEvolutions();
  if (!silent) {
    alert(`Evolucion iniciada. Completa las misiones de ${firstPhase.name || 'la Fase 1'}.`);
  }
}

async function claimEvolution(evolution, progress, silent = false) {
  try {
    const phases = getEvolutionPhases(evolution, progress);
    const currentPhaseNum = progress.currentPhase || 1;
    const currentPhaseIndex = currentPhaseNum - 1;
    const currentPhaseData = phases[currentPhaseIndex] || phases[0];
    const missions = currentPhaseData.missions || [];

    const allCompleted = missions.every(mission => 
      progress.missionsCompleted[mission.id]
    );
    
    if (!allCompleted) {
      alert('Aun no has completado todas las misiones de esta fase');
      return;
    }

    const targetCardId = progress.selectedRewardVariant || progress.targetCardTo || currentPhaseData.cardTo || evolution.cardTo;
    const isFinalPhase = currentPhaseNum >= phases.length;

    // Si es la fase final, eliminamos todas las cartas consumidas y otorgamos la recompensa final
    if (isFinalPhase) {
      const consumedList = Array.isArray(progress.cardsConsumed) && progress.cardsConsumed.length > 0
        ? progress.cardsConsumed
        : (progress.cardId ? [{ id: progress.cardId, amount: 1 }] : []);

      for (const item of consumedList) {
        const cId = typeof item === 'string' ? item : item.id;
        const count = (typeof item === 'object' && item.amount) ? Number(item.amount) : 1;
        for (let i = 0; i < count; i++) {
          try {
            await window.kvrcards.sellCard(cId);
          } catch (delErr) {
            console.warn('[EVOLUTIONS] Error al consumir carta requerida:', cId, delErr);
          }
        }
      }

      const addResult = await window.kvrcards.addCard(targetCardId);
      if (!addResult || !addResult.ok) {
        alert('Error al anadir la carta evolucionada');
        return;
      }
    } else {
      // Fase intermedia
      const removeResult = await window.kvrcards.sellCard(progress.cardId);
      if (!removeResult || !removeResult.ok) {
        alert('Error al actualizar carta de fase');
        return;
      }
      const addResult = await window.kvrcards.addCard(targetCardId);
      if (!addResult || !addResult.ok) {
        alert('Error al anadir la carta de fase');
        return;
      }
    }

    // Notificar al sistema de evoluciones la carta obtenida
    if (typeof window.recordEvolutionCardObtained === 'function') {
      window.recordEvolutionCardObtained(targetCardId, 1);
    }

    // Asegurar que allCardsCache este disponible
    if (!Array.isArray(allCardsCache) || allCardsCache.length === 0) {
      if (typeof window.kvrcards?.getAllCards === 'function') {
        const res = await window.kvrcards.getAllCards();
        allCardsCache = Array.isArray(res) ? res : (Array.isArray(res?.cards) ? res.cards : (res ? Object.values(res) : []));
      }
    }

    const cardTo = (Array.isArray(allCardsCache) ? allCardsCache : []).find(c => c && (c.id === targetCardId || String(c.id).toLowerCase() === String(targetCardId).toLowerCase()));
    const cardToName = cardTo?.name || cardTo?.nombre || 'Carta Evolucionada';
    const cardToImage = cardTo?.imageUrl || cardTo?.image || cardTo?.imagen || '';

    if (!isFinalPhase) {
      // Avanzar a la siguiente fase
      const nextPhaseIndex = currentPhaseNum;
      const nextPhaseData = phases[nextPhaseIndex];
      const nextCardBase = targetCardId;

      let nextTargetCardTo = nextPhaseData.cardTo;
      if (!nextTargetCardTo && progress.selectedCardOption && Array.isArray(progress.selectedCardOption.phaseRewards) && progress.selectedCardOption.phaseRewards[nextPhaseIndex]) {
        nextTargetCardTo = progress.selectedCardOption.phaseRewards[nextPhaseIndex];
      }
      if (!nextTargetCardTo) {
        nextTargetCardTo = evolution.cardTo;
      }

      const nextMissionsCompleted = {};
      const nextMissionsProgress = {};
      (nextPhaseData.missions || []).forEach(mission => {
        nextMissionsCompleted[mission.id] = false;
        const targetValue = mission.target || 
          (Array.isArray(mission.requirements) ? mission.requirements[0]?.amount : null) || 
          (Array.isArray(mission.requirement) ? mission.requirement[0]?.amount : null) || 
          mission.requirement?.amount || 1;
        nextMissionsProgress[mission.id] = {
          current: 0,
          target: targetValue,
          completed: false
        };
      });

      progress.currentPhase = currentPhaseNum + 1;
      progress.cardId = nextCardBase;
      progress.targetCardTo = nextTargetCardTo;
      progress.missionsCompleted = nextMissionsCompleted;
      progress.missionsProgress = nextMissionsProgress;

      saveUserEvolutionsState();
      renderEvolutions();
      if (typeof window.updateGlobalNotificationBadges === 'function') {
        window.updateGlobalNotificationBadges();
      }

      if (!silent) {
        if (typeof window.showUnifiedRewardsHUD === 'function') {
          await window.showUnifiedRewardsHUD([{
            type: 'card',
            cardId: targetCardId,
            id: targetCardId,
            amount: 1,
            name: cardToName,
            imageUrl: cardToImage
          }], `¡FASE ${currentPhaseNum} COMPLETADA!`);
        } else {
          alert(`¡Fase ${currentPhaseNum} completada! Has obtenido: ${cardToName}. ¡Comienza la Fase ${progress.currentPhase}!`);
        }
      }

    } else {
      // Fase final completada
      const repeatConfig = getEvolutionRepeatConfig(evolution);
      const newCompletions = (progress.completionsCount || 0) + 1;
      const canRepeat = repeatConfig.isRepeatable && (!repeatConfig.maxCompletions || newCompletions < repeatConfig.maxCompletions);

      if (canRepeat) {
        userEvolutions[evolution.id] = {
          started: false,
          cardId: null,
          cardsConsumed: [],
          targetCardTo: null,
          selectedRewardVariant: null,
          selectedCardOption: null,
          currentPhase: 1,
          totalPhases: phases.length,
          missionsCompleted: {},
          missionsProgress: {},
          startedAt: null,
          claimedAt: null,
          completionsCount: newCompletions
        };
      } else {
        userEvolutions[evolution.id].claimedAt = Date.now();
        userEvolutions[evolution.id].completionsCount = newCompletions;
        userEvolutions[evolution.id].cardsConsumed = [];
      }

      saveUserEvolutionsState();
      renderEvolutions();
      if (typeof window.updateGlobalNotificationBadges === 'function') {
        window.updateGlobalNotificationBadges();
      }

      if (!silent) {
        if (typeof window.showUnifiedRewardsHUD === 'function') {
          await window.showUnifiedRewardsHUD([{
            type: 'card',
            cardId: targetCardId,
            id: targetCardId,
            amount: 1,
            name: cardToName,
            imageUrl: cardToImage
          }], '¡EVOLUCION COMPLETADA!');
        } else {
          alert(`¡Evolucion completada! Has obtenido: ${cardToName}`);
        }
      }
    }
    
  } catch (error) {
    console.error('[EVOLUTIONS] Error al reclamar:', error);
    if (!silent) alert('Error al reclamar la evolucion');
  }
}

function setupEvolutionCategoryButtons() {
  const buttons = document.querySelectorAll('.evolution-category-btn');
  console.log('[EVOLUTIONS] Configurando botones:', buttons.length);
  
  buttons.forEach(btn => {
    // Clonar el botón para eliminar event listeners previos
    const newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);
    
    newBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      const category = newBtn.getAttribute('data-category');
      console.log('[EVOLUTIONS] Click en categoría:', category);
      
      // Actualizar botones activos
      document.querySelectorAll('.evolution-category-btn').forEach(b => b.classList.remove('active'));
      newBtn.classList.add('active');
      
      // Ocultar todos los contenedores
      document.querySelectorAll('.evolutions-container').forEach(container => {
        container.style.display = 'none';
        container.classList.remove('active');
      });
      
      // Mostrar el contenedor seleccionado
      const targetContainer = document.getElementById(`evolutions-${category}`);
      console.log('[EVOLUTIONS] Mostrando contenedor:', category, targetContainer);
      if (targetContainer) {
        targetContainer.style.display = 'grid';
        targetContainer.classList.add('active');
        console.log('[EVOLUTIONS] Contenedor visible:', targetContainer.style.display);
      }
    });
  });
}

async function checkEvolutionMissions(shouldRender = false) {
  console.log('[EVOLUTIONS] Verificando progreso de misiones...');
  
  if (!availableEvolutions || !Array.isArray(availableEvolutions)) {
    console.log('[EVOLUTIONS] availableEvolutions no está disponible aún');
    return false;
  }
  
  if (typeof userEvolutions === 'undefined' || !userEvolutions) {
    console.log('[EVOLUTIONS] userEvolutions no está disponible aún');
    return false;
  }
  
  let updated = false;
  let progressChanged = false;
  
  for (const evolution of availableEvolutions) {
    if (!isEvolutionVisibleForUser(evolution)) continue;

    const progress = userEvolutions[evolution.id];
    if (!progress || !progress.started || progress.claimedAt) continue;
    
    const currentPhaseData = getCurrentPhaseData(evolution, progress);
    
    if (!progress.missionsProgress) {
      progress.missionsProgress = {};
      updated = true;
    }
    
    for (const mission of currentPhaseData.missions) {
      const target = mission.target || 
        (Array.isArray(mission.requirements) ? mission.requirements[0]?.amount : null) || 
        (Array.isArray(mission.requirement) ? mission.requirement[0]?.amount : null) || 
        mission.requirement?.amount || 1;
      
      // Inicializar progreso si no existe
      if (!progress.missionsProgress[mission.id] || !progress.missionsProgress[mission.id].target) {
        progress.missionsProgress[mission.id] = { current: 0, target: target, completed: false };
        updated = true;
      }
      
      // Actualizar target si cambió
      if (progress.missionsProgress[mission.id].target !== target) {
        progress.missionsProgress[mission.id].target = target;
        updated = true;
      }
      
      // Si ya está completada, continuar
      if (progress.missionsCompleted[mission.id]) {
        progress.missionsProgress[mission.id].completed = true;
        continue;
      }
      
      // Si es un evento manejado en tiempo real, solo verificar si ya alcanzó el target
      const liveEventTypes = [
        'rounds_won', 'card_rounds_won', 'rounds_won_with_filter',
        'play_games_with_card', 'games_played_with_card',
        'win_games_with_card', 'win_games_with_filter',
        'obtain_card', 'duplicate_card'
      ];

      if (liveEventTypes.includes(mission.type)) {
        const curr = progress.missionsProgress[mission.id]?.current || 0;
        if (curr >= target && !progress.missionsCompleted[mission.id]) {
          progress.missionsCompleted[mission.id] = true;
          progress.missionsProgress[mission.id].completed = true;
          updated = true;
          progressChanged = true;
        }
        continue;
      }
      
      // Añadir evolutionId para misiones evaluadas por missions.js
      mission.evolutionId = evolution.id;
      
      const currentProgress = await checkMissionProgress(mission);
      
      if (progress.missionsProgress[mission.id].current !== currentProgress) {
        progress.missionsProgress[mission.id].current = currentProgress;
        updated = true;
        progressChanged = true;
      }
      
      if (currentProgress >= target && !progress.missionsCompleted[mission.id]) {
        console.log(`[EVOLUTIONS] Mision completada: ${mission.description}`);
        progress.missionsCompleted[mission.id] = true;
        progress.missionsProgress[mission.id].completed = true;
        updated = true;
        progressChanged = true;
      }
    }
  }
  
  if (updated) {
    saveUserEvolutionsState();
  }
  
  if (progressChanged && shouldRender) {
    await renderEvolutions();
  }
  
  return updated;
}

// ============================================
// HOOKS Y DISPATCHERS DE EVENTOS EN VIVO
// ============================================

window.recordEvolutionRoundWon = function(playerCard) {
  if (!availableEvolutions || !userEvolutions) return;
  let updated = false;

  for (const evolution of availableEvolutions) {
    if (!isEvolutionVisibleForUser(evolution)) continue;

    const progress = userEvolutions[evolution.id];
    if (!progress || !progress.started || progress.claimedAt) continue;

    const currentPhaseData = getCurrentPhaseData(evolution, progress);
    for (const mission of currentPhaseData.missions) {
      if (progress.missionsCompleted[mission.id]) continue;

      let isMatch = false;
      const mType = mission.type;

      if (mType === 'rounds_won' || mType === 'card_rounds_won') {
        if (mission.cardRequired !== false) {
          const consumedIds = Array.isArray(progress.cardsConsumed)
            ? progress.cardsConsumed.map(c => (typeof c === 'string' ? c : c.id).toLowerCase())
            : [];
          const rawId = (typeof playerCard === 'string' ? playerCard : (playerCard?.id || playerCard?.cardId || playerCard?.uniqueId || playerCard?.uniqueCardId || '')).toLowerCase();
          const baseCleanId = rawId.split('_notrait')[0].split('_trait')[0];
          const baseCardId = (progress.cardId || '').toLowerCase();
          const cardName = (playerCard?.name || playerCard?.nombre || '').toLowerCase();
          const targetName = (evolution.cardName || '').toLowerCase();

          isMatch = Boolean(
            rawId === baseCardId ||
            baseCleanId === baseCardId ||
            consumedIds.includes(rawId) ||
            consumedIds.includes(baseCleanId) ||
            (cardName && targetName && cardName === targetName) ||
            (cardName && baseCardId && cardName === baseCardId)
          );
        } else {
          isMatch = true;
        }
      } else if (mType === 'rounds_won_with_filter') {
        isMatch = true;
        if (mission.origin && playerCard?.origin !== mission.origin && playerCard?.procedencia !== mission.origin) {
          isMatch = false;
        }
        if (mission.owner && playerCard?.owner !== mission.owner && playerCard?.dueno !== mission.owner) {
          isMatch = false;
        }
        if (mission.quality) {
          const cardQuality = (playerCard?.quality || playerCard?.calidad || '').toLowerCase();
          if (cardQuality !== mission.quality.toLowerCase()) isMatch = false;
        }
      }

      if (isMatch) {
        if (!progress.missionsProgress[mission.id]) {
          progress.missionsProgress[mission.id] = { current: 0, target: mission.target || 1, completed: false };
        }
        progress.missionsProgress[mission.id].current = (progress.missionsProgress[mission.id].current || 0) + 1;
        const target = progress.missionsProgress[mission.id].target || mission.target || 1;
        if (progress.missionsProgress[mission.id].current >= target) {
          progress.missionsProgress[mission.id].completed = true;
          progress.missionsCompleted[mission.id] = true;
        }
        updated = true;
        console.log(`[EVOLUTIONS] Ronda ganada sumada a ${evolution.id}.${mission.id}: ${progress.missionsProgress[mission.id].current}/${target}`);
      }
    }
  }

  if (updated) {
    saveUserEvolutionsState();
    if (typeof checkEvolutionMissions === 'function') {
      try { checkEvolutionMissions(false); } catch {}
    }
    const activeTab = document.querySelector('.collectible-tab.active');
    if (activeTab && activeTab.getAttribute('data-tab') === 'evolutions') {
      renderEvolutions();
    }
  }
};

window.recordEvolutionBattleEnded = function(playerTeam, playerWon) {
  if (!availableEvolutions || !userEvolutions) return;
  let updated = false;

  const teamCards = Array.isArray(playerTeam) ? playerTeam : [];

  for (const evolution of availableEvolutions) {
    if (!isEvolutionVisibleForUser(evolution)) continue;

    const progress = userEvolutions[evolution.id];
    if (!progress || !progress.started || progress.claimedAt) continue;

    const currentPhaseData = getCurrentPhaseData(evolution, progress);
    const consumedIds = Array.isArray(progress.cardsConsumed)
      ? progress.cardsConsumed.map(c => (typeof c === 'string' ? c : c.id).toLowerCase())
      : [];
    const baseCardId = (progress.cardId || '').toLowerCase();
    const targetName = (evolution.cardName || '').toLowerCase();

    const hasEvolutionCardInTeam = teamCards.some(c => {
      if (!c) return false;
      const rawId = (typeof c === 'string' ? c : (c.id || c.cardId || c.uniqueId || c.uniqueCardId || '')).toLowerCase();
      const baseCleanId = rawId.split('_notrait')[0].split('_trait')[0];
      const cardName = (c.name || c.nombre || '').toLowerCase();
      return (
        rawId === baseCardId ||
        baseCleanId === baseCardId ||
        consumedIds.includes(rawId) ||
        consumedIds.includes(baseCleanId) ||
        (cardName && targetName && cardName === targetName) ||
        (cardName && baseCardId && cardName === baseCardId)
      );
    });

    for (const mission of currentPhaseData.missions) {
      if (progress.missionsCompleted[mission.id]) continue;

      let isMatch = false;
      const mType = mission.type;

      if (mType === 'play_games_with_card' || mType === 'games_played_with_card') {
        isMatch = hasEvolutionCardInTeam;
      } else if (mType === 'win_games_with_card') {
        isMatch = Boolean(playerWon && hasEvolutionCardInTeam);
      } else if (mType === 'play_games' || mType === 'games_played' || mType === 'battles_played' || mType === 'play_battles') {
        isMatch = (mission.cardRequired === true) ? hasEvolutionCardInTeam : true;
      } else if (mType === 'win_games' || mType === 'battles_won' || mType === 'win_battles') {
        isMatch = Boolean(playerWon && ((mission.cardRequired === true) ? hasEvolutionCardInTeam : true));
      } else if (mType === 'win_games_with_filter') {
        if (playerWon) {
          isMatch = teamCards.some(card => {
            if (!card) return false;
            let match = true;
            if (mission.origin && card.origin !== mission.origin && card.procedencia !== mission.origin) match = false;
            if (mission.owner && card.owner !== mission.owner && card.dueno !== mission.owner) match = false;
            if (mission.quality) {
              const q = (card.quality || card.calidad || '').toLowerCase();
              if (q !== mission.quality.toLowerCase()) match = false;
            }
            return match;
          });
        }
      }

      if (isMatch) {
        if (!progress.missionsProgress[mission.id]) {
          progress.missionsProgress[mission.id] = { current: 0, target: mission.target || 1, completed: false };
        }
        progress.missionsProgress[mission.id].current = (progress.missionsProgress[mission.id].current || 0) + 1;
        const target = progress.missionsProgress[mission.id].target || mission.target || 1;
        if (progress.missionsProgress[mission.id].current >= target) {
          progress.missionsProgress[mission.id].completed = true;
          progress.missionsCompleted[mission.id] = true;
        }
        updated = true;
        console.log(`[EVOLUTIONS] Partida procesada en ${evolution.id}.${mission.id}: ${progress.missionsProgress[mission.id].current}/${target}`);
      }
    }
  }

  if (updated) {
    saveUserEvolutionsState();
    if (typeof checkEvolutionMissions === 'function') {
      try { checkEvolutionMissions(false); } catch {}
    }
    const activeTab = document.querySelector('.collectible-tab.active');
    if (activeTab && activeTab.getAttribute('data-tab') === 'evolutions') {
      renderEvolutions();
    }
  }
};

window.recordEvolutionCardObtained = function(cardId, quantity = 1) {
  if (!availableEvolutions || !userEvolutions || !cardId) return;
  let updated = false;

  for (const evolution of availableEvolutions) {
    if (!isEvolutionVisibleForUser(evolution)) continue;

    const progress = userEvolutions[evolution.id];
    if (!progress || !progress.started || progress.claimedAt) continue;

    const currentPhaseData = getCurrentPhaseData(evolution, progress);
    const consumedIds = Array.isArray(progress.cardsConsumed)
      ? progress.cardsConsumed.map(c => (typeof c === 'string' ? c : c.id).toLowerCase())
      : [];
    const baseCardId = (progress.cardId || '').toLowerCase();
    const incomingId = String(cardId).toLowerCase();

    for (const mission of currentPhaseData.missions) {
      if (progress.missionsCompleted[mission.id]) continue;

      if (mission.type === 'obtain_card' || mission.type === 'duplicate_card') {
        const targetId = (mission.cardId || progress.cardId || '').toLowerCase();
        if (incomingId === targetId || incomingId === baseCardId || consumedIds.includes(incomingId)) {
          if (!progress.missionsProgress[mission.id]) {
            progress.missionsProgress[mission.id] = { current: 0, target: mission.target || 1, completed: false };
          }
          progress.missionsProgress[mission.id].current = (progress.missionsProgress[mission.id].current || 0) + Number(quantity || 1);
          const target = progress.missionsProgress[mission.id].target || mission.target || 1;
          if (progress.missionsProgress[mission.id].current >= target) {
            progress.missionsProgress[mission.id].completed = true;
            progress.missionsCompleted[mission.id] = true;
          }
          updated = true;
          console.log(`[EVOLUTIONS] Carta obtenida sumada a ${evolution.id}.${mission.id}: ${progress.missionsProgress[mission.id].current}/${target}`);
        }
      }
    }
  }

  if (updated) {
    saveUserEvolutionsState();
    const activeTab = document.querySelector('.collectible-tab.active');
    if (activeTab && activeTab.getAttribute('data-tab') === 'evolutions') {
      renderEvolutions();
    }
  }
};

window.recordEvolutionMissionCompleted = function(missionId) {
  if (!availableEvolutions || !userEvolutions || !missionId) return;
  let updated = false;

  for (const evolution of availableEvolutions) {
    if (!isEvolutionVisibleForUser(evolution)) continue;

    const progress = userEvolutions[evolution.id];
    if (!progress || !progress.started || progress.claimedAt) continue;

    const currentPhaseData = getCurrentPhaseData(evolution, progress);
    for (const mission of currentPhaseData.missions) {
      if (progress.missionsCompleted[mission.id]) continue;

      if (mission.type === 'complete_specific_mission') {
        const requiredId = mission.targetMissionId || mission.missionId;
        if (requiredId === missionId) {
          if (!progress.missionsProgress[mission.id]) {
            progress.missionsProgress[mission.id] = { current: 0, target: 1, completed: false };
          }
          progress.missionsProgress[mission.id].current = 1;
          progress.missionsProgress[mission.id].completed = true;
          progress.missionsCompleted[mission.id] = true;
          updated = true;
          console.log(`[EVOLUTIONS] Mision especifica completada en ${evolution.id}.${mission.id}`);
        }
      }
    }
  }

  if (updated) {
    saveUserEvolutionsState();
    const activeTab = document.querySelector('.collectible-tab.active');
    if (activeTab && activeTab.getAttribute('data-tab') === 'evolutions') {
      renderEvolutions();
    }
  }
};

async function initEvolutions(forceReload = false) {
  try {
    if (window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
      const rawCards = await window.kvrcards.getAllCards();
      allCardsCache = Array.isArray(rawCards) ? rawCards : (rawCards?.cards || []);
      window.allCardsCache = allCardsCache;
      console.log('[EVOLUTIONS] Cartas cargadas:', allCardsCache.length);
    }
  } catch (cErr) {
    console.warn('[EVOLUTIONS] Error cargando cartas:', cErr);
  }
  
  await loadEvolutions(forceReload);
  await loadUserEvolutionsState();
  
  // Verificar progreso antes de renderizar
  await checkEvolutionMissions();
  
  await renderEvolutions();
  setupEvolutionCategoryButtons();

  // Conectar botón de recarga manual si existe en el DOM
  const refreshBtn = document.getElementById('refresh-evolutions-btn');
  if (refreshBtn && !refreshBtn.dataset.listenerAttached) {
    refreshBtn.dataset.listenerAttached = 'true';
    refreshBtn.addEventListener('click', async () => {
      refreshBtn.disabled = true;
      refreshBtn.style.opacity = '0.5';
      refreshBtn.style.pointerEvents = 'none';
      try {
        await initEvolutions(true);
      } catch (e) {
        console.error('[EVOLUTIONS] Error al recargar:', e);
      } finally {
        refreshBtn.disabled = false;
        refreshBtn.style.opacity = '1';
        refreshBtn.style.pointerEvents = '';
      }
    });
  }
  
  // Inicializar sistema de traits si está disponible
  try {
    const initTraits = (typeof initTraitsSystem === 'function')
      ? initTraitsSystem
      : (typeof window !== 'undefined' && typeof window.initTraitsSystem === 'function' ? window.initTraitsSystem : null);

    if (initTraits && !window.traitsSystemInitialized) {
      await initTraits();
    }
  } catch (err) {
    console.warn('[EVOLUTIONS] Error opcional inicializando Traits:', err);
  }
}

// Función para contar Evoluciones listas para reclamar o avanzar de fase
function getClaimableEvolutionsCount() {
  let list = Array.isArray(availableEvolutions) && availableEvolutions.length > 0 ? availableEvolutions : null;
  if (!list) {
    try {
      const cached = localStorage.getItem(EVOLUTIONS_CACHE_KEY);
      if (cached) list = JSON.parse(cached);
    } catch {}
  }
  if (!Array.isArray(list)) return 0;
  let uEvos = userEvolutions;
  if (!uEvos || Object.keys(uEvos).length === 0) {
    try {
      const evoUserKey = (typeof currentUser === 'string' && currentUser.trim()) ? `${USER_EVOLUTIONS_KEY}_${currentUser.trim()}` : USER_EVOLUTIONS_KEY;
      const cachedState = localStorage.getItem(evoUserKey) || localStorage.getItem(USER_EVOLUTIONS_KEY);
      if (cachedState) uEvos = JSON.parse(cachedState);
    } catch {}
  }
  uEvos = uEvos || {};

  let count = 0;
  for (const evo of list) {
    if (!evo || !evo.id) continue;
    if (!isEvolutionVisibleForUser(evo)) continue;

    const progress = uEvos[evo.id];
    if (!progress || !progress.started) continue;

    const repeatConfig = getEvolutionRepeatConfig(evo);
    const completionsCount = Number(progress.completionsCount) || 0;
    const isCompletelyFinished = progress.claimedAt && (!repeatConfig.isRepeatable || (repeatConfig.maxCompletions > 0 && completionsCount >= repeatConfig.maxCompletions));
    if (isCompletelyFinished) continue;

    const phaseInfo = getCurrentPhaseData(evo, progress);
    const totalMissions = phaseInfo && phaseInfo.missions ? phaseInfo.missions.length : 0;
    const completedMissions = totalMissions > 0 
      ? phaseInfo.missions.filter(m => progress.missionsCompleted && progress.missionsCompleted[m.id]).length 
      : 0;

    if (totalMissions > 0 && completedMissions === totalMissions) {
      count++;
    }
  }
  return count;
}
window.getClaimableEvolutionsCount = getClaimableEvolutionsCount;

// Exponer funciones y variables clave al scope global
window.availableEvolutions = availableEvolutions;
window.userEvolutions = userEvolutions;
window.allCardsCache = allCardsCache;
window.loadEvolutions = loadEvolutions;
window.loadUserEvolutionsState = loadUserEvolutionsState;
window.saveUserEvolutionsState = saveUserEvolutionsState;
window.getEvolutionPhases = getEvolutionPhases;
window.startEvolution = startEvolution;
window.claimEvolution = claimEvolution;
window.renderEvolutions = renderEvolutions;
window.initEvolutions = initEvolutions;
window.getActiveEvolutionsUsername = getActiveEvolutionsUsername;
window.isEvolutionVisibleForUser = isEvolutionVisibleForUser;
window.getEvolutionRepeatConfig = getEvolutionRepeatConfig;
window.getRequiredCardsList = getRequiredCardsList;
window.getRewardOptionsList = getRewardOptionsList;



