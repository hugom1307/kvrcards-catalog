function filterCardSelector(searchText) {
  const selectorGrid = document.getElementById('card-selector-grid');
  if (!selectorGrid) return;
  
  const items = selectorGrid.querySelectorAll('.card-selector-item');
  const search = searchText.toLowerCase();
  
  items.forEach(item => {
    const card = item._cardData;
    
    if (card) {
      const matchesName = card.name?.toLowerCase().includes(search);
      const matchesClub = card.club?.toLowerCase().includes(search);
      const matchesQuality = card.quality?.toLowerCase().includes(search);
      
      if (matchesName || matchesClub || matchesQuality || !search) {
        item.style.display = '';
      } else {
        item.style.display = 'none';
      }
    }
  });
}

// ==================== RANKINGS ====================
let currentRankingPeriod = 'weekly'; // 'weekly' o 'historical'
let currentRankingCategory = 'cards'; // 'cards', 'packs', 'coins', 'infinite'

const INFINITE_RANKINGS_FALLBACK_URL = 'https://kvrcards-server.onrender.com/api/infinite/rankings';

function getCurrentRankingsUsername() {
  try {
    if (typeof currentUser === 'string' && currentUser.trim()) return currentUser.trim();
  } catch {}

  try {
    const savedUsername = localStorage.getItem('kvrUsername') || localStorage.getItem('userId') || '';
    if (savedUsername.trim()) return savedUsername.trim();
  } catch {}

  return '';
}

async function resolveCurrentUsernameForInfiniteRankings() {
  try {
    if (window.kvrcards && typeof window.kvrcards.getProfile === 'function') {
      const profileResult = await window.kvrcards.getProfile();
      const profileUsername = String(profileResult?.profile?.username || '').trim();
      if (profileUsername) return profileUsername;
    }
  } catch (error) {
    console.warn('[RANKINGS] No se pudo resolver el usuario desde el perfil:', error);
  }

  return getCurrentRankingsUsername();
}

async function fetchInfiniteRankingsOverviewWithFallback(limit = 5) {
  const safeLimit = Math.min(50, Math.max(1, Number(limit) || 5));
  const username = await resolveCurrentUsernameForInfiniteRankings();
  console.log('[RANKINGS] Buscando rankings infinito con limit:', safeLimit, 'usuario:', username);

  try {
    if (window.kvrcards && typeof window.kvrcards.getInfiniteRankingsOverview === 'function') {
      const bridgeResult = await window.kvrcards.getInfiniteRankingsOverview(safeLimit);
      if (bridgeResult && bridgeResult.ok) {
        console.log('[RANKINGS] Bridge exitoso');
        return bridgeResult;
      }
    }
  } catch (error) {
    console.warn('[RANKINGS] Bridge falló, intentando fallback:', error?.message);
  }

  // Fallback directo a API remota
  try {
    const url = new URL(INFINITE_RANKINGS_FALLBACK_URL);
    url.searchParams.set('limit', String(safeLimit));
    if (username) url.searchParams.set('username', username);
    url.searchParams.set('t', String(Date.now()));

    console.log('[RANKINGS] Fallback fetch a:', url.toString());
    const response = await fetch(url.toString(), { cache: 'no-store' });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    console.log('[RANKINGS] Fallback respuesta:', data);
    
    if (data && data.ok) {
      return data;
    }
    
    // Si no es ok pero sigue siendo un objeto válido, returnar con error
    return { 
      ok: false, 
      error: data?.error || 'Respuesta inválida del servidor' 
    };
  } catch (error) {
    console.warn('[RANKINGS] Fallback falló:', error?.message);
    return { 
      ok: false, 
      error: `Fallback falló: ${error?.message || 'Error desconocido'}`
    };
  }
}

function updateRankingsPeriodLabels() {
  const weeklyTab = document.querySelector('.rankings-tab[data-period="weekly"]');
  const historicalTab = document.querySelector('.rankings-tab[data-period="historical"]');

  if (currentRankingCategory === 'infinite') {
    if (weeklyTab) weeklyTab.innerHTML = '<img src="./infinite-cardpoint.png" style="width:16px;height:16px;vertical-align:middle;margin-right:6px;"> Temporada';
    if (historicalTab) historicalTab.textContent = 'Histórico';
    if (weeklyResetTimer) weeklyResetTimer.style.display = 'none';
    stopResetTimer();
    return;
  }

  if (weeklyTab) weeklyTab.textContent = 'Semanal';
  if (historicalTab) historicalTab.textContent = 'Histórico';
}

function renderInfiniteRankings(result) {
  // Renderizado para el modal de Rankings: mantener formato de posicion, nombre y puntuacion
  const isEntryAdmin = (entry) => {
    if (!entry) return false;
    if (entry.isAdmin === true || entry.role === 'admin') return true;
    if (window.currentUserIsAdmin) {
      const u = String(entry.username || '').trim().toLowerCase();
      const current = String(currentUser || window.currentUser || localStorage.getItem('kvrUsername') || '').trim().toLowerCase();
      if (u && current && u === current) return true;
    }
    return false;
  };

  const topSeasonal = (Array.isArray(result?.topSeasonal) ? result.topSeasonal : []).filter(e => !isEntryAdmin(e));
  const topHistorical = (Array.isArray(result?.topHistorical) ? result.topHistorical : []).filter(e => !isEntryAdmin(e));
  const you = result?.you && typeof result.you === 'object' ? result.you : {};
  const season = result?.season && typeof result.season === 'object' ? result.season : {};
  const seasonName = String(season.name || '').trim();
  const isHistoricalView = currentRankingPeriod === 'historical';
  const activeTop = isHistoricalView ? topHistorical : topSeasonal;

  if (!activeTop || activeTop.length === 0) {
    rankingsList.innerHTML = `
      <div class="rankings-empty">
        <div class="rankings-empty-text">No hay datos disponibles</div>
        <div class="rankings-empty-subtext">Sé el primero en aparecer en el ranking</div>
      </div>
    `;
    return;
  }

  const categoryLabel = isHistoricalView ? 'histórico' : 'temporada';

  const html = activeTop.map((entry, idx) => {
    const position = Math.max(1, Number(entry?.rank) || (idx + 1));
    const value = (Number(entry?.score) || Number(entry?.seasonalScore) || Number(entry?.historicalScore) || 0).toLocaleString();

    return `
      <div class="ranking-item ${position <= 3 ? `position-${position}` : ''}" data-username="${String(entry?.username || '').replace(/"/g, '&quot;')}">
        <div class="ranking-position">${position}</div>
        <div class="ranking-user-info">
          <div class="ranking-username">${String(entry?.username || 'Jugador')}</div>
          <div class="ranking-stat-label">${categoryLabel}</div>
        </div>
        <div class="ranking-stat-value">${value}</div>
      </div>
    `;
  }).join('');

  // Cabecera con nombre de temporada (si disponible)
  const headerHtml = seasonName ? `<div class="rankings-season-header">Temporada: ${seasonName}</div>` : '';
  const noteHtml = currentRankingPeriod === 'weekly'
    ? `<div class="infinite-season-note">Nota: Este ranking no se reinicia semanalmente; se reinicia cuando cambie la temporada.</div>`
    : '';

  rankingsList.innerHTML = headerHtml + noteHtml + html;
}

// Cargar y mostrar rankings
async function loadRankings() {
  console.log(`[RANKINGS] Cargando ${currentRankingPeriod} - ${currentRankingCategory}`);
  console.log('[RANKINGS] window.kvrcards.getWeeklyRankings:', typeof window.kvrcards.getWeeklyRankings);
  console.log('[RANKINGS] window.kvrcards.getHistoricalRankings:', typeof window.kvrcards.getHistoricalRankings);
  console.log('[RANKINGS] window.kvrcards.getInfiniteRankingsOverview:', typeof window.kvrcards?.getInfiniteRankingsOverview);
  
  rankingsList.innerHTML = '<div class="rankings-loading">Cargando rankings...</div>';
  
  try {
    let result;
    if (currentRankingCategory === 'infinite') {
      console.log('[RANKINGS] Llamando a getInfiniteRankingsOverview con fallback directo');
      result = await fetchInfiniteRankingsOverviewWithFallback(50);
      console.log('[RANKINGS] getInfiniteRankingsOverview result:', result);
      if (result?.debug) {
        console.log('[RANKINGS] DEBUG INFO:', result.debug);
      }
      if (!result || !result.ok) {
        throw new Error(result?.error || 'Error al cargar rankings de infinito');
      }
      renderInfiniteRankings(result);
      return;
    } else if (currentRankingPeriod === 'weekly') {
      console.log('[RANKINGS] Llamando a getWeeklyRankings con:', currentRankingCategory);
      result = await window.kvrcards.getWeeklyRankings(currentRankingCategory);
      console.log('[RANKINGS] getWeeklyRankings result:', result);
      if (result.debug) {
        console.log('[RANKINGS] DEBUG INFO:', result.debug);
      }
    } else {
      console.log('[RANKINGS] Llamando a getHistoricalRankings con:', currentRankingCategory);
      result = await window.kvrcards.getHistoricalRankings(currentRankingCategory);
      console.log('[RANKINGS] getHistoricalRankings result:', result);
      if (result.debug) {
        console.log('[RANKINGS] DEBUG INFO:', result.debug);
      }
    }
    
    if (!result || !result.ok) {
      throw new Error('Error al cargar rankings');
    }
    
    const rankings = result.rankings || [];
    renderRankings(rankings);
  } catch (error) {
    console.error('[RANKINGS] Error:', error);
    rankingsList.innerHTML = `
      <div class="rankings-empty">
        <div class="rankings-empty-text">Error al cargar rankings</div>
        <div class="rankings-empty-subtext">Inténtalo de nuevo más tarde</div>
      </div>
    `;
  }
}

// Renderizar lista de rankings
function renderRankings(rankings) {
  if (currentRankingCategory === 'infinite') {
    return;
  }

  const isUserAdminEntry = (user) => {
    if (!user) return false;
    if (user.isAdmin === true || user.role === 'admin') return true;
    if (window.currentUserIsAdmin) {
      const u = String(user.username || '').trim().toLowerCase();
      const current = String(currentUser || window.currentUser || localStorage.getItem('kvrUsername') || '').trim().toLowerCase();
      if (u && current && u === current) return true;
    }
    return false;
  };

  const filteredRankings = (Array.isArray(rankings) ? rankings : []).filter(u => !isUserAdminEntry(u));

  if (!filteredRankings || filteredRankings.length === 0) {
    rankingsList.innerHTML = `
      <div class="rankings-empty">
        <div class="rankings-empty-text">No hay datos disponibles</div>
        <div class="rankings-empty-subtext">Sé el primero en aparecer en el ranking</div>
      </div>
    `;
    return;
  }
  
  let categoryLabel = '';
  if (currentRankingCategory === 'cards') categoryLabel = 'cartas';
  else if (currentRankingCategory === 'packs') categoryLabel = 'sobres';
  else if (currentRankingCategory === 'coins') categoryLabel = 'coins';
  
  const html = filteredRankings.map((user, index) => {
    const position = index + 1;
    const positionClass = `position-${position}`;
    
    return `
      <div class="ranking-item ${position <= 3 ? positionClass : ''}" data-username="${user.username}">
        <div class="ranking-position">${position}</div>
        <div class="ranking-user-info">
          <div class="ranking-username">${user.username}</div>
          <div class="ranking-stat-label">${categoryLabel} ${currentRankingPeriod === 'weekly' ? 'esta semana' : 'en total'}</div>
        </div>
        <div class="ranking-stat-value">${user.value.toLocaleString()}</div>
      </div>
    `;
  }).join('');
  
  rankingsList.innerHTML = html;
  
  // Añadir event listeners para abrir perfiles
  document.querySelectorAll('.ranking-item').forEach(item => {
    item.addEventListener('click', () => {
      const username = item.dataset.username;
      console.log('[RANKINGS] Click en perfil:', username);
      openUserProfile(username);
    });
  });
}

// Calcular tiempo hasta el próximo lunes 00:00
function calculateTimeToNextMonday() {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0 = Domingo, 1 = Lunes, etc.
  
  // Calcular próximo lunes
  let daysUntilMonday = (8 - dayOfWeek) % 7;
  if (daysUntilMonday === 0 && (now.getHours() > 0 || now.getMinutes() > 0 || now.getSeconds() > 0)) {
    daysUntilMonday = 7; // Si es lunes pero ya pasó la medianoche, ir al próximo
  }
  
  const nextMonday = new Date(now);
  nextMonday.setDate(now.getDate() + daysUntilMonday);
  nextMonday.setHours(0, 0, 0, 0);
  
  const diff = nextMonday - now;
  
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  
  return { days, hours, minutes, totalMs: diff };
}

// Actualizar contador de reinicio
let resetTimerInterval = null;

function updateResetTimer() {
  const { days, hours, minutes } = calculateTimeToNextMonday();
  
  let text = '';
  if (days > 0) {
    text = `${days}d ${hours}h ${minutes}m`;
  } else if (hours > 0) {
    text = `${hours}h ${minutes}m`;
  } else {
    text = `${minutes}m`;
  }
  
  // Actualizar contador del modal de rankings
  if (resetCountdown) {
    resetCountdown.textContent = text;
  }
}

function startResetTimer() {
  if (resetTimerInterval) clearInterval(resetTimerInterval);
  updateResetTimer();
  resetTimerInterval = setInterval(updateResetTimer, 60000); // Actualizar cada minuto
}

function stopResetTimer() {
  if (resetTimerInterval) {
    clearInterval(resetTimerInterval);
    resetTimerInterval = null;
  }
}

// Abrir perfil de usuario
async function openUserProfile(username) {
  console.log('[PROFILE] Abriendo perfil de:', username);
  
  const modal = document.getElementById('user-profile-modal');
  if (!modal) {
    console.error('[PROFILE] Modal user-profile-modal no encontrado');
    return;
  }

  try {
    let profile = null;
    if (window.kvrcards && typeof window.kvrcards.getUserProfileData === 'function') {
      const result = await window.kvrcards.getUserProfileData(username);
      if (result && result.ok && result.profile) {
        profile = result.profile;
      }
    }
    
    // Fallback remoto si kvrcards falló o estamos en navegador web
    if (!profile) {
      try {
        const res = await fetch(`https://kvrcards-server.onrender.com/api/inventory/${encodeURIComponent(username)}`);
        if (res.ok) {
          const userData = await res.json();
          if (userData) {
            let uniqueCards = 0;
            if (userData.cards) {
              uniqueCards = Object.values(userData.cards).filter(count => count > 0).length;
            }
            profile = {
              username,
              profileImage: userData.profileImage || '',
              currentTitle: userData.currentTitle || '',
              unlockedTitles: Array.isArray(userData.unlockedTitles) ? userData.unlockedTitles : ['novato'],
              currentBackground: userData.currentBackground || userData.settings?.currentBackground || 'default',
              unlockedBackgrounds: (Array.isArray(userData.unlockedBackgrounds) && userData.unlockedBackgrounds.length > 0)
                ? userData.unlockedBackgrounds
                : (Array.isArray(userData.settings?.unlockedBackgrounds) ? userData.settings.unlockedBackgrounds : ['default']),
              stats: {
                totalCardsObtained: (userData.stats?.totalCardsObtained || 0),
                totalPacksOpened: (userData.stats?.totalPacksOpened || 0),
                totalCoinsEarned: (userData.stats?.totalCoinsEarned || 0),
                uniqueCards
              },
              weeklyStats: {
                cards: (userData.weeklyStats?.cards || 0),
                packs: (userData.weeklyStats?.packs || 0),
                coins: (userData.weeklyStats?.coins || 0)
              },
              showcaseCards: userData.showcaseCards || []
            };
          }
        }
      } catch (errFallback) {
        console.warn('[PROFILE] Error en fallback de perfil:', errFallback);
      }
    }

    if (!profile) {
      throw new Error('Error al cargar perfil');
    }
    
    // Actualizar datos del modal
    document.getElementById('profile-modal-username').textContent = profile.username;
    
    // Imagen de perfil
    const avatar = document.getElementById('profile-modal-avatar');
    const placeholder = document.getElementById('profile-modal-avatar-placeholder');
    if (profile.profileImage) {
      avatar.src = profile.profileImage;
      avatar.style.display = 'block';
      placeholder.style.display = 'none';
    } else {
      avatar.style.display = 'none';
      placeholder.style.display = 'flex';
    }
    
    // Título actual
    const titleEl = document.getElementById('profile-modal-title');
    if (profile.currentTitle) {
      titleEl.textContent = `"${profile.currentTitle}"`;
      titleEl.style.display = 'block';
      if (typeof window.applyTitleStyle === 'function') {
        window.applyTitleStyle(titleEl, profile.currentTitle);
      }
    } else {
      titleEl.style.display = 'none';
    }
    
    // Estadísticas
    document.getElementById('profile-stat-cards').textContent = (profile.stats?.totalCardsObtained || 0).toLocaleString();
    document.getElementById('profile-stat-packs').textContent = (profile.stats?.totalPacksOpened || 0).toLocaleString();
    document.getElementById('profile-stat-coins').textContent = (profile.stats?.totalCoinsEarned || 0).toLocaleString();
    document.getElementById('profile-stat-unique').textContent = (profile.stats?.uniqueCards || 0).toLocaleString();
    
    // Stats semanales
    document.getElementById('profile-weekly-cards').textContent = (profile.weeklyStats?.cards || 0).toLocaleString();
    document.getElementById('profile-weekly-packs').textContent = (profile.weeklyStats?.packs || 0).toLocaleString();
    document.getElementById('profile-weekly-coins').textContent = (profile.weeklyStats?.coins || 0).toLocaleString();
    
    // Showcase de cartas (las 3 cartas destacadas del usuario)
    const showcaseGrid = document.getElementById('profile-showcase-grid');
    if (profile.showcaseCards && profile.showcaseCards.length > 0) {
      showcaseGrid.innerHTML = '';
      
      for (let i = 0; i < 3; i++) {
        const card = profile.showcaseCards[i];
        
        if (card && (card.id || card.image)) {
          const cardDiv = document.createElement('div');
          cardDiv.className = 'profile-showcase-card';
          
          const img = document.createElement('img');
          img.src = card.image || '';
          img.alt = card.name || 'Carta';
          img.loading = 'lazy';
          img.onerror = function() {
            this.style.display = 'none';
          };
          
          const nameDiv = document.createElement('div');
          nameDiv.className = 'profile-showcase-card-name';
          nameDiv.textContent = card.name || 'Sin nombre';
          
          const countDiv = document.createElement('div');
          countDiv.className = 'profile-showcase-card-count';
          countDiv.textContent = `x${card.count || 0}`;
          
          cardDiv.appendChild(img);
          cardDiv.appendChild(nameDiv);
          cardDiv.appendChild(countDiv);
          
          showcaseGrid.appendChild(cardDiv);
        } else {
          const emptySlot = document.createElement('div');
          emptySlot.className = 'profile-showcase-empty-slot';
          emptySlot.innerHTML = `
            <div class="profile-showcase-empty-slot-text">Sin carta</div>
          `;
          showcaseGrid.appendChild(emptySlot);
        }
      }
    } else {
      showcaseGrid.innerHTML = `
        <div class="profile-showcase-empty">
          <div>Este usuario aún no ha configurado sus cartas destacadas</div>
        </div>
      `;
    }
    
    // Cargar catálogo de fondos si no está cargado aún
    if (typeof window.loadBackgrounds === 'function' && (!window.availableBackgrounds || window.availableBackgrounds.length <= 1)) {
      await window.loadBackgrounds().catch(() => {});
    }

    // Aplicar fondo de perfil personalizado en el backdrop (a izquierda y derecha del recuadro azul)
    const bgToApply = profile.currentBackground || 'default';
    if (typeof window.applyProfileBackground === 'function') {
      console.log('[PROFILE] Aplicando fondo de perfil de amigo en el backdrop:', bgToApply, 'para usuario:', username);
      window.applyProfileBackground(modal, bgToApply);
    }

    // Aplicar color personalizado del recuadro si el fondo lo define, o mantener su color original
    const userProfileModalContent = modal.querySelector('.user-profile-content');
    if (userProfileModalContent) {
      userProfileModalContent.classList.remove('has-custom-bg');
      if (typeof window.applyProfileBoxStyle === 'function') {
        window.applyProfileBoxStyle(userProfileModalContent, bgToApply);
      } else {
        userProfileModalContent.style.removeProperty('background');
        userProfileModalContent.style.removeProperty('border-color');
        userProfileModalContent.style.removeProperty('box-shadow');
      }
    }
    
    // Mostrar modal
    modal.classList.add('show');
    
  } catch (error) {
    console.error('[PROFILE] Error al cargar perfil:', error);
    alert('Error al cargar el perfil del usuario');
  }
}
window.openUserProfile = openUserProfile;

// Cerrar perfil de usuario
function closeUserProfile() {
  const modal = document.getElementById('user-profile-modal');
  if (modal) {
    modal.classList.remove('show');
    modal.classList.remove('has-custom-bg');
    modal.classList.remove('has-custom-border');
    modal.style.backgroundImage = '';
    const userProfileModalContent = modal.querySelector('.user-profile-content');
    if (userProfileModalContent) {
      userProfileModalContent.classList.remove('has-custom-bg');
      userProfileModalContent.classList.remove('has-custom-border');
      userProfileModalContent.style.backgroundImage = '';
      if (typeof window.applyProfileBoxStyle === 'function') {
        window.applyProfileBoxStyle(userProfileModalContent, 'default');
      }
    }
  }
}
window.closeUserProfile = closeUserProfile;

// Abrir modal de rankings
function openRankingsModal() {
  console.log('[RANKINGS] Abriendo modal, período actual:', currentRankingPeriod);
  rankingsModal.classList.add('show');
  updateRankingsPeriodLabels();
  
  // Mostrar/ocultar contador según período (ANTES de cargar rankings)
  if (currentRankingPeriod === 'weekly' && currentRankingCategory !== 'infinite') {
    console.log('[RANKINGS] Mostrando contador semanal...');
    if (weeklyResetTimer) {
      weeklyResetTimer.style.display = 'block';
      console.log('[RANKINGS] weeklyResetTimer.style.display =', weeklyResetTimer.style.display);
    } else {
      console.error('[RANKINGS] weeklyResetTimer no encontrado!');
    }
    startResetTimer();
  } else {
    console.log('[RANKINGS] Ocultando contador (modo histórico)');
    if (weeklyResetTimer) {
      weeklyResetTimer.style.display = 'none';
    }
    stopResetTimer();
  }
  
  loadRankings();
}

// Cerrar modal de rankings
function closeRankingsModal() {
  rankingsModal.classList.remove('show');
  stopResetTimer();
}

// Cambiar período (semanal/histórico)
function switchRankingPeriod(period) {
  currentRankingPeriod = period;
  updateRankingsPeriodLabels();
  
  // Actualizar UI de tabs
  document.querySelectorAll('.rankings-tab').forEach(tab => {
    if (tab.dataset.period === period) {
      tab.classList.add('active');
    } else {
      tab.classList.remove('active');
    }
  });
  
  // Mostrar/ocultar contador
  if (period === 'weekly' && currentRankingCategory !== 'infinite') {
    weeklyResetTimer.style.display = 'block';
    startResetTimer();
  } else {
    weeklyResetTimer.style.display = 'none';
    stopResetTimer();
  }
  
  loadRankings();
}

// Cambiar categoría (cards/packs/coins)
function switchRankingCategory(category) {
  currentRankingCategory = category;
  if (category === 'infinite') {
    currentRankingPeriod = 'weekly';
  }
  updateRankingsPeriodLabels();
  
  // Actualizar UI de categorías
  document.querySelectorAll('.rankings-category').forEach(btn => {
    if (btn.dataset.category === category) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });
  
  loadRankings();
}

window.loadRankings = loadRankings;
window.switchRankingCategory = switchRankingCategory;
window.switchRankingPeriod = switchRankingPeriod;

