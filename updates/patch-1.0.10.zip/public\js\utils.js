function refreshCardFilterCatalogOptions(cards) {
  const safeCards = Array.isArray(cards) ? cards : [];
  availableProcedencias = [...new Set(
    safeCards
      .map(card => String(card?.procedencia || card?.origen || card?.source || '').trim())
      .filter(Boolean)
  )].sort((a, b) => a.localeCompare(b, 'es', { sensitivity: 'base' }));

  availableOwners = [...new Set(
    safeCards
      .map(card => String(card?.owner || '').trim())
      .filter(Boolean)
  )].sort((a, b) => a.localeCompare(b, 'es', { sensitivity: 'base' }));
}

async function fetchRemoteCardFilterOptions() {
  const now = Date.now();
  const cacheAge = now - remoteFilterOptionsCache.fetchedAt;
  const cacheFresh = remoteFilterOptionsCache.fetchedAt > 0 && cacheAge < (5 * 60 * 1000);

  if (cacheFresh) {
    return {
      procedencias: remoteFilterOptionsCache.procedencias,
      owners: remoteFilterOptionsCache.owners
    };
  }

  if (remoteFilterOptionsCache.pending) {
    return remoteFilterOptionsCache.pending;
  }

  remoteFilterOptionsCache.pending = fetch(`${REMOTE_CATALOG_CARDS_URL}?t=${now}`)
    .then(res => {
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return res.json();
    })
    .then(cards => {
      const safeCards = Array.isArray(cards) ? cards : [];
      const procedencias = [...new Set(
        safeCards
          .map(card => String(card?.procedencia || card?.origen || card?.source || '').trim())
          .filter(Boolean)
      )].sort((a, b) => a.localeCompare(b, 'es', { sensitivity: 'base' }));

      const owners = [...new Set(
        safeCards
          .map(card => String(card?.owner || '').trim())
          .filter(Boolean)
      )].sort((a, b) => a.localeCompare(b, 'es', { sensitivity: 'base' }));

      remoteFilterOptionsCache.fetchedAt = Date.now();
      remoteFilterOptionsCache.procedencias = procedencias;
      remoteFilterOptionsCache.owners = owners;
      return { procedencias, owners };
    })
    .catch(err => {
      console.warn('[FILTERS] No se pudo cargar procedencias/owners desde GitHub:', err?.message || err);
      return {
        procedencias: remoteFilterOptionsCache.procedencias,
        owners: remoteFilterOptionsCache.owners
      };
    })
    .finally(() => {
      remoteFilterOptionsCache.pending = null;
    });

  return remoteFilterOptionsCache.pending;
}

async function syncRemoteFilterOptionsIntoState() {
  const remoteFilterOptions = await fetchRemoteCardFilterOptions();
  if (Array.isArray(remoteFilterOptions?.procedencias) && remoteFilterOptions.procedencias.length > 0) {
    availableProcedencias = remoteFilterOptions.procedencias;
  }
  if (Array.isArray(remoteFilterOptions?.owners) && remoteFilterOptions.owners.length > 0) {
    availableOwners = remoteFilterOptions.owners;
  }
}

// Variables de misiones
let availableMissions = [];
let userMissions = {};
let availableKizunas = [];
let userKizunas = {}; // {missionId: {completed, claimedAt, progress}}

// Variables de Traits
window.selectedTraitCard = window.selectedTraitCard || null;
var selectedTraitCard = window.selectedTraitCard;
window.isTraitRouletteSpinning = window.isTraitRouletteSpinning || false;
var isTraitRouletteSpinning = window.isTraitRouletteSpinning;
const KNOWN_TRAITS_CATALOG = [
  { id: 'ninjutsu1', name: 'Ninjutsu I', rarity: 'common', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/ninjutsu-1.png', effect: { type: 'boost_stat', stat: 'ninjutsu', value: 1 } },
  { id: 'taijutsu1', name: 'Taijutsu I', rarity: 'common', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/taijutsu-1.png', effect: { type: 'boost_stat', stat: 'taijutsu', value: 1 } },
  { id: 'resistencia1', name: 'Resistencia I', rarity: 'common', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/resistencia-1.png', effect: { type: 'boost_stat', stat: 'resistencia', value: 1 } },
  { id: 'velocidad1', name: 'Velocidad I', rarity: 'common', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/velocidad-1.png', effect: { type: 'boost_stat', stat: 'velocidad', value: 1 } },
  { id: 'defensa1', name: 'Defensa I', rarity: 'common', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/defensa-1.png', effect: { type: 'boost_stat', stat: 'defensa', value: 1 } },
  { id: 'fisico1', name: 'Físico I', rarity: 'common', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/fisico-1.png', effect: { type: 'boost_stat', stat: 'fisico', value: 1 } },
  { id: 'ninjutsu2', name: 'Ninjutsu II', rarity: 'rare', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/ninjutsu-2.png', effect: { type: 'boost_stat', stat: 'ninjutsu', value: 2 } },
  { id: 'taijutsu2', name: 'Taijutsu II', rarity: 'rare', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/taijutsu-2.png', effect: { type: 'boost_stat', stat: 'taijutsu', value: 2 } },
  { id: 'resistencia2', name: 'Resistencia II', rarity: 'rare', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/resistencia-2.png', effect: { type: 'boost_stat', stat: 'resistencia', value: 2 } },
  { id: 'velocidad2', name: 'Velocidad II', rarity: 'rare', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/velocidad-2.png', effect: { type: 'boost_stat', stat: 'velocidad', value: 2 } },
  { id: 'defensa2', name: 'Defensa II', rarity: 'rare', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/defensa-2.png', effect: { type: 'boost_stat', stat: 'defensa', value: 2 } },
  { id: 'fisico2', name: 'Físico II', rarity: 'rare', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/fisico-2.png', effect: { type: 'boost_stat', stat: 'fisico', value: 2 } },
  { id: 'ninjutsu3', name: 'Ninjutsu III', rarity: 'epic', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/ninjutsu-3.png', effect: { type: 'boost_stat', stat: 'ninjutsu', value: 3 } },
  { id: 'taijutsu3', name: 'Taijutsu III', rarity: 'epic', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/taijutsu-3.png', effect: { type: 'boost_stat', stat: 'taijutsu', value: 3 } },
  { id: 'resistencia3', name: 'Resistencia III', rarity: 'epic', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/resistencia-3.png', effect: { type: 'boost_stat', stat: 'resistencia', value: 3 } },
  { id: 'velocidad3', name: 'Velocidad III', rarity: 'epic', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/velocidad-3.png', effect: { type: 'boost_stat', stat: 'velocidad', value: 3 } },
  { id: 'defensa3', name: 'Defensa III', rarity: 'epic', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/defensa-3.png', effect: { type: 'boost_stat', stat: 'defensa', value: 3 } },
  { id: 'fisico3', name: 'Físico III', rarity: 'epic', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/fisico-3.png', effect: { type: 'boost_stat', stat: 'fisico', value: 3 } },
  { id: 'mimo', name: 'Mimo', rarity: 'legendary', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/mimo.png', effect: { type: 'special' } },
  { id: 'full_support', name: 'Full Support', rarity: 'legendary', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/full_support.png', effect: { type: 'special' } },
  { id: 'especialista', name: 'Especialista', rarity: 'legendary', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/especialista.png', effect: { type: 'special' } },
  { id: 'support_max', name: 'Support Máximo', rarity: 'mythic', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/support_max.png', effect: { type: 'special' } },
  { id: 'impostor', name: 'Impostor', rarity: 'mythic', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/impostor.png', effect: { type: 'special' } },
  { id: 'monarch', name: 'Monarch', rarity: 'mythic', imageUrl: 'https://hugom1307.github.io/kvrcards-catalog/image/monarch.png', effect: { type: 'special' } }
];
window.KNOWN_TRAITS_CATALOG = KNOWN_TRAITS_CATALOG;

window.getKnownTraitsList = function() {
  return KNOWN_TRAITS_CATALOG.map(t => ({ ...t }));
};

function getTraitById(traitId) {
  if (!traitId) return null;
  const list = (Array.isArray(window.battleState?.availableTraits) && window.battleState.availableTraits.length > 0)
    ? window.battleState.availableTraits
    : (Array.isArray(window.availableTraits) && window.availableTraits.length > 0
        ? window.availableTraits
        : (typeof availableTraits !== 'undefined' && Array.isArray(availableTraits) && availableTraits.length > 0 ? availableTraits : []));
  let found = list.find(t => t && t.id === traitId);
  if (found) return found;

  const fallback = KNOWN_TRAITS_CATALOG.find(t => t.id === traitId);
  return fallback ? { ...fallback } : null;
}
window.getTraitById = getTraitById;

if (!Array.isArray(window.availableTraits) || window.availableTraits.length === 0) {
  window.availableTraits = window.getKnownTraitsList();
}
var availableTraits = window.availableTraits;
window.cardTraitsMap = window.cardTraitsMap || {};
var cardTraitsMap = window.cardTraitsMap;
var activeRouletteTimeout = null;
var activeHideTimeout = null;
const MISSIONS_CACHE_KEY = 'kvrcards_missions_cache';
const MISSIONS_REMOTE_URL = 'https://hugom1307.github.io/kvrcards-catalog/missions.json';
const MISSIONS_CACHE_TIME_KEY = 'kvr_missions_cache_time';
const MISSIONS_CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 horas

const KIZUNAS_REMOTE_URL = 'https://hugom1307.github.io/kvrcards-catalog/kizunas.json';
const KIZUNAS_CACHE_KEY = 'kvr_kizunas_cache';
const KIZUNAS_CACHE_TIME_KEY = 'kvr_kizunas_cache_time';
const KIZUNAS_CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 horas

const DELIVERABLES_REMOTE_URL = 'https://hugom1307.github.io/kvrcards-catalog/entregables.json';
const DELIVERABLES_CACHE_KEY = 'kvr_deliverables_cache';
const DELIVERABLES_CACHE_TIME_KEY = 'kvr_deliverables_cache_time';
const DELIVERABLES_CACHE_DURATION = 24 * 60 * 60 * 1000; // 24 horas

// Control de inicialización para prevenir duplicación de event listeners
let listenersInitialized = false;
async function showPowerActivation(powerType, userName, isPlayer = true) {
  let overlay = document.getElementById('power-activation-overlay');
  
  // Si el overlay no existe en el DOM, crearlo dinámicamente de forma defensiva
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'power-activation-overlay';
    overlay.className = 'power-activation-overlay';
    overlay.innerHTML = `
      <div class="power-activation-bg"></div>
      <div class="power-activation-content">
        <div class="power-activation-lights">
          <div class="power-light"></div>
          <div class="power-light"></div>
        </div>
        <h1 id="power-activation-title" class="power-activation-title"></h1>
        <div id="power-activation-description" class="power-activation-description">
          <h3 id="power-name"></h3>
          <p id="power-desc"></p>
        </div>
        <div class="power-activation-click-hint">Haz click para continuar</div>
      </div>
    `;
    document.body.appendChild(overlay);
  }

  const title = document.getElementById('power-activation-title');
  const powerName = document.getElementById('power-name');
  const powerDesc = document.getElementById('power-desc');
  
  // Normalizar el tipo de poder
  const typeMap = {
    reserva: 'swap',
    reserve_card: 'swap',
    power_up: 'powerup',
    exchange: 'intercambio',
    swap_cards: 'intercambio'
  };
  const normalizedKey = typeMap[powerType] || powerType;
  
  let powerDef = (typeof POWER_DEFINITIONS !== 'undefined' && POWER_DEFINITIONS) ? (POWER_DEFINITIONS[normalizedKey] || POWER_DEFINITIONS[powerType]) : null;
  
  if (!powerDef && Array.isArray(window.availablePowers)) {
    const found = window.availablePowers.find(p => p.id === normalizedKey || p.id === powerType);
    if (found) {
      powerDef = { name: found.name, description: found.description || '' };
    }
  }
  
  if (!powerDef) {
    powerDef = { name: String(powerType || 'PODER').toUpperCase(), description: 'Efecto de poder activado' };
  }
  
  // Reproducir efecto de sonido de activación de poder
  if (typeof playSFX === 'function') {
    playSFX('powerActivate');
  }
  
  // Configurar textos
  const playerText = isPlayer ? (userName || 'TÚ') : (userName || 'OPONENTE');
  if (title) title.textContent = `¡${playerText.toUpperCase()} HA UTILIZADO ${powerDef.name.toUpperCase()}!`;
  if (powerName) powerName.textContent = powerDef.name;
  if (powerDesc) powerDesc.textContent = powerDef.description;
  
  // Mostrar overlay con pointer-events habilitado para capturar clicks
  overlay.style.pointerEvents = 'auto';
  overlay.classList.remove('hiding');
  overlay.classList.add('show');
  
  // Esperar click del usuario para cerrar (con auto-cierre de 2.5 segundos para evitar bloqueos)
  await new Promise(resolve => {
    const timeoutId = setTimeout(function() {
      overlay.removeEventListener('click', handleClick);
      resolve();
    }, 2500);

    function handleClick() {
      clearTimeout(timeoutId);
      overlay.removeEventListener('click', handleClick);
      resolve();
    }
    overlay.addEventListener('click', handleClick);
  });
  
  // Ocultar overlay con animación de salida
  overlay.classList.add('hiding');
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Limpiar clases y deshabilitar pointer-events
  overlay.classList.remove('show', 'hiding');
  overlay.style.pointerEvents = 'none';
}

// Obtener el valor de combate de una stat (calculado de forma segura en memoria, inmune a manipulación del DOM)
function getDisplayedBattleStatValue(side, stat) {
  const card = side === 'player' ? window.battleState?.playerCurrentCard : window.battleState?.opponentCurrentCard;
  if (card && typeof getStatValue === 'function') {
    return getStatValue(card, stat, side);
  }

  const prefix = side === 'player' ? 'battle-player' : 'battle-opponent';

  if (stat === 'media') {
    const mediaEl = document.getElementById(`${prefix}-media`);
    if (!mediaEl) return null;
    const displayedValue = parseInt(mediaEl.textContent, 10);
    return Number.isFinite(displayedValue) ? displayedValue : null;
  }

  const statNames = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
  const statIndex = statNames.indexOf(stat);
  if (statIndex === -1) return null;

  const statEl = document.getElementById(`${prefix}-stat${statIndex + 1}`);
  if (!statEl) return null;

  // textContent incluye etiquetas como (+1), parseInt recupera el valor principal mostrado
  const displayedValue = parseInt(statEl.textContent, 10);
  return Number.isFinite(displayedValue) ? displayedValue : null;
}

const sections = {
  collection: document.querySelector('.collection'),
  packs: document.querySelector('.packs'),
  shop: document.querySelector('.shop'),
  missions: document.querySelector('.missions'),
};
function coinIcon(amount) {
  return `<span class="cur cur-coins"><img class="currency-icon" src="./coin.png" alt="Coins" /> ${amount}</span>`;
}
function kvrIcon(amount) {
  return `<span class="cur cur-kvr"><img class="currency-icon" src="./kvr.png" alt="KvR" /> ${amount}</span>`;
}

function normalizeAssetUrl(url) {
  if (!url || typeof url !== 'string') return url;
  return url.replace(/^https?:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/main\/(.*)$/i, 'https://$1.github.io/$2/$3');
}
window.normalizeAssetUrl = normalizeAssetUrl;

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
window.escapeHtml = escapeHtml;

function isSpecialQuality(qualityNameOrId) {
  if (!qualityNameOrId) return false;
  const qStr = String(qualityNameOrId).trim().toLowerCase();
  const normalize = (s) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\s\-_]/g, '');
  const qNorm = normalize(qStr);

  const qualitiesList = window.appQualities || window.appQualitiesCache || [];
  if (Array.isArray(qualitiesList) && qualitiesList.length > 0) {
    const qObj = qualitiesList.find(q => {
      const idNorm = normalize(String(q.id || ''));
      const nameNorm = normalize(String(q.name || q.nombre || ''));
      return idNorm === qNorm || nameNorm === qNorm;
    });
    if (qObj) {
      return Boolean(qObj.special ?? qObj.especial);
    }
  }

  // Fallback seguro de calidades especiales reconocidas
  const knownSpecials = ['heroe', 'icono', 'iconoprime', 'iconosuperprime', 'evo'];
  return knownSpecials.includes(qNorm);
}
window.isSpecialQuality = isSpecialQuality;

function isCardSpecialQuality(card) {
  if (!card) return false;
  return isSpecialQuality(card.calidad) || isSpecialQuality(card.quality) || isSpecialQuality(card.calidadId);
}
window.isCardSpecialQuality = isCardSpecialQuality;

// Regex para emojis estándar y secuencias compuestas (Unicode 11+)
const TITLE_EMOJI_REGEX = /(?:\p{Extended_Pictographic}|\p{Emoji_Presentation})(?:(?:\uFE0F|\uFE0E)|(?:\uD83C[\uDFFB-\uDFFF])|(?:\u200D(?:\p{Extended_Pictographic}|\p{Emoji_Presentation}))*)*/gu;

/**
 * Formatea un título aplicando el gradiente únicamente al texto alfanumérico/símbolos normales,
 * mientras que los emojis se aíslan en spans neutros para conservar sus colores originales.
 */
function formatTitleWithGradient(rawText, gradient) {
  if (!rawText) return '';
  const text = String(rawText);
  if (!gradient) {
    return escapeHtml(text);
  }

  let result = '';
  let lastIndex = 0;
  let match;
  TITLE_EMOJI_REGEX.lastIndex = 0;

  const gradStyle = `background-image:${gradient};-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent;`;

  while ((match = TITLE_EMOJI_REGEX.exec(text)) !== null) {
    const textPart = text.slice(lastIndex, match.index);
    if (textPart) {
      result += `<span class="title-gradient-text" style="${gradStyle}">${escapeHtml(textPart)}</span>`;
    }
    result += `<span class="title-emoji">${match[0]}</span>`;
    lastIndex = TITLE_EMOJI_REGEX.lastIndex;
  }

  if (lastIndex < text.length) {
    const textPart = text.slice(lastIndex);
    result += `<span class="title-gradient-text" style="${gradStyle}">${escapeHtml(textPart)}</span>`;
  }

  return result;
}
window.formatTitleWithGradient = formatTitleWithGradient;
window.TITLE_EMOJI_REGEX = TITLE_EMOJI_REGEX;

/**
 * Limpia el formato de un título: elimina prefijos ("Título:", "Titulo:"),
 * emojis y comillas, dejando únicamente el nombre limpio del título.
 */
function stripTitleFormatting(rawText) {
  if (!rawText) return '';
  let str = String(rawText);
  str = str.replace(/^(?:🏆|🃏|🎖️|🥇|🥈|🥉|\s)*(?:título|titulo)\s*:\s*/i, '');
  TITLE_EMOJI_REGEX.lastIndex = 0;
  str = str.replace(TITLE_EMOJI_REGEX, '');
  str = str.replace(/^["'«»“”]+|["'«»“”]+$/g, '');
  return str.trim();
}
window.stripTitleFormatting = stripTitleFormatting;
