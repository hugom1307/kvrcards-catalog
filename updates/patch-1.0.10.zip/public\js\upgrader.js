/**
 * ==================== UPGRADER "MEJORÁMELA" GAME SYSTEM ====================
 * Modular client-side controller for the KVRCards Upgrader Gambling Mode.
 * Features fullscreen superposed inventory selectors, cubic balance curve,
 * and card mutation rewards.
 */

(function () {
  let selectedSacrifices = [];
  let selectedTarget = null;
  
  // Temporary selector variables (UX refinement)
  let selectorType = "sacrifice"; // "sacrifice" or "target"
  let tempSelectedSacrifices = [];
  let tempSelectedTarget = null;
  let activeFilteredList = [];
  let itemsRendered = 24;
  
  let userInventory = null;
  let allCardsCatalog = [];
  let cardMap = new Map();
  let availableTraits = [];
  let cardTraitsMap = {};
  let cardUpgradesMap = {};
  
  // Animation state
  let spinAnimationId = null;
  let currentWheelAngle = 0;
  
  // DOM element selections
  let modalEl = null;
  let selectorModalEl = null;
  let canvasEl = null;
  let ctx = null;

  // Base64 encoded SVGs to completely prevent Electron/Chromium inline data URI parsing crashes and infinite loops
  const FALLBACK_100x140_BASE64 = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAiIGhlaWdodD0iMTQwIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjMWYyOTM3Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGRvbWluYW50LWJhc2VsaW5lPSJtaWRkbGUiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZpbGw9IiM5Y2EzYWYiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxMCI+U2luIGltYWdlbjwvdGV4dD48L3N2Zz4=";
  const FALLBACK_60x84_BASE64 = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2MCIgaGVpZ2h0PSI4NCI+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0iIzExMSIvPjwvc3ZnPg==";

  function getCardImageUrl(card, isMicro = false) {
    if (card) {
      const url = card.imageUrl || card.imagen || card.imagen_url || card.image || "";
      if (url) return url;
    }
    return isMicro ? FALLBACK_60x84_BASE64 : FALLBACK_100x140_BASE64;
  }

  // Web Audio API Synthesis Engine
  let audioCtx = null;
  
  function getAudioContext() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  }

  function playSynthTickSound() {
    try {
      const ctx = getAudioContext();
      if (!ctx || ctx.state === 'suspended') return;
      
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(150, ctx.currentTime);
      
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);
      
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.05);
    } catch (e) {
      console.warn("[UPGRADER AUDIO] Error playing synth tick:", e);
    }
  }

  function playSynthSuccessSound() {
    try {
      const ctx = getAudioContext();
      if (!ctx || ctx.state === 'suspended') return;
      
      const now = ctx.currentTime;
      const notes = [440, 554, 659, 880];
      const noteDuration = 0.08;
      
      notes.forEach((freq, index) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + index * noteDuration);
        
        const noteStart = now + index * noteDuration;
        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.12, noteStart + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDuration - 0.01);
        
        osc.start(noteStart);
        osc.stop(noteStart + noteDuration);
      });
    } catch (e) {
      console.warn("[UPGRADER AUDIO] Error playing synth success:", e);
    }
  }

  function playSynthSuperSuccessSparkle() {
    try {
      const ctx = getAudioContext();
      if (!ctx || ctx.state === 'suspended') return;
      
      const now = ctx.currentTime;
      const notes = [880, 1109, 1318, 1760];
      const noteDuration = 0.06;
      
      notes.forEach((freq, index) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + index * noteDuration);
        
        const noteStart = now + index * noteDuration;
        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(0.10, noteStart + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + noteDuration - 0.01);
        
        osc.start(noteStart);
        osc.stop(noteStart + noteDuration);
      });
    } catch (e) {
      console.warn("[UPGRADER AUDIO] Error playing synth super success sparkle:", e);
    }
  }

  function playSynthFailureSound() {
    try {
      const ctx = getAudioContext();
      if (!ctx || ctx.state === 'suspended') return;
      
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();
      
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.exponentialRampToValueAtTime(80, now + 0.5);
      
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800, now);
      filter.frequency.exponentialRampToValueAtTime(100, now + 0.5);
      
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
      
      osc.start(now);
      osc.stop(now + 0.5);
    } catch (e) {
      console.warn("[UPGRADER AUDIO] Error playing synth failure:", e);
    }
  }

  // Direct asynchronous vivo fetch to remote inventory-server database
  async function fetchServerInventory() {
    let baseUrl = "";
    if (window.kvrcards && typeof window.kvrcards.getInventoryServerInfo === 'function') {
      try {
        const info = await window.kvrcards.getInventoryServerInfo();
        if (info && info.ok && info.effectiveBaseUrl) {
          baseUrl = info.effectiveBaseUrl.endsWith('/') ? info.effectiveBaseUrl.slice(0, -1) : info.effectiveBaseUrl;
        }
      } catch (e) {
        baseUrl = "http://localhost:4321";
      }
    } else {
      baseUrl = "http://localhost:4321";
    }
    
    console.log("[UPGRADER] Obteniendo inventario real time directamente de la base de datos distribuida:", `${baseUrl}/api/inventory/${currentUser}`);
    
    const response = await fetch(`${baseUrl}/api/inventory/${currentUser}`);
    if (!response.ok) {
      throw new Error(`Fallo del servidor de base de datos: ${response.status}`);
    }
    
    const data = await response.json();
    
    // Normalizar la respuesta garantizando consistencia de mapas y la bandera 'ok: true'
    return {
      ok: true,
      cards: data.cards || {},
      packs: data.packs || {},
      cardTraits: data.cardTraits || {},
      cardUpgrades: data.cardUpgrades || {},
      wallet: data.wallet || { coins: 0, kvr: 0 }
    };
  }

  window.openUpgraderModal = async function () {
    if (!currentUser) {
      alert("Debes iniciar sesión para poder usar el Upgrader.");
      return;
    }
    
    // Initialize Web Audio API on user interaction thread
    getAudioContext();
    
    // Cache DOM Elements
    modalEl = document.getElementById("gambling-upgrader-modal");
    selectorModalEl = document.getElementById("upgrader-selector-modal");
    canvasEl = document.getElementById("upgrader-roulette-canvas");
    if (canvasEl) {
      ctx = canvasEl.getContext("2d");
    }
    
    // Bind high-performance paginated scrolling on selector grid
    const grid = document.getElementById("upgrader-selector-grid");
    if (grid && !grid.dataset.scrollListenerSet) {
      grid.dataset.scrollListenerSet = "true";
      grid.addEventListener("scroll", () => {
        // Detect near-bottom of scrolling container
        if (grid.scrollTop + grid.clientHeight >= grid.scrollHeight - 150) {
          if (itemsRendered < activeFilteredList.length) {
            const nextStart = itemsRendered;
            itemsRendered += 24;
            const nextSlice = activeFilteredList.slice(nextStart, itemsRendered);
            nextSlice.forEach(item => {
              const el = createCardDOMElement(item);
              if (el) grid.appendChild(el);
            });
            console.log("[UPGRADER] Lazy loaded next 24 elements. Total rendered:", itemsRendered);
          }
        }
      });
    }
    
    // Reset state
    selectedSacrifices = [];
    selectedTarget = null;
    currentWheelAngle = 0;
    
    // Hide standard gambling panel for deep immersion
    const gamblingPanel = document.getElementById("gambling-panel");
    if (gamblingPanel) gamblingPanel.style.display = "none";
    
    // Show Modal
    if (modalEl) {
      modalEl.classList.add("active");
      const existingOverlays = modalEl.querySelectorAll('.upgrader-overlay, .flash-burst');
      existingOverlays.forEach(el => el.remove());
    }
    
    try {
      // Fetch Inventory & Catalog
      const [allCards, inv] = await Promise.all([
        window.kvrcards.getAllCards(),
        fetchServerInventory()
      ]);
      
      let normalizedCards = [];
      if (Array.isArray(allCards)) {
        normalizedCards = allCards;
      } else if (allCards && allCards.ok && Array.isArray(allCards.cards)) {
        normalizedCards = allCards.cards;
      } else if (allCards && Array.isArray(allCards.data)) {
        normalizedCards = allCards.data;
      }
      allCardsCatalog = normalizedCards;
      cardMap = new Map(allCardsCatalog.map(c => [c.id, c]));
      userInventory = inv;
      
      cardTraitsMap = inv.cardTraits || {};
      cardUpgradesMap = inv.cardUpgrades || {};
      
      if (window.kvrcards && typeof window.kvrcards.getAllTraits === 'function') {
        availableTraits = await window.kvrcards.getAllTraits().catch(() => []);
      }
      
      // Render Initial State
      clearUpgraderTarget();
      renderSelectedSacrificesThumbnails();
      updateUpgraderProbabilities();

      if (window.DiscordPresence) {
        window.DiscordPresence.setGambling('Mejoramela');
      }
      
    } catch (err) {
      console.error("[UPGRADER] Error al abrir el modal:", err);
      alert("Error al cargar el inventario de cartas.");
      closeUpgraderModal();
    }
  };

  window.closeUpgraderModal = function () {
    if (spinAnimationId) {
      cancelAnimationFrame(spinAnimationId);
      spinAnimationId = null;
    }
    
    if (modalEl) {
      modalEl.classList.remove("active");
    }
    
    // Hide selector sub-modal too if open
    closeInventorySelector();
    
    // Restore background gambling panel
    const gamblingPanel = document.getElementById("gambling-panel");
    if (gamblingPanel) gamblingPanel.style.display = "block";

    if (window.DiscordPresence) {
      window.DiscordPresence.setGambling('Seleccion de Juego');
    }
  };
  
  // Helper to fetch details of a card including upgrades/traits
  function getCardDetail(instanceIdOrCardId) {
    let cardId = instanceIdOrCardId;
    let bonus = 0;
    let trait = null;
    
    if (cardTraitsMap[instanceIdOrCardId]) {
      cardId = cardTraitsMap[instanceIdOrCardId].cardId;
      const traitId = cardTraitsMap[instanceIdOrCardId].traitId;
      trait = availableTraits.find(t => t.id === traitId);
    }
    
    if (cardUpgradesMap[instanceIdOrCardId]) {
      cardId = cardUpgradesMap[instanceIdOrCardId].cardId;
      bonus = Number(cardUpgradesMap[instanceIdOrCardId].mediaBonus) || 0;
    }
    
    if (instanceIdOrCardId.includes('_') && !cardTraitsMap[instanceIdOrCardId] && !cardUpgradesMap[instanceIdOrCardId]) {
      // If the full string is a valid base card, use it
      if (cardMap.has(instanceIdOrCardId)) {
        cardId = instanceIdOrCardId;
      } else {
        // Otherwise, split by the last underscore to remove the instance suffix
        const lastIndex = instanceIdOrCardId.lastIndexOf('_');
        if (lastIndex !== -1) {
          const possibleCardId = instanceIdOrCardId.substring(0, lastIndex);
          if (cardMap.has(possibleCardId)) {
            cardId = possibleCardId;
          } else {
            // Fallback to splitting by first underscore if all else fails
            cardId = instanceIdOrCardId.split('_')[0];
          }
        }
      }
    }
    
    const baseCard = cardMap.get(cardId);
    if (!baseCard) return null;
    
    const media = (Number(baseCard.media) || Number(baseCard.mediaVal) || 75) + bonus;
    const name = baseCard.name || baseCard.nombre || "Carta KVR";
    const imageUrl = baseCard.imageUrl || baseCard.imagen || baseCard.imagen_url || baseCard.image || "";
    
    return {
      ...baseCard,
      id: baseCard.id || cardId,
      instanceId: instanceIdOrCardId,
      name: name,
      imageUrl: imageUrl,
      media: media,
      bonus: bonus,
      trait: trait
  };
  }

  // ==================== LARGE SELECTION MODAL LOGIC ====================

  window.openInventorySelector = function (type) {
    getAudioContext();
    selectorType = type;
    
    const selectorTitle = document.getElementById("upgrader-selector-title");
    const searchInput = document.getElementById("upgrader-selector-search");
    
    if (searchInput) searchInput.value = "";
    
    if (type === "sacrifice") {
      selectorTitle.textContent = "Seleccionar Cartas de Sacrificio";
      // Clone selections to temp array
      tempSelectedSacrifices = [...selectedSacrifices];
      tempSelectedTarget = selectedTarget;
    } else {
      selectorTitle.textContent = "Seleccionar Carta a Mejorar";
      tempSelectedTarget = selectedTarget;
      tempSelectedSacrifices = [...selectedSacrifices];
    }
    
    if (selectorModalEl) {
      selectorModalEl.style.display = "flex";
      renderSelectorGrid();
    }
  };

  window.closeInventorySelector = function () {
    if (selectorModalEl) {
      selectorModalEl.style.display = "none";
    }
  };

  // Compile list of all selectable inventory items (both standard and unique instances)
  function getSelectableInventoryList() {
    const counts = userInventory && userInventory.ok ? userInventory.cards : {};
    const entries = Object.entries(counts).filter(([id, count]) => count > 0);
    const list = [];
    
    // Group traits by cardId
    const traitsByCard = {};
    for (const [instanceId, data] of Object.entries(cardTraitsMap)) {
      if (data && data.cardId) {
        if (!traitsByCard[data.cardId]) traitsByCard[data.cardId] = [];
        traitsByCard[data.cardId].push(instanceId);
      } else if (typeof data === 'string') {
        let cardId = instanceId;
        if (instanceId.includes('_')) {
          const parts = instanceId.split('_');
          if (parts.length >= 3 && !isNaN(parts[parts.length - 1]) && !isNaN(parts[parts.length - 2])) {
            cardId = parts.slice(0, -2).join('_');
          }
        }
        if (!traitsByCard[cardId]) traitsByCard[cardId] = [];
        traitsByCard[cardId].push(instanceId);
      }
    }
    
    // Group upgrades by cardId
    const upgradesByCard = {};
    for (const [instanceId, data] of Object.entries(cardUpgradesMap)) {
      if (data && data.cardId) {
        if (!upgradesByCard[data.cardId]) upgradesByCard[data.cardId] = [];
        if (!traitsByCard[data.cardId]?.includes(instanceId)) {
          upgradesByCard[data.cardId].push(instanceId);
        }
      }
    }
    
    entries.forEach(([id, count]) => {
      const baseCard = cardMap.get(id);
      if (!baseCard) return;
      
      const traitsForCard = (traitsByCard[id] || []).slice(0, count);
      const upgradesForCard = upgradesByCard[id] || [];
      
      // Unique traits instances
      traitsForCard.forEach(instId => {
        list.push({ instanceId: instId, cardId: id, isInstance: true });
      });
      
      // Unique upgrades instances
      upgradesForCard.forEach(instId => {
        list.push({ instanceId: instId, cardId: id, isInstance: true });
      });
      
      // Standard copies count
      const totalInstances = traitsForCard.length + upgradesForCard.length;
      const standardCount = Math.max(0, count - totalInstances);
      
      if (standardCount > 0) {
        // We push individual selectable units, keeping track of their total standard quantity
        list.push({ instanceId: id, cardId: id, isInstance: false, count: standardCount });
      }
    });
    
    return list;
  }

  function createCardDOMElement(item) {
    const cardDetail = getCardDetail(item.instanceId);
    if (!cardDetail) return null;
    
    const div = document.createElement("div");
    div.className = "selector-card-item";
    div.setAttribute("data-instance-id", item.instanceId);
    
    let isChosen = false;
    let isLocked = false;
    let currentlyChosen = 0;
    
    if (selectorType === "sacrifice") {
      div.classList.add("sacrifice-type");
      currentlyChosen = tempSelectedSacrifices.filter(sac => sac === item.instanceId).length;
      isChosen = currentlyChosen > 0;
      isLocked = tempSelectedTarget === item.instanceId;
    } else {
      isChosen = tempSelectedTarget === item.instanceId;
      isLocked = tempSelectedSacrifices.includes(item.instanceId);
    }
    
    if (isChosen) div.classList.add("chosen-in-selector");
    if (isLocked) div.classList.add("locked-in-selector");
    
    // Stacking checkmark text indicator
    let indicatorText = "";
    if (isChosen) {
      if (selectorType === "sacrifice" && currentlyChosen > 1) {
        indicatorText = `x${currentlyChosen}`;
      } else {
        indicatorText = "✓";
      }
    }
    
    // Render standard counts label and checks
    let displayCount = "";
    if (!item.isInstance && item.count > 1) {
      let availableCount = item.count;
      if (selectorType === "sacrifice") {
        availableCount = item.count - currentlyChosen;
        if (availableCount <= 0 && !isChosen) {
          div.classList.add("locked-in-selector");
        }
      }
      displayCount = `<div class="selector-card-count">x${availableCount}</div>`;
    }
    
    let badgesMarkup = "";
    if (cardDetail.bonus > 0) {
      badgesMarkup += `<div class="selector-card-badge">+${cardDetail.bonus}</div>`;
    }
    if (cardDetail.trait) {
      badgesMarkup += `<div class="selector-card-badge-trait">${cardDetail.trait.name.slice(0,5)}</div>`;
    }
    
    div.innerHTML = `
      ${badgesMarkup}
      <div class="selector-check-indicator">${indicatorText}</div>
      <img src="${getCardImageUrl(cardDetail)}" onerror="this.onerror=null; this.src='${FALLBACK_100x140_BASE64}';">
      <div class="selector-card-name" title="${cardDetail.name}">${cardDetail.name}</div>
      <div class="selector-card-media">Media: ${cardDetail.media}</div>
      ${displayCount}
    `;
    
    if (!isLocked) {
      div.addEventListener("click", () => {
        handleSelectorClick(item.instanceId, item.isInstance, item.count);
      });
    }
    
    return div;
  }

  function updateCardDOMNodeDirectly(instanceId, totalCount, isInstance) {
    const div = document.querySelector(`.selector-card-item[data-instance-id="${instanceId}"]`);
    if (!div) return;
    
    let isChosen = false;
    let currentlyChosen = 0;
    
    if (selectorType === "sacrifice") {
      currentlyChosen = tempSelectedSacrifices.filter(sac => sac === instanceId).length;
      isChosen = currentlyChosen > 0;
    } else {
      isChosen = tempSelectedTarget === instanceId;
    }
    
    if (isChosen) {
      div.classList.add("chosen-in-selector");
    } else {
      div.classList.remove("chosen-in-selector");
    }
    
    // Update check indicator dynamically in HTML
    const indicator = div.querySelector(".selector-check-indicator");
    if (indicator) {
      if (isChosen) {
        indicator.textContent = (selectorType === "sacrifice" && currentlyChosen > 1) ? `x${currentlyChosen}` : "✓";
      } else {
        indicator.textContent = "";
      }
    }
    
    // Update standard counts label
    if (!isInstance && totalCount > 1) {
      const countLabel = div.querySelector(".selector-card-count");
      if (countLabel) {
        let availableCount = totalCount;
        if (selectorType === "sacrifice") {
          availableCount = totalCount - currentlyChosen;
        }
        countLabel.textContent = `x${availableCount}`;
      }
    }
    
    // Update Chosen count badge
    const chosenCount = selectorType === "sacrifice" ? tempSelectedSacrifices.length : (tempSelectedTarget ? 1 : 0);
    document.getElementById("upgrader-selector-chosen-count").textContent = chosenCount;
  }

  window.renderSelectorGrid = function () {
    const grid = document.getElementById("upgrader-selector-grid");
    if (!grid) return;
    
    grid.innerHTML = "";
    
    const list = getSelectableInventoryList();
    const query = document.getElementById("upgrader-selector-search")?.value.trim().toLowerCase() || "";
    
    activeFilteredList = list.filter(item => {
      const card = cardMap.get(item.cardId);
      return card && card.name.toLowerCase().includes(query);
    });
    
    // Sort descendingly by Media, and secondarily alphabetically A-Z by Name
    activeFilteredList.sort((a, b) => {
      const cardA = getCardDetail(a.instanceId);
      const cardB = getCardDetail(b.instanceId);
      const mediaA = cardA ? (cardA.media || 0) : 0;
      const mediaB = cardB ? (cardB.media || 0) : 0;
      
      if (mediaB !== mediaA) {
        return mediaB - mediaA;
      }
      
      const nameA = cardA ? (cardA.name || "").toLowerCase() : "";
      const nameB = cardB ? (cardB.name || "").toLowerCase() : "";
      return nameA.localeCompare(nameB);
    });
    
    // Update Available count badge
    document.getElementById("upgrader-selector-avail-count").textContent = activeFilteredList.length;
    
    if (activeFilteredList.length === 0) {
      grid.innerHTML = '<div style="grid-column: span 5; text-align: center; color: rgba(255,255,255,0.3); padding: 50px 0; font-size: 13px;">No se encontraron cartas que coincidan en tu inventario.</div>';
      return;
    }
    
    // Update Chosen count badge
    const chosenCount = selectorType === "sacrifice" ? tempSelectedSacrifices.length : (tempSelectedTarget ? 1 : 0);
    document.getElementById("upgrader-selector-chosen-count").textContent = chosenCount;
    
    // Reset pages for lazy scroll
    itemsRendered = 24;
    const visibleSlice = activeFilteredList.slice(0, itemsRendered);
    
    visibleSlice.forEach(item => {
      const el = createCardDOMElement(item);
      if (el) grid.appendChild(el);
    });
  };
  
  window.filterSelectorInventory = function () {
    renderSelectorGrid();
  };

  function handleSelectorClick(instanceId, isInstance, totalCount) {
    getAudioContext();
    if (selectorType === "sacrifice") {
      const currentlyChosen = tempSelectedSacrifices.filter(sac => sac === instanceId).length;
      const limit = tempSelectedTarget === instanceId ? (totalCount - 1) : totalCount;
      
      if (currentlyChosen < limit) {
        tempSelectedSacrifices.push(instanceId);
      } else {
        // Reset to 0 copies
        tempSelectedSacrifices = tempSelectedSacrifices.filter(sac => sac !== instanceId);
      }
      
      // Dynamic inline updates (No lag or visual resets)
      updateCardDOMNodeDirectly(instanceId, totalCount, isInstance);
    } else {
      const prevTarget = tempSelectedTarget;
      
      if (tempSelectedTarget === instanceId) {
        tempSelectedTarget = null;
      } else {
        tempSelectedTarget = instanceId;
      }
      
      updateCardDOMNodeDirectly(instanceId, totalCount, isInstance);
      if (prevTarget && prevTarget !== instanceId) {
        updateCardDOMNodeDirectly(prevTarget, totalCount, isInstance);
      }
    }
  }

  window.confirmInventorySelection = function () {
    getAudioContext();
    if (selectorType === "sacrifice") {
      selectedSacrifices = [...tempSelectedSacrifices];
    } else {
      selectedTarget = tempSelectedTarget;
      
      // Update Target Slot view immediately
      if (selectedTarget) {
        renderSelectedTargetSlot();
      } else {
        clearUpgraderTarget();
      }
    }
    
    closeInventorySelector();
    
    // Update main visuals
    renderSelectedSacrificesThumbnails();
    updateUpgraderProbabilities();
  };

  // ==================== MAIN PANEL DISPLAYS ====================

  function renderSelectedSacrificesThumbnails() {
    const grid = document.getElementById("upgrader-sacrifice-thumbnails");
    if (!grid) return;
    
    grid.innerHTML = "";
    
    if (selectedSacrifices.length === 0) {
      grid.innerHTML = '<div class="thumbnails-placeholder">No hay cartas seleccionadas para el sacrificio. Pulsa el botón superior para agregar cartas.</div>';
      document.getElementById("upgrader-selected-sac-count").textContent = "0";
      return;
    }
    
    selectedSacrifices.forEach((sacId, index) => {
      const cardDetail = getCardDetail(sacId);
      if (!cardDetail) return;
      
      const div = document.createElement("div");
      div.className = "upgrader-micro-thumbnail";
      
      div.innerHTML = `
        <div class="upgrader-micro-badge" onclick="removeSingleSacrifice(${index}, event)">&times;</div>
        <img src="${getCardImageUrl(cardDetail, true)}" onerror="this.onerror=null; this.src='${FALLBACK_60x84_BASE64}';">
        <div class="upgrader-micro-name" title="${cardDetail.name}">${cardDetail.name}</div>
        <div class="upgrader-micro-media">${cardDetail.media}</div>
      `;
      
      grid.appendChild(div);
    });
    
    document.getElementById("upgrader-selected-sac-count").textContent = selectedSacrifices.length;
  }

  // Elite UX detail: allows removing single cards instantly from panel view
  window.removeSingleSacrifice = function (index, event) {
    if (event) event.stopPropagation(); // Avoid triggering parent clicks
    
    selectedSacrifices.splice(index, 1);
    
    renderSelectedSacrificesThumbnails();
    updateUpgraderProbabilities();
  };

  function renderSelectedTargetSlot() {
    const slot = document.getElementById("upgrader-target-card-slot");
    const cardDetail = getCardDetail(selectedTarget);
    
    if (slot && cardDetail) {
      let badgesMarkup = "";
      if (cardDetail.bonus > 0) {
        badgesMarkup += `<div class="selector-card-badge">+${cardDetail.bonus}</div>`;
      }
      if (cardDetail.trait) {
        badgesMarkup += `<div class="selector-card-badge-trait">${cardDetail.trait.name.slice(0,5)}</div>`;
      }
      
      slot.innerHTML = `
        <div class="upgrader-target-card-display">
          ${badgesMarkup}
          <img src="${getCardImageUrl(cardDetail)}" onerror="this.onerror=null; this.src='${FALLBACK_100x140_BASE64}';">
          <div class="upgrader-target-card-info">
            <div class="upgrader-target-card-name">${cardDetail.name}</div>
            <div class="upgrader-target-card-media">Media: ${cardDetail.media}</div>
          </div>
        </div>
      `;
      
      document.getElementById("upgrader-change-target-btn-container").style.display = "flex";
    }
  }

  window.clearUpgraderTarget = function () {
    selectedTarget = null;
    
    const slot = document.getElementById("upgrader-target-card-slot");
    if (slot) {
      slot.innerHTML = `
        <div class="slot-placeholder">
          <span class="slot-plus">+</span>
          <span class="slot-text">Seleccionar Carta a Mejorar</span>
        </div>
      `;
    }
    
    document.getElementById("upgrader-change-target-btn-container").style.display = "none";
    updateUpgraderProbabilities();
  };

  // ==================== MATHEMATICAL CURVE ALGORITHM ====================

  function updateUpgraderProbabilities() {
    let successChance = 0;
    
    if (selectedTarget && selectedSacrifices.length > 0) {
      const targetDetail = getCardDetail(selectedTarget);
      if (targetDetail) {
        const targetRating = targetDetail.media || 75;
        
        // DIFICULTAD INVERSA: f(Rt) = max(0.05, 1 - 0.05 * max(0, Rt - 70))
        const diffMultiplier = Math.max(0.05, 1 - 0.05 * Math.max(0, targetRating - 70));
        
        let sumChance = 0;
        
        selectedSacrifices.forEach(sacId => {
          const sacDetail = getCardDetail(sacId);
          if (sacDetail) {
            const sacRating = sacDetail.media || 75;
            
            // CUBIC CURVE: C = 15 * (sacRating / targetRating)^3
            let contribution = 15 * Math.pow(sacRating / targetRating, 3);
            
            // LOW-TIER SACRIFICE NERF: cards <= 75 get penalized by 90%
            if (sacRating <= 75) {
              contribution = contribution * 0.1;
            }
            
            // APLICAR MULTIPLICADOR DE DIFICULTAD INVERSA POR MEDIA
            contribution = contribution * diffMultiplier;
            
            sumChance += contribution;
          }
        });
        
        successChance = Math.min(95, parseFloat(sumChance.toFixed(1)));
      }
    }
    
    // Update display values
    document.getElementById("upgrader-percent-val").textContent = `${successChance}%`;
    document.getElementById("upgrader-chance-val").textContent = `${successChance}%`;
    
    // Toggle start button
    const startBtn = document.getElementById("upgrader-start-btn");
    if (startBtn) {
      startBtn.disabled = !(selectedTarget && selectedSacrifices.length > 0);
    }
    
    // Redraw wheel canvas
    drawRouletteWheel(successChance, currentWheelAngle);
  }

  // Draw Roulette Wheel Canvas
  function drawRouletteWheel(successChance, rotationAngleRad) {
    if (!canvasEl || !ctx) return;
    
    const width = canvasEl.width;
    const height = canvasEl.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = centerX - 10;
    
    ctx.clearRect(0, 0, width, height);
    
    // 1. Success Arc (Green Segment)
    const successRatio = successChance / 100;
    const successAngleRad = successRatio * Math.PI * 2;
    
    const startAngle = rotationAngleRad - Math.PI / 2;
    const dividerAngle = startAngle + successAngleRad;
    const endAngle = startAngle + Math.PI * 2;
    
    // Green success segment
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.arc(centerX, centerY, radius, startAngle, dividerAngle, false);
    ctx.closePath();
    
    const greenGrad = ctx.createRadialGradient(centerX, centerY, 50, centerX, centerY, radius);
    greenGrad.addColorStop(0, '#10b981');
    greenGrad.addColorStop(1, '#047857');
    ctx.fillStyle = greenGrad;
    ctx.fill();
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = "rgba(16, 185, 129, 0.4)";
    ctx.stroke();
    
    // 2. Failure Arc (Red Segment)
    if (successChance < 100) {
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.arc(centerX, centerY, radius, dividerAngle, endAngle, false);
      ctx.closePath();
      
      const redGrad = ctx.createRadialGradient(centerX, centerY, 50, centerX, centerY, radius);
      redGrad.addColorStop(0, '#ef4444');
      redGrad.addColorStop(1, '#991b1b');
      ctx.fillStyle = redGrad;
      ctx.fill();
      ctx.strokeStyle = "rgba(239, 68, 68, 0.4)";
      ctx.stroke();
    }
    
    // Outer golden/metallic border
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    ctx.lineWidth = 3.5;
    const borderGrad = ctx.createLinearGradient(0, 0, width, height);
    borderGrad.addColorStop(0, '#ffe082');
    borderGrad.addColorStop(0.5, '#fbbf24');
    borderGrad.addColorStop(1, '#d97706');
    ctx.strokeStyle = borderGrad;
    ctx.stroke();
    
    // Outer soft glow shadow
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius + 2, 0, Math.PI * 2);
    ctx.lineWidth = 1;
    ctx.strokeStyle = "rgba(251, 191, 36, 0.15)";
    ctx.stroke();
  }

  // ==================== ANIMATIONS AND TRANSACTION RESOLUTION ====================

  window.startUpgraderRoll = async function () {
    getAudioContext();
    if (!selectedTarget || selectedSacrifices.length === 0) return;
    
    const startBtn = document.getElementById("upgrader-start-btn");
    const closeBtn = modalEl.querySelector(".gambling-modal-close");
    const triggerButtons = document.querySelectorAll(".upgrader-trigger-select-btn, .upgrader-change-target-btn");
    
    // Lock controls
    if (startBtn) startBtn.disabled = true;
    if (closeBtn) closeBtn.style.display = "none";
    triggerButtons.forEach(btn => btn.style.display = "none");
    
    let baseUrl = "";
    if (window.kvrcards && typeof window.kvrcards.getInventoryServerInfo === 'function') {
      try {
        const info = await window.kvrcards.getInventoryServerInfo();
        if (info && info.ok && info.effectiveBaseUrl) {
          baseUrl = info.effectiveBaseUrl.endsWith('/') ? info.effectiveBaseUrl.slice(0, -1) : info.effectiveBaseUrl;
        }
      } catch (e) {
        baseUrl = "http://localhost:4321";
      }
    }
    
    try {
      const response = await fetch(`${baseUrl}/api/gambling/upgrade/${currentUser}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          targetCardInstanceId: selectedTarget,
          sacrificedCardInstanceIds: selectedSacrifices
        })
      });
      
      const result = await response.json();
      
      if (!response.ok || !result.ok) {
        alert(result.error || "Ocurrió un error al procesar la mejora.");
        if (startBtn) startBtn.disabled = false;
        if (closeBtn) closeBtn.style.display = "block";
        triggerButtons.forEach(btn => btn.style.display = "block");
        return;
      }
      
      // Start spin animation locally using result
      animateRouletteWheel(result);
      
    } catch (err) {
      console.error("[UPGRADER] Error al conectar con servidor:", err);
      alert("Error de red: No se pudo contactar al servidor.");
      if (startBtn) startBtn.disabled = false;
      if (closeBtn) closeBtn.style.display = "block";
      triggerButtons.forEach(btn => btn.style.display = "block");
    }
  };

  function animateRouletteWheel(serverResult) {
    const percentStr = document.getElementById("upgrader-percent-val").textContent;
    const percentage = parseFloat(percentStr) || 0;
    const successArcDeg = (percentage / 100) * 360;
    
    let finalAngleDeg;
    if (serverResult.success) {
      // Land in green zone
      finalAngleDeg = Math.random() * (successArcDeg - 4) + 2;
    } else {
      // Land in red zone
      finalAngleDeg = Math.random() * (356 - successArcDeg) + successArcDeg + 2;
    }
    
    const targetLandingRad = (finalAngleDeg / 360) * Math.PI * 2;
    const totalRotationsRad = (6 + Math.floor(Math.random() * 3)) * Math.PI * 2 + (Math.PI * 2 - targetLandingRad);
    
    const durationMs = 4000; // 4 seconds spinning
    const startTime = performance.now();
    
    let lastTickSegment = -1;
    
    function tick(now) {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / durationMs);
      
      // Cubic ease-out deceleration
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      currentWheelAngle = easeProgress * totalRotationsRad;
      
      // Redraw wheel
      drawRouletteWheel(percentage, currentWheelAngle);
      
      // Mechanical synthesized click sound at angular segment crossings
      const segmentAngleRad = Math.PI / 12; // 24 segments in full circle
      const currentSegment = Math.floor(currentWheelAngle / segmentAngleRad);
      if (currentSegment !== lastTickSegment) {
        lastTickSegment = currentSegment;
        playSynthTickSound();
      }
      
      if (progress < 1) {
        spinAnimationId = requestAnimationFrame(tick);
      } else {
        spinAnimationId = null;
        resolveUpgradeResolution(serverResult);
      }
    }
    
    spinAnimationId = requestAnimationFrame(tick);
  }

  async function resolveUpgradeResolution(result) {
    // 1. Trigger screen flash
    const burst = document.createElement("div");
    burst.className = "flash-burst animate";
    modalEl.appendChild(burst);
    
    setTimeout(() => {
      burst.remove();
    }, 850);
    
    // 2. Play Audio: Triumph Fanfare or Failure Impact using Web Audio API synthesis
    try {
      if (result.success) {
        playSynthSuccessSound();
        
        // Elite feedback: Play chime sparkle on Super Success
        if (result.superSuccess) {
          setTimeout(() => {
            playSynthSuperSuccessSparkle();
          }, 350);
        }
      } else {
        playSynthFailureSound();
      }
    } catch (e) {
      console.warn("[UPGRADER] Error al reproducir SFX de resolución:", e);
    }
    
    // 3. Create full-screen overlay inside modal
    const overlay = document.createElement("div");
    overlay.className = `upgrader-overlay ${result.success ? 'success' : 'failure'}`;
    
    const titleText = result.success ? "¡MUTACIÓN COMPLETADA!" : "MUTACIÓN FALLIDA";
    
    let contentMarkup = "";
    
    if (result.success) {
      const cardDetail = result.upgradedCard;
      const superSuccessBadge = result.superSuccess ? `<div class="super-success-banner">⚡ ¡MUTACIÓN RARA COMPLETA! ⚡</div>` : "";
      
      contentMarkup = `
        <div class="upgrader-overlay-title" style="margin-bottom: 15px;">${titleText}</div>
        <div style="font-size: 16px; font-weight: 700; color: #fbbf24; margin-bottom: 20px; letter-spacing: 1px; text-transform: uppercase;">
          ¡Tu carta se ha convertido en esta nueva!
        </div>
        <div class="upgraded-card-container-wrapper">
          <div class="sparkle-particles" id="sparkle-layer"></div>
          <div class="upgraded-card-shiny-effect"></div>
          <div class="upgrader-target-card-display" style="border-radius: 16px; border: 2.5px solid #fbbf24; overflow: hidden; box-shadow: 0 0 45px rgba(251,191,36,0.45);">
            <img src="${getCardImageUrl(cardDetail)}" onerror="this.onerror=null; this.src='${FALLBACK_100x140_BASE64}';">
            <div class="upgrader-target-card-info" style="padding-bottom: 12px;">
              <div class="upgrader-target-card-name" style="font-size: 15px;">${cardDetail.name}</div>
              <div class="upgrader-target-card-media" style="font-size: 14px; text-shadow: 0 0 10px rgba(251,191,36,0.5);">Media: ${result.finalRating}</div>
            </div>
          </div>
        </div>
        ${superSuccessBadge}
        <div class="upgrader-result-details" style="margin-top: 20px;">
          Tu carta objetivo ha sido **consumida** y mutada en una versión de media superior del catálogo.
        </div>
      `;
    } else {
      contentMarkup = `
        <div class="upgrader-overlay-title">${titleText}</div>
        <div style="font-size: 58px; margin-bottom: 25px; filter: drop-shadow(0 0 12px rgba(239,68,68,0.35));">💥</div>
        <div class="upgrader-result-details" style="max-width: 420px; line-height: 1.6; color: rgba(255,255,255,0.7);">
          La mejora ha fallado. La carta objetivo <strong>regresa intacta</strong> a tu inventario, pero has perdido permanentemente todas las cartas de sacrificio apostadas.
        </div>
      `;
    }
    
    overlay.innerHTML = `
      ${contentMarkup}
      <button class="upgrader-result-dismiss-btn" onclick="dismissUpgraderResult()">Aceptar</button>
    `;
    
    modalEl.appendChild(overlay);
    overlay.style.display = "flex";
    
    if (result.success) {
      createSparkleBurst();
    }
    
    // 4. Force local offline snapshot sync in main process
    if (window.kvrcards && typeof window.kvrcards.inventoryReloadFromServer === 'function') {
      try {
        await window.kvrcards.inventoryReloadFromServer();
      } catch (syncErr) {
        console.error("[UPGRADER] Error sync local inventory snapshot:", syncErr);
      }
    }
    
    // 5. Force asynchronous vivo fetch directly from database for the Upgrader maps
    try {
      const freshInv = await fetchServerInventory();
      userInventory = freshInv;
      cardTraitsMap = freshInv.cardTraits || {};
      cardUpgradesMap = freshInv.cardUpgrades || {};
      console.log("[UPGRADER] Inventario vivo sincronizado desde el servidor tras resolución.");
    } catch (reloadErr) {
      console.error("[UPGRADER] Error al recargar inventario en caliente:", reloadErr);
    }
    
    // 6. Update global UI collections
    if (typeof renderCollection === 'function') renderCollection().catch(() => {});
    if (typeof renderWallet === 'function') renderWallet().catch(() => {});
  }
  
  function createSparkleBurst() {
    const layer = document.getElementById("sparkle-layer");
    if (!layer) return;
    
    const count = 40;
    for (let i = 0; i < count; i++) {
      const p = document.createElement("div");
      p.className = "sparkle-particle";
      
      const angle = Math.random() * Math.PI * 2;
      const velocity = 40 + Math.random() * 120;
      const x = Math.cos(angle) * velocity;
      const y = Math.sin(angle) * velocity;
      const size = 3 + Math.random() * 6;
      
      p.style.setProperty('--x', `${x}px`);
      p.style.setProperty('--y', `${y}px`);
      p.style.setProperty('--s', `${Math.random() * 0.8 + 0.4}`);
      p.style.width = `${size}px`;
      p.style.height = `${size}px`;
      p.style.left = `calc(50% - ${size/2}px)`;
      p.style.top = `calc(50% - ${size/2}px)`;
      
      layer.appendChild(p);
    }
  }

  window.dismissUpgraderResult = function () {
    const overlay = modalEl.querySelector(".upgrader-overlay");
    if (overlay) overlay.remove();
    
    // Unlock control visuals
    const startBtn = document.getElementById("upgrader-start-btn");
    const closeBtn = modalEl.querySelector(".gambling-modal-close");
    const triggerButtons = document.querySelectorAll(".upgrader-trigger-select-btn, .upgrader-change-target-btn");
    
    if (startBtn) startBtn.disabled = false;
    if (closeBtn) closeBtn.style.display = "block";
    triggerButtons.forEach(btn => btn.style.display = "block");
    
    // Reset selection and return to standard selection state
    clearUpgraderTarget();
    selectedSacrifices = [];
    renderSelectedSacrificesThumbnails();
    updateUpgraderProbabilities();
  };
  
})();
