// ==================== AUTH SYSTEM ====================

let currentUser = null;
let currentUserPassword = null;
let userAvatar = null;
let userProfile = {
  profileImage: '',  // Imagen de perfil del usuario
  title: 'Novato',
  currentTitle: 'Novato', // Título actual para enviar al backend
  description: 'Sin descripción',
  unlockedTitles: ['novato'],
  currentBackground: 'default', // Fondo de perfil actual
  unlockedBackgrounds: ['default'], // Fondos desbloqueados por el usuario
  showcaseCards: [null, null, null], // IDs de las 3 cartas destacadas
  stats: {
    totalCardsObtained: 0,    // Total histórico de cartas conseguidas
    totalPacksOpened: 0,       // Total histórico de sobres abiertos
    totalCoinsEarned: 0        // Total histórico de coins obtenidos
  }
};

// ==================== FONDOS DE PERFIL ====================
const REMOTE_BACKGROUNDS_URL = 'https://hugom1307.github.io/kvrcards-catalog/fondos_perfil.json';
const RAW_BACKGROUNDS_URL = 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/fondos_perfil.json';
const BACKGROUNDS_CACHE_KEY = 'kvr_fondos_perfil_cache';

const DEFAULT_BACKGROUNDS = [
  {
    id: 'default',
    nombre: 'Predeterminado KVR',
    imagen: './assets/backgrounds/bg_default.svg',
    descripcion: 'El fondo clásico oficial de KVRCards.'
  },
  {
    id: 'fondo_ronan_hatake',
    nombre: 'Mangekyo Watching-Time',
    imagen: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/fondos/fondo_ronan_hatake.png',
    boxColor: 'linear-gradient(to right, #8A0000 0%, #BE0000 100%)',
    borderColor: '#FFB833',
    descripcion: 'Fondo obtenido al alcanzar el prestigio 5 con Ronan Hatake.'
  }
];
window.DEFAULT_BACKGROUNDS = DEFAULT_BACKGROUNDS;

let availableBackgrounds = DEFAULT_BACKGROUNDS.map(b => ({ ...b }));
try {
  const cachedBg = localStorage.getItem(BACKGROUNDS_CACHE_KEY);
  if (cachedBg) {
    const parsed = JSON.parse(cachedBg);
    if (Array.isArray(parsed) && parsed.length > 0) {
      // Filtrar solo entradas que tengan estructura de catálogo JSON válida
      const validCached = parsed.filter(b => b && b.id && b.nombre);
      if (validCached.length > 0) {
        availableBackgrounds = validCached;
      }
    }
  }
} catch {}
window.availableBackgrounds = availableBackgrounds;

let availableTitles = [
  { id: 'novato', name: 'Novato', description: 'Título inicial para todos los jugadores', gradient: 'linear-gradient(135deg, #a8ff78 0%, #78ffd6 100%)' },
  { id: 'coleccionista', name: 'Coleccionista', description: 'Consigue 50 cartas diferentes', gradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)' },
  { id: 'adinerado', name: 'Adinerado', description: 'Acumula 10,000 Coins', gradient: 'linear-gradient(135deg, #f6d365 0%, #fda085 100%)' },
  { id: 'abridor', name: 'Abridor de Sobres', description: 'Abre 100 sobres', gradient: 'linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%)' },
  { id: 'oro_puro', name: 'Oro Puro', description: 'Consigue 10 cartas de calidad Oro', gradient: 'linear-gradient(135deg, #ffe066 0%, #f59e0b 50%, #d97706 100%)' },
  { id: 'icono_legendario', name: 'Icono Legendario', description: 'Consigue 5 cartas de calidad Icono', gradient: 'linear-gradient(135deg, #ff0844 0%, #ffb199 100%)' },
  { id: 'millonario', name: 'Millonario', description: 'Acumula 100,000 Coins', gradient: 'linear-gradient(135deg, #f12711 0%, #f5af19 100%)' },
  { id: 'maestro_kvr', name: 'Maestro KvR', description: 'Acumula 1,000 KvR Coins', gradient: 'linear-gradient(135deg, #00c6ff 0%, #0072ff 100%)' },
  { id: 'comprador', name: 'Comprador Compulsivo', description: 'Compra este título por 5,000 Coins', gradient: 'linear-gradient(135deg, #b224ef 0%, #7579ff 100%)' },
  { id: 'elite', name: 'Élite', description: 'Compra este título exclusivo por 500 KvR Coins', gradient: 'linear-gradient(135deg, #f857a6 0%, #ff5858 100%)' }
];
window.availableTitles = availableTitles;
let currentShowcaseSlot = null; // Slot actual siendo editado

// Elementos DOM Auth
const authModal = document.getElementById('auth-modal');
const authTabLogin = document.getElementById('auth-tab-login');
const authTabRegister = document.getElementById('auth-tab-register');
const authPanelLogin = document.getElementById('auth-panel-login');
const authPanelRegister = document.getElementById('auth-panel-register');
const loginUsername = document.getElementById('login-username');
const loginPassword = document.getElementById('login-password');
const loginSubmit = document.getElementById('login-submit');
const registerUsername = document.getElementById('register-username');
const registerPassword = document.getElementById('register-password');
const registerPasswordConfirm = document.getElementById('register-password-confirm');
const registerSubmit = document.getElementById('register-submit');

// Elementos perfil HUD
const profileAvatar = document.getElementById('profile-avatar');
const profileAvatarPlaceholder = document.querySelector('.profile-avatar-placeholder');
const hudAvatarLarge = document.getElementById('hud-avatar-large');
const hudAvatarPlaceholder = document.querySelector('.hud-avatar-placeholder');
const hudUsernameDisplay = document.getElementById('hud-username-display');
const changeAvatarBtn = document.getElementById('change-avatar-btn');
const avatarInput = document.getElementById('avatar-input');
const hudLogout = document.getElementById('hud-logout');

// Elementos DOM Modal Perfil
const profileModal = document.getElementById('profile-modal');
const profileClose = document.getElementById('profile-close');
const hudViewProfile = document.getElementById('hud-view-profile');
const profileView = document.querySelector('.profile-view');
const profileEdit = document.querySelector('.profile-edit');
const editProfileBtn = document.getElementById('edit-profile-btn');
const saveProfileBtn = document.getElementById('save-profile-btn');
const cancelEditBtn = document.getElementById('cancel-edit-btn');
const profileAvatarImgLarge = document.getElementById('profile-avatar-img-large');
const profileUsernameDisplay = document.getElementById('profile-username-display');
const profileTitleDisplay = document.getElementById('profile-title-display');
const profileDescription = document.getElementById('profile-description');
const editTitleSelect = document.getElementById('edit-title-select');
const editDescription = document.getElementById('edit-description');
const descriptionCharCount = document.getElementById('description-char-count');
const profileTotalCards = document.getElementById('profile-total-cards');
const profileTotalPacks = document.getElementById('profile-total-packs');
const profileTotalCoins = document.getElementById('profile-total-coins');

// Elementos DOM del Showcase
const showcaseSlots = document.querySelectorAll('.showcase-slot');
const showcaseEditSlots = document.querySelectorAll('.showcase-edit-slot');
const cardSelectorModal = document.getElementById('card-selector-modal');
const cardSelectorClose = document.getElementById('card-selector-close');
const cardSelectorSearch = document.getElementById('card-selector-search');
const cardSelectorGrid = document.getElementById('card-selector-grid');

// Elementos DOM del Zoom
const cardZoomModal = document.getElementById('card-zoom-modal');
const cardZoomClose = document.getElementById('card-zoom-close');
const cardZoomImage = document.getElementById('card-zoom-image');

// Elementos DOM de Fondos de Perfil
const openBackgroundSelectorBtn = document.getElementById('open-background-selector-btn');
const backgroundSelectorModal = document.getElementById('background-selector-modal');
const backgroundSelectorClose = document.getElementById('background-selector-close');
const backgroundSelectorGrid = document.getElementById('background-selector-grid');
const profileBgCurrentPreview = document.getElementById('profile-bg-current-preview');
const profileBgCurrentName = document.getElementById('profile-bg-current-name');

// Variables globales para títulos y showcase
// let availableTitles = []; // Ya declarado arriba
// let currentShowcaseSlot = null; // Ya declarado arriba

// Variables globales de poderes
let availablePowers = []; // Todos los poderes disponibles del JSON
let ownedPowersInventory = {}; // {powerId: {uses: X}} o {powerId: {permanent: true}}

// Verificar autenticación al inicio
async function checkAuthentication() {
  console.log('[AUTH] Verificando autenticación...');
  
  // Intentar cargar sesión guardada
  const savedUsername = localStorage.getItem('kvrUsername');
  const savedPassword = localStorage.getItem('kvrPassword');
  
  if (savedUsername && savedPassword) {
    console.log('[AUTH] Sesión encontrada para:', savedUsername);
    
    // Asignar inmediatamente para evitar estado "Usuario" o demoras en la UI
    currentUser = savedUsername;
    currentUserPassword = savedPassword;
    const savedAvatar = localStorage.getItem('kvrAvatar_' + savedUsername);
    if (savedAvatar) userAvatar = savedAvatar;
    
    // Cargar perfil y actualizar UI de inmediato (0ms de retraso)
    loadUserProfile();
    updateProfileUI();
    
    try {
      const result = await window.kvrcards.cloudLogin(savedUsername, savedPassword);
      if (result.ok) {
        await window.kvrcards.setUsername(savedUsername);
        updateProfileUI();
        
        // Recargar vistas para mostrar inventario del usuario
        Promise.all([renderCollection(), renderOwnedPacks(), renderShop(), renderWallet(), updateMissionsProgress(), updateKizunasProgress()]).catch(console.error);
        
        console.log('[AUTH] ✓ Sesión restaurada');
        return true;
      } else {
        console.log('[AUTH] ⚠ Sesión inválida, requiere login');
        localStorage.removeItem('kvrUsername');
        localStorage.removeItem('kvrPassword');
        currentUser = null;
        userAvatar = null;
        updateProfileUI();
      }
    } catch (e) {
      console.error('[AUTH] Error en verificación de sesión:', e);
      await window.kvrcards.setUsername(savedUsername).catch(() => {});
      updateProfileUI();
      Promise.all([renderCollection(), renderOwnedPacks(), renderShop(), renderWallet()]).catch(console.error);
      return true;
    }
  }
  
  // No hay sesión o es inválida, mostrar modal de auth
  console.log('[AUTH] Mostrando modal de autenticación');
  showAuthModal();
  return false;
}

async function showAuthModal() {
  console.log('[AUTH] showAuthModal called');
  authModal?.classList.add('show');
  // Asegurar que esté en el tab de login por defecto
  switchAuthTab('login');
  
  // CRÍTICO: Forzar focus en la ventana de Electron PRIMERO
  try {
    const result = await window.kvrcards.windowForceFocus();
    console.log('[AUTH] Window force focus result:', result);
  } catch (err) {
    console.error('[AUTH] Failed to force window focus:', err);
  }
  
  // Forzar reflow para asegurar que el modal esté renderizado
  if (authModal) {
    authModal.offsetHeight; // Trigger reflow
  }
  
  // Esperar un poco más para que Electron procese el focus
  await new Promise(resolve => setTimeout(resolve, 100));
  
  // Usar requestAnimationFrame para asegurar que el DOM esté actualizado
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      if (loginUsername) {
        console.log('[AUTH] Attempting focus on loginUsername');
        
        // Asegurar propiedades antes de focus
        loginUsername.disabled = false;
        loginUsername.readOnly = false;
        loginUsername.tabIndex = 0;
        
        // Blur cualquier elemento activo primero
        if (document.activeElement && document.activeElement !== loginUsername) {
          document.activeElement.blur();
        }
        
        // Focus simple
        loginUsername.focus();
        
        console.log('[AUTH] Active element:', document.activeElement?.id);
        console.log('[AUTH] Is focused?', document.activeElement === loginUsername);
      }
    });
  });
}

function hideAuthModal() {
  authModal?.classList.remove('show');
}

// Tabs de Auth
function switchAuthTab(tab) {
  if (tab === 'login') {
    authTabLogin?.classList.add('active');
    authTabRegister?.classList.remove('active');
    authPanelLogin?.classList.add('active');
    authPanelRegister?.classList.remove('active');
  } else {
    authTabLogin?.classList.remove('active');
    authTabRegister?.classList.add('active');
    authPanelLogin?.classList.remove('active');
    authPanelRegister?.classList.add('active');
  }
}

// Login
async function handleLogin() {
  const username = loginUsername?.value?.trim();
  const password = loginPassword?.value?.trim();
  
  if (!username || !password) {
    alert('Por favor completa todos los campos');
    return;
  }
  
  console.log('[AUTH] Intentando login:', username);
  
  try {
    const result = await window.kvrcards.cloudLogin(username, password);
    
    if (result.ok) {
      currentUser = username;
      currentUserPassword = password;
      
      // Cargar avatar del usuario si existe
      const savedAvatar = localStorage.getItem('kvrAvatar_' + username);
      userAvatar = savedAvatar;
      
      // Cargar perfil del usuario
      loadUserProfile();
      
      // Guardar sesión
      localStorage.setItem('kvrUsername', username);
      localStorage.setItem('kvrPassword', password);
      localStorage.setItem('userId', username); // Usar username como userId para sistema de amigos
      
      // Actualizar perfil local del backend
      await window.kvrcards.setUsername(username);
      
      updateProfileUI();
      hideAuthModal();
      
      // Marcar misión de login como completada
      await completeLoginMission();
      
      // VERIFICAR SI HAY DATOS EN R2 Y SI SON DIFERENTES A LOS LOCALES
      await checkAndOfferCloudSync();
      
      // SIEMPRE recargar vistas después del login para cargar inventario del usuario
      await Promise.all([renderCollection(), renderOwnedPacks(), renderShop(), renderWallet(), updateMissionsProgress()]);
      
      // Recargar lista de amigos si el modal está abierto (usa clase 'active')
      const friendsModal = document.getElementById('friends-modal');
      if (friendsModal && friendsModal.classList.contains('active')) {
        // Limpiar y recargar todo
        console.log('[AUTH] Recargando amigos después del login');
        document.getElementById('friends-list').innerHTML = '';
        document.getElementById('requests-list').innerHTML = '';
        document.getElementById('search-results-list').innerHTML = '';
        
        // Recargar la tab actual
        if (currentFriendsTab === 'my-friends') {
          loadFriendsList();
        } else if (currentFriendsTab === 'requests') {
          loadFriendRequests();
        } else if (currentFriendsTab === 'add-friends') {
          searchUsers();
        }
      }
      
      alert('Sesion iniciada correctamente');
    } else {
      alert('Error: ' + (result.error || 'No se pudo iniciar sesion'));
    }
  } catch (e) {
    console.error('[AUTH] Error en login:', e);
    alert('Error al conectar con el servidor');
  }
}

// Registro
async function handleRegister() {
  const username = registerUsername?.value?.trim();
  const password = registerPassword?.value?.trim();
  const passwordConfirm = registerPasswordConfirm?.value?.trim();
  
  if (!username || !password || !passwordConfirm) {
    alert('Por favor completa todos los campos');
    return;
  }
  
  if (password !== passwordConfirm) {
    alert('Las contrasenas no coinciden');
    return;
  }
  
  if (username.length < 3) {
    alert('El usuario debe tener al menos 3 caracteres');
    return;
  }
  
  if (password.length < 4) {
    alert('La contrasena debe tener al menos 4 caracteres');
    return;
  }
  
  console.log('[AUTH] Intentando registro:', username);
  
  try {
    const result = await window.kvrcards.cloudRegister(username, password);
    
    if (result.ok) {
      alert('Cuenta creada exitosamente. Iniciando sesion...');
      
      // Auto-login
      loginUsername.value = username;
      loginPassword.value = password;
      await handleLogin();
    } else {
      alert('Error: ' + (result.error || 'No se pudo crear la cuenta'));
    }
  } catch (e) {
    console.error('[AUTH] Error en registro:', e);
    alert('Error al crear la cuenta');
  }
}

// ==================== GESTIÓN DE ACCESO ADMIN / MODO DEBUG ====================
window.currentUserIsAdmin = false;

window.refreshAdminStatus = async function() {
  const username = (currentUser || window.currentUser || localStorage.getItem('kvrUsername') || '').trim();
  const hudDebugRow = document.getElementById('hud-debug-row');

  if (!username) {
    window.currentUserIsAdmin = false;
    if (hudDebugRow) hudDebugRow.style.display = 'none';
    return false;
  }

  try {
    let remoteData = null;
    if (window.kvrcards && typeof window.kvrcards.getRemoteInventory === 'function') {
      const res = await window.kvrcards.getRemoteInventory();
      if (res && res.ok && res.data) {
        remoteData = res.data;
      }
    }

    if (!remoteData) {
      try {
        const fetchRes = await fetch(`https://inventory-43i0.onrender.com/api/inventory/${encodeURIComponent(username)}?t=${Date.now()}`);
        if (fetchRes.ok) {
          remoteData = await fetchRes.json();
        }
      } catch (_) {}
    }

    const isAdmin = Boolean(remoteData && (remoteData.isAdmin === true || remoteData.isAdmin === 'true'));
    window.currentUserIsAdmin = isAdmin;

    if (hudDebugRow) {
      hudDebugRow.style.display = isAdmin ? 'block' : 'none';
    }
    document.querySelectorAll('.admin-only-btn').forEach(el => {
      el.style.display = isAdmin ? '' : 'none';
    });
    if (typeof window.updateInfiniteAdminButtons === 'function') {
      window.updateInfiniteAdminButtons(isAdmin);
    }
    console.log(`[AUTH] Estado de admin verificado para "${username}": ${isAdmin}`);
    return isAdmin;
  } catch (err) {
    console.warn('[AUTH] Error comprobando estado de admin:', err);
    if (hudDebugRow) hudDebugRow.style.display = window.currentUserIsAdmin ? 'block' : 'none';
    document.querySelectorAll('.admin-only-btn').forEach(el => {
      el.style.display = window.currentUserIsAdmin ? '' : 'none';
    });
    if (typeof window.updateInfiniteAdminButtons === 'function') {
      window.updateInfiniteAdminButtons(window.currentUserIsAdmin);
    }
    return window.currentUserIsAdmin;
  }
};

// Actualizar UI del perfil
function updateProfileUI() {
  const name = currentUser || localStorage.getItem('kvrUsername') || 'Usuario';
  if (hudUsername) hudUsername.textContent = name;
  if (hudUsernameDisplay) hudUsernameDisplay.textContent = name;
  if (document.getElementById('current-user-display')) {
    document.getElementById('current-user-display').textContent = name;
  }
  
  // Actualizar visibilidad del botón modo debug según rango admin
  window.refreshAdminStatus().catch(() => {});
  
  // Cargar avatar si existe
  const avatar = userAvatar || userProfile.profileImage || (currentUser ? localStorage.getItem('kvrAvatar_' + currentUser) : '');
  if (avatar) {
    if (profileAvatar) {
      profileAvatar.src = avatar;
      profileAvatar.classList.add('has-image');
    }
    if (hudAvatarLarge) {
      hudAvatarLarge.src = avatar;
      hudAvatarLarge.classList.add('has-image');
    }
  } else {
    if (profileAvatar) profileAvatar.classList.remove('has-image');
    if (hudAvatarLarge) hudAvatarLarge.classList.remove('has-image');
  }
}

// Cambiar avatar
function handleAvatarChange(e) {
  const file = e.target.files[0];
  if (!file) return;
  
  if (!file.type.startsWith('image/')) {
    alert('Por favor selecciona una imagen válida');
    return;
  }
  
  const reader = new FileReader();
  reader.onload = (event) => {
    userAvatar = event.target.result;
    userProfile.profileImage = event.target.result; // Actualizar también en userProfile
    
    // Guardar avatar asociado al usuario actual
    if (currentUser) {
      localStorage.setItem('kvrAvatar_' + currentUser, userAvatar);
      saveUserProfile(); // Guardar perfil completo en backend
    }
    updateProfileUI();
  };
  reader.readAsDataURL(file);
}

// ==================== SISTEMA DE PERFIL ====================

// Cargar perfil del usuario desde localStorage y backend
function loadUserProfile() {
  if (!currentUser) {
    currentUser = localStorage.getItem('kvrUsername');
  }
  if (!currentUser) return;
  
  let localUnlocked = [];
  let loaded = {};
  const savedProfile = localStorage.getItem('kvrProfile_' + currentUser);
  if (savedProfile) {
    try {
      loaded = JSON.parse(savedProfile) || {};
      if (Array.isArray(loaded.unlockedTitles)) {
        localUnlocked = loaded.unlockedTitles;
      }
    } catch (e) {
      console.error('[PROFILE] Error parsing local profile:', e);
    }
  }

  const initialTitle = loaded.currentTitle || loaded.title || 'Novato';
  const savedAvatar = userAvatar || loaded.profileImage || localStorage.getItem('kvrAvatar_' + currentUser) || '';
  const initialBackground = loaded.currentBackground || 'default';
  const localUnlockedBackgrounds = Array.isArray(loaded.unlockedBackgrounds) ? loaded.unlockedBackgrounds : ['default'];

  userProfile = {
    profileImage: savedAvatar,
    title: initialTitle,
    currentTitle: initialTitle,
    description: loaded.description || 'Sin descripción',
    unlockedTitles: Array.from(new Set([...localUnlocked, 'novato'])).filter(Boolean),
    currentBackground: initialBackground,
    unlockedBackgrounds: Array.from(new Set([...localUnlockedBackgrounds, 'default'])).filter(Boolean),
    showcaseCards: loaded.showcaseCards || [null, null, null],
    stats: loaded.stats || {
      totalCardsObtained: 0,
      totalPacksOpened: 0,
      totalCoinsEarned: 0
    }
  };
  
  if (userProfile.profileImage) {
    userAvatar = userProfile.profileImage;
  }

  // Sincronizar en segundo plano con el backend para no bloquear la interfaz
  if (window.kvrcards && typeof window.kvrcards.getUserProfile === 'function') {
    window.kvrcards.getUserProfile().then(backendRes => {
      if (backendRes?.ok && backendRes?.profile) {
        const bp = backendRes.profile;
        if (Array.isArray(bp.unlockedTitles)) {
          userProfile.unlockedTitles = Array.from(new Set([...userProfile.unlockedTitles, ...bp.unlockedTitles, 'novato'])).filter(Boolean);
        }
        if (Array.isArray(bp.unlockedBackgrounds)) {
          userProfile.unlockedBackgrounds = Array.from(new Set([...userProfile.unlockedBackgrounds, ...bp.unlockedBackgrounds, 'default'])).filter(Boolean);
        }
        if (bp.currentBackground) {
          userProfile.currentBackground = bp.currentBackground;
        }
        if (bp.profileImage && !userProfile.profileImage) {
          userProfile.profileImage = bp.profileImage;
          userAvatar = bp.profileImage;
          localStorage.setItem('kvrAvatar_' + currentUser, bp.profileImage);
        }
        localStorage.setItem('kvrProfile_' + currentUser, JSON.stringify(userProfile));
        updateProfileUI();
        if (profileModal && profileModal.classList.contains('show')) {
          updateProfileDisplay();
        }
      }
    }).catch(() => {});
  }
}

// Guardar perfil del usuario en localStorage y backend
async function saveUserProfile() {
  if (!currentUser) return;
  
  if (!userProfile.unlockedTitles || !Array.isArray(userProfile.unlockedTitles)) {
    userProfile.unlockedTitles = ['novato'];
  }
  
  // Asegurar que 'novato' y el título actual siempre estén en la lista
  if (!userProfile.unlockedTitles.includes('novato')) {
    userProfile.unlockedTitles.push('novato');
  }

  if (!userProfile.unlockedBackgrounds || !Array.isArray(userProfile.unlockedBackgrounds)) {
    userProfile.unlockedBackgrounds = ['default'];
  }
  if (!userProfile.unlockedBackgrounds.includes('default')) {
    userProfile.unlockedBackgrounds.push('default');
  }
  if (!userProfile.currentBackground) {
    userProfile.currentBackground = 'default';
  }
  
  if (userProfile.currentTitle) {
    // Si tenemos la lista de títulos disponibles, añadir tanto el id como el nombre
    if (Array.isArray(availableTitles) && availableTitles.length > 0) {
      const matched = availableTitles.find(t => t.name === userProfile.currentTitle || t.id === userProfile.currentTitle);
      if (matched) {
        if (!userProfile.unlockedTitles.includes(matched.id)) userProfile.unlockedTitles.push(matched.id);
      }
    }
  }
  
  // Guardar en localStorage (cache local)
  localStorage.setItem('kvrProfile_' + currentUser, JSON.stringify(userProfile));
  
  // Guardar en el backend (inventario)
  try {
    if (window.kvrcards && typeof window.kvrcards.updateUserProfile === 'function') {
      const result = await window.kvrcards.updateUserProfile({
        profileImage: userProfile.profileImage,
        currentTitle: userProfile.currentTitle,
        unlockedTitles: userProfile.unlockedTitles,
        currentBackground: userProfile.currentBackground,
        unlockedBackgrounds: userProfile.unlockedBackgrounds,
        showcaseCards: userProfile.showcaseCards
      });
      
      if (result.ok) {
        console.log('[PROFILE] Profile saved to backend with unlockedTitles:', userProfile.unlockedTitles, 'currentBackground:', userProfile.currentBackground);
      } else {
        console.error('[PROFILE] Error saving to backend:', result.error);
      }
    }
  } catch (err) {
    console.error('[PROFILE] Error saving profile:', err);
  }
  
  console.log('[PROFILE] Profile saved with', userProfile.unlockedTitles.length, 'unlocked titles, background:', userProfile.currentBackground);
}

// Mostrar modal de perfil
async function showProfileModal() {
  if (!currentUser) {
    currentUser = localStorage.getItem('kvrUsername');
  }
  if (!currentUser) {
    alert('❌ No hay sesión activa');
    return;
  }
  
  // 1. Mostrar modal de inmediato para respuesta instantánea (0 lag)
  profileModal?.classList.add('show');
  profileView.style.display = 'flex';
  profileEdit.style.display = 'none';
  
  // 2. Cargar perfil local de inmediato
  loadUserProfile();
  updateProfileDisplay();
  validateEquippedTitleAndKizunas().catch(console.error);
  if (typeof window.updateProfileBlessingUI === 'function') {
    window.updateProfileBlessingUI();
  }
  
  // 3. Cargar en segundo plano títulos, fondos, estadísticas y showcase sin congelar la interfaz
  if (availableTitles.length === 0) {
    loadTitles().then(() => {
      updateProfileDisplay();
      updateTitleSelector();
      validateEquippedTitleAndKizunas().catch(console.error);
    }).catch(console.error);
  }

  if (availableBackgrounds.length === 0) {
    loadBackgrounds().then(() => {
      updateProfileDisplay();
      updateBackgroundEditPreview();
    }).catch(console.error);
  }
  
  updateProfileStats().then(updateProfileDisplay).catch(console.error);
  updateShowcaseDisplay().catch(console.error);
}

// Actualizar display del perfil
function updateProfileDisplay() {
  const name = currentUser || localStorage.getItem('kvrUsername') || 'Usuario';
  if (profileUsernameDisplay) {
    profileUsernameDisplay.textContent = name;
  }
  
  // Avatar
  const avatarToUse = userAvatar || userProfile.profileImage || (currentUser ? localStorage.getItem('kvrAvatar_' + currentUser) : '');
  const placeholder = document.querySelector('.profile-avatar-placeholder-large');
  if (avatarToUse && profileAvatarImgLarge) {
    profileAvatarImgLarge.src = avatarToUse;
    profileAvatarImgLarge.style.display = 'block';
    profileAvatarImgLarge.classList.add('has-image');
    if (placeholder) placeholder.style.display = 'none';
  } else if (profileAvatarImgLarge) {
    profileAvatarImgLarge.style.display = 'none';
    profileAvatarImgLarge.classList.remove('has-image');
    if (placeholder) placeholder.style.display = 'flex';
  }
  
  // Título
  if (profileTitleDisplay) {
    const currentT = userProfile.currentTitle || userProfile.title || 'Novato';
    profileTitleDisplay.textContent = currentT;
    window.applyTitleStyle(profileTitleDisplay, currentT);
  }
  
  // Descripción
  if (profileDescription) {
    profileDescription.textContent = userProfile.description || 'Sin descripción';
  }
  
  // Fondo de perfil y recuadro
  applyProfileBackground(profileModal, userProfile.currentBackground);
  const ownCard = profileModal ? profileModal.querySelector('.modal.profile-modal') : null;
  if (ownCard && typeof applyProfileBoxStyle === 'function') {
    applyProfileBoxStyle(ownCard, userProfile.currentBackground);
  }
  updateBackgroundEditPreview();

  // Actualizar selector de títulos
  updateTitleSelector();
  
  // Actualizar showcase
  updateShowcaseDisplay();
}

// Actualizar estadísticas del perfil
async function updateProfileStats() {
  try {
    // Obtener estadísticas actualizadas del backend
    const inventory = await window.kvrcards.getInventory();
    
    if (inventory && inventory.cards) {
      window.__lastKnownInventoryCards = inventory.cards;
      validateEquippedTitleAndKizunas().catch(console.error);
    }
    
    if (inventory && inventory.stats) {
      // Actualizar estadísticas locales
      userProfile.stats.totalCardsObtained = inventory.stats.totalCardsObtained || 0;
      userProfile.stats.totalPacksOpened = inventory.stats.totalPacksOpened || 0;
      userProfile.stats.totalCoinsEarned = inventory.stats.totalCoinsEarned || 0;
      
      // Guardar en localStorage
      saveUserProfile();
    }
    
    // Mostrar estadísticas
    if (profileTotalCards) {
      profileTotalCards.textContent = (userProfile.stats.totalCardsObtained || 0).toLocaleString('es-ES');
    }
    
    if (profileTotalPacks) {
      profileTotalPacks.textContent = (userProfile.stats.totalPacksOpened || 0).toLocaleString('es-ES');
    }
    
    if (profileTotalCoins) {
      profileTotalCoins.textContent = (userProfile.stats.totalCoinsEarned || 0).toLocaleString('es-ES');
    }
  } catch (e) {
    console.error('[PROFILE] Error updating stats:', e);
  }
}

// ==================== SISTEMA GLOBAL DE GRADIENTES Y TOOLTIPS DE TÍTULOS ====================

window.getTitleDetails = function(titleNameOrId) {
  if (!titleNameOrId) return null;
  const list = Array.isArray(window.availableTitles) ? window.availableTitles : (Array.isArray(availableTitles) ? availableTitles : []);
  const query = String(titleNameOrId).trim().toLowerCase().replace(/^["']|["']$/g, '');
  return list.find(t => 
    String(t.id).toLowerCase() === query || 
    String(t.name).toLowerCase() === query ||
    String(t.titulo || '').toLowerCase() === query
  ) || null;
};

window.applyTitleStyle = function(element, titleNameOrId) {
  if (!element) return;
  const titleObj = window.getTitleDetails(titleNameOrId);
  const gradient = titleObj?.gradient || '';
  const titleDesc = titleObj?.description || titleObj?.desc || '';
  const titleName = titleObj?.name || titleObj?.titulo || String(titleNameOrId || '').replace(/^["']|["']$/g, '');

  // Limpiar estilos directos del elemento padre para que los emojis hijos no se vean afectados
  element.style.removeProperty('background');
  element.style.removeProperty('background-image');
  element.style.removeProperty('-webkit-background-clip');
  element.style.removeProperty('background-clip');
  element.style.removeProperty('-webkit-text-fill-color');
  element.style.removeProperty('color');
  element.classList.remove('title-gradient-text');

  // Detectar si el texto actual del elemento tiene comillas envolventes (ej: rankings)
  const existingText = element.textContent?.trim() || '';
  let textToRender = titleName;
  if (existingText.startsWith('"') && existingText.endsWith('"') && !titleName.startsWith('"')) {
    textToRender = `"${titleName}"`;
  } else if (existingText && !titleObj && !titleNameOrId) {
    textToRender = existingText;
  }

  // Renderizar el HTML con gradiente solo en texto y emojis intactos
  if (typeof window.formatTitleWithGradient === 'function') {
    element.innerHTML = window.formatTitleWithGradient(textToRender, gradient);
  } else {
    element.textContent = textToRender;
  }

  const parentBadge = element.closest('.profile-title');
  if (parentBadge) {
    if (gradient) {
      parentBadge.classList.add('has-gradient-border');
    } else {
      parentBadge.classList.remove('has-gradient-border');
    }
  }

  if (titleDesc) {
    element.setAttribute('data-title-desc', titleDesc);
    element.setAttribute('data-title-name', titleName);
    if (gradient) element.setAttribute('data-title-gradient', gradient);
    
    if (parentBadge && parentBadge !== element) {
      parentBadge.setAttribute('data-title-desc', titleDesc);
      parentBadge.setAttribute('data-title-name', titleName);
      if (gradient) parentBadge.setAttribute('data-title-gradient', gradient);
    }
  }
};

let titleTooltipEl = null;
let titleTooltipTimeout = null;

function ensureTitleTooltip() {
  if (!titleTooltipEl) {
    titleTooltipEl = document.getElementById('kvr-title-tooltip');
    if (!titleTooltipEl) {
      titleTooltipEl = document.createElement('div');
      titleTooltipEl.id = 'kvr-title-tooltip';
      document.body.appendChild(titleTooltipEl);
    }
  }
  return titleTooltipEl;
}

window.showTitleTooltip = function(targetEl, data = {}) {
  const tooltip = ensureTitleTooltip();
  if (!tooltip || !targetEl) return;

  const escapeFn = typeof window.escapeHtml === 'function' ? window.escapeHtml : (s => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'));

  const isBuff = targetEl.classList?.contains('reward-buff') || targetEl.getAttribute('data-reward-type') === 'buff' || Boolean(data.isBuff);
  const icon = isBuff ? '⚡' : '🏆';
  const defaultHeader = isBuff ? 'Buff Kizuna' : 'Título';
  const titleName = data.name || targetEl.getAttribute('data-title-name') || targetEl.textContent?.replace(/^[🏆⚡]\s*(Buff:\s*|Título:\s*)?/i, '').replace(/^["']|["']$/g, '').trim() || defaultHeader;
  const titleDesc = data.description || targetEl.getAttribute('data-title-desc') || targetEl.getAttribute('data-tooltip') || '';
  const gradient = data.gradient || targetEl.getAttribute('data-title-gradient') || '';

  if (!titleDesc) return;

  clearTimeout(titleTooltipTimeout);

  const formattedHeaderTitle = typeof window.formatTitleWithGradient === 'function'
    ? window.formatTitleWithGradient(titleName, gradient)
    : escapeFn(titleName);

  tooltip.innerHTML = `
    <div class="tooltip-title-header"><span class="title-emoji">${icon}</span> ${formattedHeaderTitle}</div>
    <p class="tooltip-title-desc">${escapeFn(titleDesc)}</p>
  `;

  tooltip.classList.add('show');

  const rect = targetEl.getBoundingClientRect();
  const tooltipRect = tooltip.getBoundingClientRect();
  
  let top = rect.top - tooltipRect.height - 10;
  let left = rect.left + (rect.width / 2) - (tooltipRect.width / 2);

  if (top < 10) {
    top = rect.bottom + 10;
    tooltip.classList.add('arrow-top');
  } else {
    tooltip.classList.remove('arrow-top');
  }

  if (left < 10) left = 10;
  if (left + tooltipRect.width > window.innerWidth - 10) {
    left = window.innerWidth - tooltipRect.width - 10;
  }

  tooltip.style.top = `${Math.max(5, top)}px`;
  tooltip.style.left = `${Math.max(5, left)}px`;
};

window.hideTitleTooltip = function() {
  if (titleTooltipEl) {
    titleTooltipEl.classList.remove('show');
  }
};

// Delegación global para hover y clicks de títulos y buffs
document.addEventListener('mouseover', (e) => {
  const target = e.target.closest('[data-title-desc], .reward-title, .reward-buff, .mission-reward-item.reward-title, .mission-reward-item.reward-buff, .kizuna-reward-item.reward-title, .kizuna-reward-item.reward-buff, .profile-title, #profile-title-display, #profile-modal-title');
  if (target) {
    const rawDesc = target.getAttribute('data-title-desc') || target.getAttribute('data-tooltip');
    const isBuff = target.classList?.contains('reward-buff') || target.getAttribute('data-reward-type') === 'buff';
    let titleData = null;
    if (!rawDesc) {
      const titleId = target.getAttribute('data-title-id');
      const text = target.textContent.replace(/^[🏆⚡]\s*(Buff:\s*|Título:\s*)?/i, '').replace(/^["']|["']$/g, '').trim();
      const obj = window.getTitleDetails(titleId || text);
      if (obj) {
        titleData = { name: obj.name, description: obj.description, gradient: obj.gradient, isBuff };
      }
    } else {
      titleData = {
        name: target.getAttribute('data-title-name') || target.textContent?.replace(/^[🏆⚡]\s*(Buff:\s*|Título:\s*)?/i, '').replace(/^["']|["']$/g, '').trim(),
        description: rawDesc,
        gradient: target.getAttribute('data-title-gradient') || '',
        isBuff
      };
    }
    if (titleData && titleData.description) {
      window.showTitleTooltip(target, titleData);
    }
  }
});

document.addEventListener('mouseout', (e) => {
  const target = e.target.closest('[data-title-desc], .reward-title, .reward-buff, .mission-reward-item, .kizuna-reward-item, .profile-title, #profile-title-display, #profile-modal-title');
  if (target) {
    window.hideTitleTooltip();
  }
});

document.addEventListener('click', (e) => {
  const profileTitle = e.target.closest('.profile-title, #profile-title-display, #profile-modal-title');
  if (profileTitle) {
    const rawDesc = profileTitle.getAttribute('data-title-desc');
    const currentT = profileTitle.textContent.replace(/^🏆\s*(Título:\s*)?/i, '').replace(/^["']|["']$/g, '').trim();
    const titleObj = window.getTitleDetails(currentT);
    const data = {
      name: titleObj?.name || profileTitle.getAttribute('data-title-name') || currentT,
      description: titleObj?.description || rawDesc || 'Sin descripción',
      gradient: titleObj?.gradient || profileTitle.getAttribute('data-title-gradient') || ''
    };
    window.showTitleTooltip(profileTitle, data);
    clearTimeout(titleTooltipTimeout);
    titleTooltipTimeout = setTimeout(() => {
      window.hideTitleTooltip();
    }, 4000);
    return;
  }
  
  if (!e.target.closest('#kvr-title-tooltip, [data-title-desc], .profile-title, .reward-title')) {
    window.hideTitleTooltip();
  }
});

// Cargar títulos desde el backend o catálogo remoto
async function loadTitles(forceRefresh = false) {
  try {
    if (window.kvrcards && typeof window.kvrcards.getTitles === 'function') {
      const result = await window.kvrcards.getTitles();
      if (result && result.ok && Array.isArray(result.titles) && result.titles.length > 0) {
        availableTitles = result.titles;
        window.availableTitles = availableTitles;
        if (typeof updateProfileDisplay === 'function') updateProfileDisplay();
        if (typeof updateTitleSelector === 'function') updateTitleSelector();
        return availableTitles;
      }
    }
  } catch (e) {
    console.warn('[TITLES] Error loading titles via IPC:', e?.message || e);
  }

  // Fallback remoto a GitHub Pages o Raw si IPC falla o no está en Electron
  try {
    const rawUrl = 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/titles.json?t=' + Date.now();
    const res = await fetch(rawUrl, { cache: 'no-store' });
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        availableTitles = data;
        window.availableTitles = availableTitles;
        if (typeof updateProfileDisplay === 'function') updateProfileDisplay();
        if (typeof updateTitleSelector === 'function') updateTitleSelector();
        return availableTitles;
      }
    }
  } catch (e) {
    console.warn('[TITLES] Error loading titles from GitHub fallback:', e?.message || e);
  }

  return availableTitles;
}
window.loadTitles = loadTitles;

// ==================== VALIDACIÓN Y OCULTACIÓN DE TÍTULOS DE KIZUNA ====================

// Obtener el Kizuna asociado a un título si existe
function getKizunaForTitle(titleIdOrName) {
  if (!titleIdOrName) return null;
  const kizunas = Array.isArray(window.availableKizunas) ? window.availableKizunas : (Array.isArray(availableKizunas) ? availableKizunas : []);
  const tClean = String(titleIdOrName).trim().toLowerCase();
  for (const kizuna of kizunas) {
    if (!kizuna) continue;
    // Comprobar recompensas de título
    const titleRewards = (kizuna.rewards || []).filter(r => String(r.type || '').toLowerCase() === 'title');
    for (const tr of titleRewards) {
      const trId = String(tr.titleId || tr.id || '').toLowerCase().trim();
      const trName = String(tr.name || '').toLowerCase().trim();
      if (trId === tClean || trName === tClean) {
        return kizuna;
      }
    }
    // Comprobar también por ID del kizuna
    if (String(kizuna.id || '').toLowerCase().trim() === tClean) {
      return kizuna;
    }
  }
  return null;
}

// Comprobar si un Kizuna está activo actualmente con el inventario
function isKizunaActiveWithInventory(kizuna, inventoryCards) {
  if (!kizuna || !Array.isArray(kizuna.cardIds) || kizuna.cardIds.length === 0) return true;
  if (!inventoryCards || typeof inventoryCards !== 'object') return false;
  for (const cardId of kizuna.cardIds) {
    if (!inventoryCards[cardId] || inventoryCards[cardId] <= 0) {
      return false;
    }
  }
  return true;
}

// Validar títulos de Kizuna equipados y activos
async function validateEquippedTitleAndKizunas() {
  try {
    let invCards = window.__lastKnownInventoryCards;
    if (!invCards && window.kvrcards && typeof window.kvrcards.getInventory === 'function') {
      const inv = await window.kvrcards.getInventory();
      if (inv && inv.ok && inv.cards) {
        invCards = inv.cards;
        window.__lastKnownInventoryCards = invCards;
      }
    }
    
    if (!invCards) return;

    if (!window.availableKizunas || window.availableKizunas.length === 0) {
      try {
        const cachedK = localStorage.getItem('kvr_kizunas_cache');
        if (cachedK) window.availableKizunas = JSON.parse(cachedK);
      } catch (e) {}
    }

    const currentT = userProfile.currentTitle || userProfile.title || 'Novato';
    const kizuna = getKizunaForTitle(currentT);
    if (kizuna) {
      const isActive = isKizunaActiveWithInventory(kizuna, invCards);
      if (!isActive) {
        console.log(`[PROFILE] ⚠️ El título equipado "${currentT}" pertenece al Kizuna inactivo "${kizuna.title}". Restableciendo a Novato.`);
        userProfile.title = 'Novato';
        userProfile.currentTitle = 'Novato';
        saveUserProfile();
        updateProfileDisplay();
      }
    }

    updateTitleSelector();
  } catch (err) {
    console.warn('[PROFILE] Error validando títulos de Kizuna:', err);
  }
}
window.validateEquippedTitleAndKizunas = validateEquippedTitleAndKizunas;

// Cargar títulos al inicio
loadTitles();

// Actualizar selector de títulos en el panel de edición
function updateTitleSelector() {
  if (!editTitleSelect) return;
  
  // Limpiar opciones
  editTitleSelect.innerHTML = '';
  
  // Asegurar que el usuario tenga el array de títulos desbloqueados
  if (!userProfile.unlockedTitles || !Array.isArray(userProfile.unlockedTitles)) {
    userProfile.unlockedTitles = ['novato'];
  }
  if (!userProfile.unlockedTitles.includes('novato')) {
    userProfile.unlockedTitles.push('novato');
  }

  const invCards = window.__lastKnownInventoryCards || null;
  
  // Filtrar títulos desbloqueados (matching por ID o Nombre) y ocultar los de Kizunas inactivos
  const unlockedTitles = availableTitles.filter(title => {
    const isUnlocked = userProfile.unlockedTitles.includes(title.id) ||
      userProfile.unlockedTitles.includes(title.name) ||
      (userProfile.currentTitle && (userProfile.currentTitle === title.name || userProfile.currentTitle === title.id)) ||
      (userProfile.title && (userProfile.title === title.name || userProfile.title === title.id));

    if (!isUnlocked) return false;

    // Si el título pertenece a un Kizuna, comprobar si el Kizuna está activo en el inventario
    const kizuna = getKizunaForTitle(title.id) || getKizunaForTitle(title.name);
    if (kizuna && invCards) {
      const isActive = isKizunaActiveWithInventory(kizuna, invCards);
      if (!isActive) {
        // Ocultar del selector mientras esté inactivo (NO se borra de unlockedTitles para conservarlo)
        return false;
      }
    }

    return true;
  });
  
  // Agregar opciones
  unlockedTitles.forEach(title => {
    if (!userProfile.unlockedTitles.includes(title.id)) {
      userProfile.unlockedTitles.push(title.id);
    }
    const option = document.createElement('option');
    option.value = title.id;
    option.textContent = title.name;
    const currentTitleId = availableTitles.find(t => t.name === userProfile.title || t.id === userProfile.title)?.id;
    if (title.id === currentTitleId || title.name === userProfile.title || title.id === userProfile.currentTitle || title.name === userProfile.currentTitle) {
      option.selected = true;
    }
    editTitleSelect.appendChild(option);
  });
  
  // Si no hay títulos desbloqueados o disponibles, agregar Novato
  if (unlockedTitles.length === 0 || editTitleSelect.options.length === 0) {
    const option = document.createElement('option');
    option.value = 'novato';
    option.textContent = 'Novato';
    option.selected = true;
    editTitleSelect.appendChild(option);
  }
}

// ==================== GALERÍA DE TÍTULOS EN COLECCIONABLES ====================

/**
 * Renderiza la pestaña de títulos en Coleccionables en el orden exacto de titles.json.
 * Muestra el recuadro en verde si el título está desbloqueado o con el color de su gradiente si está bloqueado.
 * Muestra la descripción del título y su unlockDescription.
 */
async function renderTitlesCollectibleView(forceRefresh = false) {
  const container = document.getElementById('collectibles-titles-grid');
  if (!container) return;

  if (forceRefresh || !Array.isArray(availableTitles) || availableTitles.length === 0) {
    container.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; color: #94a3b8; padding: 40px; font-size: 16px;">Cargando catálogo de títulos...</div>';
    await loadTitles(forceRefresh);
  }

  const titles = Array.isArray(window.availableTitles) && window.availableTitles.length > 0 ? window.availableTitles : availableTitles;
  if (!Array.isArray(titles) || titles.length === 0) {
    container.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; color: #ef4444; padding: 40px; font-size: 16px;">No se pudieron cargar los títulos del catálogo. Revisa tu conexión.</div>';
    return;
  }

  const escapeFn = typeof window.escapeHtml === 'function' ? window.escapeHtml : (s => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'));

  // Títulos desbloqueados del jugador
  let unlocked = [];
  if (window.userProfile && Array.isArray(window.userProfile.unlockedTitles)) {
    unlocked = window.userProfile.unlockedTitles;
  }
  if (!unlocked.includes('novato')) unlocked.push('novato');

  const currentTitleName = window.userProfile?.currentTitle || window.userProfile?.title || 'Novato';

  // Actualizar contador del encabezado
  const counterEl = document.getElementById('titles-unlocked-counter');
  const ownedCount = titles.filter(t => {
    return unlocked.includes(t.id) || unlocked.includes(t.name) || t.id === 'novato';
  }).length;
  if (counterEl) {
    counterEl.textContent = `${ownedCount} / ${titles.length} Desbloqueados`;
  }

  const fragment = document.createDocumentFragment();

  // Renderizado respetando el orden del json titles.json
  titles.forEach(title => {
    const isOwned = unlocked.includes(title.id) || unlocked.includes(title.name) || (title.id === 'novato');
    const isEquipped = (currentTitleName === title.name || currentTitleName === title.id) || (!window.userProfile?.currentTitle && title.id === 'novato');
    const gradient = title.gradient || 'linear-gradient(135deg, #4b5563, #374151)';
    const desc = title.description || title.desc || 'Sin descripción disponible.';
    const unlockDesc = title.unlockDescription || title.unlock_desc || title.howToUnlock || 'Condición de desbloqueo no especificada.';

    const card = document.createElement('div');
    card.className = `collectible-title-card ${isOwned ? 'owned' : 'locked'}`;

    // Si NO lo posee: el recuadro es del color del gradiente
    if (!isOwned) {
      card.style.background = `linear-gradient(135deg, rgba(30, 41, 59, 0.92) 0%, rgba(15, 23, 42, 0.96) 100%) padding-box, ${gradient} border-box`;
      card.style.border = '2px solid transparent';
    }

    const titleHtml = typeof window.formatTitleWithGradient === 'function'
      ? window.formatTitleWithGradient(title.name, gradient)
      : escapeFn(title.name);

    let actionBtnHtml = '';
    if (isOwned) {
      if (isEquipped) {
        actionBtnHtml = `<button class="title-card-action-btn equipped" disabled>✓ Equipado</button>`;
      } else {
        actionBtnHtml = `<button class="title-card-action-btn equip-btn" data-title-id="${escapeFn(title.id)}">Equipar Título</button>`;
      }
    }

    card.innerHTML = `
      <div>
        <div class="title-card-top">
          <span class="title-card-status-badge ${isOwned ? 'owned' : 'locked'}">
            ${isOwned ? '✓ Desbloqueado' : '🔒 Bloqueado'}
          </span>
        </div>
        <h4 class="title-card-title">${titleHtml}</h4>
        <p class="title-card-desc">${escapeFn(desc)}</p>
      </div>
      <div>
        <div class="title-card-unlock-section">
          <div class="title-card-unlock-header">
            <span class="unlock-icon">🎯</span>
            <span>Desbloqueo:</span>
          </div>
          <p class="title-card-unlock-text">${escapeFn(unlockDesc)}</p>
        </div>
        ${actionBtnHtml ? `<div class="title-card-footer">${actionBtnHtml}</div>` : ''}
      </div>
    `;

    // Conectar botón de equipar
    const equipBtn = card.querySelector('.title-card-action-btn.equip-btn');
    if (equipBtn) {
      equipBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await window.equipTitleFromCollectibles(title.id);
      });
    }

    fragment.appendChild(card);
  });

  container.innerHTML = '';
  container.appendChild(fragment);
}
window.renderTitlesCollectibleView = renderTitlesCollectibleView;

/**
 * Permite equipar un título directamente desde la galería de Coleccionables
 */
window.equipTitleFromCollectibles = async function(titleId) {
  if (!titleId || !window.userProfile) return;
  const titlesList = window.availableTitles || availableTitles || [];
  const title = titlesList.find(t => t.id === titleId || t.name === titleId);
  if (!title) return;

  const unlocked = Array.isArray(window.userProfile.unlockedTitles) ? window.userProfile.unlockedTitles : ['novato'];
  if (!unlocked.includes(title.id) && !unlocked.includes(title.name) && title.id !== 'novato') {
    alert('Aún no has desbloqueado este título.');
    return;
  }

  // Verificar Kizuna si corresponde
  const kizuna = getKizunaForTitle(title.id) || getKizunaForTitle(title.name);
  if (kizuna && window.__lastKnownInventoryCards) {
    if (!isKizunaActiveWithInventory(kizuna, window.__lastKnownInventoryCards)) {
      alert(`⚠️ No puedes equipar este título porque no tienes activas todas las cartas del Kizuna "${kizuna.name || kizuna.id}".`);
      return;
    }
  }

  window.userProfile.currentTitle = title.name;
  window.userProfile.title = title.name;

  if (typeof saveUserProfile === 'function') {
    await saveUserProfile();
  }
  if (typeof updateProfileDisplay === 'function') {
    updateProfileDisplay();
  }
  if (typeof updateTitleSelector === 'function') {
    updateTitleSelector();
  }
  const display = document.getElementById('profile-title-display');
  if (display && typeof window.applyTitleStyle === 'function') {
    window.applyTitleStyle(display, title.name);
  }

  renderTitlesCollectibleView();

  if (typeof playSFX === 'function') {
    playSFX('buttonClick');
  }
};

// Conectar botón de refrescar títulos
document.addEventListener('DOMContentLoaded', () => {
  const refreshBtn = document.getElementById('refresh-titles-btn');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      renderTitlesCollectibleView(true);
    });
  }
});

// Guardar cambios del perfil
async function handleSaveProfile() {
  // Obtener valores
  const selectedTitleId = editTitleSelect?.value || 'novato';
  const selectedTitle = availableTitles.find(t => t.id === selectedTitleId);
  const newDescription = editDescription?.value?.trim() || '';
  
  // Actualizar perfil
  userProfile.title = selectedTitle ? selectedTitle.name : 'Novato';
  userProfile.currentTitle = selectedTitle ? selectedTitle.name : 'Novato';
  userProfile.description = newDescription;
  
  // Guardar
  await saveUserProfile();
  
  // Actualizar UI
  updateProfileDisplay();
  
  // Volver a vista
  profileView.style.display = 'flex';
  profileEdit.style.display = 'none';
  
  // Mensaje
  alert('✅ Perfil actualizado correctamente');
}

// ==================== SISTEMA DE FONDOS DE PERFIL ====================

async function loadBackgrounds(forceRefresh = false) {
  // 1. Intentar cargar desde GitHub Pages del repo
  try {
    const res = await fetch(`${REMOTE_BACKGROUNDS_URL}?t=${Date.now()}`, { cache: 'no-store' });
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        const validList = data.filter(b => b && b.id && b.nombre);
        if (!validList.some(b => b.id === 'default')) {
          validList.unshift(DEFAULT_BACKGROUNDS[0]);
        }
        availableBackgrounds = validList;
        window.availableBackgrounds = availableBackgrounds;
        try { localStorage.setItem(BACKGROUNDS_CACHE_KEY, JSON.stringify(availableBackgrounds)); } catch {}
        console.log('[PROFILE] ✅ Fondos cargados desde GitHub remoto (Pages):', availableBackgrounds.length);
        return availableBackgrounds;
      }
    }
  } catch (e) {
    console.warn('[PROFILE] Error cargando fondos desde GitHub Pages, intentando Raw GitHub:', e?.message || e);
  }

  // 2. Fallback al Raw GitHub directo del repositorio
  try {
    const rawRes = await fetch(`${RAW_BACKGROUNDS_URL}?t=${Date.now()}`, { cache: 'no-store' });
    if (rawRes.ok) {
      const data = await rawRes.json();
      if (Array.isArray(data) && data.length > 0) {
        const validList = data.filter(b => b && b.id && b.nombre);
        if (!validList.some(b => b.id === 'default')) {
          validList.unshift(DEFAULT_BACKGROUNDS[0]);
        }
        availableBackgrounds = validList;
        window.availableBackgrounds = availableBackgrounds;
        try { localStorage.setItem(BACKGROUNDS_CACHE_KEY, JSON.stringify(availableBackgrounds)); } catch {}
        console.log('[PROFILE] ✅ Fondos cargados desde GitHub remoto (Raw):', availableBackgrounds.length);
        return availableBackgrounds;
      }
    }
  } catch (e) {
    console.warn('[PROFILE] Error cargando fondos desde GitHub Raw, intentando archivo local:', e?.message || e);
  }

  // 3. Fallback a archivo local fondos_perfil.json
  try {
    const localRes = await fetch(`./fondos_perfil.json?t=${Date.now()}`, { cache: 'no-store' });
    if (localRes.ok) {
      const data = await localRes.json();
      if (Array.isArray(data) && data.length > 0) {
        const validList = data.filter(b => b && b.id && b.nombre);
        if (!validList.some(b => b.id === 'default')) {
          validList.unshift(DEFAULT_BACKGROUNDS[0]);
        }
        availableBackgrounds = validList;
        window.availableBackgrounds = availableBackgrounds;
        try { localStorage.setItem(BACKGROUNDS_CACHE_KEY, JSON.stringify(availableBackgrounds)); } catch {}
        console.log('[PROFILE] ✅ Fondos cargados desde archivo local:', availableBackgrounds.length);
        return availableBackgrounds;
      }
    }
  } catch (e) {
    console.warn('[PROFILE] Error cargando fondos locales:', e?.message || e);
  }

  // Fallback seguro con DEFAULT_BACKGROUNDS
  availableBackgrounds = DEFAULT_BACKGROUNDS.map(b => ({ ...b }));
  window.availableBackgrounds = availableBackgrounds;
  try { localStorage.setItem(BACKGROUNDS_CACHE_KEY, JSON.stringify(availableBackgrounds)); } catch {}
  return availableBackgrounds;
}
window.loadBackgrounds = loadBackgrounds;

function getBackgroundById(bgId) {
  const id = String(bgId || 'default').trim();
  let list = Array.isArray(availableBackgrounds) && availableBackgrounds.length > 0 ? availableBackgrounds : DEFAULT_BACKGROUNDS;
  if (list.length <= 1) {
    try {
      const cached = JSON.parse(localStorage.getItem(BACKGROUNDS_CACHE_KEY));
      if (Array.isArray(cached) && cached.length > 0) {
        list = cached;
        availableBackgrounds = cached;
        window.availableBackgrounds = cached;
      }
    } catch {}
  }
  const found = list.find(b => b && (b.id === id || String(b.id).toLowerCase() === id.toLowerCase()));
  if (found) return found;

  const fallbackFound = DEFAULT_BACKGROUNDS.find(b => b && (b.id === id || String(b.id).toLowerCase() === id.toLowerCase()));
  if (fallbackFound) return fallbackFound;

  // Si id empieza con http o ./, usarlo directamente
  if (id.startsWith('http://') || id.startsWith('https://') || id.startsWith('./') || id.startsWith('/')) {
    return { id, nombre: 'Fondo Personalizado', imagen: id, descripcion: 'Fondo personalizado.' };
  }

  return DEFAULT_BACKGROUNDS[0] || { id: 'default', nombre: 'Predeterminado KVR', imagen: './assets/backgrounds/bg_default.svg', descripcion: 'El fondo clásico oficial de KVRCards.' };
}
window.getBackgroundById = getBackgroundById;

function applyProfileBackground(element, bgId = null) {
  if (!element) return;
  const targetId = bgId || userProfile?.currentBackground || 'default';
  const bg = getBackgroundById(targetId);
  const imgUrl = bg.imagen || bg.image || bg.imageUrl || './assets/backgrounds/bg_default.svg';

  element.classList.add('has-custom-bg');
  // Opacidad del fondo al 80% (20% de velo oscuro para equilibrar arte y legibilidad)
  element.style.setProperty('background-image', `linear-gradient(rgba(15, 23, 42, 0.20), rgba(15, 23, 42, 0.20)), url("${imgUrl}")`, 'important');
  element.style.setProperty('background-color', '#0b0f19', 'important');
  element.style.setProperty('background-size', 'cover', 'important');
  element.style.setProperty('background-position', 'center center', 'important');
  element.style.setProperty('background-repeat', 'no-repeat', 'important');
  element.style.setProperty('background-attachment', 'local', 'important');
}
window.applyProfileBackground = applyProfileBackground;

function applyProfileBoxStyle(boxElement, bgId = null) {
  if (!boxElement) return;
  const targetId = bgId || (typeof userProfile !== 'undefined' ? userProfile?.currentBackground : 'default');
  const bg = typeof window.getBackgroundById === 'function' ? window.getBackgroundById(targetId) : null;

  const customBoxBg = bg?.boxColor || bg?.boxBackground || bg?.cardColor || bg?.colorRecuadro || bg?.fondoRecuadro || bg?.recuadroColor || null;
  const customBorder = bg?.borderColor || bg?.boxBorder || bg?.bordeRecuadro || bg?.bordeColor || null;
  const customShadow = bg?.boxShadow || bg?.sombraRecuadro || bg?.boxGlow || null;

  const parentModal = boxElement.closest('.modal-backdrop, .user-profile-modal') || (boxElement.classList.contains('user-profile-modal') ? boxElement : null);

  if (customBoxBg) {
    boxElement.style.setProperty('background', customBoxBg, 'important');
  } else {
    boxElement.style.removeProperty('background');
  }

  if (customBorder) {
    boxElement.style.setProperty('border-color', customBorder, 'important');
    boxElement.style.setProperty('--profile-custom-border-color', customBorder);
    boxElement.style.setProperty('--profile-custom-border-glow', `${customBorder}88`);
    boxElement.style.setProperty('scrollbar-color', `${customBorder} #080c14`);
    boxElement.classList.add('has-custom-border');
    if (parentModal) {
      parentModal.style.setProperty('--profile-custom-border-color', customBorder);
      parentModal.style.setProperty('--profile-custom-border-glow', `${customBorder}88`);
      parentModal.classList.add('has-custom-border');
    }
  } else {
    boxElement.style.removeProperty('border-color');
    boxElement.style.removeProperty('--profile-custom-border-color');
    boxElement.style.removeProperty('--profile-custom-border-glow');
    boxElement.style.removeProperty('scrollbar-color');
    boxElement.classList.remove('has-custom-border');
    if (parentModal) {
      parentModal.style.removeProperty('--profile-custom-border-color');
      parentModal.style.removeProperty('--profile-custom-border-glow');
      parentModal.classList.remove('has-custom-border');
    }
  }

  if (customShadow) {
    boxElement.style.setProperty('box-shadow', customShadow, 'important');
  } else {
    boxElement.style.removeProperty('box-shadow');
  }

  // Círculo que rodea la foto de perfil (avatar)
  const scopeEl = parentModal || boxElement;
  const avatarElements = scopeEl.querySelectorAll(
    '.user-profile-avatar-large img, .profile-modal-placeholder, #bg-preview-avatar, #bg-preview-avatar-placeholder, #profile-modal-avatar, #profile-modal-avatar-placeholder, .profile-avatar-img-large, .profile-avatar-placeholder-large'
  );
  avatarElements.forEach(el => {
    if (customBorder) {
      el.style.setProperty('border-color', customBorder, 'important');
      el.style.setProperty('box-shadow', `0 0 25px ${customBorder}88`, 'important');
    } else {
      el.style.removeProperty('border-color');
      el.style.removeProperty('box-shadow');
    }
  });

  // Nombre del perfil
  const usernameElements = scopeEl.querySelectorAll(
    '#profile-modal-username, #bg-preview-username, #profile-username-display, .profile-username-large'
  );
  usernameElements.forEach(el => {
    if (customBorder) {
      el.style.setProperty('background', `linear-gradient(135deg, #ffffff 0%, ${customBorder} 65%, ${customBorder} 100%)`, 'important');
      el.style.setProperty('-webkit-background-clip', 'text', 'important');
      el.style.setProperty('-webkit-text-fill-color', 'transparent', 'important');
      el.style.setProperty('background-clip', 'text', 'important');
      el.style.setProperty('color', customBorder, 'important');
      el.style.setProperty('filter', `drop-shadow(0 2px 8px ${customBorder}66)`, 'important');
    } else {
      el.style.removeProperty('background');
      el.style.removeProperty('-webkit-background-clip');
      el.style.removeProperty('-webkit-text-fill-color');
      el.style.removeProperty('background-clip');
      el.style.removeProperty('color');
      el.style.removeProperty('filter');
    }
  });
}
window.applyProfileBoxStyle = applyProfileBoxStyle;

function updateBackgroundEditPreview() {
  const currentBgId = userProfile.currentBackground || 'default';
  const bg = getBackgroundById(currentBgId);
  if (profileBgCurrentName) {
    profileBgCurrentName.textContent = bg.nombre || bg.name || 'Predeterminado KVR';
  }
  if (profileBgCurrentPreview) {
    const imgUrl = bg.imagen || bg.image || bg.imageUrl || './assets/backgrounds/bg_default.svg';
    profileBgCurrentPreview.style.backgroundImage = `linear-gradient(rgba(15, 23, 42, 0.3), rgba(15, 23, 42, 0.6)), url("${imgUrl}")`;
  }
}

async function unlockProfileBackground(bgId) {
  if (!bgId) return;
  const id = String(bgId).trim();
  if (!Array.isArray(userProfile.unlockedBackgrounds)) {
    userProfile.unlockedBackgrounds = ['default'];
  }
  if (!userProfile.unlockedBackgrounds.includes(id)) {
    userProfile.unlockedBackgrounds.push(id);
    await saveUserProfile();
    console.log('[PROFILE] ✅ Fondo desbloqueado:', id);
    updateBackgroundEditPreview();
    if (typeof window.showToastNotification === 'function') {
      const bg = getBackgroundById(id);
      window.showToastNotification(`🖼️ ¡Nuevo fondo de perfil desbloqueado: ${bg.nombre || id}!`, 'success');
    }
  }
}
window.unlockProfileBackground = unlockProfileBackground;

function openBackgroundSelectorModal() {
  if (!backgroundSelectorModal) return;
  backgroundSelectorModal.style.display = 'flex';
  renderBackgroundSelectorGrid();
}

function closeBackgroundSelectorModal() {
  if (!backgroundSelectorModal) return;
  backgroundSelectorModal.style.display = 'none';
}

function renderBackgroundSelectorGrid() {
  if (!backgroundSelectorGrid) return;
  backgroundSelectorGrid.innerHTML = '';

  const unlocked = Array.isArray(userProfile.unlockedBackgrounds) ? userProfile.unlockedBackgrounds : ['default'];
  const currentBgId = userProfile.currentBackground || 'default';

  const allList = Array.isArray(availableBackgrounds) && availableBackgrounds.length > 0
    ? availableBackgrounds
    : [{ id: 'default', nombre: 'Predeterminado KVR', imagen: './assets/backgrounds/bg_default.svg', descripcion: 'Fondo oficial predeterminado.' }];

  // Solo mostrar los fondos que el usuario tiene desbloqueados
  const list = allList.filter(bg =>
    bg.id === 'default' || unlocked.includes(bg.id) || unlocked.includes(String(bg.id).toLowerCase())
  );

  if (list.length === 0) {
    backgroundSelectorGrid.innerHTML = '<div style="color:#9ca3af;text-align:center;padding:24px;">No tienes fondos desbloqueados todavía.<br>Consíguelos en misiones, kizunas o prestigios.</div>';
    return;
  }

  list.forEach(bg => {
    const isEquipped = currentBgId === bg.id || (currentBgId === 'default' && bg.id === 'default');
    const imgUrl = bg.imagen || bg.image || bg.imageUrl || './assets/backgrounds/bg_default.svg';
    const name = bg.nombre || bg.name || bg.id;
    const desc = bg.descripcion || bg.description || 'Fondo desbloqueado';

    const card = document.createElement('div');
    card.className = `background-card ${isEquipped ? 'equipped' : ''}`;

    const actionBtnHtml = isEquipped
      ? '<button type="button" class="background-card-btn btn-equipped">✓ Equipado</button>'
      : `<button type="button" class="background-card-btn btn-equip" data-bg-id="${bg.id}">Equipar</button>`;

    card.innerHTML = `
      <div class="background-card-thumb" style="background-image: url('${imgUrl}');"></div>
      <div class="background-card-body">
        <div class="background-card-name">${name}</div>
        <div class="background-card-desc">${desc}</div>
        ${actionBtnHtml}
      </div>
    `;

    const equipBtn = card.querySelector('.btn-equip');
    if (equipBtn) {
      equipBtn.addEventListener('click', async () => {
        userProfile.currentBackground = bg.id;
        await saveUserProfile();
        applyProfileBackground(profileModal, bg.id);
        updateBackgroundEditPreview();
        renderBackgroundSelectorGrid();
      });
    }

    backgroundSelectorGrid.appendChild(card);
  });
}

// Listeners de Fondos de Perfil
openBackgroundSelectorBtn?.addEventListener('click', openBackgroundSelectorModal);
backgroundSelectorClose?.addEventListener('click', closeBackgroundSelectorModal);
backgroundSelectorModal?.addEventListener('click', (e) => {
  if (e.target === backgroundSelectorModal) closeBackgroundSelectorModal();
});
loadBackgrounds().catch(console.error);

// ==================== GALERÍA DE FONDOS EN COLECCIONABLES ====================

/**
 * Renderiza la pestaña de fondos en Coleccionables.
 * Muestra las tarjetas con thumbnail en miniatura, descripción, desbloqueo y botones de acción.
 */
async function renderBackgroundsCollectibleView(forceRefresh = false) {
  const container = document.getElementById('collectibles-backgrounds-grid');
  if (!container) return;

  if (forceRefresh || !Array.isArray(availableBackgrounds) || availableBackgrounds.length === 0) {
    container.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; color: #94a3b8; padding: 40px; font-size: 16px;">Cargando catálogo de fondos...</div>';
    await loadBackgrounds(forceRefresh);
  }

  const backgrounds = Array.isArray(window.availableBackgrounds) && window.availableBackgrounds.length > 0
    ? window.availableBackgrounds
    : (Array.isArray(availableBackgrounds) && availableBackgrounds.length > 0 ? availableBackgrounds : DEFAULT_BACKGROUNDS);

  if (!Array.isArray(backgrounds) || backgrounds.length === 0) {
    container.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; color: #ef4444; padding: 40px; font-size: 16px;">No se pudieron cargar los fondos del catálogo. Revisa tu conexión.</div>';
    return;
  }

  const escapeFn = typeof window.escapeHtml === 'function' ? window.escapeHtml : (s => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'));

  // Fondos desbloqueados del jugador
  let unlocked = [];
  if (window.userProfile && Array.isArray(window.userProfile.unlockedBackgrounds)) {
    unlocked = window.userProfile.unlockedBackgrounds.map(id => String(id).toLowerCase());
  }
  if (!unlocked.includes('default')) unlocked.push('default');

  const currentBgId = String(window.userProfile?.currentBackground || 'default').toLowerCase();

  // Actualizar contador del encabezado
  const counterEl = document.getElementById('backgrounds-unlocked-counter');
  const ownedCount = backgrounds.filter(bg => {
    const bgId = String(bg.id || '').toLowerCase();
    return bgId === 'default' || bg.unlockedByDefault || unlocked.includes(bgId);
  }).length;
  if (counterEl) {
    counterEl.textContent = `${ownedCount} / ${backgrounds.length} Desbloqueados`;
  }

  const fragment = document.createDocumentFragment();

  backgrounds.forEach(bg => {
    const bgIdLower = String(bg.id || '').toLowerCase();
    const isOwned = bgIdLower === 'default' || bg.unlockedByDefault || unlocked.includes(bgIdLower);
    const isEquipped = currentBgId === bgIdLower;
    const imgUrl = bg.imagen || bg.image || bg.imageUrl || './assets/backgrounds/bg_default.svg';
    const name = bg.nombre || bg.name || bg.id;
    const desc = bg.descripcion || bg.description || bg.unlockDescription || (isOwned ? 'Desbloqueado por defecto.' : 'Condición especial de obtención.');

    const card = document.createElement('div');
    card.className = `collectible-background-card ${isOwned ? 'owned' : 'locked'}`;

    let equipBtnHtml = '';
    if (isOwned) {
      if (isEquipped) {
        equipBtnHtml = `<button type="button" class="title-card-action-btn equipped" disabled>✓ Equipado</button>`;
      } else {
        equipBtnHtml = `<button type="button" class="title-card-action-btn equip-bg-btn" data-bg-id="${escapeFn(bg.id)}">Equipar Fondo</button>`;
      }
    }

    card.innerHTML = `
      <div>
        <div class="title-card-top">
          <span class="title-card-status-badge ${isOwned ? 'owned' : 'locked'}">
            ${isOwned ? '✓ Desbloqueado' : '🔒 Bloqueado'}
          </span>
        </div>

        <div class="background-card-thumb-wrap" data-bg-id="${escapeFn(bg.id)}" title="Haz clic para ver una vista previa con tu perfil">
          <div class="background-card-thumb" style="background-image: url('${escapeFn(imgUrl)}');"></div>
          <div class="background-card-thumb-overlay">
            <span>👁️ Vista Previa</span>
          </div>
          <span class="background-card-thumb-badge">Clic para probar</span>
        </div>

        <h4 class="background-card-title">${escapeFn(name)}</h4>
      </div>

      <div>
        <div class="title-card-unlock-section">
          <div class="title-card-unlock-header">
            <span class="unlock-icon">🎯</span>
            <span>Desbloqueo:</span>
          </div>
          <p class="title-card-unlock-text">${escapeFn(desc)}</p>
        </div>

        <div class="background-card-footer">
          <button type="button" class="background-preview-action-btn" data-bg-id="${escapeFn(bg.id)}" title="Previsualizar tu perfil con este fondo">
            👁️ Ver Perfil
          </button>
          ${equipBtnHtml}
        </div>
      </div>
    `;

    // Conectar clic en thumbnail para abrir vista previa
    const thumbWrap = card.querySelector('.background-card-thumb-wrap');
    if (thumbWrap) {
      thumbWrap.addEventListener('click', (e) => {
        e.stopPropagation();
        openBackgroundProfilePreview(bg.id);
      });
    }

    // Conectar botón de vista previa
    const previewBtn = card.querySelector('.background-preview-action-btn');
    if (previewBtn) {
      previewBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        openBackgroundProfilePreview(bg.id);
      });
    }

    // Conectar botón de equipar
    const equipBtn = card.querySelector('.title-card-action-btn.equip-bg-btn');
    if (equipBtn) {
      equipBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        await window.equipBackgroundFromCollectibles(bg.id);
      });
    }

    fragment.appendChild(card);
  });

  container.innerHTML = '';
  container.appendChild(fragment);
}
window.renderBackgroundsCollectibleView = renderBackgroundsCollectibleView;

/**
 * Abre la vista previa del perfil con un fondo aplicado de forma estrictamente visual.
 * NO modifica userProfile.currentBackground ni guarda nada en el perfil real.
 */
async function openBackgroundProfilePreview(bgId) {
  const modal = document.getElementById('bg-preview-modal');
  if (!modal) {
    console.error('[PROFILE] Modal bg-preview-modal no encontrado');
    return;
  }

  const bg = getBackgroundById(bgId);

  // 1. Nombre de usuario
  const username = currentUser || localStorage.getItem('kvrUsername') || 'Usuario';
  const usernameEl = document.getElementById('bg-preview-username');
  if (usernameEl) usernameEl.textContent = username;

  // 2. Avatar
  const avatarToUse = userAvatar || userProfile?.profileImage || (currentUser ? localStorage.getItem('kvrAvatar_' + currentUser) : '');
  const avatarImg = document.getElementById('bg-preview-avatar');
  const placeholder = document.getElementById('bg-preview-avatar-placeholder');
  if (avatarToUse && avatarImg) {
    avatarImg.src = avatarToUse;
    avatarImg.style.display = 'block';
    if (placeholder) placeholder.style.display = 'none';
  } else if (avatarImg) {
    avatarImg.style.display = 'none';
    if (placeholder) placeholder.style.display = 'flex';
  }

  // 3. Título actual
  const currentTitle = userProfile?.currentTitle || userProfile?.title || 'Novato';
  const titleEl = document.getElementById('bg-preview-title');
  if (titleEl) {
    titleEl.textContent = `"${currentTitle}"`;
    titleEl.style.display = 'block';
    if (typeof window.applyTitleStyle === 'function') {
      window.applyTitleStyle(titleEl, currentTitle);
    }
  }

  // 4. Estadísticas
  const statCardsEl = document.getElementById('bg-preview-stat-cards');
  const statPacksEl = document.getElementById('bg-preview-stat-packs');
  const statCoinsEl = document.getElementById('bg-preview-stat-coins');
  const statUniqueEl = document.getElementById('bg-preview-stat-unique');

  const totalCards = userProfile?.stats?.totalCardsObtained || 0;
  const totalPacks = userProfile?.stats?.totalPacksOpened || 0;
  const totalCoins = userProfile?.stats?.totalCoinsEarned || 0;
  let uniqueCards = 0;
  if (window.__lastKnownInventoryCards) {
    uniqueCards = Object.values(window.__lastKnownInventoryCards).filter(count => count > 0).length;
  } else if (userProfile?.stats?.uniqueCards) {
    uniqueCards = userProfile.stats.uniqueCards;
  }

  if (statCardsEl) statCardsEl.textContent = totalCards.toLocaleString();
  if (statPacksEl) statPacksEl.textContent = totalPacks.toLocaleString();
  if (statCoinsEl) statCoinsEl.textContent = totalCoins.toLocaleString();
  if (statUniqueEl) statUniqueEl.textContent = uniqueCards.toLocaleString();

  // 5. Estadísticas semanales
  const weeklyCardsEl = document.getElementById('bg-preview-weekly-cards');
  const weeklyPacksEl = document.getElementById('bg-preview-weekly-packs');
  const weeklyCoinsEl = document.getElementById('bg-preview-weekly-coins');
  if (weeklyCardsEl) weeklyCardsEl.textContent = (userProfile?.weeklyStats?.cards || 0).toLocaleString();
  if (weeklyPacksEl) weeklyPacksEl.textContent = (userProfile?.weeklyStats?.packs || 0).toLocaleString();
  if (weeklyCoinsEl) weeklyCoinsEl.textContent = (userProfile?.weeklyStats?.coins || 0).toLocaleString();

  // 6. Showcase de cartas
  const showcaseGrid = document.getElementById('bg-preview-showcase-grid');
  if (showcaseGrid) {
    showcaseGrid.innerHTML = '';
    const showcase = Array.isArray(userProfile?.showcaseCards) ? userProfile.showcaseCards : [null, null, null];
    let allCards = [];
    if (window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
      try { allCards = await window.kvrcards.getAllCards(); } catch {}
    }

    let hasAnyCard = false;
    for (let i = 0; i < 3; i++) {
      const cardEntry = showcase[i];
      if (cardEntry) {
        hasAnyCard = true;
        let cardObj = typeof cardEntry === 'object' ? cardEntry : (allCards.find(c => c.id === cardEntry) || { id: cardEntry, name: 'Carta' });
        const cardDiv = document.createElement('div');
        cardDiv.className = 'profile-showcase-card';
        const img = document.createElement('img');
        img.src = cardObj.imageUrl || cardObj.image || '';
        img.alt = cardObj.name || 'Carta';
        img.loading = 'lazy';
        img.onerror = function() { this.style.display = 'none'; };
        const nameDiv = document.createElement('div');
        nameDiv.className = 'profile-showcase-card-name';
        nameDiv.textContent = cardObj.name || 'Carta';
        cardDiv.appendChild(img);
        cardDiv.appendChild(nameDiv);
        showcaseGrid.appendChild(cardDiv);
      } else {
        const emptySlot = document.createElement('div');
        emptySlot.className = 'profile-showcase-empty-slot';
        emptySlot.innerHTML = `
          <div class="profile-showcase-empty-slot-icon">🃏</div>
          <div class="profile-showcase-empty-slot-text">Sin carta</div>
        `;
        showcaseGrid.appendChild(emptySlot);
      }
    }

    if (!hasAnyCard) {
      showcaseGrid.innerHTML = `
        <div class="profile-showcase-empty">
          <div class="profile-showcase-empty-icon">⭐</div>
          <div>Aún no has configurado cartas destacadas en tu perfil</div>
        </div>
      `;
    }
  }

  // 7. Aplicar fondo y estilo de recuadro ÚNICAMENTE al modal de vista previa
  applyProfileBackground(modal, bg.id);
  const contentBox = modal.querySelector('.bg-preview-content');
  if (contentBox && typeof applyProfileBoxStyle === 'function') {
    applyProfileBoxStyle(contentBox, bg.id);
  }

  // 8. Actualizar nombre de fondo en banner y footer
  const currentNameEl = document.getElementById('bg-preview-current-name');
  if (currentNameEl) {
    currentNameEl.textContent = `Fondo en vista previa: ${bg.nombre || bg.name || bg.id}`;
  }

  // Mostrar modal con display flex
  modal.style.display = 'flex';
  modal.classList.add('show');

  // Cerrar al pulsar en el fondo
  modal.onclick = (e) => {
    if (e.target === modal) {
      closeBackgroundProfilePreview();
    }
  };
}
window.openBackgroundProfilePreview = openBackgroundProfilePreview;

function closeBackgroundProfilePreview() {
  const modal = document.getElementById('bg-preview-modal');
  if (modal) {
    modal.style.display = 'none';
    modal.classList.remove('show');
    modal.classList.remove('has-custom-bg');
    modal.classList.remove('has-custom-border');
    modal.style.backgroundImage = '';
    const contentBox = modal.querySelector('.bg-preview-content');
    if (contentBox && typeof applyProfileBoxStyle === 'function') {
      applyProfileBoxStyle(contentBox, 'default');
    }
  }
}
window.closeBackgroundProfilePreview = closeBackgroundProfilePreview;

/**
 * Permite equipar un fondo de perfil directamente desde la galería de Coleccionables
 */
window.equipBackgroundFromCollectibles = async function(bgId) {
  if (!bgId || !window.userProfile) return;
  const id = String(bgId).trim();
  const unlocked = Array.isArray(window.userProfile.unlockedBackgrounds) ? window.userProfile.unlockedBackgrounds : ['default'];
  const isOwned = id === 'default' || unlocked.includes(id) || unlocked.includes(id.toLowerCase());
  if (!isOwned) {
    alert('Aún no has desbloqueado este fondo de perfil.');
    return;
  }

  window.userProfile.currentBackground = id;
  if (typeof saveUserProfile === 'function') {
    await saveUserProfile();
  }
  if (typeof updateProfileDisplay === 'function') {
    updateProfileDisplay();
  }

  renderBackgroundsCollectibleView();

  if (typeof playSFX === 'function') {
    playSFX('buttonClick');
  }
};

// Conectar botón de refrescar fondos
document.addEventListener('DOMContentLoaded', () => {
  const refreshBgBtn = document.getElementById('refresh-backgrounds-btn');
  if (refreshBgBtn) {
    refreshBgBtn.addEventListener('click', () => {
      renderBackgroundsCollectibleView(true);
    });
  }
});

// ==================== SHOWCASE DE CARTAS ====================

// Actualizar showcase en el perfil (modo vista)
async function updateShowcaseDisplay() {
  const slots = document.querySelectorAll('.showcase-slot');
  if (!slots || slots.length === 0) {
    console.warn('[SHOWCASE] No showcase slots found');
    return;
  }
  
  // Asegurar que showcaseCards existe
  if (!userProfile.showcaseCards) {
    userProfile.showcaseCards = [null, null, null];
  }
  
  for (let index = 0; index < slots.length; index++) {
    const slot = slots[index];
    const cardId = userProfile.showcaseCards[index];
    slot.innerHTML = ''; // Limpiar
    
    if (cardId) {
      try {
        // Obtener carta del backend
        const cards = await window.kvrcards.getAllCards();
        const card = cards.find(c => c.id === cardId);
        
        if (card && card.imageUrl) {
          const img = document.createElement('img');
          img.src = card.imageUrl;
          img.classList.add('showcase-card-img');
          img.alt = card.name || 'Carta';
          img.title = 'Haz clic para ampliar';
          
          // Agregar evento click para zoom
          img.addEventListener('click', (e) => {
            e.stopPropagation();
            openCardZoom(card.imageUrl);
          });
          
          slot.appendChild(img);
        } else {
          slot.innerHTML = '<div class="showcase-empty">?</div>';
        }
      } catch (e) {
        console.error('[SHOWCASE] Error loading card:', e);
        slot.innerHTML = '<div class="showcase-empty">?</div>';
      }
    } else {
      slot.innerHTML = '<div class="showcase-empty">+</div>';
    }
  }
}

// Actualizar showcase en modo edición
async function updateShowcaseEdit() {
  const editSlots = document.querySelectorAll('.showcase-edit-slot');
  if (!editSlots || editSlots.length === 0) {
    console.warn('[SHOWCASE] No showcase edit slots found');
    return;
  }
  
  // Asegurar que showcaseCards existe
  if (!userProfile.showcaseCards) {
    userProfile.showcaseCards = [null, null, null];
  }
  
  for (let index = 0; index < editSlots.length; index++) {
    const slot = editSlots[index];
    const cardId = userProfile.showcaseCards[index];
    slot.innerHTML = ''; // Limpiar
    
    if (cardId) {
      try {
        const cards = await window.kvrcards.getAllCards();
        const card = cards.find(c => c.id === cardId);
        
        if (card && card.imageUrl) {
          const img = document.createElement('img');
          img.src = card.imageUrl;
          img.classList.add('showcase-card-img');
          img.alt = card.name || 'Carta';
          slot.appendChild(img);
          
          // Botón para eliminar
          const removeBtn = document.createElement('button');
          removeBtn.classList.add('showcase-remove-btn');
          removeBtn.innerHTML = '×';
          removeBtn.onclick = async (e) => {
            e.stopPropagation();
            userProfile.showcaseCards[index] = null;
            await updateShowcaseEdit();
            await saveUserProfile(); // Guardar perfil en backend
          };
          slot.appendChild(removeBtn);
          
          slot.classList.add('has-card');
        } else {
          slot.innerHTML = '<div class="showcase-empty">+</div>';
          slot.classList.remove('has-card');
        }
      } catch (e) {
        console.error('[SHOWCASE] Error loading card:', e);
        slot.innerHTML = '<div class="showcase-empty">+</div>';
        slot.classList.remove('has-card');
      }
    } else {
      slot.innerHTML = '<div class="showcase-empty">+</div>';
      slot.classList.remove('has-card');
    }
  }
}

// Abrir modal de selección de carta
async function openCardSelector(slotIndex) {
  currentShowcaseSlot = slotIndex;
  
  const selectorModal = document.getElementById('card-selector-modal');
  const selectorGrid = document.getElementById('card-selector-grid');
  
  if (!selectorModal || !selectorGrid) {
    console.error('[SHOWCASE] Card selector elements not found');
    return;
  }
  
  // Cargar inventario y catálogo
  try {
    const [inventory, allCards] = await Promise.all([
      window.kvrcards.getInventory(),
      window.kvrcards.getAllCards()
    ]);
    
    if (!inventory || !inventory.cards) {
      alert('❌ No se pudo cargar el inventario');
      return;
    }
    
    // Obtener todas las cartas del inventario
    const ownedCardIds = Object.keys(inventory.cards);
    
    if (ownedCardIds.length === 0) {
      alert('❌ No tienes cartas en tu inventario');
      return;
    }
    
    // Crear array de cartas con sus datos y ordenar por media (rating)
    const ownedCards = ownedCardIds
      .map(cardId => {
        const card = allCards.find(c => c.id === cardId);
        const count = inventory.cards[cardId];
        return card ? { card, count, cardId } : null;
      })
      .filter(item => item !== null)
      .sort((a, b) => {
        // Ordenar por rating de mayor a menor
        const ratingA = parseInt(a.card.rating) || 0;
        const ratingB = parseInt(b.card.rating) || 0;
        return ratingB - ratingA;
      });
    
    // Renderizar grid de cartas
    selectorGrid.innerHTML = '';
    
    ownedCards.forEach(({ card, count, cardId }) => {
      const item = document.createElement('div');
      item.classList.add('card-selector-item');
      item.dataset.cardId = cardId;
      
      if (card.imageUrl) {
        const img = document.createElement('img');
        img.src = card.imageUrl;
        img.alt = card.name || 'Carta';
        item.appendChild(img);
      }
      
      // Mostrar cantidad
      const countLabel = document.createElement('div');
      countLabel.classList.add('card-selector-count');
      countLabel.textContent = `×${count}`;
      item.appendChild(countLabel);
      
      // Guardar info de la carta en el elemento
      item._cardData = card;
      
      // Click para seleccionar
      item.addEventListener('click', () => selectShowcaseCard(cardId));
      
      selectorGrid.appendChild(item);
    });
    
    // Mostrar modal
    selectorModal.style.display = 'flex';
    
  } catch (e) {
    console.error('[SHOWCASE] Error loading cards:', e);
    alert('❌ Error al cargar las cartas');
  }
}

// Seleccionar carta para el showcase
async function selectShowcaseCard(cardId) {
  if (currentShowcaseSlot === null) return;
  
  const selectorModal = document.getElementById('card-selector-modal');
  
  userProfile.showcaseCards[currentShowcaseSlot] = cardId;
  await updateShowcaseEdit();
  
  // Guardar perfil en backend
  await saveUserProfile();
  
  // Cerrar modal
  if (selectorModal) selectorModal.style.display = 'none';
  currentShowcaseSlot = null;
}

// Abrir zoom de carta
function openCardZoom(imageUrl) {
  if (!cardZoomModal || !cardZoomImage) return;
  
  cardZoomImage.src = imageUrl;
  cardZoomModal.style.display = 'flex';
  console.log('[SHOWCASE] Zoom opened for:', imageUrl);
}

// Cerrar zoom de carta
function closeCardZoom() {
  if (!cardZoomModal) return;
  
  cardZoomModal.style.display = 'none';
  cardZoomImage.src = '';
  console.log('[SHOWCASE] Zoom closed');
}

// ==================== BENDICIÓN DEL SUPPORTER: HUD Y RECLAMO DIARIO ====================

window.updateProfileBlessingUI = async function() {
  const hudRow = document.getElementById('hud-blessing-row');
  const hudClaimBtn = document.getElementById('hud-claim-blessing-btn');
  const hudTextSpan = document.getElementById('hud-blessing-text');

  const profileRow = document.getElementById('profile-blessing-row');
  const profileClaimBtn = document.getElementById('profile-claim-blessing-btn');
  const profileSubtext = document.getElementById('profile-blessing-subtext');

  if (!window.kvrcards || typeof window.kvrcards.getBlessingStatus !== 'function') {
    if (hudRow) hudRow.style.display = 'none';
    if (profileRow) profileRow.style.display = 'none';
    return;
  }

  try {
    const res = await window.kvrcards.getBlessingStatus();
    console.log('[BLESSING UI] Estado recibido:', res);
    if (!res || !res.ok || !res.active || res.daysRemaining <= 0) {
      if (hudRow) hudRow.style.display = 'none';
      if (profileRow) profileRow.style.display = 'none';
      return;
    }

    if (hudRow) hudRow.style.display = 'block';
    if (profileRow) profileRow.style.display = 'block';

    if (res.canClaimToday) {
      if (hudClaimBtn) {
        hudClaimBtn.disabled = false;
        hudClaimBtn.className = 'hud-blessing-btn can-claim';
        hudClaimBtn.title = 'Haz clic para reclamar tus 30 KvR diarios de hoy';
      }
      if (hudTextSpan) {
        hudTextSpan.textContent = `Reclamar bendición (${res.daysRemaining} días)`;
      }

      if (profileClaimBtn) {
        profileClaimBtn.disabled = false;
        profileClaimBtn.className = 'profile-claim-blessing-btn can-claim';
        profileClaimBtn.textContent = '✨ Reclamar 30 KvR';
        profileClaimBtn.title = 'Haz clic para reclamar tus 30 KvR diarios de hoy';
      }
      if (profileSubtext) {
        profileSubtext.textContent = `${res.daysRemaining} días restantes • ¡Disponible para reclamar hoy!`;
      }
    } else {
      if (hudClaimBtn) {
        hudClaimBtn.disabled = true;
        hudClaimBtn.className = 'hud-blessing-btn already-claimed';
        hudClaimBtn.title = 'Ya has reclamado los 30 KvR de hoy. El contador se reinicia a las 06:00 AM hora Madrid.';
      }
      if (hudTextSpan) {
        hudTextSpan.textContent = `Reclamado hoy (${res.daysRemaining} días)`;
      }

      if (profileClaimBtn) {
        profileClaimBtn.disabled = true;
        profileClaimBtn.className = 'profile-claim-blessing-btn already-claimed';
        profileClaimBtn.textContent = '✔️ Reclamado hoy';
        profileClaimBtn.title = 'Ya has reclamado los 30 KvR de hoy. Se reinicia a las 06:00 AM hora Madrid.';
      }
      if (profileSubtext) {
        profileSubtext.textContent = `${res.daysRemaining} días restantes • Vuelve mañana a partir de las 06:00 AM`;
      }
    }
  } catch (err) {
    console.error('[BLESSING UI] Error consultando estado:', err);
  }
};

async function handleClaimBlessingClick(e) {
  e?.stopPropagation();
  const hudClaimBtn = document.getElementById('hud-claim-blessing-btn');
  const profileClaimBtn = document.getElementById('profile-claim-blessing-btn');

  if (hudClaimBtn) hudClaimBtn.disabled = true;
  if (profileClaimBtn) profileClaimBtn.disabled = true;

  try {
    const res = await window.kvrcards.claimBlessingDaily();
    if (!res || !res.ok) {
      alert(res?.error || 'No se pudo reclamar la bendición en este momento.');
      window.updateProfileBlessingUI();
      return;
    }

    // Actualizar monedero y vistas
    if (typeof window.renderWallet === 'function') {
      window.renderWallet();
    } else {
      const kvrEl = document.getElementById('wallet-kvr-amt');
      if (kvrEl && res.newWallet) {
        kvrEl.textContent = res.newWallet.kvr || 0;
      }
    }

    // Mostrar HUD unificado de recompensas
    if (typeof window.showUnifiedRewardsHUD === 'function') {
      await window.showUnifiedRewardsHUD([{ type: 'kvr', amount: res.amount || 30 }], 'BENDICIÓN RECLAMADA');
    } else if (typeof window.showToastNotification === 'function') {
      window.showToastNotification(`✨ ¡Reclamados ${res.amount || 30} KvR diarios de la Bendición del Supporter!`, 'success');
    } else {
      alert(`✨ ¡Has recibido ${res.amount || 30} KvR diarios de la Bendición del Supporter!\nVuelve mañana a partir de las 06:00 AM.`);
    }

    window.updateProfileBlessingUI();
  } catch (err) {
    console.error('[BLESSING] Error al reclamar:', err);
    alert('Error al reclamar la bendición: ' + err.message);
  }
}

function initProfileBlessing() {
  const hudClaimBtn = document.getElementById('hud-claim-blessing-btn');
  if (hudClaimBtn) {
    hudClaimBtn.addEventListener('click', handleClaimBlessingClick);
  }

  const profileClaimBtn = document.getElementById('profile-claim-blessing-btn');
  if (profileClaimBtn) {
    profileClaimBtn.addEventListener('click', handleClaimBlessingClick);
  }

  const hudToggle = document.getElementById('hud-toggle');
  if (hudToggle) {
    hudToggle.addEventListener('click', () => {
      window.updateProfileBlessingUI();
      window.refreshAdminStatus?.();
    });
  }

  // Comprobar periódicamente cada minuto y al inicio
  window.updateProfileBlessingUI();
  window.refreshAdminStatus?.();
  setInterval(() => {
    window.updateProfileBlessingUI();
    window.refreshAdminStatus?.();
  }, 60000);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initProfileBlessing);
} else {
  initProfileBlessing();
}

