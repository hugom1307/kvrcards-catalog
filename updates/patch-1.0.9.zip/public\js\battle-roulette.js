async function startBattleRoulette() {
  if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) {
    console.log('[BATTLE] startBattleRoulette abortado: batalla cancelada o finalizada');
    return;
  }
  console.log('[BATTLE] Iniciando ruleta...');
  
  // Cortar música de introbatalla inmediatamente al comenzar la ruleta
  if (typeof stopBattleIntroMusic === 'function') {
    stopBattleIntroMusic();
  } else if (typeof window.stopBattleIntroMusic === 'function') {
    window.stopBattleIntroMusic();
  }
  if (typeof stopBackgroundMusic === 'function') {
    stopBackgroundMusic();
  }

  // Asegurar que las stats y cartas usadas comiencen 100% limpias al inicio del combate
  if (!window.battleState.currentRound || window.battleState.currentRound <= 1) {
    window.battleState.playerUsedStats = [];
    window.battleState.opponentUsedStats = [];
    window.battleState.selectedStat = null;
    window.battleState.opponentSelectedStat = null;
    window.battleState.annulledStat = null;
    window.battleState.playerUsedCards = [];
    window.battleState.opponentUsedCards = [];

    // Limpiar DOM de botones de stats
    document.querySelectorAll('.battle-stat-btn, .battle-stat-display').forEach(el => {
      el.classList.remove('used', 'highlighted', 'annulled', 'disabled', 'selected', 'nerfed');
      el.disabled = false;
      el.style.opacity = '';
      el.style.borderColor = '';
      el.style.background = '';
      el.style.boxShadow = '';
      const label = el.querySelector('.stat-label');
      if (label) {
        label.innerHTML = label.innerHTML.replace(/\(BLOQUEADO\)\s*/g, '').replace(/\u{1F512}\s*/gu, '');
      }
    });
  }
  
  // Guardar la carta inicial que el jugador eligió en la animación
  const initialPlayerCard = window.battleState.playerCurrentCard;
  const initialOpponentCard = window.battleState.opponentCurrentCard;
  
  console.log('[BATTLE] Cartas guardadas antes de ruleta:');
  console.log('[BATTLE] - Jugador:', initialPlayerCard?.nombre || initialPlayerCard?.name);
  console.log('[BATTLE] - Oponente:', initialOpponentCard?.nombre || initialOpponentCard?.name);
  
  // Obtener avatar del jugador
  let playerAvatar = 'https://api.dicebear.com/7.x/avataaars/svg?seed=default';
  try {
    if (isElectron) {
      const userResult = await window.kvrcards.getUserProfile();
      if (userResult?.ok && userResult?.profile) {
        playerAvatar = userResult.profile.profileImage || playerAvatar;
      } else if (userResult?.profileImage) {
        playerAvatar = userResult.profileImage;
      }
    }
  } catch (error) {
    console.error('[BATTLE] Error obteniendo avatar:', error);
  }
  
  // Obtener avatar del oponente (online o IA)
  let opponentAvatar = 'https://api.dicebear.com/7.x/avataaars/svg?seed=opponent';
  if (window.battleState.isOnline && window.onlineState.opponentData?.profileImage) {
    opponentAvatar = window.onlineState.opponentData.profileImage;
  } else {
    opponentAvatar = getOpponentAvatar(window.battleState.difficulty);
  }
  
  // Mostrar ruleta
  const roulette = document.getElementById('battle-roulette');
  const rouletteWheel = document.getElementById('roulette-wheel');
  const battleScreen = document.getElementById('battle-screen');
  document.getElementById('roulette-player-avatar').src = playerAvatar;
  const oppRouletteEl = document.getElementById('roulette-opponent-avatar');
  if (oppRouletteEl) {
    oppRouletteEl.src = opponentAvatar;
    oppRouletteEl.onerror = function() {
      this.src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(window.battleState?.opponentName || 'opponent')}`;
      this.onerror = null;
    };
  }
  if (battleScreen) battleScreen.classList.add('blurred');
  roulette.style.display = 'flex';
  
  // Decidir quién empieza basándose en el servidor (sincronizado)
  // En modo online, esto viene del servidor en round-start
  let playerStarts;
  if (window.battleState.isOnline && window.battleState.firstPlayer !== undefined) {
    // Usar decisión del servidor
    playerStarts = window.battleState.firstPlayer;
  } else {
    // Modo offline: decidir localmente
    playerStarts = Math.random() < 0.5;
  }
  
  window.battleState.currentTurn = playerStarts ? 'player' : 'opponent';
  window.battleState.roundWinner = window.battleState.currentTurn;
  
  // Resetear rotación
  rouletteWheel.style.transition = 'none';
  rouletteWheel.style.transform = 'rotate(0deg)';
  
  // Force reflow
  rouletteWheel.offsetHeight;
  
  // Reproducir sonido de ruleta
  playSFX('roulette');
  
  // Calcular rotación final para que la flecha apunte al ganador
  // IMPORTANTE: Al girar en sentido horario, la mitad izquierda (jugador) pasa por arriba PRIMERO
  // Por lo tanto: Si gira 90°, el jugador (izquierda) queda arriba; Si gira 270°, el oponente (derecha) queda arriba
  const baseRotations = 1440; // 4 vueltas completas
  let finalAngle;
  
  if (playerStarts) {
    // Jugador gana: necesita girar 90° para que la mitad izquierda quede arriba
    finalAngle = baseRotations + 90 + (Math.random() * 40 - 20); // ±20° de variación
  } else {
    // Oponente gana: necesita girar 270° para que la mitad derecha quede arriba
    finalAngle = baseRotations + 270 + (Math.random() * 40 - 20);
  }
  
  // Aplicar transición y rotación
  rouletteWheel.style.transition = 'transform 5s cubic-bezier(0.25, 0.1, 0.25, 1)';
  rouletteWheel.style.transform = `rotate(${finalAngle}deg)`;
  
  const abortRouletteCleanup = () => {
    console.log('[BATTLE] Ruleta abortada: limpiando elementos visuales...');
    if (roulette) roulette.style.display = 'none';
    if (battleScreen) battleScreen.classList.remove('blurred');
    if (rouletteWheel) {
      rouletteWheel.style.transition = 'none';
      rouletteWheel.style.transform = 'rotate(0deg)';
    }
    const res = document.getElementById('roulette-result');
    if (res) res.textContent = '';
  };

  // Esperar animación (5 segundos de giro)
  await (typeof window.battleSleep === 'function' ? window.battleSleep(5000) : new Promise(resolve => setTimeout(resolve, 5000)));
  if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) {
    abortRouletteCleanup();
    return;
  }
  
  // Mostrar resultado
  const isInfiniteBattle = !!(window.__infiniteBattleContext?.active || window.battleState?.difficulty === 'inmo');
  const activeMod = isInfiniteBattle ? (window.battleState?.infiniteModifier || window.__infiniteBattleContext?.modifier) : null;
  const isReservado = isInfiniteBattle && activeMod?.id === 'reservado';

  const resultText = playerStarts ? '¡TÚ EMPIEZAS!' : '¡EL OPONENTE EMPIEZA!';
  document.getElementById('roulette-result').textContent = resultText;
  
  if (isReservado && !playerStarts) {
    // Si la ruleta dio inicio al oponente, el modificador Reservado anula y reemplaza el turno
    await (typeof window.battleSleep === 'function' ? window.battleSleep(1200) : new Promise(resolve => setTimeout(resolve, 1200)));
    if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) {
      abortRouletteCleanup();
      return;
    }
    document.getElementById('roulette-result').textContent = 'RESERVADO: ¡EMPIEZAS TÚ!';
    if (typeof playSFX === 'function') playSFX('cardSelect');
    await (typeof window.battleSleep === 'function' ? window.battleSleep(1500) : new Promise(resolve => setTimeout(resolve, 1500)));
    if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) {
      abortRouletteCleanup();
      return;
    }
  } else {
    // Esperar 2 segundos adicionales para que se vea bien el ganador
    await (typeof window.battleSleep === 'function' ? window.battleSleep(2000) : new Promise(resolve => setTimeout(resolve, 2000)));
    if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) {
      abortRouletteCleanup();
      return;
    }
  }
  
  // Ocultar ruleta y resetear
  roulette.style.display = 'none';
  if (battleScreen) battleScreen.classList.remove('blurred');
  rouletteWheel.style.transition = 'none';
  rouletteWheel.style.transform = 'rotate(0deg)';

  // Si el modificador Reservado está activo, el jugador siempre empieza
  if (isReservado) {
    window.battleState.currentTurn = 'player';
    window.battleState.roundWinner = 'player';
    console.log('[BATTLE] Modificador Reservado activo: El jugador siempre actúa primero');
  }
  
  // Cambiar a música de batalla (personalizada por entrenador o por defecto)
  console.log('[BATTLE] Cambiando a música de batalla');
  if (typeof musicEnabled !== 'undefined' ? musicEnabled : true) {
    const isCustomAllowed = typeof window.isCustomBattleMusicEnabled === 'function'
      ? window.isCustomBattleMusicEnabled()
      : (localStorage.getItem('customBattleMusicEnabled') !== 'false');

    let customSong = null;
    if (isCustomAllowed && !window.battleState?.isOnline) {
      if (window.battleState?.opponentSong) {
        customSong = window.battleState.opponentSong;
      } else if (window.__infiniteBattleContext?.active && (window.__infiniteBattleContext?.battleSong || window.__infiniteBattleContext?.opponentSong)) {
        customSong = window.__infiniteBattleContext.battleSong || window.__infiniteBattleContext.opponentSong;
      }
    }

    const defaultBattleTrack = localStorage.getItem('battleMusicTrack') || (typeof BATTLE_TRACK !== 'undefined' ? BATTLE_TRACK : 'music/battlesong.mp3');
    const battleTrack = customSong || defaultBattleTrack;
    
    if (customSong) {
      window.__isCustomBattleTrack = true;
      console.log('[BATTLE] Reproduciendo música de batalla personalizada (offline/infinito):', customSong);
    } else {
      window.__isCustomBattleTrack = false;
      console.log('[BATTLE] Reproduciendo música de batalla estándar del jugador:', battleTrack);
    }

    if (typeof playBackgroundMusic === 'function') {
      playBackgroundMusic(battleTrack);
    } else if (typeof window.playBackgroundMusic === 'function') {
      window.playBackgroundMusic(battleTrack);
    }
  }
  
  if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) {
    console.log('[BATTLE] Ruleta abortada antes de restaurar cartas.');
    return;
  }

  // Restaurar las cartas iniciales que eligieron en la animación
  window.battleState.playerCurrentCard = initialPlayerCard;
  window.battleState.opponentCurrentCard = initialOpponentCard;
  
  console.log('[BATTLE] Cartas restauradas después de ruleta:');
  console.log('[BATTLE] - Jugador:', window.battleState.playerCurrentCard?.nombre || window.battleState.playerCurrentCard?.name);
  console.log('[BATTLE] - Oponente:', window.battleState.opponentCurrentCard?.nombre || window.battleState.opponentCurrentCard?.name);
  
  // Marcar las cartas como usadas
  const playerCardIndex = window.battleState.playerTeam.findIndex(c => c.id === initialPlayerCard.id);
  const opponentCardIndex = window.battleState.opponentTeam.findIndex(c => c.id === initialOpponentCard.id);
  
  console.log('[BATTLE] Índices de cartas:', playerCardIndex, opponentCardIndex);
  
  if (playerCardIndex !== -1) {
    window.battleState.playerUsedCards.push(playerCardIndex);
  }
  if (opponentCardIndex !== -1) {
    window.battleState.opponentUsedCards.push(opponentCardIndex);
  }
  
  // Cambiar fase a selección de stats (ya tienen sus cartas)
  window.battleState.gamePhase = 'stat-selection';
  window.battleState.canChangeCard = false; // No pueden cambiar esta primera carta
  
  console.log('[BATTLE] Llamando a updateBattleCards...');
  try {
    // Mostrar las cartas en pantalla
    updateBattleCards();
    console.log('[BATTLE] updateBattleCards ejecutado correctamente');
  } catch (error) {
    console.error('[BATTLE] ERROR en updateBattleCards:', error);
  }
  
  console.log('[BATTLE] Llamando a enableStatSelection...');
  try {
    // Empezar la selección de stats
    enableStatSelection();
    console.log('[BATTLE] enableStatSelection ejecutado correctamente');
  } catch (error) {
    console.error('[BATTLE] ERROR en enableStatSelection:', error);
  }
  
  console.log('[BATTLE] Turno inicial:', window.battleState.currentTurn, 'con cartas ya elegidas');
  console.log('[BATTLE] VERSION CON ANIMACION ACTUALIZADA - v2.0');
}

// Limpiar cartas y mostrar espacios vacíos
function clearBattleCards() {
  const playerCardDisplay = document.querySelector('.battle-side-player .battle-card-display');
  const opponentCardDisplay = document.querySelector('.battle-side-opponent .battle-card-display');
  
  if (playerCardDisplay) {
    playerCardDisplay.classList.add('empty');
    const plTrait = playerCardDisplay.querySelector('.card-trait-icon');
    if (plTrait) plTrait.remove();
  }
  if (opponentCardDisplay) {
    opponentCardDisplay.classList.add('empty');
    const opTrait = opponentCardDisplay.querySelector('.card-trait-icon');
    if (opTrait) opTrait.remove();
  }
  
  const playerCardImg = document.getElementById('battle-player-card');
  const opponentCardImg = document.getElementById('battle-opponent-card');
  
  if (playerCardImg) playerCardImg.style.display = 'none';
  if (opponentCardImg) opponentCardImg.style.display = 'none';
}

// Renderizar sidebar con el equipo del jugador
function renderTeamSidebar() {
  const container = document.getElementById('battle-team-cards');
  container.innerHTML = '';
  
  // Solo mostrar las 7 cartas principales (no la carta de reserva en index 7)
  const mainCards = window.battleState.playerTeam.slice(0, 7);
  mainCards.forEach((card, index) => {
    const cardDiv = document.createElement('div');
    cardDiv.className = 'battle-team-card';
    if (window.battleState.playerUsedCards.includes(index)) {
      cardDiv.classList.add('used');
    }
    
    const img = document.createElement('img');
    img.src = card.imageUrl || card.imagen || card.image || '';
    img.alt = card.name || card.nombre || 'Carta';
    
    cardDiv.appendChild(img);
    
    // Añadir icono de trait si existe
    const cardKey = card.uniqueId || card.id;
    const traitId = (cardTraitsMap && cardTraitsMap[cardKey]) || card.traitId;
    const trait = traitId ? ((typeof window.getTraitById === 'function') ? window.getTraitById(traitId) : (availableTraits && availableTraits.find(t => t.id === traitId))) : null;
    if (trait) {
      const traitIcon = document.createElement('div');
      traitIcon.className = 'card-trait-icon';
      const traitImg = document.createElement('img');
      traitImg.src = trait.imageUrl || trait.image || trait.icon || './trait.png';
      traitImg.alt = trait.name || trait.id;
      traitImg.title = trait.name || trait.id;
      traitImg.onerror = function() { this.src = './trait.png'; };
      traitIcon.appendChild(traitImg);
      cardDiv.appendChild(traitIcon);
    }
    
    // Click para seleccionar carta (solo si no está usada y puede cambiar)
    if (!window.battleState.playerUsedCards.includes(index) && window.battleState.canChangeCard) {
      cardDiv.addEventListener('click', () => selectPlayerCard(index));
    }
    
    container.appendChild(cardDiv);
  });
}

// Jugador selecciona una carta
function selectPlayerCard(cardIndex) {
  if (!window.battleState.canChangeCard) {
    console.log('[BATTLE] No puedes cambiar de carta en este momento');
    return;
  }
  
  if (window.battleState.gamePhase !== 'card-selection') {
    console.log('[BATTLE] No es momento de seleccionar carta');
    return;
  }
  
  const isOnlineBattle = window.battleState.isOnline || (window.onlineState && window.onlineState.inBattle);
  
  // BLOQUEAR si es turno del oponente y aún no ha colocado su carta (SOLO offline)
  if (!isOnlineBattle) {
    if (window.battleState.currentTurn === 'opponent' && !window.battleState.opponentCurrentCard) {
      console.log('[BATTLE] Debes esperar a que el oponente coloque su carta primero');
      return;
    }
    
    if (window.battleState.currentTurn !== 'player' && !window.battleState.waitingForCardSelection) {
      console.log('[BATTLE] No es tu turno para elegir carta');
      return;
    }
  }
  
  console.log('[BATTLE] Jugador selecciona carta:', cardIndex);
  
  // Reproducir efecto de sonido de selección de carta
  playSFX('cardSelect');
  
  window.battleState.playerCurrentCard = window.battleState.playerTeam[cardIndex];
  window.battleState.playerUsedCards.push(cardIndex);
  window.battleState.canChangeCard = false; // Bloquear cambio hasta próxima ronda
  
  // Ocultar sidebar después de elegir
  const sidebar = document.getElementById('battle-team-sidebar');
  if (sidebar) {
    sidebar.style.display = 'none';
  }
  
  // Actualizar visual
  renderTeamSidebar();
  updateBattleCards();
  
  // Marcar carta activa
  const cards = document.querySelectorAll('.battle-team-card');
  cards.forEach(c => c.classList.remove('active'));
  if (cards[cardIndex]) cards[cardIndex].classList.add('active');
  
  // En ONLINE: emitir card-selected al servidor y esperar a que ambos seleccionen
  if (isOnlineBattle && window.onlineState.socket && window.onlineState.matchId) {
    window.onlineState.socket.emit('card-selected', {
      matchId: window.onlineState.matchId,
      cardIndex: cardIndex
    });
    console.log('[ONLINE-BATTLE] card-selected enviado al servidor (ronda 2+) - índice:', cardIndex);
    
    // Mostrar mensaje de espera
    const instruction = document.getElementById('battle-intro-instruction');
    if (instruction) {
      instruction.innerHTML = '<h1>Esperando a que tu rival elija carta...</h1>';
    }
    return; // El servidor enviará 'select-stat' cuando ambos hayan elegido
  }
  
  // OFFLINE: lógica local
  // Si el oponente ya eligió, pasar a selección de stats
  if (window.battleState.opponentCurrentCard) {
    window.battleState.gamePhase = 'stat-selection';
    enableStatSelection();
  } else {
    // Esperar a que el oponente elija
    window.battleState.waitingForCardSelection = false;
    opponentSelectsCard();
  }
}

// Oponente selecciona su carta
function opponentSelectsCard() {
  if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
  console.log('[BATTLE] Oponente selecciona carta...');
  
  // Verificar primero si tiene cartas disponibles
  const availableIndices = [];
  for (let i = 0; i < window.battleState.opponentTeam.length; i++) {
    if (!window.battleState.opponentUsedCards.includes(i)) {
      availableIndices.push(i);
    }
  }
  
  if (availableIndices.length === 0) {
    console.log('[BATTLE] Oponente no tiene más cartas disponibles');
    return;
  }
  
  (typeof window.setBattleTimeout === 'function' ? window.setBattleTimeout : setTimeout)(() => {
    if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;

    let chosenIndex;
    
    if (window.battleState.gameMode === 'alternativo7v7' || window.battleState.gameMode === 'eleccion_alternativo') {
      console.log('[BATTLE-AI] Ejecutando IA Estratégica Combinatoria para Selección de Carta (Alternativo)...');
      chosenIndex = selectOptimalCardAlternativeMode(availableIndices);
    } else {
      chosenIndex = availableIndices[Math.floor(Math.random() * availableIndices.length)];
    }
    
    window.battleState.opponentCurrentCard = window.battleState.opponentTeam[chosenIndex];
    window.battleState.opponentUsedCards.push(chosenIndex);
    
    // Reproducir efecto de sonido de selección de carta
    playSFX('cardSelect');
    
    updateBattleCards();
    
    console.log('[BATTLE] Oponente eligió carta:', window.battleState.opponentCurrentCard.name || window.battleState.opponentCurrentCard.nombre);
    
    // Si el jugador ya eligió, pasar a selección de stats
    if (window.battleState.playerCurrentCard) {
      window.battleState.gamePhase = 'stat-selection';
      enableStatSelection();
    } else {
      // Indicar al jugador que elija y MOSTRAR SIDEBAR
      window.battleState.waitingForCardSelection = true;
      const sidebar = document.getElementById('battle-team-sidebar');
      if (sidebar) {
        sidebar.style.display = 'flex';
      }
      console.log('[BATTLE] Sidebar mostrado - Ahora el jugador puede elegir su carta');
    }
  }, 1500);
}

// Habilitar selección de stats
function enableStatSelection() {
  if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
  console.log('[BATTLE] Habilitando selección de stats. Turno:', window.battleState.currentTurn);
  
  const isOnline = window.battleState.isOnline;
  const isOpponentTurn = window.battleState.currentTurn === 'opponent';

  // Determinar si el jugador tiene una stat anulada en esta ronda
  const isPlayerStatAnnulled = !!(window.battleState.opponentPowersUsed && window.battleState.opponentPowersUsed.anulo && window.battleState.annulledStat);
  const playerAnnulledStat = isPlayerStatAnnulled ? window.battleState.annulledStat : null;

  // Determinar si el oponente tiene una stat anulada en esta ronda
  const isOpponentStatAnnulled = !!(window.battleState.playerPowersUsed && window.battleState.playerPowersUsed.anulo && window.battleState.annulledStat);
  const opponentAnnulledStat = isOpponentStatAnnulled ? window.battleState.annulledStat : null;

  // Marcar stats ya usadas como deshabilitadas (SOLO LAS DEL JUGADOR)
  const playerStatButtons = document.querySelectorAll('.battle-side-player .battle-stat-btn');
  playerStatButtons.forEach(btn => {
    const stat = btn.dataset?.stat;
    const isUsed = Array.isArray(window.battleState?.playerUsedStats) && window.battleState.playerUsedStats.includes(stat);
    if (isUsed) {
      btn.classList.add('used');
    } else {
      btn.classList.remove('used', 'highlighted', 'highlighted-static', 'selected', 'disabled');
      btn.style.borderColor = '';
      btn.style.background = '';
      btn.style.backgroundColor = '';
      btn.style.boxShadow = '';
      btn.style.pointerEvents = '';
      btn.style.cursor = '';
    }
  });
  
  // Marcar stats ya usadas por el oponente (SOLO LAS DEL OPONENTE)
  const opponentStatDisplays = document.querySelectorAll('.battle-side-opponent .battle-stat-display');
  opponentStatDisplays.forEach(display => {
    const stat = display.dataset?.stat;
    const isUsed = Array.isArray(window.battleState?.opponentUsedStats) && window.battleState.opponentUsedStats.includes(stat);
    if (isUsed) {
      display.classList.add('used');
    } else {
      display.classList.remove('used', 'highlighted', 'highlighted-static', 'selected');
      display.style.borderColor = '';
      display.style.background = '';
      display.style.backgroundColor = '';
      display.style.boxShadow = '';
    }
  });
  
  // Habilitar/deshabilitar botones del jugador visualmente y limpiar/mantener candados de ANULO
  playerStatButtons.forEach(btn => {
    const stat = btn.dataset?.stat;
    
    if (isOnline && isOpponentTurn) {
      // Si es online y es turno del rival, deshabilitar todo
      btn.disabled = true;
    } else {
      btn.disabled = false;
    }

    // Si esta stat está anulada para el jugador, mantenerla bloqueada
    if (stat === playerAnnulledStat) {
      btn.disabled = true;
      btn.classList.add('annulled');
      btn.style.opacity = '0.4';
      const label = btn.querySelector('.stat-label');
      if (label && !label.innerHTML.includes('(BLOQUEADO)')) {
        label.innerHTML = '(BLOQUEADO) ' + label.innerHTML;
      }
    } else {
      btn.classList.remove('disabled', 'annulled');
      if (!isOnline || !isOpponentTurn) {
        btn.style.opacity = '';
      }
      const label = btn.querySelector('.stat-label');
      if (label) {
        label.innerHTML = label.innerHTML.replace('(BLOQUEADO) ', '').replace(/\u{1F512}\s*/gu, '');
      }
    }
  });
  
  // Habilitar/deshabilitar displays del oponente visualmente y limpiar/mantener candados de ANULO
  opponentStatDisplays.forEach(display => {
    const stat = display.dataset?.stat;
    
    // Si esta stat está anulada para el oponente, mantenerla bloqueada
    if (stat === opponentAnnulledStat) {
      display.classList.add('annulled');
      display.style.opacity = '0.4';
      display.style.pointerEvents = 'none';
      const label = display.querySelector('.stat-label');
      if (label && !label.innerHTML.includes('(BLOQUEADO)')) {
        label.innerHTML = '(BLOQUEADO) ' + label.innerHTML;
      }
    } else {
      display.classList.remove('annulled');
      display.style.opacity = '';
      display.style.pointerEvents = '';
      const label = display.querySelector('.stat-label');
      if (label) {
        label.innerHTML = label.innerHTML.replace('(BLOQUEADO) ', '').replace(/\u{1F512}\s*/gu, '');
      }
    }
  });
  
  // Si es turno del jugador, esperar su selección
  if (window.battleState.currentTurn === 'player') {
    console.log('[BATTLE] Esperando selección del jugador');
    if (!window.battleState.isOnline) {
      opponentConsidersPowerAnulo();
    }
  } else {
    // Es turno del oponente
    if (window.battleState.isOnline) {
      // Modo online: no ejecutar IA, esperar evento del servidor
      console.log('[BATTLE] Modo online - esperando stat del oponente desde servidor');
    } else {
      // Modo offline: seleccionar automáticamente con IA
      opponentSelectsStat();
    }
  }
}

// Oponente selecciona stat (CON IA INTELIGENTE)
async function opponentSelectsStat() {
  if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
  console.log('[BATTLE] Oponente selecciona stat...');
  
  // Considerar usar poder ANULO si el jugador ya eligió stat
  if (window.battleState.selectedStat) {
    const usedAnulo = await opponentConsidersPowerAnulo();
    if (usedAnulo) {
      console.log('[BATTLE] IA usó ANULO. Cancelando selección actual.');
      return;
    }
  }
  
  // Considerar usar poder de intercambio antes de elegir stat
  const usedSwap = await opponentConsidersPowerSwap();
  
  // Considerar usar INTERCAMBIO antes de elegir stat
  const usedIntercambio = await opponentConsidersPowerIntercambio();
  
  // Considerar usar Power Up antes de elegir stat (y esperar si lo usa)
  const usedPowerUp = await opponentConsidersPowerUp();
  
  // Considerar usar NERF si está perdiendo y tiene 2 derrotas consecutivas
  const usedNerf = await opponentConsidersNerfPower();
  
  // Si usó algún poder, esperar 2 segundos extra para que el jugador lo vea
  const delay = (usedSwap || usedPowerUp || usedNerf || usedIntercambio) ? 2000 : 0;
  
  (typeof window.setBattleTimeout === 'function' ? window.setBattleTimeout : setTimeout)(async () => {
    if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
    // Elegir de las stats disponibles PARA EL OPONENTE (no las que YA usó ni la ANULADA)
    const availableStats = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
      .filter(s => !window.battleState.opponentUsedStats.includes(s) && s !== window.battleState.annulledStat);
    
    if (availableStats.length === 0) {
      console.error('[BATTLE] No hay stats disponibles para el oponente');
      return;
    }
    
    let chosenStat;
    const opponentCard = window.battleState.opponentCurrentCard;
    const perceivedPlayerCard = (!window.battleState.playerImpostorRevealed && window.battleState.playerDecoyCard)
      ? window.battleState.playerDecoyCard
      : window.battleState.playerCurrentCard;
    
    if (window.battleState.gameMode === 'alternativo7v7' || window.battleState.gameMode === 'eleccion_alternativo') {
      console.log('[BATTLE-AI] Ejecutando IA de Selección de Stat Estratégica para Alternativo (Opción A)...');
      
      const playerCard = perceivedPlayerCard;
      
      // SI EL JUGADOR YA ELIGIÓ (IA reacciona defensivamente)
      if (playerCard && window.battleState.selectedStat) {
        const playerStatValue = getStatValue(playerCard, window.battleState.selectedStat, 'player');
        
        // Simular cada una de nuestras stats disponibles contra la stat elegida por el jugador
        // Queremos maximizar la diferencia de puntos a nuestro favor: opVal - playerStatValue
        let bestStat = availableStats[0];
        let bestScore = -Infinity;
        
        for (const stat of availableStats) {
          const opVal = getStatValue(opponentCard, stat, 'opponent');
          const score = opVal - playerStatValue;
          if (score > bestScore) {
            bestScore = score;
            bestStat = stat;
          }
        }
        chosenStat = bestStat;
        console.log('[BATTLE-AI] IA reactiva modo alternativo: maximiza ganancia de puntos eligiendo stat:', chosenStat, 'puntos netos proyectados:', bestScore);
      } else {
        // LA IA ELIGE PRIMERO (IA ofensiva)
        // Evaluamos cada una de nuestras stats disponibles contra el promedio de las stats disponibles del jugador.
        // Queremos maximizar nuestro score esperado.
        const playerAvailableStats = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
          .filter(s => !window.battleState.playerUsedStats.includes(s));
          
        let bestStat = availableStats[0];
        let bestScore = -Infinity;
        
        for (const stat of availableStats) {
          const opVal = getStatValue(opponentCard, stat, 'opponent');
          
          let expectedScore = 0;
          if (playerCard) {
            // Si el jugador eligió carta pero no stat
            let totalScore = 0;
            if (playerAvailableStats.length > 0) {
              for (const pStat of playerAvailableStats) {
                const pVal = getStatValue(playerCard, pStat, 'player');
                totalScore += (opVal - pVal);
              }
              expectedScore = totalScore / playerAvailableStats.length;
            } else {
              expectedScore = opVal;
            }
          } else {
            // Si el jugador no ha elegido carta ni stat (estimamos contra todas las restantes del jugador)
            const remainingPlayerCards = [];
            for (let i = 0; i < window.battleState.playerTeam.length; i++) {
              if (!window.battleState.playerUsedCards.includes(i)) {
                remainingPlayerCards.push(window.battleState.playerTeam[i]);
              }
            }
            
            let totalScore = 0;
            let count = 0;
            for (const pCard of remainingPlayerCards) {
              for (const pStat of playerAvailableStats) {
                const pVal = getStatValue(pCard, pStat, 'player');
                totalScore += (opVal - pVal);
                count++;
              }
            }
            expectedScore = count > 0 ? (totalScore / count) : opVal;
          }
          
          if (expectedScore > bestScore) {
            bestScore = expectedScore;
            bestStat = stat;
          }
        }
        
        chosenStat = bestStat;
        console.log('[BATTLE-AI] IA ofensiva modo alternativo: maximiza ganancia esperada eligiendo stat:', chosenStat, 'score proyectado:', bestScore);
      }
    } else {
      // MODO CLÁSICO ORIGINAL (Lógica original intacta)
      // SI EL JUGADOR YA ELIGIÓ (jugador empezó), usar IA INTELIGENTE DEFENSIVA
      if (window.battleState.selectedStat) {
        const playerCard = perceivedPlayerCard;
        const playerStatValue = getStatValue(playerCard, window.battleState.selectedStat, 'player');
        
        console.log('[BATTLE] IA analiza: Jugador eligió', window.battleState.selectedStat, 'con valor', playerStatValue);
        
        // Buscar stats que superen el valor del jugador (considerando buffeos)
        const winningStatsData = availableStats.map(stat => {
          const opValue = getStatValue(opponentCard, stat, 'opponent');
          return {
            stat: stat,
            value: opValue
          };
        }).filter(item => item.value > playerStatValue);
        
        if (winningStatsData.length > 0) {
          // ESTRATEGIA: Elegir la MENOR stat ganadora para guardar las altas
          winningStatsData.sort((a, b) => a.value - b.value); // Ordenar de menor a mayor
          chosenStat = winningStatsData[0].stat;
          console.log('[BATTLE] IA encontró stats superiores:', winningStatsData.map(s => `${s.stat}:${s.value}`), '→ Eligió LA MENOR:', chosenStat, 'con valor', winningStatsData[0].value);
        } else {
          // No hay stats que ganen, elegir aleatoriamente
          chosenStat = availableStats[Math.floor(Math.random() * availableStats.length)];
          console.log('[BATTLE] IA no puede ganar, eligió aleatoriamente:', chosenStat);
        }
      } else {
        // El oponente empieza - IA INTELIGENTE OFENSIVA
        const playerCard = perceivedPlayerCard;
        
        // Evaluar todas las stats disponibles del oponente (considerando buffeos)
        const statsWithValues = availableStats.map(stat => ({
          stat: stat,
          opponentValue: getStatValue(opponentCard, stat, 'opponent')
        }));
        
        // Obtener stats disponibles del jugador
        const playerAvailableStats = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
          .filter(s => !window.battleState.playerUsedStats.includes(s));
        
        // ESTRATEGIA CLAVE: Buscar stats que pueden ganar a TODAS las stats del jugador (considerando buffeos del jugador)
        const dominantStats = statsWithValues.filter(opStat => {
          return playerAvailableStats.every(playerStat => {
            const playerValue = getStatValue(playerCard, playerStat, 'player');
            return opStat.opponentValue > playerValue;
          });
        });
        
        if (dominantStats.length > 0) {
          // Tiene stats que ganan a TODAS las del jugador → elegir la MENOR para conservar las altas
          dominantStats.sort((a, b) => a.opponentValue - b.opponentValue);
          chosenStat = dominantStats[0].stat;
          console.log('[BATTLE] IA tiene', dominantStats.length, 'stats que ganan a TODAS las del jugador → Elige LA MENOR:', chosenStat, 'valor', dominantStats[0].opponentValue);
        } else {
          // No tiene ninguna stat que gane a TODAS → usar la MÁS ALTA disponible (puede empatar y ganar por suma)
          statsWithValues.sort((a, b) => b.opponentValue - a.opponentValue);
          chosenStat = statsWithValues[0].stat;
          console.log('[BATTLE] IA no tiene stats superiores a TODAS → Usa su stat MÁS ALTA:', chosenStat, 'valor', statsWithValues[0].opponentValue, '(puede empatar y ganar por suma total)');
        }
      }
    }
    
    window.battleState.opponentSelectedStat = chosenStat;
    window.battleState.opponentUsedStats.push(chosenStat); // Marcar como usada por el oponente
    
    console.log('[BATTLE] Oponente eligió stat:', chosenStat);
    
    // Highlight persistente en dorado en la stat elegida por el oponente
    const opponentStatBtn = document.querySelector(`.battle-side-opponent .battle-stat-display[data-stat="${chosenStat}"]`);
    if (opponentStatBtn) {
      opponentStatBtn.classList.add('highlighted');
      // Marcar también como usada visualmente
      opponentStatBtn.classList.add('used');
      console.log('[BATTLE] Destacando stat del oponente:', chosenStat);
    }
    
    // Si el jugador ya eligió, comparar
    if (window.battleState.selectedStat) {
      console.log('[BATTLE] Ambos eligieron, comparando...');
      await compareStats();
    } else {
      // Si no, ahora es turno del jugador
      window.battleState.currentTurn = 'player';
      console.log('[BATTLE] Ahora es turno del jugador para elegir stat');
    }
    
  }, 2000 + delay);
}

// Jugador elige stat (reconfigurar setupStatButtons)
function setupStatButtons() {
  const statButtons = document.querySelectorAll('.battle-stat-btn');
  
  statButtons.forEach(btn => {
    const clone = btn.cloneNode(true);
    const stat = clone.dataset?.stat;
    const isUsed = Array.isArray(window.battleState?.playerUsedStats) && window.battleState.playerUsedStats.includes(stat);
    if (!isUsed) {
      clone.classList.remove('used', 'highlighted', 'highlighted-static', 'selected', 'annulled', 'disabled');
      clone.style.borderColor = '';
      clone.style.background = '';
      clone.style.backgroundColor = '';
      clone.style.boxShadow = '';
      clone.style.pointerEvents = '';
      clone.style.cursor = '';
      clone.disabled = false;
    }
    // Remover listeners anteriores
    btn.replaceWith(clone);
  });
  
  // Volver a seleccionar después de clonar
  const newStatButtons = document.querySelectorAll('.battle-stat-btn');
  
  newStatButtons.forEach(btn => {
    btn.addEventListener('click', async () => {
      if (window.battleState.gamePhase !== 'stat-selection') {
        return;
      }
      
      const stat = btn.dataset.stat;
      
      // Verificar si la stat ya fue usada POR EL JUGADOR
      if (window.battleState.playerUsedStats.includes(stat)) {
        console.log('[BATTLE] Stat ya usada por el jugador:', stat);
        return;
      }
      
      // Verificar que sea el turno del jugador
      if (window.battleState.currentTurn !== 'player') {
        console.log('[BATTLE] No es tu turno');
        return;
      }
      
      console.log('[BATTLE] Jugador selecciona stat:', stat);
      
      // Reproducir efecto de sonido de selección de stat
      playSFX('statSelect');
      
      // Guardar la stat seleccionada (solo UNA)
      window.battleState.selectedStat = stat;
      window.battleState.playerUsedStats.push(stat); // Marcar como usada por el jugador
      
      // Deshabilitar la stat visualmente
      btn.classList.add('used');
      
      // Verificar si es batalla ONLINE
      const isOnlineBattle = window.battleState.isOnline || (window.onlineState && window.onlineState.inBattle && window.onlineState.matchId);
      
      if (isOnlineBattle) {
        // MODO ONLINE: enviar selección al servidor, NO ejecutar IA local
        console.log('[BATTLE] Modo ONLINE - enviando stat al servidor:', stat);
        handleOnlineStatSelection(stat);
        return;
      }
      
      // MODO OFFLINE: lógica local con IA
      // Verificar si el oponente ya eligió su stat
      if (window.battleState.opponentSelectedStat) {
        // En offline, si el oponente ya había elegido stat pero va en desventaja con la stat del jugador,
        // permitir que evalúe sus poderes reactivos (Power Up o Nerf) antes de comparar
        if (!isOnlineBattle) {
          const usedPowerUp = await opponentConsidersPowerUp();
          const usedNerf = await opponentConsidersNerfPower();
          if (usedPowerUp || usedNerf) {
            await (typeof window.battleSleep === 'function' ? window.battleSleep(800) : new Promise(resolve => setTimeout(resolve, 800)));
            if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
          }
        }
        // El oponente ya eligió, comparar
        if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
        console.log('[BATTLE] Oponente ya eligió, comparando...');
        await compareStats();
      } else {
        // El jugador eligió primero, ahora le toca al oponente (IA inteligente)
        if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
        console.log('[BATTLE] Jugador eligió primero, llamando a IA inteligente...');
        window.battleState.currentTurn = 'opponent';
        opponentSelectsStat();
      }
    });
  });
}
window.setupStatButtons = setupStatButtons;

// Comparar stats y determinar ganador
async function compareStats() {
  if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
  console.log('[BATTLE] Comparando stats...');
  window.battleState.gamePhase = 'comparing';
  
  // Revelar cartas de Impostor antes de comparar stats
  const currentOppCard = window.battleState.opponentCurrentCard;
  const oppTraitId = (typeof getCardActiveTraitId === 'function') ? getCardActiveTraitId(currentOppCard, 'opponent') : (currentOppCard?.opponentTraitId || currentOppCard?.traitId);
  if ((window.battleState.opponentDecoyCard || oppTraitId === 'impostor') && !window.battleState.opponentImpostorRevealed) {
    if (typeof revealImpostorCard === 'function') {
      await revealImpostorCard('opponent');
    } else {
      window.battleState.opponentImpostorRevealed = true;
      if (typeof updateBattleCards === 'function') updateBattleCards();
    }
  }
  const currentPlCard = window.battleState.playerCurrentCard;
  const plTraitId = (typeof getCardActiveTraitId === 'function') ? getCardActiveTraitId(currentPlCard, 'player') : (currentPlCard?.traitId);
  if ((window.battleState.playerDecoyCard || plTraitId === 'impostor') && !window.battleState.playerImpostorRevealed) {
    if (typeof revealImpostorCard === 'function') {
      await revealImpostorCard('player');
    } else {
      window.battleState.playerImpostorRevealed = true;
      if (typeof updateBattleCards === 'function') updateBattleCards();
    }
  }

  let playerCard = window.battleState.playerCurrentCard;
  let opponentCard = window.battleState.opponentCurrentCard;
  
  const playerStat = window.battleState.selectedStat; // Stat elegida por el jugador
  const opponentStat = window.battleState.opponentSelectedStat; // Stat elegida por la IA
  
  // Fuente de verdad SEGURA: cálculo matemático en memoria (inmune a manipulación de inspect element en el DOM)
  let playerValue = getStatValue(playerCard, playerStat, 'player');
  let opponentValue = getStatValue(opponentCard, opponentStat, 'opponent');

  // Modificadores activos de Nerf aplicados a la stat
  if (window.battleState.opponentNerfActive && window.battleState.nerfAppliedTo?.side === 'player' &&
      window.battleState.nerfAppliedTo.stat === playerStat && Number.isFinite(window.battleState.nerfAppliedTo.value)) {
    playerValue = window.battleState.nerfAppliedTo.value;
  }

  if (window.battleState.playerNerfActive && window.battleState.nerfAppliedTo?.side === 'opponent' &&
      window.battleState.nerfAppliedTo.stat === opponentStat && Number.isFinite(window.battleState.nerfAppliedTo.value)) {
    opponentValue = window.battleState.nerfAppliedTo.value;
  }
  
  console.log('[BATTLE] ====== VALORES FINALES DE COMPARACIÓN (EN MEMORIA) ======');
  console.log(`[BATTLE] Jugador: ${playerCard?.nombre || playerCard?.name} - Stat: ${playerStat} → ${playerValue}`);
  console.log(`[BATTLE] Oponente: ${opponentCard?.nombre || opponentCard?.name} - Stat: ${opponentStat} → ${opponentValue}`);
  console.log('[BATTLE] ========================================================');
  const isAlternativeMode = window.battleState.gameMode === 'alternativo7v7' || window.battleState.gameMode === 'eleccion_alternativo';
  let points = 1;

  if (playerValue > opponentValue) {
    winner = 'player';
    points = isAlternativeMode ? Math.abs(playerValue - opponentValue) : 1;
    window.battleState.playerScore += points;
    window.battleState.roundWinner = 'player';
    message = isAlternativeMode
      ? `¡VENTAJA ABSOLUTA!\n\nTú: ${playerValue} vs Oponente: ${opponentValue}\n¡Ganas +${points} puntos de ventaja!`
      : `¡GANASTE LA RONDA!\n\nTú: ${playerValue} (${playerStat.toUpperCase()})\nOponente: ${opponentValue} (${opponentStat.toUpperCase()})`;
  } else if (opponentValue > playerValue) {
    winner = 'opponent';
    points = isAlternativeMode ? Math.abs(playerValue - opponentValue) : 1;
    window.battleState.opponentScore += points;
    window.battleState.roundWinner = 'opponent';
    message = isAlternativeMode
      ? `DESVENTAJA EN LA RONDA\n\nTú: ${playerValue} vs Oponente: ${opponentValue}\nEl oponente gana +${points} puntos.`
      : `PERDISTE LA RONDA\n\nTú: ${playerValue} (${playerStat.toUpperCase()})\nOponente: ${opponentValue} (${opponentStat.toUpperCase()})`;
  } else {
    // EMPATE - Sumar todas las stats de ambas cartas (con sus respectivos buffs)
    console.log('[BATTLE] ¡EMPATE! Sumando todas las stats...');
    
    const statList = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
    const playerTotal = getStatValue(playerCard, 'media', 'player') + 
                        statList.reduce((sum, s) => sum + getStatValue(playerCard, s, 'player'), 0);
    const opponentTotal = getStatValue(opponentCard, 'media', 'opponent') + 
                          statList.reduce((sum, s) => sum + getStatValue(opponentCard, s, 'opponent'), 0);
    
    console.log('[BATTLE] Total jugador (con buffs):', playerTotal, 'Total oponente (con buffs):', opponentTotal);
    
    // Guardar totales para mostrarlos
    window.battleState.playerTotalInTie = playerTotal;
    window.battleState.opponentTotalInTie = opponentTotal;
    window.battleState.wasTie = true;
    
    if (playerTotal > opponentTotal) {
      winner = 'player';
      points = isAlternativeMode ? Math.abs(playerTotal - opponentTotal) : 1;
      window.battleState.playerScore += points;
      window.battleState.roundWinner = 'player';
      message = isAlternativeMode
        ? `EMPATE DE STAT -> DESEMPATE POR SUMA TOTAL\n\n¡GANASTE!\nVentaja total: +${points} puntos (Tú: ${playerTotal} vs Rival: ${opponentTotal})`
        : `EMPATE DE STAT -> DESEMPATE POR SUMA TOTAL\n\n¡GANASTE!\nTú: ${playerValue} (${playerStat.toUpperCase()}) -> Total carta: ${playerTotal}\nOponente: ${opponentValue} (${opponentStat.toUpperCase()}) -> Total carta: ${opponentTotal}`;
    } else if (opponentTotal > playerTotal) {
      winner = 'opponent';
      points = isAlternativeMode ? Math.abs(playerTotal - opponentTotal) : 1;
      window.battleState.opponentScore += points;
      window.battleState.roundWinner = 'opponent';
      message = isAlternativeMode
        ? `EMPATE DE STAT -> DESEMPATE POR SUMA TOTAL\n\nPERDISTE\nEl oponente gana +${points} puntos (Tú: ${playerTotal} vs Rival: ${opponentTotal})`
        : `EMPATE DE STAT -> DESEMPATE POR SUMA TOTAL\n\nPERDISTE\nTú: ${playerValue} (${playerStat.toUpperCase()}) -> Total carta: ${playerTotal}\nOponente: ${opponentValue} (${opponentStat.toUpperCase()}) -> Total carta: ${opponentTotal}`;
    } else {
      // Empate total - mantener al que empezó la ronda
      winner = 'tie';
      const isInfiniteTie = !!(window.__infiniteBattleContext?.active || window.battleState?.difficulty === 'inmo');
      const activeTieMod = isInfiniteTie ? (window.battleState?.infiniteModifier || window.__infiniteBattleContext?.modifier) : null;
      if (isInfiniteTie && activeTieMod?.id === 'reservado') {
        message = `EMPATE TOTAL\n\nAmbas cartas tienen la misma suma: ${playerTotal}\nContinúa el turno: Jugador (Reservado)`;
      } else {
        message = `EMPATE TOTAL\n\nAmbas cartas tienen la misma suma: ${playerTotal}\nContinúa el turno: ${window.battleState.roundWinner === 'player' ? 'Jugador' : 'Oponente'}`;
      }
    }
  }
  
  // Notificar al sistema de evoluciones y misiones si el jugador ganó la ronda
  if (winner === 'player') {
    if (typeof window.recordEvolutionRoundWon === 'function') {
      try {
        window.recordEvolutionRoundWon(playerCard);
      } catch (evoRoundErr) {
        console.warn('[EVOLUTIONS] Error registrando ronda ganada:', evoRoundErr);
      }
    }
    if (typeof window.recordMissionRoundWon === 'function') {
      try {
        window.recordMissionRoundWon();
      } catch (mRoundErr) {
        console.warn('[MISSIONS] Error registrando ronda ganada:', mRoundErr);
      }
    }
  }
  
  // Actualizar marcador
  document.getElementById('score-player-value').textContent = window.battleState.playerScore;
  document.getElementById('score-opponent-value').textContent = window.battleState.opponentScore;

  // Actualizar modificador del Modo Infinito tras cada ronda (Muerte, Deseo)
  const isInfiniteBattle = !!(window.__infiniteBattleContext?.active || window.battleState?.difficulty === 'inmo');
  const activeMod = isInfiniteBattle ? (window.battleState?.infiniteModifier || window.__infiniteBattleContext?.modifier) : null;
  if (activeMod) {
    if (winner === 'opponent') {
      window.battleState.playerRoundsLostCount = (window.battleState.playerRoundsLostCount || 0) + 1;
      console.log('[MODIFIER] Ronda perdida por el jugador. Total perdidas:', window.battleState.playerRoundsLostCount);
    }
    if (activeMod.id === 'deseo') {
      const isDoubled = (activeMod.floor >= 51);
      const mult = isDoubled ? 2 : 1;
      const addPercent = (winner === 'player') ? (2 * mult) : (1 * mult);
      window.battleState.deseoBossBuffPercent = (window.battleState.deseoBossBuffPercent || 0) + addPercent;
      console.log(`[MODIFIER] Deseo activado tras ronda: +${addPercent}%. Total acumulado: +${window.battleState.deseoBossBuffPercent}%`);
    }
  }
  
  // DESACTIVAR Power Up y NERF después de comparar (solo duran 1 ronda)
  if (window.battleState.playerPowerUpActive) {
    window.battleState.playerPowerUpActive = false;
    console.log('[BATTLE] Power Up del jugador desactivado (fin de ronda)');
    // Restaurar colores originales de las stats del jugador
    restoreStatsColors('player');
  }
  if (window.battleState.opponentPowerUpActive) {
    window.battleState.opponentPowerUpActive = false;
    console.log('[BATTLE] Power Up del oponente desactivado (fin de ronda)');
    // Restaurar colores originales de las stats del oponente
    restoreStatsColors('opponent');
  }
  if (window.battleState.playerNerfActive) {
    window.battleState.playerNerfActive = false;
    console.log('[BATTLE] NERF del jugador desactivado (fin de ronda)');
    // Restaurar colores del oponente
    restoreStatsColors('opponent');
  }
  if (window.battleState.opponentNerfActive) {
    window.battleState.opponentNerfActive = false;
    console.log('[BATTLE] NERF del oponente desactivado (fin de ronda)');
    // Restaurar colores del jugador
    restoreStatsColors('player');
  }
  window.battleState.nerfAppliedTo = null;
  
  // ===== LIMPIAR SOLO MODIFICADORES TEMPORALES (POWER UP Y NERF) =====
  // Los bufes de procedencia/owner son PERMANENTES durante toda la batalla
  // Solo se limpian los modificadores temporales por ronda
  playerCard = window.battleState.playerCurrentCard;
  opponentCard = window.battleState.opponentCurrentCard;
  
  if (playerCard) {
    const playerCardKeys = [playerCard.uniqueId, playerCard.id, String(playerCard.id)].filter(Boolean);
    playerCardKeys.forEach(k => {
      if (window.battleState.statModifiers[k]) {
        delete window.battleState.statModifiers[k].all;
        if (playerStat) delete window.battleState.statModifiers[k][playerStat];
        if (Object.keys(window.battleState.statModifiers[k]).length === 0) {
          delete window.battleState.statModifiers[k];
        }
      }
    });
    console.log(`[STATS-MOD] Modificadores temporales del jugador limpiados`);
  }
  if (opponentCard) {
    const opponentCardKeys = [opponentCard.uniqueId, opponentCard.id, String(opponentCard.id)].filter(Boolean);
    opponentCardKeys.forEach(k => {
      if (window.battleState.statModifiers[k]) {
        delete window.battleState.statModifiers[k].all;
        if (opponentStat) delete window.battleState.statModifiers[k][opponentStat];
        if (Object.keys(window.battleState.statModifiers[k]).length === 0) {
          delete window.battleState.statModifiers[k];
        }
      }
    });
    console.log(`[STATS-MOD] Modificadores temporales del oponente limpiados`);
  }
  
  // Actualizar contador de derrotas consecutivas
  if (winner === 'player') {
    window.battleState.playerConsecutiveLosses = 0;
    window.battleState.opponentConsecutiveLosses++;
  } else if (winner === 'opponent') {
    window.battleState.opponentConsecutiveLosses = 0;
    window.battleState.playerConsecutiveLosses++;
  }
  // En empate no se resetean
  
  // Mostrar animación de resultado de ronda
  if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) {
    console.log('[BATTLE] Batalla abortada antes de showRoundResult');
    return;
  }
  await showRoundResult(playerValue, opponentValue, winner);
}

// Mostrar animación de resultado de ronda
async function showRoundResult(playerValue, opponentValue, winner) {
  if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;

  // Mostrar marcador animado con las stats usadas
  const overlay = document.getElementById('round-result-overlay');
  document.getElementById('round-result-player-value').textContent = playerValue;
  document.getElementById('round-result-opponent-value').textContent = opponentValue;
  overlay.style.display = 'flex';
  
  // Si fue empate, mostrar también el marcador de totales
  const tieOverlay = document.getElementById('tie-total-overlay');
  if (window.battleState.wasTie && tieOverlay) {
    document.getElementById('tie-total-player-value').textContent = window.battleState.playerTotalInTie || 0;
    document.getElementById('tie-total-opponent-value').textContent = window.battleState.opponentTotalInTie || 0;
    tieOverlay.style.display = 'block';
  }
  
  // Añadir efecto de victoria a la carta ganadora
  const playerCardDisplay = document.querySelector('.battle-side-player .battle-card-display');
  const opponentCardDisplay = document.querySelector('.battle-side-opponent .battle-card-display');
  const playerCardImg = document.getElementById('battle-player-card');
  const opponentCardImg = document.getElementById('battle-opponent-card');
  
  // Limpiar clases previas
  playerCardDisplay.classList.remove('winner');
  opponentCardDisplay.classList.remove('winner');
  playerCardImg.classList.remove('battle-card-winner');
  opponentCardImg.classList.remove('battle-card-winner');
  
  // Añadir efecto al ganador
  if (winner === 'player') {
    playerCardDisplay.classList.add('winner');
    playerCardImg.classList.add('battle-card-winner');
  } else if (winner === 'opponent') {
    opponentCardDisplay.classList.add('winner');
    opponentCardImg.classList.add('battle-card-winner');
  }
  
  // Esperar 5 segundos para la animación (con temporizador rastreado)
  await (typeof window.battleSleep === 'function' ? window.battleSleep(5000) : new Promise(resolve => setTimeout(resolve, 5000)));

  if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) {
    console.log('[BATTLE] showRoundResult interrumpido tras espera por cancelación/abandono');
    return;
  }
  
  // Ocultar overlays
  overlay.style.display = 'none';
  if (tieOverlay) tieOverlay.style.display = 'none';
  
  // Resetear flag de empate
  window.battleState.wasTie = false;
  
  // Limpiar TODOS los efectos visuales (incluyendo las clases de brillo)
  playerCardDisplay.classList.remove('winner');
  opponentCardDisplay.classList.remove('winner');
  playerCardImg.classList.remove('battle-card-winner');
  opponentCardImg.classList.remove('battle-card-winner');
  
  // Verificar si el juego terminó (cuando cualquier jugador se queda sin cartas)
  const playerCardsLeft = window.battleState.playerTeam.length - window.battleState.playerUsedCards.length;
  const opponentCardsLeft = window.battleState.opponentTeam.length - window.battleState.opponentUsedCards.length;
  
  // El juego termina cuando cualquier jugador se queda sin cartas
  if (playerCardsLeft === 0 || opponentCardsLeft === 0) {
    if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
    await endBattle();
  } else {
    if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
    // Continuar a la siguiente ronda
    nextRound();
  }
}

// Obtener valor de una stat
function getStatValue(card, statType, side = 'player') {
  if (!card) return 0;
  const statNames = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
  let baseValue = 0;

  if (statType === 'media') {
    baseValue = parseInt(card.media) || 0;
  } else {
    const statIndex = statNames.indexOf(statType);
    if (statIndex === -1) {
      console.warn('[BATTLE] Stat desconocida:', statType);
      return 0;
    }
    const stats = card.stats || card.parametros || [];
    baseValue = parseInt(stats[statIndex]) || 0;
  }

  const cardKey = card.uniqueId || card.id;
  const baseId = card.id ? String(card.id).replace(/_notrait.*$/, '') : cardKey;

  // Trait ID
  let traitId = (typeof getCardActiveTraitId === 'function') ? getCardActiveTraitId(card, side) : (card.traitId || (side === 'opponent' ? card.opponentTraitId : null));
  if (!traitId) {
    const cardTraitsMap = window.battleState?.cardTraitsMap || {};
    const entry = cardTraitsMap[cardKey];
    traitId = entry?.traitId || entry || null;
  }

  // Inmunidad a debuffs (Especialista y Monarch)
  const isImmune = (traitId === 'especialista' || traitId === 'monarch');

  // Modificadores de Modo Infinito para la carta
  let infiniteBuff = 0;
  const infiniteBuffMap = window.battleState?.infiniteCardBuffs || window.__infiniteRunCardBuffs;
  if (infiniteBuffMap) {
    const cardBuffs = infiniteBuffMap[cardKey] || infiniteBuffMap[card.id] || infiniteBuffMap[baseId];
    if (cardBuffs) {
      if (statType === 'media') {
        const vals = statNames.map((s) => Number(cardBuffs[s]) || 0);
        infiniteBuff = Math.round(vals.reduce((a, b) => a + b, 0) / (vals.length || 1));
      } else {
        infiniteBuff = Number(cardBuffs[statType]) || 0;
      }
    }
  }
  if (isImmune && infiniteBuff < 0) infiniteBuff = 0;

  // Boost de Trait
  let traitBoost = 0;
  const availableTraits = window.battleState?.availableTraits || [];
  let trait = (typeof window.getTraitById === 'function') ? window.getTraitById(traitId) : availableTraits.find(t => t.id === traitId);

  if (traitId === 'especialista') {
    traitBoost += 5;
  } else if (traitId === 'monarch') {
    traitBoost += Math.floor(baseValue * 0.20);
  } else if (trait && trait.effect) {
    if (trait.effect.type === 'boost_all') {
      traitBoost = Number(trait.effect.value) || 0;
    } else if (trait.effect.type === 'boost_stat' && trait.effect.stat === statType) {
      traitBoost = Number(trait.effect.value) || 0;
    }
  }

  // Buff de Procedencia (incluyendo buffs copiados por Mimo)
  let procedenciaBuff = 0;
  const teamBuffs = side === 'player' ? window.battleState?.playerBuffs : window.battleState?.opponentBuffs;
  let procPercentage = 0;
  if (teamBuffs && card.procedencia && teamBuffs.byProcedencia?.[card.procedencia]) {
    const buffData = teamBuffs.byProcedencia[card.procedencia];
    if (buffData && (buffData.stats?.includes('all') || buffData.stats?.includes(statType))) {
      procPercentage += (buffData.percentage || 0);
    }
  }
  const mimoCopied = (side === 'player') ? window.battleState?.playerMimoCopiedBuffs : window.battleState?.opponentMimoCopiedBuffs;
  if (mimoCopied && mimoCopied.procedencia) {
    const cpData = mimoCopied.procedencia;
    if (cpData && (cpData.stats?.includes('all') || cpData.stats?.includes(statType))) {
      procPercentage += (cpData.percentage || 0);
    }
  }
  if (procPercentage > 0) {
    procedenciaBuff = Math.floor(baseValue * (procPercentage / 100));
  }

  // Buff de Owner (incluyendo buffs copiados por Mimo)
  let ownerBuff = 0;
  let ownerPercentage = 0;
  if (teamBuffs && card.owner && teamBuffs.byOwner?.[card.owner]) {
    const ownerBuffData = teamBuffs.byOwner[card.owner];
    if (ownerBuffData && (ownerBuffData.stats?.includes('all') || ownerBuffData.stats?.includes(statType))) {
      ownerPercentage += (ownerBuffData.percentage || 0);
    }
  }
  if (mimoCopied && mimoCopied.owner) {
    const cpOwner = mimoCopied.owner;
    if (cpOwner && (cpOwner.stats?.includes('all') || cpOwner.stats?.includes(statType))) {
      ownerPercentage += (cpOwner.percentage || 0);
    }
  }
  if (ownerPercentage > 0) {
    ownerBuff = Math.floor(baseValue * (ownerPercentage / 100));
  }

  // Buff de Kizuna (incluyendo buffs copiados por Mimo)
  let kizunaBuff = 0;
  const kizunaCardBuffs = teamBuffs?.byKizunaCard?.[baseId] || {};
  let kizunaBuffPercentage = statType === 'media'
    ? (kizunaCardBuffs.all || 0)
    : ((kizunaCardBuffs[statType] || 0) + (kizunaCardBuffs.all || 0));
  if (mimoCopied && mimoCopied.kizuna) {
    const cpKiz = mimoCopied.kizuna;
    kizunaBuffPercentage += statType === 'media'
      ? (cpKiz.all || 0)
      : ((cpKiz[statType] || 0) + (cpKiz.all || 0));
  }
  if (kizunaBuffPercentage > 0) {
    kizunaBuff = Math.floor(baseValue * (kizunaBuffPercentage / 100));
  }

  // Support Buffs (Full Support permanente + Support Maximo temporal)
  const supportPermanent = (side === 'player') ? (window.battleState?.playerSupportPermanentBuff || 0) : (window.battleState?.opponentSupportPermanentBuff || 0);
  const supportTemp = (side === 'player') ? (window.battleState?.playerSupportTempBuff || 0) : (window.battleState?.opponentSupportTempBuff || 0);
  const totalSupportPercentage = supportPermanent + supportTemp;
  const supportBuff = totalSupportPercentage > 0 ? Math.floor(baseValue * (totalSupportPercentage / 100)) : 0;

  // Power Up activo
  const powerUpActive = side === 'player' ? window.battleState?.playerPowerUpActive : window.battleState?.opponentPowerUpActive;
  const powerUpBoost = powerUpActive ? 3 : 0;

  // Modificadores temporales de batalla (ej. Nerf). Evitar duplicar powerUp si ya está en allModifier
  const modifiers = window.battleState?.statModifiers?.[cardKey] || {};
  let statModifier = Number(modifiers[statType]) || 0;
  let allModifier = Number(modifiers.all) || 0;
  if (powerUpBoost > 0 && allModifier > 0) {
    allModifier = Math.max(0, allModifier - powerUpBoost);
  }
  if (isImmune) {
    if (statModifier < 0) statModifier = 0;
    if (allModifier < 0) allModifier = 0;
  }

  // Modificador de combate del Modo Infinito
  let modifierDelta = 0;
  if (window.InfiniteModifiers && typeof window.InfiniteModifiers.getCardStatDelta === 'function') {
    modifierDelta = window.InfiniteModifiers.getCardStatDelta(side, card, statType, baseValue);
  }
  if (isImmune && modifierDelta < 0) modifierDelta = 0;

  return Math.max(1, baseValue + infiniteBuff + traitBoost + procedenciaBuff + ownerBuff + kizunaBuff + supportBuff + powerUpBoost + statModifier + allModifier + modifierDelta);
}


// Siguiente ronda
function nextRound() {
  if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
  console.log('[BATTLE] Siguiente ronda. Ganador anterior:', window.battleState.roundWinner);
  
  // Verificar si quedan cartas disponibles antes de continuar
  const playerCardsLeft = window.battleState.playerTeam.length - window.battleState.playerUsedCards.length;
  const opponentCardsLeft = window.battleState.opponentTeam.length - window.battleState.opponentUsedCards.length;
  
  console.log('[BATTLE] Cartas restantes - Jugador:', playerCardsLeft, 'Oponente:', opponentCardsLeft);
  
  // Si cualquiera no tiene cartas, finalizar batalla
  if (playerCardsLeft === 0 || opponentCardsLeft === 0) {
    console.log('[BATTLE] Al menos un jugador sin cartas, finalizando batalla...');
    if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
    endBattle();
    return;
  }
  
  window.battleState.gamePhase = 'round-end';
  
  // Limpiar cartas (mostrar placeholders vacíos)
  clearBattleCards();
  
  // Limpiar TODOS los efectos visuales previos
  const playerCardDisplay = document.querySelector('.battle-side-player .battle-card-display');
  const opponentCardDisplay = document.querySelector('.battle-side-opponent .battle-card-display');
  const playerCardImg = document.getElementById('battle-player-card');
  const opponentCardImg = document.getElementById('battle-opponent-card');
  
  if (playerCardDisplay) playerCardDisplay.classList.remove('winner');
  if (opponentCardDisplay) opponentCardDisplay.classList.remove('winner');
  if (playerCardImg) playerCardImg.classList.remove('battle-card-winner');
  if (opponentCardImg) opponentCardImg.classList.remove('battle-card-winner');

  // Transición de rasgos y buffeos de cartas que salen del campo
  const exitingPlayerCard = window.battleState.playerCurrentCard;
  const exitingOpponentCard = window.battleState.opponentCurrentCard;

  if (exitingPlayerCard) {
    const pTrait = typeof getCardActiveTraitId === 'function' ? getCardActiveTraitId(exitingPlayerCard, 'player') : null;
    window.battleState.playerSupportTempBuff = 0;
    window.battleState.playerMimoCopiedBuffs = null;
    window.battleState.playerDecoyCard = null;
    window.battleState.playerImpostorRevealed = false;

    if (pTrait === 'full_support') {
      window.battleState.playerSupportPermanentBuff = (window.battleState.playerSupportPermanentBuff || 0) + 3;
      console.log('[TRAIT] Full Support activado: +3% permanente (Total:', window.battleState.playerSupportPermanentBuff, '%)');
    } else if (pTrait === 'support_max') {
      window.battleState.playerSupportTempBuff = 10;
      console.log('[TRAIT] Support Maximo activado: +10% para la siguiente carta');
    }
  }

  if (exitingOpponentCard) {
    const oTrait = typeof getCardActiveTraitId === 'function' ? getCardActiveTraitId(exitingOpponentCard, 'opponent') : null;
    window.battleState.opponentSupportTempBuff = 0;
    window.battleState.opponentMimoCopiedBuffs = null;
    window.battleState.opponentDecoyCard = null;
    window.battleState.opponentImpostorRevealed = false;

    if (oTrait === 'full_support') {
      window.battleState.opponentSupportPermanentBuff = (window.battleState.opponentSupportPermanentBuff || 0) + 3;
      console.log('[TRAIT] Opponent Full Support activado: +3% permanente');
    } else if (oTrait === 'support_max') {
      window.battleState.opponentSupportTempBuff = 10;
      console.log('[TRAIT] Opponent Support Maximo activado: +10%');
    }
  }
  
  // Resetear stats seleccionadas
  window.battleState.selectedStat = null;
  window.battleState.opponentSelectedStat = null;
  window.battleState.playerCurrentCard = null;
  window.battleState.opponentCurrentCard = null;
  window.battleState.annulledStat = null;
  
  // Permitir cambio de carta para la próxima ronda
  window.battleState.canChangeCard = true;
  
  // El ganador de la ronda anterior elige primero (salvo con modificador Reservado)
  const isInfiniteRound = !!(window.__infiniteBattleContext?.active || window.battleState?.difficulty === 'inmo');
  const activeRoundMod = isInfiniteRound ? (window.battleState?.infiniteModifier || window.__infiniteBattleContext?.modifier) : null;
  const isReservadoRound = isInfiniteRound && activeRoundMod?.id === 'reservado';

  if (isReservadoRound) {
    window.battleState.currentTurn = 'player';
    console.log('[BATTLE] Modificador Reservado activo: El jugador actúa primero en la ronda');
  } else {
    window.battleState.currentTurn = window.battleState.roundWinner;
  }
  window.battleState.gamePhase = 'card-selection';
  
  // Limpiar active de cartas
  document.querySelectorAll('.battle-team-card').forEach(c => c.classList.remove('active'));
  
  // Mostrar sidebar SOLO si es turno del jugador
  // Si es turno del oponente, el sidebar se mostrará DESPUÉS de que coloque su carta
  const sidebar = document.getElementById('battle-team-sidebar');
  if (sidebar) {
    if (window.battleState.currentTurn === 'player') {
      sidebar.style.display = 'flex';
    } else {
      sidebar.style.display = 'none';
    }
  }
  renderTeamSidebar();
  
  // Si el oponente ganó, elige primero (salvo si el modificador Reservado está activo)
  if (!isReservadoRound && window.battleState.roundWinner === 'opponent') {
    if (window.__battleCancelled || window.__battleEnded || window.battleState?.isAbandoned) return;
    opponentSelectsCard();
  }
  
  console.log('[BATTLE] Nueva ronda iniciada. Turno:', window.battleState.currentTurn);
}

// Finalizar batalla

// Auxiliary functions for IA Estratégica Combinatoria 7v7 Alternativo
function selectOptimalCardAlternativeMode(availableIndices) {
  const opponentTeam = window.battleState.opponentTeam;
  const playerTeam = window.battleState.playerTeam;
  const playerUsedCards = window.battleState.playerUsedCards || [];
  
  const availablePlayerCards = [];
  for (let i = 0; i < playerTeam.length; i++) {
    if (!playerUsedCards.includes(i)) {
      availablePlayerCards.push(playerTeam[i]);
    }
  }
  
  const playerCard = window.battleState.playerCurrentCard;
  
  // Si el jugador ya eligió su carta
  if (playerCard) {
    let bestCardIndex = availableIndices[0];
    let bestScore = -Infinity;
    
    for (const idx of availableIndices) {
      const opCard = opponentTeam[idx];
      const score = evaluateCardMatchup(opCard, playerCard);
      if (score > bestScore) {
        bestScore = score;
        bestCardIndex = idx;
      }
    }
    return bestCardIndex;
  } else {
    // Si la IA elige primero, evalúa su carta contra el promedio esperado contra todas las del jugador
    let bestCardIndex = availableIndices[0];
    let bestScore = -Infinity;
    
    for (const idx of availableIndices) {
      const opCard = opponentTeam[idx];
      let totalScore = 0;
      
      if (availablePlayerCards.length > 0) {
        for (const pCard of availablePlayerCards) {
          totalScore += evaluateCardMatchup(opCard, pCard);
        }
        const avgScore = totalScore / availablePlayerCards.length;
        if (avgScore > bestScore) {
          bestScore = avgScore;
          bestCardIndex = idx;
        }
      }
    }
    return bestCardIndex;
  }
}

function evaluateCardMatchup(opCard, playerCard) {
  const availableStats = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
    .filter(s => !window.battleState.opponentUsedStats.includes(s));
  
  if (availableStats.length === 0) return 0;
  
  const isOpponentTurnToSelectStat = window.battleState.currentTurn === 'opponent';
  
  if (isOpponentTurnToSelectStat) {
    // La IA elegirá la stat que maximice la diferencia de puntos a su favor
    let maxDiff = -Infinity;
    for (const stat of availableStats) {
      const opVal = getStatValue(opCard, stat, 'opponent');
      const plVal = getStatValue(playerCard, stat, 'player');
      const diff = opVal - plVal;
      if (diff > maxDiff) {
        maxDiff = diff;
      }
    }
    return maxDiff;
  } else {
    // Si es el turno del jugador de elegir stat, asumimos que elegirá de sus stats disponibles la que minimice nuestra ganancia
    const playerAvailableStats = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
      .filter(s => !window.battleState.playerUsedStats.includes(s));
      
    if (playerAvailableStats.length === 0) return 0;
    
    let minDiff = Infinity;
    for (const stat of playerAvailableStats) {
      const opVal = getStatValue(opCard, stat, 'opponent');
      const plVal = getStatValue(playerCard, stat, 'player');
      const diff = opVal - plVal;
      if (diff < minDiff) {
        minDiff = diff;
      }
    }
    return minDiff;
  }
}

// Asegurar exposición global de funciones críticas
window.startBattleRoulette = startBattleRoulette;
