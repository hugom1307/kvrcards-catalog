// ==================== SISTEMA DE MANTENIMIENTO Y ACTUALIZACIONES ====================

let maintenanceCheckInterval = null;
let currentAppVersion = '1.0.0';

// Función para verificar si la cuenta actual tiene permisos de Administrador
async function isCurrentUserAdminAccount() {
  // 1. Variable en memoria de la sesión
  if (window.currentUserIsAdmin === true) return true;

  // 2. Caché en LocalStorage
  try {
    if (localStorage.getItem('kvrIsAdmin') === 'true') return true;
  } catch (_) {}

  // 3. Estado en el proceso principal de Electron (IPC)
  if (window.kvrcards && typeof window.kvrcards.getAdminStatus === 'function') {
    try {
      const isAdm = await window.kvrcards.getAdminStatus();
      if (isAdm === true) {
        window.currentUserIsAdmin = true;
        try { localStorage.setItem('kvrIsAdmin', 'true'); } catch (_) {}
        return true;
      }
    } catch (_) {}
  }

  // 4. Inventario remoto cargado por Electron
  if (window.kvrcards && typeof window.kvrcards.getRemoteInventory === 'function') {
    try {
      const invRes = await window.kvrcards.getRemoteInventory();
      if (invRes && invRes.ok && invRes.data) {
        const isAdm = Boolean(invRes.data.isAdmin === true || invRes.data.isAdmin === 'true');
        if (isAdm) {
          window.currentUserIsAdmin = true;
          try { localStorage.setItem('kvrIsAdmin', 'true'); } catch (_) {}
          return true;
        }
      }
    } catch (_) {}
  }

  // 5. Consulta HTTP directa al servidor como último recurso solo si no está en Electron
  let savedUser = '';
  try {
    savedUser = (window.currentUser || localStorage.getItem('kvrUsername') || '').trim();
  } catch (_) {}

  if (savedUser && !window.kvrcards) {
    try {
      const response = await fetch(`https://kvrcards-server.onrender.com/api/inventory/${encodeURIComponent(savedUser)}`);
      if (response.ok) {
        const userData = await response.json();
        const isAdm = Boolean(userData && (userData.isAdmin === true || userData.isAdmin === 'true'));
        if (isAdm) {
          window.currentUserIsAdmin = true;
          try { localStorage.setItem('kvrIsAdmin', 'true'); } catch (_) {}
          return true;
        }
      }
    } catch (_) {}
  }

  return false;
}

// Badge flotante de administrador en mantenimiento
function showMaintenanceAdminBadge() {
  let badge = document.getElementById('maintenance-admin-badge');
  if (!badge) {
    badge = document.createElement('div');
    badge.id = 'maintenance-admin-badge';
    badge.className = 'maintenance-admin-badge';
    badge.title = 'Modo mantenimiento activo en el servidor. Tienes acceso prioritario como Administrador para probar el juego.';
    badge.innerHTML = '👑 MODO MANTENIMIENTO ACTIVO · ACCESO ADMIN';
    document.body.appendChild(badge);
  }
  badge.style.display = 'block';
}

function hideMaintenanceAdminBadge() {
  const badge = document.getElementById('maintenance-admin-badge');
  if (badge) {
    badge.style.display = 'none';
  }
}

// Cache en memoria y control de peticiones en vuelo para evitar 429
let maintenanceCache = {
  data: null,
  timestamp: 0,
  inFlight: null
};
const MAINTENANCE_CACHE_TTL_MS = 60000; // 60 segundos de micro-caché

// Función para verificar estado de mantenimiento
async function checkMaintenanceStatus(force = false) {
  const now = Date.now();
  // 1. Reutilizar caché en memoria si no ha expirado (0 peticiones de red)
  if (!force && maintenanceCache.data && (now - maintenanceCache.timestamp < MAINTENANCE_CACHE_TTL_MS)) {
    return maintenanceCache.data;
  }

  // 2. Si ya hay una petición en vuelo, esperar a la misma promesa para evitar duplicados simultáneos
  if (maintenanceCache.inFlight) {
    return await maintenanceCache.inFlight;
  }

  maintenanceCache.inFlight = (async () => {
    try {
      // 3. En entorno Electron, priorizar la comprobación nativa mediante IPC (ultra-rápido, local y seguro)
      if (window.kvrcards && typeof window.kvrcards.checkMaintenance === 'function') {
        try {
          const ipcRes = await window.kvrcards.checkMaintenance();
          if (ipcRes && (ipcRes.maintenance || ipcRes.version)) {
            const formatted = {
              maintenance: ipcRes.maintenance || { enabled: false },
              version: ipcRes.version || { current: '1.0.0', minimumRequired: '1.0.0' }
            };
            maintenanceCache.data = formatted;
            maintenanceCache.timestamp = Date.now();
            return formatted;
          }
        } catch (ipcErr) {
          console.warn('[MAINTENANCE] Falló IPC nativo, recurriendo a CDN:', ipcErr?.message);
        }
      }

      // 4. Intentar CDN estático de GitHub Pages (SIN ?t= para aprovechar el caché de borde de Fastly y no provocar 429)
      //    y con fallback a Raw GitHub CDN
      const candidateUrls = [
        'https://hugom1307.github.io/kvrcards-catalog/remote-config.json',
        'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/remote-config.json'
      ];

      for (const url of candidateUrls) {
        try {
          const response = await fetch(url, { cache: 'default' });
          if (response.ok) {
            const config = await response.json();
            const formatted = {
              maintenance: config.maintenance || { enabled: false },
              version: config.version || { current: '1.0.0', minimumRequired: '1.0.0' }
            };
            maintenanceCache.data = formatted;
            maintenanceCache.timestamp = Date.now();
            return formatted;
          } else if (response.status === 429) {
            console.warn(`[MAINTENANCE] 429 en ${url}, probando fallback alternativo...`);
          }
        } catch (_) {}
      }

      // 5. Fallback a configuración local si no hay conexión o hubo rate-limit
      try {
        const localRes = await fetch('./remote-config.json');
        if (localRes.ok) {
          const localConfig = await localRes.json();
          const formatted = {
            maintenance: localConfig.maintenance || { enabled: false },
            version: localConfig.version || { current: '1.0.0', minimumRequired: '1.0.0' }
          };
          maintenanceCache.data = formatted;
          maintenanceCache.timestamp = Date.now();
          return formatted;
        }
      } catch (_) {}

      // Si teníamos datos previos guardados en memoria, usarlos
      if (maintenanceCache.data) return maintenanceCache.data;
      return null;
    } catch (error) {
      console.warn('[MAINTENANCE] No se pudo verificar estado de mantenimiento:', error?.message);
      return maintenanceCache.data || null;
    } finally {
      maintenanceCache.inFlight = null;
    }
  })();

  return await maintenanceCache.inFlight;
}

// Función para comparar versiones semánticas
function compareVersions(v1, v2) {
  // Retorna: -1 si v1 < v2, 0 si v1 == v2, 1 si v1 > v2
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);
  
  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const num1 = parts1[i] || 0;
    const num2 = parts2[i] || 0;
    
    if (num1 < num2) return -1;
    if (num1 > num2) return 1;
  }
  
  return 0;
}

// Función para mostrar/ocultar pantalla de mantenimiento
async function showMaintenanceScreen(maintenanceData) {
  // Comprobar si el usuario es administrador: en modo mantenimiento true, NO le sale a las cuentas admin
  const isAdmin = await isCurrentUserAdminAccount();
  if (isAdmin) {
    console.log('[MAINTENANCE] 👑 Bypass de mantenimiento: La cuenta es Administrador. No se muestra la pantalla de bloqueo.');
    hideMaintenanceScreen();
    showMaintenanceAdminBadge();
    return;
  }

  const screen = document.getElementById('maintenance-screen');
  const title = document.getElementById('maintenance-title');
  const message = document.getElementById('maintenance-message');
  const time = document.getElementById('maintenance-time');
  
  if (!screen) return;
  
  // Ocultar pantalla de versión desactualizada si está visible
  hideOutdatedVersionScreen();
  hideMaintenanceAdminBadge();
  
  title.textContent = maintenanceData?.title || '🔧 Mantenimiento en Curso';
  message.textContent = maintenanceData?.message || 'Estamos actualizando el juego. Volveremos pronto.';
  
  if (maintenanceData && maintenanceData.estimatedTime) {
    time.textContent = 'Tiempo estimado: ' + maintenanceData.estimatedTime;
    time.style.display = 'block';
  } else {
    time.style.display = 'none';
  }
  
  screen.style.display = 'flex';
  console.log('[MAINTENANCE] Pantalla de mantenimiento mostrada');
}

function hideMaintenanceScreen() {
  const screen = document.getElementById('maintenance-screen');
  if (screen) {
    screen.style.display = 'none';
    console.log('[MAINTENANCE] Pantalla de mantenimiento ocultada');
  }
}

// Función para mostrar pantalla de versión desactualizada (BLOQUEANTE)
function showOutdatedVersionScreen(currentVersion, remoteVersion, downloadUrl, changelog) {
  const screen = document.getElementById('outdated-version-screen');
  const currentVersionEl = document.getElementById('current-version-display');
  const latestVersionEl = document.getElementById('latest-version-display');
  const changelogEl = document.getElementById('update-changelog');
  const closeBtn = document.getElementById('outdated-close-btn');
  
  if (!screen) return;
  
  // Ocultar pantalla de mantenimiento si está visible
  hideMaintenanceScreen();
  
  if (currentVersionEl) currentVersionEl.textContent = 'v' + currentVersion;
  if (latestVersionEl) latestVersionEl.textContent = 'v' + remoteVersion;
  
  if (changelog && changelogEl) {
    changelogEl.textContent = 'Novedades:\n\n' + changelog;
    changelogEl.style.display = 'block';
  } else if (changelogEl) {
    changelogEl.style.display = 'none';
  }
  
  const downloadBtn = document.getElementById('outdated-download-btn');
  if (downloadBtn) {
    if (downloadUrl) {
      downloadBtn.href = downloadUrl;
      downloadBtn.style.display = 'inline-flex';
      downloadBtn.onclick = (e) => {
        e.preventDefault();
        if (window.kvrcards && typeof window.kvrcards.openExternal === 'function') {
          window.kvrcards.openExternal(downloadUrl);
        } else {
          window.open(downloadUrl, '_blank');
        }
      };
    } else {
      downloadBtn.style.display = 'none';
    }
  }

  if (closeBtn) {
    closeBtn.onclick = () => {
      if (window.kvrcards && typeof window.kvrcards.quitApp === 'function') {
        window.kvrcards.quitApp();
      } else {
        window.close();
      }
    };
  }
  
  screen.style.display = 'flex';
  console.log('[VERSION] Pantalla bloqueante: Version desactualizada mostrada:', currentVersion, '->', remoteVersion);
}

function hideOutdatedVersionScreen() {
  const screen = document.getElementById('outdated-version-screen');
  if (screen) {
    screen.style.display = 'none';
    console.log('[VERSION] Pantalla de versión desactualizada ocultada');
  }
}

// Función para verificar actualizaciones y decidir si bloquear o notificar
async function checkForUpdatesAndVersionCompatibility() {
  try {
    const status = await checkMaintenanceStatus();
    if (!status) return;
    
    // Obtener versión actual del archivo version.json local
    try {
      const versionResponse = await fetch('./version.json?t=' + Date.now());
      if (versionResponse.ok) {
        const versionData = await versionResponse.json();
        currentAppVersion = versionData.version || '1.0.0';
        console.log('[VERSION] Versión local leída desde version.json:', currentAppVersion);
      }
    } catch (e) {
      console.log('[VERSION] No se pudo leer version.json local, usando 1.0.0');
      currentAppVersion = '1.0.0';
    }
    
    const remoteVersion = status.version?.current || '1.0.0';
    const minimumRequired = status.version?.minimumRequired || '1.0.0';
    const downloadUrl = status.version?.downloadUrl || '';
    const changelog = status.version?.changelog || '';
    const forceUpdate = status.version?.forceUpdate || false;
    
    console.log('[VERSION] ========================================');
    console.log('[VERSION] Versión local:', currentAppVersion);
    console.log('[VERSION] Versión remota (GitHub):', remoteVersion);
    console.log('[VERSION] Versión mínima requerida:', minimumRequired);
    console.log('[VERSION] Actualización forzada:', forceUpdate);
    console.log('[VERSION] ========================================');
    
    // Comparar versiones
    const comparison = compareVersions(currentAppVersion, remoteVersion);
    const meetsMinimum = compareVersions(currentAppVersion, minimumRequired) >= 0;
    
    // CASO 1: Versión desactualizada - BLOQUEAR COMPLETAMENTE (pantalla bloqueante)
    // Solo si la versión local es MENOR que la remota y (no cumple el mínimo o forceUpdate está activo)
    if (comparison < 0 && (!meetsMinimum || forceUpdate)) {
      console.log('[VERSION] BLOQUEO ACTIVADO: Tu versión (' + currentAppVersion + ') es menor a la requerida (' + minimumRequired + ')');
      console.log('[VERSION] ACCESO AL JUEGO BLOQUEADO - Debes reiniciar para actualizar');
      showOutdatedVersionScreen(currentAppVersion, remoteVersion, downloadUrl, changelog);
      return;
    }
    
    // CASO 2: Hay actualización disponible pero no es obligatoria - NOTIFICAR (banner)
    if (comparison < 0 && downloadUrl) {
      console.log('[VERSION] ℹ️ Nueva versión disponible (opcional) - Mostrando notificación');
      showUpdateNotification(remoteVersion, downloadUrl, changelog);
      return;
    }
    
    // CASO 3: Versión actual o superior - Todo OK
    console.log('[VERSION] ✅ Versión actualizada - Acceso permitido');
    hideOutdatedVersionScreen();
    
  } catch (error) {
    console.error('[VERSION] Error al verificar actualizaciones:', error);
  }
}

// Función para mostrar notificación de actualización (NO bloqueante)
function showUpdateNotification(version, downloadUrl, changelog) {
  const notification = document.getElementById('update-notification');
  const versionEl = document.getElementById('update-notification-version');
  const btn = document.getElementById('update-notification-btn');
  const closeBtn = document.getElementById('update-notification-close');
  
  if (!notification) return;
  
  versionEl.textContent = 'v' + version;
  
  btn.onclick = () => {
    // Abrir directamente en el navegador
    window.open(downloadUrl, '_blank');
  };
  
  closeBtn.onclick = () => {
    notification.style.display = 'none';
  };
  
  notification.style.display = 'block';
  console.log('[UPDATE] Notificación de actualización mostrada:', version);
}

// Configurar reintentos en pantalla de mantenimiento
function setupMaintenanceRetry(maintenanceData) {
  const retryBtn = document.getElementById('maintenance-retry-btn');
  if (retryBtn) {
    retryBtn.onclick = async () => {
      console.log('[MAINTENANCE] Reintentando verificación...');
      const newStatus = await checkMaintenanceStatus();
      
      if (newStatus && newStatus.maintenance && newStatus.maintenance.enabled) {
        const isAdmin = await isCurrentUserAdminAccount();
        if (isAdmin) {
          console.log('[MAINTENANCE] 👑 Admin detectado en reintento. Acceso concedido.');
          hideMaintenanceScreen();
          showMaintenanceAdminBadge();
          await checkForUpdatesAndVersionCompatibility();
          return;
        }
        console.log('[MAINTENANCE] Aún en mantenimiento');
      } else {
        hideMaintenanceScreen();
        hideMaintenanceAdminBadge();
        console.log('[MAINTENANCE] Mantenimiento finalizado, verificando versión...');
        await checkForUpdatesAndVersionCompatibility();
      }
    };
  }
}

// Configurar botón de inicio de sesión de administrador desde pantalla de mantenimiento
function setupMaintenanceAdminLogin() {
  const adminBtn = document.getElementById('maintenance-admin-login-btn');
  if (!adminBtn) return;

  adminBtn.onclick = async () => {
    const username = prompt('👑 Ingresa tu usuario Administrador:');
    if (!username || !username.trim()) return;
    const password = prompt('🔑 Ingresa tu contraseña:');
    if (!password) return;

    try {
      const cleanUser = username.trim();
      let isAdm = false;

      if (window.kvrcards && typeof window.kvrcards.cloudLogin === 'function') {
        const loginRes = await window.kvrcards.cloudLogin(cleanUser, password);
        if (loginRes && loginRes.ok && loginRes.isAdmin) {
          isAdm = true;
          await window.kvrcards.setUsername(cleanUser);
        }
      } else {
        const authRes = await fetch('https://kvrcards-server.onrender.com/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ username: cleanUser, password })
        });
        if (authRes.ok) {
          const authData = await authRes.json();
          if (authData && authData.ok && authData.isAdmin) {
            isAdm = true;
          }
        }
      }

      if (isAdm) {
        window.currentUserIsAdmin = true;
        try {
          localStorage.setItem('kvrUsername', cleanUser);
          localStorage.setItem('kvrPassword', password);
          localStorage.setItem('kvrIsAdmin', 'true');
        } catch (_) {}
        if (window.kvrcards && typeof window.kvrcards.setAdminStatus === 'function') {
          window.kvrcards.setAdminStatus(true);
        }
        hideMaintenanceScreen();
        showMaintenanceAdminBadge();
        alert(`👑 Bienvenido Administrador "${cleanUser}". Acceso a pruebas concedido.`);
        if (typeof reloadAllClientViews === 'function') {
          await reloadAllClientViews();
        } else {
          location.reload();
        }
      } else {
        alert('❌ Error: Credenciales incorrectas o la cuenta no tiene rango de Administrador.');
      }
    } catch (loginErr) {
      console.error('[MAINTENANCE] Error en login admin:', loginErr);
      alert('❌ No se pudo conectar con el servidor.');
    }
  };
}

// Función principal para inicializar el sistema de mantenimiento
async function initMaintenanceSystem() {

  console.log('[MAINTENANCE] ========================================');
  console.log('[MAINTENANCE] Inicializando sistema de mantenimiento y versiones...');
  console.log('[MAINTENANCE] ========================================');
  
  // Verificación inicial
  const status = await checkMaintenanceStatus();
  
  // PRIORIDAD 1: Verificar mantenimiento
  if (status && status.maintenance && status.maintenance.enabled) {
    const isAdmin = await isCurrentUserAdminAccount();
    if (isAdmin) {
      console.log('[MAINTENANCE] 👑 Modo mantenimiento activo PERO la cuenta es ADMIN. Permitiendo acceso para pruebas.');
      hideMaintenanceScreen();
      showMaintenanceAdminBadge();
      await checkForUpdatesAndVersionCompatibility();
    } else {
      console.log('[MAINTENANCE] ⚠️ Modo mantenimiento activo - BLOQUEANDO acceso a usuario estándar');
      await showMaintenanceScreen(status.maintenance);
      setupMaintenanceRetry(status.maintenance);
      setupMaintenanceAdminLogin();
      return; // No continuar para usuarios comunes
    }
  } else {
    // PRIORIDAD 2: Verificar versión y compatibilidad
    console.log('[MAINTENANCE] ✅ No hay mantenimiento activo, verificando versión...');
    hideMaintenanceScreen();
    hideMaintenanceAdminBadge();
    await checkForUpdatesAndVersionCompatibility();
  }
  
  // Configurar chequeo periódico (cada 5 minutos)
  if (maintenanceCheckInterval) {
    clearInterval(maintenanceCheckInterval);
  }
  
  maintenanceCheckInterval = setInterval(async () => {
    console.log('[MAINTENANCE] ⏰ Chequeo periódico automático...');
    const status = await checkMaintenanceStatus();
    
    // Prioridad: mantenimiento > versión desactualizada
    if (status && status.maintenance && status.maintenance.enabled) {
      const isAdmin = await isCurrentUserAdminAccount();
      if (isAdmin) {
        console.log('[MAINTENANCE] 👑 Mantenimiento activo - Bypass admin activo');
        hideMaintenanceScreen();
        showMaintenanceAdminBadge();
      } else {
        hideMaintenanceAdminBadge();
        await showMaintenanceScreen(status.maintenance);
      }
    } else {
      hideMaintenanceScreen();
      hideMaintenanceAdminBadge();
      await checkForUpdatesAndVersionCompatibility();
    }
  }, 5 * 60 * 1000); // 5 minutos
}

window.isCurrentUserAdminAccount = isCurrentUserAdminAccount;
window.showMaintenanceScreen = showMaintenanceScreen;
window.hideMaintenanceScreen = hideMaintenanceScreen;
window.showMaintenanceAdminBadge = showMaintenanceAdminBadge;
window.hideMaintenanceAdminBadge = hideMaintenanceAdminBadge;
window.checkAndApplyMaintenanceAdminBypass = async function() {
  const status = await checkMaintenanceStatus();
  if (status && status.maintenance && status.maintenance.enabled) {
    const isAdmin = await isCurrentUserAdminAccount();
    if (isAdmin) {
      hideMaintenanceScreen();
      showMaintenanceAdminBadge();
      return true;
    }
  } else {
    hideMaintenanceAdminBadge();
  }
  return false;
};

// Función para esperar a que la página esté lista
function waitForPageReady(callback) {
  // No necesitamos esperar por window.kvrcards, el sistema funciona con fetch directo
  console.log('[MAINTENANCE] ✅ Sistema listo, inicializando...');
  callback();
}

// Inicializar sistema de mantenimiento cuando el DOM esté listo
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    waitForPageReady(initMaintenanceSystem);
  });
} else {
  waitForPageReady(initMaintenanceSystem);
}

console.log('[MAINTENANCE] 📦 Sistema de mantenimiento y versiones cargado');

// ==================== FIN SISTEMA DE MANTENIMIENTO ====================
