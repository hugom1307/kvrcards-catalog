(function registerOnlineBattleHandlersModule() {
  'use strict';

  // Centralized socket event binding for online battle flow.
  // Keeps app.js lighter and makes online sync changes safer.
  function bind(socket, eventName, handler) {
    socket.off(eventName);
    socket.on(eventName, handler);
  }

  function handleOpponentCardSelectedUI(data) {
    console.log('[ONLINE-BATTLE] Oponente selecciono carta:', data);

    if (data.card) {
      window.battleState.opponentCurrentCard = data.card;
      if (typeof updateBattleCards === 'function') {
        updateBattleCards();
      }
    }

    // If opponent starts first, reveal local sidebar after opponent picks.
    if (window.battleState && window.battleState.firstPlayer === false) {
      var sidebar = document.getElementById('battle-team-sidebar');
      if (sidebar) {
        sidebar.style.display = 'flex';
        console.log('[ONLINE-BATTLE] Rival eligio carta primero, ahora muestro mi sidebar');
      }

      var instruction = document.getElementById('battle-intro-instruction');
      if (instruction) {
        instruction.innerHTML = '<h1>\u2694\ufe0f El rival ya eligio carta</h1><p>Ahora selecciona la tuya</p>';
      }

      if (typeof showNotification === 'function') {
        showNotification('\u2694\ufe0f El rival ya eligio su carta. \u00a1Tu turno!', 'info');
      }
    } else {
      if (typeof showNotification === 'function') {
        showNotification('\u2694\ufe0f El rival ya eligio su carta', 'info');
      }
    }
  }

  window.registerOnlineBattleSocketHandlers = function registerOnlineBattleSocketHandlers(socket) {
    if (!socket) return;

    // Battle sync events (player/opponent actions).
    bind(socket, 'opponent-ready', function(data) {
      console.log('[ONLINE] Oponente listo:', data);
      if (typeof handleOpponentReady === 'function') handleOpponentReady(data);
    });

    bind(socket, 'opponent-stat-selected', function(data) {
      console.log('[ONLINE] Oponente selecciono stat:', data);
      if (typeof handleOpponentStatSelected === 'function') handleOpponentStatSelected(data);
    });

    bind(socket, 'opponent-power-used', function(data) {
      console.log('[LOG-SOCKET] Evento socket "opponent-power-used" recibido. Payload:', JSON.stringify(data));
      console.log('[LOG-SOCKET] ¿Existe handleOpponentPowerUsed global?', typeof handleOpponentPowerUsed === 'function');
      if (typeof handleOpponentPowerUsed === 'function') {
        console.log('[LOG-SOCKET] Invocando handleOpponentPowerUsed...');
        handleOpponentPowerUsed(data);
      }
    });

    bind(socket, 'stat-auto-assigned', function(data) {
      console.log('[ONLINE-BATTLE] Stat auto-asignada por el servidor:', data);
      if (typeof handleStatAutoAssigned === 'function') handleStatAutoAssigned(data);
    });

    bind(socket, 'opponent-stat-auto-assigned', function(data) {
      console.log('[ONLINE-BATTLE] Stat del oponente auto-asignada por el servidor:', data);
      if (typeof handleOpponentStatAutoAssigned === 'function') handleOpponentStatAutoAssigned(data);
    });

    bind(socket, 'power-confirmed', function(data) {
      console.log('[LOG-SOCKET] Evento socket "power-confirmed" recibido. Payload:', JSON.stringify(data));
      console.log('[LOG-SOCKET] ¿Existe handlePowerConfirmed global?', typeof handlePowerConfirmed === 'function');
      if (typeof handlePowerConfirmed === 'function') {
        console.log('[LOG-SOCKET] Invocando handlePowerConfirmed...');
        handlePowerConfirmed(data);
      }
    });

    bind(socket, 'power-error', function(data) {
      console.error('[LOG-SOCKET] Evento socket "power-error" recibido. Payload:', JSON.stringify(data));
      console.log('[LOG-SOCKET] ¿Existe handlePowerError global?', typeof handlePowerError === 'function');
      if (typeof handlePowerError === 'function') {
        console.log('[LOG-SOCKET] Invocando handlePowerError...');
        handlePowerError(data);
      } else if (typeof showNotification === 'function') {
        showNotification('\u26a0\ufe0f ' + (data && data.message ? data.message : 'Error al usar poder'), 'warning');
      }
    });

    bind(socket, 'opponent-disconnected', function() {
      console.log('[ONLINE] Oponente desconectado');
      if (typeof handleOpponentDisconnected === 'function') handleOpponentDisconnected();
    });

    bind(socket, 'opponent-card-selected', handleOpponentCardSelectedUI);

    // Server authoritative flow events.
    bind(socket, 'round-start', function(data) {
      console.log('[ONLINE-BATTLE] \ud83c\udfae Servidor inicia ronda:', data);
      if (typeof handleServerRoundStart === 'function') handleServerRoundStart(data);
    });

    bind(socket, 'select-stat', function(data) {
      console.log('[ONLINE-BATTLE] \ud83d\udcca Servidor solicita seleccion de stat:', data);
      if (typeof handleServerSelectStat === 'function') handleServerSelectStat(data);
    });

    bind(socket, 'round-result', function(data) {
      console.log('[ONLINE-BATTLE] \ud83c\udfc6 Resultado de ronda desde servidor:', data);
      if (typeof handleServerRoundResult === 'function') handleServerRoundResult(data);
    });

    bind(socket, 'battle-finished', function(data) {
      console.log('[ONLINE-BATTLE] \ud83c\udf89 Batalla terminada por servidor:', data);
      if (typeof handleServerBattleFinished === 'function') handleServerBattleFinished(data);
    });
  };
})();
