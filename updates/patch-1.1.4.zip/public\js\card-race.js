// ========================================
// GAMBLING - CARRERA DE CARTAS
// ========================================
// Modo de gambling donde el jugador apuesta coins,
// elige una única carta y compite en una carrera
// basada en velocidad + promedio de stats contra la IA.
// ========================================

console.log('[CARD-RACE] Módulo Carrera de Cartas cargado');

// ---- Configuración de dificultad ----
const RACE_DIFFICULTY_CONFIG = {
  easy:       { rows: 3, multiplier: 3,  label: 'Fácil',      aiMode: 'top3' },
  normal:     { rows: 4, multiplier: 4,  label: 'Normal',     aiMode: 'top3' },
  hard:       { rows: 5, multiplier: 5,  label: 'Difícil',    aiMode: 'top3' },
  impossible: { rows: 6, multiplier: 10, label: 'Imposible',  aiMode: 'best' }
};

const RACE_MIN_BET = 1000;
const CARDS_PER_ROW = 6;

// ---- Estado del juego ----
let raceState = null; // null = no juego activo

// ---- Catálogo de cartas cacheado ----
let raceCatalogCache = null;

// =======================================================
// FUNCIONES AUXILIARES
// =======================================================

// Retorna la imagen de fondo basada en probabilidad (90% cardrace.png, 10% cardracealt.png)
function getRandomRaceBg() {
  const rand = Math.random();
  return rand < 0.90 ? 'cardrace.png' : 'cardracealt.png';
}

function getCardStatValue(card, statIndex) {
  if (card.stats && Array.isArray(card.stats)) {
    return parseInt(card.stats[statIndex]) || 0;
  }
  if (card.parametros && Array.isArray(card.parametros)) {
    return parseInt(card.parametros[statIndex]) || 0;
  }
  const prop = `stat${statIndex + 1}`;
  return parseInt(card[prop]) || 0;
}

// Fórmula de rendimiento: 70% velocidad + 30% promedio del resto
function calculateRacePerformance(card) {
  const velocidad = getCardStatValue(card, 3); // stat4 = velocidad
  const ninjutsu   = getCardStatValue(card, 0);
  const taijutsu   = getCardStatValue(card, 1);
  const resistencia = getCardStatValue(card, 2);
  const defensa    = getCardStatValue(card, 4);
  const fisico     = getCardStatValue(card, 5);
  
  const avgOther = (ninjutsu + taijutsu + resistencia + defensa + fisico) / 5;
  return (0.70 * velocidad) + (0.30 * avgOther);
}

function getCardName(card) {
  return card.nombre || card.name || card.id || '???';
}

function getCardImage(card) {
  return card.imageUrl || card.imagen || card.image || '';
}

function getCardMedia(card) {
  return parseInt(card.media) || 0;
}

// Shuffle array (Fisher-Yates)
function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// =======================================================
// OBTENER CATÁLOGO DE CARTAS
// =======================================================

async function getRaceCatalog() {
  if (raceCatalogCache && raceCatalogCache.length > 0) {
    return raceCatalogCache;
  }
  
  try {
    let allCards = [];
    
    if (window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
      const result = await window.kvrcards.getAllCards();
      if (result && result.ok && result.cards) {
        allCards = Object.values(result.cards);
      } else if (Array.isArray(result)) {
        allCards = result;
      }
    }
    
    // Filtrar cartas que tienen stats válidos y NO son calidad 'Evo'
    raceCatalogCache = allCards.filter(card => {
      const vel = getCardStatValue(card, 3);
      const media = getCardMedia(card);
      return vel > 0 && media > 0 && card.calidad !== 'Evo';
    });
    
    console.log(`[CARD-RACE] Catálogo cargado: ${raceCatalogCache.length} cartas válidas`);
    return raceCatalogCache;
  } catch (err) {
    console.error('[CARD-RACE] Error cargando catálogo:', err);
    return [];
  }
}

// =======================================================
// SISTEMA DE PISTAS
// =======================================================

function generateHintForRow(cards, difficulty) {
  const isEasyOrNormal = (difficulty === 'easy' || difficulty === 'normal');
  const roll = Math.random();
  
  // En Fácil y Normal, hay un 60% de probabilidad de tener 3 pistas individuales
  if (isEasyOrNormal && roll < 0.60) {
    const indices = shuffleArray([0, 1, 2, 3, 4, 5]).slice(0, 3);
    const hints = indices.map(idx => {
      const card = cards[idx];
      const cardNum = idx + 1;
      const subRoll = Math.random();
      
      if (subRoll < 0.33) {
        const statNames = ['Ninjutsu', 'Taijutsu', 'Resistencia', 'Velocidad', 'Defensa', 'Físico'];
        const statIdx = Math.floor(Math.random() * 6);
        const statVal = getCardStatValue(card, statIdx);
        return `La Carta #${cardNum} tiene ${statVal} de ${statNames[statIdx]}`;
      } else if (subRoll < 0.66) {
        const vel = getCardStatValue(card, 3);
        return `La Carta #${cardNum} tiene ${vel} de Velocidad`;
      } else {
        const media = getCardMedia(card);
        return `La Carta #${cardNum} tiene una media de ${media}`;
      }
    });
    
    return {
      type: 'individual_3',
      text: hints.map(h => `• ${h}`).join('<br>'),
      icon: '◈'
    };
  } else {
    // Pista única (individual o global) para Difícil/Imposible o Fácil/Normal (40%)
    const singleRoll = Math.random();
    if (singleRoll < 0.50) {
      const randomCardIdx = Math.floor(Math.random() * cards.length);
      const card = cards[randomCardIdx];
      const cardNum = randomCardIdx + 1;
      const vel = getCardStatValue(card, 3);
      return {
        type: 'individual_1',
        text: `La Carta #${cardNum} tiene ${vel} de Velocidad`,
        icon: '◈'
      };
    } else {
      const avgPerf = cards.reduce((s, c) => s + calculateRacePerformance(c), 0) / cards.length;
      return {
        type: 'global',
        text: `El rendimiento medio de la fila es ${avgPerf.toFixed(1)}`,
        icon: '◈'
      };
    }
  }
}

// =======================================================
// SELECCIÓN DE IA
// =======================================================

function aiSelectCard(cards, mode) {
  const withPerf = cards.map((card, idx) => ({
    card,
    idx,
    performance: calculateRacePerformance(card)
  }));
  
  withPerf.sort((a, b) => b.performance - a.performance);
  
  if (mode === 'best') {
    return withPerf[0].idx;
  }
  
  const topN = Math.min(3, withPerf.length);
  const chosen = Math.floor(Math.random() * topN);
  return withPerf[chosen].idx;
}

// =======================================================
// OBTENER WALLET
// =======================================================

async function getRaceWalletCoins() {
  try {
    if (window.kvrcards && typeof window.kvrcards.getWallet === 'function') {
      const w = await window.kvrcards.getWallet();
      return w.coins || 0;
    }
    const el = document.getElementById('wallet-coins-amt');
    return parseInt(el?.textContent) || 0;
  } catch {
    return 0;
  }
}

// =======================================================
// ABRIR / CERRAR MODAL
// =======================================================

window.openCardRaceModal = async function() {
  const modal = document.getElementById('card-race-modal');
  if (!modal) return;
  
  console.log('[CARD-RACE] Abriendo Carrera de Cartas');
  
  // Determinar la imagen de fondo usando el sistema de probabilidad
  const bgImage = getRandomRaceBg();
  console.log(`[CARD-RACE] Imagen seleccionada para el fondo: ${bgImage}`);
  
  const modalContent = modal.querySelector('.card-race-modal-content');
  if (modalContent) {
    // Usamos ruta relativa compatible con file:// (Electron) y http:// (Web)
    modalContent.style.setProperty('--card-race-bg', `url('./gambling/${bgImage}')`);
  }
  
  const gamblingPanel = document.getElementById('gambling-panel');
  if (gamblingPanel) gamblingPanel.style.display = 'none';
  
  showRaceScreen('config');
  
  const coins = await getRaceWalletCoins();
  const balanceEl = document.getElementById('race-balance-coins-val');
  if (balanceEl) balanceEl.textContent = coins.toLocaleString();
  
  raceState = null;
  document.getElementById('race-bet-amount').value = '';
  document.getElementById('race-bet-error').style.display = 'none';
  document.getElementById('race-start-btn').disabled = true;
  
  document.querySelectorAll('.race-difficulty-btn').forEach(btn => btn.classList.remove('active'));
  
  modal.classList.add('active');
  
  if (window.kvrcards && typeof window.kvrcards.windowForceFocus === 'function') {
    try { await window.kvrcards.windowForceFocus(); } catch {}
  }
  
  getRaceCatalog();
};

window.closeCardRaceModal = function() {
  const modal = document.getElementById('card-race-modal');
  if (!modal) return;
  
  if (raceState && raceState.phase !== 'result') {
    const confirmClose = confirm('⚠️ Si cierras ahora, perderás tu apuesta. ¿Estás seguro?');
    if (!confirmClose) return;
  }
  
  console.log('[CARD-RACE] Cerrando Carrera de Cartas');
  modal.classList.remove('active');
  raceState = null;
  
  const gamblingPanel = document.getElementById('gambling-panel');
  if (gamblingPanel) gamblingPanel.style.display = 'block';
};

// =======================================================
// NAVEGACIÓN ENTRE PANTALLAS
// =======================================================

function showRaceScreen(screenName) {
  const screens = ['config', 'selection', 'track', 'result'];
  screens.forEach(s => {
    const el = document.getElementById(`race-${s}-screen`);
    if (el) el.style.display = (s === screenName) ? 'flex' : 'none';
  });
}

// =======================================================
// SELECCIÓN DE DIFICULTAD
// =======================================================

window.selectRaceDifficulty = function(diff) {
  document.querySelectorAll('.race-difficulty-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.difficulty === diff);
  });
  
  window._selectedRaceDifficulty = diff;
  validateRaceBet();
};

// =======================================================
// VALIDAR APUESTA
// =======================================================

window.validateRaceBet = function() {
  const inputEl = document.getElementById('race-bet-amount');
  const startBtn = document.getElementById('race-start-btn');
  const errorEl = document.getElementById('race-bet-error');
  
  const rawValue = inputEl.value;
  const amount = parseInt(rawValue) || 0;
  const difficulty = window._selectedRaceDifficulty;
  
  errorEl.style.display = 'none';
  
  if (!difficulty) {
    startBtn.disabled = true;
    return;
  }
  
  if (rawValue === '') {
    startBtn.disabled = true;
    return;
  }
  
  if (amount < 1000) {
    errorEl.textContent = 'La apuesta mínima es de 1000 monedas.';
    errorEl.style.display = 'block';
    startBtn.disabled = true;
    return;
  }
  
  startBtn.disabled = false;
};

// =======================================================
// INICIAR JUEGO
// =======================================================

window.startCardRace = async function() {
  const inputEl = document.getElementById('race-bet-amount');
  const startBtn = document.getElementById('race-start-btn');
  const errorEl = document.getElementById('race-bet-error');
  
  const betAmount = parseInt(inputEl.value) || 0;
  const difficulty = window._selectedRaceDifficulty;
  
  if (!difficulty) {
    errorEl.textContent = 'Por favor, selecciona una dificultad.';
    errorEl.style.display = 'block';
    startBtn.disabled = true;
    return;
  }
  
  if (inputEl.value === '') {
    errorEl.textContent = 'Por favor, introduce una apuesta.';
    errorEl.style.display = 'block';
    startBtn.disabled = true;
    return;
  }
  
  if (betAmount < 1000) {
    errorEl.textContent = 'La apuesta mínima es de 1000 monedas.';
    errorEl.style.display = 'block';
    startBtn.disabled = true;
    return;
  }
  
  const config = RACE_DIFFICULTY_CONFIG[difficulty];
  if (!config) return;
  
  // Verificar saldo
  const currentCoins = await getRaceWalletCoins();
  if (currentCoins < betAmount) {
    errorEl.textContent = `No tienes suficientes coins. Saldo actual: ${currentCoins.toLocaleString()}`;
    errorEl.style.display = 'block';
    return;
  }
  
  // Obtener catálogo
  const catalog = await getRaceCatalog();
  if (catalog.length < CARDS_PER_ROW * config.rows) {
    errorEl.textContent = `No hay suficientes cartas en el catálogo (se necesitan ${CARDS_PER_ROW * config.rows}).`;
    errorEl.style.display = 'block';
    return;
  }
  
  startBtn.disabled = true;
  errorEl.style.display = 'none';
  
  // Deducir apuesta
  try {
    if (window.kvrcards && typeof window.kvrcards.gamblingBet === 'function') {
      const betResult = await window.kvrcards.gamblingBet(betAmount);
      if (betResult && betResult.error) {
        errorEl.textContent = betResult.error;
        errorEl.style.display = 'block';
        startBtn.disabled = false;
        return;
      }
    } else {
      throw new Error('Función window.kvrcards.gamblingBet no disponible');
    }
  } catch (err) {
    console.error('[CARD-RACE] Error deduciendo apuesta:', err);
    errorEl.textContent = 'Error al procesar la apuesta. Inténtalo de nuevo.';
    errorEl.style.display = 'block';
    startBtn.disabled = false;
    return;
  }
  
  if (typeof renderWallet === 'function') await renderWallet();
  
  // Generar filas con cartas aleatorias
  const shuffled = shuffleArray(catalog);
  const rows = [];
  
  for (let r = 0; r < config.rows; r++) {
    const startIdx = r * CARDS_PER_ROW;
    const rowCards = shuffled.slice(startIdx, startIdx + CARDS_PER_ROW);
    
    rows.push({
      cards: rowCards,
      hint: generateHintForRow(rowCards, difficulty),
      playerChoice: null,
      aiChoice: null,
      isPlayerRow: false,
      runnerCard: null,
      runnerPerf: 0,
      finalTime: 0,
      rank: 0,
      playerWon: false
    });
  }
  
  // Crear estado del juego
  raceState = {
    phase: 'selection',
    difficulty: difficulty,
    config: config,
    betAmount: betAmount,
    rows: rows,
    playerRowIdx: null,
    playerCardIdx: null,
    podium: []
  };
  
  console.log(`[CARD-RACE] Juego iniciado: ${config.label}, apuesta: ${betAmount}, filas: ${config.rows}`);
  
  renderSelectionScreen();
  showRaceScreen('selection');
};

// =======================================================
// RENDERIZAR PANTALLA DE SELECCIÓN
// =======================================================

function renderSelectionScreen() {
  const container = document.getElementById('race-rows-container');
  if (!container || !raceState) return;
  
  container.innerHTML = '';
  
  raceState.rows.forEach((row, rowIdx) => {
    const rowEl = document.createElement('div');
    rowEl.className = 'race-row';
    rowEl.id = `race-row-${rowIdx}`;
    
    // Header
    const headerEl = document.createElement('div');
    headerEl.className = 'race-row-header';
    headerEl.innerHTML = `
      <span class="race-row-label">Fila ${rowIdx + 1}</span>
      <span class="race-row-status" id="race-row-status-${rowIdx}">Pendiente</span>
    `;
    rowEl.appendChild(headerEl);
    
    // Hint
    const hintEl = document.createElement('div');
    hintEl.className = 'race-hint-panel';
    hintEl.innerHTML = `
      <span class="race-hint-icon">${row.hint.icon}</span>
      <span class="race-hint-text">${row.hint.text}</span>
    `;
    rowEl.appendChild(hintEl);
    
    // Cards grid
    const gridEl = document.createElement('div');
    gridEl.className = 'race-cards-grid';
    
    row.cards.forEach((card, cardIdx) => {
      const cardEl = document.createElement('div');
      cardEl.className = 'race-card mystery';
      cardEl.dataset.row = rowIdx;
      cardEl.dataset.card = cardIdx;
      cardEl.id = `race-card-${rowIdx}-${cardIdx}`;
      
      const numBadge = document.createElement('div');
      numBadge.className = 'race-card-number';
      numBadge.textContent = `#${cardIdx + 1}`;
      cardEl.appendChild(numBadge);
      
      const img = document.createElement('img');
      img.className = 'race-card-img';
      img.src = getCardImage(card);
      img.alt = getCardName(card);
      img.style.display = 'none';
      img.onerror = function() { this.style.display = 'none'; };
      cardEl.appendChild(img);
      
      const mystery = document.createElement('div');
      mystery.className = 'race-card-mystery-icon';
      mystery.textContent = '?';
      cardEl.appendChild(mystery);
      
      cardEl.addEventListener('click', () => {
        selectCardInRow(rowIdx, cardIdx);
      });
      
      gridEl.appendChild(cardEl);
    });
    
    rowEl.appendChild(gridEl);
    container.appendChild(rowEl);
  });
  
  updateBeginRaceButton();
}

// =======================================================
// SELECCIONAR CARTA EN FILA (JUGADOR Y LUEGO AUTO IA)
// =======================================================

function selectCardInRow(rowIdx, cardIdx) {
  if (!raceState || raceState.phase !== 'selection') return;
  
  if (typeof playSFX === 'function') playSFX('cardSelect');
  
  // Registrar elección del jugador
  raceState.playerRowIdx = rowIdx;
  raceState.playerCardIdx = cardIdx;
  raceState.phase = 'ready'; // Bloquear futuras elecciones
  
  // 1. Asignar la carta del jugador en su fila
  const playerRow = raceState.rows[rowIdx];
  playerRow.playerChoice = cardIdx;
  playerRow.isPlayerRow = true;
  playerRow.runnerCard = playerRow.cards[cardIdx];
  playerRow.runnerPerf = calculateRacePerformance(playerRow.runnerCard);
  
  revealCardVisual(rowIdx, cardIdx, 'player');
  fadeUnselectedCardsInRow(rowIdx, cardIdx);
  
  // 2. La IA selecciona automáticamente para los demás carriles
  raceState.rows.forEach((row, rIdx) => {
    if (rIdx === rowIdx) return; // Saltar fila del jugador
    
    const aiIdx = aiSelectCard(row.cards, raceState.config.aiMode);
    row.aiChoice = aiIdx;
    row.isPlayerRow = false;
    row.runnerCard = row.cards[aiIdx];
    row.runnerPerf = calculateRacePerformance(row.runnerCard);
    
    revealCardVisual(rIdx, aiIdx, 'ai');
    fadeUnselectedCardsInRow(rIdx, aiIdx);
  });
  
  // 3. Actualizar estados de las filas a 'Elegida'
  raceState.rows.forEach((row, rIdx) => {
    const statusEl = document.getElementById(`race-row-status-${rIdx}`);
    if (statusEl) {
      statusEl.textContent = 'Elegida';
      statusEl.classList.add('done');
    }
  });
  
  updateBeginRaceButton();
}

function revealCardVisual(rowIdx, cardIdx, owner) {
  const cardEl = document.getElementById(`race-card-${rowIdx}-${cardIdx}`);
  if (!cardEl) return;
  
  cardEl.classList.remove('mystery');
  cardEl.classList.add(owner === 'player' ? 'selected' : 'ai-selected');
  
  const img = cardEl.querySelector('.race-card-img');
  if (img) img.style.display = 'block';
  
  const mystery = cardEl.querySelector('.race-card-mystery-icon');
  if (mystery) mystery.style.display = 'none';
  
  const existingBadge = cardEl.querySelector('.race-card-badge');
  if (existingBadge) existingBadge.remove();
  
  const badge = document.createElement('div');
  badge.className = `race-card-badge ${owner}-badge`;
  badge.textContent = owner === 'player' ? 'TÚ' : 'IA';
  cardEl.appendChild(badge);
}

function fadeUnselectedCardsInRow(rowIdx, selectedIdx) {
  const rowEl = document.getElementById(`race-row-${rowIdx}`);
  if (!rowEl) return;
  
  const cards = rowEl.querySelectorAll('.race-card');
  cards.forEach((card, idx) => {
    if (idx !== selectedIdx) {
      card.classList.add('not-selected');
      card.style.pointerEvents = 'none';
      const mystery = card.querySelector('.race-card-mystery-icon');
      if (mystery) mystery.style.opacity = '0.15';
    }
  });
}

function updateBeginRaceButton() {
  const btn = document.getElementById('race-begin-btn');
  if (!btn || !raceState) return;
  
  const allDone = raceState.playerRowIdx !== null;
  btn.disabled = !allDone;
  btn.style.display = allDone ? 'block' : 'none';
}

// =======================================================
// COMENZAR CARRERA
// =======================================================

// Helper local para obtener URL base de API de Gambling
async function getGamblingBaseUrl() {
  if (window.kvrcards && typeof window.kvrcards.getInventoryServerInfo === 'function') {
    try {
      const serverInfo = await window.kvrcards.getInventoryServerInfo();
      if (serverInfo && serverInfo.ok && serverInfo.effectiveBaseUrl) {
        let base = serverInfo.effectiveBaseUrl;
        if (base.endsWith('/')) {
          base = base.slice(0, -1);
        }
        return base;
      }
    } catch (e) {
      console.error('[CARD-RACE] Error al obtener getInventoryServerInfo:', e);
    }
  }
  return 'https://kvrcards-server.onrender.com';
}

window.beginRace = async function() {
  if (!raceState || raceState.phase !== 'ready') return;
  
  raceState.phase = 'racing';
  
  showRaceScreen('track');
  renderRaceTracks();
  
  await runCountdown();
  revealRaceCards();
  await runAllRaces();
  
  // Detener el audio cardsrunning.mp3 y liberar la instancia cuando todos cruzan
  if (window._raceSoundInstance) {
    if (typeof stopSFX === 'function') {
      stopSFX(window._raceSoundInstance, 300);
    } else {
      try {
        window._raceSoundInstance.pause();
        window._raceSoundInstance.currentTime = 0;
      } catch {}
    }
    window._raceSoundInstance = null;
  }
  
  await showRaceResults();
};

// =======================================================
// RENDERIZAR PISTAS DE CARRERA (1 CORREDOR POR PISTA)
// =======================================================

function renderRaceTracks() {
  const container = document.getElementById('race-tracks-container');
  if (!container || !raceState) return;
  
  container.innerHTML = '';
  
  raceState.rows.forEach((row, rowIdx) => {
    const trackEl = document.createElement('div');
    trackEl.className = 'race-track';
    trackEl.id = `race-track-${rowIdx}`;
    
    // Label
    const labelEl = document.createElement('div');
    labelEl.className = 'race-track-label';
    labelEl.textContent = `F${rowIdx + 1}`;
    trackEl.appendChild(labelEl);
    
    // Finish line
    const finishEl = document.createElement('div');
    finishEl.className = 'race-track-finish-line';
    trackEl.appendChild(finishEl);
    
    // Corredor único asignado
    const card = row.runnerCard;
    const cardTrack = document.createElement('div');
    cardTrack.className = 'race-track-card';
    cardTrack.id = `race-track-card-${rowIdx}`;
    cardTrack.style.left = '2%';
    cardTrack.style.top = '10px';
    
    if (row.isPlayerRow) {
      cardTrack.classList.add('player-card');
    } else {
      cardTrack.classList.add('ai-card');
    }
    
    const img = document.createElement('img');
    img.src = getCardImage(card);
    img.alt = getCardName(card);
    img.onerror = function() {
      this.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="40" height="56"><rect width="100%" height="100%" fill="%23333" rx="4"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" fill="%23999" font-size="10">?</text></svg>';
    };
    cardTrack.appendChild(img);
    
    const nameTag = document.createElement('div');
    nameTag.className = 'race-track-card-name';
    nameTag.textContent = row.isPlayerRow ? 'TÚ' : 'IA';
    cardTrack.appendChild(nameTag);
    
    trackEl.appendChild(cardTrack);
    container.appendChild(trackEl);
  });
}

// =======================================================
// COUNTDOWN
// =======================================================

async function runCountdown() {
  const overlay = document.getElementById('race-countdown-overlay');
  if (!overlay) return;
  
  overlay.style.display = 'flex';
  
  // Detener instancia previa para evitar superposiciones
  if (window._raceSoundInstance) {
    if (typeof stopSFX === 'function') {
      stopSFX(window._raceSoundInstance);
    } else {
      try { window._raceSoundInstance.pause(); } catch {}
    }
    window._raceSoundInstance = null;
  }
  
  // Iniciar cardsrunning.mp3 justo al aparecer la cuenta atrás en "3"
  if (typeof playSFX === 'function') {
    window._raceSoundInstance = playSFX('cardsrunning', { loop: true });
  }
  
  const steps = ['3', '2', '1', '¡GO!'];
  
  for (const step of steps) {
    overlay.textContent = step;
    overlay.classList.remove('countdown-animate');
    void overlay.offsetWidth; // Trigger reflow
    overlay.classList.add('countdown-animate');
    
    if (typeof playSFX === 'function') playSFX('cardSelect');
    
    await new Promise(r => setTimeout(r, 800));
  }
  
  await new Promise(r => setTimeout(r, 400));
  overlay.style.display = 'none';
}

// =======================================================
// REVELAR CORREDORES
// =======================================================

function revealRaceCards() {
  if (!raceState) return;
  
  raceState.rows.forEach((row, rowIdx) => {
    const cardEl = document.getElementById(`race-track-card-${rowIdx}`);
    if (cardEl) {
      cardEl.classList.add('revealed');
    }
  });
}

// =======================================================
// EJECUTAR SIMULACIÓN DE CARRERA (DURACIÓN ~30 SEGUNDOS)
// =======================================================

async function runAllRaces() {
  if (!raceState) return;
  
  // 1. Calcular tiempos finales con 3 decimales
  const baseTime = 14.0; // tiempo base
  raceState.rows.forEach((row) => {
    const perf = row.runnerPerf;
    const perfFactor = (perf / 100) * 2.5; // mejor rendimiento resta hasta 2.5s
    const randomFactor = Math.random() * 1.5;
    row.finalTime = parseFloat((baseTime - perfFactor + randomFactor).toFixed(3));
  });
  
  // 2. Garantizar que NO haya empates absolutos
  let times = raceState.rows.map(r => r.finalTime);
  let hasTies = true;
  while (hasTies) {
    hasTies = false;
    for (let i = 0; i < times.length; i++) {
      for (let j = i + 1; j < times.length; j++) {
        if (Math.abs(times[i] - times[j]) < 0.001) {
          times[j] += 0.005 + Math.random() * 0.01;
          times[j] = parseFloat(times[j].toFixed(3));
          hasTies = true;
        }
      }
    }
  }
  
  // Reasignar tiempos finales sin duplicados
  raceState.rows.forEach((row, idx) => {
    row.finalTime = times[idx];
  });
  
  // 3. Determinar el orden y las posiciones del podio
  const sorted = [...raceState.rows].sort((a, b) => a.finalTime - b.finalTime);
  
  raceState.rows.forEach((row) => {
    row.rank = sorted.indexOf(row);
    row.playerWon = (row.rank === 0 && row.isPlayerRow);
  });
  
  raceState.podium = sorted.map((row, idx) => ({
    rank: idx,
    rowIdx: raceState.rows.indexOf(row),
    card: row.runnerCard,
    finalTime: row.finalTime,
    isPlayer: row.isPlayerRow
  }));
  
  // 4. Iniciar la animación física simultánea (esperar a que todos terminen)
  const promises = raceState.rows.map((row, rowIdx) => 
    animateRace(row, rowIdx)
  );
  
  await Promise.all(promises);
}

function animateRace(row, rowIdx) {
  return new Promise(resolve => {
    const startTime = performance.now();
    // La duración de animación es proporcional a su tiempo final * 2000 (aproximadamente 30 segundos)
    const runnerDuration = row.finalTime * 2000;
    
    // Todos los participantes cruzan la meta al 92%
    const finalPos = 92;
    
    // Parámetros de oscilación (para adelantamientos visuales emocionantes)
    const freq = 4.5 + Math.random() * 2.0;
    const phase = rowIdx * 1.8;
    const maxOscillation = 8.0; // amplitud de desvío
    
    function tick(now) {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / runnerDuration, 1);
      
      const easedProgress = easeInOutQuad(progress);
      
      // Variación no lineal del ritmo (aceleraciones y deceleraciones)
      const paceChange = Math.sin(progress * Math.PI * 2) * 0.04 * Math.sin(progress * Math.PI);
      const modifiedProgress = Math.max(0, Math.min(1, easedProgress + paceChange));
      
      // Amortiguación de la oscilación hacia el final de la carrera
      const decay = Math.pow(1 - progress, 1.2);
      const oscillation = Math.sin(progress * Math.PI * freq + phase) * maxOscillation * decay;
      
      // Posición actual
      let pos = 2 + (modifiedProgress * (finalPos - 2)) + oscillation;
      pos = Math.max(2, Math.min(94, pos));
      
      const cardEl = document.getElementById(`race-track-card-${rowIdx}`);
      if (cardEl) {
        cardEl.style.left = `${pos}%`;
      }
      
      if (progress < 1) {
        requestAnimationFrame(tick);
      } else {
        // Fin de la carrera para este carril
        const trackEl = document.getElementById(`race-track-${rowIdx}`);
        if (trackEl) {
          trackEl.classList.add('race-finished');
          
          if (row.rank === 0) {
            // Se marca inmediatamente como ganadora con brillo verde y corona
            trackEl.classList.add('race-won');
            if (cardEl) {
              cardEl.classList.add('winner-glow');
              const nameTag = cardEl.querySelector('.race-track-card-name');
              if (nameTag) {
                nameTag.innerHTML = `👑 ${row.isPlayerRow ? 'TÚ' : 'IA'}`;
              }
            }
          } else {
            trackEl.classList.add('race-lost');
          }
        }
        
        if (typeof playSFX === 'function' && row.isPlayerRow) {
          playSFX(row.rank === 0 ? 'cardSelect' : 'packSplitWhoosh');
        }
        
        resolve();
      }
    }
    
    requestAnimationFrame(tick);
  });
}

function easeInOutQuad(t) {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}

// =======================================================
// MOSTRAR RESULTADOS
// =======================================================

async function showRaceResults() {
  if (!raceState) return;
  
  raceState.phase = 'result';
  
  await new Promise(r => setTimeout(r, 1500));
  
  // Ganar la apuesta requiere quedar en 1er lugar (rank === 0) en su carril
  const playerRow = raceState.rows[raceState.playerRowIdx];
  const playerWon = playerRow.rank === 0;
  const winnings = playerWon ? raceState.betAmount * raceState.config.multiplier : 0;
  
  if (playerWon && winnings > 0) {
    try {
      if (window.kvrcards && typeof window.kvrcards.gamblingPayout === 'function') {
        await window.kvrcards.gamblingPayout(winnings);
      } else if (window.kvrcards && typeof window.kvrcards.addCoins === 'function') {
        await window.kvrcards.addCoins(winnings);
      }
      
      // Sincronizar victoria y ganancias con el servidor
      const username = (typeof currentUser === 'string' && currentUser.trim()) ? currentUser : (localStorage.getItem('kvrUsername') || 'Invitado');
      const baseUrl = await getGamblingBaseUrl();
      const response = await fetch(`${baseUrl}/api/gambling/card-race/win/${username}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ difficulty: raceState.difficulty, winnings: winnings })
      });
      const resJson = await response.json();
      
      // Refrescar el leaderboard en tiempo real sin recargar la página
      if (resJson.ok && typeof window.refreshGamblingLeaderboardData === 'function') {
        await window.refreshGamblingLeaderboardData();
      }
    } catch (err) {
      console.error('[CARD-RACE] Error al procesar victoria y sincronizar ranking:', err);
    }
  }
  
  if (window.kvrcards && typeof window.kvrcards.inventoryReloadFromServer === 'function') {
    try { await window.kvrcards.inventoryReloadFromServer(); } catch {}
  }
  if (typeof renderWallet === 'function') await renderWallet();
  
  showRaceScreen('result');
  renderResultScreen(playerWon, winnings);
}

// =======================================================
// RENDERIZAR PANTALLA DE RESULTADO (CON PODIO)
// =======================================================

function renderResultScreen(playerWon, winnings) {
  const titleEl = document.getElementById('race-result-title');
  const rowsEl = document.getElementById('race-result-rows');
  const rewardEl = document.getElementById('race-result-reward');
  const rewardAmtEl = document.getElementById('race-result-reward-amount');
  
  if (!raceState) return;
  
  if (playerWon) {
    titleEl.textContent = '¡HAS GANADO!';
    titleEl.className = 'race-result-title win';
    if (typeof playSFX === 'function') playSFX('cardSelect');
  } else {
    titleEl.textContent = 'HAS PERDIDO';
    titleEl.className = 'race-result-title lose';
    if (typeof playSFX === 'function') playSFX('packSplitWhoosh');
  }
  
  rowsEl.innerHTML = '';
  
  const podiumWrapper = document.createElement('div');
  podiumWrapper.className = 'race-podium-wrapper';
  
  raceState.podium.forEach((item, idx) => {
    const podiumItem = document.createElement('div');
    let rankClass = 'rank-other';
    let medal = `${idx + 1}º`;
    
    if (idx === 0) { rankClass = 'rank-gold'; medal = '🥇'; }
    else if (idx === 1) { rankClass = 'rank-silver'; medal = '🥈'; }
    else if (idx === 2) { rankClass = 'rank-bronze'; medal = '🥉'; }
    
    podiumItem.className = `race-podium-item ${rankClass} ${item.isPlayer ? 'is-player-row' : ''}`;
    
    podiumItem.innerHTML = `
      <div class="podium-rank-badge">${medal}</div>
      <img src="${getCardImage(item.card)}" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=&quot;http://www.w3.org/2000/svg&quot; width=&quot;40&quot; height=&quot;56&quot;><rect width=&quot;100%&quot; height=&quot;100%&quot; fill=&quot;%23333&quot; rx=&quot;4&quot;/><text x=&quot;50%&quot; y=&quot;50%&quot; dominant-baseline=&quot;middle&quot; text-anchor=&quot;middle&quot; fill=&quot;%23999&quot; font-size=&quot;10&quot;>?</text></svg>'" class="podium-card-thumb">
      <div class="podium-card-info">
        <span class="podium-card-name">${getCardName(item.card)}</span>
        <span class="podium-card-owner-badge ${item.isPlayer ? 'player-badge' : 'ai-badge'}">${item.isPlayer ? 'TÚ' : 'IA'}</span>
      </div>
      <div class="podium-card-time">${item.finalTime.toFixed(3)} s</div>
    `;
    
    podiumWrapper.appendChild(podiumItem);
  });
  
  rowsEl.appendChild(podiumWrapper);
  
  if (playerWon) {
    rewardEl.style.display = 'block';
    rewardEl.className = 'race-result-reward win';
    rewardAmtEl.textContent = `+${winnings.toLocaleString()} Coins (x${raceState.config.multiplier})`;
  } else {
    rewardEl.style.display = 'block';
    rewardEl.className = 'race-result-reward lose';
    rewardAmtEl.textContent = `-${raceState.betAmount.toLocaleString()} Coins`;
  }
}

// =======================================================
// REINICIAR / VOLVER
// =======================================================

window.racePlayAgain = function() {
  raceState = null;
  window._selectedRaceDifficulty = null;
  
  // Limpiar de forma imperativa todos los corredores, podio, tiempos e interfaz de carrera
  const tracksContainer = document.getElementById('race-tracks-container');
  if (tracksContainer) tracksContainer.innerHTML = '';
  const rowsContainer = document.getElementById('race-rows-container');
  if (rowsContainer) rowsContainer.innerHTML = '';
  const resultRows = document.getElementById('race-result-rows');
  if (resultRows) resultRows.innerHTML = '';
  
  showRaceScreen('config');
  
  getRaceWalletCoins().then(coins => {
    const el = document.getElementById('race-balance-coins-val');
    if (el) el.textContent = coins.toLocaleString();
  });
  
  document.getElementById('race-bet-amount').value = '';
  document.getElementById('race-bet-error').style.display = 'none';
  document.getElementById('race-start-btn').disabled = true;
  document.querySelectorAll('.race-difficulty-btn').forEach(btn => btn.classList.remove('active'));
};

window.raceBackToMenu = function() {
  closeCardRaceModal();
};
