// ==================== SISTEMA ONLINE PVP ====================

// Estado global del sistema online (debe estar ANTES de cualquier uso)
console.log('🟢 CHECKPOINT 2: Definiendo window.onlineState...');
window.onlineState = {
  socket: null,
  connected: false,
  inQueue: false,
  inBattle: false,
  matchId: null,
  opponentId: null,
  opponentData: null,
  isHost: false,
  teamReadySent: false
};

console.log('🟢 CHECKPOINT 3: window.onlineState creado:', window.onlineState);

// Inicializar sistema online (DEFINIR ANTES DE USAR)
function initOnlineSystem() {
  console.log('[ONLINE] ⚡ Configurando listeners...');
  
  // Botón de matchmaking aleatorio
  const matchmakingBtn = document.getElementById('matchmaking-random-btn');
  console.log('[ONLINE] Botón matchmaking encontrado:', matchmakingBtn);
  if (matchmakingBtn) {
    matchmakingBtn.addEventListener('click', async () => {
      console.log('[ONLINE] ¡Click en matchmaking detectado!');
      await startMatchmaking();
    });
  }
  
  // Botón de jugar con amigo
  const playWithFriendBtn = document.getElementById('play-with-friend-btn');
  console.log('[ONLINE] Botón friend battle encontrado:', playWithFriendBtn);
  if (playWithFriendBtn) {
    playWithFriendBtn.addEventListener('click', async () => {
      console.log('[ONLINE] ¡Click en friend battle detectado!');
      await openFriendBattleScreen();
    });
  }
  
  // Botón cancelar matchmaking
  const cancelMatchmakingBtn = document.getElementById('cancel-matchmaking-btn');
  if (cancelMatchmakingBtn) {
    cancelMatchmakingBtn.addEventListener('click', cancelMatchmaking);
  }
  
  // Botón volver de friend battle
  const backFromFriendBattleBtn = document.getElementById('back-from-friend-battle-btn');
  if (backFromFriendBattleBtn) {
    backFromFriendBattleBtn.addEventListener('click', closeFriendBattleScreen);
  }
  
  // Tabs de friend battle
  const friendBattleTabs = document.querySelectorAll('.friend-battle-tab');
  friendBattleTabs.forEach(tab => {
    tab.addEventListener('click', function() {
      const tabName = this.dataset.tab;
      switchFriendBattleTab(tabName);
    });
  });
  
  console.log('[ONLINE] ✅ Sistema online inicializado');
}

// Inicializar sistema de traits al cargar
console.log('[APP] Registrando DOMContentLoaded...');
document.addEventListener('DOMContentLoaded', () => {
  console.log('[APP] ✅ DOMContentLoaded disparado!');
  console.log('[APP] Inicializando sistema de traits...');
  try {
    const initTraits = (typeof initTraitsSystem === 'function')
      ? initTraitsSystem
      : (typeof window !== 'undefined' && typeof window.initTraitsSystem === 'function' ? window.initTraitsSystem : null);
    if (typeof initTraits === 'function') {
      initTraits();
    }
  } catch (e) {
    console.error('[APP] Error en initTraitsSystem:', e);
  }
  
  // Inicializar sistema online
  console.log('[ONLINE] Inicializando sistema online...');
  try {
    initOnlineSystem();
  } catch (e) {
    console.error('[ONLINE] Error en initOnlineSystem:', e);
  }
});

// También inicializar inmediatamente si el DOM ya está listo
if (document.readyState === 'loading') {
  console.log('[APP] DOM todavía cargando, esperando DOMContentLoaded...');
} else {
  console.log('[APP] DOM ya listo, inicializando inmediatamente...');
  try {
    const initTraits = (typeof initTraitsSystem === 'function')
      ? initTraitsSystem
      : (typeof window !== 'undefined' && typeof window.initTraitsSystem === 'function' ? window.initTraitsSystem : null);
    if (typeof initTraits === 'function') {
      initTraits();
    }
  } catch (e) {
    console.error('[APP] Error en initTraitsSystem:', e);
  }
  try {
    initOnlineSystem();
  } catch (e) {
    console.error('[ONLINE] Error en initOnlineSystem:', e);
  }
}


// Conectar al servidor WebSocket
function connectToServer() {
  return new Promise(async (resolve, reject) => {
    if (window.onlineState.connected && window.onlineState.socket && window.onlineState.socket.connected) {
      console.log('[ONLINE] Ya conectado al servidor');
      resolve();
      return;
    }
    
    console.log('[ONLINE] Conectando al servidor WebSocket...');
    
    // Determinar la URL del servidor dinámicamente
    var serverUrl = 'https://kvrcards-server.onrender.com';
    
    if (window.kvrcards && typeof window.kvrcards.getInventoryServerInfo === 'function') {
      try {
        var serverInfo = await window.kvrcards.getInventoryServerInfo();
        if (serverInfo && serverInfo.effectiveBaseUrl) {
          serverUrl = serverInfo.effectiveBaseUrl;
          console.log('[ONLINE] Usando URL de servidor desde Electron:', serverUrl);
        } else if (serverInfo && serverInfo.baseUrl) {
          serverUrl = serverInfo.baseUrl;
          console.log('[ONLINE] Usando baseUrl de servidor desde Electron:', serverUrl);
        }
      } catch (e) {
        console.error('[ONLINE] Error al obtener info de servidor desde Electron:', e);
      }
    } else {
      // Si estamos en navegador, comprobar si es local
      if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        serverUrl = window.location.origin || 'http://localhost:3000';
        console.log('[ONLINE] Navegador local detectado, conectando a:', serverUrl);
      }
    }
    
    // Normalizar URL eliminando barra diagonal final
    if (serverUrl.endsWith('/')) {
      serverUrl = serverUrl.slice(0, -1);
    }
    
    try {
      // Nota: Socket.io debe estar cargado en index.html
      if (typeof io === 'undefined') {
        console.error('[ONLINE] Socket.io no está cargado');
        reject(new Error('Socket.io no disponible'));
        return;
      }
      
      window.onlineState.socket = io(serverUrl, {
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionAttempts: 5
      });
      
      window.onlineState.socket.on('connect', async () => {
        console.log('[ONLINE] ✅ Conectado al servidor');
        window.onlineState.connected = true;
        
        // Obtener datos del perfil del usuario
        let username = localStorage.getItem('username') || 'Jugador';
        let profileImageUrl = null;
        
        try {
          if (isElectron) {
            const userResult = await window.kvrcards.getUserProfile();
            if (userResult?.ok && userResult?.profile) {
              username = userResult.profile.username || username;
              const img = userResult.profile.profileImage;
              if (img && typeof img === 'string') {
                profileImageUrl = img;
              }
            } else if (userResult?.username) {
              username = userResult.username;
              const img = userResult.profileImage;
              if (img && typeof img === 'string') {
                profileImageUrl = img;
              }
            }
          }
        } catch (error) {
          console.error('[ONLINE] Error obteniendo perfil:', error);
        }

        // Evitar enviar valores inválidos que rompen el avatar remoto.
        if (profileImageUrl && typeof profileImageUrl === 'string') {
          const trimmed = profileImageUrl.trim();
          const isHttp = /^https?:\/\//i.test(trimmed);
          const isDataImage = /^data:image\//i.test(trimmed);
          const isDefaultToken = trimmed === 'default-avatar.png' || trimmed === 'default-avatar';
          if ((!isHttp && !isDataImage) || isDefaultToken) {
            profileImageUrl = null;
          } else {
            profileImageUrl = trimmed;
          }
        }
        
        // Si no hay URL válida, usar Dicebear
        if (!profileImageUrl) {
          profileImageUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`;
        }
        
        // Enviar datos del jugador (acepta URL remota o data URL).
        const playerData = {
          username: username,
          userId: localStorage.getItem('userId') || generateUserId(),
          profileImage: profileImageUrl
        };
        
        console.log('[ONLINE] Registrando jugador con datos:', playerData);
        window.onlineState.socket.emit('register-player', playerData);
        resolve();
      });
      
      window.onlineState.socket.on('disconnect', () => {
        console.log('[ONLINE] ❌ Desconectado del servidor');
        window.onlineState.connected = false;
      });
      
      window.onlineState.socket.on('connect_error', (error) => {
        console.error('[ONLINE] Error de conexión:', error);
        reject(error);
      });
      
      // Eventos de matchmaking
      window.onlineState.socket.on('queue-update', (data) => {
        console.log('[ONLINE] Actualización de cola:', data.playersInQueue);
        updateQueueCount(data.playersInQueue);
      });
      
      window.onlineState.socket.on('match-found', (data) => {
        console.log('[ONLINE] ¡Match encontrado!', data);
        handleMatchFound(data);
      });
      
      // Eventos de batalla con amigos
      window.onlineState.socket.on('battle-request-received', (data) => {
        console.log('[ONLINE] Solicitud de batalla recibida:', data);
        handleBattleRequestReceived(data);
      });
      
      window.onlineState.socket.on('battle-request-accepted', (data) => {
        console.log('[ONLINE] Solicitud aceptada:', data);
        handleBattleRequestAccepted(data);
      });
      
      window.onlineState.socket.on('battle-request-rejected', (data) => {
        console.log('[ONLINE] Solicitud rechazada:', data);
        handleBattleRequestRejected(data);
      });

      window.onlineState.socket.on('battle-requests-list', (data) => {
        handleBattleRequestsList(data);
      });

      window.onlineState.socket.on('friends-status', (data) => {
        handleFriendsStatusUpdate(data);
      });

      window.onlineState.socket.on('match-created', (data) => {
        console.log('[ONLINE] Match creado para aceptador:', data);
        handleFriendMatchCreated(data);
      });
      
      // Eventos de batalla online centralizados en módulo dedicado.
      if (typeof window.registerOnlineBattleSocketHandlers === 'function') {
        window.registerOnlineBattleSocketHandlers(window.onlineState.socket);
      } else {
        console.warn('[ONLINE] registerOnlineBattleSocketHandlers no disponible, usando handlers inline legacy');
      }

      // Vincular listeners de la Fase de Elección (Draft)
      if (typeof window.initDraftSocketListeners === 'function') {
        console.log('[ONLINE] 🗳️ Vinculando listeners del Draft al nuevo socket...');
        window.initDraftSocketListeners();
      } else {
        console.warn('[ONLINE] window.initDraftSocketListeners no disponible al registrar socket');
      }
      
      // Listener para detectar cierre de ventana o recarga
      window.addEventListener('beforeunload', (e) => {
        if (window.onlineState && window.onlineState.socket && window.onlineState.matchId) {
          console.log('[ONLINE] Ventana cerrándose, notificando abandono...');
          window.onlineState.socket.emit('leave-match', { matchId: window.onlineState.matchId });
        }
      });
      
    } catch (error) {
      console.error('[ONLINE] Error al conectar:', error);
      reject(error);
    }
  });
}

// Generar ID único de usuario
function generateUserId() {
  const userId = 'user_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
  localStorage.setItem('userId', userId);
  return userId;
}

// ==================== MATCHMAKING ALEATORIO ====================

async function startMatchmaking() {
  console.log('[MATCHMAKING] Iniciando matchmaking...');
  
  try {
    // Conectar al servidor si no está conectado
    if (!window.onlineState.connected) {
      await connectToServer();
    }
    
    // Mostrar pantalla de matchmaking
    document.getElementById('online-friendly-selection').style.display = 'none';
    document.getElementById('matchmaking-screen').style.display = 'block';
    
    // Unirse a la cola con el modo de juego seleccionado
    window.onlineState.socket.emit('join-queue', { gameMode: window.selectedGameMode || 'clasico7v7' });
    window.onlineState.inQueue = true;
    
    console.log('[MATCHMAKING] En cola de matchmaking');
    
  } catch (error) {
    console.error('[MATCHMAKING] Error:', error);
    alert('❌ No se pudo conectar al servidor. Intenta más tarde.');
  }
}

function cancelMatchmaking() {
  console.log('[MATCHMAKING] Cancelando matchmaking...');
  
  if (window.onlineState.socket && window.onlineState.inQueue) {
    window.onlineState.socket.emit('leave-queue');
    window.onlineState.inQueue = false;
  }
  
  // Volver a selección de modo online
  document.getElementById('matchmaking-screen').style.display = 'none';
  document.getElementById('online-friendly-selection').style.display = 'block';
}

function updateQueueCount(count) {
  const queueCountEl = document.getElementById('queue-count');
  if (queueCountEl) {
    queueCountEl.textContent = count;
  }
}

function handleMatchFound(data) {
  console.log('[MATCHMAKING] Match encontrado, iniciando batalla...');
  console.log('[MATCHMAKING] Datos del oponente:', data.opponent);
  
  window.onlineState.inQueue = false;
  window.onlineState.inBattle = true;
  window.onlineState.matchId = data.matchId;
  window.onlineState.opponentId = data.opponentId;
  window.onlineState.opponentData = {
    username: data.opponent?.username || 'Rival',
    profileImage: data.opponent?.profileImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=${data.opponent?.username || 'rival'}`,
    gameMode: data.gameMode || 'clasico7v7'
  };
  window.onlineState.isHost = data.isHost;
  window.onlineState.teamReadySent = false;
  
  // Ocultar pantalla de matchmaking
  document.getElementById('matchmaking-screen').style.display = 'none';
  
  // Ir al team builder para online
  startOnlineBattle();
}

// ==================== BATALLAS CON AMIGOS ====================

async function openFriendBattleScreen() {
  console.log('[FRIEND-BATTLE] Abriendo pantalla de batallas con amigos...');
  
  try {
    // Conectar al servidor si no está conectado
    if (!window.onlineState.connected) {
      await connectToServer();
    }
    
    // Mostrar pantalla de friend battle
    document.getElementById('online-friendly-selection').style.display = 'none';
    document.getElementById('friend-battle-screen').style.display = 'block';
    
    // Cargar lista de amigos
    loadFriendsListForBattle();
    
    // Cargar solicitudes pendientes
    loadBattleRequests();
    
  } catch (error) {
    console.error('[FRIEND-BATTLE] Error:', error);
    alert('❌ No se pudo conectar al servidor. Intenta más tarde.');
  }
}

function closeFriendBattleScreen() {
  console.log('[FRIEND-BATTLE] Cerrando pantalla de batallas con amigos...');
  
  document.getElementById('friend-battle-screen').style.display = 'none';
  document.getElementById('online-friendly-selection').style.display = 'block';
}

function switchFriendBattleTab(tabName) {
  console.log('[FRIEND-BATTLE] Cambiando a tab:', tabName);
  
  // Actualizar tabs activas
  document.querySelectorAll('.friend-battle-tab').forEach(tab => {
    tab.classList.remove('active');
  });
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
  
  // Mostrar contenido correcto
  document.querySelectorAll('.friend-battle-tab-content').forEach(content => {
    content.style.display = 'none';
  });
  
  if (tabName === 'friends-list') {
    document.getElementById('friends-list-tab').style.display = 'block';
  } else if (tabName === 'battle-requests') {
    document.getElementById('battle-requests-tab').style.display = 'block';
    loadBattleRequests();
  }
}

const FRIEND_BATTLE_MODES = ['7v7 Clásico', '7v7 Alternativo', 'Elección Clásico', 'Elección Alternativo'];
const FRIEND_BATTLE_DEFAULT_MODE = FRIEND_BATTLE_MODES[0];

function getSelectedFriendBattleMode(friendId) {
  const selectedByFriend = window.onlineState?.friendBattleModesByFriend || {};
  return selectedByFriend[friendId] || null;
}

function setupFriendBattleModeMenuAutoClose() {
  if (window._friendBattleModeMenuListenerAttached) {
    return;
  }

  document.addEventListener('click', (event) => {
    if (event.target.closest('.battle-mode-selector')) {
      return;
    }
    document.querySelectorAll('.battle-mode-menu.open').forEach(menu => menu.classList.remove('open'));
  });

  window._friendBattleModeMenuListenerAttached = true;
}

function toggleFriendBattleModeMenu(friendId) {
  const friendKey = encodeURIComponent(friendId);
  const menu = document.getElementById(`battle-mode-menu-${friendKey}`);
  if (!menu) return;

  document.querySelectorAll('.battle-mode-menu.open').forEach(openMenu => {
    if (openMenu !== menu) {
      openMenu.classList.remove('open');
    }
  });

  menu.classList.toggle('open');
}

function selectFriendBattleMode(friendId, modeName) {
  if (!window.onlineState.friendBattleModesByFriend) {
    window.onlineState.friendBattleModesByFriend = {};
  }

  window.onlineState.friendBattleModesByFriend[friendId] = modeName;
  window.onlineState.selectedFriendBattleMode = modeName;

  const labelEl = document.querySelector(`[data-mode-label-for="${friendId}"]`);
  if (labelEl) {
    labelEl.textContent = modeName;
  }

  const friendKey = encodeURIComponent(friendId);
  const menu = document.getElementById(`battle-mode-menu-${friendKey}`);
  if (menu) {
    menu.classList.remove('open');
  }
}

function handleFriendsStatusUpdate(friendsStatusMap) {
  if (!friendsStatusMap || typeof friendsStatusMap !== 'object') return;

  Object.entries(friendsStatusMap).forEach(([friendId, status]) => {
    const statusEl = document.querySelector(`.friend-battle-status[data-status="${friendId}"]`);
    if (!statusEl) return;

    const isOnline = status === 'online';
    statusEl.classList.toggle('status-online', isOnline);
    statusEl.classList.toggle('status-offline', !isOnline);
    statusEl.textContent = isOnline ? '🟢 Online' : '⚫ Offline';
  });
}

function loadFriendsListForBattle() {
  console.log('[FRIEND-BATTLE] Cargando lista de amigos para batalla...');
  
  const friendsListEl = document.getElementById('friends-battle-list');
  if (!friendsListEl) {
    console.error('[FRIEND-BATTLE] Elemento friends-battle-list no encontrado');
    return;
  }
  
  const userId = localStorage.getItem('userId');
  
  if (!userId) {
    friendsListEl.innerHTML = '<p class="no-friends-message" style="color: #9ca3af; padding: 20px;">Inicia sesión para ver tus amigos</p>';
    return;
  }
  
  friendsListEl.innerHTML = '<p class="no-friends-message" style="color: #9ca3af; padding: 20px;">Cargando amigos...</p>';
  
  // Cargar amigos desde el servidor remoto
  fetch(`https://kvrcards-server.onrender.com/api/friends/list/${userId}`)
    .then(res => {
      // Si es 404, usuario no existe todavía
      if (res.status === 404) {
        return { ok: true, friends: [] };
      }
      return res.json();
    })
    .then(result => {
      if (!result.ok || !result.friends || result.friends.length === 0) {
        friendsListEl.innerHTML = '<p class="no-friends-message" style="color: #9ca3af; padding: 20px; text-align: center;">No tienes amigos agregados aún.<br>Agrega amigos desde el menú de Amigos (👥) para poder jugar con ellos.</p>';
        return;
      }
      
      const friends = result.friends;
      console.log('[FRIEND-BATTLE] Amigos encontrados:', friends.length);
      
      // Renderizar lista de amigos
      friendsListEl.innerHTML = friends.map(friend => {
        const selectedMode = getSelectedFriendBattleMode(friend.username);
        const friendKey = encodeURIComponent(friend.username);
        return `
        <div class="friend-battle-item" data-friend-id="${friend.username}">
          <div class="friend-battle-info">
            <div class="friend-battle-avatar">👤</div>
            <div class="friend-battle-details">
              <h4>${friend.username || 'Usuario'}</h4>
              <p class="friend-title-text" data-title-text="${friend.currentTitle || 'Jugador'}">${friend.currentTitle || 'Jugador'}</p>
              <span class="friend-battle-status status-offline" data-status="${friend.username}">⚫ Offline</span>
            </div>
          </div>
          <div class="friend-battle-actions">
            <div class="battle-mode-selector">
              <button class="battle-mode-btn" onclick="toggleFriendBattleModeMenu('${friend.username}')">
                <span class="battle-mode-label" data-mode-label-for="${friend.username}">${selectedMode || 'Seleccionar modo de juego'}</span>
                <span class="battle-mode-arrow">▾</span>
              </button>
              <div class="battle-mode-menu" id="battle-mode-menu-${friendKey}">
                ${FRIEND_BATTLE_MODES.map(mode => `<button class="battle-mode-option" onclick="selectFriendBattleMode('${friend.username}', '${mode}')">${mode}</button>`).join('')}
              </div>
            </div>
            <button class="battle-request-btn" onclick="sendBattleRequest('${friend.username}', '${friend.username}', '${friend.username}')">
              ⚔️ Solicitar Batalla
            </button>
          </div>
        </div>
      `;
      }).join('');

      setupFriendBattleModeMenuAutoClose();

      if (typeof window.applyTitleStyle === 'function') {
        friendsListEl.querySelectorAll('.friend-title-text').forEach(el => {
          const tText = el.getAttribute('data-title-text');
          if (tText) window.applyTitleStyle(el, tText);
        });
      }

      // Solicitar estado online de amigos al servidor cuando el DOM ya está renderizado
      if (window.onlineState.socket) {
        window.onlineState.socket.emit('get-friends-status', { friendIds: friends.map(f => f.username) });
      }
    })
    .catch(err => {
      console.error('[FRIEND-BATTLE] Error cargando amigos:', err);
      friendsListEl.innerHTML = '<p class="no-friends-message" style="color: #9ca3af; padding: 20px;">Error al cargar amigos</p>';
    });
}

function loadBattleRequests() {
  console.log('[FRIEND-BATTLE] Cargando solicitudes de batalla...');
  
  // Solicitar al servidor las solicitudes pendientes
  if (window.onlineState.socket) {
    window.onlineState.socket.emit('get-battle-requests');
  }
}

function sendBattleRequest(friendId, friendUsername, modeFriendId = friendId) {
  console.log('[FRIEND-BATTLE] Enviando solicitud a:', friendUsername);
  
  if (!window.onlineState.connected) {
    alert('❌ No estás conectado al servidor');
    return;
  }
  
  const playerData = {
    username: localStorage.getItem('username') || 'Jugador',
    userId: localStorage.getItem('userId')
  };

  const selectedModeName = getSelectedFriendBattleMode(modeFriendId) || FRIEND_BATTLE_DEFAULT_MODE;
  let gameMode = 'clasico7v7';
  if (selectedModeName === '7v7 Alternativo') {
    gameMode = 'alternativo7v7';
  } else if (selectedModeName === 'Elección Clásico') {
    gameMode = 'eleccion_clasico';
  } else if (selectedModeName === 'Elección Alternativo') {
    gameMode = 'eleccion_alternativo';
  }
  
  window.onlineState.socket.emit('send-battle-request', {
    fromId: playerData.userId,
    fromUsername: playerData.username,
    toId: friendId,
    toUsername: friendUsername,
    modeName: selectedModeName,
    gameMode: gameMode
  });
  
  alert(`✅ Solicitud enviada a ${friendUsername} en modo ${selectedModeName}`);
}

function handleBattleRequestReceived(data) {
  console.log('[FRIEND-BATTLE] Nueva solicitud recibida:', data);

  const modeName = data.modeName || FRIEND_BATTLE_DEFAULT_MODE;
  
  // Agregar a la lista de solicitudes
  const requestsListEl = document.getElementById('battle-requests-list');
  if (!requestsListEl) return;

  // Evitar duplicados si llega de evento en vivo y de recarga de lista
  const existingRequest = requestsListEl.querySelector(`[data-request-id="${data.requestId}"]`);
  if (existingRequest) {
    updateRequestsCount();
    return;
  }
  
  // Eliminar mensaje de "no hay solicitudes"
  const noRequestsMsg = requestsListEl.querySelector('.no-requests-message');
  if (noRequestsMsg) noRequestsMsg.remove();
  
  // Agregar nueva solicitud
  const requestHTML = `
    <div class="friend-battle-item" data-request-id="${data.requestId}">
      <div class="friend-battle-info">
        <div class="friend-battle-avatar">⚔️</div>
        <div class="friend-battle-details">
          <h4>${data.fromUsername}</h4>
          <p>Te ha retado a una batalla en el modo de juego: ${modeName}</p>
        </div>
      </div>
      <div class="friend-battle-actions">
        <button class="accept-battle-btn" onclick="acceptBattleRequest('${data.requestId}', '${data.fromId}', '${data.fromUsername}', '${modeName}')">
          ✅ Aceptar
        </button>
        <button class="reject-battle-btn" onclick="rejectBattleRequest('${data.requestId}')">
          ❌ Rechazar
        </button>
      </div>
    </div>
  `;
  
  requestsListEl.insertAdjacentHTML('afterbegin', requestHTML);
  updateRequestsCount();
  
  // Notificación
  if (Notification.permission === 'granted') {
    new Notification('Nueva Solicitud de Batalla', {
      body: `${data.fromUsername} te ha retado en modo ${modeName}`,
      icon: './assets/menu/battle.png'
    });
  }
}

function handleBattleRequestsList(data) {
  const requestsListEl = document.getElementById('battle-requests-list');
  if (!requestsListEl) return;

  const requests = Array.isArray(data?.requests) ? data.requests : [];

  if (requests.length === 0) {
    requestsListEl.innerHTML = '<p class="no-requests-message">No tienes solicitudes pendientes</p>';
    updateRequestsCount();
    return;
  }

  requestsListEl.innerHTML = requests.map(req => {
    const modeName = req.modeName || FRIEND_BATTLE_DEFAULT_MODE;
    return `
      <div class="friend-battle-item" data-request-id="${req.requestId}">
        <div class="friend-battle-info">
          <div class="friend-battle-avatar">⚔️</div>
          <div class="friend-battle-details">
            <h4>${req.fromUsername}</h4>
            <p>Te ha retado a una batalla en el modo de juego: ${modeName}</p>
          </div>
        </div>
        <div class="friend-battle-actions">
          <button class="accept-battle-btn" onclick="acceptBattleRequest('${req.requestId}', '${req.fromId}', '${req.fromUsername}', '${modeName}')">
            ✅ Aceptar
          </button>
          <button class="reject-battle-btn" onclick="rejectBattleRequest('${req.requestId}')">
            ❌ Rechazar
          </button>
        </div>
      </div>
    `;
  }).join('');

  updateRequestsCount();
}

function acceptBattleRequest(requestId, opponentId, opponentUsername, modeName = FRIEND_BATTLE_DEFAULT_MODE) {
  console.log('[FRIEND-BATTLE] Aceptando solicitud:', requestId);
  
  if (!window.onlineState.socket) return;
  
  window.onlineState.socket.emit('accept-battle-request', { requestId });
  
  // Configurar datos de batalla
  let gameMode = 'clasico7v7';
  if (modeName === '7v7 Alternativo') {
    gameMode = 'alternativo7v7';
  } else if (modeName === 'Elección Clásico') {
    gameMode = 'eleccion_clasico';
  } else if (modeName === 'Elección Alternativo') {
    gameMode = 'eleccion_alternativo';
  }
  window.onlineState.inBattle = true;
  window.onlineState.opponentId = opponentId;
  window.onlineState.opponentData = { username: opponentUsername, modeName, gameMode };
  window.onlineState.isHost = false; // El que acepta no es host
  
  // Eliminar solicitud de la lista
  const requestEl = document.querySelector(`[data-request-id="${requestId}"]`);
  if (requestEl) requestEl.remove();
  
  updateRequestsCount();

  // Esperar evento match-created del servidor para recibir matchId antes de iniciar.
  console.log('[FRIEND-BATTLE] Esperando match-created para iniciar batalla...');
}

function handleFriendMatchCreated(data) {
  if (!data || !data.matchId) {
    console.warn('[FRIEND-BATTLE] match-created sin matchId:', data);
    return;
  }

  if (!window.onlineState?.inBattle) {
    console.log('[FRIEND-BATTLE] match-created ignorado porque no estamos en batalla.');
    return;
  }

  console.log('[FRIEND-BATTLE] Match creado, iniciando batalla:', data.matchId);
  window.onlineState.matchId = data.matchId;
  window.onlineState.opponentData = {
    username: data.opponentUsername || window.onlineState.opponentData?.username || 'Rival',
    profileImage: data.opponentProfileImage || window.onlineState.opponentData?.profileImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=${data.opponentUsername || 'rival'}`,
    gameMode: data.gameMode || window.onlineState.opponentData?.gameMode || 'clasico7v7'
  };

  startOnlineBattle();
}

function rejectBattleRequest(requestId) {
  console.log('[FRIEND-BATTLE] Rechazando solicitud:', requestId);
  
  if (!window.onlineState.socket) return;
  
  window.onlineState.socket.emit('reject-battle-request', { requestId });
  
  // Eliminar solicitud de la lista
  const requestEl = document.querySelector(`[data-request-id="${requestId}"]`);
  if (requestEl) requestEl.remove();
  
  updateRequestsCount();
}

function handleBattleRequestAccepted(data) {
  console.log('[FRIEND-BATTLE] Solicitud aceptada:', data);
  
  // Configurar datos de batalla
  window.onlineState.inBattle = true;
  window.onlineState.matchId = data.matchId;
  window.onlineState.opponentId = data.opponentId;
  window.onlineState.opponentData = {
    username: data.opponentUsername,
    profileImage: data.opponentProfileImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=${data.opponentUsername || 'rival'}`,
    gameMode: data.gameMode || 'clasico7v7'
  };
  window.onlineState.isHost = true; // El que envió la solicitud es host
  window.onlineState.teamReadySent = false;
  
  alert(`✅ ${data.opponentUsername} aceptó tu solicitud`);
  
  // Cerrar pantalla de friend battle
  document.getElementById('friend-battle-screen').style.display = 'none';
  
  // Iniciar batalla
  startOnlineBattle();
}

function handleBattleRequestRejected(data) {
  alert(`❌ ${data.opponentUsername} rechazó tu solicitud`);
}

function updateRequestsCount() {
  const requestsListEl = document.getElementById('battle-requests-list');
  if (!requestsListEl) return;
  
  const count = requestsListEl.querySelectorAll('.friend-battle-item').length;
  
  const countEl = document.getElementById('requests-count');
  if (countEl) {
    countEl.textContent = count;
    countEl.classList.toggle('has-pending', count > 0);
  }

  const requestsTabEl = document.querySelector('.friend-battle-tab[data-tab="battle-requests"]');
  const isActiveTab = requestsTabEl?.classList.contains('active');
  if (requestsTabEl) {
    requestsTabEl.classList.toggle('pending-request', count > 0 && !isActiveTab);
  }

  if (typeof updateGlobalNotificationBadges === 'function') {
    updateGlobalNotificationBadges();
  }
}

