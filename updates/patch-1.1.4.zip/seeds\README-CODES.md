# Sistema de Códigos Canjeables

## 📍 Ubicación del archivo

El archivo `codes.json` debe estar en tu repositorio de GitHub en la **misma ubicación que `catalog.json` y `packs.json`**.

Por ejemplo, si tu estructura es:
```
https://tu-usuario.github.io/tu-repo/
├── catalog.json
├── packs.json
└── codes.json  ← AQUÍ
```

## 🔐 Sistema de una sola vez por usuario

✅ **Ya implementado**: Cada código solo puede ser canjeado **UNA VEZ** por usuario.
- Los códigos canjeados se guardan en el perfil del usuario
- Si intentas canjear un código dos veces, recibirás: "Este código ya ha sido canjeado"
- Cada usuario puede canjear todos los códigos una vez

## 📝 Estructura del archivo codes.json

```json
{
  "version": 1,
  "codes": [
    {
      "code": "CODIGO_AQUI",
      "active": true,
      "rewardsType": "mixed",
      "rewards": {
        "coins": 5000,
        "kvr": 100,
        "packs": [
          {
            "packId": "id-del-sobre-desde-packs.json",
            "quantity": 3
          }
        ],
        "cards": [
          {
            "cardId": "id-de-la-carta-desde-catalog.json",
            "quantity": 1
          }
        ]
      },
      "description": "Descripción visible al usuario"
    }
  ]
}
```

## 🎁 Tipos de recompensas

### Monedas (coins/kvr)
```json
"rewards": {
  "coins": 10000,    // Coins normales
  "kvr": 250,        // KvR Coins premium
  "packs": [],
  "cards": []
}
```

### Sobres (packs)
```json
"rewards": {
  "coins": 0,
  "kvr": 0,
  "packs": [
    {
      "packId": "el-id-del-sobre",  // Debe existir en packs.json
      "quantity": 5                   // Cantidad de sobres
    }
  ],
  "cards": []
}
```

### Cartas (cards)
```json
"rewards": {
  "coins": 0,
  "kvr": 0,
  "packs": [],
  "cards": [
    {
      "cardId": "el-id-de-la-carta",  // Debe existir en catalog.json
      "quantity": 2                    // Cantidad de esa carta
    }
  ]
}
```

### Combinado (mixed)
```json
"rewards": {
  "coins": 5000,
  "kvr": 100,
  "packs": [
    { "packId": "sobre1", "quantity": 3 }
  ],
  "cards": [
    { "cardId": "carta1", "quantity": 1 }
  ]
}
```

## 🚀 Cómo obtener los IDs

### Para IDs de sobres (packId):
1. Abre tu archivo `packs.json` en GitHub
2. Busca el sobre que quieres dar
3. Copia su `"id"` exacto

Ejemplo:
```json
{
  "id": "pack-premium-oro",  ← Usa este ID
  "name": "Pack Premium Oro",
  ...
}
```

### Para IDs de cartas (cardId):
1. Abre tu juego
2. Ve a "Mi colección"
3. Haz clic en una carta
4. En la consola del desarrollador (F12), los IDs aparecen en el catálogo
5. O revisa tu `catalog.json` en GitHub y copia el `"id"`

## ⚙️ Activar/Desactivar códigos

Para **desactivar** un código sin borrarlo:
```json
{
  "code": "EXPIRED_CODE",
  "active": false,  ← Cambia a false
  ...
}
```

## 📋 Códigos de ejemplo incluidos

| Código | Descripción | Recompensas |
|--------|-------------|-------------|
| `MEGAPACK2025` | Mega pack completo | 5000 coins, 100 KvR, 3 sobres, 1 carta |
| `WELCOME2025` | Bienvenida | 1000 coins, 50 KvR |
| `GOLDPACK100` | Sobres oro | 5 sobres |
| `RICHPLAYER` | Boost monedas | 10000 coins, 250 KvR |
| `LEGEND99` | Cartas legendarias | Cartas especiales |

## 🔄 Actualizar códigos

1. Edita `codes.json` en GitHub
2. Haz commit de los cambios
3. Los jugadores recibirán los nuevos códigos **automáticamente**
4. No necesitan actualizar el juego

## ⚠️ Importante

- Los códigos se convierten automáticamente a MAYÚSCULAS
- Cada usuario puede usar cada código solo UNA VEZ
- Si borras un código del JSON, dejará de funcionar para nuevos usuarios
- Los códigos ya canjeados se mantienen en el historial del usuario
