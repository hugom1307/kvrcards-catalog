/**
 * infinite-modifiers.js - Sistema de Modificadores de Batalla para el Modo Infinito
 * 
 * Modificadores Normales:
 * - Diversidad: Buffea 5% todas las stats si solo tienes 1 carta de ese Owner; nerfea 5% a las de Owner repetido.
 * - Poderoso: Nerfea 10% todas las stats hasta usar al menos 2 poderes en batalla.
 * - Estándar: Batalla normal sin modificadores extra.
 * - Básicos: Buffea 5% todas las stats a cartas que no sean cartas especiales.
 * - Procedencial: Buffea 5% todas las stats si solo tienes 1 carta de esa Procedencia; nerfea 5% a las de Procedencia repetida.
 * 
 * Modificadores Especiales (Pisos Boss 100%, Mini-Boss 50%):
 * - Brutal: Todas las cartas del Boss tienen +5% a todas las stats (+10% en piso >= 51).
 * - Contrato: Buffea 10% (20%) dos stats aleatorias y nerfea 20% (40%) otras dos stats aleatorias.
 * - Muerte: Nerfea 10% (20%) todas las stats hasta perder 2 rondas.
 * - Deseo: Tras cada ronda, Boss gana +2% (+4%) si ganas la ronda o +1% (+2%) si pierdes la ronda.
 * - Reservado: El boss siempre actuará después de ti, sin importar si gana o pierde la ronda.
 */

(function(window) {
  'use strict';

  const STAT_NAMES = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
  const STAT_DISPLAY_NAMES = {
    ninjutsu: 'Ninjutsu',
    taijutsu: 'Taijutsu',
    resistencia: 'Resistencia',
    velocidad: 'Velocidad',
    defensa: 'Defensa',
    fisico: 'Físico'
  };

  // Definición base de modificadores normales
  const NORMAL_MODIFIERS = [
    {
      id: 'diversidad',
      name: 'Diversidad',
      type: 'normal',
      icon: '',
      target: 'player',
      baseDesc: 'Buffea un 5% todas las stats si solo posees 1 carta del mismo Owner. Nerfea un 5% las cartas de Owner repetido.'
    },
    {
      id: 'poderoso',
      name: 'Poderoso',
      type: 'normal',
      icon: '',
      target: 'player',
      baseDesc: 'Nerfea un 10% todas las stats hasta que uses al menos 2 poderes en la batalla.'
    },
    {
      id: 'estandar',
      name: 'Estándar',
      type: 'normal',
      icon: '',
      target: 'none',
      baseDesc: 'Batalla normal sin modificadores extra.'
    },
    {
      id: 'basicos',
      name: 'Básicos',
      type: 'normal',
      icon: '',
      target: 'player',
      baseDesc: 'Buffea un 5% todas las stats a las cartas que no sean cartas especiales.'
    },
    {
      id: 'procedencial',
      name: 'Procedencial',
      type: 'normal',
      icon: '',
      target: 'player',
      baseDesc: 'Buffea un 5% todas las stats si solo posees 1 carta de la misma Procedencia. Nerfea un 5% las cartas de Procedencia repetida.'
    }
  ];

  // Definición base de modificadores especiales
  const SPECIAL_MODIFIERS = [
    {
      id: 'brutal',
      name: 'Brutal',
      type: 'especial',
      icon: '',
      target: 'boss',
      baseDesc: 'Todas las cartas del Boss tienen un buffo del 5% a todas las stats.',
      descDoubled: 'Todas las cartas del Boss tienen un buffo del 10% a todas las stats (Piso ≥51: x2).'
    },
    {
      id: 'contrato',
      name: 'Contrato',
      type: 'especial',
      icon: '',
      target: 'player',
      baseDesc: 'Buffea un 10% dos stats aleatorias y nerfea un 20% otras dos stats aleatorias.',
      descDoubled: 'Buffea un 20% dos stats aleatorias y nerfea un 40% otras dos stats aleatorias (Piso ≥51: x2).'
    },
    {
      id: 'muerte',
      name: 'Muerte',
      type: 'especial',
      icon: '',
      target: 'player',
      baseDesc: 'Nerfea un 10% todas las stats hasta que pierdas dos rondas.',
      descDoubled: 'Nerfea un 20% todas las stats hasta que pierdas dos rondas (Piso ≥51: x2).'
    },
    {
      id: 'deseo',
      name: 'Deseo',
      type: 'especial',
      icon: '',
      target: 'boss',
      baseDesc: 'Tras cada ronda: Si ganas, el Boss obtiene +2% a todas las stats; si pierdes, el Boss obtiene +1%.',
      descDoubled: 'Tras cada ronda: Si ganas, el Boss obtiene +4% a todas las stats; si pierdes, el Boss obtiene +2% (Piso ≥51: x2).'
    },
    {
      id: 'reservado',
      name: 'Reservado',
      type: 'especial',
      icon: '',
      target: 'both',
      baseDesc: 'El boss siempre actuará después de ti, sin importar si gana o pierde la ronda.',
      descDoubled: 'El boss siempre actuará después de ti, sin importar si gana o pierde la ronda.'
    }
  ];

  /**
   * Determina el rol del piso (boss, mini-boss, normal).
   */
  function getFloorCombatRole(floorNumber) {
    const floor = Math.max(1, parseInt(floorNumber, 10) || 1);
    if (floor % 10 === 0) return 'boss';
    if (floor % 10 === 5) return 'mini-boss';
    return 'normal';
  }

  /**
   * Baraja un array de forma pseudo-aleatoria
   */
  function shuffleArray(array) {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  /**
   * Obtiene o genera y asigna de forma determinista y persistente un modificador para un piso dado.
   * Si ya existe en floorModifiersMap[floorNumber], devuelve exactamente ese mismo sin alterarlo.
   */
  function getOrAssignModifierForFloor(floorNumber, floorModifiersMap) {
    const floor = Math.max(1, parseInt(floorNumber, 10) || 1);
    const map = floorModifiersMap && typeof floorModifiersMap === 'object' ? floorModifiersMap : {};

    // 1. Si ya existe guardado para este piso, recuperarlo intacto (anti-exploit)
    if (map[floor] && typeof map[floor] === 'object' && map[floor].id) {
      return map[floor];
    }

    // 2. Intentar recuperar de localStorage si existe respaldo
    try {
      const stored = localStorage.getItem('INFINITE_FLOOR_MODIFIERS');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && parsed[floor] && parsed[floor].id) {
          map[floor] = parsed[floor];
          return map[floor];
        }
      }
    } catch (e) {
      console.warn('[MODIFIER] Error leyendo localStorage:', e);
    }

    // 3. Determinar tipo de modificador según reglas de piso:
    // - Boss (10, 20, 30...): 100% Especial
    // - Mini-boss (5, 15, 25...): 50% Especial / 50% Normal
    // - Normal: 100% Normal
    const role = getFloorCombatRole(floor);
    let chosenType = 'normal';

    if (role === 'boss') {
      chosenType = 'especial';
    } else if (role === 'mini-boss') {
      chosenType = Math.random() < 0.5 ? 'especial' : 'normal';
    } else {
      chosenType = 'normal';
    }

    const pool = chosenType === 'especial' ? SPECIAL_MODIFIERS : NORMAL_MODIFIERS;
    const baseMod = pool[Math.floor(Math.random() * pool.length)];

    const modifier = {
      id: baseMod.id,
      name: baseMod.name,
      type: baseMod.type,
      icon: baseMod.icon,
      target: baseMod.target,
      floor: floor,
      assignedAt: Date.now()
    };

    // Si es Contrato, seleccionar 2 stats para buff y 2 stats distintas para nerf
    if (modifier.id === 'contrato') {
      const shuffledStats = shuffleArray(STAT_NAMES);
      modifier.buffStats = shuffledStats.slice(0, 2);
      modifier.nerfStats = shuffledStats.slice(2, 4);
    }

    // Guardar en el mapa y en localStorage
    map[floor] = modifier;
    try {
      const stored = localStorage.getItem('INFINITE_FLOOR_MODIFIERS');
      const currentMap = stored ? JSON.parse(stored) : {};
      currentMap[floor] = modifier;
      localStorage.setItem('INFINITE_FLOOR_MODIFIERS', JSON.stringify(currentMap));
    } catch (e) {
      console.warn('[MODIFIER] Error guardando en localStorage:', e);
    }

    console.log(`[MODIFIER] Asignado para piso ${floor} (${role}):`, modifier);
    return modifier;
  }

  /**
   * Obtiene la descripción completa y formateada del modificador para la pantalla o modal
   */
  function getModifierDescription(mod) {
    if (!mod || !mod.id) return 'Batalla normal sin modificadores extra.';

    const isDoubled = (mod.floor >= 51);

    switch (mod.id) {
      case 'diversidad':
        return 'Buffea un 5% todas las stats si solo posees 1 carta del mismo Owner. Nerfea un 5% todas las cartas de Owner repetido.';
      case 'poderoso':
        return 'Nerfea un 10% todas las stats hasta que uses al menos 2 poderes en la batalla.';
      case 'estandar':
        return 'Batalla normal sin modificadores extra.';
      case 'basicos':
        return 'Buffea un 5% todas las stats a las cartas que no sean cartas especiales.';
      case 'procedencial':
        return 'Buffea un 5% todas las stats si solo posees 1 carta de la misma Procedencia. Nerfea un 5% las cartas de Procedencia repetida.';
      case 'brutal':
        return isDoubled
          ? 'Todas las cartas del Boss tienen un buffo del 10% a todas las stats (Piso ≥51: x2).'
          : 'Todas las cartas del Boss tienen un buffo del 5% a todas las stats.';
      case 'contrato': {
        const buffPercent = isDoubled ? 20 : 10;
        const nerfPercent = isDoubled ? 40 : 20;
        const buffStr = (mod.buffStats || ['ninjutsu', 'velocidad']).map(s => STAT_DISPLAY_NAMES[s] || s).join(' y ');
        const nerfStr = (mod.nerfStats || ['taijutsu', 'defensa']).map(s => STAT_DISPLAY_NAMES[s] || s).join(' y ');
        const extraNote = isDoubled ? ' (Piso ≥51: x2)' : '';
        return `Buffea un +${buffPercent}% ${buffStr} y nerfea un -${nerfPercent}% ${nerfStr}${extraNote}.`;
      }
      case 'muerte':
        return isDoubled
          ? 'Nerfea un 20% todas las stats hasta que pierdas dos rondas (Piso ≥51: x2).'
          : 'Nerfea un 10% todas las stats hasta que pierdas dos rondas.';
      case 'deseo':
        return isDoubled
          ? 'Tras cada ronda: Si ganas la ronda, el Boss obtiene +4% a todas las stats; si la pierdes, el Boss obtiene +2% (Piso ≥51: x2).'
          : 'Tras cada ronda: Si ganas la ronda, el Boss obtiene +2% a todas las stats; si la pierdes, el Boss obtiene +1%.';
      case 'reservado':
        return 'El boss siempre actuará después de ti, sin importar si gana o pierde la ronda.';
      default:
        return 'Modificador de combate activo.';
    }
  }

  /**
   * Genera el texto dinámico para la barra de buffeos durante el combate
   */
  function getDynamicModifierBuffText(mod, side) {
    if (!mod || !mod.id) return null;

    // Verificar correspondencia de objetivo:
    // Si el modificador afecta solo al boss y se pide para player -> null
    if (mod.target === 'boss' && side !== 'opponent') {
      return null;
    }
    // Si el modificador afecta solo al player y se pide para opponent -> null
    if (mod.target === 'player' && side !== 'player') {
      return null;
    }
    // Si es estándar ('none') y se pide para opponent -> null
    if (mod.target === 'none' && side !== 'player') {
      return null;
    }

    const isDoubled = (mod.floor >= 51);

    if (mod.id === 'estandar') {
      return 'Sin modificador extra';
    }

    if (mod.id === 'reservado') {
      return side === 'player'
        ? 'Actúas siempre primero en cada ronda'
        : 'Actúa siempre después del jugador';
    }

    if (mod.id === 'poderoso') {
      const powersCount = Object.values(window.battleState?.playerPowersUsed || {}).filter(Boolean).length;
      if (powersCount >= 2) {
        return 'Condición cumplida: Nerf desactivado (2/2 poderes usados)';
      }
      return `Nerf activo: -10% todas las stats (Poderes usados: ${powersCount}/2)`;
    }

    if (mod.id === 'muerte') {
      const roundsLost = window.battleState?.playerRoundsLostCount || 0;
      const nerfPercent = isDoubled ? 20 : 10;
      if (roundsLost >= 2) {
        return 'Condición cumplida: Nerf desactivado (2/2 rondas perdidas)';
      }
      return `Nerf activo: -${nerfPercent}% todas las stats (Rondas perdidas: ${roundsLost}/2)`;
    }

    if (mod.id === 'deseo') {
      const totalAccumulated = window.battleState?.deseoBossBuffPercent || 0;
      return side === 'opponent'
        ? `Buff acumulado: +${totalAccumulated}% a todas las stats`
        : `El Boss ha acumulado +${totalAccumulated}% a todas las stats`;
    }

    if (mod.id === 'contrato') {
      const buffPercent = isDoubled ? 20 : 10;
      const nerfPercent = isDoubled ? 40 : 20;
      const buffStr = (mod.buffStats || []).map(s => STAT_DISPLAY_NAMES[s] || s).join(' y ');
      const nerfStr = (mod.nerfStats || []).map(s => STAT_DISPLAY_NAMES[s] || s).join(' y ');
      return `+${buffPercent}% ${buffStr} | -${nerfPercent}% ${nerfStr}`;
    }

    if (mod.id === 'diversidad') {
      return 'Único Owner: +5% stats | Owner repetido: -5% stats';
    }

    if (mod.id === 'procedencial') {
      return 'Única Procedencia: +5% stats | Procedencia repetida: -5% stats';
    }

    if (mod.id === 'basicos') {
      return '+5% a todas las stats si no es carta especial';
    }

    if (mod.id === 'brutal') {
      const percent = isDoubled ? 10 : 5;
      return side === 'opponent'
        ? `+${percent}% a todas las stats (Boss)`
        : `El Boss tiene +${percent}% a todas las stats`;
    }

    return getModifierDescription(mod);
  }

  function hasDebuffImmunity(card, side) {
    if (!card) return false;
    let traitId = card.traitId;
    if (!traitId && side === 'opponent' && card.opponentTraitId) traitId = card.opponentTraitId;
    if (!traitId) {
      const cardKey = card.uniqueId || card.id;
      const map = window.battleState?.cardTraitsMap || window.cardTraitsMap || {};
      const entry = map[cardKey] || (card.id ? map[card.id] : null);
      traitId = entry?.traitId || entry || null;
    }
    return traitId === 'especialista' || traitId === 'monarch';
  }

  /**
   * Calcula el delta numérico de estadística que aporta el modificador activo para una carta
   */
  function getCardStatDelta(side, card, statType, baseValue) {
    if (!card || !Number.isFinite(baseValue) || baseValue <= 0) return 0;

    // Solo opera en Modo Infinito
    const isInfinite = !!(window.__infiniteBattleContext?.active || window.battleState?.difficulty === 'inmo');
    if (!isInfinite) return 0;

    const mod = window.battleState?.infiniteModifier || window.__infiniteBattleContext?.modifier;
    if (!mod || !mod.id || mod.id === 'estandar') return 0;

    // Cartas con Especialista o Monarch son inmunes a penalizaciones/debuffs
    const isImmune = hasDebuffImmunity(card, side);
    const clampResult = (delta) => (isImmune && delta < 0) ? 0 : delta;

    const isDoubled = (mod.floor >= 51);

    // 1. DIVERSIDAD (afecta al jugador)
    if (mod.id === 'diversidad' && side === 'player') {
      const team = window.battleState?.playerTeam || [];
      const cardOwner = String(card.owner || '').trim().toLowerCase();
      const count = team.filter(c => String(c.owner || '').trim().toLowerCase() === cardOwner).length;
      const percent = count === 1 ? 5 : -5;
      return clampResult(Math.floor(baseValue * (percent / 100)));
    }

    // 2. PODEROSO (afecta al jugador hasta usar al menos 2 poderes)
    if (mod.id === 'poderoso' && side === 'player') {
      const powersUsedCount = Object.values(window.battleState?.playerPowersUsed || {}).filter(Boolean).length;
      if (powersUsedCount < 2) {
        return clampResult(-Math.floor(baseValue * 0.10));
      }
      return 0;
    }

    // 3. BÁSICOS (afecta al jugador para cartas no especiales)
    if (mod.id === 'basicos' && side === 'player') {
      const isSpecial = typeof window.isCardSpecialQuality === 'function' ? window.isCardSpecialQuality(card) : false;
      if (!isSpecial) {
        return Math.floor(baseValue * 0.05);
      }
      return 0;
    }

    // 4. PROCEDENCIAL (afecta al jugador)
    if (mod.id === 'procedencial' && side === 'player') {
      const team = window.battleState?.playerTeam || [];
      const cardProc = String(card.procedencia || '').trim().toLowerCase();
      const count = team.filter(c => String(c.procedencia || '').trim().toLowerCase() === cardProc).length;
      const percent = count === 1 ? 5 : -5;
      return clampResult(Math.floor(baseValue * (percent / 100)));
    }

    // 5. BRUTAL (afecta al boss)
    if (mod.id === 'brutal' && side === 'opponent') {
      const percent = isDoubled ? 10 : 5;
      return Math.floor(baseValue * (percent / 100));
    }

    // 6. CONTRATO (afecta al jugador)
    if (mod.id === 'contrato' && side === 'player') {
      const buffPercent = isDoubled ? 20 : 10;
      const nerfPercent = isDoubled ? 40 : 20;

      if (statType === 'media') {
        // Para media, promedio de deltas
        const buffMatches = (mod.buffStats || []).length;
        const nerfMatches = (mod.nerfStats || []).length;
        const netPercent = ((buffMatches * buffPercent) - (nerfMatches * nerfPercent)) / 6;
        return clampResult(Math.floor(baseValue * (netPercent / 100)));
      }

      if (Array.isArray(mod.buffStats) && mod.buffStats.includes(statType)) {
        return Math.floor(baseValue * (buffPercent / 100));
      }
      if (Array.isArray(mod.nerfStats) && mod.nerfStats.includes(statType)) {
        return clampResult(-Math.floor(baseValue * (nerfPercent / 100)));
      }
      return 0;
    }

    // 7. MUERTE (afecta al jugador hasta perder 2 rondas)
    if (mod.id === 'muerte' && side === 'player') {
      const roundsLost = window.battleState?.playerRoundsLostCount || 0;
      if (roundsLost < 2) {
        const nerfPercent = isDoubled ? 20 : 10;
        return clampResult(-Math.floor(baseValue * (nerfPercent / 100)));
      }
      return 0;
    }

    // 8. DESEO (afecta al boss con el buff acumulado)
    if (mod.id === 'deseo' && side === 'opponent') {
      const totalAccumulated = window.battleState?.deseoBossBuffPercent || 0;
      if (totalAccumulated > 0) {
        return Math.floor(baseValue * (totalAccumulated / 100));
      }
      return 0;
    }

    return 0;
  }

  /**
   * Ejecuta la animación de ruleta del modificador en el área de intro de batalla.
   * Reproduce traitspin.wav, parpadea en rojo intenso durante ~2.5 segundos,
   * detiene el sonido y parpadeo a la vez, revela el modificador y espera el click del usuario.
   */
  function playModifierRoulette(callback) {
    const isInfinite = !!(window.__infiniteBattleContext?.active || window.battleState?.difficulty === 'inmo');
    if (!isInfinite) {
      if (typeof callback === 'function') callback();
      return;
    }

    const modifier = window.battleState?.infiniteModifier || window.__infiniteBattleContext?.modifier;
    if (!modifier) {
      console.warn('[MODIFIER] No hay modificador configurado para esta batalla.');
      if (typeof callback === 'function') callback();
      return;
    }

    const introSection = document.getElementById('battle-intro');
    if (!introSection) {
      if (typeof callback === 'function') callback();
      return;
    }

    // Ocultar temporalmente las cartas de intro y la instrucción para dar foco completo a la ruleta
    const introCards = document.getElementById('battle-intro-cards');
    const introInstruction = document.getElementById('battle-intro-instruction');
    if (introCards) introCards.style.display = 'none';
    if (introInstruction) introInstruction.style.display = 'none';

    // Eliminar overlay anterior si existiera
    const oldOverlay = document.getElementById('infinite-modifier-intro-overlay');
    if (oldOverlay) oldOverlay.remove();

    // Crear overlay de la ruleta dentro de battle-intro
    const overlay = document.createElement('div');
    overlay.id = 'infinite-modifier-intro-overlay';
    overlay.className = 'modifier-roulette-overlay';

    // Crear la caja roja parpadeante
    const box = document.createElement('div');
    box.id = 'infinite-modifier-roulette-box';
    box.className = 'modifier-roulette-box flashing';

    // Contenido inicial durante el parpadeo
    box.innerHTML = `
      <div class="modifier-box-header">MODO INFINITO</div>
      <div class="modifier-box-sub">MODIFICADOR DE COMBATE</div>
      <div class="modifier-roulette-spinner">
        <div class="modifier-roulette-spinner-ring"></div>
        <div class="modifier-roulette-label">Sorteando modificador...</div>
      </div>
    `;

    overlay.appendChild(box);
    introSection.appendChild(overlay);

    // Iniciar sonido de traits
    let audio = null;
    try {
      audio = new Audio('music/sfx/traitspin.wav');
      audio.volume = 0.6;
      audio.loop = true;
      audio.play().catch((err) => {
        console.log('[MODIFIER] Audio autoplay bloqueado o error:', err);
      });
    } catch (e) {
      console.warn('[MODIFIER] No se pudo instanciar Audio:', e);
    }

    // Duración de la animación: exactamente 2500ms
    const ANIMATION_DURATION = 2500;

    setTimeout(() => {
      // 1. Detener simultáneamente sonido y parpadeo
      if (audio) {
        try {
          audio.pause();
          audio.currentTime = 0;
        } catch (e) {}
      }

      box.classList.remove('flashing');
      box.classList.add('revealed');

      if (typeof window.playSFX === 'function') {
        window.playSFX('cardSelect');
      }

      // 2. Revelar modificador
      const isSpecial = modifier.type === 'especial';
      const badgeClass = isSpecial ? 'badge-especial' : 'badge-normal';
      const badgeText = isSpecial ? 'MODIFICADOR ESPECIAL' : 'MODIFICADOR NORMAL';
      const descText = getModifierDescription(modifier);

      box.innerHTML = `
        <div class="modifier-box-header">MODO INFINITO</div>
        <div class="modifier-type-badge ${badgeClass}">${badgeText}</div>
        <div class="modifier-reveal-title">${modifier.name.toUpperCase()}</div>
        <div class="modifier-reveal-desc">${descText}</div>
        <div class="modifier-continue-hint">Haz click en cualquier parte para comenzar</div>
      `;

      // 3. Esperar a que el usuario haga click en la pantalla para avanzar
      let clicked = false;
      const advanceHandler = (e) => {
        if (clicked) return;
        clicked = true;
        e.stopPropagation();
        e.preventDefault();

        document.removeEventListener('click', advanceHandler, true);
        document.removeEventListener('keydown', advanceHandler, true);

        // Desvanecer overlay suavemente
        overlay.classList.add('fade-out');
        setTimeout(() => {
          overlay.remove();
          if (introCards) introCards.style.display = '';
          if (introInstruction) introInstruction.style.display = '';
          if (typeof callback === 'function') {
            callback();
          }
        }, 300);
      };

      // Registrar escucha de click (y tecla por accesibilidad)
      setTimeout(() => {
        document.addEventListener('click', advanceHandler, { capture: true, once: true });
        document.addEventListener('keydown', advanceHandler, { capture: true, once: true });
      }, 100);

    }, ANIMATION_DURATION);
  }

  // Exportar API pública al objeto window
  window.InfiniteModifiers = {
    NORMAL_MODIFIERS,
    SPECIAL_MODIFIERS,
    getFloorCombatRole,
    getOrAssignModifierForFloor,
    getModifierDescription,
    getDynamicModifierBuffText,
    getCardStatDelta,
    playModifierRoulette
  };

})(window);
