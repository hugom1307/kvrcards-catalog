const express = require('express');
const router = express.Router();

// Almacena la versión actual autorizada
let currentVersion = {
  version: '1.0.0',
  downloadUrl: 'https://github.com/hugom1307/kvrcards-catalog/releases/download/v1.0.0/game.zip',
  size: 125000000,
  changelog: '- Versión inicial\n- Sistema de cartas ninja\n- Modo PvP online\n- Sistema de calidad y títulos',
  mandatory: false,
  publishedAt: new Date().toISOString()
};

// GET /api/launcher/version
router.get('/api/launcher/version', (req, res) => {
  console.log('📡 Launcher version check:', currentVersion.version);
  res.json(currentVersion);
});

// POST /api/launcher/publish
router.post('/api/launcher/publish', authenticateAdmin, (req, res) => {
  const { version, downloadUrl, size, changelog, mandatory } = req.body;
  
  if (!version || !downloadUrl) {
    return res.status(400).json({ error: 'Version and downloadUrl are required' });
  }
  
  currentVersion = {
    version,
    downloadUrl,
    size: size || 0,
    changelog: changelog || 'No changelog provided',
    mandatory: mandatory || false,
    publishedAt: new Date().toISOString()
  };
  
  console.log(`✅ New version published: ${version}`);
  
  res.json({ 
    success: true, 
    message: 'Version published successfully',
    version: currentVersion 
  });
});

// GET /api/launcher/history
router.get('/api/launcher/history', (req, res) => {
  res.json({
    versions: [currentVersion]
  });
});

// Middleware de autenticación
function authenticateAdmin(req, res, next) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1];
  
  const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'kvr-admin-token-2026';
  
  if (token !== ADMIN_TOKEN) {
    console.log('❌ Unauthorized launcher publish attempt');
    return res.status(403).json({ error: 'Unauthorized' });
  }
  
  next();
}

module.exports = router;
