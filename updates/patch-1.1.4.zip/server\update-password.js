// Script para actualizar la contraseña de un usuario en R2
const https = require('https');

const username = 'HugoM1307';
const password = 'HugoMan130207';

// Primero obtener los datos actuales
const getOptions = {
  hostname: 'kvrcards-server.onrender.com',
  path: `/api/inventory/${username}`,
  method: 'GET'
};

console.log('Obteniendo datos actuales...');

const getReq = https.request(getOptions, (res) => {
  let data = '';
  
  res.on('data', (chunk) => {
    data += chunk;
  });
  
  res.on('end', () => {
    try {
      const userData = JSON.parse(data);
      console.log('Datos actuales obtenidos:', userData.username);
      
      // Añadir la contraseña
      userData.password = password;
      userData.updatedAt = Date.now();
      
      // Enviar de vuelta con la contraseña
      const postData = JSON.stringify(userData);
      
      const postOptions = {
        hostname: 'kvrcards-server.onrender.com',
        path: `/api/inventory/${username}`,
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(postData)
        }
      };
      
      console.log('Actualizando con contraseña...');
      
      const postReq = https.request(postOptions, (postRes) => {
        let responseData = '';
        
        postRes.on('data', (chunk) => {
          responseData += chunk;
        });
        
        postRes.on('end', () => {
          console.log('Respuesta del servidor:', responseData);
          console.log('✓ Contraseña actualizada correctamente!');
          console.log(`Verifica en: https://kvrcards-server.onrender.com/user/${username}`);
        });
      });
      
      postReq.on('error', (e) => {
        console.error('Error en POST:', e);
      });
      
      postReq.write(postData);
      postReq.end();
      
    } catch (e) {
      console.error('Error parseando datos:', e);
    }
  });
});

getReq.on('error', (e) => {
  console.error('Error en GET:', e);
});

getReq.end();
