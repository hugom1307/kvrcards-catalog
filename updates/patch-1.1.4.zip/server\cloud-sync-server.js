const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const CLOUD_DATA_DIR = path.join(__dirname, 'cloud-data');
const USERS_FILE = path.join(CLOUD_DATA_DIR, 'users.json');

// Asegurar que existe el directorio
if (!fs.existsSync(CLOUD_DATA_DIR)) {
  fs.mkdirSync(CLOUD_DATA_DIR, { recursive: true });
}

// Inicializar archivo de usuarios si no existe
if (!fs.existsSync(USERS_FILE)) {
  fs.writeFileSync(USERS_FILE, JSON.stringify({}, null, 2));
}

// Hash de contraseña (simple para demo, en producción usar bcrypt)
function hashPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex');
}

// Leer usuarios
function loadUsers() {
  try {
    const data = fs.readFileSync(USERS_FILE, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error('[CLOUD] Error loading users:', err);
    return {};
  }
}

// Guardar usuarios
function saveUsers(users) {
  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
    return true;
  } catch (err) {
    console.error('[CLOUD] Error saving users:', err);
    return false;
  }
}

// Registrar nuevo usuario
function register(username, password) {
  console.log('[CLOUD] Register attempt:', username);
  
  if (!username || !password) {
    return { ok: false, error: 'Usuario y contraseña requeridos' };
  }
  
  if (username.length < 3) {
    return { ok: false, error: 'El usuario debe tener al menos 3 caracteres' };
  }
  
  if (password.length < 4) {
    return { ok: false, error: 'La contraseña debe tener al menos 4 caracteres' };
  }
  
  const users = loadUsers();
  
  if (users[username]) {
    return { ok: false, error: 'El usuario ya existe' };
  }
  
  users[username] = {
    password: hashPassword(password),
    createdAt: Date.now(),
    lastSync: null,
    data: null
  };
  
  if (!saveUsers(users)) {
    return { ok: false, error: 'Error al crear la cuenta' };
  }
  
  console.log('[CLOUD] User registered:', username);
  return { ok: true, username };
}

// Iniciar sesión
function login(username, password) {
  console.log('[CLOUD] Login attempt:', username);
  
  if (!username || !password) {
    return { ok: false, error: 'Usuario y contraseña requeridos' };
  }
  
  const users = loadUsers();
  const user = users[username];
  
  if (!user) {
    return { ok: false, error: 'Usuario no encontrado' };
  }
  
  if (user.password !== hashPassword(password)) {
    return { ok: false, error: 'Contraseña incorrecta' };
  }
  
  console.log('[CLOUD] Login successful:', username);
  return { 
    ok: true, 
    username,
    lastSync: user.lastSync,
    hasData: !!user.data
  };
}

// Subir datos a la nube
function uploadData(username, password, data) {
  console.log('[CLOUD] Upload data for:', username);
  
  // Verificar credenciales
  const loginResult = login(username, password);
  if (!loginResult.ok) {
    return loginResult;
  }
  
  const users = loadUsers();
  users[username].data = data;
  users[username].lastSync = Date.now();
  
  if (!saveUsers(users)) {
    return { ok: false, error: 'Error al guardar los datos' };
  }
  
  console.log('[CLOUD] Data uploaded successfully for:', username);
  return { 
    ok: true, 
    message: 'Datos subidos correctamente',
    lastSync: users[username].lastSync
  };
}

// Descargar datos de la nube
function downloadData(username, password) {
  console.log('[CLOUD] Download data for:', username);
  
  // Verificar credenciales
  const loginResult = login(username, password);
  if (!loginResult.ok) {
    return loginResult;
  }
  
  const users = loadUsers();
  const user = users[username];
  
  if (!user.data) {
    return { ok: false, error: 'No hay datos guardados en la nube' };
  }
  
  console.log('[CLOUD] Data downloaded successfully for:', username);
  return { 
    ok: true, 
    data: user.data,
    lastSync: user.lastSync
  };
}

module.exports = {
  register,
  login,
  uploadData,
  downloadData
};
