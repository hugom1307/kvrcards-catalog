(function battlePowersModule() {
  'use strict';

  const BattlePowers = {
    setupPowerButtons,
    handleOpponentPowerUsed,
    handlePowerConfirmed,
    handlePowerError
  };

  function getPlayerDisplayName() {
    return (typeof currentUser !== 'undefined' && currentUser) 
      ? currentUser 
      : (window.currentUser || window.onlineState?.username || window.battleState?.playerName || 'Tú');
  }

  function checkInfinitePoderosoModifier() {
    if (typeof updateBattleCards === 'function') updateBattleCards();
    if (typeof updateBattleBuffsDisplay === 'function') updateBattleBuffsDisplay();
  }

  function setupPowerButtons() {
    console.log('[POWER] Configurando botones de poderes');

    // Boton de intercambio del jugador
    var playerSwapBtn = document.getElementById('player-power-swap');
    if (playerSwapBtn) {
      playerSwapBtn.replaceWith(playerSwapBtn.cloneNode(true));
      var newPlayerSwapBtn = document.getElementById('player-power-swap');
      newPlayerSwapBtn.addEventListener('click', async function() {
        if (window.battleState.selectedStat) {
          showNotification('⚠️ Debes usar RESERVA antes de elegir stat', 'warning');
          return;
        }
        if (window.battleState.gamePhase === 'stat-selection' && !window.battleState.playerPowersUsed.swap) {
          var isOnlineBattle = window.onlineState && window.onlineState.inBattle && window.onlineState.matchId;

          if (isOnlineBattle) {
            console.log('[POWER-ONLINE] Enviando uso de SWAP al servidor');

            var reserveCard = window.battleState.playerReserveCard;
            if (!reserveCard) {
              showNotification('⚠️ No tienes carta de reserva', 'warning');
              return;
            }

            var reserveIndex = window.battleState.playerTeam.findIndex(function(c) {
              return (c.uniqueId && c.uniqueId === reserveCard.uniqueId) ||
                (c.id === reserveCard.id && c.nombre === reserveCard.nombre);
            });

            if (reserveIndex === -1 && Number.isInteger(window.battleState.playerReserveCardIndex) && window.battleState.playerReserveCardIndex >= 0) {
              reserveIndex = window.battleState.playerReserveCardIndex;
            }
            if (reserveIndex === -1 && window.battleState.playerTeam.length > 7) {
              reserveIndex = 7;
            }

            if (reserveIndex === -1) {
              console.error('[POWER-ONLINE] No se encontro carta de reserva en el equipo');
              showNotification('⚠️ No se pudo encontrar la carta de reserva en tu equipo', 'warning');
              return;
            }

            window.onlineState.socket.emit('power-used', {
              matchId: window.onlineState.matchId,
              powerType: 'swap',
              newCardIndex: reserveIndex
            });

            var swapBtnEl = document.getElementById('player-power-swap');
            if (swapBtnEl) {
              swapBtnEl.classList.add('activating');
              swapBtnEl.disabled = true;
            }
          } else {
            await usePowerSwap(true);
            checkInfinitePoderosoModifier();
          }
        }
      });
    }

    // Boton de Power Up del jugador
    var playerPowerUpBtn = document.getElementById('player-power-powerup');
    if (playerPowerUpBtn) {
      playerPowerUpBtn.replaceWith(playerPowerUpBtn.cloneNode(true));
      var newPlayerPowerUpBtn = document.getElementById('player-power-powerup');
      newPlayerPowerUpBtn.addEventListener('click', async function() {
        if (window.battleState.selectedStat) {
          showNotification('⚠️ Debes usar POWER UP antes de elegir stat', 'warning');
          return;
        }
        if (window.battleState.gamePhase === 'stat-selection' && !window.battleState.playerPowersUsed.powerup) {
          var isOnlineBattle = window.onlineState && window.onlineState.inBattle && window.onlineState.matchId;

          if (isOnlineBattle) {
            console.log('[POWER-ONLINE] Enviando uso de POWERUP al servidor');

            window.onlineState.socket.emit('power-used', {
              matchId: window.onlineState.matchId,
              powerType: 'powerup'
            });

            window.battleState.playerPowersUsed.powerup = true;
            window.battleState.playerPowerUpActive = true;

            var powerBtn = document.getElementById('player-power-powerup');
            if (powerBtn) {
              powerBtn.classList.add('used', 'activating');
              setTimeout(function() { powerBtn.classList.remove('activating'); }, 600);
            }

            var userName = getPlayerDisplayName();
            await showPowerActivation('powerup', userName, true);
            updateBattleCards();
          } else {
            await usePowerUp(true);
            checkInfinitePoderosoModifier();
          }
        }
      });
    }

    // Boton de NERF del jugador
    var playerNerfBtn = document.getElementById('player-power-nerf');
    if (playerNerfBtn) {
      playerNerfBtn.replaceWith(playerNerfBtn.cloneNode(true));
      var newPlayerNerfBtn = document.getElementById('player-power-nerf');
      newPlayerNerfBtn.addEventListener('click', async function() {
        if (window.battleState.selectedStat) {
          showNotification('⚠️ Debes usar NERF antes de elegir tu stat', 'warning');
          return;
        }

        if (window.battleState.gamePhase === 'stat-selection' &&
            !window.battleState.playerPowersUsed.nerf &&
            window.battleState.playerScore < window.battleState.opponentScore &&
            window.battleState.opponentSelectedStat) {

          var isOnlineBattle = window.onlineState && window.onlineState.inBattle && window.onlineState.matchId;

          if (isOnlineBattle) {
            console.log('[POWER-ONLINE] Enviando uso de NERF al servidor');

            window.onlineState.socket.emit('power-used', {
              matchId: window.onlineState.matchId,
              powerType: 'nerf'
            });

            window.battleState.playerPowersUsed.nerf = true;
            window.battleState.playerNerfActive = true;

            var playerNerfBtnEl = document.getElementById('player-power-nerf');
            if (playerNerfBtnEl) {
              playerNerfBtnEl.classList.add('used', 'activating');
              setTimeout(function() { playerNerfBtnEl.classList.remove('activating'); }, 600);
            }

            var userName = getPlayerDisplayName();
            await showPowerActivation('nerf', userName, true);
            applyNerfVisual(true);
          } else {
            window.battleState.playerPowersUsed.nerf = true;
            window.battleState.playerNerfActive = true;

            var userNameOffline = getPlayerDisplayName();
            await showPowerActivation('nerf', userNameOffline, true);
            applyNerfVisual(true);
            checkInfinitePoderosoModifier();

            newPlayerNerfBtn.classList.add('used', 'activating');
            setTimeout(function() { newPlayerNerfBtn.classList.remove('activating'); }, 600);

            console.log('[POWER] Jugador activa NERF');
          }
        } else {
          if (window.battleState.playerPowersUsed.nerf) {
            showNotification('⚠️ Ya usaste el poder NERF', 'warning');
          } else if (window.battleState.playerScore >= window.battleState.opponentScore) {
            showNotification('⚠️ Solo puedes usar NERF cuando estás perdiendo', 'warning');
          } else if (!window.battleState.opponentSelectedStat) {
            showNotification('⚠️ El oponente debe elegir su stat primero', 'warning');
          }
        }
      });
    }

    // Boton de ANULO del jugador
    var playerAnuloBtn = document.getElementById('player-power-anulo');
    if (playerAnuloBtn) {
      playerAnuloBtn.replaceWith(playerAnuloBtn.cloneNode(true));
      var newPlayerAnuloBtn = document.getElementById('player-power-anulo');
      newPlayerAnuloBtn.addEventListener('click', async function() {
        if (window.battleState.selectedStat) {
          showNotification('⚠️ Debes usar ANULO antes de elegir tu propia estadística', 'warning');
          return;
        }
        if (!window.battleState.opponentSelectedStat) {
          showNotification('⚠️ Solo puedes usar ANULO después de que el oponente haya seleccionado su estadística', 'warning');
          return;
        }
        if (window.battleState.playerPowersUsed.anulo) {
          showNotification('⚠️ Ya usaste el poder ANULO', 'warning');
          return;
        }

        var opponentAvailableStats = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
          .filter(function(s) { 
            return !window.battleState.opponentUsedStats.includes(s) || s === window.battleState.opponentSelectedStat; 
          });
          
        if (opponentAvailableStats.length <= 1) {
          showNotification('⚠️ No puedes usar ANULO cuando solo le queda una estadística disponible al rival', 'warning');
          return;
        }

        var targetStat = window.battleState.opponentSelectedStat;
        var isOnlineBattle = window.onlineState && window.onlineState.inBattle && window.onlineState.matchId;

        if (isOnlineBattle) {
          console.log('[LOG-POWERS] Click en botón ANULO - Modo Online');
          console.log('[LOG-POWERS] Parámetros a enviar - stat a anular:', targetStat, 'matchId:', window.onlineState.matchId);

          window.onlineState.socket.emit('power-used', {
            matchId: window.onlineState.matchId,
            powerType: 'anulo',
            stat: targetStat
          });
          console.log('[LOG-POWERS] Evento socket "power-used" emitido para ANULO');

          // Lógica optimista local de inmediato
          window.battleState.playerPowersUsed.anulo = true;
          window.battleState.annulledStat = targetStat;

          // Cancelar la elección del oponente localmente
          window.battleState.opponentSelectedStat = null;
          var indexOpp = window.battleState.opponentUsedStats.indexOf(targetStat);
          if (indexOpp !== -1) {
            window.battleState.opponentUsedStats.splice(indexOpp, 1);
          }
          var opponentDisplay = document.querySelector(`.battle-side-opponent .battle-stat-display[data-stat="${targetStat}"]`);
          if (opponentDisplay) {
            opponentDisplay.classList.remove('highlighted', 'used');
          }

          var anuloBtnEl = document.getElementById('player-power-anulo');
          if (anuloBtnEl) {
            anuloBtnEl.classList.add('used', 'activating');
            setTimeout(function() { anuloBtnEl.classList.remove('activating'); }, 600);
            console.log('[LOG-POWERS] Botón ANULO configurado como usado y clase "activating" agregada temporalmente');
          }

          var userNameAnulo = getPlayerDisplayName();
          console.log('[LOG-POWERS] Iniciando animación showPowerActivation para ANULO propio:', userNameAnulo);
          showPowerActivation('anulo', userNameAnulo, true).then(function() {
            console.log('[LOG-POWERS] Animación showPowerActivation de ANULO propio terminada. Aplicando visual de bloqueo.');
            applyAnuloVisual(true, targetStat);
          });
        } else {
          console.log('[LOG-POWERS] Click en botón ANULO - Modo Offline');
          await usePowerAnulo(true, targetStat);
          checkInfinitePoderosoModifier();
        }
      });
    }

    // Boton de INTERCAMBIO del jugador
    var playerIntercambioBtn = document.getElementById('player-power-intercambio');
    if (playerIntercambioBtn) {
      playerIntercambioBtn.replaceWith(playerIntercambioBtn.cloneNode(true));
      var newPlayerIntercambioBtn = document.getElementById('player-power-intercambio');
      newPlayerIntercambioBtn.addEventListener('click', async function() {
        if (window.battleState.selectedStat) {
          showNotification('⚠️ Debes usar INTERCAMBIO antes de elegir stat', 'warning');
          return;
        }
        if (window.battleState.gamePhase !== 'stat-selection') {
          showNotification('⚠️ No puedes usar INTERCAMBIO fuera de la fase de selección de stat', 'warning');
          return;
        }
        if (window.battleState.currentTurn !== 'player') {
          showNotification('⚠️ Solo puedes usar INTERCAMBIO durante tu turno de elección de stat', 'warning');
          return;
        }
        if (window.battleState.playerPowersUsed.intercambio) {
          showNotification('⚠️ Ya usaste el poder INTERCAMBIO', 'warning');
          return;
        }

        var isOnlineBattle = window.onlineState && window.onlineState.inBattle && window.onlineState.matchId;

        if (isOnlineBattle) {
          console.log('[LOG-POWERS] Click en botón INTERCAMBIO - Modo Online');
          console.log('[LOG-POWERS] Parámetros a enviar - matchId:', window.onlineState.matchId);

          window.onlineState.socket.emit('power-used', {
            matchId: window.onlineState.matchId,
            powerType: 'intercambio'
          });
          console.log('[LOG-POWERS] Evento socket "power-used" emitido para INTERCAMBIO');

          // Lógica optimista y control de animación para INTERCAMBIO
          window.battleState.playerPowersUsed.intercambio = true;
          window.battleState.playerIntercambioPending = true;
          window.battleState.playerIntercambioTransformedCard = null;
          window.battleState.playerIntercambioAnimFinished = false;

          var intercambioBtnEl = document.getElementById('player-power-intercambio');
          if (intercambioBtnEl) {
            intercambioBtnEl.classList.add('used', 'activating');
            setTimeout(function() { intercambioBtnEl.classList.remove('activating'); }, 600);
            console.log('[LOG-POWERS] Botón INTERCAMBIO configurado como usado y clase "activating" agregada temporalmente');
          }

          var userNameIntercambio = getPlayerDisplayName();
          console.log('[LOG-POWERS] Iniciando animación showPowerActivation para INTERCAMBIO propio:', userNameIntercambio);
          showPowerActivation('intercambio', userNameIntercambio, true).then(async function() {
            console.log('[LOG-POWERS] Animación showPowerActivation de INTERCAMBIO propia terminada. Iniciando swap-out.');
            var cardDisplay = document.querySelector('.battle-side-player .battle-card-display');
            if (cardDisplay) {
              cardDisplay.classList.add('swapping-out');
              await new Promise(resolve => setTimeout(resolve, 600));
            }
            
            window.battleState.playerIntercambioAnimFinished = true;
            // Si la confirmación del servidor ya llegó, aplicar el cambio de carta ahora mismo
            if (window.battleState.playerIntercambioTransformedCard) {
              await applyIntercambioCardSwap(window.battleState.playerIntercambioTransformedCard);
            }
          });
        } else {
          console.log('[LOG-POWERS] Click en botón INTERCAMBIO - Modo Offline');
          await usePowerIntercambio(true);
          checkInfinitePoderosoModifier();
        }
      });
    }
  }

  function handleOpponentPowerUsed(data) {
    console.log('[ONLINE-BATTLE] Oponente uso poder:', data.powerType);

    if (data.powerType === 'swap') {
      if (data.newCard && data.newCardIndex !== undefined) {
        console.log('[ONLINE-BATTLE] Aplicando SWAP del oponente, nueva carta:', data.newCard.name || data.newCard.nombre);

        window.battleState.opponentPowersUsed.swap = true;
        window.battleState.opponentReserveCardUsed = true;
        window.battleState.opponentCurrentCard = data.newCard;

        var opponentSwapBtn = document.getElementById('opponent-power-swap');
        if (opponentSwapBtn) {
          opponentSwapBtn.classList.add('used', 'activating');
          setTimeout(function() { opponentSwapBtn.classList.remove('activating'); }, 600);
        }

        var opponentNameSwap = window.battleState.opponentName || window.onlineState?.opponentData?.username || 'Rival';
        showPowerActivation('swap', opponentNameSwap, false).then(function() {
          updateBattleCards();
        });
      }
    } else if (data.powerType === 'powerup') {
      console.log('[ONLINE-BATTLE] Aplicando POWERUP del oponente directamente');

      window.battleState.opponentPowersUsed.powerup = true;
      window.battleState.opponentPowerUpActive = true;

      var opponentPowerUpBtn = document.getElementById('opponent-power-powerup');
      if (opponentPowerUpBtn) {
        opponentPowerUpBtn.classList.add('used', 'activating');
        setTimeout(function() { opponentPowerUpBtn.classList.remove('activating'); }, 600);
      }

      var opponentNamePower = window.battleState.opponentName || window.onlineState?.opponentData?.username || 'Rival';
      showPowerActivation('powerup', opponentNamePower, false).then(function() {
        updateBattleCards();
      });
    } else if (data.powerType === 'nerf') {
      console.log('[ONLINE-BATTLE] Aplicando NERF del oponente sobre stat:', data.targetStat);

      window.battleState.opponentPowersUsed.nerf = true;
      window.battleState.opponentNerfActive = true;

      var opponentNerfBtn = document.getElementById('opponent-power-nerf');
      if (opponentNerfBtn) {
        opponentNerfBtn.classList.add('used', 'activating');
        setTimeout(function() { opponentNerfBtn.classList.remove('activating'); }, 600);
      }

      var opponentNameNerf = window.battleState.opponentName || window.onlineState?.opponentData?.username || 'Rival';
      showPowerActivation('nerf', opponentNameNerf, false).then(function() {
        applyNerfVisual(false);
      });
    } else if (data.powerType === 'anulo') {
      console.log('[LOG-POWERS] Evento "opponent-power-used" recibido para ANULO');
      console.log('[LOG-POWERS] Datos recibidos:', data);

      window.battleState.opponentPowersUsed.anulo = true;
      window.battleState.annulledStat = data.targetStat;

      // Cancelar nuestra elección
      window.battleState.selectedStat = null;
      var index = (window.battleState.playerUsedStats || []).indexOf(data.targetStat);
      if (index !== -1) {
        window.battleState.playerUsedStats.splice(index, 1);
      }
      var playerBtn = document.querySelector(`.battle-side-player .battle-stat-btn[data-stat="${data.targetStat}"]`);
      if (playerBtn) {
        playerBtn.classList.remove('used', 'highlighted');
      }

      var opponentAnuloBtn = document.getElementById('opponent-power-anulo');
      if (opponentAnuloBtn) {
        opponentAnuloBtn.classList.add('used', 'activating');
        setTimeout(function() { opponentAnuloBtn.classList.remove('activating'); }, 600);
      }

      var opponentNameAnulo = window.battleState.opponentName || window.onlineState?.opponentData?.username || 'Rival';
      console.log('[LOG-POWERS] Iniciando animación showPowerActivation para ANULO del oponente:', opponentNameAnulo);
      showPowerActivation('anulo', opponentNameAnulo, false).then(function() {
        console.log('[LOG-POWERS] Animación showPowerActivation de ANULO terminada. Aplicando visual de bloqueo.');
        applyAnuloVisual(false, data.targetStat);
        
        // El jugador debe elegir otra stat (solo si no fue auto-asignado por el servidor)
        if (!window.battleState.selectedStat) {
          window.battleState.currentTurn = 'player';
          if (typeof enableStatSelection === 'function') {
            enableStatSelection();
          }
          showNotification('⚠️ ¡El rival ha anulado tu estadística! Elige otra.', 'warning');
        } else {
          console.log('[LOG-POWERS] Stat ya auto-asignada, no se habilita selección');
        }
        console.log('[LOG-POWERS] Efecto de ANULO aplicado con éxito');
      });
    } else if (data.powerType === 'intercambio') {
      console.log('[LOG-POWERS] Evento "opponent-power-used" recibido para INTERCAMBIO');
      console.log('[LOG-POWERS] Datos recibidos:', data);

      window.battleState.opponentPowersUsed.intercambio = true;

      var opponentIntercambioBtn = document.getElementById('opponent-power-intercambio');
      if (opponentIntercambioBtn) {
        opponentIntercambioBtn.classList.add('used', 'activating');
        setTimeout(function() { opponentIntercambioBtn.classList.remove('activating'); }, 600);
      }

      var opponentNameIntercambio = window.battleState.opponentName || window.onlineState?.opponentData?.username || 'Rival';
      console.log('[LOG-POWERS] Iniciando animación showPowerActivation para INTERCAMBIO del oponente:', opponentNameIntercambio);
      showPowerActivation('intercambio', opponentNameIntercambio, false).then(async function() {
        console.log('[LOG-POWERS] Animación showPowerActivation de INTERCAMBIO terminada. Aplicando cambio de carta.');
        
        const originalOpponentCard = window.battleState.opponentCurrentCard;
        var oppCardIndex = -1;
        if (originalOpponentCard && window.battleState.opponentTeam) {
          oppCardIndex = window.battleState.opponentTeam.findIndex(c => 
            (originalOpponentCard.uniqueId && c.uniqueId === originalOpponentCard.uniqueId) || 
            (originalOpponentCard.id && c.id === originalOpponentCard.id && (
              (c.nombre && originalOpponentCard.nombre && c.nombre === originalOpponentCard.nombre) ||
              (c.name && originalOpponentCard.name && c.name === originalOpponentCard.name) ||
              (!c.nombre && !originalOpponentCard.nombre && !c.name && !originalOpponentCard.name)
            ))
          );
        }

        var cardDisplay = document.querySelector('.battle-side-opponent .battle-card-display');
        if (cardDisplay) {
          cardDisplay.classList.add('swapping-out');
          await new Promise(resolve => setTimeout(resolve, 600));

          window.battleState.opponentCurrentCard = data.transformedCard;
          if (oppCardIndex !== -1) {
            window.battleState.opponentTeam[oppCardIndex] = data.transformedCard;
          }

          updateBattleCards();

          cardDisplay.classList.remove('swapping-out');
          cardDisplay.classList.add('swapping-in');
          await new Promise(resolve => setTimeout(resolve, 600));
          cardDisplay.classList.remove('swapping-in');
        } else {
          window.battleState.opponentCurrentCard = data.transformedCard;
          if (oppCardIndex !== -1) {
            window.battleState.opponentTeam[oppCardIndex] = data.transformedCard;
          }
          updateBattleCards();
        }
        console.log('[LOG-POWERS] Efecto de INTERCAMBIO aplicado con éxito');
      });
    }
  }

  async function handlePowerConfirmed(data) {
    console.log('[ONLINE-BATTLE] Poder confirmado por servidor:', data.powerType);

    if (data.powerType === 'swap') {
      if (window.battleState.playerPowersUsed.swap) {
        console.log('[ONLINE-BATTLE] SWAP ya aplicado localmente, confirmacion del servidor OK');
        return;
      }
      if (data.newCard) {
        if (data.newCardIndex !== undefined) {
          window.battleState.playerCurrentCard = window.battleState.playerTeam[data.newCardIndex] || data.newCard;
        } else {
          window.battleState.playerCurrentCard = data.newCard;
        }
      }
      window.battleState.playerPowersUsed.swap = true;
      window.battleState.playerReserveCardUsed = true;
      var playerSwapBtn = document.getElementById('player-power-swap');
      if (playerSwapBtn) {
        playerSwapBtn.classList.add('used', 'activating');
        setTimeout(function() { playerSwapBtn.classList.remove('activating'); }, 600);
      }
      var userNameSwap = getPlayerDisplayName();
      await showPowerActivation('swap', userNameSwap, true);
      updateBattleCards();
    } else if (data.powerType === 'powerup') {
      if (window.battleState.playerPowersUsed.powerup) {
        console.log('[ONLINE-BATTLE] POWERUP ya aplicado localmente, confirmacion del servidor OK');
        return;
      }
      console.log('[ONLINE-BATTLE] Aplicando POWERUP propio directamente');
      window.battleState.playerPowersUsed.powerup = true;
      window.battleState.playerPowerUpActive = true;
      var powerBtn = document.getElementById('player-power-powerup');
      if (powerBtn) {
        powerBtn.classList.add('used', 'activating');
        setTimeout(function() { powerBtn.classList.remove('activating'); }, 600);
      }
      var userNamePower = getPlayerDisplayName();
      await showPowerActivation('powerup', userNamePower, true);
      updateBattleCards();
    } else if (data.powerType === 'nerf') {
      if (window.battleState.playerPowersUsed.nerf) {
        console.log('[ONLINE-BATTLE] NERF ya aplicado localmente, confirmacion del servidor OK');
        return;
      }
      window.battleState.playerPowersUsed.nerf = true;
      window.battleState.playerNerfActive = true;
      var playerNerfBtn = document.getElementById('player-power-nerf');
      if (playerNerfBtn) {
        playerNerfBtn.classList.add('used', 'activating');
        setTimeout(function() { playerNerfBtn.classList.remove('activating'); }, 600);
      }
      var userNameNerf = getPlayerDisplayName();
      await showPowerActivation('nerf', userNameNerf, true);
      applyNerfVisual(true);
    } else if (data.powerType === 'anulo') {
      console.log('[LOG-POWERS] Evento "power-confirmed" recibido para ANULO');
      console.log('[LOG-POWERS] Datos recibidos:', data);

      if (window.battleState.playerPowersUsed.anulo) {
        console.log('[LOG-POWERS] ANULO ya aplicado localmente, confirmacion del servidor OK');
        return;
      }
      window.battleState.playerPowersUsed.anulo = true;
      window.battleState.annulledStat = data.targetStat;
      
      // Cancelar la elección del oponente
      window.battleState.opponentSelectedStat = null;
      var indexOpp = window.battleState.opponentUsedStats.indexOf(data.targetStat);
      if (indexOpp !== -1) {
        window.battleState.opponentUsedStats.splice(indexOpp, 1);
      }
      var opponentDisplay = document.querySelector(`.battle-side-opponent .battle-stat-display[data-stat="${data.targetStat}"]`);
      if (opponentDisplay) {
        opponentDisplay.classList.remove('highlighted', 'used');
      }

      var playerAnuloBtn = document.getElementById('player-power-anulo');
      if (playerAnuloBtn) {
        playerAnuloBtn.classList.add('used', 'activating');
        setTimeout(function() { playerAnuloBtn.classList.remove('activating'); }, 600);
      }
      var userNameAnulo = getPlayerDisplayName();
      console.log('[LOG-POWERS] Iniciando animación showPowerActivation para ANULO propio:', userNameAnulo);
      await showPowerActivation('anulo', userNameAnulo, true);
      console.log('[LOG-POWERS] Animación showPowerActivation de ANULO propio terminada. Aplicando visual de bloqueo.');
      applyAnuloVisual(true, data.targetStat);
      console.log('[LOG-POWERS] Efecto de ANULO propio aplicado con éxito');
    } else if (data.powerType === 'intercambio') {
      console.log('[LOG-POWERS] Evento "power-confirmed" recibido para INTERCAMBIO');
      console.log('[LOG-POWERS] Datos recibidos:', data);

      window.battleState.playerIntercambioTransformedCard = data.transformedCard;
      
      // Si la animación de activación ya terminó (y por ende el swap-out), aplicar el intercambio inmediatamente.
      // De lo contrario, se aplicará al finalizar la animación de salida.
      if (window.battleState.playerIntercambioAnimFinished) {
        await applyIntercambioCardSwap(data.transformedCard);
      }
    }
  }

  function handlePowerError(data) {
    showNotification('⚠️ ' + (data.message || 'No se pudo aplicar el poder'), 'warning');

    var powerType = data?.powerType;
    if (!powerType || !window.battleState) return;

    if (powerType === 'swap') {
      var swapBtn = document.getElementById('player-power-swap');
      if (swapBtn) {
        swapBtn.classList.remove('activating');
        if (!window.battleState.playerPowersUsed.swap) {
          swapBtn.disabled = false;
        }
      }
      return;
    }

    if (powerType === 'powerup') {
      if (window.battleState.playerPowersUsed.powerup && !data.success) {
        window.battleState.playerPowersUsed.powerup = false;
        window.battleState.playerPowerUpActive = false;
        var powerBtn = document.getElementById('player-power-powerup');
        if (powerBtn) {
          powerBtn.classList.remove('used', 'activating');
          powerBtn.disabled = false;
        }
        restoreStatsColors('player');
      }
      return;
    }

    if (powerType === 'nerf') {
      if (window.battleState.playerPowersUsed.nerf && !data.success) {
        window.battleState.playerPowersUsed.nerf = false;
        window.battleState.playerNerfActive = false;
        var nerfBtn = document.getElementById('player-power-nerf');
        if (nerfBtn) {
          nerfBtn.classList.remove('used', 'activating');
          nerfBtn.disabled = false;
        }
        restoreStatsColors('opponent');
      }
      return;
    }

    if (powerType === 'anulo') {
      if (window.battleState.playerPowersUsed.anulo && !data.success) {
        window.battleState.playerPowersUsed.anulo = false;
        window.battleState.annulledStat = null;
        var anuloBtn = document.getElementById('player-power-anulo');
        if (anuloBtn) {
          anuloBtn.classList.remove('used', 'activating');
          anuloBtn.disabled = false;
        }
        if (typeof enableStatSelection === 'function') {
          enableStatSelection();
        }
      }
      return;
    }

    if (powerType === 'intercambio') {
      if (window.battleState.playerPowersUsed.intercambio && !data.success) {
        window.battleState.playerPowersUsed.intercambio = false;
        window.battleState.playerIntercambioPending = false;
        window.battleState.playerIntercambioTransformedCard = null;
        window.battleState.playerIntercambioAnimFinished = false;
        var exchangeBtn = document.getElementById('player-power-intercambio');
        if (exchangeBtn) {
          exchangeBtn.classList.remove('used', 'activating');
          exchangeBtn.disabled = false;
        }
        var cardDisplay = document.querySelector('.battle-side-player .battle-card-display');
        if (cardDisplay) {
          cardDisplay.classList.remove('swapping-out', 'swapping-in');
        }
      }
    }
  }

  async function applyIntercambioCardSwap(transformedCard) {
    if (!window.battleState.playerIntercambioPending) return;
    window.battleState.playerIntercambioPending = false;
    
    console.log('[LOG-POWERS] Aplicando cambio de carta de INTERCAMBIO propio con:', transformedCard);
    
    const originalCard = window.battleState.playerCurrentCard;
    var playerCardIndex = -1;
    if (originalCard && window.battleState.playerTeam) {
      playerCardIndex = window.battleState.playerTeam.findIndex(c => 
        (originalCard.uniqueId && c.uniqueId === originalCard.uniqueId) || 
        (originalCard.id && c.id === originalCard.id && (
          (c.nombre && originalCard.nombre && c.nombre === originalCard.nombre) ||
          (c.name && originalCard.name && c.name === originalCard.name) ||
          (!c.nombre && !originalCard.nombre && !c.name && !originalCard.name)
        ))
      );
    }
    
    window.battleState.playerCurrentCard = transformedCard;
    if (playerCardIndex !== -1) {
      window.battleState.playerTeam[playerCardIndex] = transformedCard;
    }
    
    updateBattleCards();
    
    var cardDisplay = document.querySelector('.battle-side-player .battle-card-display');
    if (cardDisplay) {
      cardDisplay.classList.remove('swapping-out');
      cardDisplay.classList.add('swapping-in');
      await new Promise(resolve => setTimeout(resolve, 600));
      cardDisplay.classList.remove('swapping-in');
    }
  }

  window.BattlePowers = BattlePowers;

  function showStatSelectionModal(availableStats) {
    return new Promise(function(resolve) {
      var modal = document.createElement('div');
      modal.className = 'anulo-select-modal-overlay';
      modal.style.cssText = 'position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.85);display:flex;justify-content:center;align-items:center;z-index:10000;backdrop-filter:blur(5px);animation:fadeIn 0.3s ease;';

      var container = document.createElement('div');
      container.className = 'anulo-select-modal-container';
      container.style.cssText = 'background:linear-gradient(135deg, #1a1a2e, #16213e);border:2px solid #ffd700;border-radius:12px;padding:24px;width:90%;max-width:400px;text-align:center;box-shadow:0 0 20px rgba(255,215,0,0.3);';

      var title = document.createElement('h3');
      title.innerText = 'SELECCIONA STAT A ANULAR';
      title.style.cssText = 'color:#ffd700;margin-top:0;margin-bottom:8px;font-size:1.4rem;letter-spacing:1px;text-shadow:0 0 10px rgba(255,215,0,0.5);';

      var subtitle = document.createElement('p');
      subtitle.innerText = 'El rival no podrá elegir esta estadística en este turno.';
      subtitle.style.cssText = 'color:#e0e0e0;font-size:0.9rem;margin-bottom:20px;';

      var grid = document.createElement('div');
      grid.style.cssText = 'display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:20px;';

      availableStats.forEach(function(stat) {
        var btn = document.createElement('button');
        btn.innerText = stat.toUpperCase();
        btn.style.cssText = 'background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.1);color:#fff;padding:12px;border-radius:6px;font-weight:bold;cursor:pointer;transition:all 0.2s ease;';
        
        btn.addEventListener('mouseenter', function() {
          btn.style.background = 'rgba(255,215,0,0.1)';
          btn.style.borderColor = '#ffd700';
        });
        btn.addEventListener('mouseleave', function() {
          btn.style.background = 'rgba(255,255,255,0.05)';
          btn.style.borderColor = 'rgba(255,255,255,0.1)';
        });
        btn.addEventListener('click', function() {
          document.body.removeChild(modal);
          resolve(stat);
        });
        grid.appendChild(btn);
      });

      var cancelBtn = document.createElement('button');
      cancelBtn.innerText = 'CANCELAR';
      cancelBtn.style.cssText = 'background:transparent;border:1px solid #ff4d4d;color:#ff4d4d;padding:8px 16px;border-radius:6px;cursor:pointer;font-weight:bold;transition:all 0.2s ease;';
      
      cancelBtn.addEventListener('mouseenter', function() {
        cancelBtn.style.background = 'rgba(255,77,77,0.1)';
      });
      cancelBtn.addEventListener('mouseleave', function() {
        cancelBtn.style.background = 'transparent';
      });
      cancelBtn.addEventListener('click', function() {
        document.body.removeChild(modal);
        resolve(null);
      });

      container.appendChild(title);
      container.appendChild(subtitle);
      container.appendChild(grid);
      container.appendChild(cancelBtn);
      modal.appendChild(container);
      document.body.appendChild(modal);
    });
  }
})();
