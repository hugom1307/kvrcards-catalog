const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 4317;
// Serve from project root seeds by default
const root = path.join(__dirname, '..', 'seeds');

function sendJson(res, obj) {
  res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  if (url.pathname === '/catalog/manifest.json') {
    // Read version from file if exists, else default timestamp
    const manifestPath = path.join(root, 'manifest.json');
    let manifest = { version: Date.now().toString() };
    try {
      if (fs.existsSync(manifestPath)) manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
    } catch {}
    return sendJson(res, manifest);
  }
  if (url.pathname === '/catalog/cards.json') {
    try {
      const p = path.join(root, 'cards.json');
      const arr = JSON.parse(fs.readFileSync(p, 'utf-8'));
      return sendJson(res, arr);
    } catch (e) {
      res.writeHead(500); res.end('cards error');
      return;
    }
  }
  if (url.pathname === '/catalog/packs.json') {
    try {
      const p = path.join(root, 'packs.json');
      const arr = JSON.parse(fs.readFileSync(p, 'utf-8'));
      return sendJson(res, arr);
    } catch (e) {
      res.writeHead(500); res.end('packs error');
      return;
    }
  }
  if (url.pathname === '/catalog/evolutions.json') {
    try {
      const p = path.join(__dirname, '..', 'game-data', 'evolutions.json');
      const data = JSON.parse(fs.readFileSync(p, 'utf-8'));
      return sendJson(res, data);
    } catch (e) {
      res.writeHead(500); res.end('evolutions error');
      return;
    }
  }
  res.writeHead(404); res.end('Not found');
});

server.listen(PORT, () => {
  console.log(`[catalog-server] Listening on http://localhost:${PORT}/catalog/`);
});
