// ==================== SISTEMA DE NOVEDADES Y ACTUALIZACIONES ====================
// Este sistema carga y muestra el changelog/actualizaciones desde GitHub Pages

const CHANGELOG_URL = 'https://hugom1307.github.io/kvrcards-catalog/changelog.json';

let changelogData = null;

// Inicializar sistema de novedades
document.addEventListener('DOMContentLoaded', function() {
  console.log('[UPDATES] Inicializando sistema de novedades...');
  
  const updatesBtn = document.getElementById('updates-btn');
  const updatesPanel = document.getElementById('updates-panel');
  const updatesClose = document.getElementById('updates-panel-close');
  const updatesOverlay = document.querySelector('.updates-panel-overlay');
  
  if (updatesBtn) {
    updatesBtn.addEventListener('click', openUpdatesPanel);
  }
  
  if (updatesClose) {
    updatesClose.addEventListener('click', closeUpdatesPanel);
  }
  
  if (updatesOverlay) {
    updatesOverlay.addEventListener('click', closeUpdatesPanel);
  }
  
  // Cargar changelog al iniciar (en segundo plano)
  loadChangelog();
});

// Abrir panel de novedades
function openUpdatesPanel() {
  console.log('[UPDATES] Abriendo panel de novedades...');
  const updatesPanel = document.getElementById('updates-panel');
  
  if (updatesPanel) {
    updatesPanel.style.display = 'flex';
    
    // Si no hay datos cargados, intentar cargar
    if (!changelogData) {
      loadChangelog();
    } else {
      renderUpdates();
    }
  }
}

// Cerrar panel de novedades
function closeUpdatesPanel() {
  console.log('[UPDATES] Cerrando panel de novedades...');
  const updatesPanel = document.getElementById('updates-panel');
  
  if (updatesPanel) {
    updatesPanel.style.display = 'none';
  }
}

// Cargar changelog desde GitHub Pages
async function loadChangelog() {
  console.log('[UPDATES] Cargando changelog desde GitHub...');
  
  try {
    const response = await fetch(CHANGELOG_URL + '?t=' + Date.now());
    
    if (!response.ok) {
      throw new Error('No se pudo cargar changelog: ' + response.status);
    }
    
    changelogData = await response.json();
    console.log('[UPDATES] ✅ Changelog cargado:', changelogData);
    
    // Renderizar si el panel está abierto
    const updatesPanel = document.getElementById('updates-panel');
    if (updatesPanel && updatesPanel.style.display !== 'none') {
      renderUpdates();
    }
    
  } catch (error) {
    console.error('[UPDATES] ❌ Error al cargar changelog:', error);
    showUpdatesError();
  }
}

// Renderizar actualizaciones
function renderUpdates() {
  const updatesList = document.getElementById('updates-list');
  
  if (!updatesList) return;
  
  if (!changelogData || !changelogData.updates || changelogData.updates.length === 0) {
    updatesList.innerHTML = `
      <div class="updates-empty">
        <div class="updates-empty-icon">📭</div>
        <p>No hay actualizaciones disponibles</p>
      </div>
    `;
    return;
  }
  
  // Ordenar por fecha (más reciente primero)
  const sortedUpdates = [...changelogData.updates].sort((a, b) => {
    return new Date(b.date) - new Date(a.date);
  });
  
  updatesList.innerHTML = sortedUpdates.map(update => createUpdateHTML(update)).join('');
}

// Crear HTML para una actualización
function createUpdateHTML(update) {
  const date = formatDate(update.date);
  
  let sectionsHTML = '';
  
  // Cartas añadidas
  if (update.cardsAdded && update.cardsAdded.length > 0) {
    sectionsHTML += createSectionHTML('<img src="./icon-oro.png" style="width:18px;height:18px;vertical-align:middle;margin-right:4px;"> Cartas Añadidas', update.cardsAdded, 'card');
  }
  
  // Poderes añadidos
  if (update.powersAdded && update.powersAdded.length > 0) {
    sectionsHTML += createSectionHTML('⚡ Poderes Añadidos', update.powersAdded, 'power');
  }
  
  // Traits añadidos
  if (update.traitsAdded && update.traitsAdded.length > 0) {
    sectionsHTML += createSectionHTML('🎯 Traits Añadidos', update.traitsAdded, 'trait');
  }
  
  // Sobres añadidos
  if (update.packsAdded && update.packsAdded.length > 0) {
    sectionsHTML += createSectionHTML('<img src="./sobre_oro.png" style="width:16px;height:16px;vertical-align:middle;margin-right:4px;object-fit:contain;" alt="Sobre"> Sobres Añadidos', update.packsAdded, 'pack');
  }
  
  return `
    <div class="update-item">
      <div class="update-header">
        <div class="update-version-title">
          <span class="update-version">v${update.version}</span>
          <span class="update-title">${update.title}</span>
        </div>
        <span class="update-date">${date}</span>
      </div>
      
      ${update.description ? `
        <div class="update-description">${update.description}</div>
      ` : ''}
      
      ${sectionsHTML ? `
        <div class="update-content-sections">
          ${sectionsHTML}
        </div>
      ` : ''}
    </div>
  `;
}

// Crear HTML para una sección (cartas, poderes, etc.)
function createSectionHTML(title, items, type) {
  if (!items || items.length === 0) return '';
  
  const itemsHTML = items.map(item => createItemCardHTML(item, type)).join('');
  
  return `
    <div class="update-section">
      <div class="update-section-title">
        ${title}
        <span class="update-section-count">${items.length}</span>
      </div>
      <div class="update-items-grid">
        ${itemsHTML}
      </div>
    </div>
  `;
}

// Crear HTML para un item individual (carta, poder, trait, sobre)
function createItemCardHTML(item, type) {
  const imageUrl = getItemImageUrl(item, type);
  const name = typeof item === 'string' ? item : (item.name || 'Sin nombre');
  
  return `
    <div class="update-item-card" data-type="${type}" data-id="${typeof item === 'string' ? item : item.id}">
      <img src="${imageUrl}" alt="${name}" class="update-item-image" onerror="this.src='./icon-oro.png'">
      <div class="update-item-name">${name}</div>
    </div>
  `;
}

// Obtener URL de imagen según el tipo
function getItemImageUrl(item, type) {
  // Si el item es un objeto con imagen personalizada
  if (typeof item === 'object' && item.imageUrl) {
    return item.imageUrl;
  }
  
  // Si el item es un string (ID), construir la URL
  const itemId = typeof item === 'string' ? item : item.id;
  
  switch (type) {
    case 'card':
      return `./assets/${itemId}.png`;
    case 'power':
      return `./assets/${itemId}.png`;
    case 'trait':
      return `./assets/traits/${itemId}.png`;
    case 'pack':
      return `./assets/packs/${itemId}.png`;
    default:
      return './icon-oro.png';
  }
}

// Formatear fecha
function formatDate(dateString) {
  const date = new Date(dateString);
  const options = { year: 'numeric', month: 'long', day: 'numeric' };
  return date.toLocaleDateString('es-ES', options);
}

// Mostrar error al cargar actualizaciones
function showUpdatesError() {
  const updatesList = document.getElementById('updates-list');
  
  if (!updatesList) return;
  
  updatesList.innerHTML = `
    <div class="updates-empty">
      <div class="updates-empty-icon">⚠️</div>
      <p>Error al cargar las actualizaciones</p>
      <button onclick="loadChangelog()" style="
        margin-top: 16px;
        padding: 8px 16px;
        background: var(--gold);
        color: #0b1220;
        border: none;
        border-radius: 6px;
        font-weight: 600;
        cursor: pointer;
      ">
        Reintentar
      </button>
    </div>
  `;
}

console.log('[UPDATES] ✅ Sistema de novedades cargado');
