// Simple inventory server for viewing and storing users' inventories online
// Now with Cloudflare R2 storage support (S3-compatible)
// Usage: node server/inventory-server.js

const path = require('path');
const fs = require('fs/promises');
const crypto = require('crypto');
const zlib = require('zlib');
const { promisify } = require('util');
const gzipAsync = promisify(zlib.gzip);
const gunzipAsync = promisify(zlib.gunzip);
require('dotenv').config({ path: path.join(__dirname, '.env') });

const express = require('express');
const { S3Client, PutObjectCommand, GetObjectCommand, ListObjectsV2Command, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const http = require('http');
const https = require('https');
const socketIO = require('socket.io');

// Cargar launcher-api con fallback para distintos layouts de deploy
let launcherAPI = null;
try {
  launcherAPI = require('./launcher-api');
} catch (errPrimary) {
  try {
    launcherAPI = require(path.join(__dirname, 'server', 'launcher-api'));
    console.warn('[inventory-server] launcher-api cargado por fallback: ./server/launcher-api');
  } catch (errFallback) {
    console.warn('[inventory-server] launcher-api no encontrado, continuando sin esas rutas');
  }
}

let compression = null;
try {
  compression = require('compression');
} catch (errCompression) {
  console.warn('[inventory-server] compression package not found, continuing without compression');
}

const app = express();
if (compression) {
  app.use(compression());
  console.log('[inventory-server] GZIP compression enabled');
}
const server = http.createServer(app);
// Aumentar límite de payload para soportar imágenes de perfil grandes (hasta 10MB)
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// CORS básico para permitir llamadas desde otros orígenes (apps o navegadores externos)
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// Launcher API routes (si el modulo existe)
if (launcherAPI) {
  app.use(launcherAPI);
}

// Admin password
const ADMIN_PASSWORD = 'kvcard';

// Middleware de autenticación para páginas admin
function requireAuth(req, res, next) {
  const auth = req.headers.authorization || req.query.auth || req.cookies?.adminAuth;
  if (auth === ADMIN_PASSWORD) {
    return next();
  }
  // Si no está autenticado, mostrar página de login
  res.send(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Admin Access Required</title>
<style>
  body { font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background: #f0f0f0; }
  .login-box { background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
  input { padding: 0.75rem; margin: 1rem 0; width: 200px; border: 1px solid #ddd; border-radius: 4px; }
  button { padding: 0.75rem 2rem; background: #0066cc; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 1rem; }
  button:hover { background: #0052a3; }
  h2 { color: #333; margin-bottom: 0.5rem; }
  p { color: #666; margin-top: 0; }
</style>
<script>
  function submitPassword() {
    const pwd = document.getElementById('pwd').value;
    if (pwd) {
      window.location.href = '/?auth=' + encodeURIComponent(pwd);
    }
  }
  document.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') submitPassword();
  });
</script>
</head>
<body>
<div class="login-box">
  <h2>🔒 Admin Access</h2>
  <p>Enter password to access inventory management</p>
  <input type="password" id="pwd" placeholder="Password" autofocus>
  <br>
  <button onclick="submitPassword()">Access</button>
</div>
</body></html>`);
}

// ---- Cloudflare R2 Configuration ----
const R2_ACCOUNT_ID = process.env.R2_ACCOUNT_ID || '';
const R2_ACCESS_KEY_ID = process.env.R2_ACCESS_KEY_ID || '';
const R2_SECRET_ACCESS_KEY = process.env.R2_SECRET_ACCESS_KEY || '';
const R2_BUCKET_NAME = process.env.R2_BUCKET_NAME || 'kvrcards-inventory';
const INFINITE_SEASON_REMOTE_URL = process.env.INFINITE_SEASON_REMOTE_URL || 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/infinite-season.json';
const INFINITE_SEASON_CACHE_MS = Math.max(15000, Number(process.env.INFINITE_SEASON_CACHE_MS) || 120000);

const FALLBACK_INFINITE_SEASON_CONFIG = {
  version: 1,
  season: {
    id: 'season-1',
    name: 'Temporada 1 - Modo Infinito'
  },
  rewards: [
    {
      level: 10,
      rewards: [
        { type: 'currency', currency: 'coins', amount: 5000 },
        { type: 'currency', currency: 'traits', amount: 3 }
      ]
    },
    {
      level: 20,
      rewards: [
        { type: 'currency', currency: 'coins', amount: 10000 },
        { type: 'pack', packId: 'sobre_oro', amount: 3 },
        { type: 'currency', currency: 'traits', amount: 2 }
      ]
    },
    {
      level: 30,
      rewards: [
        { type: 'pack', packId: 'sobre_83_plus', amount: 1 },
        { type: 'currency', currency: 'traits', amount: 5 }
      ]
    },
    {
      level: 40,
      rewards: [
        { type: 'currency', currency: 'coins', amount: 30000 },
        { type: 'pack', packId: 'sobre_83_plus', amount: 2 }
      ]
    },
    {
      level: 50,
      rewards: [
        { type: 'title', titleId: 'conquistador_del_infinito', name: 'Conquistador del Infinito' },
        { type: 'card', cardId: 'carta_exclusiva_infinito', name: 'Carta Exclusiva Infinito' },
        { type: 'currency', currency: 'traits', amount: 10 }
      ]
    },
    {
      level: 60,
      rewards: [
        { type: 'currency', currency: 'traits', amount: 15 }
      ]
    },
    {
      level: 70,
      rewards: [
        { type: 'currency', currency: 'traits', amount: 20 }
      ]
    },
    {
      level: 80,
      rewards: [
        { type: 'pack', packId: 'sobre_85_plus', amount: 1 },
        { type: 'currency', currency: 'coins', amount: 25000 }
      ]
    },
    {
      level: 90,
      rewards: [
        { type: 'currency', currency: 'traits', amount: 25 }
      ]
    },
    {
      level: 100,
      rewards: [
        { type: 'currency', currency: 'coins', amount: 100000 },
        { type: 'pack', packId: 'sobre_especial', amount: 1 }
      ]
    }
  ],
  beyondLevel100: {
    enabled: true,
    startLevel: 101,
    perLevelRewards: [
      { type: 'traits', amount: 1 }
    ]
  }
};

let infiniteSeasonCache = {
  loadedAt: 0,
  data: FALLBACK_INFINITE_SEASON_CONFIG
};

// Initialize S3 Client for R2
let s3Client = null;
if (R2_ACCOUNT_ID && R2_ACCESS_KEY_ID && R2_SECRET_ACCESS_KEY) {
  s3Client = new S3Client({
    region: 'auto',
    endpoint: `https://${R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: R2_ACCESS_KEY_ID,
      secretAccessKey: R2_SECRET_ACCESS_KEY,
    },
  });
  console.log('[inventory-server] R2 storage enabled, bucket:', R2_BUCKET_NAME);
} else {
  console.warn('[inventory-server] R2 not configured - set R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_BUCKET_NAME');
}

function userFileKey(username) {
  const safe = String(username || '').replace(/[^a-zA-Z0-9_-]/g, '_');
  return `users/${safe}.json`;
}

function avatarFileKey(username) {
  const safe = String(username || '').replace(/[^a-zA-Z0-9_-]/g, '_');
  return `avatars/${safe}.json`;
}

function sanitizeInfiniteRunPayload(raw) {
  const data = raw && typeof raw === 'object' ? raw : {};
  const runStats = data.runStats && typeof data.runStats === 'object' ? data.runStats : {};
  const rawRunCardBuffs = data.runCardBuffs && typeof data.runCardBuffs === 'object' ? data.runCardBuffs : {};
  const arcWorldAssignments = data.arcWorldAssignments && typeof data.arcWorldAssignments === 'object'
    ? data.arcWorldAssignments
    : {};

  const runCardBuffs = {};
  Object.entries(rawRunCardBuffs).forEach(([cardId, statMap]) => {
    const safeCardId = String(cardId || '').trim();
    if (!safeCardId || !statMap || typeof statMap !== 'object') return;

    const cleanStats = {};
    Object.entries(statMap).forEach(([statKey, delta]) => {
      const safeStat = String(statKey || '').trim().toLowerCase();
      const safeDelta = Math.max(0, Number(delta) || 0);
      if (!safeStat || safeDelta <= 0) return;
      cleanStats[safeStat] = safeDelta;
    });

    if (Object.keys(cleanStats).length > 0) {
      runCardBuffs[safeCardId] = cleanStats;
    }
  });

  return {
    version: 1,
    savedAt: Date.now(),
    currentFloor: Math.max(1, Number(data.currentFloor) || 1),
    seasonMaxFloor: Math.max(1, Number(data.seasonMaxFloor) || Number(data.currentFloor) || 1),
    initialTeamLocked: !!data.initialTeamLocked,
    runActive: !!data.runActive,
    claimedMilestones: Array.isArray(data.claimedMilestones) ? data.claimedMilestones.map(Number).filter(n => n > 0) : [],
    runDeckIds: Array.isArray(data.runDeckIds) ? data.runDeckIds.map(String) : [],
    runStats: {
      upgrades: Math.max(0, Number(runStats.upgrades) || 0),
      riskEvents: Math.max(0, Number(runStats.riskEvents) || 0),
      shopVisits: Math.max(0, Number(runStats.shopVisits) || 0),
      addedFromOutside: Math.max(0, Number(runStats.addedFromOutside) || 0)
    },
    runCardBuffs,
    selectedInitialCardIds: Array.isArray(data.selectedInitialCardIds) ? data.selectedInitialCardIds.map(String) : [],
    selectedInitialPowerIds: Array.isArray(data.selectedInitialPowerIds) ? data.selectedInitialPowerIds.map(String) : [],
    initialTeamSnapshot: Array.isArray(data.initialTeamSnapshot) ? data.initialTeamSnapshot.map(String) : null,
    initialPowersSnapshot: Array.isArray(data.initialPowersSnapshot) ? data.initialPowersSnapshot.map(String) : null,
    arcWorldAssignments: { ...arcWorldAssignments },
    infiniteCoins: Math.max(0, Math.floor(Number(data.infiniteCoins) || 0)),
    infiniteCardpoints: Math.max(0, Math.floor(Number(data.infiniteCardpoints) || 0))
  };
}

// ---- Cache en memoria para Cloudflare R2 (reduce ancho de banda saliente a prácticamente cero) ----
const r2MemoryCache = new Map(); // key -> { data, timestamp }
const R2_CACHE_TTL_MS = 3 * 60 * 1000; // 3 minutos de validez de caché para lecturas (ahorro de R2)
let userListCache = { users: [], timestamp: 0 };
const USER_LIST_CACHE_TTL_MS = 2 * 60 * 1000; // 2 minutos para el listado general de usuarios

// Helper: Read from R2 con caché en memoria y descompresión transparente
async function readFromR2(key, forceFresh = false) {
  if (!s3Client) throw new Error('R2 not configured');

  // 1. Comprobar caché en memoria si no se fuerza lectura fresca
  if (!forceFresh && r2MemoryCache.has(key)) {
    const cached = r2MemoryCache.get(key);
    if (Date.now() - cached.timestamp < R2_CACHE_TTL_MS) {
      return cached.data;
    }
  }

  try {
    const command = new GetObjectCommand({
      Bucket: R2_BUCKET_NAME,
      Key: key,
    });
    const response = await s3Client.send(command);

    // Leer chunks de bytes para soportar tanto gzip como texto plano
    const byteChunks = [];
    for await (const chunk of response.Body) {
      byteChunks.push(chunk);
    }
    let buffer = Buffer.concat(byteChunks);

    // Detectar si está comprimido en GZIP (Content-Encoding o magic bytes 0x1f 0x8b)
    if (response.ContentEncoding === 'gzip' || (buffer.length >= 2 && buffer[0] === 0x1f && buffer[1] === 0x8b)) {
      buffer = await gunzipAsync(buffer);
    }

    const str = buffer.toString('utf-8');
    const parsed = JSON.parse(str);

    // Guardar en caché
    r2MemoryCache.set(key, { data: parsed, timestamp: Date.now() });
    return parsed;
  } catch (err) {
    if (err.name === 'NoSuchKey' || err.$metadata?.httpStatusCode === 404) {
      r2MemoryCache.set(key, { data: null, timestamp: Date.now() });
      return null; // File doesn't exist
    }
    // Si falla la red de R2 pero teníamos datos previos en caché, devolverlos como fallback
    if (r2MemoryCache.has(key)) {
      return r2MemoryCache.get(key).data;
    }
    throw err;
  }
}

// Helper: Write to R2 con actualización inmediata de caché, JSON minificado y compresión GZIP
async function writeToR2(key, data) {
  if (!s3Client) throw new Error('R2 not configured');

  // Actualizar caché en memoria inmediatamente para que las siguientes lecturas no vayan a R2
  r2MemoryCache.set(key, { data, timestamp: Date.now() });

  // Invalidar caché de listado de usuarios por si es un usuario nuevo
  userListCache.timestamp = 0;

  // Optimización 1 y 2: JSON minificado (sin espacios ni saltos de línea inútiles) y comprimido en GZIP
  const minifiedJson = JSON.stringify(data);
  const compressed = await gzipAsync(Buffer.from(minifiedJson, 'utf-8'));

  const command = new PutObjectCommand({
    Bucket: R2_BUCKET_NAME,
    Key: key,
    Body: compressed,
    ContentType: 'application/json',
    ContentEncoding: 'gzip',
  });
  await s3Client.send(command);
}

// Helper: List all users from R2 con caché en memoria
async function listUsersFromR2(forceFresh = false) {
  if (!s3Client) throw new Error('R2 not configured');

  if (!forceFresh && userListCache.users.length > 0 && (Date.now() - userListCache.timestamp < USER_LIST_CACHE_TTL_MS)) {
    return userListCache.users;
  }

  try {
    const command = new ListObjectsV2Command({
      Bucket: R2_BUCKET_NAME,
      Prefix: 'users/',
    });
    const response = await s3Client.send(command);
    const users = (response.Contents || [])
      .map(obj => obj.Key.replace('users/', '').replace('.json', ''))
      .filter(u => u.length > 0);

    userListCache = { users, timestamp: Date.now() };
    return users;
  } catch (err) {
    console.error('[R2] Error listing users:', err);
    return userListCache.users || [];
  }
}

// Helper: Delete user from R2
async function deleteFromR2(key) {
  if (!s3Client) throw new Error('R2 not configured');
  r2MemoryCache.delete(key);
  userListCache.timestamp = 0;
  const { DeleteObjectCommand } = require('@aws-sdk/client-s3');
  const command = new DeleteObjectCommand({
    Bucket: R2_BUCKET_NAME,
    Key: key,
  });
  await s3Client.send(command);
}

// ---- Catálogo (para resolver IDs -> nombres) ----
const CATALOG_BASE_URL = process.env.CATALOG_BASE_URL || '';
let catalogIndex = { cards: {}, packs: {}, lastLoaded: 0 };

function ensureSlash(u) { return u.endsWith('/') ? u : u + '/'; }

function fetchJson(url) {
  const lib = url.startsWith('https') ? https : http;
  return new Promise((resolve, reject) => {
    const req = lib.get(url, (res) => {
      if (res.statusCode < 200 || res.statusCode >= 300) {
        return reject(new Error('HTTP ' + res.statusCode));
      }
      let data = '';
      res.on('data', (c) => data += c.toString('utf-8'));
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } });
    });
    req.on('error', reject);
  });
}

// ---- Pools de Draft y Carga de Catálogos (Fase de Elección) ----
let draftCardsPool = [];
let draftTraitsPool = [];
let draftPacksPool = [];
let draftTitlesPool = [];

async function loadDraftCatalog() {
  // Fetch cards
  try {
    console.log('[DRAFT-CATALOG] Cargando cartas desde GitHub remoto...');
    const rawCards = await fetchJson('https://hugom1307.github.io/kvrcards-catalog/cards.json');
    const isEvoCard = c => {
      const q = String(c.calidad || c.quality || c.calidadId || '').trim().toLowerCase();
      return q === 'evo';
    };
    draftCardsPool = Array.isArray(rawCards) ? rawCards.filter(c => !isEvoCard(c)) : [];
    console.log(`[DRAFT-CATALOG] ✅ ${draftCardsPool.length} cartas cargadas desde remoto (sin Evo).`);
  } catch (e) {
    console.error('[DRAFT-CATALOG] ❌ Error cargando cartas desde GitHub remoto, usando local fallback:', e.message);
    try {
      const localCardsPath = fs.existsSync(path.join(__dirname, '../seeds/catalog.json')) 
        ? path.join(__dirname, '../seeds/catalog.json') 
        : path.join(__dirname, '../game-data/cards.json');
      if (fs.existsSync(localCardsPath)) {
        const localCards = JSON.parse(fs.readFileSync(localCardsPath, 'utf-8'));
        const isEvoCard = c => {
          const q = String(c.calidad || c.quality || c.calidadId || '').trim().toLowerCase();
          return q === 'evo';
        };
        draftCardsPool = Array.isArray(localCards) ? localCards.filter(c => !isEvoCard(c)) : [];
        console.log(`[DRAFT-CATALOG] ✅ ${draftCardsPool.length} cartas cargadas de fallback local (sin Evo).`);
      }
    } catch (err) {
      console.error('[DRAFT-CATALOG] ❌ Fallo crítico al cargar fallback de cartas:', err.message);
    }
  }

  // Fetch traits
  try {
    console.log('[DRAFT-CATALOG] Cargando traits desde GitHub remoto...');
    const traitsData = await fetchJson('https://hugom1307.github.io/kvrcards-catalog/traits.json');
    draftTraitsPool = traitsData.traits || [];
    console.log(`[DRAFT-CATALOG] ✅ ${draftTraitsPool.length} traits cargados desde remoto.`);
  } catch (e) {
    console.error('[DRAFT-CATALOG] ❌ Error cargando traits desde GitHub remoto, usando local fallback:', e.message);
    try {
      const localTraitsPath = fs.existsSync(path.join(__dirname, '../seeds/traits.json'))
        ? path.join(__dirname, '../seeds/traits.json')
        : path.join(__dirname, 'seeds/traits.json');
      if (fs.existsSync(localTraitsPath)) {
        const localData = JSON.parse(fs.readFileSync(localTraitsPath, 'utf-8'));
        draftTraitsPool = localData.traits || [];
        console.log(`[DRAFT-CATALOG] ✅ ${draftTraitsPool.length} traits cargados de fallback local.`);
      }
    } catch (err) {
      console.error('[DRAFT-CATALOG] ❌ Fallo crítico al cargar fallback de traits:', err.message);
    }
  }

  // Fetch packs
  try {
    console.log('[DRAFT-CATALOG] Cargando packs desde GitHub remoto...');
    const rawPacks = await fetchJson('https://hugom1307.github.io/kvrcards-catalog/packs.json');
    if (Array.isArray(rawPacks)) {
      draftPacksPool = rawPacks;
    } else if (rawPacks && typeof rawPacks === 'object' && Array.isArray(rawPacks.packs)) {
      draftPacksPool = rawPacks.packs;
    }
    console.log(`[DRAFT-CATALOG] ✅ ${draftPacksPool.length} packs cargados desde remoto.`);
  } catch (e) {
    console.warn('[DRAFT-CATALOG] Error cargando packs desde remoto, usando local fallback:', e.message);
    try {
      const localPacksPath = fs.existsSync(path.join(__dirname, '../game-data/packs.json'))
        ? path.join(__dirname, '../game-data/packs.json')
        : (fs.existsSync(path.join(__dirname, 'game-data/packs.json')) ? path.join(__dirname, 'game-data/packs.json') : null);
      if (localPacksPath && fs.existsSync(localPacksPath)) {
        draftPacksPool = JSON.parse(fs.readFileSync(localPacksPath, 'utf-8'));
        console.log(`[DRAFT-CATALOG] ✅ ${draftPacksPool.length} packs cargados de fallback local.`);
      }
    } catch (err) {
      console.warn('[DRAFT-CATALOG] Fallo cargando packs locales:', err.message);
    }
  }

  // Fetch titles
  try {
    console.log('[DRAFT-CATALOG] Cargando titles desde GitHub remoto...');
    const rawTitles = await fetchJson('https://hugom1307.github.io/kvrcards-catalog/titles.json');
    if (Array.isArray(rawTitles)) {
      draftTitlesPool = rawTitles;
    } else if (rawTitles && typeof rawTitles === 'object' && Array.isArray(rawTitles.titles)) {
      draftTitlesPool = rawTitles.titles;
    }
    console.log(`[DRAFT-CATALOG] ✅ ${draftTitlesPool.length} titles cargados desde remoto.`);
  } catch (e) {
    console.warn('[DRAFT-CATALOG] Error cargando titles desde remoto, usando local fallback:', e.message);
  }
  if (!Array.isArray(draftTitlesPool) || draftTitlesPool.length === 0) {
    try {
      const localTitlesPath = fs.existsSync(path.join(__dirname, '../seeds/titles.json'))
        ? path.join(__dirname, '../seeds/titles.json')
        : (fs.existsSync(path.join(__dirname, 'seeds/titles.json')) ? path.join(__dirname, 'seeds/titles.json') : null);
      if (localTitlesPath && fs.existsSync(localTitlesPath)) {
        draftTitlesPool = JSON.parse(fs.readFileSync(localTitlesPath, 'utf-8'));
        console.log(`[DRAFT-CATALOG] ✅ ${draftTitlesPool.length} titles cargados de fallback local.`);
      }
    } catch (err) {
      console.warn('[DRAFT-CATALOG] Fallo cargando titles locales:', err.message);
    }
  }
}

// Inicializar carga
loadDraftCatalog();
// Recargar cada hora
setInterval(loadDraftCatalog, 60 * 60 * 1000);

function normalizeInfiniteSeasonConfig(raw) {
  const source = raw && typeof raw === 'object' ? raw : {};
  const sourceSeason = source.season && typeof source.season === 'object' ? source.season : {};
  const rawSeasonId = String(sourceSeason.id || source.seasonId || '').trim();
  const seasonId = rawSeasonId || 'season-default';
  const seasonName = String(sourceSeason.name || source.name || `Temporada ${seasonId}`).trim() || `Temporada ${seasonId}`;
  const seasonVersion = Number(source.version) || 1;

  const rawRewards = Array.isArray(source.rewards) ? source.rewards : [];
  const rewards = rawRewards
    .map((entry) => {
      const level = Math.max(1, Number(entry?.level) || 0);
      if (!level) return null;

      let rewardItems = [];
      if (Array.isArray(entry?.rewards)) {
        rewardItems = entry.rewards
          .map((reward) => {
            const rewardType = String(reward?.type || '').trim().toLowerCase();

            if (['coins', 'traits', 'kvr', 'infinite-coins', 'infinite-cardpoints'].includes(rewardType)) {
              const amount = Math.max(0, Number(reward?.amount) || 0);
              if (amount <= 0) return null;
              return {
                type: 'currency',
                currency: rewardType,
                amount
              };
            }

            if (!rewardType || rewardType === 'currency') {
              const currency = String(reward?.currency || '').trim();
              const amount = Math.max(0, Number(reward?.amount) || 0);
              if (!currency || amount <= 0) return null;
              return {
                type: 'currency',
                currency,
                amount
              };
            }

            if (rewardType === 'pack' || rewardType === 'packs') {
              const packId = String(reward?.packId || reward?.id || '').trim();
              const amount = Math.max(1, Number(reward?.amount || reward?.count) || 0);
              if (!packId || amount <= 0) return null;
              return {
                type: 'pack',
                packId,
                amount
              };
            }

            if (rewardType === 'card' || rewardType === 'cards') {
              const cardId = String(reward?.cardId || reward?.id || '').trim();
              const amount = Math.max(1, Number(reward?.amount || reward?.count) || 0);
              if (!cardId || amount <= 0) return null;
              return {
                type: 'card',
                cardId,
                amount
              };
            }

            if (rewardType === 'title' || rewardType === 'titles') {
              const titleId = String(reward?.titleId || reward?.id || '').trim();
              if (!titleId) return null;
              return {
                type: 'title',
                titleId,
                name: reward?.name || titleId
              };
            }

            return null;
          })
          .filter(Boolean);
      }

      if (rewardItems.length === 0 && entry?.reward && typeof entry.reward === 'object') {
        rewardItems = Object.entries(entry.reward)
          .map(([currency, amount]) => {
            const safeCurrency = String(currency || '').trim();
            const safeAmount = Math.max(0, Number(amount) || 0);
            if (!safeCurrency || safeAmount <= 0) return null;
            return {
              type: 'currency',
              currency: safeCurrency,
              amount: safeAmount
            };
          })
          .filter(Boolean);
      }

      return {
        level,
        rewards: rewardItems
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.level - b.level);

  return {
    version: seasonVersion,
    season: {
      id: seasonId,
      name: seasonName
    },
    rewards: rewards.length > 0 ? rewards : FALLBACK_INFINITE_SEASON_CONFIG.rewards,
    beyondLevel100: source.beyondLevel100 || FALLBACK_INFINITE_SEASON_CONFIG.beyondLevel100
  };
}

function getSeasonRankingKey(seasonConfig) {
  const version = Number(seasonConfig?.version) || 1;
  return `v${version}`;
}

async function getInfiniteSeasonConfig() {
  const now = Date.now();
  if ((now - infiniteSeasonCache.loadedAt) < INFINITE_SEASON_CACHE_MS && infiniteSeasonCache.data) {
    return infiniteSeasonCache.data;
  }

  try {
    const remote = await fetchJson(`${INFINITE_SEASON_REMOTE_URL}?t=${now}`);
    const normalized = normalizeInfiniteSeasonConfig(remote);
    infiniteSeasonCache = {
      loadedAt: now,
      data: normalized
    };
    return normalized;
  } catch (error) {
    console.warn('[INFINITE SEASON] No se pudo cargar config remota, usando cache/fallback:', error?.message || error);
    if (!infiniteSeasonCache.data) {
      infiniteSeasonCache = {
        loadedAt: now,
        data: FALLBACK_INFINITE_SEASON_CONFIG
      };
    } else {
      infiniteSeasonCache.loadedAt = now;
    }
    return infiniteSeasonCache.data;
  }
}

function getInfiniteCombatFloorFromNode(floor) {
  const safeFloor = Math.max(1, Number(floor) || 1);
  const arcIndex = Math.floor((safeFloor - 1) / 13);
  const relativeNode = ((safeFloor - 1) % 13) + 1;

  let localCombat = 1;
  if (relativeNode <= 4) localCombat = relativeNode;
  else if (relativeNode === 5) localCombat = 4;
  else if (relativeNode <= 10) localCombat = relativeNode - 1;
  else if (relativeNode === 11) localCombat = 9;
  else localCombat = 10;

  return Math.max(0, (arcIndex * 10) + localCombat);
}

function normalizeInfiniteScoreFromRun(run) {
  const currentFloor = Math.max(1, Number(run?.currentFloor) || 1);
  const maxFloor = Math.max(currentFloor, Number(run?.seasonMaxFloor) || 1);
  const combatFloor = getInfiniteCombatFloorFromNode(maxFloor);
  // Score oficial: pisos superados reales, sin contar nodos de decisión o recompensa.
  return Math.max(0, combatFloor - 1);
}

function ensureInfiniteRankingsShape(raw) {
  const data = raw && typeof raw === 'object' ? raw : {};
  const rawSeasonMap = data.seasonBestById && typeof data.seasonBestById === 'object'
    ? data.seasonBestById
    : {};

  const seasonBestById = {};
  Object.entries(rawSeasonMap).forEach(([seasonId, score]) => {
    const safeSeasonId = String(seasonId || '').trim();
    const safeScore = Math.max(0, Number(score) || 0);
    if (!safeSeasonId) return;
    seasonBestById[safeSeasonId] = safeScore;
  });

  return {
    historicalBest: Math.max(0, Number(data.historicalBest) || 0),
    seasonBestById,
    lastSeasonId: String(data.lastSeasonId || '').trim(),
    updatedAt: Math.max(0, Number(data.updatedAt) || 0)
  };
}

function updateUserInfiniteRankingsFromRun(userData, run, seasonId) {
  if (userData && (userData.isAdmin === true || userData.role === 'admin')) {
    return userData.infiniteRankings || {};
  }
  const normalized = ensureInfiniteRankingsShape(userData?.infiniteRankings);
  const score = normalizeInfiniteScoreFromRun(run);

  normalized.historicalBest = Math.max(normalized.historicalBest, score);
  if (seasonId) {
    const currentSeasonBest = Math.max(0, Number(normalized.seasonBestById[seasonId]) || 0);
    normalized.seasonBestById[seasonId] = Math.max(currentSeasonBest, score);
    normalized.lastSeasonId = seasonId;
  }
  normalized.updatedAt = Date.now();

  userData.infiniteRankings = normalized;
  return normalized;
}

let infiniteRankingsCache = { rankings: null, userPayloads: null, seasonConfig: null, seasonKey: null, seasonalSorted: null, historicalSorted: null, timestamp: 0 };
const INFINITE_RANKINGS_CACHE_TTL_MS = 4 * 60 * 1000; // 4 minutos para evitar lecturas masivas en R2

async function buildInfiniteRankingsOverview(username, limit) {
  const safeLimit = Math.min(50, Math.max(1, Number(limit) || 5));
  const now = Date.now();

  let seasonConfig, seasonKey, userPayloads, seasonalSorted, historicalSorted;

  if (infiniteRankingsCache.rankings && (now - infiniteRankingsCache.timestamp < INFINITE_RANKINGS_CACHE_TTL_MS)) {
    seasonConfig = infiniteRankingsCache.seasonConfig;
    seasonKey = infiniteRankingsCache.seasonKey;
    userPayloads = infiniteRankingsCache.userPayloads;
    seasonalSorted = infiniteRankingsCache.seasonalSorted;
    historicalSorted = infiniteRankingsCache.historicalSorted;
  } else {
    seasonConfig = await getInfiniteSeasonConfig();
    seasonKey = getSeasonRankingKey(seasonConfig);

    const users = await listUsersFromR2();
    userPayloads = await Promise.all(users.map((u) => readFromR2(userFileKey(u)).catch(() => null)));

    const rankings = userPayloads
      .filter((entry) => entry && typeof entry === 'object' && !entry.isAdmin && entry.role !== 'admin')
      .map((entry) => {
        const inf = ensureInfiniteRankingsShape(entry.infiniteRankings);

        return {
          username: String(entry.username || '').trim(),
          historicalScore: inf.historicalBest,
          seasonalScore: Math.max(0, Number(inf.seasonBestById[seasonKey]) || 0)
        };
      })
      .filter((entry) => !!entry.username);

    const sortDesc = (a, b, scoreKey) => {
      const diff = (Number(b[scoreKey]) || 0) - (Number(a[scoreKey]) || 0);
      if (diff !== 0) return diff;
      return String(a.username || '').localeCompare(String(b.username || ''));
    };

    seasonalSorted = [...rankings].sort((a, b) => sortDesc(a, b, 'seasonalScore'));
    historicalSorted = [...rankings].sort((a, b) => sortDesc(a, b, 'historicalScore'));

    infiniteRankingsCache = {
      rankings,
      userPayloads,
      seasonConfig,
      seasonKey,
      seasonalSorted,
      historicalSorted,
      timestamp: now
    };
  }

  const normalizedUsername = String(username || '').trim().toLowerCase();
  const requesterPayload = userPayloads.find((p) => String(p?.username || '').trim().toLowerCase() === normalizedUsername);
  const isRequesterAdmin = Boolean(requesterPayload && (requesterPayload.isAdmin === true || requesterPayload.role === 'admin'));

  const seasonalIndex = (!isRequesterAdmin && normalizedUsername)
    ? seasonalSorted.findIndex((entry) => String(entry.username || '').trim().toLowerCase() === normalizedUsername)
    : -1;
  const historicalIndex = (!isRequesterAdmin && normalizedUsername)
    ? historicalSorted.findIndex((entry) => String(entry.username || '').trim().toLowerCase() === normalizedUsername)
    : -1;

  return {
    ok: true,
    scoreFormula: 'clearedFloors = max(0, combatFloor - 1)',
    rankingResetRule: 'season resets when infinite-season.json version changes',
    season: seasonConfig.season,
    seasonVersion: Number(seasonConfig?.version) || 1,
    seasonRankingKey: seasonKey,
    rewards: Array.isArray(seasonConfig.rewards) ? seasonConfig.rewards : [],
    topSeasonal: seasonalSorted.slice(0, safeLimit).map((entry, index) => ({
      rank: index + 1,
      username: entry.username,
      score: entry.seasonalScore
    })),
    topHistorical: historicalSorted.slice(0, safeLimit).map((entry, index) => ({
      rank: index + 1,
      username: entry.username,
      score: entry.historicalScore
    })),
    you: {
      username: String(username || '').trim(),
      isAdmin: isRequesterAdmin,
      seasonalRank: isRequesterAdmin ? null : (seasonalIndex >= 0 ? seasonalIndex + 1 : null),
      seasonalScore: isRequesterAdmin ? 0 : (seasonalIndex >= 0 ? seasonalSorted[seasonalIndex].seasonalScore : 0),
      historicalRank: isRequesterAdmin ? null : (historicalIndex >= 0 ? historicalIndex + 1 : null),
      historicalScore: isRequesterAdmin ? 0 : (historicalIndex >= 0 ? historicalSorted[historicalIndex].historicalScore : 0),
      inTopSeasonal: !isRequesterAdmin && seasonalIndex >= 0 && seasonalIndex < safeLimit,
      inTopHistorical: !isRequesterAdmin && historicalIndex >= 0 && historicalIndex < safeLimit
    }
  };
}

let generalRankingsCache = { data: null, timestamp: 0 };
const GENERAL_RANKINGS_CACHE_TTL_MS = 4 * 60 * 1000; // 4 minutos para evitar lecturas masivas en R2

async function buildGeneralRankings() {
  const now = Date.now();
  if (generalRankingsCache.data && (now - generalRankingsCache.timestamp < GENERAL_RANKINGS_CACHE_TTL_MS)) {
    return generalRankingsCache.data;
  }

  const users = await listUsersFromR2();
  const userPayloads = await Promise.all(users.map(u => readFromR2(userFileKey(u)).catch(() => null)));
  const validUsers = userPayloads.filter(entry => entry && typeof entry === 'object' && !entry.isAdmin && entry.role !== 'admin');

  const currentDate = new Date();
  const dayOfWeek = currentDate.getDay();
  const currentMonday = new Date(currentDate);
  const diff = (dayOfWeek === 0 ? -6 : 1) - dayOfWeek;
  currentMonday.setDate(currentDate.getDate() + diff);
  currentMonday.setHours(0, 0, 0, 0);
  const currentMondayTimestamp = currentMonday.getTime();

  const getEffectiveWeekly = (entry, cat) => {
    const ws = entry.weeklyStats;
    if (!ws || (ws.weekStart && ws.weekStart < currentMondayTimestamp)) return 0;
    return Math.max(0, Number(ws[cat]) || 0);
  };

  const mapUser = (u, val) => ({
    username: String(u.username || '').trim(),
    currentTitle: u.currentTitle || '',
    value: val
  });

  const sortTop = (arr) => [...arr].sort((a, b) => ((Number(b.value) || 0) - (Number(a.value) || 0)) || a.username.localeCompare(b.username)).slice(0, 10);

  const result = {
    ok: true,
    timestamp: now,
    weekly: {
      cards: sortTop(validUsers.map(u => mapUser(u, getEffectiveWeekly(u, 'cards')))),
      packs: sortTop(validUsers.map(u => mapUser(u, getEffectiveWeekly(u, 'packs')))),
      coins: sortTop(validUsers.map(u => mapUser(u, getEffectiveWeekly(u, 'coins'))))
    },
    historical: {
      cards: sortTop(validUsers.map(u => mapUser(u, Math.max(0, Number(u.stats?.totalCardsObtained) || 0)))),
      packs: sortTop(validUsers.map(u => mapUser(u, Math.max(0, Number(u.stats?.totalPacksOpened) || 0)))),
      coins: sortTop(validUsers.map(u => mapUser(u, Math.max(0, Number(u.stats?.totalCoinsEarned) || 0))))
    }
  };

  generalRankingsCache = { data: result, timestamp: now };
  return result;
}

async function loadCatalogIndex() {
  if (!CATALOG_BASE_URL) return;
  try {
    const base = ensureSlash(CATALOG_BASE_URL);
    const [cardsArr, packsArr] = await Promise.all([
      fetchJson(base + 'cards.json').catch(() => []),
      fetchJson(base + 'packs.json').catch(() => []),
    ]);
    const cardMap = {};
    if (Array.isArray(cardsArr)) {
      cardsArr.forEach((c, idx) => {
        const id = c && c.id ? String(c.id) : ('idx-' + idx);
        const name = c && c.name ? String(c.name) : ('Carta ' + idx);
        cardMap[id] = name;
      });
    }
    const packMap = {};
    const packDefs = Array.isArray(packsArr)
      ? packsArr
      : (packsArr && typeof packsArr === 'object' && Array.isArray(packsArr.packs) ? packsArr.packs : []);
    if (Array.isArray(packDefs)) {
      packDefs.forEach((p, idx) => {
        const id = p && p.id ? String(p.id) : ('pack-' + idx);
        const name = p && p.name ? String(p.name) : ('Pack ' + idx);
        packMap[id] = name;
      });
    }
    catalogIndex.cards = cardMap;
    catalogIndex.packs = packMap;
    catalogIndex.lastLoaded = Date.now();
  } catch (e) {
    // no-op
  }
}

if (CATALOG_BASE_URL) {
  loadCatalogIndex();
  setInterval(loadCatalogIndex, 5 * 60 * 1000);
}

function expandInventory(base) {
  const cards = Object.keys(base.cards || {}).map(id => ({
    id,
    count: Number(base.cards[id]) || 0,
    name: catalogIndex.cards[id] || id
  }));
  const packs = Object.keys(base.packs || {}).map(id => ({
    id,
    count: Number(base.packs[id]) || 0,
    name: catalogIndex.packs[id] || id
  }));
  return {
    ...base,
    cardsExpanded: cards,
    packsExpanded: packs
  };
}

// ---- Helper function para reset semanal ----

function getCurrentMondayTimestamp() {
  const now = new Date();
  const dayOfWeek = now.getDay(); // 0 = Domingo, 1 = Lunes, etc.
  const currentMonday = new Date(now);
  
  // Calcular el lunes de esta semana
  const diff = (dayOfWeek === 0 ? -6 : 1) - dayOfWeek;
  currentMonday.setDate(now.getDate() + diff);
  currentMonday.setHours(0, 0, 0, 0);
  
  return currentMonday.getTime();
}

function shouldResetWeeklyStats(weekStart) {
  if (!weekStart) return true;
  const currentMonday = getCurrentMondayTimestamp();
  return weekStart < currentMonday;
}

function resetWeeklyStatsIfNeeded(userData) {
  if (!userData.weeklyStats) {
    console.log('[WEEKLY RESET] User', userData.username, '- No weeklyStats, initializing...');
    userData.weeklyStats = { cards: 0, packs: 0, coins: 0, weekStart: getCurrentMondayTimestamp() };
    return true;
  }
  
  const currentMonday = getCurrentMondayTimestamp();
  console.log('[WEEKLY RESET] Checking user', userData.username);
  console.log('[WEEKLY RESET] - weekStart:', userData.weeklyStats.weekStart, '(', new Date(userData.weeklyStats.weekStart).toISOString(), ')');
  console.log('[WEEKLY RESET] - currentMonday:', currentMonday, '(', new Date(currentMonday).toISOString(), ')');
  console.log('[WEEKLY RESET] - Current stats:', JSON.stringify(userData.weeklyStats));
  
  if (shouldResetWeeklyStats(userData.weeklyStats.weekStart)) {
    console.log('[WEEKLY RESET] ✅ RESETTING stats for user:', userData.username);
    console.log('[WEEKLY RESET] - Old stats:', JSON.stringify(userData.weeklyStats));
    userData.weeklyStats = {
      cards: 0,
      packs: 0,
      coins: 0,
      weekStart: currentMonday
    };
    console.log('[WEEKLY RESET] - New stats:', JSON.stringify(userData.weeklyStats));
    return true;
  }
  
  console.log('[WEEKLY RESET] ❌ No reset needed for user:', userData.username);
  return false;
}

// ---- Autenticacion Remota (Login y Registro) ----

function hashPassword(password) {
  return crypto.createHash('sha256').update(String(password || '')).digest('hex');
}

app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body || {};
  const uname = String(username || '').trim();
  const pwd = String(password || '').trim();

  if (!uname || !pwd) {
    return res.status(400).json({ ok: false, error: 'Usuario y contrasena requeridos' });
  }

  try {
    const key = userFileKey(uname);
    const user = await readFromR2(key);

    if (!user) {
      return res.status(404).json({ ok: false, error: 'Usuario no encontrado' });
    }

    const storedPwd = user.password ? String(user.password).trim() : '';
    const hashedInput = hashPassword(pwd);

    const isMatch = !storedPwd || storedPwd === pwd || storedPwd === hashedInput;
    if (!isMatch) {
      return res.status(401).json({ ok: false, error: 'Contrasena incorrecta' });
    }

    if (!storedPwd) {
      user.password = pwd;
      try {
        await writeToR2(key, user);
        console.log('[AUTH LOGIN] Contrasena inicial guardada para:', uname);
      } catch (saveErr) {
        console.warn('[AUTH LOGIN] No se pudo actualizar contrasena inicial:', saveErr.message);
      }
    }

    console.log('[AUTH LOGIN] Sesion iniciada correctamente para:', uname);
    return res.json({
      ok: true,
      username: uname,
      isAdmin: Boolean(user.isAdmin),
      lastSync: user.updatedAt || Date.now(),
      isReset: Boolean(user.isReset),
      resetAt: Number(user.resetAt) || 0
    });
  } catch (e) {
    console.error('[AUTH LOGIN] Error:', e);
    return res.status(500).json({ ok: false, error: 'Error del servidor al iniciar sesion' });
  }
});

app.post('/api/auth/register', async (req, res) => {
  const { username, password } = req.body || {};
  const uname = String(username || '').trim();
  const pwd = String(password || '').trim();

  if (!uname || !pwd) {
    return res.status(400).json({ ok: false, error: 'Usuario y contrasena requeridos' });
  }

  if (uname.length < 3) {
    return res.status(400).json({ ok: false, error: 'El usuario debe tener al menos 3 caracteres' });
  }

  if (pwd.length < 4) {
    return res.status(400).json({ ok: false, error: 'La contrasena debe tener al menos 4 caracteres' });
  }

  if (!/^[a-zA-Z0-9_\-\.]+$/.test(uname)) {
    return res.status(400).json({ ok: false, error: 'El usuario solo puede contener letras, numeros, puntos, guiones y guiones bajos' });
  }

  try {
    const key = userFileKey(uname);
    const existing = await readFromR2(key);

    if (existing) {
      return res.status(409).json({ ok: false, error: 'El usuario ya existe. Si es tu cuenta, inicia sesion.' });
    }

    const newUser = {
      username: uname,
      password: pwd,
      cards: {},
      packs: {},
      cardTraits: {},
      cardUpgrades: {},
      wallet: { coins: 0, kvr: 0, traits: 0, 'infinite-coins': 0, 'infinite-cardpoints': 0 },
      stats: { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0, battlesWon: 0 },
      weeklyStats: { cards: 0, packs: 0, coins: 0, weekStart: getCurrentMondayTimestamp() },
      profileImage: '',
      currentTitle: 'Novato',
      unlockedTitles: ['novato'],
      currentBackground: 'default',
      unlockedBackgrounds: ['default'],
      showcaseCards: [null, null, null],
      friends: [],
      friendRequests: [],
      sentRequests: [],
      missions: {},
      settings: {
        theme: { active: 'default', customTheme: null }
      },
      powers: {},
      completedDeliverables: [],
      deliverableCompletions: {},
      deliverableDailyCompletions: {},
      packPurchases: {},
      redeemedCodes: [],
      supporterBlessing: null,
      isAdmin: false,
      resetAt: Date.now(),
      isReset: false,
      updatedAt: Date.now()
    };

    await writeToR2(key, newUser);
    console.log('[AUTH REGISTER] Usuario registrado correctamente en R2:', uname);
    return res.json({ ok: true, username: uname });
  } catch (e) {
    console.error('[AUTH REGISTER] Error:', e);
    return res.status(500).json({ ok: false, error: 'Error del servidor al registrar' });
  }
});

// ---- Endpoints ----

// Cache en memoria para avatares (reduce lecturas R2 y uso de ancho de banda)
const avatarBufferCache = new Map(); // username -> { buffer, contentType, etag, timestamp }
const AVATAR_CACHE_MAX_AGE = 86400; // 24 horas en segundos

app.get('/api/avatar/:username', async (req, res) => {
  const username = String(req.params.username || '').trim();
  if (!username) {
    return res.redirect('https://api.dicebear.com/7.x/avataaars/svg?seed=default');
  }

  // 1. Revisar caché en memoria
  const cached = avatarBufferCache.get(username);
  if (cached && (Date.now() - cached.timestamp < 3600000)) { // 1 hora fresca en memoria
    if (req.headers['if-none-match'] === cached.etag) {
      return res.status(304).end();
    }
    res.set({
      'Content-Type': cached.contentType,
      'Cache-Control': `public, max-age=${AVATAR_CACHE_MAX_AGE}, stale-while-revalidate=604800`,
      'ETag': cached.etag
    });
    return res.send(cached.buffer);
  }

  try {
    // 2. Intentar leer avatar aislado en avatars/<username>.json
    let rawImg = '';
    try {
      const avatarData = await readFromR2(avatarFileKey(username));
      if (avatarData && avatarData.profileImage) {
        rawImg = avatarData.profileImage;
      }
    } catch {}

    // 3. Fallback a users/<username>.json si no está aislado todavía
    if (!rawImg) {
      const key = userFileKey(username);
      const data = await readFromR2(key);
      rawImg = data?.profileImage || '';
    }

    // Si tiene imagen en base64 (data:image)
    if (typeof rawImg === 'string' && rawImg.startsWith('data:image/')) {
      const match = rawImg.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
      if (match) {
        const contentType = match[1];
        const buffer = Buffer.from(match[2], 'base64');
        const etag = `W/"${buffer.length}-${Buffer.from(username).toString('hex')}"`;

        avatarBufferCache.set(username, {
          buffer,
          contentType,
          etag,
          timestamp: Date.now()
        });

        if (req.headers['if-none-match'] === etag) {
          return res.status(304).end();
        }

        res.set({
          'Content-Type': contentType,
          'Cache-Control': `public, max-age=${AVATAR_CACHE_MAX_AGE}, stale-while-revalidate=604800`,
          'ETag': etag
        });
        return res.send(buffer);
      }
    }

    // Si es una URL http/https directa
    if (typeof rawImg === 'string' && /^https?:\/\//i.test(rawImg.trim())) {
      res.set('Cache-Control', `public, max-age=${AVATAR_CACHE_MAX_AGE}`);
      return res.redirect(rawImg.trim());
    }

    // Fallback: avatar DiceBear servido por su propio CDN gratuito (0 consumo Render)
    res.set('Cache-Control', `public, max-age=${AVATAR_CACHE_MAX_AGE}`);
    return res.redirect(`https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(username)}`);
  } catch (err) {
    res.set('Cache-Control', `public, max-age=300`);
    return res.redirect(`https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(username)}`);
  }
});

app.get('/api/inventory/:username', async (req, res) => {
  const expanded = String(req.query.expanded || '').toLowerCase() === '1';
  try {
    const key = userFileKey(req.params.username);
    let data = await readFromR2(key);
    
    if (!data) {
      // User doesn't exist, return empty
      data = {
        username: req.params.username,
        cards: {},
        packs: {},
        cardTraits: {},
        wallet: { coins: 0, kvr: 0, traits: 0, 'infinite-coins': 0, 'infinite-cardpoints': 0 },
        stats: { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0 },
        weeklyStats: { cards: 0, packs: 0, coins: 0 },
        total_upgrades_success: 0,
        profileImage: '',
        currentTitle: '',
        showcaseCards: [null, null, null],
        missions: {},
        settings: {
          theme: {
            active: 'default',
            customTheme: null
          }
        },
        infiniteRankings: {
          historicalBest: 0,
          seasonBestById: {},
          lastSeasonId: '',
          updatedAt: 0
        },
        updatedAt: 0
      };
    }
    
    // Asegurar que existen los campos nuevos (migración automática)
    if (data.total_upgrades_success === undefined) data.total_upgrades_success = 0;
    if (!data.missions) data.missions = {};
    if (!data.completedDeliverables) data.completedDeliverables = [];
    if (!data.deliverableCompletions) data.deliverableCompletions = {};
    if (!data.packPurchases) data.packPurchases = {};
    if (!data.unlockedTitles || !Array.isArray(data.unlockedTitles)) {
      data.unlockedTitles = ['novato'];
    }
    if (data.currentTitle && !data.unlockedTitles.includes(data.currentTitle)) {
      data.unlockedTitles.push(data.currentTitle);
    }
    if (!data.settings) {
      data.settings = {
        theme: {
          active: 'default',
          customTheme: null
        }
      };
    }
    data.infiniteRankings = ensureInfiniteRankingsShape(data.infiniteRankings);
    
    // NO resetear en GET - el cliente maneja completamente weeklyStats
    // Solo asegurar que weeklyStats existe con estructura básica
    if (!data.weeklyStats || typeof data.weeklyStats !== 'object') {
      data.weeklyStats = { cards: 0, packs: 0, coins: 0, weekStart: null };
    }
    
    // Asegurar campo isAdmin y estado de reseteo
    data.isAdmin = Boolean(data.isAdmin);
    data.isReset = Boolean(data.isReset);
    data.resetAt = Number(data.resetAt) || 0;
    
    // Optimización 6: Soporte ETag / 304 Not Modified para inventario
    const etag = `W/"inv-${data.updatedAt || 0}-${Number(data.resetAt) || 0}"`;
    res.setHeader('ETag', etag);
    if (req.headers['if-none-match'] === etag) {
      return res.status(304).end();
    }

    if (!expanded) {
      return res.json(data);
    }
    return res.json(expandInventory(data));
  } catch (e) {
    console.error('[R2] Error getting user:', e);
    res.status(500).json({ error: String(e) });
  }
});

app.post('/api/inventory/:username', async (req, res) => {
  const body = req.body || {};
  const username = String(req.params.username || body.username || '').trim();
  if (!username) return res.status(400).json({ error: 'username required' });
  let existing = null;
  try {
    existing = await readFromR2(userFileKey(username));
  } catch (readErr) {
    console.log('[POST] Could not read existing data:', readErr?.message);
  }

  const incomingTitles = Array.isArray(body.unlockedTitles) ? body.unlockedTitles : [];
  const existingTitles = Array.isArray(existing?.unlockedTitles) ? existing.unlockedTitles : [];
  const currentTitle = body.currentTitle || existing?.currentTitle || '';
  const mergedTitles = Array.from(new Set([...incomingTitles, ...existingTitles, currentTitle, 'novato'])).filter(Boolean);

  const localCardsCount = Object.values(body.cards || {}).reduce((sum, n) => sum + (Number(n) || 0), 0);
  const localPacksCount = Object.values(body.packs || {}).reduce((sum, n) => sum + (Number(n) || 0), 0);
  const localPowersCount = Object.keys(body.powers || {}).length;
  const incomingInventoryIsEmpty = localCardsCount === 0 && localPacksCount === 0 && localPowersCount === 0;

  // forceReplace=true permite sobrescribir intencionalmente; por defecto protegemos datos remotos.
  const forceReplace = String(body.forceReplace || '').toLowerCase() === 'true';

  // Si el usuario fue reseteado de fábrica por el admin en R2 y el cliente envía datos previos al reseteo, bloquear y avisar
  const bodyResetAt = Number(body.resetAt) || 0;
  const existingResetAt = Number(existing?.resetAt) || 0;
  if (existingResetAt > 0 && bodyResetAt < existingResetAt && !forceReplace) {
    console.warn(`[POST] Bloqueada subida para "${username}": cuenta reseteada por admin el ${new Date(existingResetAt).toISOString()}, cliente envió resetAt=${bodyResetAt}`);
    return res.status(409).json({
      ok: false,
      error: 'account-reset-by-admin',
      resetAt: existingResetAt,
      isReset: true,
      message: 'La cuenta ha sido reiniciada por el administrador.'
    });
  }
  
  // Optimización 3: Aislar los avatares Base64 del JSON de inventario (ahorra hasta 70% de cada subida a R2)
  let resolvedProfileImage = (body.profileImage !== undefined && body.profileImage !== '')
    ? body.profileImage
    : (existing?.profileImage || '');

  if (typeof resolvedProfileImage === 'string' && resolvedProfileImage.startsWith('data:image/')) {
    try {
      await writeToR2(avatarFileKey(username), { profileImage: resolvedProfileImage });
      avatarBufferCache.delete(username);
    } catch (avErr) {
      console.warn('[AVATAR] Error saving isolated avatar:', avErr?.message);
    }
    resolvedProfileImage = `/api/avatar/${encodeURIComponent(username)}`;
  }

  const payload = {
    username,
    password: body.password || '', // Contraseña del usuario
    cards: body.cards || {},
    packs: body.packs || {},
    cardTraits: body.cardTraits || {},
    cardUpgrades: body.cardUpgrades || {},
    completedDeliverables: forceReplace ? (Array.isArray(body.completedDeliverables) ? body.completedDeliverables : []) : (Array.isArray(body.completedDeliverables) ? body.completedDeliverables : (existing?.completedDeliverables || [])),
    deliverableCompletions: forceReplace ? ((body.deliverableCompletions && typeof body.deliverableCompletions === 'object') ? body.deliverableCompletions : {}) : ((body.deliverableCompletions && typeof body.deliverableCompletions === 'object') ? body.deliverableCompletions : (existing?.deliverableCompletions || {})),
    deliverableDailyCompletions: forceReplace ? ((body.deliverableDailyCompletions && typeof body.deliverableDailyCompletions === 'object') ? body.deliverableDailyCompletions : {}) : ((body.deliverableDailyCompletions && typeof body.deliverableDailyCompletions === 'object') ? body.deliverableDailyCompletions : (existing?.deliverableDailyCompletions || {})),
    packPurchases: forceReplace ? ((body.packPurchases && typeof body.packPurchases === 'object') ? body.packPurchases : {}) : ((body.packPurchases && typeof body.packPurchases === 'object') ? body.packPurchases : (existing?.packPurchases || {})),
    wallet: (body.wallet && typeof body.wallet === 'object') 
      ? {
          coins: Math.max(0, Number(body.wallet.coins)||0),
          kvr: Math.max(0, Number(body.wallet.kvr)||0),
          traits: Math.max(0, Number(body.wallet.traits)||0),
          'infinite-coins': Math.max(0, Number(body.wallet['infinite-coins'])||0),
          'infinite-cardpoints': Math.max(0, Number(body.wallet['infinite-cardpoints'])||0)
        }
      : { coins: 0, kvr: 0, traits: 0, 'infinite-coins': 0, 'infinite-cardpoints': 0 },
    stats: body.stats || { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0 },
    weeklyStats: body.weeklyStats || { cards: 0, packs: 0, coins: 0, weekStart: null },
    profileImage: resolvedProfileImage,
    currentTitle: body.currentTitle || existing?.currentTitle || '',
    unlockedTitles: forceReplace ? (Array.isArray(body.unlockedTitles) ? body.unlockedTitles : ['novato']) : mergedTitles,
    currentBackground: body.currentBackground || existing?.currentBackground || 'default',
    unlockedBackgrounds: forceReplace ? (Array.isArray(body.unlockedBackgrounds) ? body.unlockedBackgrounds : ['default']) : Array.from(new Set([
      ...(Array.isArray(existing?.unlockedBackgrounds) ? existing.unlockedBackgrounds : ['default']),
      ...(Array.isArray(body.unlockedBackgrounds) ? body.unlockedBackgrounds : ['default'])
    ])).filter(Boolean),
    showcaseCards: forceReplace ? (Array.isArray(body.showcaseCards) ? body.showcaseCards : [null, null, null]) : (Array.isArray(body.showcaseCards) ? body.showcaseCards : (existing?.showcaseCards || [null, null, null])),
    // Sistema de amigos (preservar siempre del servidor si el cliente no envía el array)
    friends: (Array.isArray(body.friends) && body.friends.length > 0) ? body.friends : (existing?.friends || []),
    friendRequests: (Array.isArray(body.friendRequests) && body.friendRequests.length > 0) ? body.friendRequests : (existing?.friendRequests || []),
    sentRequests: (Array.isArray(body.sentRequests) && body.sentRequests.length > 0) ? body.sentRequests : (existing?.sentRequests || []),
    // NUEVO: Estado de misiones
    missions: body.missions || {},
    // NUEVO: Configuración del usuario (tema, etc)
    settings: body.settings || {
      theme: {
        active: 'default',
        customTheme: null
      }
    },
    // NUEVO: Poderes
    powers: body.powers || {},
    redeemedCodes: forceReplace ? (Array.isArray(body.redeemedCodes) ? body.redeemedCodes : []) : Array.from(new Set([
      ...(Array.isArray(existing?.redeemedCodes) ? existing.redeemedCodes : []),
      ...(Array.isArray(body.redeemedCodes) ? body.redeemedCodes : [])
    ])),
    supporterBlessing: forceReplace ? ((body.supporterBlessing && typeof body.supporterBlessing === 'object') ? body.supporterBlessing : null) : ((body.supporterBlessing && typeof body.supporterBlessing === 'object') ? body.supporterBlessing : (existing?.supporterBlessing || null)),
    isAdmin: (body.isAdmin !== undefined) ? Boolean(body.isAdmin) : (existing?.isAdmin === true),
    resetAt: bodyResetAt >= existingResetAt ? bodyResetAt : existingResetAt,
    isReset: (bodyResetAt >= existingResetAt && existingResetAt > 0) ? false : Boolean(existing?.isReset),
    infiniteRun: null,
    updatedAt: Date.now(),
  };
  
  // CRÍTICO: Verificar weekStart, pero NO resetear los valores enviados por el cliente
  // El cliente ya tiene los valores correctos después de sus incrementos
  console.log('[POST] Checking weeklyStats for:', username);
  console.log('[POST] Received weeklyStats:', payload.weeklyStats);

  // Protección crítica anti-pérdida: bloquear overwrite vacío si R2 ya tiene progreso.
  try {
    existing = await readFromR2(userFileKey(username));
    const existingCardsCount = Object.values(existing?.cards || {}).reduce((sum, n) => sum + (Number(n) || 0), 0);
    const existingPacksCount = Object.values(existing?.packs || {}).reduce((sum, n) => sum + (Number(n) || 0), 0);
    const existingPowersCount = Object.keys(existing?.powers || {}).length;
    const existingHasData = existingCardsCount > 0 || existingPacksCount > 0 || existingPowersCount > 0;

    if (!forceReplace && incomingInventoryIsEmpty && existingHasData) {
      console.error('[POST] BLOCKED destructive overwrite for user:', username);
      return res.status(409).json({
        ok: false,
        error: 'blocked-destructive-overwrite',
        message: 'Se bloqueó una sobrescritura vacía para proteger tu inventario en nube.',
        existing: {
          cards: existingCardsCount,
          packs: existingPacksCount,
          powers: existingPowersCount
        }
      });
    }
  } catch (guardErr) {
    console.error('[POST] Guard check failed, continuing with caution:', guardErr?.message || guardErr);
  }
  
  // Solo asegurar que weekStart existe
  if (!payload.weeklyStats.weekStart) {
    payload.weeklyStats.weekStart = getCurrentMondayTimestamp();
    console.log('[POST] weekStart not set, initializing to current Monday');
  }

  payload.infiniteRun = body.infiniteRun && typeof body.infiniteRun === 'object'
    ? sanitizeInfiniteRunPayload(body.infiniteRun)
    : (existing?.infiniteRun || null);

    const seasonConfig = await getInfiniteSeasonConfig();
    const seasonKey = getSeasonRankingKey(seasonConfig);
    if (payload.infiniteRun) {
      updateUserInfiniteRankingsFromRun(payload, payload.infiniteRun, seasonKey);
    } else {
      const normalizedRankings = ensureInfiniteRankingsShape(payload.infiniteRankings || existing?.infiniteRankings);
      normalizedRankings.lastSeasonId = seasonKey;
      payload.infiniteRankings = normalizedRankings;
    }

  // Preservar y aplicar deducciones pendientes ordenadas por el admin
  const pendingDeductions = Array.isArray(existing?.adminDeductions) ? existing.adminDeductions : [];
  payload.adminDeductions = pendingDeductions;

  if (pendingDeductions.length > 0) {
    for (const d of pendingDeductions) {
      if (!d) continue;
      if (d.type === 'clear-blessing') {
        payload.supporterBlessing = null;
      } else if (d.type === 'remove-coins') {
        if (existing?.wallet && typeof existing.wallet.coins === 'number') {
          payload.wallet.coins = Math.min(payload.wallet.coins, existing.wallet.coins);
        }
      } else if (d.type === 'remove-kvr') {
        if (existing?.wallet && typeof existing.wallet.kvr === 'number') {
          payload.wallet.kvr = Math.min(payload.wallet.kvr, existing.wallet.kvr);
        }
      } else if (d.type === 'remove-card' && d.cardId) {
        if (existing?.cards) {
          const exCount = Number(existing.cards[d.cardId]) || 0;
          if (exCount <= 0) {
            delete payload.cards[d.cardId];
          } else {
            payload.cards[d.cardId] = Math.min(Number(payload.cards[d.cardId]) || 0, exCount);
          }
        }
      } else if ((d.type === 'give-card' || d.type === 'add-card') && d.cardId) {
        if (existing?.cards) {
          const exCount = Number(existing.cards[d.cardId]) || 0;
          payload.cards[d.cardId] = Math.max(Number(payload.cards[d.cardId]) || 0, exCount);
        }
      } else if ((d.type === 'give-pack' || d.type === 'add-pack') && d.packId) {
        if (!payload.packs || typeof payload.packs !== 'object') payload.packs = {};
        if (existing?.packs) {
          const exCount = Number(existing.packs[d.packId]) || 0;
          payload.packs[d.packId] = Math.max(Number(payload.packs[d.packId]) || 0, exCount);
        }
      } else if ((d.type === 'give-title' || d.type === 'add-title') && d.titleId) {
        if (!Array.isArray(payload.unlockedTitles)) payload.unlockedTitles = ['novato'];
        if (!payload.unlockedTitles.includes(d.titleId)) {
          payload.unlockedTitles.push(d.titleId);
        }
      } else if ((d.type === 'give-coins' || d.type === 'add-coins') && d.amount) {
        if (existing?.wallet && typeof existing.wallet.coins === 'number') {
          payload.wallet.coins = Math.max(payload.wallet.coins, existing.wallet.coins);
        }
      } else if ((d.type === 'give-kvr' || d.type === 'add-kvr') && d.amount) {
        if (existing?.wallet && typeof existing.wallet.kvr === 'number') {
          payload.wallet.kvr = Math.max(payload.wallet.kvr, existing.wallet.kvr);
        }
      } else if (d.type === 'remove-traits') {
        if (existing?.wallet && typeof existing.wallet.traits === 'number') {
          payload.wallet.traits = Math.min(payload.wallet.traits, existing.wallet.traits);
        }
      } else if ((d.type === 'give-traits' || d.type === 'add-traits') && d.amount) {
        if (existing?.wallet && typeof existing.wallet.traits === 'number') {
          payload.wallet.traits = Math.max(payload.wallet.traits, existing.wallet.traits);
        }
      } else if ((d.type === 'give-card-trait' || d.type === 'add-card-trait') && d.cardId && d.traitId) {
        if (!payload.cardTraits || typeof payload.cardTraits !== 'object') payload.cardTraits = {};
        const instId = d.instanceId || `trait_${d.cardId}`;
        payload.cardTraits[instId] = { cardId: d.cardId, traitId: d.traitId };
        if (!payload.cards || typeof payload.cards !== 'object') payload.cards = {};
        if ((payload.cards[d.cardId] || 0) < 1) {
          payload.cards[d.cardId] = 1;
        }
      } else if (d.type === 'remove-card-trait') {
        if (payload.cardTraits && typeof payload.cardTraits === 'object') {
          if (d.instanceId && payload.cardTraits[d.instanceId]) {
            delete payload.cardTraits[d.instanceId];
          } else if (d.cardId) {
            for (const [instId, tObj] of Object.entries(payload.cardTraits)) {
              const cId = typeof tObj === 'object' && tObj ? tObj.cardId : instId;
              if (cId === d.cardId) delete payload.cardTraits[instId];
            }
          }
        }
      }
    }
  }
  
  try {
    const key = userFileKey(username);
    await writeToR2(key, payload);
    if (body.profileImage) {
      avatarBufferCache.delete(username);
    }
    console.log('[inventory-server] Saved snapshot for', username, 'to R2');
    res.json({ ok: true, pendingDeductions });
  } catch (e) {
    console.error('[R2] Error saving user:', e);
    res.status(500).json({ error: String(e) });
  }
});

// List all users
app.get('/api/inventory', async (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    const users = await listUsersFromR2();
    console.log('[inventory-server] List users from R2:', users);
    res.json({ users });
  } catch (e) {
    console.error('[R2] Error listing users:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Healthcheck
app.get('/api/health', async (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    const users = await listUsersFromR2();
    res.json({ 
      ok: true, 
      storage: 'cloudflare-r2',
      bucket: R2_BUCKET_NAME,
      count: users.length 
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

app.get('/api/infinite/world-config', async (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    const configPath = path.join(__dirname, 'data', 'infinite-worlds.json');
    const raw = await fs.readFile(configPath, 'utf-8');
    const parsed = JSON.parse(raw);
    res.json(parsed);
  } catch (e) {
    console.error('[INFINITE CONFIG] Error loading world config:', e);
    res.status(500).json({ error: 'No se pudo cargar infinite-worlds.json' });
  }
});

// ==================== CÓDIGOS DE ÚNICO USO (GLOBAL) ====================

app.get('/api/codes/status/:code', async (req, res) => {
  try {
    const codeUpper = String(req.params.code || '').trim().toUpperCase();
    if (!codeUpper) return res.status(400).json({ error: 'code required' });
    let usedCodes = await readFromR2('used_codes.json').catch(() => null);
    if (usedCodes && typeof usedCodes === 'object' && usedCodes[codeUpper]) {
      return res.json({ used: true, user: usedCodes[codeUpper].user, date: usedCodes[codeUpper].date });
    }
    return res.json({ used: false });
  } catch (err) {
    return res.json({ used: false });
  }
});

app.post('/api/codes/claim', async (req, res) => {
  try {
    const { code, username } = req.body || {};
    if (!code) return res.status(400).json({ error: 'code required' });
    const codeUpper = String(code).trim().toUpperCase();

    let usedCodes = await readFromR2('used_codes.json').catch(() => null);
    if (!usedCodes || typeof usedCodes !== 'object') {
      usedCodes = {};
    }

    if (usedCodes[codeUpper]) {
      return res.status(400).json({ 
        error: `Este código de único uso ya ha sido canjeado por ${usedCodes[codeUpper].user || 'otro jugador'}.`,
        used: true,
        usedBy: usedCodes[codeUpper].user
      });
    }

    usedCodes[codeUpper] = {
      user: username || 'unknown',
      date: new Date().toISOString(),
      timestamp: Date.now()
    };

    await writeToR2('used_codes.json', usedCodes).catch(() => {});
    return res.json({ ok: true, message: 'Código de único uso canjeado exitosamente' });
  } catch (err) {
    console.error('[CODES] Error canjeando código único:', err);
    return res.status(500).json({ error: err.message });
  }
});

app.get('/api/infinite/run/:username', async (req, res) => {
  try {
    const username = String(req.params.username || '').trim();
    if (!username) return res.status(400).json({ ok: false, error: 'username required' });

    const data = await readFromR2(userFileKey(username));
    return res.json({ ok: true, run: data?.infiniteRun || null });
  } catch (e) {
    console.error('[INFINITE RUN] Error getting run:', e);
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.post('/api/infinite/run/:username', async (req, res) => {
  try {
    const username = String(req.params.username || '').trim();
    if (!username) return res.status(400).json({ ok: false, error: 'username required' });

    const body = req.body || {};
    if (!body.run || typeof body.run !== 'object') {
      return res.status(400).json({ ok: false, error: 'run object required' });
    }

    const key = userFileKey(username);
    const existing = await readFromR2(key);
    const payload = existing && typeof existing === 'object'
      ? { ...existing }
      : {
          username,
          cards: {},
          packs: {},
          cardTraits: {},
          wallet: { coins: 0, kvr: 0, traits: 0, 'infinite-coins': 0, 'infinite-cardpoints': 0 },
          stats: { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0 },
          weeklyStats: { cards: 0, packs: 0, coins: 0, weekStart: null },
          total_upgrades_success: 0,
          profileImage: '',
          currentTitle: '',
          showcaseCards: [null, null, null],
          missions: {},
          settings: {
            theme: {
              active: 'default',
              customTheme: null
            }
          },
          infiniteRankings: {
            historicalBest: 0,
            seasonBestById: {},
            lastSeasonId: '',
            updatedAt: 0
          },
          powers: {}
        };
    
    if (payload.total_upgrades_success === undefined) payload.total_upgrades_success = 0;
    payload.infiniteRun = sanitizeInfiniteRunPayload(body.run);
    const seasonConfig = await getInfiniteSeasonConfig();
    const seasonKey = getSeasonRankingKey(seasonConfig);
    updateUserInfiniteRankingsFromRun(payload, payload.infiniteRun, seasonKey);
    payload.updatedAt = Date.now();

    await writeToR2(key, payload);
    return res.json({ ok: true, run: payload.infiniteRun });
  } catch (e) {
    console.error('[INFINITE RUN] Error saving run:', e);
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.delete('/api/infinite/run/:username', async (req, res) => {
  try {
    const username = String(req.params.username || '').trim();
    if (!username) return res.status(400).json({ ok: false, error: 'username required' });

    const key = userFileKey(username);
    const existing = await readFromR2(key);
    if (!existing || typeof existing !== 'object') {
      return res.json({ ok: true, cleared: false, run: null });
    }

    const payload = { ...existing };
    delete payload.infiniteRun;
    if (payload.wallet) {
      payload.wallet['infinite-coins'] = 0;
      payload.wallet['infinite-cardpoints'] = 0;
    }
    payload.updatedAt = Date.now();

    await writeToR2(key, payload);
    return res.json({ ok: true, cleared: true, run: null });
  } catch (e) {
    console.error('[INFINITE RUN] Error clearing run:', e);
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.get('/api/infinite/season', async (_req, res) => {
  try {
    const seasonConfig = await getInfiniteSeasonConfig();
    return res.json({
      ok: true,
      version: Number(seasonConfig?.version) || 1,
      season: seasonConfig.season,
      rewards: seasonConfig.rewards,
      beyondLevel100: seasonConfig.beyondLevel100,
      source: INFINITE_SEASON_REMOTE_URL
    });
  } catch (e) {
    console.error('[INFINITE SEASON] Error getting season config:', e);
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

app.get('/api/infinite/rankings', async (req, res) => {
  try {
    const etag = `W/"infrank-${infiniteRankingsCache.timestamp}"`;
    res.setHeader('ETag', etag);
    if (req.headers['if-none-match'] === etag) {
      return res.status(304).end();
    }
    const username = String(req.query.username || '').trim();
    const limit = Math.max(1, Number(req.query.limit) || 5);
    const result = await buildInfiniteRankingsOverview(username, limit);
    return res.json(result);
  } catch (e) {
    console.error('[INFINITE RANKINGS] Error getting rankings:', e);
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// Endpoint general de rankings (semanal e histórico en una sola respuesta ligera)
app.get('/api/rankings', async (req, res) => {
  try {
    const etag = `W/"rank-${generalRankingsCache.timestamp}"`;
    res.setHeader('ETag', etag);
    if (req.headers['if-none-match'] === etag) {
      return res.status(304).end();
    }
    const rankings = await buildGeneralRankings();
    return res.json(rankings);
  } catch (e) {
    console.error('[RANKINGS] Error getting rankings:', e);
    return res.status(500).json({ ok: false, error: String(e) });
  }
});

// Detail page for a user
// Detail page for a user
app.get('/user/:username', requireAuth, async (req, res) => {
  try {
    const username = String(req.params.username || '').trim();
    const data = await readFromR2(userFileKey(username));
    
    if (!data) {
      return res.status(404).send('User not found');
    }
    
    // DEBUG: Log para ver qué hay en powers
    console.log('[DEBUG] User:', username);
    console.log('[DEBUG] Powers data:', JSON.stringify(data.powers || {}));
    console.log('[DEBUG] Powers keys:', Object.keys(data.powers || {}));
    
    // Card datalist for quick autocomplete
    let cardDatalistOptions = '';
    if (Array.isArray(draftCardsPool) && draftCardsPool.length > 0) {
      cardDatalistOptions = draftCardsPool
        .slice()
        .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id)))
        .map(c => `<option value="${c.id}">${c.name || c.id} (Media: ${c.media || '-'})</option>`)
        .join('');
    } else if (catalogIndex.cards && Object.keys(catalogIndex.cards).length > 0) {
      cardDatalistOptions = Object.entries(catalogIndex.cards)
        .sort((a, b) => String(a[1]).localeCompare(String(b[1])))
        .map(([id, name]) => `<option value="${id}">${name}</option>`)
        .join('');
    }

    // Pack datalist for quick autocomplete
    let packDatalistOptions = '';
    if (Array.isArray(draftPacksPool) && draftPacksPool.length > 0) {
      packDatalistOptions = draftPacksPool
        .slice()
        .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id)))
        .map(p => `<option value="${p.id}">${p.name || p.id} (${p.id})</option>`)
        .join('');
    } else if (catalogIndex.packs && Object.keys(catalogIndex.packs).length > 0) {
      packDatalistOptions = Object.entries(catalogIndex.packs)
        .sort((a, b) => String(a[1]).localeCompare(String(b[1])))
        .map(([id, name]) => `<option value="${id}">${name} (${id})</option>`)
        .join('');
    }

    // Title datalist for quick autocomplete
    let titleDatalistOptions = '';
    if (Array.isArray(draftTitlesPool) && draftTitlesPool.length > 0) {
      titleDatalistOptions = draftTitlesPool
        .slice()
        .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id)))
        .map(t => `<option value="${t.id}">${t.name || t.id} (${t.id})</option>`)
        .join('');
    }

    const titlesRows = (Array.isArray(data.unlockedTitles) ? data.unlockedTitles : ['novato']).map(tId => {
      const foundTitle = Array.isArray(draftTitlesPool) ? draftTitlesPool.find(t => t.id === tId) : null;
      const titleName = foundTitle?.name || tId;
      const isEquipped = String(tId).toLowerCase() === String(data.currentTitle || 'novato').toLowerCase();
      return `<tr><td><strong>${titleName}</strong> <small style="color:#64748b;">(${tId})</small></td><td>${isEquipped ? '<span style="color:#16a34a; font-weight:bold;">🟢 Equipado</span>' : 'Desbloqueado'}</td></tr>`;
    }).join('');

    // Trait datalist for quick autocomplete
    let traitDatalistOptions = '';
    if (Array.isArray(draftTraitsPool) && draftTraitsPool.length > 0) {
      traitDatalistOptions = draftTraitsPool
        .slice()
        .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id)))
        .map(t => `<option value="${t.id}">${t.name || t.id} (${t.rarity || 'común'}) - ${t.description || t.id}</option>`)
        .join('');
    }

    // Build traits table rows
    const traitsRows = Object.entries(data.cardTraits || {}).map(([instanceId, traitData]) => {
      const cardId = typeof traitData === 'object' && traitData ? traitData.cardId : '';
      const traitId = typeof traitData === 'object' && traitData ? traitData.traitId : String(traitData);
      
      const foundTrait = Array.isArray(draftTraitsPool) ? draftTraitsPool.find(t => t.id === traitId) : null;
      const traitName = foundTrait?.name || traitId;
      const traitRarity = foundTrait?.rarity || 'común';
      const traitDesc = foundTrait?.description || '';
      const traitIcon = foundTrait?.imageUrl || '';

      const cardName = catalogIndex.cards[cardId] || (findCardInCatalog(cardId)?.name) || cardId || 'Desconocida';
      
      return `
        <tr>
          <td><strong>${cardName}</strong> <small style="color:#64748b;">(${cardId || instanceId})</small></td>
          <td>
            <div style="display:flex; align-items:center; gap:8px;">
              ${traitIcon ? `<img src="${traitIcon}" style="width:28px; height:28px; object-fit:contain; border-radius:4px; background:#1e293b; padding:2px;">` : ''}
              <div>
                <strong>${traitName}</strong> <span style="font-size:0.75rem; color:#64748b; text-transform:uppercase;">[${traitRarity}]</span>
                ${traitDesc ? `<br><small style="color:#475569;">${traitDesc}</small>` : ''}
              </div>
            </div>
          </td>
          <td><code style="font-size:0.8rem; background:#f1f5f9; padding:2px 5px; border-radius:3px;">${instanceId}</code></td>
          <td style="text-align:center;">
            <button onclick="removeCardTrait('${username}', '${instanceId}')" style="background:#dc2626; color:#fff; border:none; padding:0.35rem 0.65rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.8rem;" title="Eliminar rasgo de esta carta">🗑️ Quitar Trait</button>
          </td>
        </tr>
      `;
    }).join('');

    // Build tables
    const cardsRows = Object.entries(data.cards || {}).map(([id, count]) => {
      const cardName = catalogIndex.cards[id] || (findCardInCatalog(id)?.name) || '';
      const displayName = cardName && cardName !== id 
        ? `${cardName} <small style="color:#64748b; font-weight:normal;">(${id})</small>` 
        : id;
      return `
      <tr>
        <td>${displayName}</td>
        <td><strong>${count}</strong></td>
        <td style="text-align:center;">
          <button onclick="removeCard('${username}', '${id}', 1)" style="background:#f59e0b; color:#fff; border:none; padding:0.35rem 0.65rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.8rem; margin-right:4px;" title="Quitar 1 copia">➖ 1</button>
          <button onclick="promptRemoveCard('${username}', '${id}', ${count})" style="background:#ea580c; color:#fff; border:none; padding:0.35rem 0.65rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.8rem; margin-right:4px;" title="Quitar cantidad personalizada">➖ X</button>
          <button onclick="removeCard('${username}', '${id}', ${count})" style="background:#dc2626; color:#fff; border:none; padding:0.35rem 0.65rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.8rem;" title="Eliminar todas las copias">🗑️ Todas</button>
        </td>
      </tr>
    `}).join('');
    
    const packsRows = Object.entries(data.packs || {}).map(([id, count]) => `
      <tr><td>${id}</td><td>${count}</td></tr>
    `).join('');
    
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${username} - Inventory</title>
<style>
  body { font-family: sans-serif; max-width: 1200px; margin: 2rem auto; padding: 1rem; background: #f9f9f9; }
  h1 { color: #333; border-bottom: 2px solid #0066cc; padding-bottom: 0.5rem; }
  h2 { color: #0066cc; margin-top: 2rem; }
  .section { background: white; padding: 1.5rem; border-radius: 8px; margin-bottom: 1.5rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
  table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
  th, td { border: 1px solid #ddd; padding: 0.75rem; text-align: left; }
  th { background-color: #f2f2f2; font-weight: bold; }
  tr:hover { background-color: #f5f5f5; }
  .info-box { background: #e8f4f8; padding: 1rem; border-radius: 4px; margin: 0.5rem 0; border-left: 4px solid #0066cc; }
  .back-link { display: inline-block; margin-bottom: 1rem; color: #0066cc; text-decoration: none; }
  .back-link:hover { text-decoration: underline; }
  .password-container { display: flex; align-items: center; gap: 1rem; }
  .password-hidden { color: #333; font-size: 1.2rem; letter-spacing: 2px; }
  .password-revealed { color: #333; font-family: monospace; }
  .reveal-btn { background: #0066cc; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; font-size: 0.9rem; }
  .reveal-btn:hover { background: #0052a3; }
</style>
<script>
  const actualPassword = '${data.password || ''}';
  function togglePassword() {
    const pwd = document.getElementById('password');
    const btn = document.getElementById('revealBtn');
    if (pwd.classList.contains('password-hidden')) {
      pwd.classList.remove('password-hidden');
      pwd.classList.add('password-revealed');
      pwd.textContent = actualPassword || '(sin contraseña)';
      btn.textContent = '🔒 Ocultar';
    } else {
      pwd.classList.add('password-hidden');
      pwd.classList.remove('password-revealed');
      pwd.textContent = '••••••••';
      btn.textContent = '🔓 Revelar';
    }
  }

  async function toggleAdmin(username, makeAdmin) {
    const actionText = makeAdmin ? 'conceder permisos de ADMIN a' : 'quitar el rango ADMIN a';
    if (!confirm('¿Estás seguro de que deseas ' + actionText + ' "' + username + '"?')) return;
    try {
      const authParam = new URLSearchParams(window.location.search).get('auth') || 'kvcard';
      const res = await fetch('/api/admin/toggle-admin/' + encodeURIComponent(username) + '?auth=' + encodeURIComponent(authParam), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isAdmin: makeAdmin })
      });
      const result = await res.json();
      if (result.ok) {
        alert('Estado de admin actualizado para ' + username);
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo actualizar'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function resetUser(username) {
    if (!confirm('¿Estás seguro de que deseas REINICIAR DE FÁBRICA la cuenta de "' + username + '"? Se restablecerá todo su progreso a cero (cartas, sobres, monedas, misiones, entregables, kizunas, evoluciones, prestigios, códigos).')) return;
    if (!confirm('CONFIRMACIÓN DEFINITIVA: La cuenta de "' + username + '" quedará completamente limpia como recién registrada. ¿Confirmas el reinicio definitivo?')) return;

    try {
      const authParam = new URLSearchParams(window.location.search).get('auth') || 'kvcard';
      const res = await fetch('/api/admin/reset-user/' + encodeURIComponent(username) + '?auth=' + encodeURIComponent(authParam), {
        method: 'POST'
      });
      const result = await res.json();
      if (result.ok) {
        alert('Cuenta de "' + username + '" reiniciada de fábrica con éxito.');
        location.reload();
      } else {
        alert('Error: ' + (result.error || result.message || 'No se pudo reiniciar'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function removeBlessing(username) {
    if (!confirm('¿Estás seguro de que deseas ELIMINAR la Bendición del Supporter de "' + username + '"? Se quitará en la nube y se borrará localmente en su juego sin afectar el resto de sus datos.')) return;
    try {
      const authParam = new URLSearchParams(window.location.search).get('auth') || 'kvcard';
      const res = await fetch('/api/admin/remove-blessing/' + encodeURIComponent(username) + '?auth=' + encodeURIComponent(authParam), {
        method: 'POST'
      });
      const result = await res.json();
      if (result.ok) {
        alert('Bendición del supporter eliminada correctamente.');
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo eliminar'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function deductCurrency(username, type) {
    const input = document.getElementById(type === 'kvr' ? 'deductKvrInput' : (type === 'traits' ? 'deductTraitsInput' : 'deductCoinsInput'));
    const amount = parseInt(input.value, 10);
    if (isNaN(amount) || amount <= 0) {
      alert('Por favor introduce una cantidad válida mayor a 0');
      return;
    }
    const label = type === 'kvr' ? 'KvR' : (type === 'traits' ? 'Traits' : 'Coins');
    if (!confirm('¿Quitar ' + amount + ' ' + label + ' a "' + username + '"? Se restará en la nube y se le descontará localmente en su juego.')) return;
    try {
      const authParam = new URLSearchParams(window.location.search).get('auth') || 'kvcard';
      const res = await fetch('/api/admin/deduct-currency/' + encodeURIComponent(username) + '?auth=' + encodeURIComponent(authParam), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, amount })
      });
      const result = await res.json();
      if (result.ok) {
        alert('Se han quitado ' + amount + ' ' + label + ' a ' + username);
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo restar dinero'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function giveTraitsCurrency(username) {
    const input = document.getElementById('giveTraitsInput');
    const amount = parseInt(input.value, 10);
    if (isNaN(amount) || amount <= 0) {
      alert('Por favor introduce una cantidad válida mayor a 0');
      return;
    }
    if (!confirm('¿Givear ' + amount + ' Traits a "' + username + '"? Se agregarán en la nube y se transferirán localmente a su juego.')) return;
    try {
      const authParam = new URLSearchParams(window.location.search).get('auth') || 'kvcard';
      const res = await fetch('/api/admin/give-traits/' + encodeURIComponent(username) + '?auth=' + encodeURIComponent(authParam), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount })
      });
      const result = await res.json();
      if (result.ok) {
        alert('¡Traits entregados con éxito a ' + username + '! Total actual: ' + result.total);
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo givear traits'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function removeCard(username, cardId, count) {
    if (!confirm('¿Quitar ' + count + ' copia(s) de la carta "' + cardId + '" a "' + username + '"? Se restará en la nube y se borrará localmente en su juego.')) return;
    try {
      const authParam = new URLSearchParams(window.location.search).get('auth') || 'kvcard';
      const res = await fetch('/api/admin/remove-card/' + encodeURIComponent(username) + '?auth=' + encodeURIComponent(authParam), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cardId, count })
      });
      const result = await res.json();
      if (result.ok) {
        alert('Carta(s) eliminada(s) correctamente.');
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo quitar la carta'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  function promptRemoveCard(username, cardId, maxCount) {
    const input = prompt('¿Cuántas copias deseas quitar de "' + cardId + '"? (Máximo ' + maxCount + '):', '1');
    if (input === null) return;
    const count = parseInt(input, 10);
    if (isNaN(count) || count <= 0) {
      alert('Cantidad inválida.');
      return;
    }
    removeCard(username, cardId, Math.min(count, maxCount));
  }

  async function giveCard(username) {
    const cardIdInput = document.getElementById('giveCardId');
    const countInput = document.getElementById('giveCardCount');
    const cardId = (cardIdInput.value || '').trim();
    const count = parseInt(countInput.value, 10);

    if (!cardId) {
      alert('Por favor introduce o selecciona el ID de la carta');
      cardIdInput.focus();
      return;
    }
    if (isNaN(count) || count <= 0) {
      alert('Por favor introduce una cantidad válida (mínimo 1)');
      countInput.focus();
      return;
    }

    if (!confirm('¿Givear ' + count + ' copia(s) de la carta "' + cardId + '" a "' + username + '"? Se agregará en la nube y se transferirá localmente a su juego.')) return;

    try {
      const authParam = new URLSearchParams(window.location.search).get('auth') || 'kvcard';
      const res = await fetch('/api/admin/give-card/' + encodeURIComponent(username) + '?auth=' + encodeURIComponent(authParam), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cardId, count })
      });
      const result = await res.json();
      if (result.ok) {
        alert('¡Carta entregada con éxito a ' + username + '! Cantidad total actual: ' + result.total);
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo givear la carta'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function givePack(username) {
    const packIdInput = document.getElementById('givePackId');
    const countInput = document.getElementById('givePackCount');
    const packId = (packIdInput.value || '').trim();
    const count = parseInt(countInput.value, 10);

    if (!packId) {
      alert('Por favor introduce o selecciona el ID del sobre');
      packIdInput.focus();
      return;
    }
    if (isNaN(count) || count <= 0) {
      alert('Por favor introduce una cantidad válida (mínimo 1)');
      countInput.focus();
      return;
    }

    if (!confirm('¿Givear ' + count + ' sobre(s) "' + packId + '" a "' + username + '"? Se agregará en la nube y se transferirá localmente a su juego.')) return;

    try {
      const authParam = new URLSearchParams(window.location.search).get('auth') || 'kvcard';
      const res = await fetch('/api/admin/give-pack/' + encodeURIComponent(username) + '?auth=' + encodeURIComponent(authParam), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ packId, count })
      });
      const result = await res.json();
      if (result.ok) {
        alert('¡Sobre(s) entregado(s) con éxito a ' + username + '! Cantidad total actual: ' + result.total);
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo givear el sobre'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function giveTitle(username) {
    const titleIdInput = document.getElementById('giveTitleId');
    const titleId = (titleIdInput.value || '').trim();

    if (!titleId) {
      alert('Por favor introduce o selecciona el ID del título');
      titleIdInput.focus();
      return;
    }

    if (!confirm('¿Desbloquear el título "' + titleId + '" a "' + username + '"? Se agregará en la nube y se transferirá localmente a su juego.')) return;

    try {
      const authParam = new URLSearchParams(window.location.search).get('auth') || 'kvcard';
      const res = await fetch('/api/admin/give-title/' + encodeURIComponent(username) + '?auth=' + encodeURIComponent(authParam), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ titleId })
      });
      const result = await res.json();
      if (result.ok) {
        alert('¡Título desbloqueado con éxito para ' + username + '!');
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo givear el título'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function giveCardTrait(username) {
    const cardIdInput = document.getElementById('giveTraitCardId');
    const traitIdInput = document.getElementById('giveTraitId');
    const cardId = (cardIdInput.value || '').trim();
    const traitId = (traitIdInput.value || '').trim();

    if (!cardId) {
      alert('Por favor introduce o selecciona el ID de la carta');
      cardIdInput.focus();
      return;
    }
    if (!traitId) {
      alert('Por favor introduce o selecciona el ID del rasgo / trait');
      traitIdInput.focus();
      return;
    }

    if (!confirm('¿Asignar rasgo "' + traitId + '" a la carta "' + cardId + '" para "' + username + '"? Se guardará en la nube y se transferirá localmente a su juego.')) return;

    try {
      const authParam = new URLSearchParams(window.location.search).get('auth') || 'kvcard';
      const res = await fetch('/api/admin/give-card-trait/' + encodeURIComponent(username) + '?auth=' + encodeURIComponent(authParam), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cardId, traitId })
      });
      const result = await res.json();
      if (result.ok) {
        alert('¡Rasgo asignado con éxito a la carta de ' + username + '!');
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo asignar el rasgo'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function removeCardTrait(username, instanceId) {
    if (!confirm('¿Estás seguro de eliminar este rasgo de la carta (' + instanceId + ')? Se quitará en la nube y localmente en el juego del usuario.')) return;
    try {
      const authParam = new URLSearchParams(window.location.search).get('auth') || 'kvcard';
      const res = await fetch('/api/admin/remove-card-trait/' + encodeURIComponent(username) + '?auth=' + encodeURIComponent(authParam), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ instanceId })
      });
      const result = await res.json();
      if (result.ok) {
        alert('Rasgo eliminado de la carta con éxito.');
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo eliminar el rasgo'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }
</script>
</head>
<body>
<a href="/?auth=${req.query.auth || ''}" class="back-link">← Volver a inicio</a>
<h1>Inventario de ${username}</h1>

<div class="section">
  <h2>📋 Información de Cuenta</h2>
  <div class="info-box">
    <strong>Username:</strong> ${username}
  </div>
  <div class="info-box" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px;">
    <div>
      <strong>Rango Admin:</strong> 
      ${data.isAdmin ? '<span style="color:#d97706; font-weight:bold;">⭐ ADMINISTRADOR (Acceso a Modo Debug)</span>' : '<span style="color:#64748b; font-weight:bold;">👤 Usuario Estándar</span>'}
    </div>
    <div style="display:flex; gap:8px; flex-wrap:wrap;">
      <button onclick="toggleAdmin('${username}', ${!data.isAdmin})" style="background:${data.isAdmin ? '#f59e0b' : '#3b82f6'}; color:${data.isAdmin ? '#000' : '#fff'}; border:none; padding:0.5rem 1rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.9rem;">
        ${data.isAdmin ? '🛡️ Quitar Rango Admin' : '⭐ Conceder Rango Admin'}
      </button>
      <button onclick="resetUser('${username}')" style="background:#ea580c; color:#fff; border:none; padding:0.5rem 1rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.9rem;" title="Reiniciar de fábrica todas las cartas, monedas, misiones, evoluciones y códigos">
        🔄 Reiniciar Cuenta de Fábrica
      </button>
    </div>
  </div>
  <div class="info-box">
    <div class="password-container">
      <strong>Contraseña:</strong> 
      <span id="password" class="password-hidden">••••••••</span>
      <button id="revealBtn" class="reveal-btn" onclick="togglePassword()">🔓 Revelar</button>
    </div>
  </div>
  <div class="info-box">
    <strong>Título Actual:</strong> ${data.currentTitle || 'Sin título'}
  </div>
  <div class="info-box">
    <strong>Última Actualización:</strong> ${new Date(data.updatedAt || 0).toLocaleString()}
  </div>
</div>

<div class="section">
  <h2>⭐ Bendición del Supporter</h2>
  ${data.supporterBlessing && data.supporterBlessing.active && (data.supporterBlessing.daysRemaining > 0) ? `
    <div class="info-box" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px; background:#f0fdf4; border-left:4px solid #16a34a;">
      <div>
        <span style="color:#16a34a; font-weight:bold; font-size:1.1rem;">🟢 Activa</span> — 
        <strong>${data.supporterBlessing.daysRemaining}</strong> días restantes
        (Total contratado: ${data.supporterBlessing.totalDays || 30} días, Diario: ${data.supporterBlessing.dailyAmount || 30} KvR/día)
        <br><small style="color:#64748b;">Activada: ${data.supporterBlessing.activatedAt ? new Date(data.supporterBlessing.activatedAt).toLocaleString() : 'N/A'} | Último reclamo: ${data.supporterBlessing.lastClaimCycle || 'Ninguno'}</small>
      </div>
      <button onclick="removeBlessing('${username}')" style="background:#dc2626; color:#fff; border:none; padding:0.5rem 1rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.9rem;">
        ❌ Eliminar Bendición
      </button>
    </div>
  ` : `
    <div class="info-box" style="color:#64748b;">
      ⚪ No tiene ninguna bendición activa.
    </div>
  `}
</div>

<div class="section">
  <h2>🪙 Dinero</h2>
  <div class="info-box" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px;">
    <div><strong>Coins:</strong> <span style="font-size:1.15rem; font-weight:bold;">${data.wallet?.coins || 0}</span></div>
    <div style="display:flex; gap:6px; align-items:center;">
      <input type="number" id="deductCoinsInput" placeholder="Cantidad a quitar" min="1" max="${data.wallet?.coins || 0}" style="padding:0.4rem 0.6rem; border:1px solid #ccc; border-radius:4px; width:150px; font-size:0.9rem;">
      <button onclick="deductCurrency('${username}', 'coins')" style="background:#dc2626; color:#fff; border:none; padding:0.45rem 0.9rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.85rem;">➖ Quitar Coins</button>
    </div>
  </div>
  <div class="info-box" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px;">
    <div><strong>KvR:</strong> <span style="font-size:1.15rem; font-weight:bold;">${data.wallet?.kvr || 0}</span></div>
    <div style="display:flex; gap:6px; align-items:center;">
      <input type="number" id="deductKvrInput" placeholder="Cantidad a quitar" min="1" max="${data.wallet?.kvr || 0}" style="padding:0.4rem 0.6rem; border:1px solid #ccc; border-radius:4px; width:150px; font-size:0.9rem;">
      <button onclick="deductCurrency('${username}', 'kvr')" style="background:#dc2626; color:#fff; border:none; padding:0.45rem 0.9rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.85rem;">➖ Quitar KvR</button>
    </div>
  </div>
  <div class="info-box">
    <strong>Infinite Coins:</strong> ${data.wallet?.['infinite-coins'] || 0}
  </div>
  <div class="info-box">
    <strong>Infinite Cardpoints:</strong> ${data.wallet?.['infinite-cardpoints'] || 0}
  </div>
  <div class="info-box" style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px;">
    <div><strong>Traits:</strong> <span style="font-size:1.15rem; font-weight:bold;">${data.wallet?.traits || 0}</span></div>
    <div style="display:flex; gap:12px; align-items:center; flex-wrap:wrap;">
      <div style="display:flex; gap:6px; align-items:center;">
        <input type="number" id="giveTraitsInput" placeholder="Cantidad a dar" min="1" value="1" style="padding:0.4rem 0.6rem; border:1px solid #ccc; border-radius:4px; width:120px; font-size:0.9rem;">
        <button onclick="giveTraitsCurrency('${username}')" style="background:#16a34a; color:#fff; border:none; padding:0.45rem 0.9rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.85rem;">➕ Givear Traits</button>
      </div>
      <div style="display:flex; gap:6px; align-items:center;">
        <input type="number" id="deductTraitsInput" placeholder="Cantidad a quitar" min="1" max="${data.wallet?.traits || 0}" style="padding:0.4rem 0.6rem; border:1px solid #ccc; border-radius:4px; width:120px; font-size:0.9rem;">
        <button onclick="deductCurrency('${username}', 'traits')" style="background:#dc2626; color:#fff; border:none; padding:0.45rem 0.9rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.85rem;">➖ Quitar Traits</button>
      </div>
    </div>
  </div>
</div>

<div class="section">
  <h2>🎴 Cartas (${Object.keys(data.cards || {}).length} tipos)</h2>

  <div style="background:#f0fdf4; border:1px solid #86efac; border-radius:8px; padding:1.2rem; margin-bottom:1.5rem;">
    <h3 style="margin-top:0; margin-bottom:0.4rem; color:#166534; font-size:1.1rem; display:flex; align-items:center; gap:6px;">
      🎁 Givear Carta a ${username}
    </h3>
    <p style="margin-top:0; margin-bottom:0.8rem; color:#15803d; font-size:0.88rem;">
      Escribe o selecciona el ID de la carta para agregársela a este usuario. Se guardará en la nube y se transferirá localmente a su juego.
    </p>
    <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
      <div style="flex:1; min-width:240px;">
        <input type="text" id="giveCardId" list="cardCatalogList" placeholder="Escribe el ID de la carta (ej: ronan_hatake)" style="width:100%; box-sizing:border-box; padding:0.55rem 0.75rem; border:1px solid #86efac; border-radius:4px; font-size:0.95rem;">
        <datalist id="cardCatalogList">
          ${cardDatalistOptions}
        </datalist>
      </div>
      <div style="width:100px;">
        <input type="number" id="giveCardCount" value="1" min="1" max="999" placeholder="Cant." style="width:100%; box-sizing:border-box; padding:0.55rem 0.6rem; border:1px solid #86efac; border-radius:4px; font-size:0.95rem;">
      </div>
      <button onclick="giveCard('${username}')" style="background:#16a34a; color:#fff; border:none; padding:0.6rem 1.4rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.95rem; box-shadow:0 1px 2px rgba(0,0,0,0.1);">
        ➕ Givear Carta
      </button>
    </div>
  </div>

  ${Object.keys(data.cards || {}).length > 0 ? `
    <table>
      <thead>
        <tr>
          <th>Carta / ID</th>
          <th>Cantidad</th>
          <th style="width:240px; text-align:center;">Acciones Admin</th>
        </tr>
      </thead>
      <tbody>
        ${cardsRows}
      </tbody>
    </table>
  ` : '<p>Sin cartas</p>'}
</div>

<div class="section">
  <h2>📦 Sobres/Packs (${Object.keys(data.packs || {}).length} tipos)</h2>

  <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:1.2rem; margin-bottom:1.5rem;">
    <h3 style="margin-top:0; margin-bottom:0.4rem; color:#1e40af; font-size:1.1rem; display:flex; align-items:center; gap:6px;">
      🎁 Givear Sobre a ${username}
    </h3>
    <p style="margin-top:0; margin-bottom:0.8rem; color:#1d4ed8; font-size:0.88rem;">
      Escribe o selecciona el ID del sobre y la cantidad para otorgárselo. Se guardará en la nube y se transferirá localmente a su juego.
    </p>
    <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
      <div style="flex:1; min-width:240px;">
        <input type="text" id="givePackId" list="packCatalogList" placeholder="Escribe el ID del sobre (ej: sobres_oro)" style="width:100%; box-sizing:border-box; padding:0.55rem 0.75rem; border:1px solid #bfdbfe; border-radius:4px; font-size:0.95rem;">
        <datalist id="packCatalogList">
          ${packDatalistOptions}
        </datalist>
      </div>
      <div style="width:100px;">
        <input type="number" id="givePackCount" value="1" min="1" max="999" placeholder="Cant." style="width:100%; box-sizing:border-box; padding:0.55rem 0.6rem; border:1px solid #bfdbfe; border-radius:4px; font-size:0.95rem;">
      </div>
      <button onclick="givePack('${username}')" style="background:#2563eb; color:#fff; border:none; padding:0.6rem 1.4rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.95rem; box-shadow:0 1px 2px rgba(0,0,0,0.1);">
        ➕ Givear Sobre
      </button>
    </div>
  </div>

  ${Object.keys(data.packs || {}).length > 0 ? `
    <table>
      <thead>
        <tr>
          <th>ID de Pack</th>
          <th>Cantidad</th>
        </tr>
      </thead>
      <tbody>
        ${packsRows}
      </tbody>
    </table>
  ` : '<p>Sin packs</p>'}
</div>

<div class="section">
  <h2>🎖️ Títulos Desbloqueados (${(Array.isArray(data.unlockedTitles) ? data.unlockedTitles : ['novato']).length})</h2>
  <div style="background:#fefce8; border:1px solid #fef08a; border-radius:8px; padding:1.2rem; margin-bottom:1.5rem;">
    <h3 style="margin-top:0; margin-bottom:0.4rem; color:#854d0e; font-size:1.1rem; display:flex; align-items:center; gap:6px;">
      🎁 Givear Título a ${username}
    </h3>
    <p style="margin-top:0; margin-bottom:0.8rem; color:#a16207; font-size:0.88rem;">
      Escribe o selecciona el ID del título para desbloqueárselo a este usuario. Se guardará en la nube y se transferirá localmente a su juego.
    </p>
    <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
      <div style="flex:1; min-width:240px;">
        <input type="text" id="giveTitleId" list="titleCatalogList" placeholder="Escribe el ID del título (ej: knight_supporter)" style="width:100%; box-sizing:border-box; padding:0.55rem 0.75rem; border:1px solid #fef08a; border-radius:4px; font-size:0.95rem;">
        <datalist id="titleCatalogList">
          ${titleDatalistOptions}
        </datalist>
      </div>
      <button onclick="giveTitle('${username}')" style="background:#ca8a04; color:#fff; border:none; padding:0.6rem 1.4rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.95rem; box-shadow:0 1px 2px rgba(0,0,0,0.1);">
        ➕ Givear Título
      </button>
    </div>
  </div>
  <table>
    <thead>
      <tr>
        <th>Título / ID</th>
        <th>Estado</th>
      </tr>
    </thead>
    <tbody>
      ${titlesRows}
    </tbody>
  </table>
</div>

<div class="section">
  <h2>🧬 Rasgos / Traits Asignados (${Object.keys(data.cardTraits || {}).length})</h2>
  <div style="background:#f5f3ff; border:1px solid #ddd6fe; border-radius:8px; padding:1.2rem; margin-bottom:1.5rem;">
    <h3 style="margin-top:0; margin-bottom:0.4rem; color:#6d28d9; font-size:1.1rem; display:flex; align-items:center; gap:6px;">
      🎁 Asignar Trait a Carta de ${username}
    </h3>
    <p style="margin-top:0; margin-bottom:0.8rem; color:#7c3aed; font-size:0.88rem;">
      Selecciona la carta y el rasgo/trait para asignarlo directamente a este usuario. Se guardará en la nube y se sincronizará localmente con su juego.
    </p>
    <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
      <div style="flex:1; min-width:240px;">
        <input type="text" id="giveTraitCardId" list="cardCatalogList" placeholder="Escribe el ID de la carta (ej: ronan_hatake)" style="width:100%; box-sizing:border-box; padding:0.55rem 0.75rem; border:1px solid #ddd6fe; border-radius:4px; font-size:0.95rem;">
      </div>
      <div style="flex:1.5; min-width:280px;">
        <input type="text" id="giveTraitId" list="traitCatalogList" placeholder="Escribe o selecciona el Trait (ej: ninjutsu1)" style="width:100%; box-sizing:border-box; padding:0.55rem 0.75rem; border:1px solid #ddd6fe; border-radius:4px; font-size:0.95rem;">
        <datalist id="traitCatalogList">
          ${traitDatalistOptions}
        </datalist>
      </div>
      <button onclick="giveCardTrait('${username}')" style="background:#7c3aed; color:#fff; border:none; padding:0.6rem 1.4rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.95rem; box-shadow:0 1px 2px rgba(0,0,0,0.1);">
        ➕ Asignar Trait
      </button>
    </div>
  </div>

  ${Object.keys(data.cardTraits || {}).length > 0 ? `
    <table>
      <thead>
        <tr>
          <th>Carta / ID</th>
          <th>Rasgo / Trait</th>
          <th>Instance ID</th>
          <th style="width:140px; text-align:center;">Acciones Admin</th>
        </tr>
      </thead>
      <tbody>
        ${traitsRows}
      </tbody>
    </table>
  ` : '<p>Sin rasgos asignados</p>'}
</div>

<div class="section">
  <h2>⚡ Poderes</h2>
  <p><strong>Poderes en R2:</strong> ${JSON.stringify(data.powers || {})}</p>
  <p><strong>Total de poderes:</strong> ${Object.keys(data.powers || {}).length}</p>
  ${Object.keys(data.powers || {}).length > 0 ? `
    <table>
      <thead>
        <tr>
          <th>ID de Poder</th>
          <th>Tipo</th>
          <th>Usos/Estado</th>
        </tr>
      </thead>
      <tbody>
        ${Object.entries(data.powers || {}).map(([id, powerData]) => {
          const isPermanent = powerData.permanent === true;
          const tipo = isPermanent ? '♾️ Permanente' : '🔢 Consumible';
          const usos = isPermanent ? 'Siempre disponible' : `${powerData.uses || 0} usos`;
          return `<tr><td>${id}</td><td>${tipo}</td><td>${usos}</td></tr>`;
        }).join('')}
      </tbody>
    </table>
  ` : '<p style="color: red; font-weight: bold;">⚠️ NO HAY PODERES EN R2 - data.powers está vacío o undefined</p>'}
</div>

<div class="section">
  <h2>📊 Estadísticas</h2>
  <table>
    <tr>
      <td><strong>Total de Cartas Obtenidas:</strong></td>
      <td>${data.stats?.totalCardsObtained || 0}</td>
    </tr>
    <tr>
      <td><strong>Total de Packs Abiertos:</strong></td>
      <td>${data.stats?.totalPacksOpened || 0}</td>
    </tr>
    <tr>
      <td><strong>Total de Coins Ganados:</strong></td>
      <td>${data.stats?.totalCoinsEarned || 0}</td>
    </tr>
  </table>
</div>

<a href="/" class="back-link">← Volver a inicio</a>
</body></html>`;
    res.send(html);
  } catch (e) {
    res.status(500).send('Error: ' + String(e));
  }
});

// Basic UI (legacy, mainly for debugging)
app.get('/', requireAuth, async (req, res) => {
  try {
    const users = await listUsersFromR2();
    let usersData = [];
    for (const u of users) {
      const data = await readFromR2(userFileKey(u));
      usersData.push({ username: u, ...data });
    }
    
    const authParam = req.query.auth || '';

    // Card datalist for quick autocomplete
    let cardDatalistOptions = '';
    if (Array.isArray(draftCardsPool) && draftCardsPool.length > 0) {
      cardDatalistOptions = draftCardsPool
        .slice()
        .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id)))
        .map(c => `<option value="${c.id}">${c.name || c.id} (Media: ${c.media || '-'})</option>`)
        .join('');
    } else if (catalogIndex.cards && Object.keys(catalogIndex.cards).length > 0) {
      cardDatalistOptions = Object.entries(catalogIndex.cards)
        .sort((a, b) => String(a[1]).localeCompare(String(b[1])))
        .map(([id, name]) => `<option value="${id}">${name}</option>`)
        .join('');
    }

    // Pack datalist for quick autocomplete
    let packDatalistOptions = '';
    if (Array.isArray(draftPacksPool) && draftPacksPool.length > 0) {
      packDatalistOptions = draftPacksPool
        .slice()
        .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id)))
        .map(p => `<option value="${p.id}">${p.name || p.id} (${p.id})</option>`)
        .join('');
    } else if (catalogIndex.packs && Object.keys(catalogIndex.packs).length > 0) {
      packDatalistOptions = Object.entries(catalogIndex.packs)
        .sort((a, b) => String(a[1]).localeCompare(String(b[1])))
        .map(([id, name]) => `<option value="${id}">${name} (${id})</option>`)
        .join('');
    }

    // Title datalist for quick autocomplete
    let titleDatalistOptions = '';
    if (Array.isArray(draftTitlesPool) && draftTitlesPool.length > 0) {
      titleDatalistOptions = draftTitlesPool
        .slice()
        .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id)))
        .map(t => `<option value="${t.id}">${t.name || t.id} (${t.id})</option>`)
        .join('');
    }

    // Trait datalist for quick autocomplete
    let traitDatalistOptions = '';
    if (Array.isArray(draftTraitsPool) && draftTraitsPool.length > 0) {
      traitDatalistOptions = draftTraitsPool
        .slice()
        .sort((a, b) => String(a.name || a.id).localeCompare(String(b.name || b.id)))
        .map(t => `<option value="${t.id}">${t.name || t.id} (${t.rarity || 'común'}) - ${t.description || t.id}</option>`)
        .join('');
    }
    const rows = usersData.map(u => `
      <tr>
        <td>
          <a href="/user/${u.username}?auth=${authParam}">${u.username}</a>
          ${u.isAdmin ? '<span class="admin-user-pill">⭐ ADMIN</span>' : ''}
        </td>
        <td>${Object.keys(u.cards || {}).length}</td>
        <td>${Object.keys(u.packs || {}).length}</td>
        <td>${Object.keys(u.powers || {}).length}</td>
        <td>
          ${u.wallet?.coins || 0} Coins<br>
          ${u.wallet?.kvr || 0} KVR<br>
          ${u.wallet?.['infinite-coins'] || 0} Infinite Coins<br>
          ${u.wallet?.['infinite-cardpoints'] || 0} Infinite Cardpoints<br>
          ${u.wallet?.traits || 0} Traits
        </td>
        <td>${u.currentTitle || '-'}</td>
        <td>${new Date(u.updatedAt || 0).toLocaleString()}</td>
        <td>
          <button class="toggle-admin-btn ${u.isAdmin ? 'is-admin' : ''}" onclick="toggleAdmin('${u.username}', ${!u.isAdmin})">
            ${u.isAdmin ? '🛡️ Quitar Admin' : '⭐ Hacer Admin'}
          </button>
          <button class="reset-user-btn" onclick="resetUser('${u.username}')" title="Reiniciar toda la cuenta de fábrica (misiones, kizunas, cartas, monedas, códigos)">
            🔄 Reset
          </button>
          <button class="delete-btn" onclick="deleteUser('${u.username}')" title="Banear usuario">
            🗑️ Banear
          </button>
        </td>
      </tr>
    `).join('');
    
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>KVRCards Inventory (R2)</title>
<style>
  body { font-family: sans-serif; max-width: 1400px; margin: 2rem auto; padding: 1rem; }
  table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
  th, td { border: 1px solid #ddd; padding: 0.75rem; text-align: left; }
  th { background-color: #f2f2f2; font-weight: bold; }
  tr:hover { background-color: #f5f5f5; }
  a { color: #0066cc; text-decoration: none; font-weight: 600; }
  a:hover { text-decoration: underline; }
  .delete-btn { background: #dc2626; color: white; border: none; padding: 0.45rem 0.8rem; border-radius: 4px; cursor: pointer; font-size: 0.85rem; }
  .delete-btn:hover { background: #b91c1c; }
  .reset-user-btn { background: #ea580c; color: white; border: none; padding: 0.45rem 0.8rem; border-radius: 4px; cursor: pointer; font-size: 0.85rem; margin-right: 6px; font-weight: 600; }
  .reset-user-btn:hover { background: #c2410c; }
  .admin-badge { background: #10b981; color: white; padding: 0.25rem 0.75rem; border-radius: 4px; font-size: 0.9rem; margin-left: 1rem; }
  .admin-user-pill { background: #f59e0b; color: #000; font-weight: bold; font-size: 0.72rem; padding: 2px 6px; border-radius: 4px; margin-left: 6px; display: inline-block; vertical-align: middle; }
  .toggle-admin-btn { background: #2563eb; color: white; border: none; padding: 0.45rem 0.8rem; border-radius: 4px; cursor: pointer; font-size: 0.85rem; margin-right: 6px; font-weight: 600; }
  .toggle-admin-btn.is-admin { background: #f59e0b; color: #000; }
  .toggle-admin-btn:hover { opacity: 0.88; }
</style>
<script>
  async function toggleAdmin(username, makeAdmin) {
    const actionText = makeAdmin ? 'conceder permisos de ADMIN a' : 'quitar el rango ADMIN a';
    if (!confirm('¿Estás seguro de que deseas ' + actionText + ' "' + username + '"?')) {
      return;
    }
    try {
      const res = await fetch('/api/admin/toggle-admin/' + encodeURIComponent(username) + '?auth=${authParam}', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isAdmin: makeAdmin })
      });
      const result = await res.json();
      if (result.ok) {
        alert('Permisos de admin actualizados para "' + username + '"');
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo actualizar'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function resetUser(username) {
    if (!confirm('¿Estás seguro de que deseas REINICIAR DE FÁBRICA la cuenta de "' + username + '"? Se restablecerá todo su progreso a cero (cartas, sobres, monedas, misiones, entregables, kizunas, evoluciones, prestigios, códigos).')) return;
    if (!confirm('CONFIRMACIÓN DEFINITIVA: La cuenta de "' + username + '" quedará completamente limpia como recién registrada. ¿Confirmas el reinicio definitivo?')) return;

    try {
      const authParam = new URLSearchParams(window.location.search).get('auth') || 'kvcard';
      const res = await fetch('/api/admin/reset-user/' + encodeURIComponent(username) + '?auth=' + encodeURIComponent(authParam), {
        method: 'POST'
      });
      const result = await res.json();
      if (result.ok) {
        alert('Cuenta de "' + username + '" reiniciada de fábrica con éxito.');
        location.reload();
      } else {
        alert('Error: ' + (result.error || result.message || 'No se pudo reiniciar'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function deleteUser(username) {
    if (!confirm('¿Estás seguro de que quieres BANEAR (eliminar) al usuario "' + username + '"? Esta acción NO se puede deshacer.')) {
      return;
    }
    try {
      const res = await fetch('/api/admin/delete-user/' + username + '?auth=${authParam}', { method: 'DELETE' });
      const result = await res.json();
      if (result.ok) {
        alert('Usuario ' + username + ' eliminado correctamente');
        location.reload();
      } else {
        alert('Error: ' + result.error);
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function quickGiveCard() {
    const userSelect = document.getElementById('quickUser');
    const cardIdInput = document.getElementById('quickCardId');
    const countInput = document.getElementById('quickCardCount');
    const username = (userSelect.value || '').trim();
    const cardId = (cardIdInput.value || '').trim();
    const count = parseInt(countInput.value, 10);

    if (!username) {
      alert('Por favor selecciona un usuario.');
      userSelect.focus();
      return;
    }
    if (!cardId) {
      alert('Por favor escribe o selecciona el ID de la carta.');
      cardIdInput.focus();
      return;
    }
    if (isNaN(count) || count <= 0) {
      alert('Por favor introduce una cantidad válida (mínimo 1).');
      countInput.focus();
      return;
    }

    if (!confirm('¿Givear ' + count + ' copia(s) de la carta "' + cardId + '" a "' + username + '"?')) return;

    try {
      const res = await fetch('/api/admin/give-card/' + encodeURIComponent(username) + '?auth=${authParam}', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cardId, count })
      });
      const result = await res.json();
      if (result.ok) {
        alert('¡Carta entregada con éxito a ' + username + '! Cantidad total actual: ' + result.total);
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo givear la carta'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function quickGivePack() {
    const userSelect = document.getElementById('quickUserPack');
    const packIdInput = document.getElementById('quickPackId');
    const countInput = document.getElementById('quickPackCount');
    const username = (userSelect.value || '').trim();
    const packId = (packIdInput.value || '').trim();
    const count = parseInt(countInput.value, 10);

    if (!username) {
      alert('Por favor selecciona un usuario.');
      userSelect.focus();
      return;
    }
    if (!packId) {
      alert('Por favor escribe o selecciona el ID del sobre.');
      packIdInput.focus();
      return;
    }
    if (isNaN(count) || count <= 0) {
      alert('Por favor introduce una cantidad válida (mínimo 1).');
      countInput.focus();
      return;
    }

    if (!confirm('¿Givear ' + count + ' sobre(s) "' + packId + '" a "' + username + '"?')) return;

    try {
      const res = await fetch('/api/admin/give-pack/' + encodeURIComponent(username) + '?auth=${authParam}', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ packId, count })
      });
      const result = await res.json();
      if (result.ok) {
        alert('¡Sobre(s) entregado(s) con éxito a ' + username + '! Total actual: ' + result.total);
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo givear el sobre'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function quickGiveTitle() {
    const userSelect = document.getElementById('quickUserTitle');
    const titleIdInput = document.getElementById('quickTitleId');
    const username = (userSelect.value || '').trim();
    const titleId = (titleIdInput.value || '').trim();

    if (!username) {
      alert('Por favor selecciona un usuario.');
      userSelect.focus();
      return;
    }
    if (!titleId) {
      alert('Por favor escribe o selecciona el ID del título.');
      titleIdInput.focus();
      return;
    }

    if (!confirm('¿Desbloquear el título "' + titleId + '" a "' + username + '"?')) return;

    try {
      const res = await fetch('/api/admin/give-title/' + encodeURIComponent(username) + '?auth=${authParam}', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ titleId })
      });
      const result = await res.json();
      if (result.ok) {
        alert('¡Título desbloqueado con éxito para ' + username + '!');
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo givear el título'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function quickGiveTraits() {
    const userSelect = document.getElementById('quickUserTraits');
    const amountInput = document.getElementById('quickTraitsAmount');
    const username = (userSelect.value || '').trim();
    const amount = parseInt(amountInput.value, 10);

    if (!username) {
      alert('Por favor selecciona un usuario.');
      userSelect.focus();
      return;
    }
    if (isNaN(amount) || amount <= 0) {
      alert('Por favor introduce una cantidad válida (mínimo 1).');
      amountInput.focus();
      return;
    }

    if (!confirm('¿Givear ' + amount + ' Traits a "' + username + '"?')) return;

    try {
      const res = await fetch('/api/admin/give-traits/' + encodeURIComponent(username) + '?auth=${authParam}', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount })
      });
      const result = await res.json();
      if (result.ok) {
        alert('¡Traits entregados con éxito a ' + username + '! Total actual: ' + result.total);
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo givear traits'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }

  async function quickGiveCardTrait() {
    const userSelect = document.getElementById('quickUserCardTrait');
    const cardIdInput = document.getElementById('quickCardTraitCardId');
    const traitIdInput = document.getElementById('quickCardTraitTraitId');
    const username = (userSelect.value || '').trim();
    const cardId = (cardIdInput.value || '').trim();
    const traitId = (traitIdInput.value || '').trim();

    if (!username) {
      alert('Por favor selecciona un usuario.');
      userSelect.focus();
      return;
    }
    if (!cardId) {
      alert('Por favor escribe o selecciona el ID de la carta.');
      cardIdInput.focus();
      return;
    }
    if (!traitId) {
      alert('Por favor escribe o selecciona el ID del rasgo/trait.');
      traitIdInput.focus();
      return;
    }

    if (!confirm('¿Asignar rasgo "' + traitId + '" a la carta "' + cardId + '" para "' + username + '"?')) return;

    try {
      const res = await fetch('/api/admin/give-card-trait/' + encodeURIComponent(username) + '?auth=${authParam}', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cardId, traitId })
      });
      const result = await res.json();
      if (result.ok) {
        alert('¡Rasgo asignado con éxito a la carta de ' + username + '!');
        location.reload();
      } else {
        alert('Error: ' + (result.error || 'No se pudo asignar el rasgo'));
      }
    } catch (e) {
      alert('Error de conexión: ' + e.message);
    }
  }
</script>
</head>
<body>
<h1>KVRCards Inventory Server (R2) <span class="admin-badge">🔓 Admin Mode</span></h1>
<p><strong>Storage:</strong> Cloudflare R2 (${R2_BUCKET_NAME})</p>
<p><strong>Total Users:</strong> ${users.length}</p>

<div style="background:#f0fdf4; border:1px solid #86efac; border-radius:8px; padding:1.2rem; margin:1.5rem 0; box-shadow:0 1px 3px rgba(0,0,0,0.05);">
  <h2 style="color:#166534; margin-top:0; margin-bottom:0.4rem; font-size:1.15rem;">🎁 Givear Carta Rápida</h2>
  <p style="color:#15803d; margin-top:0; margin-bottom:0.8rem; font-size:0.88rem;">
    Selecciona un jugador, escribe el ID de la carta y la cantidad para otorgársela directamente. Se sincronizará localmente con su juego.
  </p>
  <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
    <select id="quickUser" style="padding:0.55rem 0.75rem; border:1px solid #86efac; border-radius:4px; font-size:0.95rem; min-width:180px;">
      <option value="">-- Seleccionar Usuario --</option>
      ${usersData.map(u => `<option value="${u.username}">${u.username}</option>`).join('')}
    </select>
    <div style="flex:1; min-width:240px;">
      <input type="text" id="quickCardId" list="cardCatalogListGlobal" placeholder="Escribe el ID de la carta (ej: ronan_hatake)" style="width:100%; box-sizing:border-box; padding:0.55rem 0.75rem; border:1px solid #86efac; border-radius:4px; font-size:0.95rem;">
      <datalist id="cardCatalogListGlobal">
        ${cardDatalistOptions}
      </datalist>
    </div>
    <div style="width:90px;">
      <input type="number" id="quickCardCount" value="1" min="1" max="999" style="width:100%; box-sizing:border-box; padding:0.55rem 0.6rem; border:1px solid #86efac; border-radius:4px; font-size:0.95rem;">
    </div>
    <button onclick="quickGiveCard()" style="background:#16a34a; color:#fff; border:none; padding:0.6rem 1.4rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.95rem; box-shadow:0 1px 2px rgba(0,0,0,0.1);">
      ➕ Givear Carta
    </button>
  </div>
</div>

<div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px; padding:1.2rem; margin:1.5rem 0; box-shadow:0 1px 3px rgba(0,0,0,0.05);">
  <h2 style="color:#1e40af; margin-top:0; margin-bottom:0.4rem; font-size:1.15rem;">🎁 Givear Sobre Rápido</h2>
  <p style="color:#1d4ed8; margin-top:0; margin-bottom:0.8rem; font-size:0.88rem;">
    Selecciona un jugador, escribe el ID del sobre y la cantidad para otorgárselo directamente. Se sincronizará localmente con su juego.
  </p>
  <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
    <select id="quickUserPack" style="padding:0.55rem 0.75rem; border:1px solid #bfdbfe; border-radius:4px; font-size:0.95rem; min-width:180px;">
      <option value="">-- Seleccionar Usuario --</option>
      ${usersData.map(u => `<option value="${u.username}">${u.username}</option>`).join('')}
    </select>
    <div style="flex:1; min-width:240px;">
      <input type="text" id="quickPackId" list="packCatalogListGlobal" placeholder="Escribe el ID del sobre (ej: sobres_oro)" style="width:100%; box-sizing:border-box; padding:0.55rem 0.75rem; border:1px solid #bfdbfe; border-radius:4px; font-size:0.95rem;">
      <datalist id="packCatalogListGlobal">
        ${packDatalistOptions}
      </datalist>
    </div>
    <div style="width:90px;">
      <input type="number" id="quickPackCount" value="1" min="1" max="999" style="width:100%; box-sizing:border-box; padding:0.55rem 0.6rem; border:1px solid #bfdbfe; border-radius:4px; font-size:0.95rem;">
    </div>
    <button onclick="quickGivePack()" style="background:#2563eb; color:#fff; border:none; padding:0.6rem 1.4rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.95rem; box-shadow:0 1px 2px rgba(0,0,0,0.1);">
      ➕ Givear Sobre
    </button>
  </div>
</div>

<div style="background:#fefce8; border:1px solid #fef08a; border-radius:8px; padding:1.2rem; margin:1.5rem 0; box-shadow:0 1px 3px rgba(0,0,0,0.05);">
  <h2 style="color:#854d0e; margin-top:0; margin-bottom:0.4rem; font-size:1.15rem;">🎁 Givear Título Rápido</h2>
  <p style="color:#a16207; margin-top:0; margin-bottom:0.8rem; font-size:0.88rem;">
    Selecciona un jugador y escribe el ID del título para desbloqueárselo directamente. Se sincronizará localmente con su juego.
  </p>
  <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
    <select id="quickUserTitle" style="padding:0.55rem 0.75rem; border:1px solid #fef08a; border-radius:4px; font-size:0.95rem; min-width:180px;">
      <option value="">-- Seleccionar Usuario --</option>
      ${usersData.map(u => `<option value="${u.username}">${u.username}</option>`).join('')}
    </select>
    <div style="flex:1; min-width:240px;">
      <input type="text" id="quickTitleId" list="titleCatalogListGlobal" placeholder="Escribe el ID del título (ej: knight_supporter)" style="width:100%; box-sizing:border-box; padding:0.55rem 0.75rem; border:1px solid #fef08a; border-radius:4px; font-size:0.95rem;">
      <datalist id="titleCatalogListGlobal">
        ${titleDatalistOptions}
      </datalist>
    </div>
    <button onclick="quickGiveTitle()" style="background:#ca8a04; color:#fff; border:none; padding:0.6rem 1.4rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.95rem; box-shadow:0 1px 2px rgba(0,0,0,0.1);">
      ➕ Givear Título
    </button>
  </div>
</div>

<div style="background:#f5f3ff; border:1px solid #ddd6fe; border-radius:8px; padding:1.2rem; margin:1.5rem 0; box-shadow:0 1px 3px rgba(0,0,0,0.05);">
  <h2 style="color:#6d28d9; margin-top:0; margin-bottom:0.4rem; font-size:1.15rem;">🧬 Givear Puntos de Traits Rápido</h2>
  <p style="color:#7c3aed; margin-top:0; margin-bottom:0.8rem; font-size:0.88rem;">
    Selecciona un jugador e introduce la cantidad de puntos de Traits para otorgárselos. Podrá usarlos en la ruleta de rasgos de su juego.
  </p>
  <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
    <select id="quickUserTraits" style="padding:0.55rem 0.75rem; border:1px solid #ddd6fe; border-radius:4px; font-size:0.95rem; min-width:180px;">
      <option value="">-- Seleccionar Usuario --</option>
      ${usersData.map(u => `<option value="${u.username}">${u.username}</option>`).join('')}
    </select>
    <div style="width:120px;">
      <input type="number" id="quickTraitsAmount" value="5" min="1" max="99999" placeholder="Cantidad" style="width:100%; box-sizing:border-box; padding:0.55rem 0.6rem; border:1px solid #ddd6fe; border-radius:4px; font-size:0.95rem;">
    </div>
    <button onclick="quickGiveTraits()" style="background:#7c3aed; color:#fff; border:none; padding:0.6rem 1.4rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.95rem; box-shadow:0 1px 2px rgba(0,0,0,0.1);">
      ➕ Givear Traits
    </button>
  </div>
</div>

<div style="background:#faf5ff; border:1px solid #e9d5ff; border-radius:8px; padding:1.2rem; margin:1.5rem 0; box-shadow:0 1px 3px rgba(0,0,0,0.05);">
  <h2 style="color:#7e22ce; margin-top:0; margin-bottom:0.4rem; font-size:1.15rem;">🧬 Asignar Trait a Carta Rápido</h2>
  <p style="color:#9333ea; margin-top:0; margin-bottom:0.8rem; font-size:0.88rem;">
    Selecciona un jugador, la carta y el rasgo/trait específico para asignárselo de inmediato. Se sincronizará localmente con su juego.
  </p>
  <div style="display:flex; flex-wrap:wrap; gap:10px; align-items:center;">
    <select id="quickUserCardTrait" style="padding:0.55rem 0.75rem; border:1px solid #e9d5ff; border-radius:4px; font-size:0.95rem; min-width:180px;">
      <option value="">-- Seleccionar Usuario --</option>
      ${usersData.map(u => `<option value="${u.username}">${u.username}</option>`).join('')}
    </select>
    <div style="flex:1; min-width:220px;">
      <input type="text" id="quickCardTraitCardId" list="cardCatalogListGlobal" placeholder="ID de la carta (ej: ronan_hatake)" style="width:100%; box-sizing:border-box; padding:0.55rem 0.75rem; border:1px solid #e9d5ff; border-radius:4px; font-size:0.95rem;">
    </div>
    <div style="flex:1.5; min-width:260px;">
      <input type="text" id="quickCardTraitTraitId" list="traitCatalogListGlobal" placeholder="Escribe o selecciona el Trait (ej: ninjutsu1)" style="width:100%; box-sizing:border-box; padding:0.55rem 0.75rem; border:1px solid #e9d5ff; border-radius:4px; font-size:0.95rem;">
      <datalist id="traitCatalogListGlobal">
        ${traitDatalistOptions}
      </datalist>
    </div>
    <button onclick="quickGiveCardTrait()" style="background:#9333ea; color:#fff; border:none; padding:0.6rem 1.4rem; border-radius:4px; cursor:pointer; font-weight:bold; font-size:0.95rem; box-shadow:0 1px 2px rgba(0,0,0,0.1);">
      ➕ Asignar Trait
    </button>
  </div>
</div>
<table>
  <thead>
    <tr>
      <th>Username</th>
      <th>Cards</th>
      <th>Packs</th>
      <th>Powers</th>
      <th>Coins</th>
      <th>Title</th>
      <th>Updated</th>
      <th>Actions</th>
    </tr>
  </thead>
  <tbody>
    ${rows}
  </tbody>
</table>
</body></html>`;
    res.send(html);
  } catch (e) {
    res.status(500).send('Error: ' + String(e));
  }
});

// ---- Admin Endpoints ----

// Toggle admin status (admin only)
app.all('/api/admin/toggle-admin/:username', requireAuth, async (req, res) => {
  try {
    const username = String(req.params.username || '').trim();
    if (!username) return res.status(400).json({ error: 'Username required' });
    
    const key = userFileKey(username);
    const data = await readFromR2(key);
    if (!data) return res.status(404).json({ error: 'User not found' });
    
    const newState = (req.body && req.body.isAdmin !== undefined)
      ? Boolean(req.body.isAdmin)
      : (req.query.isAdmin !== undefined ? req.query.isAdmin === 'true' : !data.isAdmin);
    
    data.isAdmin = newState;
    data.updatedAt = Date.now();
    await writeToR2(key, data);
    console.log(`[ADMIN] User ${username} admin status set to: ${newState}`);
    return res.json({ ok: true, username, isAdmin: newState });
  } catch (e) {
    console.error('[ADMIN] Error toggling admin:', e);
    return res.status(500).json({ error: String(e) });
  }
});

// Delete user (admin only)
app.delete('/api/admin/delete-user/:username', requireAuth, async (req, res) => {
  try {
    const username = req.params.username;
    if (!username) return res.status(400).json({ error: 'Username required' });
    
    const key = userFileKey(username);
    await deleteFromR2(key);
    
    console.log('[ADMIN] User deleted:', username);
    res.json({ ok: true, message: `User ${username} deleted successfully` });
  } catch (e) {
    console.error('[ADMIN] Error deleting user:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Reset user account to factory defaults (admin only)
app.all('/api/admin/reset-user/:username', requireAuth, async (req, res) => {
  try {
    const username = String(req.params.username || '').trim();
    if (!username) return res.status(400).json({ error: 'Username required' });

    const key = userFileKey(username);
    const existing = await readFromR2(key);
    if (!existing) return res.status(404).json({ error: 'User not found' });

    const now = Date.now();
    const resetUser = {
      username: existing.username || username,
      password: existing.password || '',
      cards: {},
      packs: {},
      cardTraits: {},
      cardUpgrades: {},
      powers: {},
      wallet: { coins: 0, kvr: 0, traits: 0, 'infinite-coins': 0, 'infinite-cardpoints': 0 },
      stats: { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0, battlesWon: 0, total_upgrades_success: 0 },
      weeklyStats: { cards: 0, packs: 0, coins: 0, weekStart: getCurrentMondayTimestamp() },
      profileImage: '',
      currentTitle: 'Novato',
      unlockedTitles: ['novato'],
      currentBackground: 'default',
      unlockedBackgrounds: ['default'],
      showcaseCards: [null, null, null],
      friends: Array.isArray(existing.friends) ? existing.friends : [],
      friendRequests: [],
      sentRequests: [],
      missions: {},
      userMissions: {},
      completedDeliverables: [],
      deliverableCompletions: {},
      deliverableDailyCompletions: {},
      packPurchases: {},
      redeemedCodes: [],
      supporterBlessing: null,
      infiniteRun: null,
      infiniteRankings: { historicalBest: 0, seasonBestById: {}, lastSeasonId: '', updatedAt: now },
      kizunas: {},
      userKizunas: {},
      evolutions: {},
      userEvolutions: {},
      userEvolutions_v2: {},
      prestige: {},
      cardPrestige: {},
      prestigeProgress: {},
      completedEvents: [],
      events: [],
      deck: [],
      savedDecks: {},
      decks: {},
      isAdmin: existing.isAdmin === true,
      settings: {
        theme: { active: 'default', customTheme: null }
      },
      updatedAt: now,
      resetAt: now,
      isReset: true
    };

    await writeToR2(key, resetUser);

    try {
      const cloudUsersPath = path.join(__dirname, 'cloud-data', 'users.json');
      if (fs.existsSync(cloudUsersPath)) {
        const usersMap = JSON.parse(fs.readFileSync(cloudUsersPath, 'utf-8'));
        if (usersMap && usersMap[username]) {
          usersMap[username] = resetUser;
          fs.writeFileSync(cloudUsersPath, JSON.stringify(usersMap, null, 2), 'utf-8');
        }
      }
    } catch (eLocal) {}

    console.log(`[ADMIN RESET] Usuario ${username} reiniciado de fábrica en R2 por el admin`);
    return res.json({ ok: true, message: `Usuario "${username}" reiniciado de fábrica correctamente`, user: resetUser });
  } catch (e) {
    console.error('[ADMIN RESET] Error resetting user:', e);
    return res.status(500).json({ error: String(e) });
  }
});

// ==================== ADMIN DEDUCTIONS & BLESSING MANAGEMENT ====================

// Remove supporter blessing (admin only)
app.all('/api/admin/remove-blessing/:username', requireAuth, async (req, res) => {
  try {
    const username = String(req.params.username || '').trim();
    if (!username) return res.status(400).json({ error: 'Username required' });

    const key = userFileKey(username);
    const data = await readFromR2(key);
    if (!data) return res.status(404).json({ error: 'User not found' });

    data.supporterBlessing = null;
    if (!Array.isArray(data.adminDeductions)) {
      data.adminDeductions = [];
    }
    const deduction = {
      id: `deduct_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      type: 'clear-blessing',
      timestamp: Date.now()
    };
    data.adminDeductions.push(deduction);
    data.updatedAt = Date.now();

    await writeToR2(key, data);
    console.log(`[ADMIN] Blessing removed for ${username}`);
    return res.json({ ok: true, message: 'Bendición del supporter eliminada correctamente', deduction });
  } catch (e) {
    console.error('[ADMIN] Error removing blessing:', e);
    return res.status(500).json({ error: String(e) });
  }
});

// Deduct currency (coins or kvr) (admin only)
app.all('/api/admin/deduct-currency/:username', requireAuth, async (req, res) => {
  try {
    const username = String(req.params.username || '').trim();
    if (!username) return res.status(400).json({ error: 'Username required' });

    const type = String(req.body?.type || req.query?.type || 'coins').toLowerCase();
    const amount = Math.max(1, Number(req.body?.amount || req.query?.amount) || 0);
    if (amount <= 0) return res.status(400).json({ error: 'Monto a quitar inválido' });

    const key = userFileKey(username);
    const data = await readFromR2(key);
    if (!data) return res.status(404).json({ error: 'User not found' });

    if (!data.wallet || typeof data.wallet !== 'object') {
      data.wallet = { coins: 0, kvr: 0, traits: 0, 'infinite-coins': 0, 'infinite-cardpoints': 0 };
    }

    if (type === 'kvr') {
      const prev = Number(data.wallet.kvr) || 0;
      data.wallet.kvr = Math.max(0, prev - amount);
    } else if (type === 'traits') {
      const prev = Number(data.wallet.traits) || 0;
      data.wallet.traits = Math.max(0, prev - amount);
    } else {
      const prev = Number(data.wallet.coins) || 0;
      data.wallet.coins = Math.max(0, prev - amount);
    }

    if (!Array.isArray(data.adminDeductions)) {
      data.adminDeductions = [];
    }
    const deduction = {
      id: `deduct_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      type: type === 'kvr' ? 'remove-kvr' : (type === 'traits' ? 'remove-traits' : 'remove-coins'),
      amount: amount,
      timestamp: Date.now()
    };
    data.adminDeductions.push(deduction);
    data.updatedAt = Date.now();

    await writeToR2(key, data);
    console.log(`[ADMIN] Deducted ${amount} ${type} for ${username}. Remaining:`, data.wallet);
    return res.json({ ok: true, wallet: data.wallet, deduction });
  } catch (e) {
    console.error('[ADMIN] Error deducting currency:', e);
    return res.status(500).json({ error: String(e) });
  }
});

// Remove card copies (admin only)
app.all('/api/admin/remove-card/:username', requireAuth, async (req, res) => {
  try {
    const username = String(req.params.username || '').trim();
    if (!username) return res.status(400).json({ error: 'Username required' });

    const cardId = String(req.body?.cardId || req.query?.cardId || '').trim();
    const count = Math.max(1, Number(req.body?.count || req.query?.count) || 1);
    if (!cardId) return res.status(400).json({ error: 'cardId requerido' });

    const key = userFileKey(username);
    const data = await readFromR2(key);
    if (!data) return res.status(404).json({ error: 'User not found' });

    if (!data.cards || typeof data.cards !== 'object') {
      data.cards = {};
    }

    const currentCount = Number(data.cards[cardId]) || 0;
    const actualToRemove = Math.min(currentCount, count);
    if (currentCount <= actualToRemove) {
      delete data.cards[cardId];
    } else {
      data.cards[cardId] = currentCount - actualToRemove;
    }

    if (!Array.isArray(data.adminDeductions)) {
      data.adminDeductions = [];
    }
    const deduction = {
      id: `deduct_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      type: 'remove-card',
      cardId: cardId,
      count: actualToRemove,
      timestamp: Date.now()
    };
    data.adminDeductions.push(deduction);
    data.updatedAt = Date.now();

    await writeToR2(key, data);
    console.log(`[ADMIN] Removed ${actualToRemove} copies of ${cardId} for ${username}. Remaining:`, data.cards[cardId] || 0);
    return res.json({ ok: true, remaining: data.cards[cardId] || 0, deduction });
  } catch (e) {
    console.error('[ADMIN] Error removing card:', e);
    return res.status(500).json({ error: String(e) });
  }
});

// Give card copies to user (admin only)
app.all('/api/admin/give-card/:username?', requireAuth, async (req, res) => {
  try {
    const username = String(req.params.username || req.body?.username || req.query?.username || '').trim();
    if (!username) return res.status(400).json({ error: 'Username required' });

    const cardId = String(req.body?.cardId || req.query?.cardId || '').trim();
    const count = Math.max(1, Number(req.body?.count || req.query?.count) || 1);
    if (!cardId) return res.status(400).json({ error: 'cardId requerido' });

    const key = userFileKey(username);
    const data = await readFromR2(key);
    if (!data) return res.status(404).json({ error: 'User not found' });

    if (!data.cards || typeof data.cards !== 'object') {
      data.cards = {};
    }

    const currentCount = Number(data.cards[cardId]) || 0;
    const newTotal = currentCount + count;
    data.cards[cardId] = newTotal;

    if (!Array.isArray(data.adminDeductions)) {
      data.adminDeductions = [];
    }
    const action = {
      id: `give_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      type: 'give-card',
      cardId: cardId,
      count: count,
      timestamp: Date.now()
    };
    data.adminDeductions.push(action);
    data.updatedAt = Date.now();

    await writeToR2(key, data);
    console.log(`[ADMIN] Gave ${count} copies of ${cardId} to ${username}. Total:`, newTotal);
    return res.json({ ok: true, total: newTotal, count, cardId, action });
  } catch (e) {
    console.error('[ADMIN] Error giving card:', e);
    return res.status(500).json({ error: String(e) });
  }
});

// Give packs to user (admin only)
app.all('/api/admin/give-pack/:username?', requireAuth, async (req, res) => {
  try {
    const username = String(req.params.username || req.body?.username || req.query?.username || '').trim();
    if (!username) return res.status(400).json({ error: 'Username required' });

    const packId = String(req.body?.packId || req.query?.packId || '').trim();
    const count = Math.max(1, Number(req.body?.count || req.query?.count) || 1);
    if (!packId) return res.status(400).json({ error: 'packId requerido' });

    const key = userFileKey(username);
    const data = await readFromR2(key);
    if (!data) return res.status(404).json({ error: 'User not found' });

    if (!data.packs || typeof data.packs !== 'object') {
      data.packs = {};
    }

    const currentCount = Number(data.packs[packId]) || 0;
    const newTotal = currentCount + count;
    data.packs[packId] = newTotal;

    if (!Array.isArray(data.adminDeductions)) {
      data.adminDeductions = [];
    }
    const action = {
      id: `give_pack_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      type: 'give-pack',
      packId: packId,
      count: count,
      timestamp: Date.now()
    };
    data.adminDeductions.push(action);
    data.updatedAt = Date.now();

    await writeToR2(key, data);
    console.log(`[ADMIN] Gave ${count} packs of ${packId} to ${username}. Total:`, newTotal);
    return res.json({ ok: true, total: newTotal, count, packId, action });
  } catch (e) {
    console.error('[ADMIN] Error giving pack:', e);
    return res.status(500).json({ error: String(e) });
  }
});

// Give title to user (admin only)
app.all('/api/admin/give-title/:username?', requireAuth, async (req, res) => {
  try {
    const username = String(req.params.username || req.body?.username || req.query?.username || '').trim();
    if (!username) return res.status(400).json({ error: 'Username required' });

    const titleId = String(req.body?.titleId || req.body?.title || req.query?.titleId || req.query?.title || '').trim().toLowerCase();
    if (!titleId) return res.status(400).json({ error: 'titleId requerido' });

    const key = userFileKey(username);
    const data = await readFromR2(key);
    if (!data) return res.status(404).json({ error: 'User not found' });

    if (!Array.isArray(data.unlockedTitles)) {
      data.unlockedTitles = ['novato'];
    }

    if (!data.unlockedTitles.includes(titleId)) {
      data.unlockedTitles.push(titleId);
    }

    if (!Array.isArray(data.adminDeductions)) {
      data.adminDeductions = [];
    }
    const action = {
      id: `give_title_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      type: 'give-title',
      titleId: titleId,
      timestamp: Date.now()
    };
    data.adminDeductions.push(action);
    data.updatedAt = Date.now();

    await writeToR2(key, data);
    console.log(`[ADMIN] Gave title ${titleId} to ${username}. Unlocked:`, data.unlockedTitles);
    return res.json({ ok: true, titleId, unlockedTitles: data.unlockedTitles, action });
  } catch (e) {
    console.error('[ADMIN] Error giving title:', e);
    return res.status(500).json({ error: String(e) });
  }
});

// Give traits currency to user (admin only)
app.all('/api/admin/give-traits/:username?', requireAuth, async (req, res) => {
  try {
    const username = String(req.params.username || req.body?.username || req.query?.username || '').trim();
    if (!username) return res.status(400).json({ error: 'Username required' });

    const amount = Math.max(1, Number(req.body?.amount || req.query?.amount) || 1);

    const key = userFileKey(username);
    const data = await readFromR2(key);
    if (!data) return res.status(404).json({ error: 'User not found' });

    if (!data.wallet || typeof data.wallet !== 'object') {
      data.wallet = { coins: 0, kvr: 0, traits: 0, 'infinite-coins': 0, 'infinite-cardpoints': 0 };
    }

    const currentTraits = Number(data.wallet.traits) || 0;
    const newTotal = currentTraits + amount;
    data.wallet.traits = newTotal;

    if (!Array.isArray(data.adminDeductions)) {
      data.adminDeductions = [];
    }
    const action = {
      id: `give_traits_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      type: 'give-traits',
      amount: amount,
      timestamp: Date.now()
    };
    data.adminDeductions.push(action);
    data.updatedAt = Date.now();

    await writeToR2(key, data);
    console.log(`[ADMIN] Gave ${amount} traits to ${username}. Total:`, newTotal);
    return res.json({ ok: true, total: newTotal, amount, action });
  } catch (e) {
    console.error('[ADMIN] Error giving traits:', e);
    return res.status(500).json({ error: String(e) });
  }
});

// Give/assign trait to a card for user (admin only)
app.all('/api/admin/give-card-trait/:username?', requireAuth, async (req, res) => {
  try {
    const username = String(req.params.username || req.body?.username || req.query?.username || '').trim();
    if (!username) return res.status(400).json({ error: 'Username required' });

    const cardId = String(req.body?.cardId || req.query?.cardId || '').trim();
    const traitId = String(req.body?.traitId || req.query?.traitId || '').trim();
    if (!cardId || !traitId) return res.status(400).json({ error: 'cardId y traitId requeridos' });

    const key = userFileKey(username);
    const data = await readFromR2(key);
    if (!data) return res.status(404).json({ error: 'User not found' });

    if (!data.cardTraits || typeof data.cardTraits !== 'object') {
      data.cardTraits = {};
    }
    if (!data.cards || typeof data.cards !== 'object') {
      data.cards = {};
    }

    if ((Number(data.cards[cardId]) || 0) < 1) {
      data.cards[cardId] = 1;
    }

    const instanceId = `trait_${cardId}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    data.cardTraits[instanceId] = { cardId, traitId };

    if (!Array.isArray(data.adminDeductions)) {
      data.adminDeductions = [];
    }
    const action = {
      id: `give_card_trait_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      type: 'give-card-trait',
      cardId,
      traitId,
      instanceId,
      timestamp: Date.now()
    };
    data.adminDeductions.push(action);
    data.updatedAt = Date.now();

    await writeToR2(key, data);
    console.log(`[ADMIN] Assigned trait ${traitId} to card ${cardId} (${instanceId}) for ${username}`);
    return res.json({ ok: true, cardId, traitId, instanceId, action });
  } catch (e) {
    console.error('[ADMIN] Error giving card trait:', e);
    return res.status(500).json({ error: String(e) });
  }
});

// Remove a trait instance from a user's card (admin only)
app.all('/api/admin/remove-card-trait/:username', requireAuth, async (req, res) => {
  try {
    const username = String(req.params.username || '').trim();
    if (!username) return res.status(400).json({ error: 'Username required' });

    const instanceId = String(req.body?.instanceId || req.query?.instanceId || '').trim();
    if (!instanceId) return res.status(400).json({ error: 'instanceId requerido' });

    const key = userFileKey(username);
    const data = await readFromR2(key);
    if (!data) return res.status(404).json({ error: 'User not found' });

    if (!data.cardTraits || typeof data.cardTraits !== 'object') {
      data.cardTraits = {};
    }

    const removed = data.cardTraits[instanceId];
    delete data.cardTraits[instanceId];

    if (!Array.isArray(data.adminDeductions)) {
      data.adminDeductions = [];
    }
    const action = {
      id: `remove_card_trait_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      type: 'remove-card-trait',
      instanceId,
      cardId: removed?.cardId,
      timestamp: Date.now()
    };
    data.adminDeductions.push(action);
    data.updatedAt = Date.now();

    await writeToR2(key, data);
    console.log(`[ADMIN] Removed trait instance ${instanceId} for ${username}`);
    return res.json({ ok: true, instanceId, removed, action });
  } catch (e) {
    console.error('[ADMIN] Error removing card trait:', e);
    return res.status(500).json({ error: String(e) });
  }
});

// Acknowledge applied deductions by client
app.all('/api/inventory/ack-deductions/:username', async (req, res) => {
  try {
    const username = String(req.params.username || '').trim();
    if (!username) return res.status(400).json({ error: 'Username required' });

    const appliedIds = Array.isArray(req.body?.appliedIds) ? req.body.appliedIds : [];
    if (appliedIds.length === 0) return res.json({ ok: true });

    const key = userFileKey(username);
    const data = await readFromR2(key);
    if (!data) return res.json({ ok: true });

    if (Array.isArray(data.adminDeductions)) {
      data.adminDeductions = data.adminDeductions.filter(d => d && !appliedIds.includes(d.id));
      await writeToR2(key, data);
    }

    return res.json({ ok: true, remainingDeductions: data.adminDeductions?.length || 0 });
  } catch (e) {
    console.error('[ADMIN] Error acking deductions:', e);
    return res.status(500).json({ error: String(e) });
  }
});

// // ---- Friends System Endpoints (Direct Friends: todos los usuarios son amigos automáticamente) ----

// Send friend request (No-op: ya son amigos directamente)
app.post('/api/friends/send', async (_req, res) => {
  res.json({ ok: true, message: 'Todos los jugadores son amigos automáticamente' });
});

// Accept friend request (No-op)
app.post('/api/friends/accept', async (_req, res) => {
  res.json({ ok: true });
});

// Reject friend request (No-op)
app.post('/api/friends/reject', async (_req, res) => {
  res.json({ ok: true });
});

// Remove friend (No-op)
app.post('/api/friends/remove', async (_req, res) => {
  res.json({ ok: true });
});

// Get friends list with profile data (todos los usuarios registrados son amigos)
app.get('/api/friends/list/:username', async (req, res) => {
  try {
    const username = String(req.params.username || '').trim().toLowerCase();
    const allUsers = await listUsersFromR2();
    const friendUsernames = allUsers.filter(u => {
      const lower = u.toLowerCase();
      return lower !== username && lower !== 'admin';
    });

    const etag = `W/"friends-${userListCache.timestamp}-${friendUsernames.length}"`;
    res.setHeader('ETag', etag);
    if (req.headers['if-none-match'] === etag) {
      return res.status(304).end();
    }

    const friendsData = [];
    for (const friendUsername of friendUsernames) {
      const friendData = await readFromR2(userFileKey(friendUsername));
      if (friendData && !friendData.isAdmin) {
        const rawImg = friendData.profileImage ? String(friendData.profileImage) : '';
        const cleanImg = (rawImg.startsWith('data:image') || rawImg.length > 500)
          ? `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(friendData.username || friendUsername)}`
          : (rawImg || `/api/avatar/${encodeURIComponent(friendUsername)}`);

        friendsData.push({
          username: friendData.username || friendUsername,
          profileImage: cleanImg,
          currentTitle: friendData.currentTitle || '',
          showcaseCards: friendData.showcaseCards || [null, null, null],
          stats: friendData.stats || {}
        });
      }
    }

    res.json({ ok: true, friends: friendsData });
  } catch (e) {
    console.error('[FRIENDS] Error getting friends list:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Get friend requests with profile data (siempre vacío porque todos son amigos ya)
app.get('/api/friends/requests/:username', async (_req, res) => {
  res.json({ ok: true, requests: [] });
});

// Search users (for adding friends)
app.get('/api/friends/search', async (req, res) => {
  try {
    const query = (req.query.q || '').toLowerCase().trim();
    const currentUser = (req.query.user || '').trim().toLowerCase();

    const allUsers = await listUsersFromR2();
    const results = [];

    for (const username of allUsers) {
      if (username.toLowerCase() === currentUser || username.toLowerCase() === 'admin') continue;
      if (query && !username.toLowerCase().includes(query)) continue;

      const userData = await readFromR2(userFileKey(username));
      if (userData && !userData.isAdmin) {
        const rawImg = userData.profileImage ? String(userData.profileImage) : '';
        const cleanImg = (rawImg.startsWith('data:image') || rawImg.length > 500)
          ? `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(userData.username || username)}`
          : (rawImg || `/api/avatar/${encodeURIComponent(username)}`);

        results.push({
          username: userData.username || username,
          profileImage: cleanImg,
          currentTitle: userData.currentTitle || '',
          showcaseCards: userData.showcaseCards || [null, null, null],
          stats: userData.stats || {},
          isFriend: true,
          requestSent: false,
          requestReceived: false
        });
      }
    }

    res.json({ ok: true, users: results });
  } catch (e) {
    console.error('[FRIENDS] Error searching users:', e);
    res.status(500).json({ error: String(e) });
  }
});

// ---- Missions State Endpoints ----

// Get user missions state
app.get('/api/missions/:username', async (req, res) => {
  try {
    const username = req.params.username;
    const userData = await readFromR2(userFileKey(username));
    
    if (!userData) {
      return res.json({ ok: true, missions: {} });
    }
    
    res.json({ ok: true, missions: userData.missions || {} });
  } catch (e) {
    console.error('[MISSIONS] Error getting missions state:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Update user missions state
app.post('/api/missions/:username', async (req, res) => {
  try {
    const username = req.params.username;
    const { missions } = req.body;
    
    if (!missions || typeof missions !== 'object') {
      return res.status(400).json({ error: 'missions object required' });
    }
    
    const userData = await readFromR2(userFileKey(username));
    
    if (!userData) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Actualizar solo el campo missions
    userData.missions = missions;
    userData.updatedAt = Date.now();
    
    await writeToR2(userFileKey(username), userData);
    
    console.log('[MISSIONS] Missions state updated for', username);
    res.json({ ok: true });
  } catch (e) {
    console.error('[MISSIONS] Error saving missions state:', e);
    res.status(500).json({ error: String(e) });
  }
});

// ---- Settings Endpoints ----

// Get user settings
app.get('/api/settings/:username', async (req, res) => {
  try {
    const username = req.params.username;
    const userData = await readFromR2(userFileKey(username));
    
    if (!userData) {
      return res.json({ 
        ok: true, 
        settings: {
          theme: {
            active: 'default',
            customTheme: null
          }
        }
      });
    }
    
    const settings = userData.settings || {
      theme: {
        active: 'default',
        customTheme: null
      }
    };
    
    res.json({ ok: true, settings });
  } catch (e) {
    console.error('[SETTINGS] Error getting settings:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Update user settings
app.post('/api/settings/:username', async (req, res) => {
  try {
    const username = req.params.username;
    const { settings } = req.body;
    
    if (!settings || typeof settings !== 'object') {
      return res.status(400).json({ error: 'settings object required' });
    }
    
    const userData = await readFromR2(userFileKey(username));
    
    if (!userData) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Actualizar solo el campo settings
    userData.settings = settings;
    userData.updatedAt = Date.now();
    
    await writeToR2(userFileKey(username), userData);
    
    console.log('[SETTINGS] Settings updated for', username);
    res.json({ ok: true });
  } catch (e) {
    console.error('[SETTINGS] Error saving settings:', e);
    res.status(500).json({ error: String(e) });
  }
});

// ---- Trades System ----
// In-memory trade state (would need Redis/DB for multi-server scaling)
const activeTrades = new Map(); // tradeId -> { id, type, participants, offers, status, createdAt }
const randomQueue = []; // Array of { username, joinedAt }
let tradeIdCounter = 1000;

function generateTradeId() {
  return `trade_${Date.now()}_${tradeIdCounter++}`;
}

// Send trade request to a friend (Sistema Handshake por Coincidencia Mutua en RAM)
app.post('/api/trades/request', async (req, res) => {
  try {
    const { from, to } = req.body;
    if (!from || !to) return res.status(400).json({ error: 'Missing from or to' });
    if (String(from).toLowerCase() === String(to).toLowerCase()) {
      return res.status(400).json({ error: 'Cannot trade with yourself' });
    }

    const now = Date.now();
    // Limpiar trades pendientes antiguos (> 60 segundos de inactividad de emparejamiento)
    for (const [tId, t] of activeTrades.entries()) {
      if (t.status === 'pending' && (now - t.createdAt > 60000)) {
        activeTrades.delete(tId);
      }
    }

    // 1. ¿Existe ya un trade activo entre ambos?
    for (const [existingId, existingTrade] of activeTrades.entries()) {
      if (existingTrade.participants.includes(from) && existingTrade.participants.includes(to) && existingTrade.status === 'active') {
        return res.json({ ok: true, tradeId: existingId, trade: existingTrade, status: 'active', message: 'Trade ya activo' });
      }
    }

    // 2. ¿La otra persona ("to") ya había solicitado tradear conmigo ("from")?
    let mutualPendingTrade = null;
    for (const [existingId, existingTrade] of activeTrades.entries()) {
      if (existingTrade.status === 'pending' &&
          existingTrade.requester.toLowerCase() === to.toLowerCase() &&
          existingTrade.participants.map(p => p.toLowerCase()).includes(from.toLowerCase())) {
        mutualPendingTrade = existingTrade;
        break;
      }
    }

    if (mutualPendingTrade) {
      // ¡COINCIDENCIA MUTUA! Ambos han pedido tradear el uno con el otro.
      mutualPendingTrade.status = 'active';
      mutualPendingTrade.acceptedAt = now;
      console.log(`[TRADES] ¡Coincidencia mutua! Trade activado entre ${from} y ${to} (TradeId: ${mutualPendingTrade.id})`);
      return res.json({
        ok: true,
        tradeId: mutualPendingTrade.id,
        trade: mutualPendingTrade,
        status: 'active',
        matched: true,
        message: '¡Conexión establecida con éxito!'
      });
    }

    // 3. ¿El usuario ya tiene un trade pendiente hacia esa persona?
    for (const [existingId, existingTrade] of activeTrades.entries()) {
      if (existingTrade.status === 'pending' &&
          existingTrade.requester.toLowerCase() === from.toLowerCase() &&
          existingTrade.participants.map(p => p.toLowerCase()).includes(to.toLowerCase())) {
        return res.json({ ok: true, tradeId: existingId, trade: existingTrade, status: 'pending', matched: false, message: 'Esperando al otro jugador' });
      }
    }

    // 4. Si ninguno de los dos había pedido aún, crear el trade como PENDING esperando la coincidencia
    const tradeId = generateTradeId();
    const trade = {
      id: tradeId,
      type: 'friend',
      participants: [from, to],
      offers: {
        [from]: { cards: {}, packs: {}, coins: 0, confirmed: false },
        [to]: { cards: {}, packs: {}, coins: 0, confirmed: false }
      },
      avatars: {
        [from]: `/api/avatar/${encodeURIComponent(from)}`,
        [to]: `/api/avatar/${encodeURIComponent(to)}`
      },
      status: 'pending',
      createdAt: now,
      requester: from
    };

    activeTrades.set(tradeId, trade);
    console.log(`[TRADES] Intención de trade registrada: ${from} -> ${to} (esperando coincidencia mutua)`);
    res.json({ ok: true, tradeId, trade, status: 'pending', matched: false, message: 'Esperando a que tu amigo también solicite tradear contigo' });
  } catch (e) {
    console.error('[TRADES] Error sending request:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Get pending trade requests for a user
app.get('/api/trades/pending/:username', async (req, res) => {
  try {
    const { username } = req.params;
    if (!username) return res.status(400).json({ error: 'Missing username' });
    
    const pendingRequests = [];
    
    for (const [tradeId, trade] of activeTrades.entries()) {
      // Find trades where this user is the recipient and status is pending
      if (trade.status === 'pending' && 
          trade.participants.includes(username) && 
          trade.requester !== username) {
        pendingRequests.push({
          tradeId,
          from: trade.requester,
          createdAt: trade.createdAt,
          trade
        });
      }
    }
    
    console.log('[TRADES] Pending requests for', username, ':', pendingRequests.length);
    res.json({ ok: true, requests: pendingRequests, pending: pendingRequests });
  } catch (e) {
    console.error('[TRADES] Error getting pending requests:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Accept trade request
app.post('/api/trades/accept', async (req, res) => {
  try {
    const { tradeId, username } = req.body;
    if (!tradeId || !username) return res.status(400).json({ error: 'Missing tradeId or username' });
    
    const trade = activeTrades.get(tradeId);
    if (!trade) return res.status(404).json({ error: 'Trade not found' });
    
    if (trade.status !== 'pending') {
      return res.status(400).json({ error: 'Trade is not pending' });
    }
    
    if (!trade.participants.includes(username)) {
      return res.status(403).json({ error: 'Not a participant' });
    }
    
    if (trade.requester === username) {
      return res.status(400).json({ error: 'Cannot accept your own request' });
    }
    
    // Change status to active
    trade.status = 'active';
    activeTrades.set(tradeId, trade);
    
    console.log('[TRADES] Trade request accepted:', tradeId, 'by', username);
    res.json({ ok: true, trade });
  } catch (e) {
    console.error('[TRADES] Error accepting trade:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Reject/Cancel trade request
app.post('/api/trades/reject', async (req, res) => {
  try {
    const { tradeId, username } = req.body;
    if (!tradeId || !username) return res.status(400).json({ error: 'Missing tradeId or username' });
    
    const trade = activeTrades.get(tradeId);
    if (!trade) return res.status(404).json({ error: 'Trade not found' });
    
    if (!trade.participants.includes(username)) {
      return res.status(403).json({ error: 'Not a participant' });
    }
    
    // Remove trade
    activeTrades.delete(tradeId);
    
    console.log('[TRADES] Trade request rejected:', tradeId, 'by', username);
    res.json({ ok: true, message: 'Trade request rejected' });
  } catch (e) {
    console.error('[TRADES] Error rejecting trade:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Join random trade queue
app.post('/api/trades/random/queue', async (req, res) => {
  try {
    const { username } = req.body;
    if (!username) return res.status(400).json({ error: 'Missing username' });
    
    const userData = await readFromR2(userFileKey(username));
    if (!userData) return res.status(404).json({ error: 'User not found' });
    
    // Check if already in an active trade
    for (const [tradeId, trade] of activeTrades.entries()) {
      if (trade.participants.includes(username) && (trade.status === 'active' || trade.status === 'pending')) {
        return res.json({ ok: true, status: 'matched', tradeId, trade });
      }
    }
    
    // Check if already in queue
    const existing = randomQueue.find(q => q.username === username);
    if (existing) {
      return res.json({ ok: true, status: 'in-queue', message: 'Already in queue' });
    }
    
    // Look for someone else in queue (excluding same user)
    const otherUser = randomQueue.find(q => q.username !== username);
    
    if (otherUser) {
      // Match found! Remove other user from queue
      const index = randomQueue.findIndex(q => q.username === otherUser.username);
      randomQueue.splice(index, 1);
      
      const tradeId = generateTradeId();
      const trade = {
        id: tradeId,
        type: 'random',
        participants: [username, otherUser.username],
        offers: {
          [username]: { cards: {}, packs: {}, coins: 0, confirmed: false },
          [otherUser.username]: { cards: {}, packs: {}, coins: 0, confirmed: false }
        },
        avatars: {
          [username]: `/api/avatar/${encodeURIComponent(username)}`,
          [otherUser.username]: `/api/avatar/${encodeURIComponent(otherUser.username)}`
        },
        status: 'active',
        createdAt: Date.now()
      };
      
      activeTrades.set(tradeId, trade);
      
      console.log('[TRADES] Random match found:', username, 'with', otherUser.username);
      return res.json({ ok: true, status: 'matched', tradeId, trade });
    }
    
    // No match yet, add to queue
    randomQueue.push({ username, joinedAt: Date.now() });
    console.log('[TRADES] User joined queue:', username, '- Queue size:', randomQueue.length);
    
    res.json({ ok: true, status: 'in-queue', message: 'Waiting for match...' });
  } catch (e) {
    console.error('[TRADES] Error joining queue:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Check if matched from random queue
app.get('/api/trades/random/match/:username', async (req, res) => {
  try {
    const username = req.params.username;
    
    console.log('[TRADES] Checking match for:', username);
    console.log('[TRADES] Active trades:', activeTrades.size);
    console.log('[TRADES] Queue size:', randomQueue.length);
    
    // Find active trade for this user
    for (const [tradeId, trade] of activeTrades.entries()) {
      if (trade.type === 'random' && trade.participants.includes(username) && trade.status === 'active') {
        console.log('[TRADES] Match found for', username, '- Trade:', tradeId);
        return res.json({ ok: true, matched: true, tradeId, trade });
      }
    }
    
    // Still in queue
    const inQueue = randomQueue.find(q => q.username === username);
    if (inQueue) {
      console.log('[TRADES] User still in queue:', username);
      return res.json({ ok: true, matched: false, status: 'in-queue' });
    }
    
    console.log('[TRADES] User not in queue:', username);
    res.json({ ok: true, matched: false, status: 'not-in-queue' });
  } catch (e) {
    console.error('[TRADES] Error checking match:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Accept trade request
app.post('/api/trades/accept', async (req, res) => {
  try {
    const { tradeId, username } = req.body;
    if (!tradeId || !username) return res.status(400).json({ error: 'Missing tradeId or username' });
    
    const trade = activeTrades.get(tradeId);
    if (!trade) return res.status(404).json({ error: 'Trade not found' });
    
    if (!trade.participants.includes(username)) {
      return res.status(403).json({ error: 'Not a participant' });
    }
    
    trade.status = 'active';
    activeTrades.set(tradeId, trade);
    
    res.json({ ok: true, trade });
  } catch (e) {
    console.error('[TRADES] Error accepting trade:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Reject trade request
app.post('/api/trades/reject', async (req, res) => {
  try {
    const { tradeId, username } = req.body;
    if (!tradeId || !username) return res.status(400).json({ error: 'Missing tradeId or username' });
    
    const trade = activeTrades.get(tradeId);
    if (!trade) return res.status(404).json({ error: 'Trade not found' });
    
    if (!trade.participants.includes(username)) {
      return res.status(403).json({ error: 'Not a participant' });
    }
    
    trade.status = 'cancelled';
    activeTrades.delete(tradeId);
    
    res.json({ ok: true, message: 'Trade rejected' });
  } catch (e) {
    console.error('[TRADES] Error rejecting trade:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Concurrency lock for trade execution
const tradeExecutionLocks = new Set();

// Update trade offer
app.post('/api/trades/offer', async (req, res) => {
  try {
    const { tradeId, username, cards, packs, coins, traits, cardTraits } = req.body;
    if (!tradeId || !username) return res.status(400).json({ error: 'Missing tradeId or username' });
    
    const trade = activeTrades.get(tradeId);
    if (!trade) return res.status(404).json({ error: 'Trade not found' });
    
    if (!trade.participants.includes(username)) {
      return res.status(403).json({ error: 'Not a participant' });
    }
    
    if (trade.status !== 'active') {
      return res.status(400).json({ error: 'Trade not active' });
    }
    
    // Update offer and reset confirmations for BOTH players
    trade.offers[username] = {
      cards: cards || {},
      packs: packs || {},
      coins: Math.max(0, Number(coins) || 0),
      traits: Math.max(0, Number(traits) || 0),
      cardTraits: (cardTraits && typeof cardTraits === 'object') ? cardTraits : {},
      confirmed: false
    };
    
    // Auto-unconfirm: Reset confirmations whenever offer changes
    for (const participant of trade.participants) {
      if (trade.offers[participant]) {
        trade.offers[participant].confirmed = false;
      }
    }
    
    activeTrades.set(tradeId, trade);
    console.log(`[TRADES] Offer updated by ${username} in trade ${tradeId}. Confirmations reset.`);
    
    res.json({ ok: true, trade });
  } catch (e) {
    console.error('[TRADES] Error updating offer:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Confirm trade
app.post('/api/trades/confirm', async (req, res) => {
  const { tradeId, username } = req.body;
  if (!tradeId || !username) return res.status(400).json({ error: 'Missing tradeId or username' });
  
  try {
    const trade = activeTrades.get(tradeId);
    if (!trade) return res.status(404).json({ error: 'Trade not found' });
    
    if (!trade.participants.includes(username)) {
      return res.status(403).json({ error: 'Not a participant' });
    }
    
    if (trade.status !== 'active') {
      return res.status(400).json({ error: 'Trade not active' });
    }
    
    // Mark this user as confirmed
    if (!trade.offers[username]) {
      trade.offers[username] = { cards: {}, packs: {}, coins: 0, traits: 0, cardTraits: {}, confirmed: true };
    } else {
      trade.offers[username].confirmed = true;
    }
    
    // Check if both participants confirmed
    const allConfirmed = trade.participants.length === 2 && trade.participants.every(p => trade.offers[p]?.confirmed);
    
    if (allConfirmed) {
      if (tradeExecutionLocks.has(tradeId)) {
        return res.status(409).json({ error: 'Trade is already executing' });
      }
      
      tradeExecutionLocks.add(tradeId);
      trade.status = 'executing';
      
      try {
        const [user1, user2] = trade.participants;
        const user1Data = await readFromR2(userFileKey(user1));
        const user2Data = await readFromR2(userFileKey(user2));
        
        if (!user1Data || !user2Data) {
          trade.status = 'cancelled';
          activeTrades.delete(tradeId);
          return res.status(404).json({ error: 'User data not found in R2' });
        }
        
        if (!user1Data.wallet) user1Data.wallet = { coins: 0, kvr: 0, traits: 0 };
        if (!user2Data.wallet) user2Data.wallet = { coins: 0, kvr: 0, traits: 0 };
        if (!user1Data.cards) user1Data.cards = {};
        if (!user2Data.cards) user2Data.cards = {};
        if (!user1Data.packs) user1Data.packs = {};
        if (!user2Data.packs) user2Data.packs = {};
        if (!user1Data.cardTraits) user1Data.cardTraits = {};
        if (!user2Data.cardTraits) user2Data.cardTraits = {};
        
        const offer1 = trade.offers[user1] || { cards: {}, packs: {}, coins: 0, traits: 0, cardTraits: {} };
        const offer2 = trade.offers[user2] || { cards: {}, packs: {}, coins: 0, traits: 0, cardTraits: {} };
        
        // --- VALIDATION USER 1 ---
        // Validate regular cards
        for (const [cardId, count] of Object.entries(offer1.cards || {})) {
          const reqCount = Number(count) || 0;
          if (reqCount > 0 && (user1Data.cards[cardId] || 0) < reqCount) {
            trade.status = 'cancelled';
            activeTrades.delete(tradeId);
            return res.status(400).json({ error: `${user1} no tiene suficientes copias de la carta ${cardId}` });
          }
        }
        // Validate trait cards
        for (const [instanceId, tData] of Object.entries(offer1.cardTraits || {})) {
          if (!user1Data.cardTraits[instanceId]) {
            trade.status = 'cancelled';
            activeTrades.delete(tradeId);
            return res.status(400).json({ error: `${user1} no posee la instancia de trait ${instanceId}` });
          }
          const baseCardId = user1Data.cardTraits[instanceId].cardId || tData.cardId;
          if ((user1Data.cards[baseCardId] || 0) < 1) {
            trade.status = 'cancelled';
            activeTrades.delete(tradeId);
            return res.status(400).json({ error: `${user1} no tiene la carta base para el trait ${baseCardId}` });
          }
        }
        // Validate packs
        for (const [packId, count] of Object.entries(offer1.packs || {})) {
          const reqCount = Number(count) || 0;
          if (reqCount > 0 && (user1Data.packs[packId] || 0) < reqCount) {
            trade.status = 'cancelled';
            activeTrades.delete(tradeId);
            return res.status(400).json({ error: `${user1} no tiene suficientes sobres ${packId}` });
          }
        }
        // Validate coins & traits
        if ((user1Data.wallet.coins || 0) < (offer1.coins || 0)) {
          trade.status = 'cancelled';
          activeTrades.delete(tradeId);
          return res.status(400).json({ error: `${user1} no tiene suficientes Coins` });
        }
        if ((user1Data.wallet.traits || 0) < (offer1.traits || 0)) {
          trade.status = 'cancelled';
          activeTrades.delete(tradeId);
          return res.status(400).json({ error: `${user1} no tiene suficientes puntos de Traits` });
        }
        
        // --- VALIDATION USER 2 ---
        // Validate regular cards
        for (const [cardId, count] of Object.entries(offer2.cards || {})) {
          const reqCount = Number(count) || 0;
          if (reqCount > 0 && (user2Data.cards[cardId] || 0) < reqCount) {
            trade.status = 'cancelled';
            activeTrades.delete(tradeId);
            return res.status(400).json({ error: `${user2} no tiene suficientes copias de la carta ${cardId}` });
          }
        }
        // Validate trait cards
        for (const [instanceId, tData] of Object.entries(offer2.cardTraits || {})) {
          if (!user2Data.cardTraits[instanceId]) {
            trade.status = 'cancelled';
            activeTrades.delete(tradeId);
            return res.status(400).json({ error: `${user2} no posee la instancia de trait ${instanceId}` });
          }
          const baseCardId = user2Data.cardTraits[instanceId].cardId || tData.cardId;
          if ((user2Data.cards[baseCardId] || 0) < 1) {
            trade.status = 'cancelled';
            activeTrades.delete(tradeId);
            return res.status(400).json({ error: `${user2} no tiene la carta base para el trait ${baseCardId}` });
          }
        }
        // Validate packs
        for (const [packId, count] of Object.entries(offer2.packs || {})) {
          const reqCount = Number(count) || 0;
          if (reqCount > 0 && (user2Data.packs[packId] || 0) < reqCount) {
            trade.status = 'cancelled';
            activeTrades.delete(tradeId);
            return res.status(400).json({ error: `${user2} no tiene suficientes sobres ${packId}` });
          }
        }
        // Validate coins & traits
        if ((user2Data.wallet.coins || 0) < (offer2.coins || 0)) {
          trade.status = 'cancelled';
          activeTrades.delete(tradeId);
          return res.status(400).json({ error: `${user2} no tiene suficientes Coins` });
        }
        if ((user2Data.wallet.traits || 0) < (offer2.traits || 0)) {
          trade.status = 'cancelled';
          activeTrades.delete(tradeId);
          return res.status(400).json({ error: `${user2} no tiene suficientes puntos de Traits` });
        }
        
        // --- EXECUTE ATOMIC EXCHANGE ---
        console.log(`[TRADES] EXECUTING ATOMIC TRADE ${tradeId}: ${user1} <-> ${user2}`);
        
        // 1. Coins & Traits currency transfer
        user1Data.wallet.coins = Math.max(0, (user1Data.wallet.coins || 0) - (offer1.coins || 0) + (offer2.coins || 0));
        user2Data.wallet.coins = Math.max(0, (user2Data.wallet.coins || 0) - (offer2.coins || 0) + (offer1.coins || 0));
        
        user1Data.wallet.traits = Math.max(0, (user1Data.wallet.traits || 0) - (offer1.traits || 0) + (offer2.traits || 0));
        user2Data.wallet.traits = Math.max(0, (user2Data.wallet.traits || 0) - (offer2.traits || 0) + (offer1.traits || 0));
        
        // 2. Packs transfer
        for (const [packId, count] of Object.entries(offer1.packs || {})) {
          const qty = Number(count) || 0;
          user1Data.packs[packId] = Math.max(0, (user1Data.packs[packId] || 0) - qty);
          if (user1Data.packs[packId] <= 0) delete user1Data.packs[packId];
          user2Data.packs[packId] = (user2Data.packs[packId] || 0) + qty;
        }
        for (const [packId, count] of Object.entries(offer2.packs || {})) {
          const qty = Number(count) || 0;
          user2Data.packs[packId] = Math.max(0, (user2Data.packs[packId] || 0) - qty);
          if (user2Data.packs[packId] <= 0) delete user2Data.packs[packId];
          user1Data.packs[packId] = (user1Data.packs[packId] || 0) + qty;
        }
        
        // 3. Regular Cards transfer
        for (const [cardId, count] of Object.entries(offer1.cards || {})) {
          const qty = Number(count) || 0;
          user1Data.cards[cardId] = Math.max(0, (user1Data.cards[cardId] || 0) - qty);
          if (user1Data.cards[cardId] <= 0) delete user1Data.cards[cardId];
          user2Data.cards[cardId] = (user2Data.cards[cardId] || 0) + qty;
        }
        for (const [cardId, count] of Object.entries(offer2.cards || {})) {
          const qty = Number(count) || 0;
          user2Data.cards[cardId] = Math.max(0, (user2Data.cards[cardId] || 0) - qty);
          if (user2Data.cards[cardId] <= 0) delete user2Data.cards[cardId];
          user1Data.cards[cardId] = (user1Data.cards[cardId] || 0) + qty;
        }
        
        // 4. Trait Cards transfer
        for (const [instanceId, tData] of Object.entries(offer1.cardTraits || {})) {
          const traitObj = user1Data.cardTraits[instanceId] || tData;
          const baseCardId = traitObj.cardId;
          // Deduct 1 card from user1
          user1Data.cards[baseCardId] = Math.max(0, (user1Data.cards[baseCardId] || 0) - 1);
          if (user1Data.cards[baseCardId] <= 0) delete user1Data.cards[baseCardId];
          delete user1Data.cardTraits[instanceId];
          
          // Add 1 card to user2 and attach trait
          user2Data.cards[baseCardId] = (user2Data.cards[baseCardId] || 0) + 1;
          const newInstanceId = `inst_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
          user2Data.cardTraits[newInstanceId] = { cardId: baseCardId, traitId: traitObj.traitId };
        }
        for (const [instanceId, tData] of Object.entries(offer2.cardTraits || {})) {
          const traitObj = user2Data.cardTraits[instanceId] || tData;
          const baseCardId = traitObj.cardId;
          // Deduct 1 card from user2
          user2Data.cards[baseCardId] = Math.max(0, (user2Data.cards[baseCardId] || 0) - 1);
          if (user2Data.cards[baseCardId] <= 0) delete user2Data.cards[baseCardId];
          delete user2Data.cardTraits[instanceId];
          
          // Add 1 card to user1 and attach trait
          user1Data.cards[baseCardId] = (user1Data.cards[baseCardId] || 0) + 1;
          const newInstanceId = `inst_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
          user1Data.cardTraits[newInstanceId] = { cardId: baseCardId, traitId: traitObj.traitId };
        }
        
        // Update timestamps and persist in R2
        user1Data.updatedAt = Date.now();
        user2Data.updatedAt = Date.now();
        await writeToR2(userFileKey(user1), user1Data);
        await writeToR2(userFileKey(user2), user2Data);
        
        // Audit log
        const auditLog = {
          tradeId,
          timestamp: Date.now(),
          user1,
          user2,
          offer1,
          offer2
        };
        try {
          await writeToR2(`logs/trades/${Date.now()}_${tradeId}.json`, auditLog);
        } catch (logErr) {
          console.warn('[TRADES] Audit log write warning:', logErr.message);
        }
        
        trade.status = 'completed';
        trade.completedAt = Date.now();
        console.log(`[TRADES] ✅ Trade ${tradeId} completed successfully.`);
        
        setTimeout(() => activeTrades.delete(tradeId), 60000);
        
        return res.json({ ok: true, trade, message: 'Trade executed successfully' });
      } finally {
        tradeExecutionLocks.delete(tradeId);
      }
    }
    
    activeTrades.set(tradeId, trade);
    res.json({ ok: true, trade, message: 'Waiting for other player to confirm' });
  } catch (e) {
    tradeExecutionLocks.delete(tradeId);
    console.error('[TRADES] Error confirming trade:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Cancel confirmation
app.post('/api/trades/cancel-confirm', async (req, res) => {
  try {
    const { tradeId, username } = req.body;
    if (!tradeId || !username) return res.status(400).json({ error: 'Missing tradeId or username' });
    
    const trade = activeTrades.get(tradeId);
    if (!trade) return res.status(404).json({ error: 'Trade not found' });
    
    if (!trade.participants.includes(username)) {
      return res.status(403).json({ error: 'Not a participant' });
    }
    
    if (trade.status !== 'active') {
      return res.status(400).json({ error: 'Trade not active' });
    }
    
    // Unmark confirmation
    trade.offers[username].confirmed = false;
    
    activeTrades.set(tradeId, trade);
    res.json({ ok: true, trade, message: 'Confirmation canceled' });
  } catch (e) {
    console.error('[TRADES] Error canceling confirmation:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Cancel trade
app.post('/api/trades/cancel', async (req, res) => {
  try {
    const { tradeId, username } = req.body;
    if (!tradeId || !username) return res.status(400).json({ error: 'Missing tradeId or username' });
    
    const trade = activeTrades.get(tradeId);
    if (!trade) return res.json({ ok: true, message: 'Trade was already closed' });
    
    if (!trade.participants.includes(username)) {
      return res.status(403).json({ error: 'Not a participant' });
    }
    
    // Remove from queue if in random queue
    const queueIndex = randomQueue.findIndex(q => q.username === username);
    if (queueIndex !== -1) {
      randomQueue.splice(queueIndex, 1);
    }
    
    trade.status = 'cancelled';
    trade.cancelledBy = username;
    trade.cancelledAt = Date.now();
    activeTrades.set(tradeId, trade);
    
    // Keep in activeTrades briefly (10 seconds) so polling from the other player gets 'cancelled' status cleanly
    setTimeout(() => {
      if (activeTrades.get(tradeId)?.status === 'cancelled') {
        activeTrades.delete(tradeId);
      }
    }, 10000);
    
    res.json({ ok: true, message: 'Trade cancelled', trade });
  } catch (e) {
    console.error('[TRADES] Error cancelling trade:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Get trade status
app.get('/api/trades/status/:tradeId', async (req, res) => {
  try {
    const tradeId = req.params.tradeId;
    const trade = activeTrades.get(tradeId);
    
    if (!trade) {
      return res.status(404).json({ ok: false, error: 'Trade not found' });
    }
    
    trade.lastActivity = Date.now();
    res.json({ ok: true, trade });
  } catch (e) {
    console.error('[TRADES] Error getting trade status:', e);
    res.status(500).json({ error: String(e) });
  }
});


// ---- Start server ----
// Usar variable de entorno PORT (para Render/Heroku) o 5005 localmente
let PORT = Number(process.env.PORT || 5005);

function startServer(p) {
  server.listen(p, () => {
    console.log('═══════════════════════════════════════════════');
    console.log('🎮  KVR CARDS - SERVIDOR UNIFICADO');
    console.log('═══════════════════════════════════════════════');
    console.log('✅ Inventario (R2) + Online PVP activos');
    console.log('🚀 Launcher API activo');
    console.log('🌐 Puerto:', p);
    console.log('📦 R2 Storage: Cloudflare');
    console.log('⚔️  WebSockets: Activo');
    console.log('═══════════════════════════════════════════════');
  });
  server.on('error', (err) => {
    if (err && err.code === 'EADDRINUSE' && p === 4321) {
      PORT = 5005;
      console.log('[inventory-server] Port 4321 occupied, trying 5005...');
      setTimeout(() => startServer(PORT), 1000);
    } else {
      console.error('[inventory-server] Server error:', err);
      process.exit(1);
    }
  });
}

// ==================== SISTEMA ONLINE PVP ====================
// Integrado en el mismo servidor para usar un solo despliegue en Render

const io = socketIO(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  },
  // Configuración optimizada para Render free tier
  transports: ['websocket', 'polling'], // Preferir WebSocket
  pingTimeout: 60000, // 60s antes de considerar desconectado
  pingInterval: 25000, // Ping cada 25s para mantener conexión
  upgradeTimeout: 30000, // 30s para upgrade a WebSocket
  allowUpgrades: true,
  perMessageDeflate: false, // Deshabilitar compresión para reducir CPU
  httpCompression: false,
  // Configuración de conexión
  connectTimeout: 45000,
  // Logs para debugging
  allowEIO3: true,
  // IMPORTANTE: Límite de payload para evitar desconexiones por datos grandes
  maxHttpBufferSize: 5e6 // 5MB máximo por mensaje (default es 1MB)
});

// Estado del servidor online
const connectedPlayers = new Map();
const matchmakingQueue = [];
const activeMatches = new Map();
const battleRequests = new Map();

function generateMatchId() {
  return 'match_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function generateRequestId() {
  return 'request_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

function findPlayerSocketByUserId(userId) {
  if (!userId) return null;
  const target = String(userId).toLowerCase();
  for (const [socketId, data] of connectedPlayers.entries()) {
    if (data.userId === userId || String(data.userId || '').toLowerCase() === target || String(data.username || '').toLowerCase() === target) {
      const sock = io.sockets.sockets.get(socketId);
      if (sock && sock.connected) {
        return sock;
      }
    }
  }
  // Fallback para encontrar cualquier socket que exista si el flag .connected no está seteado
  for (const [socketId, data] of connectedPlayers.entries()) {
    if (data.userId === userId || String(data.userId || '').toLowerCase() === target || String(data.username || '').toLowerCase() === target) {
      const sock = io.sockets.sockets.get(socketId);
      if (sock) return sock;
    }
  }
  return null;
}

function findConnectedPlayerByUserId(userId) {
  if (!userId) return null;
  const target = String(userId).toLowerCase();
  for (const data of connectedPlayers.values()) {
    if (data.userId === userId || String(data.userId || '').toLowerCase() === target || String(data.username || '').toLowerCase() === target) {
      return data;
    }
  }
  return null;
}

function resolvePlayerFromSocket(socket, match) {
  if (!match) return null;
  const pData = connectedPlayers.get(socket.id);
  const userId = pData ? pData.userId : null;
  
  if (!userId) {
    // Fallback de contingencia: si no está en connectedPlayers, usar comparación clásica por socket.id
    if (socket.id === match.player1Socket) return 'player1';
    if (socket.id === match.player2Socket) return 'player2';
    return null;
  }
  
  if (userId === match.player1) {
    if (socket.id !== match.player1Socket) {
      console.log(`[ONLINE-SYNC] Sincronizando nuevo socket ID para Player 1: ${socket.id} (anterior: ${match.player1Socket})`);
      match.player1Socket = socket.id;
    }
    return 'player1';
  }
  
  if (userId === match.player2) {
    if (socket.id !== match.player2Socket) {
      console.log(`[ONLINE-SYNC] Sincronizando nuevo socket ID para Player 2: ${socket.id} (anterior: ${match.player2Socket})`);
      match.player2Socket = socket.id;
    }
    return 'player2';
  }
  
  return null;
}

// Helpers para identificar y excluir cartas duplicadas o del mismo personaje en Draft
function normalizeDraftString(str) {
  if (!str) return '';
  return String(str)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Quitar tildes
    .toLowerCase()
    .trim();
}

const DRAFT_QUALITY_SUFFIXES = [
  '_iconoprime', '_icono_prime', '_icon_prime', '_prime_icon',
  '_diosantiguo', '_dios_antiguo', '_ancientgod',
  '_superheroe', '_legendario', '_legendaria',
  '_especiales', '_especial', '_special',
  '_iconos', '_icono', '_icon',
  '_heroes', '_heroe', '_hero',
  '_bronce', '_bronze',
  '_plata', '_silver',
  '_oro', '_gold',
  '_evolucion', '_evolution', '_evo',
  '_inmortal', '_inmo',
  '_legend', '_prime', '_tots', '_toty',
  '_evento', '_event'
];

function getCanonicalDraftCharacterId(cardOrId) {
  let id = normalizeDraftString(typeof cardOrId === 'object' ? (cardOrId?.id || cardOrId?.uniqueId) : cardOrId);
  if (id.includes('_notrait')) id = id.split('_notrait')[0];
  for (const suffix of DRAFT_QUALITY_SUFFIXES) {
    if (id.endsWith(suffix)) {
      id = id.slice(0, -suffix.length);
      break;
    }
  }
  id = id.replace(/_+$/, '');
  return id.replace(/[^a-z0-9]/g, '');
}

function getCanonicalDraftCharacterName(card) {
  if (!card) return '';
  let name = normalizeDraftString(card.name || card.nombre || '');
  if (!name) return '';
  name = name.replace(/\([^)]*\)/g, '').replace(/\[[^\]]*\]/g, '').trim();
  const qualityWords = [
    'icono prime', 'iconoprime', 'prime icon', 'dios antiguo', 'diosantiguo',
    'super heroe', 'superheroe', 'super héroe',
    'especiales', 'especial', 'special',
    'icono', 'icon', 'heroe', 'hero',
    'bronce', 'bronze', 'plata', 'silver', 'oro', 'gold',
    'evolucion', 'evolution', 'evo',
    'legendario', 'legendaria', 'legend', 'prime', 'inmortal', 'inmo', 'tots', 'toty'
  ];
  for (const word of qualityWords) {
    const regex = new RegExp(`\\s+${word}$`, 'i');
    if (regex.test(name)) {
      name = name.replace(regex, '').trim();
      break;
    }
  }
  return name.replace(/[^a-z0-9]/g, '');
}

function getDraftCardTokens(card) {
  if (!card) return new Set();
  const tokens = new Set();
  if (card.id) {
    const rawId = normalizeDraftString(card.id);
    tokens.add(rawId);
    rawId.split(/[_-\s]+/).filter(t => t.length > 2).forEach(t => tokens.add(t));
  }
  const name = normalizeDraftString(card.name || card.nombre || '');
  if (name) {
    const cleanName = name.replace(/\([^)]*\)/g, '').trim();
    if (cleanName) tokens.add(cleanName);
    cleanName.split(/\s+/).filter(w => w.length > 2).forEach(w => tokens.add(w));
  }
  return tokens;
}

function isSameDraftCharacterOrCard(cardA, cardB) {
  if (!cardA || !cardB) return false;
  
  const charIdA = getCanonicalDraftCharacterId(cardA);
  const charIdB = getCanonicalDraftCharacterId(cardB);
  if (charIdA && charIdB && charIdA === charIdB) return true;

  const charNameA = getCanonicalDraftCharacterName(cardA);
  const charNameB = getCanonicalDraftCharacterName(cardB);
  if (charNameA && charNameB && charNameA === charNameB) return true;

  const idA = normalizeDraftString(cardA.id);
  const idB = normalizeDraftString(cardB.id);
  if (idA && idB && idA === idB) return true;

  const nameA = normalizeDraftString(cardA.name || cardA.nombre || '');
  const nameB = normalizeDraftString(cardB.name || cardB.nombre || '');
  if (nameA && nameB && nameA === nameB) return true;

  const baseNameA = nameA.replace(/\([^)]*\)/g, '').trim();
  const baseNameB = nameB.replace(/\([^)]*\)/g, '').trim();
  if (baseNameA && baseNameB && baseNameA === baseNameB) return true;

  const tokensA = getDraftCardTokens(cardA);
  const tokensB = getDraftCardTokens(cardB);
  const genericWords = new Set([
    'card', 'shinobi', 'ninja', 'modo', 'prime', 'super', 'icono', 'heroe', 'plata', 'bronce', 'oro', 'evo',
    'de', 'del', 'los', 'las', 'el', 'la', 'un', 'una', 'san', 'gran', 'lord', 'version', 'joven', 'adulto'
  ]);
  for (const t of tokensA) {
    if (tokensB.has(t) && !genericWords.has(t)) return true;
  }
  return false;
}

function generatePlayerDraftChoices(existingTeam = [], targetMedia = null) {
  if (!Array.isArray(draftCardsPool) || draftCardsPool.length === 0) {
    return [ 
      { id: 'fallback', name: 'Carta Fallback', media: 75, stats: [75, 75, 75, 75, 75, 75], imageUrl: '', quality: 'Plata', procedencia: 'Desconocido', owner: 'Nadie', trait: null }, 
      { id: 'fallback-2', name: 'Carta Fallback 2', media: 76, stats: [76, 76, 76, 76, 76, 76], imageUrl: '', quality: 'Plata', procedencia: 'Desconocido', owner: 'Nadie', trait: null } 
    ];
  }

  // Normalizar array de equipo existente
  const teamList = Array.isArray(existingTeam) ? existingTeam : [];

  // Filtrar pool para excluir:
  // 1. Calidad 'Evo'
  // 2. Cualquier carta que coincida en ID, Nombre o Personaje con alguna carta ya en el equipo
  const availablePool = draftCardsPool.filter(c => {
    if (!c || !c.id) return false;
    const q = (c.calidad || c.quality || '').trim();
    if (q.toLowerCase() === 'evo') return false;

    for (const teamCard of teamList) {
      if (isSameDraftCharacterOrCard(c, teamCard)) {
        return false;
      }
    }
    return true;
  });

  console.log(`[DRAFT-ALGORITHM] Equipo actual (${teamList.length} cartas):`, teamList.map(c => c.name || c.id));
  console.log(`[DRAFT-ALGORITHM] Cartas disponibles filtradas: ${availablePool.length} (Total pool: ${draftCardsPool.length})`);

  const safeFallbackPool = draftCardsPool.filter(c => (c.calidad || c.quality || '').trim().toLowerCase() !== 'evo');
  const poolToUse = availablePool.length >= 2 ? availablePool : (safeFallbackPool.length >= 2 ? safeFallbackPool : draftCardsPool);
  const sortedByMedia = [...poolToUse].sort((a, b) => (Number(a.media) || 75) - (Number(b.media) || 75));

  if (targetMedia === null) {
    const isRareRound = Math.random() < 0.10;
    targetMedia = isRareRound 
      ? 90 + Math.floor(Math.random() * 10) 
      : 60 + Math.floor(Math.random() * 30);
  }

  // Buscar A
  let closestIndex = 0;
  let minDiff = Infinity;
  for (let i = 0; i < sortedByMedia.length; i++) {
    const diff = Math.abs((Number(sortedByMedia[i].media) || 75) - targetMedia);
    if (diff < minDiff) {
      minDiff = diff;
      closestIndex = i;
    }
  }
  const A = sortedByMedia[closestIndex];

  // Buscar B (consistencia de pareja: diferencia <= 4, pero NUNCA el mismo personaje/carta que A ni que teamList)
  const potentialB = sortedByMedia.filter(c => {
    if (c.id === A.id) return false;
    if (isSameDraftCharacterOrCard(c, A)) return false;
    for (const teamCard of teamList) {
      if (isSameDraftCharacterOrCard(c, teamCard)) return false;
    }
    return Math.abs((Number(c.media) || 75) - (Number(A.media) || 75)) <= 4;
  });

  let B = null;
  if (potentialB.length > 0) {
    B = potentialB[Math.floor(Math.random() * potentialB.length)];
  } else {
    // Si no hay candidatos con diff <= 4, buscar cualquier otra carta válida que no duplique
    const otherCandidates = sortedByMedia.filter(c => {
      if (c.id === A.id) return false;
      if (isSameDraftCharacterOrCard(c, A)) return false;
      for (const teamCard of teamList) {
        if (isSameDraftCharacterOrCard(c, teamCard)) return false;
      }
      return true;
    });
    if (otherCandidates.length > 0) {
      B = otherCandidates[Math.floor(Math.random() * otherCandidates.length)];
    } else {
      const fallbackNonDup = safeFallbackPool.filter(c => c.id !== A.id && !isSameDraftCharacterOrCard(c, A) && !teamList.some(t => isSameDraftCharacterOrCard(c, t)));
      B = fallbackNonDup.length > 0 ? fallbackNonDup[0] : sortedByMedia[(closestIndex + 1) % sortedByMedia.length];
    }
  }

  function rollDraftTrait(pool) {
    if (!Array.isArray(pool) || pool.length === 0) return null;
    const RARITY_WEIGHTS = { common: 50, rare: 25, epic: 10, legendary: 3, mythic: 1 };
    
    let totalWeight = 0;
    const items = pool.map(t => {
      let raw = t.probability ?? t.probabilidad ?? t.chance ?? t.prob ?? null;
      let w = null;
      if (raw !== null && raw !== undefined && raw !== '') {
        const num = parseFloat(String(raw).replace('%', '').trim());
        if (!isNaN(num) && num > 0) w = num;
      }
      if (w === null) {
        const r = String(t.rarity || 'common').toLowerCase().trim();
        w = RARITY_WEIGHTS[r] !== undefined ? RARITY_WEIGHTS[r] : 10;
      }
      totalWeight += w;
      return { trait: t, weight: w };
    });

    const rand = Math.random() * totalWeight;
    let acc = 0;
    for (const item of items) {
      acc += item.weight;
      if (rand <= acc) return item.trait;
    }
    return pool[0];
  }

  // Mapear con 15% probabilidad de Traits (usando probabilidades ponderadas por rareza)
  const traitChance = 0.15;
  const mapCardOption = (card) => {
    const opt = {
      id: card.id,
      name: card.name || card.nombre || 'Carta',
      media: Number(card.media) || 75,
      stats: card.stats || card.parametros || [60, 60, 60, 60, 60, 60],
      imageUrl: card.imageUrl || card.imagen || '',
      quality: card.quality || card.calidad || 'Plata',
      procedencia: card.procedencia || 'Desconocido',
      owner: card.owner || 'Nadie',
      trait: null
    };

    if (Math.random() < traitChance && draftTraitsPool.length > 0) {
      const randomTrait = rollDraftTrait(draftTraitsPool);
      if (randomTrait) {
        opt.trait = {
          id: randomTrait.id,
          name: randomTrait.name,
          description: randomTrait.description,
          imageUrl: randomTrait.imageUrl,
          effect: randomTrait.effect,
          rarity: randomTrait.rarity
        };
      }
    }
    return opt;
  };

  return [mapCardOption(A), mapCardOption(B)];
}

function startDraftForMatch(match) {
  const isDraftMode = match.gameMode === 'eleccion_clasico' || match.gameMode === 'eleccion_alternativo';
  if (!isDraftMode) return;

  console.log(`[DRAFT] Inicializando Fase de Elección para Match ${match.matchId} (${match.gameMode})`);

  // Estado per-player independiente para flujo asíncrono y exclusiones de personajes
  // Estado per-player independiente para flujo asíncrono y exclusiones de personajes
  match.draft = {
    player1: { round: 1, team: [], currentChoices: null, excludedBaseNames: [] },
    player2: { round: 1, team: [], currentChoices: null, excludedBaseNames: [] }
  };

  let choicesP1 = generatePlayerDraftChoices([], null);
  if (!Array.isArray(choicesP1) || choicesP1.length < 2) {
    console.error('[DRAFT] ERROR: choicesP1 no es un array válido de Draft, usando fallback de seguridad.');
    choicesP1 = [ 
      { id: 'fallback', name: 'Carta Fallback', media: 75, stats: [75, 75, 75, 75, 75, 75], imageUrl: '', quality: 'Plata', procedencia: 'Desconocido', owner: 'Nadie', trait: null }, 
      { id: 'fallback-2', name: 'Carta Fallback 2', media: 76, stats: [76, 76, 76, 76, 76, 76], imageUrl: '', quality: 'Plata', procedencia: 'Desconocido', owner: 'Nadie', trait: null } 
    ];
  }

  const p1Average = (choicesP1[0].media + choicesP1[1].media) / 2;
  const delta = (Math.random() < 0.5 ? -1 : 1) * (5 + Math.random() * 3);
  const targetMediaP2 = Math.max(60, Math.min(99, p1Average + delta));

  let choicesP2 = generatePlayerDraftChoices([], targetMediaP2);
  if (!Array.isArray(choicesP2) || choicesP2.length < 2) {
    console.error('[DRAFT] ERROR: choicesP2 no es un array válido de Draft, usando fallback de seguridad.');
    choicesP2 = [ 
      { id: 'fallback', name: 'Carta Fallback', media: 75, stats: [75, 75, 75, 75, 75, 75], imageUrl: '', quality: 'Plata', procedencia: 'Desconocido', owner: 'Nadie', trait: null }, 
      { id: 'fallback-2', name: 'Carta Fallback 2', media: 76, stats: [76, 76, 76, 76, 76, 76], imageUrl: '', quality: 'Plata', procedencia: 'Desconocido', owner: 'Nadie', trait: null } 
    ];
  }

  match.draft.player1.currentChoices = choicesP1;
  match.draft.player2.currentChoices = choicesP2;

  // Emitir a ambos (resolución dinámica de socket para soportar reconexiones silentes)
  const p1Socket = io.sockets.sockets.get(match.player1Socket) || findPlayerSocketByUserId(match.player1);
  const p2Socket = io.sockets.sockets.get(match.player2Socket) || findPlayerSocketByUserId(match.player2);

  if (p1Socket) {
    // Si el socket dinámico es diferente, actualizarlo en el match
    if (p1Socket.id !== match.player1Socket) {
      console.log(`[DRAFT] Sincronizando nuevo socket ID para Player 1: ${p1Socket.id}`);
      match.player1Socket = p1Socket.id;
    }
    p1Socket.emit('draft-start', {
      matchId: match.matchId,
      gameMode: match.gameMode,
      round: 1,
      choices: choicesP1
    });
  } else {
    console.error(`[DRAFT] Error crítico: Player 1 socket no encontrado para match ${match.matchId}`);
  }

  if (p2Socket) {
    // Si el socket dinámico es diferente, actualizarlo en el match
    if (p2Socket.id !== match.player2Socket) {
      console.log(`[DRAFT] Sincronizando nuevo socket ID para Player 2: ${p2Socket.id}`);
      match.player2Socket = p2Socket.id;
    }
    p2Socket.emit('draft-start', {
      matchId: match.matchId,
      gameMode: match.gameMode,
      round: 1,
      choices: choicesP2
    });
  } else {
    console.error(`[DRAFT] Error crítico: Player 2 socket no encontrado para match ${match.matchId}`);
  }
}

function tryMatchmaking() {
  if (matchmakingQueue.length < 2) return;
  
  console.log('[MATCHMAKING] Intentando hacer match...');
  
  // Buscar pareja con el mismo gameMode
  let matchedPair = null;
  let modeToMatch = null;
  
  for (let i = 0; i < matchmakingQueue.length; i++) {
    const p1 = matchmakingQueue[i];
    for (let j = i + 1; j < matchmakingQueue.length; j++) {
      const p2 = matchmakingQueue[j];
      // Si ambos tienen el mismo gameMode
      const mode1 = p1.gameMode || 'clasico7v7';
      const mode2 = p2.gameMode || 'clasico7v7';
      if (mode1 === mode2) {
        matchedPair = { p1, p2, index1: i, index2: j };
        modeToMatch = mode1;
        break;
      }
    }
    if (matchedPair) break;
  }
  
  if (!matchedPair) {
    console.log('[MATCHMAKING] No se encontró ninguna pareja con el mismo modo de juego.');
    return;
  }
  
  // Extraer jugadores de la cola
  const { p1, p2, index1, index2 } = matchedPair;
  // Eliminar el de mayor índice primero para no alterar el otro índice
  matchmakingQueue.splice(index2, 1);
  matchmakingQueue.splice(index1, 1);
  
  const matchId = generateMatchId();
  
  const match = {
    matchId,
    player1: p1.userId,
    player2: p2.userId,
    player1Socket: p1.socketId,
    player2Socket: p2.socketId,
    player1Ready: false,
    player2Ready: false,
    player1CardIndex: null,
    player2CardIndex: null,
    firstPlayer: Math.random() < 0.5 ? 'player1' : 'player2',
    currentRound: 1,
    gameMode: modeToMatch,
    createdAt: Date.now()
  };
  
  activeMatches.set(matchId, match);
  
  const p1Socket = io.sockets.sockets.get(p1.socketId) || findPlayerSocketByUserId(p1.userId);
  const p2Socket = io.sockets.sockets.get(p2.socketId) || findPlayerSocketByUserId(p2.userId);
  
  const p1Connected = connectedPlayers.get(p1.socketId) || findConnectedPlayerByUserId(p1.userId);
  const p2Connected = connectedPlayers.get(p2.socketId) || findConnectedPlayerByUserId(p2.userId);

  const p1Username = (p1.username && p1.username !== 'Jugador') 
    ? p1.username 
    : (p1Connected?.username && p1Connected.username !== 'Jugador' ? p1Connected.username : (p1.userId && !p1.userId.startsWith('user_') ? p1.userId : (p1.username || 'Rival')));
  const p2Username = (p2.username && p2.username !== 'Jugador') 
    ? p2.username 
    : (p2Connected?.username && p2Connected.username !== 'Jugador' ? p2Connected.username : (p2.userId && !p2.userId.startsWith('user_') ? p2.userId : (p2.username || 'Rival')));

  if (p1Socket) {
    if (p1Socket.id !== p1.socketId) {
      console.log(`[MATCHMAKING] Sincronizando nuevo socket ID para Player 1: ${p1Socket.id} (anterior: ${p1.socketId})`);
      match.player1Socket = p1Socket.id;
    }
    p1Socket.emit('match-found', {
      matchId,
      opponentId: p2.userId,
      opponent: { 
        username: p2Username,
        profileImage: p2.profileImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=${p2Username}`
      },
      isHost: true,
      gameMode: modeToMatch
    });
  } else {
    console.error(`[MATCHMAKING] Error crítico: Socket para Player 1 (${p1Username}) no encontrado al hacer match`);
  }
  
  if (p2Socket) {
    if (p2Socket.id !== p2.socketId) {
      console.log(`[MATCHMAKING] Sincronizando nuevo socket ID para Player 2: ${p2Socket.id} (anterior: ${p2.socketId})`);
      match.player2Socket = p2Socket.id;
    }
    p2Socket.emit('match-found', {
      matchId,
      opponentId: p1.userId,
      opponent: { 
        username: p1Username,
        profileImage: p1.profileImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=${p1Username}`
      },
      isHost: false,
      gameMode: modeToMatch
    });
  } else {
    console.error(`[MATCHMAKING] Error crítico: Socket para Player 2 (${p2Username}) no encontrado al hacer match`);
  }
  
  console.log(`[MATCHMAKING] ✅ Match creado (${modeToMatch}): ${p1Username} vs ${p2Username}`);
  io.emit('queue-update', { playersInQueue: matchmakingQueue.length });

  // Iniciar Draft si corresponde
  startDraftForMatch(match);
  
  if (matchmakingQueue.length >= 2) {
    setTimeout(tryMatchmaking, 1000);
  }
}

// Socket.io eventos
io.on('connection', (socket) => {
  console.log(`[ONLINE] ✅ Cliente conectado: ${socket.id}`);

  socket.on('register-player', (playerData) => {
    // Saneamiento imperativo: purgar cualquier socket anterior del mismo usuario para evitar stale/duplicates
    if (playerData && playerData.userId) {
      for (const [oldSocketId, oldData] of connectedPlayers.entries()) {
        if (oldData.userId === playerData.userId && oldSocketId !== socket.id) {
          connectedPlayers.delete(oldSocketId);
          console.log(`[ONLINE-CLEANUP] Eliminado registro obsoleto de socket para ${playerData.username}: ${oldSocketId}`);
        }
      }
    }

    const rawImg = playerData?.profileImage ? String(playerData.profileImage).trim() : '';
    let cleanImg;
    if (rawImg && !rawImg.startsWith('data:image') && rawImg.length <= 500) {
      cleanImg = rawImg;
    } else {
      cleanImg = `/api/avatar/${encodeURIComponent(playerData.username || 'user')}`;
    }

    connectedPlayers.set(socket.id, {
      socketId: socket.id,
      userId: playerData.userId,
      username: playerData.username,
      profileImage: cleanImg,
      connectedAt: Date.now()
    });
    console.log(`[ONLINE] Registrado: ${playerData.username} (Total: ${connectedPlayers.size})`);
  });

  socket.on('join-queue', (data) => {
    const playerData = connectedPlayers.get(socket.id);
    if (!playerData) return;
    
    const alreadyInQueue = matchmakingQueue.find(p => p.socketId === socket.id);
    if (alreadyInQueue) return;
    
    const gameMode = (data && data.gameMode) ? data.gameMode : 'clasico7v7';
    
    matchmakingQueue.push({
      socketId: socket.id,
      userId: playerData.userId,
      username: playerData.username,
      profileImage: playerData.profileImage,
      gameMode: gameMode,
      joinedAt: Date.now()
    });
    
    console.log(`[MATCHMAKING] ${playerData.username} en cola [${gameMode}] (${matchmakingQueue.length})`);
    io.emit('queue-update', { playersInQueue: matchmakingQueue.length });
    tryMatchmaking();
  });

  socket.on('leave-queue', () => {
    const index = matchmakingQueue.findIndex(p => p.socketId === socket.id);
    if (index !== -1) {
      matchmakingQueue.splice(index, 1);
      io.emit('queue-update', { playersInQueue: matchmakingQueue.length });
    }
  });

  socket.on('get-friends-status', (data) => {
    const friendsStatus = {};
    data.friendIds.forEach(friendId => {
      const isOnline = Array.from(connectedPlayers.values()).some(p => p.userId === friendId || p.username === friendId);
      friendsStatus[friendId] = isOnline ? 'online' : 'offline';
    });
    socket.emit('friends-status', friendsStatus);
  });

  socket.on('send-battle-request', (data) => {
    const requestId = generateRequestId();
    const modeName = data.modeName || '7v7 Clásico';
    const gameMode = data.gameMode || 'clasico7v7';
    const senderData = findConnectedPlayerByUserId(data.fromId) || connectedPlayers.get(socket.id);
    const resolvedFromUsername = (data.fromUsername && data.fromUsername !== 'Jugador')
      ? data.fromUsername
      : (senderData?.username && senderData.username !== 'Jugador' ? senderData.username : (data.fromId && !data.fromId.startsWith('user_') ? data.fromId : (data.fromUsername || 'Rival')));
    const fromProfileImage = senderData?.profileImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=${resolvedFromUsername || 'rival'}`;
    battleRequests.set(requestId, {
      requestId,
      fromId: data.fromId,
      fromUsername: resolvedFromUsername,
      fromProfileImage,
      toId: data.toId,
      toUsername: data.toUsername,
      modeName,
      gameMode,
      createdAt: Date.now()
    });
    
    const targetSocket = findPlayerSocketByUserId(data.toId);
    if (targetSocket) {
      targetSocket.emit('battle-request-received', {
        requestId,
        fromId: data.fromId,
        fromUsername: resolvedFromUsername,
        fromProfileImage,
        modeName,
        gameMode
      });
    }
  });

  socket.on('accept-battle-request', (data) => {
    const request = battleRequests.get(data.requestId);
    if (!request) return;
    
    const matchId = generateMatchId();
    const gameMode = request.gameMode || 'clasico7v7';
    
    const match = {
      matchId,
      player1: request.fromId,
      player2: request.toId,
      player1Socket: findPlayerSocketByUserId(request.fromId)?.id,
      player2Socket: socket.id,
      player1Ready: false,
      player2Ready: false,
      player1CardIndex: null,
      player2CardIndex: null,
      firstPlayer: Math.random() < 0.5 ? 'player1' : 'player2',
      currentRound: 1,
      gameMode,
      createdAt: Date.now()
    };
    
    activeMatches.set(matchId, match);
    
    const player1Socket = findPlayerSocketByUserId(request.fromId);
    const acceptorData = connectedPlayers.get(socket.id) || findConnectedPlayerByUserId(request.toId);
    const senderData = findConnectedPlayerByUserId(request.fromId);

    const resolvedOpponentForSender = (request.toUsername && request.toUsername !== 'Jugador')
      ? request.toUsername
      : (acceptorData?.username && acceptorData.username !== 'Jugador' ? acceptorData.username : (request.toId && !request.toId.startsWith('user_') ? request.toId : (request.toUsername || 'Rival')));

    const resolvedOpponentForAcceptor = (request.fromUsername && request.fromUsername !== 'Jugador')
      ? request.fromUsername
      : (senderData?.username && senderData.username !== 'Jugador' ? senderData.username : (request.fromId && !request.fromId.startsWith('user_') ? request.fromId : (request.fromUsername || 'Rival')));

    const opponentProfileImageForSender = acceptorData?.profileImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=${resolvedOpponentForSender || 'rival'}`;
    const opponentProfileImageForAcceptor = request.fromProfileImage || senderData?.profileImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=${resolvedOpponentForAcceptor || 'rival'}`;

    if (player1Socket) {
      player1Socket.emit('battle-request-accepted', {
        matchId,
        opponentId: request.toId,
        opponentUsername: resolvedOpponentForSender,
        opponentProfileImage: opponentProfileImageForSender,
        isHost: true,
        gameMode
      });
    }
    
    socket.emit('match-created', {
      matchId,
      opponentId: request.fromId,
      opponentUsername: resolvedOpponentForAcceptor,
      opponentProfileImage: opponentProfileImageForAcceptor,
      isHost: false,
      gameMode
    });
    
    battleRequests.delete(data.requestId);

    // Iniciar Draft si corresponde
    startDraftForMatch(match);
  });

  socket.on('reject-battle-request', (data) => {
    const request = battleRequests.get(data.requestId);
    if (!request) return;
    
    const senderSocket = findPlayerSocketByUserId(request.fromId);
    if (senderSocket) {
      senderSocket.emit('battle-request-rejected', {
        opponentUsername: request.toUsername
      });
    }
    battleRequests.delete(data.requestId);
  });

  socket.on('get-battle-requests', () => {
    const playerData = connectedPlayers.get(socket.id);
    if (!playerData) return;
    
    const userRequests = Array.from(battleRequests.values())
      .filter(req => req.toId === playerData.userId);
    socket.emit('battle-requests-list', { requests: userRequests });
  });

  socket.on('draft-card-chosen', (data) => {
    try {
      const match = activeMatches.get(data.matchId);
      if (!match || !match.draft) return;

      const playerRole = resolvePlayerFromSocket(socket, match);
      if (!playerRole) {
        console.warn(`[DRAFT] El socket ${socket.id} no pertenece al match ${data.matchId}`);
        return;
      }

      const isPlayer1 = playerRole === 'player1';
      const playerKey = playerRole;
      const playerState = match.draft[playerKey];

      console.log(`[DRAFT] Match ${data.matchId} - ${playerKey} eligió card: ${data.cardId} en su ronda ${data.round}`);

      // Comprobar que coincide con la ronda del PROPIO jugador
      if (data.round !== playerState.round) {
        console.warn(`[DRAFT] Ronda enviada (${data.round}) no coincide con ronda del jugador (${playerState.round})`);
        return;
      }

      // Obtener la carta elegida de las opciones presentadas
      const choices = playerState.currentChoices;
      if (!choices) return;

      const chosenOption = choices.find(c => c.id === data.cardId);
      if (!chosenOption) {
        console.warn(`[DRAFT] La carta ${data.cardId} no está entre las opciones del jugador`);
        return;
      }

      // Guardar elección en el equipo del jugador
      playerState.team.push(chosenOption);

      // Notificar al oponente del progreso (opcional UI feedback)
      const opponentSocketId = isPlayer1 ? match.player2Socket : match.player1Socket;
      const opponentSocket = io.sockets.sockets.get(opponentSocketId);
      if (opponentSocket) {
        opponentSocket.emit('opponent-draft-progress', {
          round: playerState.round,
          ready: true
        });
      }

      // Avanzar al jugador independientemente
      if (playerState.round < 8) {
        playerState.round += 1;

        // Generar nuevas opciones pasando TODO el equipo elegido hasta ahora
        const nextChoices = generatePlayerDraftChoices(playerState.team);
        playerState.currentChoices = nextChoices;

        // Emitir SOLO a este jugador
        socket.emit('draft-round-options', {
          round: playerState.round,
          choices: playerState.currentChoices
        });

        console.log(`[DRAFT] Match ${data.matchId} - ${playerKey} avanza a su ronda ${playerState.round}`);
      } else {
        // Este jugador completó sus 8 rondas
        playerState.currentChoices = null;
        socket.emit('draft-complete', {});
        console.log(`[DRAFT] Match ${data.matchId} - ${playerKey} completó su draft.`);
      }
    } catch (error) {
      console.error('[DRAFT] Error en draft-card-chosen:', error);
    }
  });

  socket.on('player-ready', (data) => {
    try {
      console.log('[BATTLE] ========================================');
      console.log('[BATTLE] 🎮 EVENTO player-ready RECIBIDO');
      console.log('[BATTLE] Socket ID:', socket.id);
      console.log('[BATTLE] MatchId:', data.matchId);
      console.log('[BATTLE] firstCardIndex recibido:', data.firstCardIndex);
      console.log('[BATTLE] ========================================');
      
      const match = activeMatches.get(data.matchId);
      if (!match) {
        console.error('[BATTLE] ❌ Match no encontrado:', data.matchId);
        console.error('[BATTLE] Matches activos:', Array.from(activeMatches.keys()));
        return;
      }
      
      console.log('[BATTLE] ✅ Match encontrado:', match.matchId);
      
      // Determinar qué jugador está listo
      const playerRole = resolvePlayerFromSocket(socket, match);
      if (!playerRole) {
        console.error(`[BATTLE] player-ready: El socket ${socket.id} no pertenece al match ${data.matchId}`);
        return;
      }
      
      const sanitizeBattleTeam = (team) => {
        if (!Array.isArray(team)) return [];
        return team.map(c => {
          if (!c || typeof c !== 'object') return c;
          const img = c.imageUrl ? String(c.imageUrl).trim() : '';
          const cleanImageUrl = (img.startsWith('data:image') || img.length > 500)
            ? `uploads/${c.id || 'card'}.png`
            : img;
          return {
            ...c,
            imageUrl: cleanImageUrl
          };
        });
      };

      if (playerRole === 'player1') {
        match.player1Ready = true;
        match.player1Team = sanitizeBattleTeam(data.team);
        match.player1Powers = data.powers;
        match.player1AvailableTraits = data.availableTraits || [];  // Guardar traits disponibles
        match.player1Buffs = data.buffs || { buffs: [], byProcedencia: {}, byOwner: {} };  // NUEVO: Guardar buffs
        match.player1Username = connectedPlayers.get(socket.id)?.username || 'Player 1';
        console.log('[BATTLE] Player 1 equipo recibido:', match.player1Team.length, 'cartas');
        console.log('[BATTLE] Player 1 primera carta:', match.player1Team[0]?.name, 'imageUrl:', match.player1Team[0]?.imageUrl, 'stats:', match.player1Team[0]?.stats);
        console.log('[BATTLE] Player 1 buffs recibidos:', match.player1Buffs);
        if (data.firstCardIndex !== undefined) {
          match.player1CardIndex = data.firstCardIndex;
          console.log('[BATTLE] Player 1 carta índice guardado:', match.player1CardIndex);
        }
      } else if (playerRole === 'player2') {
        match.player2Ready = true;
        match.player2Team = sanitizeBattleTeam(data.team);
        match.player2Powers = data.powers;
        match.player2AvailableTraits = data.availableTraits || [];  // Guardar traits disponibles
        match.player2Buffs = data.buffs || { buffs: [], byProcedencia: {}, byOwner: {} };  // NUEVO: Guardar buffs
        match.player2Username = connectedPlayers.get(socket.id)?.username || 'Player 2';
        console.log('[BATTLE] Player 2 equipo recibido:', match.player2Team.length, 'cartas');
        console.log('[BATTLE] Player 2 primera carta:', match.player2Team[0]?.name, 'imageUrl:', match.player2Team[0]?.imageUrl, 'stats:', match.player2Team[0]?.stats);
        console.log('[BATTLE] Player 2 buffs recibidos:', match.player2Buffs);
        if (data.firstCardIndex !== undefined) {
          match.player2CardIndex = data.firstCardIndex;
          console.log('[BATTLE] Player 2 carta índice guardado:', match.player2CardIndex);
        }
      }
      
      console.log(`[BATTLE] Match ${data.matchId} - P1: ${match.player1Ready}, P2: ${match.player2Ready}`);
      
      // Si ambos están listos con equipos, notificar a ambos pero NO iniciar aún
      if (match.player1Ready && match.player2Ready && !match.battleStarted) {
        console.log('[BATTLE] ¡Ambos jugadores listos con equipos! Notificando...');
        
        // Marcar que ya notificamos
        match.bothPlayersNotified = true;
        
        console.log('[BATTLE] Emitiendo opponent-ready a ambos jugadores...');
        
        // Notificar a jugador 1 (recibe datos de player 2)
        const p1Socket = io.sockets.sockets.get(match.player1Socket);
        if (p1Socket) {
          p1Socket.emit('opponent-ready', {
            team: match.player2Team,
            powers: match.player2Powers,
            buffs: match.player2Buffs  // NUEVO: Enviar buffs del oponente
          });
          console.log('[BATTLE] opponent-ready enviado a P1 con buffs de P2');
        }
        
        // Notificar a jugador 2 (recibe datos de player 1)
        const p2Socket = io.sockets.sockets.get(match.player2Socket);
        if (p2Socket) {
          p2Socket.emit('opponent-ready', {
            team: match.player1Team,
            powers: match.player1Powers,
            buffs: match.player1Buffs  // NUEVO: Enviar buffs del oponente
          });
          console.log('[BATTLE] opponent-ready enviado a P2 con buffs de P1');
        }
        
        console.log('[BATTLE] Esperando que ambos jugadores confirmen que están listos para la batalla...');
        return; // NO iniciar batalla todavía
      }
    } catch (error) {
      console.error('[BATTLE] ❌ Error en player-ready:', error.message);
      console.error('[BATTLE] Stack:', error.stack);
      socket.emit('battle-error', { message: 'Error al procesar equipo. Intenta de nuevo.' });
    }
  });
  
  // Nuevo evento: confirmar que el jugador vio la pantalla del oponente y está listo
  socket.on('confirm-battle-ready', (data) => {
    try {
      console.log('[BATTLE] 🔔 Jugador confirma que está listo para iniciar:', socket.id);
      
      const match = activeMatches.get(data.matchId);
      if (!match) {
        console.error('[BATTLE] Match no encontrado');
        return;
      }
      
      // Marcar que este jugador confirmó
      const playerRole = resolvePlayerFromSocket(socket, match);
      if (!playerRole) {
        console.error(`[BATTLE] confirm-battle-ready: El socket ${socket.id} no pertenece al match ${data.matchId}`);
        return;
      }
      
      if (playerRole === 'player1') {
        match.player1Confirmed = true;
      } else if (playerRole === 'player2') {
        match.player2Confirmed = true;
      }
      
      console.log(`[BATTLE] Confirmaciones - P1: ${match.player1Confirmed}, P2: ${match.player2Confirmed}`);
    
    // Si AMBOS confirmaron, AHORA SÍ iniciar batalla
    if (match.player1Confirmed && match.player2Confirmed && !match.battleStarted) {
      match.battleStarted = true;
      console.log('[BATTLE] ¡Ambos jugadores confirmados! INICIANDO BATALLA...');
      
      // Inicializar estado de la batalla
      match.currentRound = 1;
      match.scores = { player1: 0, player2: 0 };
      if (match.player1CardIndex === undefined) match.player1CardIndex = null;
      if (match.player2CardIndex === undefined) match.player2CardIndex = null;
      match.player1Stat = null;
      match.player2Stat = null;
      match.usedCards = { player1: [], player2: [] };
      
      // Decidir quién empieza
      if (!match.firstPlayer) {
        match.firstPlayer = Math.random() < 0.5 ? 'player1' : 'player2';
      }
      console.log(`[BATTLE] ${match.matchId} - Primero juega: ${match.firstPlayer}`);
      
      // Verificar si ambos ya eligieron carta
      const bothCardsSelected = match.player1CardIndex !== null && match.player1CardIndex !== undefined && 
                                match.player2CardIndex !== null && match.player2CardIndex !== undefined;
      console.log('[BATTLE] Ambos ya eligieron carta:', bothCardsSelected);
      
      // Notificar a jugador 1
      const p1Socket = io.sockets.sockets.get(match.player1Socket);
      if (p1Socket) {
        if (bothCardsSelected) {
          const p1Card = match.player1Team[match.player1CardIndex];
          const p2Card = match.player2Team[match.player2CardIndex];
          
          console.log('[BATTLE] P1 recibe select-stat con cartas:', p1Card?.nombre || p1Card?.name, p2Card?.nombre || p2Card?.name);
          
          p1Socket.emit('select-stat', {
            roundNumber: 1,
            firstPlayer: match.firstPlayer,
            isFirstPlayer: match.firstPlayer === 'player1',
            currentTurn: match.firstPlayer,
            isYourTurn: match.firstPlayer === 'player1',
            showRoulette: true,
            playerCard: p1Card,
            opponentCard: p2Card,
            cardIndex: match.player1CardIndex
          });
        } else {
          p1Socket.emit('round-start', {
            roundNumber: 1,
            scores: match.scores,
            firstPlayer: match.firstPlayer,
            isPlayer1: true
          });
        }
      }
      
      // Notificar a jugador 2
      const p2Socket = io.sockets.sockets.get(match.player2Socket);
      if (p2Socket) {
        if (bothCardsSelected) {
          const p1Card = match.player1Team[match.player1CardIndex];
          const p2Card = match.player2Team[match.player2CardIndex];
          
          console.log('[BATTLE] P2 recibe select-stat con cartas:', p2Card?.nombre || p2Card?.name, p1Card?.nombre || p1Card?.name);
          
          p2Socket.emit('select-stat', {
            roundNumber: 1,
            firstPlayer: match.firstPlayer,
            isFirstPlayer: match.firstPlayer === 'player2',
            currentTurn: match.firstPlayer,
            isYourTurn: match.firstPlayer === 'player2',
            showRoulette: true,
            playerCard: p2Card,
            opponentCard: p1Card,
            cardIndex: match.player2CardIndex
          });
        } else {
          p2Socket.emit('round-start', {
            roundNumber: 1,
            scores: match.scores,
            firstPlayer: match.firstPlayer,
            isPlayer1: false
          });
        }
      }
      
      console.log(`[BATTLE] ${match.matchId} - Ronda 1 iniciada`);
    }
    } catch (error) {
      console.error('[BATTLE] ❌ Error en confirm-battle-ready:', error.message);
      console.error('[BATTLE] Stack:', error.stack);
      socket.emit('battle-error', { message: 'Error al iniciar batalla. Intenta de nuevo.' });
    }
  });

  socket.on('card-selected', (data) => {
    try {
      console.log('[BATTLE] Carta seleccionada:', data.matchId, 'cardIndex:', data.cardIndex);
      
      const match = activeMatches.get(data.matchId);
    if (!match) {
      console.error('[BATTLE] Match no encontrado');
      return;
    }
    
    const playerRole = resolvePlayerFromSocket(socket, match);
    if (!playerRole) {
      console.error(`[BATTLE] card-selected: El socket ${socket.id} no pertenece al match ${data.matchId}`);
      return;
    }
    
    let isPlayer1 = playerRole === 'player1';
    let cardSelected = null;
    
    // IMPORTANTE: Verificar si el oponente ya eligió ANTES de guardar nuestra selección
    const opponentAlreadySelected = isPlayer1 
      ? (match.player2CardIndex !== null && match.player2CardIndex !== undefined)
      : (match.player1CardIndex !== null && match.player1CardIndex !== undefined);
    
    console.log(`[BATTLE] Antes de guardar - Oponente ya eligió? ${opponentAlreadySelected}`);
    console.log(`[BATTLE] Estado actual - P1 index: ${match.player1CardIndex}, P2 index: ${match.player2CardIndex}`);
    
    // Guardar selección del jugador
    if (isPlayer1) {
      match.player1CardIndex = data.cardIndex;
      cardSelected = match.player1Team[data.cardIndex];
      console.log('[BATTLE] Player 1 seleccionó carta:', data.cardIndex);
    } else if (playerRole === 'player2') {
      match.player2CardIndex = data.cardIndex;
      cardSelected = match.player2Team[data.cardIndex];
      console.log('[BATTLE] Player 2 seleccionó carta:', data.cardIndex);
    }
    
    // Notificar al oponente que se seleccionó una carta y mostrarle cuál es
    const opponentSocket = io.sockets.sockets.get(
      isPlayer1 ? match.player2Socket : match.player1Socket
    );
    
    if (opponentSocket && cardSelected) {
      if (!opponentAlreadySelected) {
        // Oponente aún no ha elegido, mostrarle la carta elegida y darle su turno
        console.log('[BATTLE] ✅ Enviando opponent-card-selected al oponente');
        console.log('[BATTLE] Carta enviada:', cardSelected.nombre || cardSelected.name);
        opponentSocket.emit('opponent-card-selected', {
          card: cardSelected,
          message: 'El oponente ha seleccionado su carta'
        });
        console.log('[BATTLE] ✅ Evento opponent-card-selected enviado correctamente');
      } else {
        console.log('[BATTLE] ⏭️ Ambos ya eligieron, no enviar opponent-card-selected');
      }
    } else {
      console.error('[BATTLE] ❌ No se pudo enviar evento: opponentSocket:', !!opponentSocket, 'cardSelected:', !!cardSelected);
    }
    
    // Si ambos seleccionaron carta, pedir selección de stat
    if (match.player1CardIndex !== null && match.player1CardIndex !== undefined && 
        match.player2CardIndex !== null && match.player2CardIndex !== undefined) {
      console.log('[BATTLE] Ambos seleccionaron carta, pidiendo stats...');
      
      const p1Socket = io.sockets.sockets.get(match.player1Socket);
      const p2Socket = io.sockets.sockets.get(match.player2Socket);
      
      // Obtener las cartas seleccionadas de cada equipo
      const p1Card = match.player1Team[match.player1CardIndex];
      const p2Card = match.player2Team[match.player2CardIndex];
      
      // Determinar si debe mostrar ruleta (solo en ronda 1)
      const showRoulette = match.currentRound === 1;
      
      console.log('[BATTLE] Enviando select-stat a ambos jugadores...');
      console.log('[BATTLE] - firstPlayer:', match.firstPlayer);
      console.log('[BATTLE] - showRoulette:', showRoulette);
      console.log('[BATTLE] - P1 card:', p1Card?.nombre || p1Card?.name);
      console.log('[BATTLE] - P2 card:', p2Card?.nombre || p2Card?.name);
      
      if (p1Socket) {
        p1Socket.emit('select-stat', {
          roundNumber: match.currentRound,
          firstPlayer: match.firstPlayer,
          isFirstPlayer: match.firstPlayer === 'player1',
          currentTurn: match.firstPlayer,  // Turno actual
          isYourTurn: match.firstPlayer === 'player1',  // Es tu turno?
          playerCard: p1Card,
          opponentCard: p2Card,
          cardIndex: match.player1CardIndex,
          showRoulette: showRoulette
        });
      }
      
      if (p2Socket) {
        p2Socket.emit('select-stat', {
          roundNumber: match.currentRound,
          firstPlayer: match.firstPlayer,
          isFirstPlayer: match.firstPlayer === 'player2',
          currentTurn: match.firstPlayer,  // Turno actual
          isYourTurn: match.firstPlayer === 'player2',  // Es tu turno?
          playerCard: p2Card,
          opponentCard: p1Card,
          cardIndex: match.player2CardIndex,
          showRoulette: showRoulette
        });
      }
    }
    } catch (error) {
      console.error('[BATTLE] ❌ Error en card-selected:', error.message);
      console.error('[BATTLE] Stack:', error.stack);
      socket.emit('battle-error', { message: 'Error al seleccionar carta. Intenta de nuevo.' });
    }
  });

  socket.on('stat-selected', (data) => {
    // CRÍTICO: Envolver TODO en try-catch para prevenir crashes
    try {
      console.log('[BATTLE][SERVER_PATCH_v2026-03-24_01] Handler stat-selected actualizado activo');
      console.log('[BATTLE] Stat seleccionado:', data.matchId, 'stat:', data.stat, 'value:', data.value, '📊 Data completa:', JSON.stringify(data));
      
      const match = activeMatches.get(data.matchId);
      if (!match) {
        console.error('[BATTLE] Match no encontrado');
        return;
      }
    
    // Determinar quién es el jugador
    const playerRole = resolvePlayerFromSocket(socket, match);
    if (!playerRole) {
      console.error(`[BATTLE] stat-selected: El socket ${socket.id} no pertenece al match ${data.matchId}`);
      return;
    }
    
    const isPlayer1 = playerRole === 'player1';
    const playerKey = playerRole;
    
    // Validar si la stat seleccionada ha sido anulada por el oponente en este turno
    if (match.annulledStat && match.annulledStat.targetPlayer === playerKey && match.annulledStat.stat === data.stat) {
      console.log(`[BATTLE] Elección de stat rechazada por ANULO: ${playerKey} intentó elegir ${data.stat}`);
      socket.emit('power-error', {
        powerType: 'anulo',
        message: 'Esta estadística ha sido anulada para este turno. Elige otra.',
        success: false
      });
      return;
    }
    
    // Validar orden de turnos: el segundo jugador no puede elegir antes de que el primer jugador elija
    let shouldGoFirst = match.firstPlayer === playerKey;
    let opponentStat = isPlayer1 ? match.player2Stat : match.player1Stat;
    if (!shouldGoFirst && !opponentStat) {
      console.warn(`[BATTLE] ${playerKey} intentó elegir stat antes de que el primer jugador (${match.firstPlayer}) elija`);
      socket.emit('power-error', {
        powerType: 'turn',
        message: 'Debes esperar a que el rival elija su estadística primero',
        success: false
      });
      return;
    }
    
    // Guardar selección del jugador
    if (isPlayer1) {
      match.player1Stat = data.stat;
      match.player1StatValue = Number(data.value);
      console.log('[BATTLE] Player 1 seleccionó stat:', data.stat);
      console.log('[BATTLE] Player 1 valor recibido del cliente:', match.player1StatValue);
    } else {
      match.player2Stat = data.stat;
      match.player2StatValue = Number(data.value);
      console.log('[BATTLE] Player 2 seleccionó stat:', data.stat);
      console.log('[BATTLE] Player 2 valor recibido del cliente:', match.player2StatValue);
    }
    
    // CRÍTICO: Aplicar estado de poderes enviado por el cliente (evita race condition)
    // El cliente envía su powerState junto con stat-selected para garantizar que
    // los poderes se apliquen ANTES del cálculo, independientemente del orden de llegada
    if (data.powerState) {
      if (!match.powerUpActive) {
        match.powerUpActive = { player1: false, player2: false };
      }
      if (!match.nerfActive) {
        match.nerfActive = { player1: false, player2: false };
      }
      
      if (data.powerState.powerUpActive) {
        match.powerUpActive[playerKey] = true;
        console.log(`[BATTLE] PowerUp de ${playerKey} aplicado desde stat-selected`);
      }
      if (data.powerState.nerfActive) {
        match.nerfActive[playerKey] = true;
        console.log(`[BATTLE] Nerf activo de ${playerKey} confirmado desde stat-selected`);

        // Fallback anti-race-condition: si power-used aún no estableció target, usar el target enviado por cliente
        if ((!match.nerfTarget || !match.nerfTarget.targetStat) && data.powerState.nerfTargetStat) {
          const targetPlayer = isPlayer1 ? 'player2' : 'player1';
          match.nerfTarget = {
            appliedBy: playerKey,
            targetPlayer,
            targetStat: data.powerState.nerfTargetStat
          };
          console.log(`[BATTLE] Nerf target reconstruido desde stat-selected: ${targetPlayer}.${data.powerState.nerfTargetStat}`);
        }
      }
    }
    
    // VERIFICAR TURNOS: El firstPlayer debe elegir primero
    shouldGoFirst = match.firstPlayer === playerKey;
    const opponentSocketId = isPlayer1 ? match.player2Socket : match.player1Socket;
    const opponentSocket = io.sockets.sockets.get(opponentSocketId);
    opponentStat = isPlayer1 ? match.player2Stat : match.player1Stat;
    
    console.log('[BATTLE] Turnos - firstPlayer:', match.firstPlayer, 'playerKey:', playerKey, 'shouldGoFirst:', shouldGoFirst);
    console.log('[BATTLE] Estados - player1Stat:', match.player1Stat, 'player2Stat:', match.player2Stat);
    
    // Si es el primero en elegir
    if (shouldGoFirst && !opponentStat) {
      console.log('[BATTLE] Este jugador eligió primero, notificando al oponente...');
      
      // Notificar al oponente con el stat elegido para que lo vea brillar
      if (opponentSocket) {
        opponentSocket.emit('opponent-stat-selected', {
          stat: data.stat,
          isFirstPlayerChoice: true  // Indicar que es la elección del primero
        });
        console.log('[BATTLE] Oponente notificado, esperando su elección...');
      }
      
      // NO calcular resultado aún, esperar al segundo jugador
      return;
    }
    
    // Si el oponente ya eligió (este es el segundo en elegir) O ambos ya eligieron
    if (opponentStat) {
      console.log('[BATTLE] Ambos seleccionaron stat, notificando al primer jugador y calculando resultado...');
      
      // IMPORTANTE: Notificar al primer jugador del stat que eligió el segundo
      if (opponentSocket) {
        opponentSocket.emit('opponent-stat-selected', {
          stat: data.stat,
          isFirstPlayerChoice: false  // Este es el segundo jugador
        });
        console.log('[BATTLE] Primer jugador notificado del stat del segundo jugador:', data.stat);
      }
      
      // CRÍTICO: Procesar inmediatamente sin setTimeout - los delays causan 503 en Render free tier
      console.log('[BATTLE] Calculando resultado inmediatamente...');
      
      // Obtener las cartas seleccionadas
      const card1 = match.player1Team[match.player1CardIndex];
      const card2 = match.player2Team[match.player2CardIndex];
      
      if (!card1 || !card2) {
        console.error('[BATTLE] Error: Cartas no encontradas');
        return;
      }
      
      // Función helper para obtener valor de stat
      const getStatValue = (card, statName) => {
        // Si la carta tiene la propiedad directamente (ej: card.media)
        if (card[statName] !== undefined) {
          return Number(card[statName]) || 0;
        }
        
        // Si está en el array stats o parametros
        const stats = card.stats || card.parametros || [];
        const statIndex = {
          'media': -1, // Media no está en el array, está como propiedad
          'ninjutsu': 0,
          'taijutsu': 1,
          'resistencia': 2,
          'velocidad': 3,
          'defensa': 4,
          'fisico': 5
        }[statName];
        
        if (statIndex !== undefined && statIndex >= 0 && statIndex < stats.length) {
          return Number(stats[statIndex]) || 0;
        }
        
        console.warn(`[BATTLE] No se encontró stat ${statName} en carta ${card.name || card.nombre}`);
        return 0;
      };
      
      // Obtener los valores de los stats seleccionados por cada jugador
      // ===== USAR VALORES ENVIADOS POR EL CLIENTE (incluyendo buffs) =====
      // El cliente calcula el valor con todos los modificadores (buffs, power ups) y lo envía
      // Si el cliente envía data.value, usarlo. Si no, calcular desde la carta base
      const hasClientValue1 = Number.isFinite(match.player1StatValue);
      const hasClientValue2 = Number.isFinite(match.player2StatValue);
      let value1 = hasClientValue1 ? match.player1StatValue : getStatValue(card1, match.player1Stat);
      let value2 = hasClientValue2 ? match.player2StatValue : getStatValue(card2, match.player2Stat);
      
      console.log(`[BATTLE] Valores base para comparar: value1=${value1} (cliente=${hasClientValue1}), value2=${value2} (cliente=${hasClientValue2})`);
      
      // ============ APLICAR BOOSTS DE TRAITS ============
      // Función helper para calcular boost de trait
      const getTraitBoost = (card, selectedStat, availableTraits) => {
        if (!card.traitId || !availableTraits || availableTraits.length === 0) {
          return 0;
        }
        
        // Buscar el trait de esta carta
        const trait = availableTraits.find(t => t.id === card.traitId);
        if (!trait) {
          return 0;
        }
        
        if (trait.id === 'especialista') {
          return 5;
        }
        if (trait.id === 'monarch') {
          const baseVal = getStatValue(card, selectedStat);
          return Math.floor(baseVal * 0.20);
        }
        
        // Aplicar boost según el tipo de efecto
        if (trait.effect && trait.effect.type === 'boost_all') {
          // boost_all: suma a todas las stats
          return trait.effect.value || 0;
        } else if (trait.effect && trait.effect.type === 'boost_stat') {
          // boost_stat: solo suma a la stat específica
          if (trait.effect.stat === selectedStat) {
            return trait.effect.value || 0;
          }
        }
        
        return 0;
      };
      
      // Calcular y aplicar boosts de traits
      const trait1Boost = getTraitBoost(card1, match.player1Stat, match.player1AvailableTraits);
      const trait2Boost = getTraitBoost(card2, match.player2Stat, match.player2AvailableTraits);
      
      if (!hasClientValue1 && trait1Boost > 0) {
        value1 += trait1Boost;
        console.log(`[BATTLE] Player1 trait boost en ${match.player1Stat}: +${trait1Boost}`);
      }
      if (!hasClientValue2 && trait2Boost > 0) {
        value2 += trait2Boost;
        console.log(`[BATTLE] Player2 trait boost en ${match.player2Stat}: +${trait2Boost}`);
      }
      // ============ FIN BOOSTS DE TRAITS ============
      
      // ============ APLICAR BUFFS DE PROCEDENCIA Y OWNER ============
      // Función helper para calcular buff de procedencia/owner
      const getBuffBoost = (card, selectedStat, playerBuffs) => {
        if (!playerBuffs || !card) return 0;
        
        let totalBuffBoost = 0;
        const baseValue = getStatValue(card, selectedStat);
        
        // Mapeo de nombres de stats entre cliente y servidor
        const statNameMap = {
          'media': 'media',
          'ninjutsu': 'pace',
          'taijutsu': 'shooting', 
          'resistencia': 'passing',
          'velocidad': 'dribbling',
          'defensa': 'defending',
          'fisico': 'physical'
        };
        
        const clientStatName = Object.keys(statNameMap).find(key => statNameMap[key] === selectedStat) || selectedStat;
        
        // Buff de procedencia
        if (card.procedencia && playerBuffs.byProcedencia && playerBuffs.byProcedencia[card.procedencia]) {
          const buffData = playerBuffs.byProcedencia[card.procedencia];
          const percentage = buffData.percentage || 0;
          const buffStats = Array.isArray(buffData.stats) ? buffData.stats : [];
          
          // Verificar si aplica a esta stat
          if (buffStats.includes('all') || buffStats.includes(clientStatName)) {
            const buffValue = Math.floor(baseValue * (percentage / 100));
            totalBuffBoost += buffValue;
            console.log(`[BATTLE] Buff procedencia ${card.procedencia}: +${percentage}% = +${buffValue}`);
          }
        }
        
        // Buff de owner
        if (card.owner && playerBuffs.byOwner && playerBuffs.byOwner[card.owner]) {
          const ownerBuffData = playerBuffs.byOwner[card.owner];
          const percentage = ownerBuffData.percentage || 0;
          const ownerBuffStats = Array.isArray(ownerBuffData.stats) ? ownerBuffData.stats : [];
          
          // Verificar si aplica a esta stat
          if (ownerBuffStats.includes('all') || ownerBuffStats.includes(clientStatName)) {
            const buffValue = Math.floor(baseValue * (percentage / 100));
            totalBuffBoost += buffValue;
            console.log(`[BATTLE] Buff owner ${card.owner}: +${percentage}% = +${buffValue}`);
          }
        }

        // Buff de Kizuna
        const cardBaseId = (card.id || card.uniqueId || '').replace(/_notrait.*$/, '');
        if (playerBuffs.byKizunaCard && playerBuffs.byKizunaCard[cardBaseId]) {
          const kizunaCardBuff = playerBuffs.byKizunaCard[cardBaseId];
          const percentage = (kizunaCardBuff[clientStatName] || 0) + (kizunaCardBuff.all || 0);
          if (percentage > 0) {
            const buffValue = Math.floor(baseValue * (percentage / 100));
            totalBuffBoost += buffValue;
            console.log(`[BATTLE] Buff Kizuna para ${cardBaseId}: +${percentage}% = +${buffValue}`);
          }
        }
        
        return totalBuffBoost;
      };
      
      // Calcular y aplicar buffs
      const buff1Boost = getBuffBoost(card1, match.player1Stat, match.player1Buffs);
      const buff2Boost = getBuffBoost(card2, match.player2Stat, match.player2Buffs);
      
      if (!hasClientValue1 && buff1Boost > 0) {
        value1 += buff1Boost;
        console.log(`[BATTLE] Player1 buff total: +${buff1Boost}`);
      }
      if (!hasClientValue2 && buff2Boost > 0) {
        value2 += buff2Boost;
        console.log(`[BATTLE] Player2 buff total: +${buff2Boost}`);
      }
      // ============ FIN BUFFS ============
      
      // Aplicar Power Up (+3 a todas las stats) si está activo
      if (!hasClientValue1 && match.powerUpActive && match.powerUpActive.player1) {
        value1 += 3;
        console.log('[BATTLE] Player1 tiene Power Up activo: +3');
      }
      if (!hasClientValue2 && match.powerUpActive && match.powerUpActive.player2) {
        value2 += 3;
        console.log('[BATTLE] Player2 tiene Power Up activo: +3');
      }
      
      // Aplicar Nerf (-5 a la stat elegida) si está activo
      if (match.nerfActive && match.nerfTarget) {
        const { appliedBy, targetPlayer, targetStat } = match.nerfTarget;
        
        // Inmunidad a Nerf por rasgos Especialista y Monarch
        const p1Immune = card1 && (card1.traitId === 'especialista' || card1.traitId === 'monarch');
        const p2Immune = card2 && (card2.traitId === 'especialista' || card2.traitId === 'monarch');

        // Si el nerf afecta a player1 y es su stat elegida
        if (targetPlayer === 'player1' && targetStat === match.player1Stat) {
          if (!p1Immune) {
            value1 -= 5;
            console.log('[BATTLE] Player1 tiene Nerf activo en', targetStat, ': -5');
          } else {
            console.log('[BATTLE] Player1 es INMUNE al Nerf (Especialista/Monarch)');
          }
        }
        
        // Si el nerf afecta a player2 y es su stat elegida
        if (targetPlayer === 'player2' && targetStat === match.player2Stat) {
          if (!p2Immune) {
            value2 -= 5;
            console.log('[BATTLE] Player2 tiene Nerf activo en', targetStat, ': -5');
          } else {
            console.log('[BATTLE] Player2 es INMUNE al Nerf (Especialista/Monarch)');
          }
        }
      }
      
      console.log(`[BATTLE] Valores finales con poderes - P1: ${value1}, P2: ${value2}`);
      console.log(`[BATTLE] Comparando: ${card1.name || card1.nombre} (${match.player1Stat}: ${value1}) vs ${card2.name || card2.nombre} (${match.player2Stat}: ${value2})`);
      // NOTA: NO hacer JSON.stringify de cartas completas - puede causar timeouts con imágenes base64
      console.log(`[BATTLE] Card1: ${card1.name || card1.nombre}, media: ${card1.media}`);
      console.log(`[BATTLE] Card2: ${card2.name || card2.nombre}, media: ${card2.media}`);
      
      // Determinar ganador de la ronda
      let winner = null;
      let playerTotalInTie = null;
      let opponentTotalInTie = null;
      
      const isAlternativeMode = (match.gameMode === 'alternativo7v7' || match.gameMode === 'eleccion_alternativo');
      let points = 1;
      
      if (value1 > value2) {
        winner = 'player1';
        points = isAlternativeMode ? Math.abs(value1 - value2) : 1;
        match.scores.player1 += points;
      } else if (value2 > value1) {
        winner = 'player2';
        points = isAlternativeMode ? Math.abs(value1 - value2) : 1;
        match.scores.player2 += points;
      } else {
        // EMPATE - Calcular suma de todas las stats
        console.log('[BATTLE] ¡EMPATE! Sumando todas las stats...');
        
        const stats1 = card1.stats || card1.parametros || [];
        const stats2 = card2.stats || card2.parametros || [];
        
        // Sumar media + todas las stats (incluyendo traits y buffs)
        const computeCardTotal = (card, playerBuffs, availableTraits) => {
          if (!card) return 0;
          const statNamesList = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
          return statNamesList.reduce((sum, s) => {
            const base = getStatValue(card, s);
            const traitB = getTraitBoost(card, s, availableTraits);
            const buffB = getBuffBoost(card, s, playerBuffs);
            return sum + Math.max(1, base + traitB + buffB);
          }, 0);
        };

        let total1 = computeCardTotal(card1, match.player1Buffs, match.player1AvailableTraits);
        let total2 = computeCardTotal(card2, match.player2Buffs, match.player2AvailableTraits);
        
        console.log(`[BATTLE] Total carta P1 (con buffs): ${total1}, Total carta P2 (con buffs): ${total2}`);
        
        playerTotalInTie = total1;
        opponentTotalInTie = total2;
        
        // Determinar ganador por total
        if (total1 > total2) {
          winner = 'player1';
          points = isAlternativeMode ? Math.abs(total1 - total2) : 1;
          match.scores.player1 += points;
          console.log(`[BATTLE] Player1 gana por suma total, recibe +${points} puntos`);
        } else if (total2 > total1) {
          winner = 'player2';
          points = isAlternativeMode ? Math.abs(total1 - total2) : 1;
          match.scores.player2 += points;
          console.log(`[BATTLE] Player2 gana por suma total, recibe +${points} puntos`);
        } else {
          // Empate total - marcar como draw
          winner = 'draw';
          console.log('[BATTLE] Empate total - no se asigna punto');
        }
      }
      
      console.log(`[BATTLE] Resultado ronda ${match.currentRound}: ${winner} - Scores: P1:${match.scores.player1} P2:${match.scores.player2}`);
      
      // Marcar cartas como usadas
      match.usedCards.player1.push(match.player1CardIndex);
      match.usedCards.player2.push(match.player2CardIndex);
      
      // Preparar datos del resultado
      const roundResult = {
        round: match.currentRound,
        winner: winner,
        card1: {
          name: card1.name || card1.nombre,
          stat: match.player1Stat,
          value: value1,
          cardIndex: match.player1CardIndex,
          traitId: card1.traitId || null,
          isImpostor: (card1.traitId === 'impostor'),
          realCard: {
            id: card1.id,
            name: card1.name || card1.nombre,
            imageUrl: card1.imageUrl || card1.imagen || '',
            media: card1.media,
            stats: card1.stats || card1.parametros,
            traitId: card1.traitId || null
          }
        },
        card2: {
          name: card2.name || card2.nombre,
          stat: match.player2Stat,
          value: value2,
          cardIndex: match.player2CardIndex,
          traitId: card2.traitId || null,
          isImpostor: (card2.traitId === 'impostor'),
          realCard: {
            id: card2.id,
            name: card2.name || card2.nombre,
            imageUrl: card2.imageUrl || card2.imagen || '',
            media: card2.media,
            stats: card2.stats || card2.parametros,
            traitId: card2.traitId || null
          }
        },
        scores: { ...match.scores }
      };
      
      // Si hubo empate, incluir totales (player1Total y player2Total)
      if (playerTotalInTie !== null && opponentTotalInTie !== null) {
        roundResult.player1Total = playerTotalInTie;  // Total de player1
        roundResult.player2Total = opponentTotalInTie;  // Total de player2
        console.log(`[BATTLE] Incluyendo totales en resultado: P1=${playerTotalInTie}, P2=${opponentTotalInTie}`);
      }
      
      // Enviar resultado a ambos jugadores
      const p1Socket = io.sockets.sockets.get(match.player1Socket);
      const p2Socket = io.sockets.sockets.get(match.player2Socket);
      
      if (p1Socket) {
        p1Socket.emit('round-result', roundResult);
      }
      
      if (p2Socket) {
        p2Socket.emit('round-result', roundResult);
      }
      
      // Verificar si la batalla ha terminado (SIEMPRE 7 rondas completas)
      const roundsPlayed = match.currentRound;
      
      if (roundsPlayed >= 7) {
        // BATALLA TERMINADA después de 7 rondas
        console.log(`[BATTLE] ${match.matchId} TERMINADA - P1:${match.scores.player1} P2:${match.scores.player2}`);
        
        let battleWinner = 'draw';
        if (match.scores.player1 > match.scores.player2) {
          battleWinner = 'player1';
        } else if (match.scores.player2 > match.scores.player1) {
          battleWinner = 'player2';
        }
        
        const battleResult = {
          matchId: match.matchId,
          winner: battleWinner,
          scores: { ...match.scores },
          player1: match.player1,
          player2: match.player2,
          player1Username: match.player1Username,
          player2Username: match.player2Username,
          totalRounds: roundsPlayed,
          timestamp: Date.now(),
          modo_de_juego: match.gameMode || 'clasico7v7'
        };
        
        // Enviar resultado final a ambos jugadores
        if (p1Socket) {
          p1Socket.emit('battle-finished', battleResult);
        }
        
        if (p2Socket) {
          p2Socket.emit('battle-finished', battleResult);
        }
        
        // Eliminar match después de 5 segundos
        setTimeout(() => {
          activeMatches.delete(match.matchId);
          console.log(`[BATTLE] Match ${match.matchId} eliminado del servidor`);
        }, 5000);
        
      } else {
        // SIGUIENTE RONDA
        // Registrar stats usadas antes de borrarlas
        if (!match.usedStats) {
          match.usedStats = { player1: [], player2: [] };
        }
        if (match.player1Stat) match.usedStats.player1.push(match.player1Stat);
        if (match.player2Stat) match.usedStats.player2.push(match.player2Stat);

        match.currentRound++;
        match.player1CardIndex = null;
        match.player2CardIndex = null;
        match.player1Stat = null;
        match.player2Stat = null;
        match.player1StatValue = null;
        match.player2StatValue = null;
        match.annulledStat = null;
        
        // CRÍTICO: Resetear efectos de poderes por ronda (los poderes son de un solo uso por ronda)
        // powersUsed NO se resetea (cada poder solo se puede usar una vez en toda la batalla)
        // Pero los EFECTOS (powerUpActive, nerfActive, nerfTarget) son solo para la ronda actual
        if (match.powerUpActive) {
          match.powerUpActive = { player1: false, player2: false };
        }
        if (match.nerfActive) {
          match.nerfActive = { player1: false, player2: false };
        }
        match.nerfTarget = null;
        
        // El ganador de la ronda anterior empieza la siguiente
        // Si fue empate, mantener el mismo firstPlayer
        if (winner !== 'draw') {
          match.firstPlayer = winner;
          console.log(`[BATTLE] El ganador ${winner} empezará la siguiente ronda`);
        } else {
          console.log(`[BATTLE] Empate, ${match.firstPlayer} mantiene el turno`);
        }
        
        console.log(`[BATTLE] Preparando ronda ${match.currentRound}...`);
        
        // Esperar 3 segundos antes de iniciar la siguiente ronda
        setTimeout(() => {
          if (p1Socket && p2Socket) {
            // Enviar a player1
            p1Socket.emit('round-start', {
              roundNumber: match.currentRound,
              scores: { ...match.scores },
              usedCards: { ...match.usedCards },
              firstPlayer: match.firstPlayer,
              isPlayer1: true
            });
            
            // Enviar a player2
            p2Socket.emit('round-start', {
              roundNumber: match.currentRound,
              scores: { ...match.scores },
              usedCards: { ...match.usedCards },
              firstPlayer: match.firstPlayer,
              isPlayer1: false
            });
            
            console.log(`[BATTLE] Ronda ${match.currentRound} iniciada`);
          }
        }, 3000);
      }
      // CRÍTICO: setTimeout de 500ms REMOVIDO - causaba timeouts en Render
    }
    } catch (error) {
      console.error('[BATTLE] ❌ ERROR CRÍTICO en stat-selected:', error);
      console.error('[BATTLE] Stack:', error.stack);
      console.error('[BATTLE] Data:', data);
      // Intentar notificar a los jugadores del error
      try {
        const match = activeMatches.get(data.matchId);
        if (match) {
          const p1Socket = io.sockets.sockets.get(match.player1Socket);
          const p2Socket = io.sockets.sockets.get(match.player2Socket);
          if (p1Socket) p1Socket.emit('battle-error', { message: 'Error del servidor' });
          if (p2Socket) p2Socket.emit('battle-error', { message: 'Error del servidor' });
        }
      } catch (e) {
        console.error('[BATTLE] Error al notificar error:', e);
      }
    }
  });

  socket.on('power-used', (data) => {
    try {
      console.log('[LOG-SERVER] EVENTO "power-used" RECIBIDO en el servidor');
      console.log('[LOG-SERVER] Datos del evento:', JSON.stringify(data));
      
      const match = activeMatches.get(data.matchId);
      if (!match) {
        console.error('[LOG-SERVER] ERROR: Match no encontrado para matchId:', data.matchId);
        return;
      }
      
      // Determinar quién es el jugador
      const playerRole = resolvePlayerFromSocket(socket, match);
      if (!playerRole) {
        console.error(`[LOG-SERVER] ERROR: El socket ${socket.id} no pertenece al match ${data.matchId}`);
        socket.emit('power-error', {
          powerType: data.powerType,
          message: 'No perteneces a esta partida',
          success: false
        });
        return;
      }
      console.log('[LOG-SERVER] Jugador identificado como:', playerRole);
      
      const isPlayer1 = playerRole === 'player1';
      const playerKey = playerRole;
      const opponentKey = isPlayer1 ? 'player2' : 'player1';
      const opponentSocketId = isPlayer1 ? match.player2Socket : match.player1Socket;
      const opponentSocket = io.sockets.sockets.get(opponentSocketId);
      
      // Inicializar powersUsed si no existe
      if (!match.powersUsed) {
        match.powersUsed = {
          player1: { swap: false, powerup: false, nerf: false, anulo: false, intercambio: false },
          player2: { swap: false, powerup: false, nerf: false, anulo: false, intercambio: false }
        };
      }
      
      if (!match.powerUpActive) {
        match.powerUpActive = {
          player1: false,
          player2: false
        };
      }
      
      if (!match.nerfActive) {
        match.nerfActive = {
          player1: false,
          player2: false
        };
      }
      
      const powerType = data.powerType;
      
      // SWAP: Intercambio de carta
      if (powerType === 'swap') {
        if (match.powersUsed[playerKey].swap) {
          console.log('[POWER] Poder SWAP ya usado por', playerKey);
          socket.emit('power-error', {
            powerType: 'swap',
            message: 'Ya usaste el poder de reserva',
            success: false
          });
          return;
        }
        
        // Marcar como usado
        match.powersUsed[playerKey].swap = true;
        
        // Obtener nueva carta del índice enviado (soporta perfectamente el índice 7 del Draft y del Team Builder tradicional)
        const newCardIndex = data.newCardIndex;
        if (newCardIndex !== undefined && newCardIndex !== null) {
          const playerTeam = match[`${playerKey}Team`];
          if (!Array.isArray(playerTeam)) {
            console.error('[POWER] SWAP inválido: playerTeam no disponible');
            socket.emit('power-error', {
              powerType: 'swap',
              message: 'No se pudo aplicar reserva (equipo no disponible)',
              success: false
            });
            return;
          }

          if (newCardIndex < 0 || newCardIndex >= playerTeam.length) {
            console.error('[POWER] SWAP inválido: índice fuera de rango', newCardIndex, 'teamLength:', playerTeam.length);
            socket.emit('power-error', {
              powerType: 'swap',
              message: 'No se pudo aplicar reserva (índice inválido)',
              success: false
            });
            return;
          }

          // No permitir swap a una carta ya usada anteriormente
          const usedByPlayer = match.usedCards && Array.isArray(match.usedCards[playerKey]) ? match.usedCards[playerKey] : [];
          if (usedByPlayer.includes(newCardIndex)) {
            console.error('[POWER] SWAP inválido: carta de reserva ya usada', newCardIndex);
            socket.emit('power-error', {
              powerType: 'swap',
              message: 'No se pudo aplicar reserva (la carta ya fue usada)',
              success: false
            });
            return;
          }

          const newCard = playerTeam[newCardIndex];
          
          if (newCard) {
            // Actualizar carta actual del jugador en el servidor
            match[`${playerKey}CardIndex`] = newCardIndex;
            
            console.log('[POWER] SWAP ejecutado:', playerKey, 'nueva carta:', newCard.name || newCard.nombre);
            
            // Notificar a ambos jugadores con animación
            if (opponentSocket) {
              opponentSocket.emit('opponent-power-used', {
                powerType: 'swap',
                playerKey: playerKey,
                newCard: newCard,
                newCardIndex: newCardIndex
              });
            }
            
            // Confirmar al jugador que usó el poder
            socket.emit('power-confirmed', {
              powerType: 'swap',
              success: true,
              newCard: newCard,
              newCardIndex: newCardIndex
            });
          } else {
            console.error('[POWER] SWAP inválido: no existe carta en índice', newCardIndex);
            socket.emit('power-error', {
              powerType: 'swap',
              message: 'No se pudo aplicar reserva (carta no encontrada)',
              success: false
            });
          }
        } else {
          console.error('[POWER] SWAP inválido: newCardIndex faltante');
          socket.emit('power-error', {
            powerType: 'swap',
            message: 'No se pudo aplicar reserva (falta índice de carta)',
            success: false
          });
        }
      }
      
      // POWERUP: +3 a todas las stats
      else if (powerType === 'powerup') {
        if (match.powersUsed[playerKey].powerup) {
          console.log('[POWER] Poder POWERUP ya usado por', playerKey);
          return;
        }
        
        // Marcar como usado y activado
        match.powersUsed[playerKey].powerup = true;
        match.powerUpActive[playerKey] = true;
        
        console.log('[POWER] POWERUP activado por', playerKey);
        
        // Notificar a ambos jugadores con animación
        if (opponentSocket) {
          opponentSocket.emit('opponent-power-used', {
            powerType: 'powerup',
            playerKey: playerKey
          });
        }
        
        // Confirmar al jugador que usó el poder
        socket.emit('power-confirmed', {
          powerType: 'powerup',
          success: true
        });
      }
      
      // NERF: -5 a la stat elegida por el oponente
      else if (powerType === 'nerf') {
        if (match.powersUsed[playerKey].nerf) {
          console.log('[POWER] Poder NERF ya usado por', playerKey);
          return;
        }
        
        // Verificar que el jugador esté perdiendo
        const playerScore = match.scores[playerKey];
        const opponentScore = match.scores[opponentKey];
        
        if (playerScore >= opponentScore) {
          console.log('[POWER] NERF solo se puede usar cuando estás perdiendo');
          socket.emit('power-error', {
            powerType: 'nerf',
            message: 'Solo puedes usar NERF cuando estás perdiendo'
          });
          return;
        }
        
        // Verificar que el oponente ya haya elegido stat
        const opponentStat = match[`${opponentKey}Stat`];
        if (!opponentStat) {
          console.log('[POWER] El oponente no ha elegido stat aún');
          socket.emit('power-error', {
            powerType: 'nerf',
            message: 'El oponente debe elegir su stat primero'
          });
          return;
        }
        
        // Marcar como usado y activado
        match.powersUsed[playerKey].nerf = true;
        match.nerfActive[playerKey] = true;
        
        // Guardar a qué stat se aplica el nerf
        match.nerfTarget = {
          appliedBy: playerKey,
          targetPlayer: opponentKey,
          targetStat: opponentStat
        };
        
        console.log('[POWER] NERF activado por', playerKey, 'sobre stat', opponentStat, 'del', opponentKey);
        
        // Notificar a ambos jugadores con animación
        if (opponentSocket) {
          opponentSocket.emit('opponent-power-used', {
            powerType: 'nerf',
            playerKey: playerKey,
            targetStat: opponentStat
          });
        }
        
        // Confirmar al jugador que usó el poder
        socket.emit('power-confirmed', {
          powerType: 'nerf',
          success: true,
          targetStat: opponentStat
        });
      }
      
      // ANULO: Bloquear una stat del rival
      else if (powerType === 'anulo') {
        console.log('[LOG-SERVER-ANULO] Iniciando procesamiento de ANULO');
        console.log('[LOG-SERVER-ANULO] powersUsed para este jugador:', match.powersUsed[playerKey]);

        if (match.powersUsed[playerKey].anulo) {
          console.log('[LOG-SERVER-ANULO] RECHAZADO: Poder ANULO ya usado por', playerKey);
          socket.emit('power-error', {
            powerType: 'anulo',
            message: 'Ya usaste el poder ANULO',
            success: false
          });
          return;
        }

        // Validar que sea el turno de selección del oponente
        const opponentGoesFirst = match.firstPlayer === opponentKey;
        const playerStat = match[`${playerKey}Stat`];
        const opponentStat = match[`${opponentKey}Stat`];
        console.log('[LOG-SERVER-ANULO] Turno info - firstPlayer:', match.firstPlayer, 'opponentKey:', opponentKey, 'opponentGoesFirst:', opponentGoesFirst);
        console.log('[LOG-SERVER-ANULO] Stats info - playerStat:', playerStat, 'opponentStat:', opponentStat);

        if (!opponentStat) {
          console.log('[LOG-SERVER-ANULO] RECHAZADO: El oponente aún no ha confirmado su stat');
          socket.emit('power-error', {
            powerType: 'anulo',
            message: 'Solo puedes usar ANULO después de que el oponente haya seleccionado su estadística',
            success: false
          });
          return;
        }

        if (playerStat) {
          console.log('[LOG-SERVER-ANULO] RECHAZADO: Ya seleccionaste tu stat');
          socket.emit('power-error', {
            powerType: 'anulo',
            message: 'Debes usar ANULO antes de seleccionar tu propia estadística',
            success: false
          });
          return;
        }

        // Validar que al oponente le queden al menos 2 stats
        if (!match.usedStats) {
          match.usedStats = { player1: [], player2: [] };
        }
        const opponentUsed = match.usedStats[opponentKey] || [];
        const opponentAvailable = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
          .filter(s => !opponentUsed.includes(s));
        console.log('[LOG-SERVER-ANULO] Stats usadas del rival:', opponentUsed, 'disponibles:', opponentAvailable);

        if (opponentAvailable.length <= 1) {
          console.log('[LOG-SERVER-ANULO] RECHAZADO: No se puede usar ANULO con 1 o menos stats disponibles');
          socket.emit('power-error', {
            powerType: 'anulo',
            message: 'No puedes usar ANULO cuando solo le queda una estadística disponible al rival',
            success: false
          });
          return;
        }

        const targetStat = opponentStat;
        console.log('[LOG-SERVER-ANULO] Validaciones superadas. Anulando stat:', targetStat);

        // Limpiar la stat elegida del oponente
        if (opponentKey === 'player1') {
          match.player1Stat = null;
          match.player1StatValue = null;
        } else {
          match.player2Stat = null;
          match.player2StatValue = null;
        }

        // Marcar como usado
        match.powersUsed[playerKey].anulo = true;
        match.annulledStat = {
          appliedBy: playerKey,
          targetPlayer: opponentKey,
          stat: targetStat
        };

        console.log('[LOG-SERVER-ANULO] Aplicado en memoria del servidor. Notificando a sockets.');

        if (opponentSocket) {
          console.log('[LOG-SERVER-ANULO] Enviando "opponent-power-used" a socket rival:', opponentSocket.id);
          opponentSocket.emit('opponent-power-used', {
            powerType: 'anulo',
            playerKey: playerKey,
            targetStat: targetStat
          });
        } else {
          console.warn('[LOG-SERVER-ANULO] ADVERTENCIA: No se encontró socket del rival');
        }

        console.log('[LOG-SERVER-ANULO] Enviando "power-confirmed" a socket emisor:', socket.id);
        socket.emit('power-confirmed', {
          powerType: 'anulo',
          success: true,
          targetStat: targetStat
        });

        // Verificar si tras anular esta stat solo queda 1 stat disponible para el oponente
        const opponentRemaining = opponentAvailable.filter(s => s !== targetStat);
        if (opponentRemaining.length === 1) {
          const remainingStat = opponentRemaining[0];
          console.log(`[SERVER-ANULO] Solo queda 1 stat para ${opponentKey}: ${remainingStat}. Auto-asignando.`);

          const getStatValue = (card, statName) => {
            if (card[statName] !== undefined) {
              return Number(card[statName]) || 0;
            }
            const stats = card.stats || card.parametros || [];
            const statIndex = {
              'media': -1,
              'ninjutsu': 0,
              'taijutsu': 1,
              'resistencia': 2,
              'velocidad': 3,
              'defensa': 4,
              'fisico': 5
            }[statName];
            if (statIndex !== undefined && statIndex >= 0 && statIndex < stats.length) {
              return Number(stats[statIndex]) || 0;
            }
            return 0;
          };

          // Auto-asignar la única stat restante
          if (opponentKey === 'player1') {
            match.player1Stat = remainingStat;
            const card1 = match.player1Team[match.player1CardIndex];
            match.player1StatValue = card1 ? getStatValue(card1, remainingStat) : 0;
          } else {
            match.player2Stat = remainingStat;
            const card2 = match.player2Team[match.player2CardIndex];
            match.player2StatValue = card2 ? getStatValue(card2, remainingStat) : 0;
          }

          // Emitir eventos de auto-asignación a los sockets correspondientes
          if (opponentSocket) {
            opponentSocket.emit('stat-auto-assigned', {
              stat: remainingStat,
              message: `Solo te queda 1 estadística disponible. Se ha auto-asignado: ${remainingStat.toUpperCase()}`
            });
          }
          
          socket.emit('opponent-stat-auto-assigned', {
            stat: remainingStat,
            message: `Al rival solo le queda 1 estadística. Se ha auto-asignado: ${remainingStat.toUpperCase()}`
          });
        }
      }
      
      // INTERCAMBIO: Copiar carta aleatoria del rival
      else if (powerType === 'intercambio') {
        console.log('[LOG-SERVER-INTERCAMBIO] Iniciando procesamiento de INTERCAMBIO');
        console.log('[LOG-SERVER-INTERCAMBIO] powersUsed para este jugador:', match.powersUsed[playerKey]);

        if (match.powersUsed[playerKey].intercambio) {
          console.log('[LOG-SERVER-INTERCAMBIO] RECHAZADO: Poder INTERCAMBIO ya usado por', playerKey);
          socket.emit('power-error', {
            powerType: 'intercambio',
            message: 'Ya usaste el poder INTERCAMBIO',
            success: false
          });
          return;
        }

        // Validar que sea nuestro turno
        const playerGoesFirst = match.firstPlayer === playerKey;
        const playerStat = match[`${playerKey}Stat`];
        const opponentStat = match[`${opponentKey}Stat`];
        console.log('[LOG-SERVER-INTERCAMBIO] Turno info - firstPlayer:', match.firstPlayer, 'playerKey:', playerKey, 'playerGoesFirst:', playerGoesFirst);
        console.log('[LOG-SERVER-INTERCAMBIO] Stats info - playerStat:', playerStat, 'opponentStat:', opponentStat);
        
        const isPlayerTurn = (playerGoesFirst && !playerStat) || (!playerGoesFirst && opponentStat && !playerStat);
        console.log('[LOG-SERVER-INTERCAMBIO] ¿Es turno del jugador?', isPlayerTurn);

        if (!isPlayerTurn) {
          console.log('[LOG-SERVER-INTERCAMBIO] RECHAZADO: INTERCAMBIO no se puede usar fuera de tu turno');
          socket.emit('power-error', {
            powerType: 'intercambio',
            message: 'Solo puedes usar INTERCAMBIO durante tu turno de elección de stat',
            success: false
          });
          return;
        }

        const opponentTeam = match[`${opponentKey}Team`];
        console.log('[LOG-SERVER-INTERCAMBIO] Equipo oponente disponible - cantidad de cartas:', opponentTeam ? opponentTeam.length : 'null');

        if (!opponentTeam || opponentTeam.length === 0) {
          console.error('[LOG-SERVER-INTERCAMBIO] RECHAZADO: no hay cartas en equipo oponente');
          socket.emit('power-error', {
            powerType: 'intercambio',
            message: 'El oponente no tiene cartas en su equipo',
            success: false
          });
          return;
        }

        // Seleccionar carta aleatoria del mazo oponente
        const randomIndex = Math.floor(Math.random() * opponentTeam.length);
        const selectedOpponentCard = opponentTeam[randomIndex];
        console.log('[LOG-SERVER-INTERCAMBIO] Carta oponente seleccionada para clonar:', selectedOpponentCard.nombre || selectedOpponentCard.name);

        // Copiar carta en el equipo del jugador con fallback seguro para playerCardIndex
        const playerTeam = match[`${playerKey}Team`];
        let playerCardIndex = match[`${playerKey}CardIndex`];
        console.log('[LOG-SERVER-INTERCAMBIO] Carta actual del jugador index inicial:', playerCardIndex);
        
        if (!playerTeam || playerTeam.length === 0) {
          console.error('[LOG-SERVER-INTERCAMBIO] RECHAZADO: equipo del jugador vacío');
          socket.emit('power-error', {
            powerType: 'intercambio',
            message: 'No se puede usar INTERCAMBIO (equipo vacío)',
            success: false
          });
          return;
        }

        // Fallback: Si playerCardIndex es null o fuera de rango, calcular según ronda actual
        if (playerCardIndex === undefined || playerCardIndex === null || playerCardIndex < 0 || playerCardIndex >= playerTeam.length || !playerTeam[playerCardIndex]) {
          if (match.currentRound && Number.isInteger(match.currentRound) && match.currentRound >= 1) {
            playerCardIndex = Math.min(match.currentRound - 1, playerTeam.length - 1);
          } else {
            playerCardIndex = 0;
          }
          match[`${playerKey}CardIndex`] = playerCardIndex;
          console.log('[LOG-SERVER-INTERCAMBIO] playerCardIndex recalculado y guardado:', playerCardIndex);
        }
        
        const originalCard = playerTeam[playerCardIndex];

        // Clonar carta del oponente preservando el uniqueId original para evitar desincronizaciones
        const transformedCard = JSON.parse(JSON.stringify(selectedOpponentCard));
        if (originalCard && originalCard.uniqueId) {
          transformedCard.uniqueId = originalCard.uniqueId;
        }
        
        playerTeam[playerCardIndex] = transformedCard;
        match.powersUsed[playerKey].intercambio = true;

        console.log('[LOG-SERVER-INTERCAMBIO] INTERCAMBIO ejecutado. Carta original ID:', originalCard.id, '-> Carta clonada ID:', transformedCard.id);

        if (opponentSocket) {
          console.log('[LOG-SERVER-INTERCAMBIO] Enviando "opponent-power-used" a socket rival:', opponentSocket.id);
          opponentSocket.emit('opponent-power-used', {
            powerType: 'intercambio',
            playerKey: playerKey,
            transformedCard: transformedCard,
            randomIndex: randomIndex
          });
        } else {
          console.warn('[LOG-SERVER-INTERCAMBIO] ADVERTENCIA: No se encontró socket del rival');
        }

        console.log('[LOG-SERVER-INTERCAMBIO] Enviando "power-confirmed" a socket emisor:', socket.id);
        socket.emit('power-confirmed', {
          powerType: 'intercambio',
          success: true,
          transformedCard: transformedCard,
          randomIndex: randomIndex
        });
      }
      
    } catch (err) {
      console.error('[POWER] Error procesando poder:', err);
      socket.emit('power-error', {
        powerType: data.powerType,
        message: 'Error del servidor al procesar el poder'
      });
    }
  });

  socket.on('battle-ended', (data) => {
    const match = activeMatches.get(data.matchId);
    if (!match) return;
    
    const opponentSocketId = socket.id === match.player1Socket ? match.player2Socket : match.player1Socket;
    const opponentSocket = io.sockets.sockets.get(opponentSocketId);
    if (opponentSocket) {
      opponentSocket.emit('battle-ended', {
        winner: data.winner,
        scores: data.scores
      });
    }
    activeMatches.delete(data.matchId);
  });

  // Handler para reincorporación después de reconexión
  socket.on('rejoin-match', (data) => {
    console.log(`[ONLINE] 🔄 Jugador ${socket.id} intentando reincorporarse a match ${data.matchId}`);
    
    const match = activeMatches.get(data.matchId);
    if (!match) {
      console.log(`[ONLINE] ❌ Match ${data.matchId} no encontrado, posiblemente terminó`);
      socket.emit('match-not-found', { matchId: data.matchId });
      return;
    }
    
    // Actualizar socket ID si cambió tras reconexión
    const isPlayer1 = match.player1 === data.userId;
    if (isPlayer1) {
      match.player1Socket = socket.id;
      console.log(`[ONLINE] ✅ Player1 socket actualizado: ${socket.id}`);
    } else {
      match.player2Socket = socket.id;
      console.log(`[ONLINE] ✅ Player2 socket actualizado: ${socket.id}`);
    }
    
    // Enviar estado actual del match al jugador reconectado
    socket.emit('match-state-restored', {
      matchId: data.matchId,
      currentRound: match.currentRound,
      scores: match.scores,
      usedCards: match.usedCards,
      firstPlayer: match.firstPlayer,
      isPlayer1: isPlayer1
    });
    
    console.log(`[ONLINE] 📊 Estado de match restaurado para jugador`);
  });

  // Listener para abandono voluntario de partida
  socket.on('leave-match', (data) => {
    console.log(`[ONLINE] 🚪 Jugador ${socket.id} abandona partida ${data.matchId || 'desconocida'} - Razón: ${data.reason || 'desconocida'}`);
    
    // Buscar la partida activa
    let matchId = data.matchId;
    let match = null;
    
    // Si no se proporciona matchId, buscar por socket
    if (!matchId) {
      for (const [id, m] of activeMatches.entries()) {
        if (m.player1Socket === socket.id || m.player2Socket === socket.id) {
          matchId = id;
          match = m;
          break;
        }
      }
    } else {
      match = activeMatches.get(matchId);
    }
    
    if (match) {
      // Determinar quién abandonó y quién ganó
      const abandonerIsPlayer1 = socket.id === match.player1Socket;
      const winner = abandonerIsPlayer1 ? 'player2' : 'player1'; // El ganador es el que NO abandonó
      
      console.log(`[ONLINE] 🔍 DEBUG ABANDONO:`);
      console.log(`[ONLINE] - Abandonó: ${abandonerIsPlayer1 ? 'player1' : 'player2'} (socket: ${socket.id})`);
      console.log(`[ONLINE] - Ganador: ${winner}`);
      console.log(`[ONLINE] - player1Socket: ${match.player1Socket}`);
      console.log(`[ONLINE] - player2Socket: ${match.player2Socket}`);
      
      // Scores finales: 0-7 para el que abandonó, 7-0 para el ganador
      // Si abandonó player1 → scores: { player1: 0, player2: 7 }
      // Si abandonó player2 → scores: { player1: 7, player2: 0 }
      const finalScores = abandonerIsPlayer1 
        ? { player1: 0, player2: 7 }
        : { player1: 7, player2: 0 };
      
      console.log('[ONLINE] Scores finales 7-0 por abandono:', finalScores);
      
      // Notificar al oponente que ganó por abandono con 7-0
      const opponentSocketId = abandonerIsPlayer1 ? match.player2Socket : match.player1Socket;
      const opponentSocket = io.sockets.sockets.get(opponentSocketId);
      if (opponentSocket) {
        opponentSocket.emit('battle-finished', {
          winner: winner,
          finalScores: finalScores,
          reason: 'disconnect',
          modo_de_juego: match.gameMode || 'clasico7v7'
        });
        console.log(`[ONLINE] ✅ Oponente (${winner}) notificado con victoria 7-0`);
      }
      
      // Notificar al que abandonó que perdió con 0-7
      socket.emit('battle-finished', {
        winner: winner,
        finalScores: finalScores,
        reason: 'surrender',
        modo_de_juego: match.gameMode || 'clasico7v7'
      });
      console.log(`[ONLINE] ✅ Jugador que abandonó (${abandonerIsPlayer1 ? 'player1' : 'player2'}) notificado con derrota 0-7`);
      
      // Eliminar la partida
      activeMatches.delete(matchId);
      console.log(`[ONLINE] Partida ${matchId} terminada por abandono - Ganador: ${winner} con 7-0`);
    }
  });
  
  // Rendirse en batalla
  socket.on('surrender', (data) => {
    console.log(`[ONLINE] 🏳️ Jugador ${socket.id} se rinde en partida ${data.matchId}`);
    
    const match = activeMatches.get(data.matchId);
    if (!match) {
      console.log('[ONLINE] Partida no encontrada');
      return;
    }
    
    // Determinar ganador (el que NO se rindió)
    const isPlayer1 = socket.id === match.player1Socket;
    const winner = isPlayer1 ? 'player2' : 'player1';
    
    const p1Socket = io.sockets.sockets.get(match.player1Socket);
    const p2Socket = io.sockets.sockets.get(match.player2Socket);
    
    // Scores finales: 0-7 para el que se rindió, 7-0 para el ganador
    const finalScores = isPlayer1 
      ? { player1: 0, player2: 7 }
      : { player1: 7, player2: 0 };
      
    // Notificar a ambos jugadores
    if (p1Socket) {
      p1Socket.emit('battle-finished', {
        winner: winner,
        finalScores: finalScores,
        reason: 'surrender',
        modo_de_juego: match.gameMode || 'clasico7v7'
      });
    }
    
    if (p2Socket) {
      p2Socket.emit('battle-finished', {
        winner: winner,
        finalScores: finalScores,
        reason: 'surrender',
        modo_de_juego: match.gameMode || 'clasico7v7'
      });
    }
    
    // No eliminar inmediatamente para permitir revanchas
    match.finished = true;
    match.scores = finalScores; // Actualizar puntuaciones en memoria
    match.rematchRequests = new Set();
    
    console.log(`[ONLINE] Batalla ${data.matchId} terminada por rendición - Ganador: ${winner} con 7-0`);
  });
  
  // Solicitud de revancha
  socket.on('request-rematch', (data) => {
    console.log(`[ONLINE] 🔄 Jugador ${socket.id} solicita revancha en ${data.matchId}`);
    
    const match = activeMatches.get(data.matchId);
    if (!match) {
      console.log('[ONLINE] Partida no encontrada para revancha');
      return;
    }
    
    // Inicializar set de solicitudes si no existe
    if (!match.rematchRequests) {
      match.rematchRequests = new Set();
    }
    
    // Agregar solicitud
    match.rematchRequests.add(socket.id);
    
    const p1Socket = io.sockets.sockets.get(match.player1Socket);
    const p2Socket = io.sockets.sockets.get(match.player2Socket);
    
    // Notificar a ambos del estado actualizado
    const updateData = {
      acceptedCount: match.rematchRequests.size,
      youAccepted: match.rematchRequests.has(socket.id)
    };
    
    if (p1Socket) {
      p1Socket.emit('rematch-update', {
        ...updateData,
        youAccepted: match.rematchRequests.has(match.player1Socket)
      });
    }
    
    if (p2Socket) {
      p2Socket.emit('rematch-update', {
        ...updateData,
        youAccepted: match.rematchRequests.has(match.player2Socket)
      });
    }
    
    // Si ambos aceptaron, iniciar revancha
    if (match.rematchRequests.size === 2) {
      console.log(`[ONLINE] 🎮 Iniciando revancha en ${data.matchId}`);
      
      // Resetear estado de la partida
      match.currentRound = 1;
      match.scores = { player1: 0, player2: 0 };
      match.usedCards = { player1: [], player2: [] };
      match.player1CardIndex = null;
      match.player2CardIndex = null;
      match.player1Stat = null;
      match.player2Stat = null;
      match.finished = false;
      match.rematchRequests = null;
      
      // Determinar nuevo firstPlayer aleatorio
      match.firstPlayer = Math.random() < 0.5 ? 'player1' : 'player2';
      
      // Notificar a ambos jugadores
      setTimeout(() => {
        if (p1Socket) {
          p1Socket.emit('rematch-start', {
            matchId: data.matchId,
            isPlayer1: true,
            firstPlayer: match.firstPlayer,
            playerPowers: match.player1Powers || [],
            opponentPowers: match.player2Powers || []
          });
        }
        
        if (p2Socket) {
          p2Socket.emit('rematch-start', {
            matchId: data.matchId,
            isPlayer1: false,
            firstPlayer: match.firstPlayer,
            playerPowers: match.player2Powers || [],
            opponentPowers: match.player1Powers || []
          });
        }
        
        // Esperar 2 segundos y enviar round-start
        setTimeout(() => {
          if (p1Socket) {
            p1Socket.emit('round-start', {
              roundNumber: 1,
              scores: { player1: 0, player2: 0 },
              usedCards: { player1: [], player2: [] },
              firstPlayer: match.firstPlayer,
              isPlayer1: true,
              showRoulette: true,
              isFirstPlayer: match.firstPlayer === 'player1'
            });
          }
          
          if (p2Socket) {
            p2Socket.emit('round-start', {
              roundNumber: 1,
              scores: { player1: 0, player2: 0 },
              usedCards: { player1: [], player2: [] },
              firstPlayer: match.firstPlayer,
              isPlayer1: false,
              showRoulette: true,
              isFirstPlayer: match.firstPlayer === 'player2'
            });
          }
        }, 2000);
      }, 1000);
    }
  });

  socket.on('disconnect', () => {
    try {
      const playerData = connectedPlayers.get(socket.id);
      const username = playerData?.username || 'Unknown';
      
      console.log(`[ONLINE] ❌ Cliente desconectado: ${socket.id} (${username})`);
      
      // 1. Limpiar de la lista de jugadores conectados
      connectedPlayers.delete(socket.id);
      console.log(`[CLEANUP] Jugador eliminado de connectedPlayers. Restantes: ${connectedPlayers.size}`);
      
      // 2. Limpiar de la cola de matchmaking
      const queueIndex = matchmakingQueue.findIndex(p => p.socketId === socket.id);
      if (queueIndex !== -1) {
        const removed = matchmakingQueue.splice(queueIndex, 1);
        console.log(`[CLEANUP] Jugador ${username} eliminado de cola de matchmaking`);
        io.emit('queue-update', { playersInQueue: matchmakingQueue.length });
      }
      
      // 3. Limpiar solicitudes de batalla pendientes (enviadas o recibidas por este jugador)
      let requestsCleaned = 0;
      for (const [requestId, request] of battleRequests.entries()) {
        if (request.fromId === playerData?.userId || request.toId === playerData?.userId) {
          // Notificar al otro jugador que la solicitud fue cancelada
          const otherUserId = request.fromId === playerData?.userId ? request.toId : request.fromId;
          const otherSocket = findPlayerSocketByUserId(otherUserId);
          if (otherSocket) {
            otherSocket.emit('battle-request-cancelled', { requestId, reason: 'disconnect' });
          }
          battleRequests.delete(requestId);
          requestsCleaned++;
        }
      }
      if (requestsCleaned > 0) {
        console.log(`[CLEANUP] ${requestsCleaned} solicitud(es) de batalla canceladas`);
      }
      
      // 4. Limpiar partidas activas y notificar al oponente
      let matchesCleaned = 0;
      for (const [matchId, match] of activeMatches.entries()) {
        if (match.player1Socket === socket.id || match.player2Socket === socket.id) {
          const isPlayer1 = socket.id === match.player1Socket;
          const winner = isPlayer1 ? 'player2' : 'player1';
          const opponentSocketId = isPlayer1 ? match.player2Socket : match.player1Socket;
          const opponentSocket = io.sockets.sockets.get(opponentSocketId);
          
          // Scores finales: 7-0 para el que sigue conectado
          const finalScores = isPlayer1 
            ? { player1: 0, player2: 7 }
            : { player1: 7, player2: 0 };
          
          if (opponentSocket) {
            opponentSocket.emit('battle-finished', {
              winner: winner,
              finalScores: finalScores,
              reason: 'disconnect',
              disconnectedPlayer: username
            });
            console.log(`[CLEANUP] Oponente notificado de victoria por desconexión en match ${matchId}`);
          }
          
          activeMatches.delete(matchId);
          matchesCleaned++;
        }
      }
      if (matchesCleaned > 0) {
        console.log(`[CLEANUP] ${matchesCleaned} partida(s) terminadas por desconexión`);
      }
      
      console.log(`[CLEANUP] ✅ Desconexión procesada correctamente para ${username}`);
      console.log(`[STATUS] Jugadores: ${connectedPlayers.size} | Cola: ${matchmakingQueue.length} | Partidas: ${activeMatches.size}`);
      
    } catch (error) {
      console.error('[DISCONNECT] ❌ Error procesando desconexión:', error.message);
      console.error('[DISCONNECT] Stack:', error.stack);
      // Intentar limpieza básica aunque haya error
      try {
        connectedPlayers.delete(socket.id);
        const idx = matchmakingQueue.findIndex(p => p.socketId === socket.id);
        if (idx !== -1) matchmakingQueue.splice(idx, 1);
      } catch (cleanupError) {
        console.error('[DISCONNECT] ❌ Error en limpieza de emergencia:', cleanupError.message);
      }
    }
  });
});

// ==================== SISTEMA DE GAMBLING - HIGHER OR LOWER ====================
// Flujo Transaccional Automatizado: Deducción de apuestas y depósitos de premios sincronizados con monedero local y R2

// Almacén global de sesiones de gambling activas en memoria y Leaderboard
const gamblingSessions = {};
let gamblingLeaderboard = { maxStreak: [], maxMultiplier: [], maxUpgrades: [], cardRace: { easy: [], normal: [], hard: [], impossible: [] }, legendaryPack: { epic: [], legendary: [] } };

// Helper para actualizar en memoria el ranking de Carrera de Cartas
function updateCardRaceLeaderboardInMemory(username, difficulty, wins) {
  if (!gamblingLeaderboard.cardRace) {
    gamblingLeaderboard.cardRace = { easy: [], normal: [], hard: [], impossible: [] };
  }
  if (!gamblingLeaderboard.cardRace[difficulty]) {
    gamblingLeaderboard.cardRace[difficulty] = [];
  }
  
  const list = gamblingLeaderboard.cardRace[difficulty];
  const existingIndex = list.findIndex(item => item.username === username);
  
  if (existingIndex !== -1) {
    list[existingIndex].wins = wins;
    list[existingIndex].date = new Date().toISOString();
  } else {
    list.push({
      username,
      wins,
      date: new Date().toISOString()
    });
  }
  
  list.sort((a, b) => b.wins - a.wins);
  if (list.length > 10) {
    gamblingLeaderboard.cardRace[difficulty] = list.slice(0, 10);
  }
}

// Helper para actualizar en memoria el ranking de Sobre Legendario
function updateLegendaryPackLeaderboardInMemory(username, rarity, wins) {
  if (!gamblingLeaderboard.legendaryPack) {
    gamblingLeaderboard.legendaryPack = { epic: [], legendary: [] };
  }
  if (!gamblingLeaderboard.legendaryPack[rarity]) {
    gamblingLeaderboard.legendaryPack[rarity] = [];
  }
  
  const list = gamblingLeaderboard.legendaryPack[rarity];
  const existingIndex = list.findIndex(item => (item.username || '').toLowerCase() === String(username).toLowerCase());
  
  if (existingIndex !== -1) {
    list[existingIndex].username = username;
    list[existingIndex].wins = wins;
    list[existingIndex].date = new Date().toISOString();
  } else {
    list.push({
      username,
      wins,
      date: new Date().toISOString()
    });
  }
  
  list.sort((a, b) => b.wins - a.wins);
  if (list.length > 10) {
    gamblingLeaderboard.legendaryPack[rarity] = list.slice(0, 10);
  }
}

// Cargar Leaderboard desde R2 al arrancar el servidor
async function loadGamblingLeaderboard() {
  try {
    const data = await readFromR2('gambling_leaderboard.json').catch(() => null);
    if (data && typeof data === 'object') {
      gamblingLeaderboard.maxStreak = Array.isArray(data.maxStreak) ? data.maxStreak : [];
      gamblingLeaderboard.maxMultiplier = Array.isArray(data.maxMultiplier) ? data.maxMultiplier : [];
      gamblingLeaderboard.maxUpgrades = Array.isArray(data.maxUpgrades) ? data.maxUpgrades : [];
      gamblingLeaderboard.cardRace = data.cardRace || { easy: [], normal: [], hard: [], impossible: [] };
      if (!gamblingLeaderboard.cardRace.easy) gamblingLeaderboard.cardRace.easy = [];
      if (!gamblingLeaderboard.cardRace.normal) gamblingLeaderboard.cardRace.normal = [];
      if (!gamblingLeaderboard.cardRace.hard) gamblingLeaderboard.cardRace.hard = [];
      if (!gamblingLeaderboard.cardRace.impossible) gamblingLeaderboard.cardRace.impossible = [];
      
      gamblingLeaderboard.legendaryPack = data.legendaryPack || { epic: [], legendary: [] };
      if (!gamblingLeaderboard.legendaryPack.epic) gamblingLeaderboard.legendaryPack.epic = [];
      if (!gamblingLeaderboard.legendaryPack.legendary) gamblingLeaderboard.legendaryPack.legendary = [];
      console.log('[GAMBLING] Leaderboard cargado correctamente desde R2');
    } else {
      console.log('[GAMBLING] No se encontro leaderboard previo en R2. Inicializando vacio.');
    }
    
    // Migración inicial en caliente: si maxUpgrades está vacío, compilarlo desde perfiles de usuario
    if (!gamblingLeaderboard.maxUpgrades || gamblingLeaderboard.maxUpgrades.length === 0) {
      console.log('[GAMBLING] Recompilando ranking de Mejoras desde perfiles de R2...');
      const users = await listUsersFromR2();
      const list = [];
      for (const u of users) {
        try {
          const profile = await readFromR2(userFileKey(u));
          if (profile && Number(profile.total_upgrades_success) > 0) {
            list.push({
              username: u,
              upgrades: Number(profile.total_upgrades_success),
              date: new Date().toISOString()
            });
          }
        } catch (e) {
          // Ignorar error de lectura de archivo individual
        }
      }
      list.sort((a, b) => b.upgrades - a.upgrades);
      gamblingLeaderboard.maxUpgrades = list.slice(0, 10);
      if (gamblingLeaderboard.maxUpgrades.length > 0) {
        await writeToR2('gambling_leaderboard.json', gamblingLeaderboard);
        console.log('[GAMBLING] Ranking de Mejoras recompilado y guardado en R2:', gamblingLeaderboard.maxUpgrades.length, 'usuarios.');
      }
    }

    // Migración inicial en caliente para Carrera de Cartas
    if (gamblingLeaderboard.cardRace) {
      const totalWins = (gamblingLeaderboard.cardRace.easy?.length || 0) +
                        (gamblingLeaderboard.cardRace.normal?.length || 0) +
                        (gamblingLeaderboard.cardRace.hard?.length || 0) +
                        (gamblingLeaderboard.cardRace.impossible?.length || 0);
      if (totalWins === 0) {
        console.log('[GAMBLING] Recompilando ranking de Carrera de Cartas desde perfiles de R2...');
        const users = await listUsersFromR2();
        for (const u of users) {
          try {
            const profile = await readFromR2(userFileKey(u));
            if (profile && profile.cardRaceWins) {
              const wins = profile.cardRaceWins;
              if (wins.easy) updateCardRaceLeaderboardInMemory(u, 'easy', wins.easy);
              if (wins.normal) updateCardRaceLeaderboardInMemory(u, 'normal', wins.normal);
              if (wins.hard) updateCardRaceLeaderboardInMemory(u, 'hard', wins.hard);
              if (wins.impossible) updateCardRaceLeaderboardInMemory(u, 'impossible', wins.impossible);
            }
          } catch (e) {
            // Ignorar error de lectura
          }
        }
        await writeToR2('gambling_leaderboard.json', gamblingLeaderboard);
        console.log('[GAMBLING] Ranking de Carrera de Cartas recompilado y guardado en R2.');
      }
    }

    // Migración inicial en caliente para Sobre Legendario
    if (gamblingLeaderboard.legendaryPack) {
      const totalWins = (gamblingLeaderboard.legendaryPack.epic?.length || 0) +
                        (gamblingLeaderboard.legendaryPack.legendary?.length || 0);
      if (totalWins === 0) {
        console.log('[GAMBLING] Recompilando ranking de Sobre Legendario desde perfiles de R2...');
        const users = await listUsersFromR2();
        for (const u of users) {
          try {
            const profile = await readFromR2(userFileKey(u));
            if (profile && profile.legendaryPackWins) {
              const wins = profile.legendaryPackWins;
              if (wins.epic) updateLegendaryPackLeaderboardInMemory(u, 'epic', wins.epic);
              if (wins.legendary) updateLegendaryPackLeaderboardInMemory(u, 'legendary', wins.legendary);
            }
          } catch (e) {
            // Ignorar error de lectura
          }
        }
        if (gamblingLeaderboard.legendaryPack.epic.length > 0 || gamblingLeaderboard.legendaryPack.legendary.length > 0) {
          await writeToR2('gambling_leaderboard.json', gamblingLeaderboard);
          console.log('[GAMBLING] Ranking de Sobre Legendario recompilado y guardado en R2.');
        }
      }
    }
  } catch (err) {
    console.error('[GAMBLING] Error al cargar leaderboard de R2:', err);
  }
}
loadGamblingLeaderboard();

// Guardar y actualizar Leaderboard en R2 de forma segura
async function updateGamblingLeaderboard(username, streak, multiplier, betType, betAmount, payout, isCashout) {
  let changed = false;
  const now = new Date().toISOString();

  // 1. Clasificación por Racha Máxima (aplica tanto en fallo como en cashout si streak > 0)
  if (streak > 0) {
    const existingIndex = gamblingLeaderboard.maxStreak.findIndex(item => item.username === username);
    if (existingIndex !== -1) {
      if (streak > gamblingLeaderboard.maxStreak[existingIndex].streak) {
        gamblingLeaderboard.maxStreak[existingIndex] = {
          username,
          streak,
          betType,
          betAmount,
          date: now
        };
        changed = true;
      }
    } else {
      gamblingLeaderboard.maxStreak.push({
        username,
        streak,
        betType,
        betAmount,
        date: now
      });
      changed = true;
    }
    // Ordenar descendente y limitar a top 10
    gamblingLeaderboard.maxStreak.sort((a, b) => b.streak - a.streak);
    if (gamblingLeaderboard.maxStreak.length > 10) {
      gamblingLeaderboard.maxStreak = gamblingLeaderboard.maxStreak.slice(0, 10);
    }
  }

  // 2. Clasificación por Multiplicador Máximo (solo aplica al retirarse con éxito)
  if (isCashout && multiplier > 1.0) {
    const existingIndex = gamblingLeaderboard.maxMultiplier.findIndex(item => item.username === username);
    if (existingIndex !== -1) {
      if (multiplier > gamblingLeaderboard.maxMultiplier[existingIndex].multiplier) {
        gamblingLeaderboard.maxMultiplier[existingIndex] = {
          username,
          multiplier: parseFloat(multiplier.toFixed(2)),
          streak,
          betType,
          betAmount,
          payout,
          date: now
        };
        changed = true;
      }
    } else {
      gamblingLeaderboard.maxMultiplier.push({
        username,
        multiplier: parseFloat(multiplier.toFixed(2)),
        streak,
        betType,
        betAmount,
        payout,
        date: now
      });
      changed = true;
    }
    // Ordenar descendente y limitar a top 10
    gamblingLeaderboard.maxMultiplier.sort((a, b) => b.multiplier - a.multiplier);
    if (gamblingLeaderboard.maxMultiplier.length > 10) {
      gamblingLeaderboard.maxMultiplier = gamblingLeaderboard.maxMultiplier.slice(0, 10);
    }
  }

  if (changed) {
    try {
      await writeToR2('gambling_leaderboard.json', gamblingLeaderboard);
      console.log('[GAMBLING] Leaderboard guardado y sincronizado en R2');
    } catch (err) {
      console.error('[GAMBLING] Error al escribir leaderboard en R2:', err);
    }
  }
}

// Guardar y actualizar Leaderboard de Mejoras en R2 de forma segura
async function updateUpgradesLeaderboard(username, totalUpgradesSuccess) {
  if (totalUpgradesSuccess <= 0) return;
  
  let changed = false;
  const now = new Date().toISOString();
  
  if (!gamblingLeaderboard.maxUpgrades) {
    gamblingLeaderboard.maxUpgrades = [];
  }
  
  const existingIndex = gamblingLeaderboard.maxUpgrades.findIndex(item => item.username === username);
  if (existingIndex !== -1) {
    if (totalUpgradesSuccess > gamblingLeaderboard.maxUpgrades[existingIndex].upgrades) {
      gamblingLeaderboard.maxUpgrades[existingIndex] = {
        username,
        upgrades: totalUpgradesSuccess,
        date: now
      };
      changed = true;
    }
  } else {
    gamblingLeaderboard.maxUpgrades.push({
      username,
      upgrades: totalUpgradesSuccess,
      date: now
    });
    changed = true;
  }
  
  // Ordenar descendente y limitar a top 10
  gamblingLeaderboard.maxUpgrades.sort((a, b) => b.upgrades - a.upgrades);
  if (gamblingLeaderboard.maxUpgrades.length > 10) {
    gamblingLeaderboard.maxUpgrades = gamblingLeaderboard.maxUpgrades.slice(0, 10);
  }
  
  if (changed) {
    try {
      await writeToR2('gambling_leaderboard.json', gamblingLeaderboard);
      console.log('[GAMBLING] Leaderboard (Mejoras) guardado y sincronizado en R2');
    } catch (err) {
      console.error('[GAMBLING] Error al escribir leaderboard (Mejoras) en R2:', err);
    }
  }
}

// Helper: Calcular cuotas basadas en la distribución real de las cartas (balanceado / nerfeado)
function calculateGamblingMultipliers(cardMedia) {
  // Asegurar que tenemos un pool de cartas válido, de lo contrario usar fallback simulado
  const cards = (draftCardsPool && draftCardsPool.length > 0) ? draftCardsPool : [
    { media: 85 }, { media: 84 }, { media: 82 }, { media: 82 }, { media: 80 }, { media: 78 }, { media: 74 }, { media: 72 }, { media: 88 }
  ];
  
  const N_total = cards.length;
  let N_higher = 0;
  let N_lower = 0;
  let N_equal = 0;
  
  cards.forEach(c => {
    const m = Number(c.media) || 75;
    if (m > cardMedia) N_higher++;
    else if (m < cardMedia) N_lower++;
    else N_equal++;
  });
  
  // Calcular probabilidades suavizadas para evitar divisiones por cero en los extremos
  let P_higher = (N_higher + 0.5 * N_equal) / N_total;
  let P_lower = (N_lower + 0.5 * N_equal) / N_total;
  
  // Limitar probabilidades en rango seguro
  P_higher = Math.max(0.08, Math.min(0.92, P_higher));
  P_lower = Math.max(0.08, Math.min(0.92, P_lower));
  
  // Curva de cuota amortiguada para comprimir multiplicadores altos manteniendo los bajos
  // P alta (0.80 - 0.90) -> 1.05x - 1.10x (bajos estables)
  // P media (0.50) -> 1.32x
  // P baja (0.10 - 0.30) -> tope de 1.60x (evita multiplicadores x2 o superiores)
  const calcMult = (p) => Math.max(1.03, Math.min(1.60, 1.02 + 0.30 * ((1 - p) / p)));
  
  const mult_higher = calcMult(P_higher);
  const mult_lower = calcMult(P_lower);
  
  return {
    higher: parseFloat(mult_higher.toFixed(2)),
    lower: parseFloat(mult_lower.toFixed(2))
  };
}

// Helper: Generar una pista inmersiva aplicando pesos de drop rate
function generateGamblingHint(card) {
  const options = [
    { type: 'ninjutsu', label: 'Estadística de Ninjutsu', weight: 10 },
    { type: 'taijutsu', label: 'Estadística de Taijutsu', weight: 10 },
    { type: 'resistencia', label: 'Estadística de Resistencia', weight: 10 },
    { type: 'velocidad', label: 'Estadística de Velocidad', weight: 10 },
    { type: 'defensa', label: 'Estadística de Defensa', weight: 10 },
    { type: 'fisico', label: 'Estadística de Físico', weight: 10 },
    { type: 'procedencia', label: 'Nombre de Procedencia', weight: 20 },
    { type: 'calidad_owner', label: 'Calidad y Creador (Owner)', weight: 20 }
  ];
  
  // Selección ponderada por peso
  const totalWeight = options.reduce((sum, opt) => sum + opt.weight, 0);
  let rand = Math.floor(Math.random() * totalWeight);
  let selected = options[options.length - 1];
  
  for (const opt of options) {
    if (rand < opt.weight) {
      selected = opt;
      break;
    }
    rand -= opt.weight;
  }
  
  const stats = card.stats || [60, 60, 60, 60, 60, 60];
  let val = '';
  switch (selected.type) {
    case 'ninjutsu': val = `Ninjutsu: ${stats[0] || 60}`; break;
    case 'taijutsu': val = `Taijutsu: ${stats[1] || 60}`; break;
    case 'resistencia': val = `Resistencia: ${stats[2] || 60}`; break;
    case 'velocidad': val = `Velocidad: ${stats[3] || 60}`; break;
    case 'defensa': val = `Defensa: ${stats[4] || 60}`; break;
    case 'fisico': val = `Físico: ${stats[5] || 60}`; break;
    case 'procedencia': val = `Procedencia: ${card.procedencia || 'Desconocida'}`; break;
    case 'calidad_owner': val = `Calidad: ${card.calidad || card.quality || 'Desconocida'} | Creador (Owner): ${card.owner || 'Nadie'}`; break;
  }
  
  return {
    type: selected.type,
    label: selected.label,
    value: val
  };
}

// Endpoint: Iniciar el juego descontando saldo
app.post('/api/gambling/start/:username', async (req, res) => {
  const username = req.params.username;
  const { betType, betAmount } = req.body;
  
  if (!username) return res.status(400).json({ error: 'Usuario requerido' });
  if (!betType || !['coins', 'kvr'].includes(betType)) return res.status(400).json({ error: 'Tipo de apuesta no valido' });
  
  const amount = parseInt(betAmount) || 0;
  const minBet = betType === 'coins' ? 1000 : 10;
  if (amount < minBet) {
    return res.status(400).json({ error: `La apuesta minima es de ${minBet} ${betType.toUpperCase()}` });
  }
  
  try {
    const key = userFileKey(username);
    let userData = await readFromR2(key);
    if (!userData) return res.status(404).json({ error: 'Usuario no encontrado' });
    
    if (!userData.wallet) userData.wallet = { coins: 0, kvr: 0 };
    
    const currentBalance = parseInt(userData.wallet[betType]) || 0;
    if (currentBalance < amount) {
      return res.status(400).json({ error: 'Saldo insuficiente' });
    }
    
    // Descontar saldo y guardar en R2 de forma persistente
    userData.wallet[betType] = currentBalance - amount;
    await writeToR2(key, userData);
    console.log(`[GAMBLING] ${username} aposto ${amount} ${betType}. Saldo restante: ${userData.wallet[betType]}`);
    
    const pool = (draftCardsPool && draftCardsPool.length > 0) ? draftCardsPool : [
      { id: 'ronan_hatake', name: 'Ronan Hatake', media: 85, stats: [90, 82, 77, 82, 88, 75], quality: 'Oro', owner: 'HugoMan1307', procedencia: 'Konohagakure', imageUrl: 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/ronan.png' }
    ];
    
    const currentCard = pool[Math.floor(Math.random() * pool.length)];
    let nextCardHidden = pool[Math.floor(Math.random() * pool.length)];
    
    let retries = 0;
    while (nextCardHidden.id === currentCard.id && retries < 5) {
      nextCardHidden = pool[Math.floor(Math.random() * pool.length)];
      retries++;
    }
    
    const multipliers = calculateGamblingMultipliers(Number(currentCard.media) || 75);
    const hint = generateGamblingHint(nextCardHidden);
    
    // Aplicar reducción (nerf) según la información que otorga la pista
    const statTypes = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
    if (statTypes.includes(hint.type)) {
      multipliers.higher = parseFloat((multipliers.higher * 0.55).toFixed(2));
      multipliers.lower = parseFloat((multipliers.lower * 0.55).toFixed(2));
    } else if (hint.type === 'calidad_owner') {
      multipliers.higher = parseFloat((multipliers.higher * 0.65).toFixed(2));
      multipliers.lower = parseFloat((multipliers.lower * 0.65).toFixed(2));
    } else if (hint.type === 'procedencia') {
      multipliers.higher = parseFloat((multipliers.higher * 0.78).toFixed(2));
      multipliers.lower = parseFloat((multipliers.lower * 0.78).toFixed(2));
    }
    multipliers.higher = Math.max(1.03, Math.min(1.50, multipliers.higher));
    multipliers.lower = Math.max(1.03, Math.min(1.50, multipliers.lower));
    
    // Almacenar la sesión activa en memoria
    gamblingSessions[username] = {
      betType,
      betAmount: amount,
      currentCard,
      nextCardHidden,
      rachaMultiplier: 1.0,
      currentWin: amount,
      step: 1,
      currentHintType: hint.type,
      activeMultipliers: multipliers
    };
    
    res.json({
      ok: true,
      currentCard: {
        id: currentCard.id,
        name: currentCard.name,
        media: Number(currentCard.media) || 75,
        imageUrl: currentCard.imageUrl || currentCard.imagen || ''
      },
      hint,
      multipliers,
      wallet: userData.wallet
    });
    
  } catch (error) {
    console.error('[GAMBLING] Error en inicio:', error);
    res.status(500).json({ error: String(error) });
  }
});

// Endpoint: Procesar la predicción del jugador
app.post('/api/gambling/guess/:username', async (req, res) => {
  const username = req.params.username;
  const { prediction } = req.body;
  
  if (!username) return res.status(400).json({ error: 'Usuario requerido' });
  if (!prediction || !['higher', 'lower'].includes(prediction)) return res.status(400).json({ error: 'Prediccion no valida' });
  
  const session = gamblingSessions[username];
  if (!session) {
    return res.status(400).json({ error: 'No hay ninguna sesion de juego activa para este usuario' });
  }
  
  try {
    const currentMedia = Number(session.currentCard.media) || 75;
    const nextMedia = Number(session.nextCardHidden.media) || 75;
    
    let isCorrect = false;
    if (prediction === 'higher' && nextMedia >= currentMedia) isCorrect = true;
    if (prediction === 'lower' && nextMedia <= currentMedia) isCorrect = true;
    
    if (nextMedia === currentMedia) isCorrect = true;
    
    if (isCorrect) {
      // Usar el multiplicador ya calculado (que ya tiene el nerf aplicado si era estadística)
      const chosenMultiplier = session.activeMultipliers[prediction];
      
      // Actualizar multiplicador acumulado y ganancias
      session.rachaMultiplier = session.rachaMultiplier * chosenMultiplier;
      session.currentWin = Math.floor(session.betAmount * session.rachaMultiplier);
      session.step += 1;
      
      // Promocionar carta oculta a actual
      session.currentCard = session.nextCardHidden;
      
      // Seleccionar una nueva carta oculta
      const pool = (draftCardsPool && draftCardsPool.length > 0) ? draftCardsPool : [session.currentCard];
      let nextCard = pool[Math.floor(Math.random() * pool.length)];
      let retries = 0;
      while (nextCard.id === session.currentCard.id && retries < 5) {
        nextCard = pool[Math.floor(Math.random() * pool.length)];
        retries++;
      }
      session.nextCardHidden = nextCard;
      
      const nextMultipliers = calculateGamblingMultipliers(Number(session.currentCard.media) || 75);
      const hint = generateGamblingHint(session.nextCardHidden);
      
      // Aplicar reducción (nerf) según la información que otorga la pista
      const statTypes = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
      if (statTypes.includes(hint.type)) {
        nextMultipliers.higher = parseFloat((nextMultipliers.higher * 0.55).toFixed(2));
        nextMultipliers.lower = parseFloat((nextMultipliers.lower * 0.55).toFixed(2));
      } else if (hint.type === 'calidad_owner') {
        nextMultipliers.higher = parseFloat((nextMultipliers.higher * 0.65).toFixed(2));
        nextMultipliers.lower = parseFloat((nextMultipliers.lower * 0.65).toFixed(2));
      } else if (hint.type === 'procedencia') {
        nextMultipliers.higher = parseFloat((nextMultipliers.higher * 0.78).toFixed(2));
        nextMultipliers.lower = parseFloat((nextMultipliers.lower * 0.78).toFixed(2));
      }
      nextMultipliers.higher = Math.max(1.03, Math.min(1.50, nextMultipliers.higher));
      nextMultipliers.lower = Math.max(1.03, Math.min(1.50, nextMultipliers.lower));
      
      // Guardar el estado de la siguiente ronda
      session.currentHintType = hint.type;
      session.activeMultipliers = nextMultipliers;
      
      res.json({
        ok: true,
        win: true,
        currentCard: {
          id: session.currentCard.id,
          name: session.currentCard.name,
          media: Number(session.currentCard.media) || 75,
          imageUrl: session.currentCard.imageUrl || session.currentCard.imagen || ''
        },
        rachaMultiplier: parseFloat(session.rachaMultiplier.toFixed(2)),
        currentWin: session.currentWin,
        hint,
        multipliers: nextMultipliers,
        step: session.step
      });
      
    } else {
      // Game Over: El jugador lo pierde todo
      const failedCard = {
        id: session.nextCardHidden.id,
        name: session.nextCardHidden.name,
        media: Number(session.nextCardHidden.media) || 75,
        imageUrl: session.nextCardHidden.imageUrl || session.nextCardHidden.imagen || ''
      };
      
      const finalStreak = session.step - 1;
      const finalBetType = session.betType;
      const finalBetAmount = session.betAmount;
      
      // Destruir la sesión activa
      delete gamblingSessions[username];
      
      // Actualizar Leaderboard mundial de racha si consiguió al menos 1 acierto
      if (finalStreak > 0) {
        updateGamblingLeaderboard(username, finalStreak, 0.0, finalBetType, finalBetAmount, 0, false);
        
        // Actualizar el perfil del usuario en R2 de forma segura con sus variables personales
        try {
          const key = userFileKey(username);
          let userData = await readFromR2(key);
          if (userData) {
            if (userData.max_gambling_streak === undefined) userData.max_gambling_streak = 0;
            if (finalStreak > userData.max_gambling_streak) {
              userData.max_gambling_streak = finalStreak;
              await writeToR2(key, userData);
              console.log(`[GAMBLING RECORD] Récord personal de racha actualizado para ${username}: ${finalStreak}`);
            }
          }
        } catch (dbErr) {
          console.error('[GAMBLING] Error actualizando récord en R2 (fail):', dbErr);
        }
      }
      
      res.json({
        ok: true,
        win: false,
        revealedCard: failedCard
      });
    }
  } catch (error) {
    console.error('[GAMBLING] Error en prediccion:', error);
    res.status(500).json({ error: String(error) });
  }
});

// Endpoint: Retirada de racha y cobro de premio
app.post('/api/gambling/cashout/:username', async (req, res) => {
  const username = req.params.username;
  
  if (!username) return res.status(400).json({ error: 'Usuario requerido' });
  
  const session = gamblingSessions[username];
  if (!session) {
    return res.status(400).json({ error: 'No hay ninguna sesion de juego activa para este usuario' });
  }
  
  if (session.step <= 1) {
    return res.status(400).json({ error: 'Debes acertar al menos una prediccion antes de poder retirarte' });
  }
  
  try {
    const key = userFileKey(username);
    let userData = await readFromR2(key);
    if (!userData) return res.status(404).json({ error: 'Usuario no encontrado' });
    
    const payout = session.currentWin;
    const betType = session.betType;
    const finalStreak = session.step - 1;
    const finalMultiplier = session.rachaMultiplier;
    const finalBetAmount = session.betAmount;
    
    // Sumar el premio a la billetera de forma persistente
    userData.wallet[betType] = (parseInt(userData.wallet[betType]) || 0) + payout;
    
    // Inicializar y actualizar récords personales del usuario en R2
    if (userData.max_gambling_streak === undefined) userData.max_gambling_streak = 0;
    if (userData.max_gambling_multiplier === undefined) userData.max_gambling_multiplier = 0.0;
    
    let recordUpdated = false;
    if (finalStreak > userData.max_gambling_streak) {
      userData.max_gambling_streak = finalStreak;
      recordUpdated = true;
    }
    if (finalMultiplier > userData.max_gambling_multiplier) {
      userData.max_gambling_multiplier = parseFloat(finalMultiplier.toFixed(2));
      recordUpdated = true;
    }
    
    await writeToR2(key, userData);
    
    console.log(`[GAMBLING] ${username} se retiro con exito. Premio: ${payout} ${betType.toUpperCase()}. Nuevo saldo: ${userData.wallet[betType]}`);
    if (recordUpdated) {
      console.log(`[GAMBLING RECORD] Récords personales actualizados para ${username}: Racha=${userData.max_gambling_streak}, Mult=${userData.max_gambling_multiplier}`);
    }
    
    // Destruir la sesión activa
    delete gamblingSessions[username];
    
    // Actualizar Leaderboards (Racha y Multiplicador)
    updateGamblingLeaderboard(username, finalStreak, finalMultiplier, betType, finalBetAmount, payout, true);
    
    res.json({
      ok: true,
      payout,
      wallet: userData.wallet
    });
    
  } catch (error) {
    console.error('[GAMBLING] Error en cobro:', error);
    res.status(500).json({ error: String(error) });
  }
});

// Endpoint: Obtener el Leaderboard mundial de Gambling (filtrando cuentas admin)
app.get('/api/gambling/leaderboard', async (req, res) => {
  try {
    const users = await listUsersFromR2();
    const userPayloads = await Promise.all(users.map((u) => readFromR2(userFileKey(u)).catch(() => null)));
    const adminUsernames = new Set();
    userPayloads.forEach((u) => {
      if (u && (u.isAdmin === true || u.role === 'admin')) {
        adminUsernames.add(String(u.username || '').trim().toLowerCase());
      }
    });

    const filterList = (arr) => Array.isArray(arr) ? arr.filter(i => !adminUsernames.has(String(i.username || '').trim().toLowerCase())) : [];

    const sanitized = {
      maxStreak: filterList(gamblingLeaderboard.maxStreak),
      maxMultiplier: filterList(gamblingLeaderboard.maxMultiplier),
      maxUpgrades: filterList(gamblingLeaderboard.maxUpgrades),
      cardRace: {
        easy: filterList(gamblingLeaderboard.cardRace?.easy),
        normal: filterList(gamblingLeaderboard.cardRace?.normal),
        hard: filterList(gamblingLeaderboard.cardRace?.hard),
        impossible: filterList(gamblingLeaderboard.cardRace?.impossible)
      },
      legendaryPack: {
        epic: filterList(gamblingLeaderboard.legendaryPack?.epic),
        legendary: filterList(gamblingLeaderboard.legendaryPack?.legendary)
      }
    };

    res.json({
      ok: true,
      leaderboard: sanitized
    });
  } catch (err) {
    res.json({
      ok: true,
      leaderboard: gamblingLeaderboard
    });
  }
});

// Endpoint: Registrar una victoria en Carrera de Cartas y acreditar ganancias
app.post('/api/gambling/card-race/win/:username', async (req, res) => {
  const username = req.params.username;
  const { difficulty, winnings } = req.body;
  
  const validDifficulties = ['easy', 'normal', 'hard', 'impossible'];
  if (!validDifficulties.includes(difficulty)) {
    return res.status(400).json({ error: 'Dificultad inválida' });
  }
  
  try {
    const key = userFileKey(username);
    let userData = await readFromR2(key);
    if (!userData) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }
    
    if (!userData.cardRaceWins) {
      userData.cardRaceWins = { easy: 0, normal: 0, hard: 0, impossible: 0 };
    }
    
    userData.cardRaceWins[difficulty] = (userData.cardRaceWins[difficulty] || 0) + 1;
    
    // Acreditar ganancias al monedero en servidor
    const winAmount = Number(winnings) || 0;
    if (winAmount > 0) {
      if (!userData.wallet) userData.wallet = { coins: 0, kvr: 0 };
      userData.wallet.coins = (Number(userData.wallet.coins) || 0) + winAmount;
      if (!userData.stats) userData.stats = {};
      userData.stats.totalCoinsEarned = (Number(userData.stats.totalCoinsEarned) || 0) + winAmount;
    }

    userData.updatedAt = Date.now();
    
    await writeToR2(key, userData);
    
    // Actualizar el leaderboard en memoria y guardar en R2
    updateCardRaceLeaderboardInMemory(username, difficulty, userData.cardRaceWins[difficulty]);
    await writeToR2('gambling_leaderboard.json', gamblingLeaderboard);
    
    console.log(`[GAMBLING] Carrera de Cartas victoria registrada para ${username} en dificultad ${difficulty}. Ganancias: +${winAmount}. Total victorias: ${userData.cardRaceWins[difficulty]}`);
    
    res.json({
      ok: true,
      leaderboard: gamblingLeaderboard,
      userWins: userData.cardRaceWins,
      wallet: userData.wallet
    });
  } catch (error) {
    console.error('[GAMBLING] Error al registrar victoria en Carrera de Cartas:', error);
    res.status(500).json({ error: String(error) });
  }
});

// Endpoint: Registrar un sobre obtenido de rareza Épica o Legendaria
app.post('/api/gambling/legendary-pack/win/:username', async (req, res) => {
  const username = String(req.params.username || '').trim();
  const { rarity } = req.body;
  
  const validRarities = ['epic', 'legendary'];
  if (!validRarities.includes(rarity)) {
    return res.status(400).json({ error: 'Rareza inválida para leaderboard' });
  }
  
  try {
    let key = userFileKey(username);
    let userData = await readFromR2(key);
    if (!userData) {
      try {
        const users = await listUsersFromR2();
        const matched = users.find(u => u.toLowerCase() === username.toLowerCase());
        if (matched) {
          key = userFileKey(matched);
          userData = await readFromR2(key);
        }
      } catch (findErr) {}
    }
    
    if (!userData) {
      userData = { username, legendaryPackWins: { epic: 0, legendary: 0 } };
    }
    
    if (!userData.legendaryPackWins) {
      userData.legendaryPackWins = { epic: 0, legendary: 0 };
    }
    
    userData.legendaryPackWins[rarity] = (Number(userData.legendaryPackWins[rarity]) || 0) + 1;
    userData.updatedAt = Date.now();
    
    await writeToR2(key, userData);
    
    // Actualizar el leaderboard en memoria y guardar en R2
    const finalUsername = userData.username || username;
    updateLegendaryPackLeaderboardInMemory(finalUsername, rarity, userData.legendaryPackWins[rarity]);
    await writeToR2('gambling_leaderboard.json', gamblingLeaderboard);
    
    console.log(`[GAMBLING] Sobre Legendario registrado para ${finalUsername} en rareza ${rarity}. Total: ${userData.legendaryPackWins[rarity]}`);
    
    res.json({
      ok: true,
      leaderboard: gamblingLeaderboard,
      userWins: userData.legendaryPackWins
    });
  } catch (error) {
    console.error('[GAMBLING] Error al registrar victoria en Sobre Legendario:', error);
    res.status(500).json({ error: String(error) });
  }
});

// ==================== SISTEMA DE UPGRADER ("MEJORÁMELA") ====================

// Helper para encontrar una carta en el catálogo
function findCardInCatalog(cardId) {
  if (Array.isArray(draftCardsPool)) {
    return draftCardsPool.find(c => c.id === cardId);
  }
  return null;
}

// Helper para obtener el rating real de una carta (estándar o instancia con bonus)
function getCardRating(idOrInstanceId, userData) {
  let cardId = idOrInstanceId;
  let bonus = 0;
  if (userData.cardTraits && userData.cardTraits[idOrInstanceId]) {
    cardId = userData.cardTraits[idOrInstanceId].cardId;
  }
  if (userData.cardUpgrades && userData.cardUpgrades[idOrInstanceId]) {
    cardId = userData.cardUpgrades[idOrInstanceId].cardId;
    bonus = Number(userData.cardUpgrades[idOrInstanceId].mediaBonus) || 0;
  }
  if (idOrInstanceId.includes('_') && !userData.cardTraits?.[idOrInstanceId] && !userData.cardUpgrades?.[idOrInstanceId]) {
    // Si la cadena completa es una carta válida del catálogo, usarla tal cual
    if (findCardInCatalog(idOrInstanceId)) {
      cardId = idOrInstanceId;
    } else {
      // De lo contrario, recortar sufijo de instancia por último guion bajo
      const lastIndex = idOrInstanceId.lastIndexOf('_');
      if (lastIndex !== -1) {
        const possibleCardId = idOrInstanceId.substring(0, lastIndex);
        if (findCardInCatalog(possibleCardId)) {
          cardId = possibleCardId;
        } else {
          cardId = idOrInstanceId.split('_')[0];
        }
      }
    }
  }
  const baseCard = findCardInCatalog(cardId);
  const baseMedia = baseCard ? (Number(baseCard.media) || 75) : 75;
  return baseMedia + bonus;
}

// Helper para obtener el ID base de catálogo de una carta o instancia
function getBaseCardId(idOrInstanceId, userData) {
  if (userData.cardTraits && userData.cardTraits[idOrInstanceId]) {
    return userData.cardTraits[idOrInstanceId].cardId;
  }
  if (userData.cardUpgrades && userData.cardUpgrades[idOrInstanceId]) {
    return userData.cardUpgrades[idOrInstanceId].cardId;
  }
  if (idOrInstanceId.includes('_')) {
    // Si la cadena completa es una carta válida del catálogo, usarla tal cual
    if (findCardInCatalog(idOrInstanceId)) {
      return idOrInstanceId;
    }
    // De lo contrario, recortar sufijo por último guion bajo
    const lastIndex = idOrInstanceId.lastIndexOf('_');
    if (lastIndex !== -1) {
      const possibleCardId = idOrInstanceId.substring(0, lastIndex);
      if (findCardInCatalog(possibleCardId)) {
        return possibleCardId;
      }
    }
    return idOrInstanceId.split('_')[0];
  }
  return idOrInstanceId;
}

// Endpoint: Lógica segura de Upgrader ("Mejorámela")
app.post('/api/gambling/upgrade/:username', async (req, res) => {
  const username = req.params.username;
  const { targetCardInstanceId, sacrificedCardInstanceIds } = req.body;
  
  if (!username) return res.status(400).json({ error: 'Usuario requerido' });
  if (!targetCardInstanceId) return res.status(400).json({ error: 'Carta objetivo requerida' });
  if (!Array.isArray(sacrificedCardInstanceIds) || sacrificedCardInstanceIds.length === 0) {
    return res.status(400).json({ error: 'Debes sacrificar al menos una carta' });
  }
  
  try {
    const key = userFileKey(username);
    let userData = await readFromR2(key);
    if (!userData) return res.status(404).json({ error: 'Usuario no encontrado' });
    
    if (!userData.cards) userData.cards = {};
    if (!userData.cardTraits) userData.cardTraits = {};
    if (!userData.cardUpgrades) userData.cardUpgrades = {};
    
    // 1. Validar que la carta objetivo exista en el inventario
    const targetBaseId = getBaseCardId(targetCardInstanceId, userData);
    const isTargetInstance = targetCardInstanceId !== targetBaseId;
    
    if (isTargetInstance) {
      const existsInTraits = !!userData.cardTraits[targetCardInstanceId];
      const existsInUpgrades = !!userData.cardUpgrades[targetCardInstanceId];
      if (!existsInTraits && !existsInUpgrades) {
        return res.status(400).json({ error: 'La carta objetivo especificada no existe en tus mapas de instancias' });
      }
    }
    
    // 2. Acumular requerimientos y consumiciones
    const totalRequired = {};
    
    // Sacrificadas
    for (const sacId of sacrificedCardInstanceIds) {
      const baseId = getBaseCardId(sacId, userData);
      totalRequired[baseId] = (totalRequired[baseId] || 0) + 1;
      
      const isSacInstance = sacId !== baseId;
      if (isSacInstance) {
        const existsInTraits = !!userData.cardTraits[sacId];
        const existsInUpgrades = !!userData.cardUpgrades[sacId];
        if (!existsInTraits && !existsInUpgrades) {
          return res.status(400).json({ error: `La carta de sacrificio ${sacId} no existe en tus mapas` });
        }
      }
    }
    
    // Incluir carta objetivo en consumo requerido para asegurar copias suficientes
    totalRequired[targetBaseId] = (totalRequired[targetBaseId] || 0) + 1;
    
    // Validar existencias totales
    for (const [cardId, needed] of Object.entries(totalRequired)) {
      const owned = userData.cards[cardId] || 0;
      if (owned < needed) {
        return res.status(400).json({ 
          error: `No posees suficientes copias de la carta ${findCardInCatalog(cardId)?.name || cardId} en tu inventario. Requieres ${needed}, posees ${owned}.` 
        });
      }
    }
    
    // 3. Cómputo de la probabilidad matemática (Fórmula cúbica con penalización de bajo tier y dificultad inversa por media)
    const targetRating = getCardRating(targetCardInstanceId, userData);
    
    // DIFICULTAD INVERSA: f(Rt) = max(0.05, 1 - 0.05 * max(0, Rt - 70))
    const diffMultiplier = Math.max(0.05, 1.0 - 0.05 * Math.max(0, targetRating - 70));
    
    let sumChance = 0;
    
    for (const sacId of sacrificedCardInstanceIds) {
      const sacRating = getCardRating(sacId, userData);
      // CUBIC CURVE: C = 15 * (sacRating / targetRating)^3
      let contribution = 15 * Math.pow(sacRating / targetRating, 3);
      
      // LOW-TIER SACRIFICE NERF: cards <= 75 get penalized by 90%
      if (sacRating <= 75) {
        contribution = contribution * 0.1;
      }
      
      // APLICAR MULTIPLICADOR DE DIFICULTAD INVERSA POR MEDIA
      contribution = contribution * diffMultiplier;
      
      sumChance += contribution;
    }
    
    const finalSuccessChance = Math.min(95, parseFloat(sumChance.toFixed(2)));
    
    // 4. Tirar número aleatorio seguro
    const roll = Math.random() * 100;
    const isSuccess = roll <= finalSuccessChance;
    
    console.log(`[UPGRADER] ${username} intenta mejorar ${targetBaseId} (Rating: ${targetRating}) con ${sacrificedCardInstanceIds.length} sacrificios. Probabilidad de éxito: ${finalSuccessChance}%. Roll: ${roll.toFixed(2)} → ${isSuccess ? 'ÉXITO' : 'FALLO'}`);
    
    // 5. Consumir las cartas de sacrificio (en caso de éxito o de fallo)
    for (const sacId of sacrificedCardInstanceIds) {
      const baseId = getBaseCardId(sacId, userData);
      userData.cards[baseId] = Math.max(0, (userData.cards[baseId] || 0) - 1);
      if (userData.cards[baseId] === 0) {
        delete userData.cards[baseId];
      }
      
      // Si es instancia única, limpiar mapas
      if (sacId !== baseId) {
        delete userData.cardTraits[sacId];
        delete userData.cardUpgrades[sacId];
      }
    }
    
    let isSuperSuccess = false;
    let finalInstanceId = targetCardInstanceId;
    let upgradedCardDetails = null;
    let resultBonus = 0;
    
    if (isSuccess) {
      // Incrementar contador de mejoras exitosas y actualizar ranking
      if (userData.total_upgrades_success === undefined) {
        userData.total_upgrades_success = 0;
      }
      userData.total_upgrades_success++;
      await updateUpgradesLeaderboard(username, userData.total_upgrades_success);

      // Éxito: 10% Super Éxito (Media +5 a +7), 90% Éxito normal (Media +1 a +3)
      const rollSuper = Math.random() * 100;
      let minUpgrade = 1;
      let maxUpgrade = 3;
      
      if (rollSuper < 10) {
        isSuperSuccess = true;
        minUpgrade = 5;
        maxUpgrade = 7;
      }
      
      const minTargetMedia = targetRating + minUpgrade;
      const maxTargetMedia = targetRating + maxUpgrade;
      
      // Buscar candidatos para mutar en el catálogo de cartas (draftCardsPool)
      let candidates = [];
      if (Array.isArray(draftCardsPool)) {
        candidates = draftCardsPool.filter(c => {
          const m = Number(c.media) || 75;
          const q = (c.quality || c.calidad || "").trim().toLowerCase();
          // RESTRICCIÓN DE CATEGORÍA: Debe ser Bronce, Plata u Oro únicamente
          const isBaseTier = ["bronce", "plata", "oro"].includes(q);
          return c.id !== targetBaseId && isBaseTier && m >= minTargetMedia && m <= maxTargetMedia;
        });
        
        // Fallback 1: Si no hay candidatos en el rango específico, buscar cualquier carta distinta base con media superior
        if (candidates.length === 0) {
          candidates = draftCardsPool.filter(c => {
            const m = Number(c.media) || 75;
            const q = (c.quality || c.calidad || "").trim().toLowerCase();
            const isBaseTier = ["bronce", "plata", "oro"].includes(q);
            return c.id !== targetBaseId && isBaseTier && m > targetRating;
          });
          
          if (candidates.length > 0) {
            // Ordenar por media de menor a mayor para quedarnos con el tier superior más cercano
            candidates.sort((a, b) => (Number(a.media) || 75) - (Number(b.media) || 75));
            const baseMinMedia = Number(candidates[0].media) || 75;
            candidates = candidates.filter(c => (Number(c.media) || 75) === baseMinMedia);
          }
        }
      }
      
      let newCard = null;
      if (candidates.length > 0) {
        newCard = candidates[Math.floor(Math.random() * candidates.length)];
      }
      
      if (newCard) {
        // A. MUTACIÓN EXITOSA: Consumir carta objetivo e inyectar la nueva carta mutada de media superior
        userData.cards[targetBaseId] = Math.max(0, (userData.cards[targetBaseId] || 0) - 1);
        if (userData.cards[targetBaseId] === 0) {
          delete userData.cards[targetBaseId];
        }
        
        if (isTargetInstance) {
          delete userData.cardTraits[targetCardInstanceId];
          delete userData.cardUpgrades[targetCardInstanceId];
        }
        
        // Inyectar nueva carta mutada
        const newCardId = newCard.id;
        userData.cards[newCardId] = (userData.cards[newCardId] || 0) + 1;
        finalInstanceId = newCardId;
        
        upgradedCardDetails = {
          id: newCardId,
          instanceId: newCardId,
          name: newCard.name || newCard.nombre || newCardId,
          media: Number(newCard.media) || 75,
          imageUrl: newCard.imageUrl || newCard.imagen || ''
        };
        
        console.log(`[UPGRADER] ¡Mutación con Éxito! Carta objetivo ${targetBaseId} consumida y mutada a ${newCardId} (Media: ${newCard.media}). Super éxito: ${isSuperSuccess}`);
      } else {
        // B. FALLBACK DE SEGURIDAD (Si no hay cartas de media superior en catálogo):
        // Se mejora el bonus de la carta objetivo original (manteniendo el comportamiento clásico como salvaguarda)
        resultBonus = isSuperSuccess ? (Math.floor(Math.random() * 2) === 0 ? 5 : 6) : 2;
        
        if (!isTargetInstance) {
          finalInstanceId = `${targetBaseId}_up_${Date.now()}`;
          userData.cardUpgrades[finalInstanceId] = {
            cardId: targetBaseId,
            mediaBonus: resultBonus
          };
        } else {
          if (!userData.cardUpgrades[targetCardInstanceId]) {
            userData.cardUpgrades[targetCardInstanceId] = {
              cardId: targetBaseId,
              mediaBonus: 0
            };
          }
          userData.cardUpgrades[targetCardInstanceId].mediaBonus += resultBonus;
        }
        
        const currentUpgradedRating = getCardRating(finalInstanceId, userData);
        const targetCardDetails = findCardInCatalog(targetBaseId) || { name: targetBaseId, media: 75 };
        
        upgradedCardDetails = {
          id: targetBaseId,
          instanceId: finalInstanceId,
          name: targetCardDetails.name || targetCardDetails.nombre || targetBaseId,
          media: currentUpgradedRating,
          imageUrl: targetCardDetails.imageUrl || targetCardDetails.imagen || ''
        };
        
        console.log(`[UPGRADER] ¡Éxito de Fallback! No se encontraron cartas superiores para mutar. Carta ${targetBaseId} mejorada por +${resultBonus} puntos.`);
      }
    } else {
      // Fallo: Las cartas de sacrificio se destruyeron (ya procesado arriba), la carta objetivo permanece intacta.
      const targetCardDetails = findCardInCatalog(targetBaseId) || { name: targetBaseId, media: 75 };
      const currentRating = getCardRating(targetCardInstanceId, userData);
      
      upgradedCardDetails = {
        id: targetBaseId,
        instanceId: targetCardInstanceId,
        name: targetCardDetails.name || targetCardDetails.nombre || targetBaseId,
        media: currentRating,
        imageUrl: targetCardDetails.imageUrl || targetCardDetails.imagen || ''
      };
      
      console.log(`[UPGRADER] ¡Fallo! Carta objetivo ${targetBaseId} intacta. Se destruyeron sacrificios.`);
    }
    
    // Guardar cambios a R2 de forma persistente
    await writeToR2(key, userData);
    
    const currentRating = upgradedCardDetails.media;
    
    res.json({
      ok: true,
      success: isSuccess,
      superSuccess: isSuperSuccess,
      mediaBonus: resultBonus,
      finalRating: currentRating,
      instanceId: finalInstanceId,
      upgradedCard: upgradedCardDetails,
      wallet: userData.wallet,
      cards: userData.cards,
      cardTraits: userData.cardTraits,
      cardUpgrades: userData.cardUpgrades
    });
    
  } catch (error) {
    console.error('[UPGRADER] Error en endpoint:', error);
    res.status(500).json({ error: String(error) });
  }
});

// ==================== FIN SISTEMA DE UPGRADER ====================


// Endpoint de estado para online
app.get('/online/status', (req, res) => {
  res.json({
    status: 'online',
    connectedPlayers: connectedPlayers.size,
    matchmakingQueue: matchmakingQueue.length,
    activeMatches: activeMatches.size,
    pendingRequests: battleRequests.size
  });
});

console.log('[ONLINE] Sistema PVP integrado en servidor de inventario');

// ==================== FIN SISTEMA ONLINE PVP ====================

// ==================== MANEJADORES DE ERRORES GLOBALES ====================

// Manejador de errores no capturados en promesas
process.on('unhandledRejection', (reason, promise) => {
  console.error('[ERROR] ⚠️ Promesa rechazada no manejada:', reason);
  console.error('[ERROR] Promesa:', promise);
  // No cerrar el servidor, solo loguear el error
});

// Manejador de excepciones no capturadas
process.on('uncaughtException', (error) => {
  console.error('[ERROR] ⚠️ Excepción no capturada:', error.message);
  console.error('[ERROR] Stack:', error.stack);
  // No cerrar el servidor inmediatamente, intentar continuar
  // En producción, considera usar pm2 o similar para reiniciar automáticamente si es crítico
});

// Manejador de errores de Socket.IO
io.engine.on('connection_error', (err) => {
  console.error('[SOCKET.IO] Error de conexión:', err.message);
  console.error('[SOCKET.IO] Código:', err.code);
  console.error('[SOCKET.IO] Contexto:', err.context);
});

console.log('[SERVER] ✅ Manejadores de errores globales configurados');

// ==================== FIN MANEJADORES DE ERRORES ====================

startServer(PORT);
