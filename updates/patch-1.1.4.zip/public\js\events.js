// events.js - Controlador del Sistema de Eventos
let activeDeliverable = null;
let selectedCardsMap = {}; // instanceId o cardId -> count
let completedEventsList = [];
let deliverableCompletionsMap = {};
let allEvents = [];
let allPacksCatalog = [];

function getDeliverableMaxAllowed(event) {
  if (!event) return 1;
  if (event.repetible === true) return Infinity;
  if (typeof event.repetible === 'number' && event.repetible > 0) return event.repetible;
  if (typeof event.limite === 'number' && event.limite > 0) return event.limite;
  if (typeof event.limiteVeces === 'number' && event.limiteVeces > 0) return event.limiteVeces;
  if (typeof event.maxVeces === 'number' && event.maxVeces > 0) return event.maxVeces;
  if (typeof event.maxRepeticiones === 'number' && event.maxRepeticiones > 0) return event.maxRepeticiones;
  if (typeof event.repeticiones === 'number' && event.repeticiones > 0) return event.repeticiones;
  return 1;
}

function getDeliverableTimesCompleted(eventId) {
  if (deliverableCompletionsMap && typeof deliverableCompletionsMap[eventId] === 'number') {
    return deliverableCompletionsMap[eventId];
  }
  if (Array.isArray(completedEventsList)) {
    return completedEventsList.includes(eventId) ? 1 : 0;
  }
  return 0;
}

function getPackImageUrl(packId) {
  const pack = allPacksCatalog.find(p => p.id === packId);
  return pack?.imageUrl || `./icon-bronce.png`;
}

function getRewardBadgeHtml(type, value, packId = null) {
  const safeAmount = Number(value) || 1;
  if (type === 'coins') {
    return `<span class="reward-badge"><img src="./coin.png" class="reward-icon-inline" alt="Coins" /> ${safeAmount.toLocaleString('es-ES')} Coins</span>`;
  }
  if (type === 'kvr') {
    return `<span class="reward-badge"><img src="./kvr.png" class="reward-icon-inline" alt="KvR" /> ${safeAmount.toLocaleString('es-ES')} KvR</span>`;
  }
  if (type === 'pack') {
    const packImg = getPackImageUrl(packId);
    const pack = allPacksCatalog.find(p => p.id === packId || String(p.id).toLowerCase() === String(packId).toLowerCase());
    const rawName = pack?.name || String(packId || '').replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    const baseName = rawName.replace(/^(?:sobre|pack)\s+/i, '').trim();
    const displayName = safeAmount > 1 ? `${safeAmount} Sobres ${baseName}` : `Sobre ${baseName}`;
    return `<span class="reward-badge"><img src="${packImg}" class="reward-icon-inline" alt="${displayName}" /> ${displayName}</span>`;
  }
  if (type === 'title') {
    const titleName = String(value || packId || '').replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    return `<span class="reward-badge">🏆 Título: ${titleName}</span>`;
  }
  return '';
}

// Cargar entregables desde remoto (GitHub) con caché de LocalStorage
async function loadDeliverablesRemote() {
  console.log('[EVENTS] Cargando entregables desde GitHub...');
  
  // 1. Intentar cargar desde caché
  const cachedData = localStorage.getItem(DELIVERABLES_CACHE_KEY);
  const cachedTime = localStorage.getItem(DELIVERABLES_CACHE_TIME_KEY);
  
  if (cachedData && cachedTime) {
    const elapsed = Date.now() - parseInt(cachedTime, 10);
    if (elapsed < DELIVERABLES_CACHE_DURATION) {
      try {
        const parsed = JSON.parse(cachedData);
        allEvents = parsed.entregables || [];
        console.log('[EVENTS] ✅ Entregables cargados desde caché:', allEvents.length);
        return true;
      } catch (e) {
        console.error('[EVENTS] Error al parsear caché:', e);
      }
    }
  }
  
  // 2. Si no hay caché o expiró, descargar desde remoto
  try {
    const response = await fetch(DELIVERABLES_REMOTE_URL + '?t=' + Date.now());
    if (response.ok) {
      const data = await response.json();
      allEvents = data.entregables || [];
      localStorage.setItem(DELIVERABLES_CACHE_KEY, JSON.stringify(data));
      localStorage.setItem(DELIVERABLES_CACHE_TIME_KEY, Date.now().toString());
      console.log('[EVENTS] ✅ Entregables cargados desde GitHub:', allEvents.length);
      return true;
    } else {
      console.error('[EVENTS] Error HTTP al cargar entregables:', response.status);
    }
  } catch (error) {
    console.error('[EVENTS] Error de conexión al cargar entregables:', error);
  }
  
  // 3. Fallback: Si falló la descarga pero tenemos caché vieja, usarla
  if (cachedData) {
    try {
      const parsed = JSON.parse(cachedData);
      allEvents = parsed.entregables || [];
      console.warn('[EVENTS] ⚠️ Cargando entregables desde caché antigua por error de conexión');
      return true;
    } catch (e) {}
  }
  
  return false;
}

function showEventsLoadingState() {
  const containers = ['deliverables-permanente', 'deliverables-evento', 'deliverables-especial'];
  containers.forEach(id => {
    const container = document.getElementById(id);
    if (container) {
      container.innerHTML = `
        <div class="events-loading-state">
          <span class="loading-spinner">⏳</span>
          <p>Cargando eventos desde el servidor de GitHub...</p>
        </div>
      `;
    }
  });
}

function showEventsErrorState() {
  const containers = ['deliverables-permanente', 'deliverables-evento', 'deliverables-especial'];
  containers.forEach(id => {
    const container = document.getElementById(id);
    if (container) {
      container.innerHTML = `
        <div class="events-error-state">
          <span class="error-icon">⚠️</span>
          <h4>No se pudieron cargar los eventos</h4>
          <p>Hubo un problema al conectar con el servidor de GitHub. Por favor, comprueba tu conexión a internet e inténtalo de nuevo.</p>
          <button class="action-btn retry-btn" onclick="initEvents()">Reintentar</button>
        </div>
      `;
    }
  });
}

// Inicialización del sistema de Eventos
async function initEvents() {
  if (!isElectron) return;
  console.log('[EVENTS] Inicializando sistema de Eventos...');
  
  showEventsLoadingState();
  
  try {
    const [success, packsData] = await Promise.all([
      loadDeliverablesRemote(),
      window.kvrcards.getAllPacks()
    ]);
    
    allPacksCatalog = Array.isArray(packsData) ? packsData : [];
    
    if (!success) {
      showEventsErrorState();
      return;
    }
    
    // Cargar los entregables completados desde IPC
    const completedData = await window.kvrcards.getCompletedDeliverables();
    if (Array.isArray(completedData)) {
      completedEventsList = completedData;
      deliverableCompletionsMap = {};
      completedData.forEach(id => {
        deliverableCompletionsMap[id] = (deliverableCompletionsMap[id] || 0) + 1;
      });
    } else if (completedData && typeof completedData === 'object') {
      completedEventsList = Array.isArray(completedData.completedDeliverables) 
        ? completedData.completedDeliverables 
        : Object.keys(completedData.deliverableCompletions || {});
      deliverableCompletionsMap = (completedData.deliverableCompletions && typeof completedData.deliverableCompletions === 'object')
        ? { ...completedData.deliverableCompletions }
        : {};
      if (Array.isArray(completedEventsList)) {
        completedEventsList.forEach(id => {
          if (!deliverableCompletionsMap[id]) deliverableCompletionsMap[id] = 1;
        });
      }
    } else {
      completedEventsList = [];
      deliverableCompletionsMap = {};
    }
    
    // Renderizar las categorías
    renderEventsList();
  } catch (error) {
    console.error('[EVENTS] Error al inicializar:', error);
    showEventsErrorState();
  }
}

// Renderizar la lista de eventos en sus respectivas categorías
function renderEventsList() {
  const permContainer = document.getElementById('deliverables-permanente');
  const eventContainer = document.getElementById('deliverables-evento');
  const specContainer = document.getElementById('deliverables-especial');
  
  if (permContainer) permContainer.innerHTML = '';
  if (eventContainer) eventContainer.innerHTML = '';
  if (specContainer) specContainer.innerHTML = '';
  
  allEvents.forEach(event => {
    const timesCompleted = getDeliverableTimesCompleted(event.id);
    const maxAllowed = getDeliverableMaxAllowed(event);
    const isCompletedAtLeastOnce = timesCompleted > 0;
    const cannotRepeat = timesCompleted >= maxAllowed;
    
    const cardEl = document.createElement('div');
    cardEl.className = 'deliverable-card';
    if (cannotRepeat) {
      cardEl.classList.add('completed-locked');
    }
    
    // Generar bloque de imágenes asociadas
    let imagesHtml = '';
    if (event.imagenes && event.imagenes.length > 0) {
      const isSingle = event.imagenes.length === 1 ? 'single-image' : '';
      imagesHtml = `
        <div class="deliverable-images-strip ${isSingle}">
          ${event.imagenes.map(imgSrc => `<img src="${imgSrc}" class="deliverable-thumb-img" alt="preview" onerror="this.src='./icon-bronce.png'">`).join('')}
        </div>
      `;
    }
    
    // Generar preview de recompensas
    const rewardsHtmlList = [];
    if (event.recompensas.coins) {
      rewardsHtmlList.push(getRewardBadgeHtml('coins', event.recompensas.coins));
    }
    if (event.recompensas.kvr) {
      rewardsHtmlList.push(getRewardBadgeHtml('kvr', event.recompensas.kvr));
    }
    if (event.recompensas.packs && event.recompensas.packs.length > 0) {
      event.recompensas.packs.forEach(p => {
        rewardsHtmlList.push(getRewardBadgeHtml('pack', p.cantidad, p.id));
      });
    }
    
    const buttonText = cannotRepeat ? 'COMPLETADO' : 'ENTREGAR';
    const buttonDisabled = cannotRepeat ? 'disabled' : '';
    
    let repeatabilityBadge = '';
    if (maxAllowed === Infinity) {
      repeatabilityBadge = `<span class="deliverable-repeatable-badge repeatable">♻ Repetible</span>`;
    } else if (maxAllowed > 1) {
      repeatabilityBadge = `<span class="deliverable-repeatable-badge repeatable">♻ Repetible (${timesCompleted}/${maxAllowed})</span>`;
    } else {
      repeatabilityBadge = `<span class="deliverable-repeatable-badge unique">Único</span>`;
    }
      
    cardEl.innerHTML = `
      <div class="deliverable-card-inner">
        <div class="deliverable-badges-container">
          ${repeatabilityBadge}
          ${isCompletedAtLeastOnce ? `<div class="completed-badge-icon">✓ Completado</div>` : ''}
        </div>
        <h4 class="deliverable-card-title">${event.nombre}</h4>
        <p class="deliverable-card-desc">${event.descripcion}</p>
        ${imagesHtml}
        <div class="deliverable-rewards-box">
          <span class="rewards-title">Recompensas:</span>
          <div class="rewards-values">${rewardsHtmlList.join(' ')}</div>
        </div>
        <button class="action-btn deliverable-card-btn" ${buttonDisabled} onclick="event.stopPropagation(); openEventsDeliveryModal('${event.id}')">${buttonText}</button>
      </div>
    `;
    
    // Clasificar en contenedores (los entregables con tipo especial no se renderizan aquí)
    if (event.tipo === 'permanente' && permContainer) {
      permContainer.appendChild(cardEl);
    } else if (event.tipo === 'evento' && eventContainer) {
      eventContainer.appendChild(cardEl);
    }
  });
}

// Abrir el modal de entrega para un entregable específico
async function openEventsDeliveryModal(eventId) {
  const event = allEvents.find(e => e.id === eventId);
  if (!event) return;
  
  const timesCompleted = getDeliverableTimesCompleted(event.id);
  const maxAllowed = getDeliverableMaxAllowed(event);
  if (timesCompleted >= maxAllowed) {
    alert('Este entregable ya ha alcanzado el límite máximo de entregas.');
    return;
  }
  
  activeDeliverable = event;
  selectedCardsMap = {}; // Resetear selección
  
  // Rellenar información visual del entregable en el modal
  const titleEl = document.getElementById('req-deliverable-name');
  const descEl = document.getElementById('req-deliverable-desc');
  const rewardsContainer = document.getElementById('req-rewards-list');
  
  if (titleEl) titleEl.textContent = event.nombre;
  if (descEl) descEl.textContent = event.descripcion;
  
  if (rewardsContainer) {
    rewardsContainer.innerHTML = '';
    if (event.recompensas.coins) {
      const span = document.createElement('span');
      span.className = 'reward-preview-tag';
      span.innerHTML = getRewardBadgeHtml('coins', event.recompensas.coins);
      rewardsContainer.appendChild(span);
    }
    if (event.recompensas.kvr) {
      const span = document.createElement('span');
      span.className = 'reward-preview-tag';
      span.innerHTML = getRewardBadgeHtml('kvr', event.recompensas.kvr);
      rewardsContainer.appendChild(span);
    }
    if (event.recompensas.packs && event.recompensas.packs.length > 0) {
      event.recompensas.packs.forEach(p => {
        const span = document.createElement('span');
        span.className = 'reward-preview-tag';
        span.innerHTML = getRewardBadgeHtml('pack', p.cantidad, p.id);
        rewardsContainer.appendChild(span);
      });
    }
  }
  
  // Mostrar el modal
  const modal = document.getElementById('events-delivery-modal');
  if (modal) modal.classList.add('show');
  
  // Mover el panel de filtros `.collection-filters` al modal
  const filtersNode = document.querySelector('.collection .collection-filters');
  const anchor = document.getElementById('events-filters-anchor');
  if (filtersNode && anchor) {
    anchor.appendChild(filtersNode);
  }
  
  // Configurar ganchos para la colección compartida
  window.activeCollectionContainer = document.getElementById('events-modal-cards');
  window.activeCollectionSelectionState = (card, isUnique) => {
    const key = isUnique ? card.instanceId : card.id;
    return selectedCardsMap[key] || 0;
  };
  
  window.activeCollectionCardClick = (card, isUnique, maxCount) => {
    const key = isUnique ? card.instanceId : card.id;
    const current = selectedCardsMap[key] || 0;
    
    if (current > 0) {
      // Deseleccionar
      delete selectedCardsMap[key];
    } else {
      // Validar que no se entregue más de una copia de la misma carta base
      const getBaseCardId = (k) => {
        if (k.startsWith('trait_') || (typeof cardUpgradesMap !== 'undefined' && cardUpgradesMap[k])) {
          const traitData = (typeof cardTraitsMap !== 'undefined') ? cardTraitsMap[k] : null;
          const upgradeData = (typeof cardUpgradesMap !== 'undefined') ? cardUpgradesMap[k] : null;
          return traitData?.cardId || upgradeData?.cardId || k;
        }
        return k;
      };
      
      const hasSameBaseSelected = Object.keys(selectedCardsMap).some(k => {
        return selectedCardsMap[k] > 0 && getBaseCardId(k) === card.id;
      });
      
      if (hasSameBaseSelected) {
        alert("No se pueden entregar varias copias de la misma carta en un mismo entregable.");
        return;
      }
      
      // Validar límite total de cartas antes de seleccionar
      const totalSelected = Object.values(selectedCardsMap).reduce((a, b) => a + b, 0);
      if (totalSelected < (activeDeliverable.limites.maxCartas || 999)) {
        selectedCardsMap[key] = 1;
      } else {
        console.warn('[EVENTS] Límite máximo de cartas alcanzado');
      }
    }
    
    // Refrescar renderizado y evaluación en tiempo real
    renderCollection();
    evaluateRequirements();
  };
  
  // Limpiar filtros del buscador para mostrar el inventario limpio
  const searchInput = document.getElementById('collection-search');
  if (searchInput) searchInput.value = '';
  if (typeof collectionSearchText !== 'undefined') collectionSearchText = '';
  
  // Resetear filtros a "none"
  if (typeof currentFilterType !== 'undefined') currentFilterType = 'none';
  if (typeof currentFilterValue !== 'undefined') currentFilterValue = null;
  if (typeof currentFilterType2 !== 'undefined') currentFilterType2 = 'none';
  if (typeof currentFilterValue2 !== 'undefined') currentFilterValue2 = null;
  if (typeof updateFilterButtonText === 'function') updateFilterButtonText();
  if (typeof updateFilterButton2Text === 'function') updateFilterButton2Text();
  
  // Renderizar la colección en la modal
  await renderCollection();
  
  // Ejecutar primera evaluación
  evaluateRequirements();
}

// Cerrar modal de entrega
function closeEventsModal() {
  const modal = document.getElementById('events-delivery-modal');
  if (modal) modal.classList.remove('show');
  
  // Devolver los filtros a su sección original
  const filtersNode = document.getElementById('events-filters-anchor')?.firstElementChild;
  const originalSection = document.querySelector('.collection');
  if (filtersNode && originalSection) {
    const searchHeader = originalSection.querySelector('.collection-header');
    if (searchHeader) {
      originalSection.insertBefore(filtersNode, searchHeader.nextSibling);
    } else {
      originalSection.insertBefore(filtersNode, originalSection.firstChild);
    }
  }
  
  // Limpiar hooks globales
  window.activeCollectionContainer = null;
  window.activeCollectionSelectionState = null;
  window.activeCollectionCardClick = null;
  activeDeliverable = null;
  selectedCardsMap = {};
  
  // Volver a dibujar la colección estándar
  renderCollection();
}

// Evaluar requisitos en tiempo real
function evaluateRequirements() {
  if (!activeDeliverable) return;
  
  const checklistContainer = document.getElementById('events-requirements-list');
  if (!checklistContainer) return;
  
  checklistContainer.innerHTML = '';
  
  let allMet = true;
  const req = activeDeliverable.requisitos;
  const limits = activeDeliverable.limites;
  
  // Obtener lista plana de todas las cartas seleccionadas
  // Cada carta conserva su información, instanceId (si es única) y se repite según la cantidad elegida
  const selectedCardsList = [];
  
  // Para buscar los datos de las cartas, podemos usar el store de colección si está expuesto.
  // Como no está expuesto directamente en events.js, podemos consultar window.kvrcards.getAllCards()
  // Pero para agilizar en tiempo real, podemos usar las cartas cargadas en memoria.
  // Vamos a obtener todas las cartas del catálogo primero para mapear.
  window.kvrcards.getAllCards().then(allCards => {
    const cardsMap = new Map(allCards.map(c => [c.id, c]));
    
    // Obtener también rasgos y upgrades para poder simular sus datos
    window.kvrcards.getInventory().then(inv => {
      const traits = inv.cardTraits || {};
      const upgrades = inv.cardUpgrades || {};
      
      for (const [key, count] of Object.entries(selectedCardsMap)) {
        if (count <= 0) continue;
        
        let cardBase = null;
        let isUnique = false;
        let bonus = 0;
        let traitId = null;
        
        if (key.startsWith('trait_') || upgrades[key]) {
          isUnique = true;
          const traitData = traits[key];
          const upgradeData = upgrades[key];
          const baseId = traitData?.cardId || upgradeData?.cardId;
          cardBase = cardsMap.get(baseId);
          bonus = upgradeData ? (Number(upgradeData.mediaBonus) || 0) : 0;
          traitId = traitData?.traitId || null;
        } else {
          cardBase = cardsMap.get(key);
        }
        
        if (cardBase) {
          const finalCard = {
            ...cardBase,
            instanceId: isUnique ? key : null,
            media: (Number(cardBase.media) || 75) + bonus,
            traitId
          };
          for (let i = 0; i < count; i++) {
            selectedCardsList.push(finalCard);
          }
        }
      }
      
      const totalSelectedCount = selectedCardsList.length;
      
      // 1. REQUISITO: Límite de cartas (Cantidad exacta)
      let limitsMet = false;
      let limitText = '';
      if (limits.minCartas === limits.maxCartas) {
        limitsMet = totalSelectedCount === limits.minCartas;
        limitText = `Seleccionar exactamente ${limits.minCartas} cartas (${totalSelectedCount}/${limits.minCartas})`;
      } else {
        limitsMet = totalSelectedCount >= limits.minCartas && totalSelectedCount <= limits.maxCartas;
        limitText = `Seleccionar entre ${limits.minCartas} y ${limits.maxCartas} cartas (${totalSelectedCount} seleccionadas)`;
      }
      addChecklistItem(limitText, limitsMet);
      if (!limitsMet) allMet = false;
      
      // Si no se han seleccionado cartas, el resto de requisitos avanzados se muestran como pendientes
      const hasCards = totalSelectedCount > 0;
      
      // 2. REQUISITO: Media Mínima
      if (req.mediaMinima !== null && req.mediaMinima !== undefined) {
        const mediaMinMet = hasCards && selectedCardsList.every(c => c.media >= req.mediaMinima);
        addChecklistItem(`Media mínima por carta de ${req.mediaMinima}`, mediaMinMet);
        if (!mediaMinMet) allMet = false;
      }
      
      // 3. REQUISITO: Media Máxima
      if (req.mediaMaxima !== null && req.mediaMaxima !== undefined) {
        const mediaMaxMet = hasCards && selectedCardsList.every(c => c.media <= req.mediaMaxima);
        addChecklistItem(`Media máxima por carta de ${req.mediaMaxima}`, mediaMaxMet);
        if (!mediaMaxMet) allMet = false;
      }
      
      // 4. REQUISITO: Calidades permitidas
      if (req.calidades && req.calidades.length > 0) {
        const calidadesMet = hasCards && selectedCardsList.every(c => req.calidades.includes(c.calidad));
        addChecklistItem(`Calidad permitida: ${req.calidades.join(', ')}`, calidadesMet);
        if (!calidadesMet) allMet = false;
      }
      
      // 5. REQUISITOS: Estadísticas mínimas/máximas
      const getStatValue = (c, statName) => {
        const statNames = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
        const idx = statNames.indexOf(statName.toLowerCase());
        if (idx === -1) return 0;
        
        if (c.stats && Array.isArray(c.stats)) {
          return Number(c.stats[idx]) || 0;
        }
        if (c.parametros && Array.isArray(c.parametros)) {
          return Number(c.parametros[idx]) || 0;
        }
        const prop = `stat${idx + 1}`;
        return Number(c[prop]) || Number(c[statName]) || 0;
      };
      
      const statsReqs = [
        { key: 'ninjutsuMin', label: 'Ninjutsu mínimo', check: (c, val) => getStatValue(c, 'ninjutsu') >= val },
        { key: 'ninjutsuMax', label: 'Ninjutsu máximo', check: (c, val) => getStatValue(c, 'ninjutsu') <= val },
        { key: 'taijutsuMin', label: 'Taijutsu mínimo', check: (c, val) => getStatValue(c, 'taijutsu') >= val },
        { key: 'taijutsuMax', label: 'Taijutsu máximo', check: (c, val) => getStatValue(c, 'taijutsu') <= val },
        { key: 'velocidadMin', label: 'Velocidad mínima', check: (c, val) => getStatValue(c, 'velocidad') >= val },
        { key: 'velocidadMax', label: 'Velocidad máxima', check: (c, val) => getStatValue(c, 'velocidad') <= val },
        { key: 'defensaMin', label: 'Defensa mínima', check: (c, val) => getStatValue(c, 'defensa') >= val },
        { key: 'defensaMax', label: 'Defensa máxima', check: (c, val) => getStatValue(c, 'defensa') <= val },
        { key: 'resistenciaMin', label: 'Resistencia mínima', check: (c, val) => getStatValue(c, 'resistencia') >= val },
        { key: 'resistenciaMax', label: 'Resistencia máxima', check: (c, val) => getStatValue(c, 'resistencia') <= val },
        { key: 'fisicoMin', label: 'Físico mínimo', check: (c, val) => getStatValue(c, 'fisico') >= val },
        { key: 'fisicoMax', label: 'Físico máximo', check: (c, val) => getStatValue(c, 'fisico') <= val }
      ];
      
      statsReqs.forEach(st => {
        const val = req.stats[st.key];
        if (val !== null && val !== undefined) {
          const statMet = hasCards && selectedCardsList.every(c => st.check(c, val));
          addChecklistItem(`${st.label}: ${val}`, statMet);
          if (!statMet) allMet = false;
        }
      });
      
      // 6. REQUISITO: Procedencias (Mínimo de cartas por procedencia)
      if (req.procedencias && req.procedencias.minimo && Object.keys(req.procedencias.minimo).length > 0) {
        Object.entries(req.procedencias.minimo).forEach(([procName, minNeeded]) => {
          const matchingCount = selectedCardsList.filter(c => {
            const cardProc = String(c.procedencia || c.source || c.origen || 'Desconocida').trim().toLowerCase();
            return cardProc === procName.trim().toLowerCase();
          }).length;
          
          const procMet = matchingCount >= minNeeded;
          addChecklistItem(`Al menos ${minNeeded} cartas de procedencia "${procName}" (${matchingCount}/${minNeeded})`, procMet);
          if (!procMet) allMet = false;
        });
      }
      
      // 7. REQUISITO: Owners (Mínimo de cartas por owner original)
      if (req.owners && req.owners.minimo && Object.keys(req.owners.minimo).length > 0) {
        Object.entries(req.owners.minimo).forEach(([ownerName, minNeeded]) => {
          const matchingCount = selectedCardsList.filter(c => {
            const cardOwner = String(c.owner || 'Desconocido').trim().toLowerCase();
            return cardOwner === ownerName.trim().toLowerCase();
          }).length;
          
          const ownerMet = matchingCount >= minNeeded;
          addChecklistItem(`Al menos ${minNeeded} cartas del owner original "${ownerName}" (${matchingCount}/${minNeeded})`, ownerMet);
          if (!ownerMet) allMet = false;
        });
      }
      
      // 8. REQUISITO: Cartas específicas requeridas
      if (req.cartasEspecificas && req.cartasEspecificas.length > 0) {
        req.cartasEspecificas.forEach(cardId => {
          const cardDef = cardsMap.get(cardId);
          const nameToShow = cardDef ? cardDef.name : `Carta ID: ${cardId}`;
          const isIncluded = selectedCardsList.some(c => c.id === cardId);
          addChecklistItem(`Entregar la carta "${nameToShow}"`, isIncluded);
          if (!isIncluded) allMet = false;
        });
      }
      
      // Habilitar/Deshabilitar botón de confirmación en base a todos los checklist
      const confirmBtn = document.getElementById('events-confirm-btn');
      const errorMsg = document.getElementById('events-error-msg');
      
      if (confirmBtn) {
        confirmBtn.disabled = !allMet;
      }
      
      if (errorMsg) {
        errorMsg.style.display = allMet ? 'none' : 'block';
      }
    });
  });
}

// Función auxiliar para renderizar los elementos del checklist
function addChecklistItem(text, isMet) {
  const container = document.getElementById('events-requirements-list');
  if (!container) return;
  
  const item = document.createElement('div');
  item.className = `checklist-item ${isMet ? 'met' : 'pending'}`;
  
  const icon = document.createElement('span');
  icon.className = 'status-icon';
  icon.textContent = isMet ? '🟢' : '🔴';
  
  const label = document.createElement('span');
  label.className = 'status-text';
  label.textContent = text;
  
  item.appendChild(icon);
  item.appendChild(label);
  container.appendChild(item);
}

// Confirmar y procesar la entrega de cartas
async function confirmDelivery() {
  if (!activeDeliverable) return;
  
  const confirmBtn = document.getElementById('events-confirm-btn');
  if (confirmBtn) confirmBtn.disabled = true; // Prevenir doble click
  
  try {
    // 1. Estructurar el listado de cartas a deducir
    const cardsToDeduct = [];
    for (const [key, count] of Object.entries(selectedCardsMap)) {
      if (count <= 0) continue;
      
      if (key.startsWith('trait_')) {
        // Es una instancia única
        cardsToDeduct.push({ instanceId: key });
      } else {
        // Son copias de cartas estándar
        for (let i = 0; i < count; i++) {
          cardsToDeduct.push({ cardId: key });
        }
      }
    }
    
    console.log('[EVENTS] Enviando transacción de entrega:', {
      deliverableId: activeDeliverable.id,
      cardsToDeduct
    });
    
    // 2. Invocar el proceso principal de Electron
    const result = await window.kvrcards.completeDeliverable({
      deliverableId: activeDeliverable.id,
      cardsToDeduct,
      rewards: activeDeliverable.recompensas
    });
    
    if (result.ok) {
      // Guardar una copia de las recompensas antes de cerrar el modal (que limpia activeDeliverable)
      const rewards = activeDeliverable ? activeDeliverable.recompensas : null;

      // 3. Cerrar el modal y refrescar la billetera/colección
      closeEventsModal();
      
      if (typeof renderWallet === 'function') await renderWallet();
      if (typeof renderCollection === 'function') await renderCollection();
      
      // 4. Recargar el estado de eventos completados y re-renderizar
      if (result.deliverableCompletions && typeof result.deliverableCompletions === 'object') {
        deliverableCompletionsMap = { ...result.deliverableCompletions };
        completedEventsList = result.completedDeliverables || Object.keys(deliverableCompletionsMap);
      } else if (Array.isArray(result.completedDeliverables)) {
        completedEventsList = result.completedDeliverables;
        deliverableCompletionsMap = {};
        completedEventsList.forEach(id => {
          deliverableCompletionsMap[id] = (deliverableCompletionsMap[id] || 0) + 1;
        });
      }
      renderEventsList();
      
      // Mapear recompensas para el HUD unificado
      const formattedRewards = [];
      if (rewards) {
        if (rewards.coins) {
          formattedRewards.push({ type: 'coins', amount: rewards.coins });
        }
        if (rewards.kvr) {
          formattedRewards.push({ type: 'kvr', amount: rewards.kvr });
        }
        if (rewards.packs && rewards.packs.length > 0) {
          rewards.packs.forEach(p => {
            formattedRewards.push({ type: 'pack', packId: p.id, amount: p.cantidad });
          });
        }
      }
      
      if (typeof window.showUnifiedRewardsHUD === 'function') {
        await window.showUnifiedRewardsHUD(formattedRewards, '¡ENTREGA COMPLETADA!');
      } else {
        alert('🎉 ¡Entrega completada con éxito! Las recompensas han sido acreditadas en tu inventario.');
      }
    } else {
      alert('❌ Error al completar la entrega: ' + (result.error || 'Intente nuevamente'));
      if (confirmBtn) confirmBtn.disabled = false;
    }
  } catch (err) {
    console.error('[EVENTS] Error en la confirmación de la entrega:', err);
    alert('❌ Ocurrió un error inesperado al procesar la entrega');
    if (confirmBtn) confirmBtn.disabled = false;
  }
}

// Listeners al cargar el DOM para el modal de Eventos
document.addEventListener('DOMContentLoaded', () => {
  const closeBtn = document.getElementById('close-events-modal');
  if (closeBtn) {
    closeBtn.addEventListener('click', closeEventsModal);
  }
  
  const confirmBtn = document.getElementById('events-confirm-btn');
  if (confirmBtn) {
    confirmBtn.addEventListener('click', confirmDelivery);
  }
  
  const refreshBtn = document.getElementById('refresh-events');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', async () => {
      localStorage.removeItem(DELIVERABLES_CACHE_KEY);
      localStorage.removeItem(DELIVERABLES_CACHE_TIME_KEY);
      await initEvents();
      alert('✅ Eventos actualizados desde GitHub');
    });
  }
  
  // Agregar también listener de clicks fuera de la modal para cerrar
  const modal = document.getElementById('events-delivery-modal');
  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeEventsModal();
      }
    });
  }
});
