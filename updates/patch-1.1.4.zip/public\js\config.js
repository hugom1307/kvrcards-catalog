console.log('🔥🔥🔥 APP.JS CARGADO - VERSION 2026-01-12 07:00 🔥🔥🔥');
console.log('🔥 INICIO ABSOLUTO DEL ARCHIVO');
const isElectron = !!window.kvrcards;
const catalogInfoEl = document.getElementById('catalog-info');

// ==================== CONFIGURACIÓN DE BUFFEOS (DEBE ESTAR AL INICIO) ====================
const BUFF_CONFIG = {
  'Amegakure': { stats: ['ninjutsu'], statsLevel3: ['velocidad', 'taijutsu'], icon: '⚡' },
  'Atsuigakure': { stats: ['ninjutsu'], statsLevel3: ['velocidad', 'defensa'], icon: '🔥' },
  'Kizoku': { stats: ['defensa'], statsLevel3: ['resistencia', 'velocidad'], icon: '⚡' },
  'Jinushi': { stats: ['ninjutsu'], statsLevel3: ['defensa', 'taijutsu'], icon: '⚡' },
  'Konohagakure': { stats: ['taijutsu'], statsLevel3: ['velocidad', 'fisico'], icon: '👊' },
  'Hispania': { stats: ['taijutsu'], statsLevel3: ['resistencia', 'defensa'], icon: '👊' },
  'Kachi': { stats: ['taijutsu'], statsLevel3: ['ninjutsu', 'fisico'], icon: '👊' },
  'Sunagakure': { stats: ['resistencia'], statsLevel3: ['defensa', 'fisico'], icon: '🛡️' },
  'Hispalis': { stats: ['resistencia'], statsLevel3: ['taijutsu', 'velocidad'], icon: '🛡️' },
  'Iri': { stats: ['resistencia'], statsLevel3: ['ninjutsu', 'defensa'], icon: '🛡️' },
  'Iwagakure': { stats: ['defensa'], statsLevel3: ['resistencia', 'fisico'], icon: '🏔️' },
  'Yukon': { stats: ['defensa'], statsLevel3: ['taijutsu', 'ninjutsu'], icon: '🏔️' },
  'Fujika': { stats: ['defensa'], statsLevel3: ['velocidad', 'resistencia'], icon: '🏔️' },
  'Kumogakure': { stats: ['velocidad'], statsLevel3: ['ninjutsu', 'taijutsu'], icon: '⚡' },
  'Fusiogakure': { stats: ['velocidad'], statsLevel3: ['fisico', 'defensa'], icon: '⚡' },
  'Sekai no Hitobito': { stats: ['velocidad'], statsLevel3: ['resistencia', 'ninjutsu'], icon: '⚡' },
  'Kazegakure': { stats: ['ninjutsu', 'taijutsu'], statsLevel3: ['velocidad', 'fisico'], icon: '🌪️' },
  'Gokei': { stats: ['all'], statsLevel3: [], icon: '✨' },
  'Mundo subterráneo': { stats: ['resistencia', 'ninjutsu'], statsLevel3: ['velocidad', 'fisico'], icon: '🌑' },
  'Mundo Subterráneo': { stats: ['resistencia', 'ninjutsu'], statsLevel3: ['velocidad', 'fisico'], icon: '🌑' }
};

const OWNER_BUFF_CONFIG = {
  // Owners normales: 3+ cartas = 2 stats (5%), 5+ cartas = 4 stats (5%)
  'Manuel16': { 
    stats: ['ninjutsu', 'velocidad'],
    statsLevel2: ['ninjutsu', 'velocidad', 'taijutsu', 'defensa'],
    icon: '👤',
    minLevel1: 3,
    minLevel2: 5,
    percentageLevel1: 5,
    percentageLevel2: 5
  },
  'Juanjovc_20': { 
    stats: ['taijutsu', 'resistencia'],
    statsLevel2: ['taijutsu', 'resistencia', 'fisico', 'velocidad'],
    icon: '👤',
    minLevel1: 3,
    minLevel2: 5,
    percentageLevel1: 5,
    percentageLevel2: 5
  },
  'Nataliaa15': { 
    stats: ['defensa', 'ninjutsu'],
    statsLevel2: ['defensa', 'ninjutsu', 'resistencia', 'velocidad'],
    icon: '👤',
    minLevel1: 3,
    minLevel2: 5,
    percentageLevel1: 5,
    percentageLevel2: 5
  },
  'Alecrackman': { 
    stats: ['velocidad', 'fisico'],
    statsLevel2: ['velocidad', 'fisico', 'taijutsu', 'ninjutsu'],
    icon: '👤',
    minLevel1: 3,
    minLevel2: 5,
    percentageLevel1: 5,
    percentageLevel2: 5
  },
  'Grejino02': { 
    stats: ['fisico', 'defensa'],
    statsLevel2: ['fisico', 'defensa', 'resistencia', 'taijutsu'],
    icon: '👤',
    minLevel1: 3,
    minLevel2: 5,
    percentageLevel1: 5,
    percentageLevel2: 5
  },
  'MrVetoxx': { 
    stats: ['resistencia', 'taijutsu'],
    statsLevel2: ['resistencia', 'taijutsu', 'fisico', 'defensa'],
    icon: '👤',
    minLevel1: 3,
    minLevel2: 5,
    percentageLevel1: 5,
    percentageLevel2: 5
  },
  'Adrianpepo': { 
    stats: ['ninjutsu', 'fisico'],
    statsLevel2: ['ninjutsu', 'fisico', 'velocidad', 'resistencia'],
    icon: '👤',
    minLevel1: 3,
    minLevel2: 5,
    percentageLevel1: 5,
    percentageLevel2: 5
  },
  'Wailant': { 
    stats: ['taijutsu', 'defensa'],
    statsLevel2: ['taijutsu', 'defensa', 'ninjutsu', 'fisico'],
    icon: '👤',
    minLevel1: 3,
    minLevel2: 5,
    percentageLevel1: 5,
    percentageLevel2: 5
  },
  'Manuel2767': { 
    stats: ['taijutsu', 'defensa'],
    statsLevel2: ['taijutsu', 'defensa', 'ninjutsu', 'fisico'],
    icon: '👤',
    minLevel1: 3,
    minLevel2: 5,
    percentageLevel1: 5,
    percentageLevel2: 5
  },
  'Preput777': { 
    stats: ['ninjutsu', 'defensa'],
    statsLevel2: ['ninjutsu', 'defensa', 'velocidad', 'resistencia'],
    icon: '👤',
    minLevel1: 3,
    minLevel2: 5,
    percentageLevel1: 5,
    percentageLevel2: 5
  },
  // Owners premium: 5+ cartas = 3 stats (3%), 7 cartas = todas las stats (3%)
  'HugoMan1307': { 
    stats: ['ninjutsu', 'taijutsu', 'velocidad'],
    statsLevel2: ['ninjutsu', 'taijutsu', 'velocidad', 'resistencia', 'defensa', 'fisico'],
    icon: '👑',
    minLevel1: 5,
    minLevel2: 7,
    percentageLevel1: 3,
    percentageLevel2: 3
  },
  'TaiyoDL': { 
    stats: ['resistencia', 'defensa', 'fisico'],
    statsLevel2: ['ninjutsu', 'taijutsu', 'velocidad', 'resistencia', 'defensa', 'fisico'],
    icon: '👑',
    minLevel1: 5,
    minLevel2: 7,
    percentageLevel1: 3,
    percentageLevel2: 3
  }
};

const STAT_NAMES_MAP = {
  'ninjutsu': 'Ninjutsu',
  'taijutsu': 'Taijutsu',
  'resistencia': 'Resistencia',
  'velocidad': 'Velocidad',
  'defensa': 'Defensa',
  'fisico': 'Físico'
};
console.log('[BUFF CONFIG] Configuración de buffeos cargada al inicio');
