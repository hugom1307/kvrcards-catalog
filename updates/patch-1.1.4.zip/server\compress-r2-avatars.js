const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });
const { S3Client, GetObjectCommand, PutObjectCommand, ListObjectsV2Command } = require('@aws-sdk/client-s3');
const { Jimp } = require('jimp');

const R2_ACCOUNT_ID = process.env.R2_ACCOUNT_ID || '';
const R2_ACCESS_KEY_ID = process.env.R2_ACCESS_KEY_ID || '';
const R2_SECRET_ACCESS_KEY = process.env.R2_SECRET_ACCESS_KEY || '';
const R2_BUCKET_NAME = process.env.R2_BUCKET_NAME || 'kvrcards-server';

if (!R2_ACCOUNT_ID || !R2_ACCESS_KEY_ID || !R2_SECRET_ACCESS_KEY) {
  console.error('R2 credentials not found in .env');
  process.exit(1);
}

const s3Client = new S3Client({
  region: 'auto',
  endpoint: `https://${R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: {
    accessKeyId: R2_ACCESS_KEY_ID,
    secretAccessKey: R2_SECRET_ACCESS_KEY,
  },
});

async function main() {
  console.log('Listing users from R2 bucket:', R2_BUCKET_NAME);
  const listCmd = new ListObjectsV2Command({
    Bucket: R2_BUCKET_NAME,
    Prefix: 'users/',
  });
  const listRes = await s3Client.send(listCmd);
  const items = listRes.Contents || [];
  console.log('Found', items.length, 'user files in R2.\n');

  let totalBytesSaved = 0;

  for (const item of items) {
    const key = item.Key;
    const getCmd = new GetObjectCommand({ Bucket: R2_BUCKET_NAME, Key: key });
    const getRes = await s3Client.send(getCmd);
    const rawStr = await getRes.Body.transformToString();
    const originalLen = Buffer.byteLength(rawStr);
    let user;
    try {
      user = JSON.parse(rawStr);
    } catch {
      continue;
    }

    const img = user.profileImage || '';
    if (typeof img === 'string' && img.startsWith('data:image') && img.length > 30000) {
      console.log(`Processing ${user.username || key}: original avatar length = ${img.length} chars...`);
      try {
        const base64Data = img.replace(/^data:image\/\w+;base64,/, '');
        const inputBuf = Buffer.from(base64Data, 'base64');
        const jimpImg = await Jimp.read(inputBuf);
        
        // Mantener relación de aspecto hasta un máximo de 128x128
        let w = jimpImg.width;
        let h = jimpImg.height;
        const max = 128;
        if (w > h) {
          if (w > max) {
            h = Math.round((h * max) / w);
            w = max;
          }
        } else {
          if (h > max) {
            w = Math.round((w * max) / h);
            h = max;
          }
        }
        jimpImg.resize({ w, h });
        const outBuf = await jimpImg.getBuffer('image/jpeg');
        const newImg = `data:image/jpeg;base64,${outBuf.toString('base64')}`;

        user.profileImage = newImg;
        const newRawStr = JSON.stringify(user, null, 2);
        const newLen = Buffer.byteLength(newRawStr);
        const saved = originalLen - newLen;
        totalBytesSaved += saved;

        const putCmd = new PutObjectCommand({
          Bucket: R2_BUCKET_NAME,
          Key: key,
          Body: newRawStr,
          ContentType: 'application/json',
        });
        await s3Client.send(putCmd);
        console.log(`  -> Saved: ${originalLen} bytes -> ${newLen} bytes (saved ${Math.round(saved / 1024)} KB, avatar now ${newImg.length} chars)`);
      } catch (err) {
        console.error(`  -> Error processing image for ${key}:`, err.message);
      }
    } else {
      console.log(`Skipping ${user.username || key}: avatar size is OK (${img ? img.length : 0} chars)`);
    }
  }

  console.log(`\nCOMPLETED! Total bandwidth savings in R2: ${Math.round(totalBytesSaved / 1024)} KB (${(totalBytesSaved / (1024 * 1024)).toFixed(2)} MB)`);
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
