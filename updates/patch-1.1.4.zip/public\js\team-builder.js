// ==================== MENÚ PRINCIPAL ====================
function showMainMenu() {
  console.log('[MENU] Mostrando menú principal');
  
  // Ocultar todas las secciones
  sections.collection.style.display = 'none';
  sections.packs.style.display = 'none';
  sections.shop.style.display = 'none';
  sections.missions.style.display = 'none';
  
  // Ocultar modales si están abiertos
  const tradesModal = document.getElementById('trades-modal');
  const friendsModal = document.getElementById('friends-modal');
  const rankingsModal = document.getElementById('rankings-modal');
  const settingsModal = document.getElementById('settings-modal');
  if (tradesModal) tradesModal.classList.remove('active');
  if (friendsModal) friendsModal.classList.remove('active');
  if (rankingsModal) rankingsModal.classList.remove('active');
  if (settingsModal) settingsModal.classList.remove('active');
  
  // Ocultar nav tradicional
  const navMenu = document.querySelector('nav.menu');
  if (navMenu) navMenu.style.display = 'none';
  
  // Mostrar menú principal
  const mainMenu = document.getElementById('main-menu');
  if (mainMenu) {
    mainMenu.style.display = 'flex';
    console.log('[MENU] Menú principal mostrado');
  } else {
    console.error('[MENU] ❌ No se encontró el elemento #main-menu');
  }
  
  // Ocultar botón volver
  const backBtn = document.querySelector('.back-btn');
  if (backBtn) backBtn.style.display = 'none';
}

function hideMainMenu() {
  const mainMenu = document.getElementById('main-menu');
  if (mainMenu) {
    mainMenu.style.display = 'none';
  }
  
  // Mostrar nav tradicional
  const navMenu = document.querySelector('nav.menu');
  if (navMenu) navMenu.style.display = 'flex';
  
  // Mostrar botón volver
  const backBtn = document.querySelector('.back-btn');
  if (backBtn) backBtn.style.display = 'inline-flex';
}

// Función para inicializar los event listeners del menú
function initializeMainMenuListeners() {
  console.log('[MENU] Inicializando event listeners del menú...');
  
  // Botón principal JUGAR - MANEJADO EN index.html inline script
  // El listener está en el script inline de index.html para mejor control
  const playBtn = document.querySelector('.menu-card-primary');
  if (playBtn) {
    console.log('[MENU] ✓ Botón JUGAR encontrado (manejado por script inline)');
  } else {
    console.error('[MENU] ❌ No se encontró .menu-card-primary');
  }
  
  // Botones del grid con data-view
  const viewButtons = document.querySelectorAll('.menu-card[data-view]');
  console.log(`[MENU] Encontrados ${viewButtons.length} botones con data-view`);
  
  viewButtons.forEach(btn => {
    const view = btn.getAttribute('data-view');
    console.log(`[MENU] Configurando botón para vista: ${view}`);
    
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      console.log(`[MENU] 🔥 CLICK DETECTADO en botón: ${view}`);
      hideMainMenu();
      show(view);
    });
  });
  
  // Botones especiales (trades, friends, rankings, settings)
  const tradesMenuBtn = document.getElementById('trades-menu-btn');
  console.log('[MENU] Buscando trades-menu-btn:', tradesMenuBtn);
  if (tradesMenuBtn) {
    tradesMenuBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      console.log('[MENU] 🔥 CLICK EN TRADES DETECTADO');
      hideMainMenu();
      // Abrir modal directamente
      const tradesModal = document.getElementById('trades-modal');
      if (tradesModal) {
        tradesModal.classList.add('active');
        if (typeof showTradeSelectionView === 'function') {
          showTradeSelectionView();
        }
      }
    });
    console.log('[MENU] ✓ Listener para Trades configurado');
  }
  
  const friendsMenuBtn = document.getElementById('friends-menu-btn');
  console.log('[MENU] Buscando friends-menu-btn:', friendsMenuBtn);
  if (friendsMenuBtn) {
    friendsMenuBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      console.log('[MENU] 🔥 CLICK EN AMIGOS DETECTADO');
      hideMainMenu();
      // Abrir modal directamente
      const friendsModal = document.getElementById('friends-modal');
      if (friendsModal) {
        friendsModal.classList.add('active');
        if (typeof loadFriendsList === 'function') {
          loadFriendsList();
        }
      }
    });
    console.log('[MENU] ✓ Listener para Amigos configurado');
  }
  
  const rankingsMenuBtn = document.getElementById('rankings-menu-btn');
  console.log('[MENU] Buscando rankings-menu-btn:', rankingsMenuBtn);
  if (rankingsMenuBtn) {
    rankingsMenuBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      console.log('[MENU] 🔥 CLICK EN RANKINGS DETECTADO');
      hideMainMenu();
      // Abrir modal directamente
      const rankingsModal = document.getElementById('rankings-modal');
      if (rankingsModal) {
        rankingsModal.classList.add('active');
        if (typeof loadRankings === 'function') {
          loadRankings();
        }
      }
    });
    console.log('[MENU] ✓ Listener para Rankings configurado');
  }
  
  const settingsMenuBtn = document.getElementById('settings-menu-btn');
  console.log('[MENU] Buscando settings-menu-btn:', settingsMenuBtn);
  if (settingsMenuBtn) {
    settingsMenuBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      console.log('[MENU] 🔥 CLICK EN AJUSTES DETECTADO');
      hideMainMenu();
      // Abrir modal directamente
      const settingsModal = document.getElementById('settings-modal');
      if (settingsModal) {
        settingsModal.classList.add('active');
        if (typeof syncDisplaySettingsUI === 'function') syncDisplaySettingsUI();
      }
    });
    console.log('[MENU] ✓ Listener para Ajustes configurado');
  }
  
  // Botón "volver" para regresar al menú principal
  const backBtn = document.querySelector('.back-btn');
  if (backBtn) {
    backBtn.addEventListener('click', (e) => {
      e.preventDefault();
      console.log('[MENU] Click en volver al menú');
      showMainMenu();
    });
    console.log('[MENU] ✓ Listener para botón volver configurado');
  }
  
  console.log('[MENU] ✅ Event listeners del menú inicializados correctamente');
}

// Inicializar menú principal - Ejecutar inmediatamente sin esperar DOMContentLoaded
console.log('[MENU] Estado del DOM:', document.readyState);
console.log('[MENU] Iniciando inicialización del menú...');

// Función para inicializar todo el menú
function initMenu() {
  console.log('[MENU] Ejecutando initMenu()...');
  const mainMenuElement = document.getElementById('main-menu');
  console.log('[MENU] Elemento main-menu encontrado:', !!mainMenuElement);
  
  if (mainMenuElement) {
    initializeMainMenuListeners();
  } else {
    console.error('[MENU] ❌ No se encontró el elemento #main-menu, reintentando...');
    setTimeout(initMenu, 100);
  }
}

// Ejecutar cuando el script se cargue
// DESACTIVADO: Los botones del menú se manejan en script inline del HTML
/*
if (document.readyState === 'loading') {
  console.log('[MENU] DOM aún cargando, esperando DOMContentLoaded...');
  document.addEventListener('DOMContentLoaded', initMenu);
} else {
  console.log('[MENU] DOM ya listo, ejecutando inmediatamente...');
  initMenu();
}
*/
console.log('[MENU] Listeners del menú manejados por script inline en index.html');

// ========================================
// TEAM BUILDER - Sistema de creación de equipo
// ========================================

// Variables globales del team builder - 5 equipos diferentes
if (!window.allTeams) {
  window.allTeams = [
    [null, null, null, null, null, null, null, null], // Equipo 1
    [null, null, null, null, null, null, null, null], // Equipo 2
    [null, null, null, null, null, null, null, null], // Equipo 3
    [null, null, null, null, null, null, null, null], // Equipo 4
    [null, null, null, null, null, null, null, null]  // Equipo 5
  ];
}
if (!window.teamNames) {
  window.teamNames = ['Equipo 1', 'Equipo 2', 'Equipo 3', 'Equipo 4', 'Equipo 5'];
}
if (typeof window.currentTeamIndex === 'undefined') {
  window.currentTeamIndex = 0; // Equipo activo (0-4)
}
if (!window.selectedTeam) {
  window.selectedTeam = window.allTeams[0]; // Referencia al equipo actual
}
if (!window.teamBuilderCards) {
  window.teamBuilderCards = [];
}

// Variables globales de poderes de equipos
if (!window.allTeamPowers) {
  window.allTeamPowers = [
    [null, null, null], // Poderes Equipo 1
    [null, null, null], // Poderes Equipo 2
    [null, null, null], // Poderes Equipo 3
    [null, null, null], // Poderes Equipo 4
    [null, null, null]  // Poderes Equipo 5
  ];
}
if (!window.selectedTeamPowers) {
  window.selectedTeamPowers = window.allTeamPowers[0]; // Referencia a poderes del equipo actual
}

// Cargar inventario de cartas para el team builder
async function loadTeamBuilderInventory() {
  console.log('[TEAM BUILDER] Cargando inventario...');
  
  // Inicializar variables si no existen
  if (!window.allTeams) {
    window.allTeams = [
      [null, null, null, null, null, null, null, null],
      [null, null, null, null, null, null, null, null],
      [null, null, null, null, null, null, null, null],
      [null, null, null, null, null, null, null, null],
      [null, null, null, null, null, null, null, null]
    ];
  }
  if (!window.teamNames) {
    window.teamNames = ['Equipo 1', 'Equipo 2', 'Equipo 3', 'Equipo 4', 'Equipo 5'];
  }
  if (typeof window.currentTeamIndex === 'undefined') {
    window.currentTeamIndex = 0;
  }
  window.selectedTeam = window.allTeams[window.currentTeamIndex];
  
  if (!window.teamBuilderCards) {
    window.teamBuilderCards = [];
    console.log('[TEAM BUILDER] teamBuilderCards inicializado');
  }
  
  console.log('[TEAM BUILDER] window.selectedTeam:', window.selectedTeam);
  console.log('[TEAM BUILDER] window.teamBuilderCards:', window.teamBuilderCards);
  
  if (!isElectron) {
    console.error('[TEAM BUILDER] Solo disponible en Electron');
    return;
  }
  
  try {
    // Obtener cartas del inventario
    const inv = await window.kvrcards.getInventory();
    console.log('[TEAM BUILDER] Inventario recibido:', inv);
    
    if (!inv.ok) {
      console.error('[TEAM BUILDER] Error obteniendo inventario:', inv.error);
      return;
    }
    
    if (inv.cards) {
      window.__lastKnownInventoryCards = inv.cards;
    }
    
    // Cargar cardTraitsMap desde inventario para que los iconos aparezcan
    if (inv.cardTraits) {
      cardTraitsMap = inv.cardTraits;
      console.log('[TEAM BUILDER] cardTraitsMap cargado:', Object.keys(cardTraitsMap).length);
    }
    
    // Cargar availableTraits si no están cargados
    if (!availableTraits || availableTraits.length === 0) {
      try {
        if (window.kvrcards && window.kvrcards.getAllTraits) {
          availableTraits = await window.kvrcards.getAllTraits();
          console.log('[TEAM BUILDER] availableTraits cargados:', availableTraits.length);
        }
      } catch (e) {
        console.error('[TEAM BUILDER] Error cargando traits:', e);
      }
    }
    
    // Obtener todas las cartas del catálogo
    const allCards = await window.kvrcards.getAllCards();
    console.log('[TEAM BUILDER] Catálogo recibido:', allCards);
    
    // getAllCards devuelve directamente un array de cartas, no un objeto {ok, cards}
    let cardsList = [];
    if (Array.isArray(allCards)) {
      cardsList = allCards;
    } else if (allCards.ok && Array.isArray(allCards.cards)) {
      cardsList = allCards.cards;
    } else {
      console.error('[TEAM BUILDER] Formato de catálogo inválido');
      return;
    }
    
    console.log('[TEAM BUILDER] Cards list obtenida:', cardsList.length, 'cartas');
    
    // Log de ejemplo de carta para ver estructura
    if (cardsList.length > 0) {
      console.log('[TEAM BUILDER] Ejemplo de carta:', cardsList[0]);
    }
    
    // Organizar traits por cardId
    const traitsByCard = {};
    for (const [instanceId, data] of Object.entries(cardTraitsMap)) {
      if (data && data.cardId && data.traitId) {
        if (!traitsByCard[data.cardId]) traitsByCard[data.cardId] = [];
        traitsByCard[data.cardId].push({ instanceId, traitId: data.traitId });
      } else if (typeof data === 'string') {
        let cardId = instanceId;
        if (instanceId.includes('_')) {
          const parts = instanceId.split('_');
          if (parts.length >= 3 && !isNaN(parts[parts.length - 1]) && !isNaN(parts[parts.length - 2])) {
            cardId = parts.slice(0, -2).join('_');
          }
        }
        if (!traitsByCard[cardId]) traitsByCard[cardId] = [];
        traitsByCard[cardId].push({ instanceId, traitId: data });
      }
    }
    
    // Generar lista de cartas: traits individuales + un grupo para las sin trait
    window.teamBuilderCards = [];
    for (const card of cardsList) {
      const totalCount = inv.cards[card.id] || 0;
      if (totalCount === 0) continue;
      
      const traitsForCard = (traitsByCard[card.id] || []).slice(0, totalCount);
      
      // Agregar instancias con traits (cada una como carta separada)
      for (const traitInfo of traitsForCard) {
        window.teamBuilderCards.push({
          ...card,
          uniqueId: traitInfo.instanceId,
          instanceId: traitInfo.instanceId,
          hasTrait: true
        });
      }
      
      // Agregar UNA entrada para todas las cartas sin trait (si hay alguna)
      const countWithoutTrait = Math.max(0, totalCount - traitsForCard.length);
      if (countWithoutTrait > 0) {
        window.teamBuilderCards.push({
          ...card,
          uniqueId: `${card.id}_notrait`,
          instanceId: null,
          hasTrait: false,
          availableCount: countWithoutTrait // Cuántas hay disponibles de este tipo
        });
      }
    }
    
    console.log('[TEAM BUILDER] Cartas filtradas (con traits separados):', window.teamBuilderCards.length);
    
    // Ordenar por media (de mayor a menor)
    window.teamBuilderCards.sort((a, b) => {
      const mediaA = parseInt(a.media) || 0;
      const mediaB = parseInt(b.media) || 0;
      return mediaB - mediaA;
    });
    
    console.log(`[TEAM BUILDER] ${window.teamBuilderCards.length} cartas cargadas y ordenadas por media`);
    
    // Configurar pestañas y nombre del equipo PRIMERO
    setupTeamTabsAndName();
    
    // Cargar poderes primero para tener availablePowers y ownedPowersInventory en memoria
    await loadPowers();

    // Cargar equipos guardados
    loadSavedTeam();
    
    // Ahora sí renderizar todo
    renderTeamBuilderInventory();
    renderPowerSlots();
    renderPowersInventory();
    setupTeamBuilderSearch();
    
    // Configurar el botón Continuar
    setupContinueButton();
    
    // Configurar el botón Restablecer
    setupResetButton();
    
    // Configurar el botón Guardar
    setupSaveButton();
    
    // Sincronizar UI de modo (ocultar botón guardar y pestañas si es modo infinito)
    updateTeamBuilderModeUI();
    
  } catch (error) {
    console.error('[TEAM BUILDER] Error:', error);
  }
}

// ==================== FUNCIONES DE PODERES ====================

// Cargar poderes desde el backend
async function loadPowers() {
  console.log('[POWERS] Cargando poderes...');
  
  if (!isElectron) {
    console.error('[POWERS] Solo disponible en Electron');
    return;
  }
  
  try {
    // Obtener todos los poderes disponibles del JSON
    const allPowers = await window.kvrcards.getAllPowers();
    console.log('[POWERS] Poderes disponibles:', allPowers);
    
    if (Array.isArray(allPowers)) {
      availablePowers = allPowers;
    } else {
      console.error('[POWERS] Formato de poderes inválido');
      return;
    }
    
    // Obtener inventario de poderes del usuario
    const inv = await window.kvrcards.getPowersInventory();
    console.log('[POWERS] Inventario de poderes:', inv);
    
    if (inv.ok) {
      ownedPowersInventory = inv.powers || {};
    } else {
      console.error('[POWERS] Error obteniendo inventario de poderes:', inv.error);
    }
    
    console.log(`[POWERS] ${availablePowers.length} poderes disponibles, ${Object.keys(ownedPowersInventory).length} en inventario`);
    
    // Renderizar inventario
    renderPowersInventory();
    renderPowerSlots();
    
  } catch (error) {
    console.error('[POWERS] Error:', error);
  }
}

// Renderizar inventario de poderes
function renderPowersInventory() {
  const container = document.getElementById('powers-inventory');
  if (!container) {
    console.log('[POWERS] Contenedor powers-inventory no encontrado');
    return;
  }
  
  console.log('[POWERS] Renderizando inventario...');
  console.log('[POWERS] availablePowers:', availablePowers);
  console.log('[POWERS] ownedPowersInventory:', ownedPowersInventory);
  
  container.innerHTML = '';
  
  // Filtrar solo poderes que el usuario posee
  const ownedPowers = availablePowers.filter(power => {
    return ownedPowersInventory[power.id];
  });
  
  console.log('[POWERS] ownedPowers filtrados:', ownedPowers);
  
  if (ownedPowers.length === 0) {
    container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; color: #64748b; padding: 20px; font-size: 14px;">No tienes poderes aún</div>';
    return;
  }
  
  ownedPowers.forEach(power => {
    const powerDiv = document.createElement('div');
    powerDiv.className = 'power-inventory-item';
    powerDiv.dataset.powerId = power.id;
    
    const inventoryData = ownedPowersInventory[power.id];
    const isPermanent = inventoryData.permanent === true;
    const uses = inventoryData.uses || 0;
    
    if (isPermanent) {
      powerDiv.classList.add('permanent');
    }
    if (!power.tradeable) {
      powerDiv.classList.add('non-tradeable');
    }
    
    // Comprobar si está asignado al equipo actual
    const isInTeam = window.selectedTeamPowers && window.selectedTeamPowers.includes(power.id);
    if (isInTeam) {
      powerDiv.classList.add('in-team');
    }
    
    const imageUrl = power.imageUrl || 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22%3E%3Ccircle cx=%2250%22 cy=%2250%22 r=%2245%22 fill=%22%23fbbf24%22/%3E%3Ctext x=%2250%25%22 y=%2255%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%23000%22 font-size=%2240%22%3E⚡%3C/text%3E%3C/svg%3E';
    
    powerDiv.innerHTML = `
      <img src="${imageUrl}" alt="${power.name}" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22100%22 height=%22100%22%3E%3Ccircle cx=%2250%22 cy=%2250%22 r=%2245%22 fill=%22%23fbbf24%22/%3E%3Ctext x=%2250%25%22 y=%2255%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%23000%22 font-size=%2240%22%3E⚡%3C/text%3E%3C/svg%3E'" />
      <div class="power-name">${power.name}</div>
      ${!isPermanent ? `<div class="power-uses-badge">${uses} usos</div>` : '<div class="power-permanent-badge">♾️</div>'}
    `;
    
    // Click para asignar al equipo
    powerDiv.addEventListener('click', () => {
      assignPowerToSlot(power.id);
    });
    
    container.appendChild(powerDiv);
  });
  
  console.log(`[POWERS] ${ownedPowers.length} poderes renderizados`);
}

// Asignar poder a un slot del equipo
function assignPowerToSlot(powerId) {
  if (!window.selectedTeamPowers) {
    console.error('[POWERS] selectedTeamPowers no inicializado');
    return;
  }
  
  // Verificar si el poder ya está asignado en algún slot
  if (window.selectedTeamPowers.includes(powerId)) {
    const powerName = availablePowers.find(p => p.id === powerId)?.name || powerId;
    alert(`⚠️ No puedes equipar el mismo poder dos veces\n\nEl poder "${powerName}" ya está equipado en tu equipo.`);
    return;
  }
  
  // Buscar el primer slot vacío o reemplazar el último
  let assigned = false;
  for (let i = 0; i < 3; i++) {
    if (!window.selectedTeamPowers[i]) {
      window.selectedTeamPowers[i] = powerId;
      assigned = true;
      console.log(`[POWERS] Poder ${powerId} asignado al slot ${i}`);
      break;
    }
  }
  
  // Si no hay slots vacíos, reemplazar el último
  if (!assigned) {
    window.selectedTeamPowers[2] = powerId;
    console.log(`[POWERS] Poder ${powerId} reemplazó el slot 2`);
  }
  
  // Actualizar vista
  renderPowerSlots();
  renderPowersInventory(); // Re-renderizar para actualizar el estado "in-team"
  
  // Guardar cambios
  saveCurrentTeam();
}

// Renderizar slots de poderes del equipo
function renderPowerSlots() {
  const slots = document.querySelectorAll('.power-slot');
  
  // Verificar que selectedTeamPowers existe
  if (!window.selectedTeamPowers) {
    window.selectedTeamPowers = [null, null, null];
  }
  
  slots.forEach((slot, index) => {
    const powerId = window.selectedTeamPowers[index];
    
    if (powerId) {
      const power = availablePowers.find(p => p.id === powerId);
      const inventoryData = ownedPowersInventory[powerId];
      
      if (power && inventoryData) {
        slot.classList.add('filled');
        
        const imageUrl = power.imageUrl || 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22110%22 height=%22110%22%3E%3Ccircle cx=%2255%22 cy=%2255%22 r=%2250%22 fill=%22%23fbbf24%22/%3E%3Ctext x=%2250%25%22 y=%2255%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%23000%22 font-size=%2250%22%3E⚡%3C/text%3E%3C/svg%3E';
        
        const isPermanent = inventoryData.permanent === true;
        const uses = inventoryData.uses || 0;
        
        slot.innerHTML = `
          <div class="power-slot-number">${index + 1}</div>
          <img src="${imageUrl}" alt="${power.name}" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22110%22 height=%22110%22%3E%3Ccircle cx=%2255%22 cy=%2255%22 r=%2250%22 fill=%22%23fbbf24%22/%3E%3Ctext x=%2250%25%22 y=%2255%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%23000%22 font-size=%2250%22%3E⚡%3C/text%3E%3C/svg%3E'" />
          ${!isPermanent ? `<div class="power-uses">${uses} usos</div>` : '<div class="power-permanent-icon">♾️</div>'}
        `;
      } else {
        slot.classList.remove('filled');
        slot.innerHTML = `
          <div class="power-slot-number">${index + 1}</div>
          <div class="power-slot-placeholder">⚡</div>
        `;
      }
    } else {
      slot.classList.remove('filled');
      slot.innerHTML = `
        <div class="power-slot-number">${index + 1}</div>
        <div class="power-slot-placeholder">⚡</div>
      `;
    }
    
    // Click para remover poder
    slot.onclick = () => {
      if (window.selectedTeamPowers[index]) {
        window.selectedTeamPowers[index] = null;
        console.log(`[POWERS] Poder removido del slot ${index}`);
        renderPowerSlots();
        renderPowersInventory();
        saveCurrentTeam();
      }
    };
  });
}

// ==================== FIN FUNCIONES DE PODERES ====================

// Renderizar inventario de cartas
function renderTeamBuilderInventory(filteredCards = null) {
  const container = document.getElementById('team-inventory');
  if (!container) {
    console.error('[TEAM BUILDER] Contenedor team-inventory no encontrado');
    return;
  }
  
  const cardsToRender = filteredCards || window.teamBuilderCards;
  
  console.log('[TEAM BUILDER] Renderizando', cardsToRender.length, 'cartas');
  console.log('[TEAM BUILDER] Equipo actual al renderizar:', window.selectedTeam);
  
  container.innerHTML = '';
  
  if (cardsToRender.length === 0) {
    container.innerHTML = '<div style="grid-column: 1/-1; text-align: center; color: #64748b; padding: 40px; font-size: 16px;">No se encontraron cartas en tu colección</div>';
    return;
  }
  
  console.log('[TEAM BUILDER] cardTraitsMap:', cardTraitsMap);
  console.log('[TEAM BUILDER] Total cards with traits:', Object.keys(cardTraitsMap).length);
  console.log('[TEAM BUILDER] Total cards to render:', cardsToRender.length);
  
  // Renderizar las cartas directamente (ya vienen como instancias individuales)
  cardsToRender.forEach((card, index) => {
    console.log(`[TEAM BUILDER] Rendering card ${index + 1}/${cardsToRender.length}:`, card.name || card.nombre, card.id, card.uniqueId);
    const cardDiv = document.createElement('div');
    cardDiv.className = 'team-inventory-card';
    cardDiv.dataset.cardId = card.id;
    cardDiv.dataset.uniqueId = card.uniqueId || card.id;
    
    // Verificar si esta carta específica está en el equipo
    const uniqueId = card.uniqueId || card.id;
    let isInTeam = false;
    
    if (window.selectedTeam) {
      if (card.hasTrait) {
        // Para cartas con trait, verificar por uniqueId exacto (instanceId)
        isInTeam = window.selectedTeam.includes(uniqueId);
      } else {
        // Para cartas sin trait, verificar si algún slot contiene el cardId base con _notrait
        const baseId = card.id;
        isInTeam = window.selectedTeam.some(teamCard => {
          if (!teamCard) return false;
          // Verificar si es la misma carta sin trait (puede tener timestamp/random añadido)
          // Formato: cardId_notrait o cardId_notrait_timestamp_random
          return teamCard === `${baseId}_notrait` || teamCard.startsWith(`${baseId}_notrait_`);
        });
      }
    }
    
    console.log(`[TEAM BUILDER] Carta ${card.name || card.nombre} (${uniqueId}), hasTrait: ${card.hasTrait}, en equipo: ${isInTeam}`);
    
    if (isInTeam) {
      cardDiv.classList.add('selected');
    }
    
    const imageUrl = card.imageUrl || card.imagen || '';
    const nombre = card.nombre || card.name || 'Jugador';
    const media = card.media || 0;
    
    // Verificar si la carta tiene trait
    let traitIconHTML = '';
    if (card.hasTrait && card.instanceId && cardTraitsMap[card.instanceId]) {
      const traitData = cardTraitsMap[card.instanceId];
      const traitId = traitData.traitId || traitData;
      const trait = availableTraits.find(t => t.id === traitId);
      if (trait) {
        traitIconHTML = `<div class="card-trait-icon"><img src="${trait.imageUrl}" alt="${trait.name}" title="${trait.name}" /></div>`;
      }
    }
    
    cardDiv.innerHTML = `
      <img src="${imageUrl}" alt="${nombre}" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%22200%22 height=%22300%22%3E%3Crect width=%22200%22 height=%22300%22 fill=%22%231e293b%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22 fill=%22%23fff%22 font-size=%2216%22%3E${nombre}%3C/text%3E%3C/svg%3E'" />
      ${traitIconHTML}
      <div class="team-inventory-card-name">${nombre}</div>
      <button class="team-inventory-card-btn ${isInTeam ? 'remove' : 'add'}">
        ${isInTeam ? '✓ En equipo' : '+ Añadir'}
      </button>
    `;
    
    // Click en la imagen para zoom
    const img = cardDiv.querySelector('img');
    img.addEventListener('click', (e) => {
      e.stopPropagation();
      openCardZoom(imageUrl);
    });
    img.style.cursor = 'pointer';
    
    // Click en el botón
    const btn = cardDiv.querySelector('.team-inventory-card-btn');
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      if (isInTeam) {
        // Eliminar del equipo
        const uniqueId = card.uniqueId || card.id;
        let slotIndex = -1;
        
        if (card.hasTrait) {
          // Para cartas con trait, buscar por uniqueId exacto
          slotIndex = window.selectedTeam.indexOf(uniqueId);
        } else {
          // Para cartas sin trait, buscar por cardId base con _notrait
          const baseId = card.id;
          slotIndex = window.selectedTeam.findIndex(teamCard => {
            return teamCard && teamCard.startsWith(`${baseId}_notrait`);
          });
        }
        
        if (slotIndex !== -1) {
          removeCardFromTeam(slotIndex);
        }
      } else {
        // Añadir al equipo
        addCardToTeam(card);
      }
    });
    
    container.appendChild(cardDiv);
  });
  
  console.log('[TEAM BUILDER] Renderizado completado');
}

// ==================== IDENTIFICACIÓN Y PREVENCIÓN DE PERSONAJES DUPLICADOS ====================
const QUALITY_SUFFIXES_LIST = [
  '_iconoprime', '_icono_prime', '_icon_prime', '_prime_icon',
  '_diosantiguo', '_dios_antiguo', '_ancientgod',
  '_superheroe', '_legendario', '_legendaria',
  '_especiales', '_especial', '_special',
  '_iconos', '_icono', '_icon',
  '_heroes', '_heroe', '_hero',
  '_bronce', '_bronze',
  '_plata', '_silver',
  '_oro', '_gold',
  '_evolucion', '_evolution', '_evo',
  '_inmortal', '_inmo',
  '_legend', '_prime', '_tots', '_toty',
  '_evento', '_event'
];

/**
 * Obtiene el identificador canónico base de un personaje/jugador a partir de su ID o carta.
 * Limpia sufijos de calidad (incluso compuestos sin guión bajo como iconoprime, diosantiguo),
 * tags de traits (_notrait, trait_...) y nombres de versiones en texto.
 */
function getBasePlayerIdentifier(cardOrId, cardObj = null) {
  if (!cardOrId && !cardObj) return '';
  
  let id = '';
  let name = '';
  
  if (typeof cardOrId === 'object' && cardOrId !== null) {
    id = String(cardOrId.id || cardOrId.uniqueId || '').toLowerCase().trim();
    name = String(cardOrId.name || cardOrId.nombre || '').toLowerCase().trim();
  } else {
    id = String(cardOrId || '').toLowerCase().trim();
    if (cardObj && typeof cardObj === 'object') {
      name = String(cardObj.name || cardObj.nombre || '').toLowerCase().trim();
    }
  }
  
  // 1. Limpiar sufijos de instancia/traits y notrait
  if (id.includes('_notrait')) {
    id = id.split('_notrait')[0];
  }
  if (id.includes('trait_') && typeof cardTraitsMap !== 'undefined' && cardTraitsMap && cardTraitsMap[id]) {
    id = String(cardTraitsMap[id].cardId || id).toLowerCase();
  }
  
  // Si en teamBuilderCards existe la carta, intentar obtener su name
  if (!name && Array.isArray(window.teamBuilderCards)) {
    const found = window.teamBuilderCards.find(c => c && (c.id === id || c.uniqueId === id));
    if (found) name = String(found.name || found.nombre || '').toLowerCase().trim();
  }
  
  // 2. Limpiar sufijos de calidad/versión del ID
  let baseId = id;
  for (const suffix of QUALITY_SUFFIXES_LIST) {
    if (baseId.endsWith(suffix)) {
      baseId = baseId.slice(0, -suffix.length);
      break;
    }
  }
  baseId = baseId.replace(/_+$/, '');
  
  // 3. Limpiar calidad y formato del nombre para obtener la raíz canónica del personaje
  let cleanName = '';
  if (name) {
    let n = name.replace(/\([^)]*\)/g, '').replace(/\[[^\]]*\]/g, '').trim();
    const qualityWords = [
      'icono prime', 'iconoprime', 'prime icon', 'dios antiguo', 'diosantiguo',
      'super heroe', 'superheroe', 'super héroe',
      'especiales', 'especial', 'special',
      'icono', 'icon', 'héroe', 'heroe', 'hero',
      'bronce', 'bronze', 'plata', 'silver', 'oro', 'gold',
      'evolucion', 'evolución', 'evolution', 'evo',
      'legendario', 'legendaria', 'legend', 'prime', 'inmortal', 'inmo', 'tots', 'toty'
    ];
    for (const word of qualityWords) {
      const regex = new RegExp(`\\s+${word}$`, 'i');
      if (regex.test(n)) {
        n = n.replace(regex, '').trim();
        break;
      }
    }
    cleanName = n.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
  }
  
  const cleanId = baseId.replace(/[^a-z0-9]/g, '');
  return cleanName || cleanId;
}

/**
 * Comprueba si dos cartas representan exactamente al mismo personaje (incluso entre diferentes calidades/versiones).
 */
function areSamePlayerCards(cardA, cardB) {
  if (!cardA || !cardB) return false;
  const keyA = getBasePlayerIdentifier(cardA);
  const keyB = getBasePlayerIdentifier(cardB);
  if (keyA && keyB && keyA === keyB) return true;

  // Fallback por ID base limpio
  const getRawId = (c) => {
    let raw = typeof c === 'object' ? (c.id || c.uniqueId) : c;
    if (raw && raw.startsWith('trait_') && typeof cardTraitsMap !== 'undefined' && cardTraitsMap?.[raw]) {
      raw = cardTraitsMap[raw].cardId || raw;
    }
    return String(raw || '').toLowerCase().trim();
  };

  let idA = getRawId(cardA).split('_notrait')[0];
  let idB = getRawId(cardB).split('_notrait')[0];

  for (const s of QUALITY_SUFFIXES_LIST) {
    if (idA.endsWith(s)) { idA = idA.slice(0, -s.length); break; }
  }
  for (const s of QUALITY_SUFFIXES_LIST) {
    if (idB.endsWith(s)) { idB = idB.slice(0, -s.length); break; }
  }
  idA = idA.replace(/_+$/, '').replace(/[^a-z0-9]/g, '');
  idB = idB.replace(/_+$/, '').replace(/[^a-z0-9]/g, '');

  return !!(idA && idB && idA === idB);
}

// Registrar en window para disponibilidad global en todos los módulos (draft, infinito, online)
window.getBasePlayerIdentifier = getBasePlayerIdentifier;
window.areSamePlayerCards = areSamePlayerCards;
window.getBasePlayerName = getBasePlayerIdentifier;

// Añadir carta al equipo
function addCardToTeam(card) {
  // Verificar si ya hay una carta del mismo jugador en el equipo (cualquier versión o calidad)
  const isDuplicate = window.selectedTeam.some(teamCard => {
    if (!teamCard) return false;
    return areSamePlayerCards(card, teamCard);
  });
  
  if (isDuplicate) {
    const cardName = card.name || card.nombre || 'este personaje';
    alert(`⚠️ Ya tienes una versión de ${cardName} en el equipo.\n\nNo se permite equipar dos cartas del mismo personaje en ningún modo de juego.`);
    return;
  }
  
  // Buscar primer slot vacío en el equipo principal (slots 0-6)
  let emptySlot = -1;
  for (let i = 0; i < 7; i++) {
    if (window.selectedTeam[i] === null) {
      emptySlot = i;
      break;
    }
  }
  
  // Si el equipo principal está lleno, usar el slot de reserva (slot 7)
  if (emptySlot === -1 && window.selectedTeam[7] === null) {
    emptySlot = 7;
  }
  
  if (emptySlot === -1) {
    alert('⚠️ El equipo está completo (7 cartas + 1 reserva). Elimina una carta primero.');
    return;
  }
  
  // Si es una carta sin trait, generar un uniqueId con índice único
  let uniqueIdToSave = card.uniqueId || card.id;
  if (!card.hasTrait && uniqueIdToSave.includes('_notrait')) {
    // Generar ID único para esta instancia específica
    uniqueIdToSave = `${card.id}_notrait_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
  }
  
  window.selectedTeam[emptySlot] = uniqueIdToSave;
  
  // Crear copia de la carta con el uniqueId correcto para renderizar
  const cardToRender = { ...card, uniqueId: uniqueIdToSave };
  renderTeamSlot(emptySlot, cardToRender);
  renderTeamBuilderInventory(); // Re-renderizar para deshabilitar la carta
  
  // Guardar automáticamente
  saveTeam();
  
  // Si el equipo está completo (8 cartas), guardar con notificación (solo modo normal)
  const cardsInTeam = window.selectedTeam.filter(c => c !== null).length;
  if (cardsInTeam === 8 && !window.isInfiniteModeTeamBuilding) {
    console.log('[TEAM BUILDER] Equipo completo detectado, guardando con notificación...');
    setTimeout(() => {
      saveTeam(true); // Guardar con notificación
    }, 500);
  }
  
  console.log(`[TEAM BUILDER] Carta ${card.nombre || card.name} añadida al slot ${emptySlot + 1}`);
}

// Renderizar slot del equipo
function renderTeamSlot(slotIndex, card) {
  const slot = document.querySelector(`.team-slot[data-slot="${slotIndex}"]`);
  if (!slot) return;
  
  slot.classList.add('filled');
  
  // Limpiar contenido anterior
  const placeholder = slot.querySelector('.team-slot-placeholder');
  if (placeholder) placeholder.remove();
  
  // Añadir imagen de la carta
  let img = slot.querySelector('.team-slot-card-img');
  if (!img) {
    img = document.createElement('img');
    img.className = 'team-slot-card-img';
    slot.appendChild(img);
  }
  img.src = card.imageUrl || '';
  img.alt = card.nombre;
  
  // Añadir icono de trait si existe
  let traitIcon = slot.querySelector('.card-trait-icon');
  if (card.instanceId && cardTraitsMap && cardTraitsMap[card.instanceId]) {
    const traitData = cardTraitsMap[card.instanceId];
    const traitId = traitData.traitId || traitData;
    const trait = availableTraits.find(t => t.id === traitId);
    if (trait) {
      if (!traitIcon) {
        traitIcon = document.createElement('div');
        traitIcon.className = 'card-trait-icon';
        slot.appendChild(traitIcon);
      }
      traitIcon.innerHTML = `<img src="${trait.imageUrl}" alt="${trait.name}" title="${trait.name}" />`;
    }
  } else if (traitIcon) {
    traitIcon.remove();
  }
  
  // Añadir botón de eliminar
  let removeBtn = slot.querySelector('.team-slot-remove');
  if (!removeBtn) {
    removeBtn = document.createElement('button');
    removeBtn.className = 'team-slot-remove';
    removeBtn.innerHTML = '×';
    removeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      removeCardFromTeam(slotIndex);
    });
    slot.appendChild(removeBtn);
  }
  
  // Actualizar buffeos después de renderizar slot
  console.log('[TEAM BUILDER] Actualizando buffeos después de añadir carta...');
  updateTeamBuffs();
  console.log('[TEAM BUILDER] Buffeos actualizados');
}

// Eliminar carta del equipo
function removeCardFromTeam(slotIndex) {
  const cardId = window.selectedTeam[slotIndex];
  if (!cardId) return;
  
  window.selectedTeam[slotIndex] = null;
  
  const slot = document.querySelector(`.team-slot[data-slot="${slotIndex}"]`);
  if (slot) {
    slot.classList.remove('filled');
    
    // Eliminar imagen y botón
    const img = slot.querySelector('.team-slot-card-img');
    const removeBtn = slot.querySelector('.team-slot-remove');
    if (img) img.remove();
    if (removeBtn) removeBtn.remove();
    
    // Restaurar placeholder
    const placeholder = document.createElement('div');
    placeholder.className = 'team-slot-placeholder';
    placeholder.textContent = '+';
    slot.appendChild(placeholder);
  }
  
  renderTeamBuilderInventory(); // Re-renderizar para habilitar la carta
  
  // Guardar automáticamente
  saveTeam();
  
  // Actualizar buffeos después de eliminar carta
  updateTeamBuffs();
  
  console.log(`[TEAM BUILDER] Carta eliminada del slot ${slotIndex + 1}`);
}

// ==================== SISTEMA DE BUFFEOS ====================
// NOTA: BUFF_CONFIG y STAT_NAMES_MAP están declarados al inicio del archivo

// Calcular buffeos activos del equipo
function calculateTeamBuffs() {
  const mainTeam = window.selectedTeam.slice(0, 7).filter(cardId => cardId !== null);
  
  console.log('[TEAM BUFFS] ===== CALCULANDO BUFFEOS =====');
  console.log('[TEAM BUFFS] Cartas en equipo principal:', mainTeam);
  
  if (mainTeam.length === 0) {
    console.log('[TEAM BUFFS] No hay cartas en el equipo');
    return [];
  }
  
  // Contar procedencias
  const procedenciaCounts = {};
  
  for (const cardId of mainTeam) {
    // Obtener la carta del inventario
    const card = window.teamBuilderCards.find(c => {
      if (c.hasTrait) {
        return c.uniqueId === cardId;
      } else {
        return cardId.startsWith(`${c.id}_notrait`);
      }
    });
    
    console.log(`[TEAM BUFFS] Carta ${cardId}:`, card ? `${card.name} - Procedencia: ${card.procedencia}` : 'NO ENCONTRADA');
    
    if (card && card.procedencia) {
      procedenciaCounts[card.procedencia] = (procedenciaCounts[card.procedencia] || 0) + 1;
    }
  }
  
  console.log('[TEAM BUFFS] Procedencias contadas:', procedenciaCounts);
  
  // Generar buffeos activos con niveles
  // Nivel I: 3+ cartas = 2%
  // Nivel II: 5+ cartas = 5%
  // Nivel III: 7 cartas = 5% + stats adicionales
  const activeBuffs = [];
  
  for (const [procedencia, count] of Object.entries(procedenciaCounts)) {
    if (BUFF_CONFIG[procedencia]) {
      const buffInfo = BUFF_CONFIG[procedencia];
      
      // Determinar nivel según cantidad de cartas
      if (count >= 7) {
        // Nivel III: 5% a stats principales + stats adicionales
        const allStats = [...buffInfo.stats, ...buffInfo.statsLevel3];
        activeBuffs.push({
          procedencia,
          count,
          level: 3,
          stats: allStats,
          icon: buffInfo.icon,
          percentage: 5
        });
        console.log(`[TEAM BUFFS] ✅ Buffeo NIVEL III activado: ${procedencia} (${count} cartas) - 5% a ${allStats.join(', ')}`);
      } else if (count >= 5) {
        // Nivel II: 5% a stats principales
        activeBuffs.push({
          procedencia,
          count,
          level: 2,
          stats: buffInfo.stats,
          icon: buffInfo.icon,
          percentage: 5
        });
        console.log(`[TEAM BUFFS] ✅ Buffeo NIVEL II activado: ${procedencia} (${count} cartas) - 5%`);
      } else if (count >= 3) {
        // Nivel I: 2% a stats principales
        activeBuffs.push({
          procedencia,
          count,
          level: 1,
          stats: buffInfo.stats,
          icon: buffInfo.icon,
          percentage: 2
        });
        console.log(`[TEAM BUFFS] ✅ Buffeo NIVEL I activado: ${procedencia} (${count} cartas) - 2%`);
      }
    }
  }
  
  console.log(`[TEAM BUFFS] Total buffeos de procedencia activos: ${activeBuffs.length}`);
  
  // ========== CALCULAR BUFFEOS POR OWNER ==========
  const ownerCounts = {};
  
  for (const cardId of mainTeam) {
    const card = window.teamBuilderCards.find(c => {
      if (c.hasTrait) {
        return c.uniqueId === cardId;
      } else {
        return cardId.startsWith(`${c.id}_notrait`);
      }
    });
    
    if (card && card.owner) {
      ownerCounts[card.owner] = (ownerCounts[card.owner] || 0) + 1;
    }
  }
  
  console.log('[OWNER BUFFS] Owners contados:', ownerCounts);
  
  // Generar buffeos de owner
  for (const [owner, count] of Object.entries(ownerCounts)) {
    if (OWNER_BUFF_CONFIG[owner]) {
      const ownerInfo = OWNER_BUFF_CONFIG[owner];
      
      // Determinar nivel según cantidad de cartas
      if (count >= ownerInfo.minLevel2) {
        // Nivel II: 4 stats para normales, todas para premium
        activeBuffs.push({
          owner,
          count,
          level: 2,
          stats: ownerInfo.statsLevel2,
          icon: ownerInfo.icon,
          percentage: ownerInfo.percentageLevel2,
          isOwnerBuff: true
        });
        console.log(`[OWNER BUFFS] ✅ Buffeo NIVEL II activado: ${owner} (${count} cartas) - ${ownerInfo.percentageLevel2}% a ${ownerInfo.statsLevel2.length} stats`);
      } else if (count >= ownerInfo.minLevel1) {
        // Nivel I: 2 stats para normales, 3 stats para premium
        activeBuffs.push({
          owner,
          count,
          level: 1,
          stats: ownerInfo.stats,
          icon: ownerInfo.icon,
          percentage: ownerInfo.percentageLevel1,
          isOwnerBuff: true
        });
        console.log(`[OWNER BUFFS] ✅ Buffeo NIVEL I activado: ${owner} (${count} cartas) - ${ownerInfo.percentageLevel1}% a ${ownerInfo.stats.length} stats`);
      }
    }
  }
  
  // ========== CALCULAR BUFFEOS DE KIZUNA ==========
  const kizunaBuffResults = calculateKizunaBuffs(mainTeam);
  if (kizunaBuffResults.buffs.length > 0) {
    activeBuffs.push(...kizunaBuffResults.buffs);
    console.log('[KIZUNA BUFFS] ✅ Buffeos de Kizuna activados:', kizunaBuffResults.buffs.length);
  }

  console.log(`[TEAM BUFFS] Total buffeos activos (procedencia + owner + kizuna): ${activeBuffs.length}`);
  return activeBuffs;
}

// Calcular buffeos de Kizunas para un equipo
function calculateKizunaBuffs(team, customInventoryCards = null) {
  if (!Array.isArray(team) || team.length === 0) {
    return { buffs: [], byCard: {}, byKizuna: {} };
  }

  // Extraer los base IDs de las cartas del equipo
  const teamBaseIds = team.map(c => {
    if (!c) return '';
    const rawId = typeof c === 'string' ? c : (c.id || c.uniqueId || '');
    return rawId.replace(/_notrait.*$/, '').trim();
  }).filter(Boolean);

  const activeKizunaBuffs = [];
  const buffsByKizuna = {};
  const buffsByCard = {}; // { [baseCardId]: { ninjutsu: 0, taijutsu: 0, ... } }

  const kizunasList = Array.isArray(window.availableKizunas) ? window.availableKizunas : (Array.isArray(availableKizunas) ? availableKizunas : []);
  const invCards = customInventoryCards || window.__lastKnownInventoryCards || null;

  for (const kizuna of kizunasList) {
    if (!Array.isArray(kizuna.cardIds) || kizuna.cardIds.length === 0) continue;

    // 1. Si tenemos información de inventario, comprobar que el usuario posee TODAS las cartas del Kizuna (Kizuna Activo)
    if (invCards && typeof invCards === 'object') {
      const isKizunaActiveInInv = kizuna.cardIds.every(cardId => invCards[cardId] && invCards[cardId] > 0);
      if (!isKizunaActiveInInv) {
        // Kizuna inactivo: el buff no está disponible
        continue;
      }
    }

    // 2. Verificar si todas las cartas de este Kizuna están presentes en el equipo equipado
    const hasAllCards = kizuna.cardIds.every(cardId => teamBaseIds.includes(cardId));
    if (!hasAllCards) continue;

    const buffRewards = (kizuna.rewards || []).filter(r => String(r.type || '').toLowerCase() === 'buff');
    if (buffRewards.length === 0) continue;

    for (const reward of buffRewards) {
      const stats = reward.stats || reward.efecto || {};
      const allTeam = Boolean(reward.allTeam);

      const buffName = reward.name || kizuna.title || 'Buff Kizuna';
      let buffDesc = reward.description || '';
      if (!buffDesc) {
        const statParts = Object.entries(stats).map(([s, val]) => `+${val}% ${STAT_NAMES_MAP[s] || (s.toLowerCase() === 'all' ? 'Todas las stats' : (s.charAt(0).toUpperCase() + s.slice(1)))}`);
        const targetText = allTeam ? 'a todo el equipo' : `a los miembros de ${kizuna.title}`;
        buffDesc = `Aumenta un ${statParts.join(' y ')} ${targetText}`;
      }

      const kizunaBuffData = {
        kizunaId: kizuna.id,
        kizunaTitle: kizuna.title,
        name: buffName,
        description: buffDesc,
        stats,
        allTeam,
        cardIds: kizuna.cardIds,
        isKizunaBuff: true,
        icon: '⚡'
      };

      activeKizunaBuffs.push(kizunaBuffData);
      buffsByKizuna[kizuna.id] = kizunaBuffData;

      const targetCardIds = allTeam ? teamBaseIds : kizuna.cardIds;
      for (const targetId of targetCardIds) {
        if (!buffsByCard[targetId]) {
          buffsByCard[targetId] = {
            ninjutsu: 0,
            taijutsu: 0,
            resistencia: 0,
            velocidad: 0,
            defensa: 0,
            fisico: 0,
            all: 0
          };
        }

        for (const [statKey, statVal] of Object.entries(stats)) {
          const valNum = Number(statVal) || 0;
          const sLower = statKey.toLowerCase();
          if (sLower === 'all') {
            buffsByCard[targetId].all = (buffsByCard[targetId].all || 0) + valNum;
          } else if (buffsByCard[targetId][sLower] !== undefined) {
            buffsByCard[targetId][sLower] = (buffsByCard[targetId][sLower] || 0) + valNum;
          } else {
            buffsByCard[targetId][sLower] = valNum;
          }
        }
      }
    }
  }

  return {
    buffs: activeKizunaBuffs,
    byKizuna: buffsByKizuna,
    byCard: buffsByCard
  };
}

// Renderizar buffeos en la UI
function updateTeamBuffs() {
  console.log('[TEAM BUFFS] ========== updateTeamBuffs LLAMADA ==========');
  const buffsList = document.getElementById('team-buffs-list');
  if (!buffsList) {
    console.warn('[TEAM BUFFS] Elemento team-buffs-list no encontrado');
    return;
  }
  
  const activeBuffs = calculateTeamBuffs();
  console.log('[TEAM BUFFS] Buffeos calculados:', activeBuffs.length, activeBuffs);
  
  if (activeBuffs.length === 0) {
    buffsList.innerHTML = '<div class="buff-empty">Equipa al menos 3 cartas de la misma procedencia o completa un Kizuna para activar buffeos</div>';
    console.log('[TEAM BUFFS] No hay buffeos activos, mostrando mensaje vacío');
    return;
  }
  
  const buffsHTML = activeBuffs.map((buff, index) => {
    // Buff de Kizuna
    if (buff.isKizunaBuff) {
      return `
        <div class="buff-item buff-item-kizuna">
          <div class="buff-item-icon">${buff.icon || '⚡'}</div>
          <div class="buff-item-text">
            <strong>${escapeHtml(buff.name)}:</strong> ${escapeHtml(buff.description)}
          </div>
        </div>
      `;
    }

    let statText;
    if (buff.stats.includes('all')) {
      statText = 'todas las stats';
    } else {
      statText = buff.stats.map(s => STAT_NAMES_MAP[s] || s).join(' y ');
    }
    
    // Convertir nivel a número romano
    const levelRoman = buff.level === 1 ? 'I' : buff.level === 2 ? 'II' : 'III';
    
    // Diferenciar entre buffeo de procedencia y owner
    if (buff.isOwnerBuff) {
      console.log(`[OWNER BUFFS] Renderizando buffeo ${index + 1}:`, buff.owner, levelRoman, '-', statText, `${buff.percentage}%`);
      return `
        <div class="buff-item buff-item-owner">
          <div class="buff-item-icon">${buff.icon}</div>
          <div class="buff-item-text">
            <strong>${buff.owner} ${levelRoman}:</strong> Aumenta un ${buff.percentage}% ${statText} a las cartas de ${buff.owner}
          </div>
        </div>
      `;
    } else {
      console.log(`[TEAM BUFFS] Renderizando buffeo ${index + 1}:`, buff.procedencia, levelRoman, '-', statText, `${buff.percentage}%`);
      return `
        <div class="buff-item">
          <div class="buff-item-icon">${buff.icon}</div>
          <div class="buff-item-text">
            <strong>${buff.procedencia} ${levelRoman}:</strong> Aumenta un ${buff.percentage}% ${statText} a las cartas de ${buff.procedencia}
          </div>
        </div>
      `;
    }
  }).join('');
  
  buffsList.innerHTML = buffsHTML;
  console.log('[TEAM BUFFS] HTML de buffeos renderizado:', buffsHTML.length, 'caracteres');
  console.log('[TEAM BUFFS] Total buffeos mostrados:', activeBuffs.length);
}

// Calcular buffeos para batalla (recibe un array de cartas)
function calculateBattleBuffs(team) {
  if (!team || team.length === 0) {
    return { buffs: [], byProcedencia: {}, byOwner: {}, byKizuna: {}, byKizunaCard: {} };
  }
  
  // Contar procedencias
  const procedenciaCounts = {};
  const cardsByProcedencia = {};
  
  for (const card of team) {
    if (card && card.procedencia) {
      procedenciaCounts[card.procedencia] = (procedenciaCounts[card.procedencia] || 0) + 1;
      if (!cardsByProcedencia[card.procedencia]) {
        cardsByProcedencia[card.procedencia] = [];
      }
      cardsByProcedencia[card.procedencia].push(card);
    }
  }
  
  // Generar buffeos activos con niveles
  const activeBuffs = [];
  const buffsByProcedencia = {};
  
  for (const [procedencia, count] of Object.entries(procedenciaCounts)) {
    if (BUFF_CONFIG[procedencia]) {
      const buffInfo = BUFF_CONFIG[procedencia];
      let level, percentage, statsToUse;
      
      // Determinar nivel
      if (count >= 7) {
        level = 3;
        percentage = 5;
        statsToUse = [...buffInfo.stats, ...buffInfo.statsLevel3];
      } else if (count >= 5) {
        level = 2;
        percentage = 5;
        statsToUse = buffInfo.stats;
      } else if (count >= 3) {
        level = 1;
        percentage = 2;
        statsToUse = buffInfo.stats;
      } else {
        continue; // No hay buffeo
      }
      
      const buffData = {
        procedencia,
        level,
        count,
        stats: statsToUse,
        icon: buffInfo.icon,
        percentage
      };
      
      activeBuffs.push(buffData);
      buffsByProcedencia[procedencia] = buffData;
    }
  }
  
  // ========== CALCULAR BUFFEOS POR OWNER ==========
  const ownerCounts = {};
  const buffsByOwner = {};
  
  for (const card of team) {
    if (card && card.owner) {
      ownerCounts[card.owner] = (ownerCounts[card.owner] || 0) + 1;
    }
  }
  
  // Generar buffeos de owner
  for (const [owner, count] of Object.entries(ownerCounts)) {
    if (OWNER_BUFF_CONFIG[owner]) {
      const ownerInfo = OWNER_BUFF_CONFIG[owner];
      let level, percentage, statsToUse;
      
      // Determinar nivel
      if (count >= ownerInfo.minLevel2) {
        level = 2;
        percentage = ownerInfo.percentageLevel2;
        statsToUse = ownerInfo.statsLevel2;
      } else if (count >= ownerInfo.minLevel1) {
        level = 1;
        percentage = ownerInfo.percentageLevel1;
        statsToUse = ownerInfo.stats;
      } else {
        continue; // No hay buffeo
      }
      
      const buffData = {
        owner,
        level,
        count,
        stats: statsToUse,
        icon: ownerInfo.icon,
        percentage,
        isOwnerBuff: true
      };
      
      activeBuffs.push(buffData);
      buffsByOwner[owner] = buffData;
    }
  }
  
  // ========== CALCULAR BUFFEOS DE KIZUNA ==========
  const kizunaBuffResults = calculateKizunaBuffs(team);
  if (kizunaBuffResults.buffs.length > 0) {
    activeBuffs.push(...kizunaBuffResults.buffs);
  }

  return {
    buffs: activeBuffs,
    byProcedencia: buffsByProcedencia,
    byOwner: buffsByOwner,
    byKizuna: kizunaBuffResults.byKizuna,
    byKizunaCard: kizunaBuffResults.byCard
  };
}

// ==================== FIN SISTEMA DE BUFFEOS ====================

// Buscar cartas en el inventario
function setupTeamBuilderSearch() {
  
  const slot = document.querySelector(`.team-slot[data-slot="${slotIndex}"]`);
  if (slot) {
    slot.classList.remove('filled');
    
    // Eliminar imagen y botón
    const img = slot.querySelector('.team-slot-card-img');
    const removeBtn = slot.querySelector('.team-slot-remove');
    if (img) img.remove();
    if (removeBtn) removeBtn.remove();
    
    // Restaurar placeholder
    const placeholder = document.createElement('div');
    placeholder.className = 'team-slot-placeholder';
    placeholder.textContent = '+';
    slot.appendChild(placeholder);
  }
  
  renderTeamBuilderInventory(); // Re-renderizar para habilitar la carta
  
  // Guardar automáticamente
  saveTeam();
  
  console.log(`[TEAM BUILDER] Carta eliminada del slot ${slotIndex + 1}`);
}

// Configurar búsqueda
function setupTeamBuilderSearch() {
  const searchInput = document.getElementById('team-search');
  if (!searchInput) {
    console.error('[TEAM BUILDER] Input de búsqueda no encontrado');
    return;
  }
  
  console.log('[TEAM BUILDER] Búsqueda configurada');
  
  searchInput.addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase().trim();
    
    console.log('[TEAM BUILDER] Búsqueda:', query);
    
    if (!query) {
      renderTeamBuilderInventory();
      return;
    }
    
    const filtered = window.teamBuilderCards.filter(card => {
      const nombre = (card.nombre || card.name || '').toLowerCase();
      return nombre.includes(query);
    });
    
    console.log(`[TEAM BUILDER] ${filtered.length} cartas encontradas de ${window.teamBuilderCards.length} totales`);
    renderTeamBuilderInventory(filtered);
  });
}

// ========================================
// GUARDAR Y CARGAR EQUIPO
// ========================================

// Sanitizar equipos normales para eliminar cualquier residuo o carta temporal del Modo Infinito
function sanitizeNormalTeamsFromInfiniteResidue() {
  if (!Array.isArray(window.allTeams)) return;

  const validInventoryBaseIds = new Set();
  const validUniqueIds = new Set();
  if (Array.isArray(window.teamBuilderCards) && window.teamBuilderCards.length > 0) {
    window.teamBuilderCards.forEach((c) => {
      if (c && !c.isRunTemporal) {
        validInventoryBaseIds.add(String(c.id));
        if (c.uniqueId) validUniqueIds.add(String(c.uniqueId));
      }
    });
  }

  let modified = false;
  window.allTeams = window.allTeams.map((team) => {
    if (!Array.isArray(team)) return [null, null, null, null, null, null, null, null];
    return team.map((entry) => {
      if (!entry) return null;
      const str = String(entry);
      // Solo descartar cartas temporales exclusivas de runs infinitas que no existen en el inventario real
      if (str.startsWith('infinite_') || str.startsWith('temp_') || str.startsWith('run_card_')) {
        modified = true;
        return null;
      }
      if (validInventoryBaseIds.size > 0) {
        const baseId = str.includes('_notrait') ? str.split('_notrait')[0] : 
                       str.includes('trait_') ? (cardTraitsMap[str]?.cardId || str) : str;
        if (!validInventoryBaseIds.has(baseId) && !validUniqueIds.has(str)) {
          modified = true;
          return null;
        }
      }
      return entry;
    });
  });

  if (modified) {
    window.selectedTeam = window.allTeams[window.currentTeamIndex] || [];
    try {
      const teamData = {
        allTeams: window.allTeams,
        teamNames: window.teamNames,
        allTeamPowers: window.allTeamPowers,
        currentTeamIndex: window.currentTeamIndex,
        timestamp: new Date().toISOString()
      };
      localStorage.setItem('savedTeams', JSON.stringify(teamData));
    } catch {}
  }
}

// Actualizar UI según si se está en Modo Normal o Modo Infinito
function updateTeamBuilderModeUI() {
  const isInfinite = Boolean(window.isInfiniteModeTeamBuilding);
  const saveBtn = document.getElementById('team-save-btn');
  const tabsContainer = document.querySelector('.team-tabs-container');
  const continueBtn = document.getElementById('team-continue-btn');
  const gameTitle = document.querySelector('#team-builder .game-title');

  if (saveBtn) {
    saveBtn.style.display = isInfinite ? 'none' : '';
  }
  if (tabsContainer) {
    tabsContainer.style.display = isInfinite ? 'none' : '';
  }
  if (continueBtn) {
    continueBtn.textContent = isInfinite ? 'Confirmar Equipo' : 'Continuar ➔';
  }
  if (gameTitle) {
    gameTitle.textContent = isInfinite ? 'Equipo Modo Infinito' : 'Crea tu Equipo';
  }
}
window.updateTeamBuilderModeUI = updateTeamBuilderModeUI;

// Guardar equipo exclusivo de Modo Infinito reactivamente
function saveInfiniteCurrentTeam() {
  try {
    const raw = localStorage.getItem('infinite_saved_team');
    const existing = raw ? JSON.parse(raw) : {};
    const team = Array.isArray(window.selectedTeam) ? [...window.selectedTeam] : (existing.team || []);
    const powers = Array.isArray(window.selectedTeamPowers) ? [...window.selectedTeamPowers] : (existing.powers || []);
    const cardIds = team.map(c => {
      if (!c) return null;
      if (typeof c === 'string') {
        if (c.includes('_notrait')) return c.split('_notrait')[0];
        return c;
      }
      return c.id || null;
    }).filter(Boolean);
    const powerIds = powers.filter(Boolean).map(p => typeof p === 'string' ? p : (p?.id || null)).filter(Boolean);
    const updated = {
      ...existing,
      team,
      powers,
      cardIds,
      powerIds,
      timestamp: new Date().toISOString()
    };
    localStorage.setItem('infinite_saved_team', JSON.stringify(updated));
    console.log('[TEAM BUILDER] Guardado reactivo de equipo y poderes en infinite_saved_team:', updated);
    return true;
  } catch (e) {
    console.warn('[TEAM BUILDER] Error en guardado reactivo de equipo infinito:', e);
    return false;
  }
}
window.saveInfiniteCurrentTeam = saveInfiniteCurrentTeam;

// Guardar equipos en localStorage (NORMAL ONLY - Modo Infinito se guarda reactivamente en su propio storage)
function saveTeam(showNotif = false) {
  if (window.isInfiniteModeTeamBuilding) {
    console.log('[TEAM BUILDER] Modo Infinito activo: Guardando reactivamente en infinite_saved_team.');
    saveInfiniteCurrentTeam();
    return true;
  }

  console.log('[TEAM BUILDER] saveTeam() normal llamada, showNotif:', showNotif);
  console.log('[TEAM BUILDER] Guardando equipo', window.currentTeamIndex + 1);
  
  // Actualizar window.allTeams con los datos actuales de window.selectedTeam
  if (window.selectedTeam && window.currentTeamIndex >= 0 && window.currentTeamIndex < 5) {
    window.allTeams[window.currentTeamIndex] = [...window.selectedTeam];
  }
  
  // Actualizar window.allTeamPowers con los poderes actuales
  if (window.selectedTeamPowers && window.currentTeamIndex >= 0 && window.currentTeamIndex < 5) {
    window.allTeamPowers[window.currentTeamIndex] = [...window.selectedTeamPowers];
  }
  
  // Guardar en localStorage
  try {
    const teamData = {
      allTeams: window.allTeams,
      teamNames: window.teamNames,
      allTeamPowers: window.allTeamPowers,
      currentTeamIndex: window.currentTeamIndex,
      lastSaved: new Date().toISOString()
    };
    
    console.log('[TEAM BUILDER] Guardando estructura completa:', teamData);
    localStorage.setItem('savedTeams', JSON.stringify(teamData));
    
    // Mostrar notificación si se solicita (solo modo normal)
    if (showNotif && !window.isInfiniteModeTeamBuilding) {
      if (typeof showSaveNotification === 'function') {
        showSaveNotification();
      } else if (typeof showNotification === 'function') {
        showNotification('💾 ¡Equipo guardado con éxito!', 'success');
      }
    }
    
    return true;
  } catch (error) {
    console.error('[TEAM BUILDER] Error al guardar equipos:', error);
    if (showNotif) {
      alert('Error al guardar el equipo. Por favor, intenta de nuevo.');
    }
    return false;
  }
}

// Guardar equipo actual (wrapper para saveTeam sin notificación)
function saveCurrentTeam() {
  if (window.isInfiniteModeTeamBuilding) {
    saveInfiniteCurrentTeam();
    return;
  }
  saveTeam(false);
}

// Cargar equipos desde localStorage
function loadSavedTeam() {
  if (window.isInfiniteModeTeamBuilding) {
    console.log('[TEAM BUILDER] Cargando equipo exclusivo de Modo Infinito...');
    try {
      const savedInfinite = localStorage.getItem('infinite_saved_team');
      if (savedInfinite) {
        const parsed = JSON.parse(savedInfinite);
        window.selectedTeam = parsed.team || [null, null, null, null, null, null, null, null];
        const loadedPowers = parsed.powers || parsed.powerIds || [null, null, null];
        window.selectedTeamPowers = Array.isArray(loadedPowers) ? [...loadedPowers] : [null, null, null];
        while (window.selectedTeamPowers.length < 3) window.selectedTeamPowers.push(null);
        renderTeamSlots();
        renderPowerSlots();
        return true;
      }
    } catch (err) {
      console.error('[TEAM BUILDER] Error cargando equipo de Modo Infinito:', err);
    }
    window.selectedTeam = [null, null, null, null, null, null, null, null];
    window.selectedTeamPowers = [null, null, null];
    renderTeamSlots();
    renderPowerSlots();
    return false;
  }

  console.log('[TEAM BUILDER] loadSavedTeam() normal llamada');
  
  try {
    const savedData = localStorage.getItem('savedTeams');
    console.log('[TEAM BUILDER] Datos recuperados de localStorage:', savedData);
    
    if (!savedData) {
      console.log('[TEAM BUILDER] No hay equipos guardados');
      return false;
    }
    
    const teamData = JSON.parse(savedData);
    console.log('[TEAM BUILDER] Datos parseados:', teamData);
    
    window.allTeams = teamData.allTeams || [
      [null, null, null, null, null, null, null, null],
      [null, null, null, null, null, null, null, null],
      [null, null, null, null, null, null, null, null],
      [null, null, null, null, null, null, null, null],
      [null, null, null, null, null, null, null, null]
    ];
    window.teamNames = teamData.teamNames || ['Equipo 1', 'Equipo 2', 'Equipo 3', 'Equipo 4', 'Equipo 5'];
    window.allTeamPowers = teamData.allTeamPowers || [
      [null, null, null],
      [null, null, null],
      [null, null, null],
      [null, null, null],
      [null, null, null]
    ];
    window.currentTeamIndex = (typeof teamData.currentTeamIndex === 'number' && teamData.currentTeamIndex >= 0 && teamData.currentTeamIndex < 5) ? teamData.currentTeamIndex : 0;
    window.selectedTeam = window.allTeams[window.currentTeamIndex];
    window.selectedTeamPowers = window.allTeamPowers[window.currentTeamIndex];

    // Limpiar cualquier residuo ajeno en los equipos normales
    sanitizeNormalTeamsFromInfiniteResidue();
    
    console.log('[TEAM BUILDER] Equipos cargados:', window.allTeams);
    console.log('[TEAM BUILDER] Poderes cargados:', window.allTeamPowers);
    console.log('[TEAM BUILDER] Equipo actual:', window.currentTeamIndex);
    
    // Actualizar UI con el nombre del equipo
    updateTeamNameUI();
    updateTeamTabs();
    
    // Renderizar los slots con las cartas guardadas
    renderTeamSlots();
    renderPowerSlots();
    
    return true;
  } catch (error) {
    console.error('[TEAM BUILDER] Error cargando equipos:', error);
    return false;
  }
}

// Renderizar slots del equipo con las cartas guardadas
async function renderTeamSlots() {
  if (!isElectron) return;
  
  console.log('[TEAM BUILDER] Renderizando slots guardados...');
  
  try {
    // Obtener todas las cartas del catálogo para mostrar las imágenes
    const allCards = await window.kvrcards.getAllCards();
    
    // Normalizar el array de cartas
    let cardsList = [];
    if (Array.isArray(allCards)) {
      cardsList = allCards;
    } else if (allCards.ok && Array.isArray(allCards.cards)) {
      cardsList = allCards.cards;
    }
    
    console.log('[TEAM BUILDER] Cartas del catálogo:', cardsList.length);
    
    for (let i = 0; i < window.selectedTeam.length; i++) {
      const cardUniqueId = window.selectedTeam[i];
      
      if (cardUniqueId) {
        // Determinar el cardId base
        let baseCardId = cardUniqueId;
        let instanceId = null;
        
        if (cardUniqueId.includes('_notrait_')) {
          baseCardId = cardUniqueId.split('_notrait_')[0];
        } else if (cardUniqueId.includes('trait_')) {
          instanceId = cardUniqueId;
          if (cardTraitsMap && cardTraitsMap[cardUniqueId]) {
            baseCardId = cardTraitsMap[cardUniqueId].cardId || cardUniqueId;
          }
        }
        
        // Buscar la carta en el catálogo
        const card = cardsList.find(c => c.id === baseCardId);
        console.log(`[TEAM BUILDER] Slot ${i}: Buscando carta ${baseCardId} (uniqueId: ${cardUniqueId}), encontrada:`, card);
        
        if (card) {
          // Crear copia con uniqueId e instanceId si aplica
          const cardWithInstance = {
            ...card,
            uniqueId: cardUniqueId,
            instanceId: instanceId
          };
          // Usar la función existente renderTeamSlot
          renderTeamSlot(i, cardWithInstance);
        }
      }
    }
    
    // Re-renderizar el inventario para actualizar los botones
    renderTeamBuilderInventory();
    
    // Actualizar buffeos después de cargar las cartas
    updateTeamBuffs();
    
    console.log('[TEAM BUILDER] Slots renderizados correctamente');
  } catch (error) {
    console.error('[TEAM BUILDER] Error renderizando slots:', error);
  }
}

// ========================================
// SISTEMA DE PESTAÑAS Y NOMBRES DE EQUIPOS
// ========================================

// Cambiar de equipo (pestaña)
function switchTeam(teamIndex) {
  console.log('[TEAM BUILDER] Cambiando al equipo', teamIndex + 1);
  
  // Guardar el equipo actual antes de cambiar
  window.allTeams[window.currentTeamIndex] = [...window.selectedTeam];
  window.allTeamPowers[window.currentTeamIndex] = [...window.selectedTeamPowers];
  saveTeam(); // Guardar automáticamente
  
  // Cambiar al nuevo equipo
  window.currentTeamIndex = teamIndex;
  window.selectedTeam = window.allTeams[teamIndex];
  window.selectedTeamPowers = window.allTeamPowers[teamIndex];
  
  // Actualizar UI
  updateTeamTabs();
  updateTeamNameUI();
  clearTeamSlots();
  renderTeamSlots();
  renderPowerSlots(); // Renderizar poderes del nuevo equipo
  renderTeamBuilderInventory();
  renderPowersInventory(); // Actualizar inventario de poderes
  
  console.log('[TEAM BUILDER] Equipo cambiado a:', window.selectedTeam);
  console.log('[TEAM BUILDER] Poderes del equipo:', window.selectedTeamPowers);
}

// Actualizar pestañas activas
function updateTeamTabs() {
  const tabs = document.querySelectorAll('.team-tab');
  tabs.forEach((tab, index) => {
    if (index === window.currentTeamIndex) {
      tab.classList.add('active');
    } else {
      tab.classList.remove('active');
    }
  });
}

// Actualizar nombre del equipo en la UI
function updateTeamNameUI() {
  const nameInput = document.getElementById('team-name-input');
  if (nameInput) {
    nameInput.value = window.teamNames[window.currentTeamIndex];
  }
}

// Limpiar todos los slots visualmente
function clearTeamSlots() {
  for (let i = 0; i < 8; i++) {
    const slot = document.querySelector(`.team-slot[data-slot="${i}"]`);
    if (slot) {
      slot.classList.remove('filled');
      slot.innerHTML = `
        <div class="team-slot-number">${i === 7 ? 'R' : i + 1}</div>
        <div class="team-slot-placeholder">+</div>
      `;
    }
  }
}

// Configurar listeners de pestañas y nombre
function setupTeamTabsAndName() {
  console.log('[TEAM BUILDER] Configurando pestañas y nombres...');
  
  // Pestañas
  const tabs = document.querySelectorAll('.team-tab');
  console.log('[TEAM BUILDER] Pestañas encontradas:', tabs.length);
  
  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => {
      switchTeam(index);
    });
  });
  
  // Edición del nombre
  const nameInput = document.getElementById('team-name-input');
  const editBtn = document.getElementById('team-name-edit-btn');
  
  console.log('[TEAM BUILDER] Input de nombre:', nameInput);
  console.log('[TEAM BUILDER] Botón de edición:', editBtn);
  
  if (nameInput && editBtn) {
    // Inicialmente deshabilitado
    nameInput.disabled = true;
    console.log('[TEAM BUILDER] Input deshabilitado inicialmente');
    
    editBtn.addEventListener('click', (e) => {
      e.preventDefault();
      console.log('[TEAM BUILDER] Click en botón de edición, disabled:', nameInput.disabled);
      
      if (nameInput.disabled) {
        // Activar edición
        nameInput.disabled = false;
        nameInput.focus();
        nameInput.select();
        editBtn.classList.add('editing');
        editBtn.innerHTML = '✓';
        console.log('[TEAM BUILDER] Modo edición activado');
      } else {
        // Guardar y desactivar edición
        window.teamNames[window.currentTeamIndex] = nameInput.value || `Equipo ${window.currentTeamIndex + 1}`;
        nameInput.disabled = true;
        editBtn.classList.remove('editing');
        editBtn.innerHTML = '✏️';
        saveTeam(); // Guardar cambios
        console.log('[TEAM BUILDER] Nombre guardado:', window.teamNames[window.currentTeamIndex]);
      }
    });
    
    // Guardar con Enter
    nameInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter' && !nameInput.disabled) {
        e.preventDefault();
        editBtn.click();
      }
    });
    
    console.log('[TEAM BUILDER] Listeners de nombre configurados');
  } else {
    console.error('[TEAM BUILDER] No se encontraron elementos de nombre');
  }
  
  console.log('[TEAM BUILDER] Pestañas y nombres configurados');
}

// Mostrar notificación de guardado de equipo (solo team builder normal)
function showSaveNotification() {
  if (window.isInfiniteModeTeamBuilding) return;
  const currentTeamName = (window.teamNames && window.teamNames[window.currentTeamIndex]) 
    ? window.teamNames[window.currentTeamIndex] 
    : `Equipo ${window.currentTeamIndex + 1}`;
  showNotification(`💾 ¡${currentTeamName} guardado con éxito!`, 'success');
}
window.showSaveNotification = showSaveNotification;

// Mostrar notificación temporal
function showNotification(message, type = 'info') {
  // Crear elemento de notificación
  const notification = document.createElement('div');
  notification.className = `team-notification team-notification-${type}`;
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 15px 25px;
    background: ${type === 'success' ? 'linear-gradient(135deg, #10b981 0%, #059669 100%)' : 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)'};
    color: white;
    border-radius: 10px;
    font-weight: bold;
    font-size: 16px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    z-index: 10000;
    animation: slideInRight 0.3s ease;
  `;
  
  document.body.appendChild(notification);
  
  // Eliminar después de 3 segundos
  setTimeout(() => {
    notification.style.animation = 'slideOutRight 0.3s ease';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}
window.showNotification = showNotification;

// Función para configurar botón de reset
function setupResetButton() {
  console.log('[TEAM BUILDER] Configurando botón Restablecer...');
  
  const resetBtn = document.getElementById('team-reset-btn');
  if (!resetBtn) {
    console.warn('[TEAM BUILDER] Botón team-reset-btn no encontrado');
    return;
  }
  
  // Remover listeners anteriores si existen (clonar y reemplazar)
  const newResetBtn = resetBtn.cloneNode(true);
  resetBtn.parentNode.replaceChild(newResetBtn, resetBtn);
  
  newResetBtn.addEventListener('click', () => {
    console.log('[TEAM BUILDER] Click en Restablecer Equipo');
    
    // Confirmar antes de restablecer
    if (confirm('¿Seguro que quieres restablecer el equipo? Se eliminarán todas las cartas y poderes.')) {
      console.log('[TEAM BUILDER] Usuario confirmó restablecer');
      
      // Limpiar directamente el array de equipo
      window.selectedTeam = [null, null, null, null, null, null, null, null];
      console.log('[TEAM BUILDER] selectedTeam limpiado:', window.selectedTeam);
      
      // Limpiar todos los poderes  
      window.selectedPowers = [null, null, null];
      window.selectedTeamPowers = [null, null, null];
      console.log('[TEAM BUILDER] Poderes limpiados');
      
      // Renderizar slots vacíos
      for (let i = 0; i < 8; i++) {
        const slot = document.querySelector(`.team-slot[data-slot="${i}"]`);
        if (slot) {
          slot.classList.remove('filled');
          // Limpiar completamente el contenido
          slot.innerHTML = '';
          // Agregar placeholder
          const placeholder = document.createElement('div');
          placeholder.className = 'team-slot-placeholder';
          placeholder.textContent = '+';
          slot.appendChild(placeholder);
        }
      }
      console.log('[TEAM BUILDER] Slots limpiados');
      
      // Renderizar poderes vacíos
      renderPowerSlots();
      console.log('[TEAM BUILDER] Poderes renderizados');
      
      // Re-renderizar inventario para habilitar todas las cartas
      renderTeamBuilderInventory();
      console.log('[TEAM BUILDER] Inventario re-renderizado');
      
      // Guardar estado vacío
      saveTeam();
      console.log('[TEAM BUILDER] Estado guardado');
      
      // Actualizar buffeos (debería mostrar mensaje vacío)
      updateTeamBuffs();
      console.log('[TEAM BUILDER] Buffeos actualizados');
      
      console.log('[TEAM BUILDER] ✅ Equipo restablecido completamente');
    } else {
      console.log('[TEAM BUILDER] Usuario canceló restablecer');
    }
  });
  
  console.log('[TEAM BUILDER] ✅ Listener del botón reset registrado');
}

// Configurar botón Guardar
function setupSaveButton() {
  console.log('[TEAM BUILDER] Configurando botón Guardar...');
  
  const saveBtn = document.getElementById('team-save-btn');
  if (!saveBtn) {
    console.warn('[TEAM BUILDER] Botón team-save-btn no encontrado');
    return;
  }

  if (window.isInfiniteModeTeamBuilding) {
    saveBtn.style.display = 'none';
    console.log('[TEAM BUILDER] Modo Infinito activo: botón Guardar ocultado.');
    return;
  }
  saveBtn.style.display = '';
  
  // Remover listeners anteriores si existen (clonar y reemplazar)
  const newSaveBtn = saveBtn.cloneNode(true);
  saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
  
  newSaveBtn.addEventListener('click', () => {
    if (window.isInfiniteModeTeamBuilding) return;
    console.log('[TEAM BUILDER] Click en Guardar Equipo');
    
    // Llamar saveTeam con notificación
    const success = saveTeam(true);
    
    if (success) {
      console.log('[TEAM BUILDER] Equipo guardado exitosamente');
      const originalHTML = newSaveBtn.innerHTML;
      newSaveBtn.innerHTML = '✅ ¡Guardado!';
      newSaveBtn.disabled = true;
      setTimeout(() => {
        newSaveBtn.innerHTML = originalHTML;
        newSaveBtn.disabled = false;
      }, 1500);
    } else {
      console.error('[TEAM BUILDER] Error al guardar equipo');
    }
  });
  
  console.log('[TEAM BUILDER] Botón Guardar configurado');
}

// Botón Continuar
if (isElectron) {
  // El listener del botón continuar se registra más abajo, después de cargar el inventario
}

// Registrar el botón de continuar cuando el DOM esté listo
function setupContinueButton() {
  console.log('[TEAM BUILDER] Configurando botón Continuar...');
  
  // Usar setTimeout para asegurar que el DOM está listo
  setTimeout(() => {
    const continueBtn = document.getElementById('team-continue-btn');
    console.log('[TEAM BUILDER] Botón encontrado:', continueBtn);
    
    if (continueBtn) {
      // Remover listeners anteriores si existen
      const newBtn = continueBtn.cloneNode(true);
      continueBtn.parentNode.replaceChild(newBtn, continueBtn);
      
      newBtn.addEventListener('click', () => {
        console.log('[TEAM BUILDER] ===== CLICK EN CONTINUAR =====');
        validateTeamAndContinue();
      });
      console.log('[TEAM BUILDER] Listener registrado correctamente');
      updateTeamBuilderModeUI();
    } else {
      console.error('[TEAM BUILDER] ERROR: No se encontró el botón team-continue-btn');
      // Reintentar después de 500ms
      setTimeout(setupContinueButton, 500);
    }
  }, 100);
}

// Función para validar el equipo según la dificultad
function validateTeamAndContinue() {
  const difficulty = window.selectedDifficulty;
  const isOnlineBattle = window.onlineState && (window.onlineState.inQueue || window.onlineState.inBattle || window.onlineState.matchId);
  
  console.log('[VALIDATION] Difficulty selected:', difficulty);
  console.log('[VALIDATION] Is online battle:', isOnlineBattle);
  console.log('[VALIDATION] window.selectedDifficulty:', window.selectedDifficulty);
  
  // Solo validar dificultad para partidas offline
  if (!isOnlineBattle && !difficulty) {
    alert('⚠️ Error: No se ha seleccionado ninguna dificultad');
    return;
  }
  
  // Validar que hay exactamente 7 cartas en el equipo principal y 1 en reserva
  const mainTeam = window.selectedTeam.slice(0, 7).filter(cardId => cardId !== null);
  const reserveSlot = window.selectedTeam[7];
  
  console.log('[VALIDATION] Main team:', mainTeam);
  console.log('[VALIDATION] Reserve slot:', reserveSlot);
  
  if (mainTeam.length !== 7) {
    alert(`⚠️ Requisito obligatorio:\n\n• Debes tener exactamente 7 cartas en el equipo principal\n• Actualmente tienes: ${mainTeam.length}/7 cartas`);
    return;
  }
  
  if (!reserveSlot) {
    alert('⚠️ Requisito obligatorio:\n\n• Debes tener 1 carta en el slot de reserva (8º slot)');
    return;
  }
  
  // Validar que hay exactamente 3 poderes equipados
  const equippedPowers = window.selectedTeamPowers.filter(powerId => powerId !== null);
  console.log('[VALIDATION] Equipped powers:', equippedPowers);
  
  if (equippedPowers.length !== 3) {
    alert(`⚠️ Requisito obligatorio:\n\n• Debes tener exactamente 3 poderes equipados\n• Actualmente tienes: ${equippedPowers.length}/3 poderes`);
    return;
  }
  
  // Obtener información completa de las cartas (usando uniqueId para respetar traits)
  const teamCards = mainTeam.map(uniqueId => {
    // Buscar por uniqueId o por id si no hay match
    let card = window.teamBuilderCards.find(c => (c.uniqueId || c.id) === uniqueId);
    if (!card) {
      // Fallback: buscar solo por id base y asignar el uniqueId correcto
      const baseId = uniqueId.includes('_notrait') ? uniqueId.split('_notrait')[0] : 
                     uniqueId.includes('trait_') ? (cardTraitsMap[uniqueId]?.cardId || uniqueId) : uniqueId;
      const baseCard = window.teamBuilderCards.find(c => c.id === baseId && !c.hasTrait);
      if (baseCard) {
        card = {
          ...baseCard,
          uniqueId: uniqueId,
          instanceId: uniqueId.includes('trait_') ? uniqueId : null
        };
      }
    }
    return card;
  }).filter(card => card !== undefined);
  
  console.log('[VALIDATION] Team cards:', teamCards);
  
  if (teamCards.length === 0) {
    alert('⚠️ Error al cargar las cartas del equipo');
    return;
  }
  
  // Validar duplicados de personaje en todo el equipo (7 titulares + 1 reserva)
  const fullTeamIds = [...mainTeam, reserveSlot];
  const fullTeamCards = fullTeamIds.map(uid => {
    let c = window.teamBuilderCards.find(card => (card.uniqueId || card.id) === uid);
    if (!c) {
      const baseId = uid.includes('_notrait') ? uid.split('_notrait')[0] : 
                     uid.includes('trait_') ? (cardTraitsMap[uid]?.cardId || uid) : uid;
      c = window.teamBuilderCards.find(card => card.id === baseId);
    }
    return c || { id: uid };
  });

  const seenCharacters = new Map();
  for (let i = 0; i < fullTeamCards.length; i++) {
    const card = fullTeamCards[i];
    const charKey = getBasePlayerIdentifier(card);
    if (seenCharacters.has(charKey)) {
      const prevName = seenCharacters.get(charKey);
      const curName = card.name || card.nombre || card.id;
      alert(`⚠️ No puedes tener dos versiones del mismo personaje en el equipo:\n\n• ${prevName}\n• ${curName}\n\nPor favor, cambia una de las dos cartas antes de continuar.`);
      return;
    }
    seenCharacters.set(charKey, card.name || card.nombre || card.id);
  }
  
  // Obtener la media más alta del equipo (stat media individual)
  const mediaStats = teamCards.map(card => card.media || 0);
  const maxMedia = Math.max(...mediaStats);
  
  console.log('[VALIDATION] Dificultad:', difficulty);
  console.log('[VALIDATION] Cartas en equipo:', teamCards.length);
  console.log('[VALIDATION] Media más alta:', maxMedia);
  console.log('[VALIDATION] Todas las medias:', mediaStats);
  
  const errors = [];
  
  // Solo validar restricciones de dificultad para partidas offline
  if (!isOnlineBattle) {
    // Validar según dificultad
    switch(difficulty) {
      case 'principiante':
        // Media máxima: 80 (ninguna carta puede superar 80), Mínimo 2 platas
        if (maxMedia > 80) {
          errors.push(`Tienes una carta con media ${maxMedia} que supera el máximo de 80`);
        }
        const platas = teamCards.filter(card => card.calidad === 'Plata' || card.quality === 'Plata');
        if (platas.length < 2) {
          errors.push(`Necesitas al menos 2 cartas de Plata (tienes ${platas.length})`);
        }
        break;
        
      case 'amateur':
        // Media máxima: 85, Mínimo 1 plata
        if (maxMedia > 85) {
          errors.push(`Tienes una carta con media ${maxMedia} que supera el máximo de 85`);
        }
        const platasAmateur = teamCards.filter(card => card.calidad === 'Plata' || card.quality === 'Plata');
        if (platasAmateur.length < 1) {
          errors.push('Necesitas al menos 1 carta de Plata');
        }
        break;
        
      case 'experimentado':
        // Media máxima: 90, Mínimo 1 carta ≤80
        if (maxMedia > 90) {
          errors.push(`Tienes una carta con media ${maxMedia} que supera el máximo de 90`);
        }
        const cartasBajas = teamCards.filter(card => (card.media || 0) <= 80);
        if (cartasBajas.length < 1) {
          errors.push('Necesitas al menos 1 carta con media ≤80');
        }
        break;
        
      case 'profesional':
        // Media máxima: 95, Mínimo 1 carta especial
        if (maxMedia > 95) {
          errors.push(`Tienes una carta con media ${maxMedia} que supera el máximo de 95`);
        }
        const especiales = teamCards.filter(card => {
          const qStr = String(card.calidad || card.quality || card.tipo || card.type || '').toLowerCase();
          if (typeof appQualitiesCache !== 'undefined' && Array.isArray(appQualitiesCache)) {
            const qObj = appQualitiesCache.find(q => q.name?.toLowerCase() === qStr || q.id?.toLowerCase() === qStr);
            if (qObj) return Boolean(qObj.special);
          }
          return qStr.includes('especial') || 
            qStr.includes('icono') || 
            qStr.includes('heroe') || 
            qStr.includes('evo') || 
            qStr.includes('prime');
        });
        if (especiales.length < 1) {
          errors.push('Necesitas al menos 1 carta especial');
        }
        break;
        
      case 'dios-antiguo':
        // Media máxima: 99
        if (maxMedia > 99) {
          errors.push(`Tienes una carta con media ${maxMedia} que supera el máximo de 99`);
        }
        break;
        
      case 'inmo':
        // Sin restricciones
        break;
        
      default:
        // Si es una batalla de evento, permitir equipo sin restricciones a menos que el evento las defina
        if (window.isEventBattle || window.currentEventBattle || (typeof difficulty === 'string' && difficulty.toLowerCase().startsWith('evento_'))) {
          console.log('[VALIDATION] Batalla de evento detectada:', difficulty);
          const eventBattle = window.currentEventBattle;
          if (eventBattle && eventBattle.maxMedia && maxMedia > eventBattle.maxMedia) {
            errors.push(`Tienes una carta con media ${maxMedia} que supera el maximo permitido (${eventBattle.maxMedia})`);
          }
          break;
        }
        alert('Dificultad no reconocida: ' + difficulty);
        return;
    }
  } else {
    console.log('[VALIDATION] Modo online: omitiendo restricciones de dificultad');
  }
  
  // Mostrar resultado
  if (errors.length > 0) {
    const errorMessage = '❌ Equipo Inválido\n\nFaltan por cumplir los siguientes requisitos:\n\n' + 
                        errors.map(err => '• ' + err).join('\n');
    alert(errorMessage);
  } else {
    console.log('[GAME] ✅ Equipo válido. Iniciando batalla...');
    
    // IMPORTANTE: Verificar si es batalla online
    console.log('[GAME] DEBUG - window.battleState:', window.battleState);
    console.log('[GAME] DEBUG - window.battleState?.isOnline:', window.battleState?.isOnline);
    console.log('[GAME] DEBUG - window.onlineState:', window.onlineState);
    console.log('[GAME] DEBUG - window.onlineState.matchId:', window.onlineState?.matchId);
    
    if (window.battleState?.isOnline) {
      console.log('[GAME] 🌐 Modo online detectado - Enviando equipo al servidor');
      
      // Ejecutar de forma asíncrona
      (async () => {
        try {
          console.log('[GAME] 🔍 Iniciando carga de catálogo para envío...');
          
          // Cargar catálogo
          const allCardsData = await window.kvrcards.getAllCards();
          if (!allCardsData) {
            throw new Error('getAllCards devolvió null/undefined');
          }
          
          const cardsList = Array.isArray(allCardsData) ? allCardsData : (allCardsData.ok && Array.isArray(allCardsData.cards) ? allCardsData.cards : []);
          
          console.log('[GAME] ✅ Catálogo cargado:', cardsList.length, 'cartas');
          
          if (cardsList.length === 0) {
            throw new Error('El catálogo está vacío');
          }
          
          // Cargar traits disponibles
          const availableTraits = JSON.parse(localStorage.getItem('titles') || '[]');
          
          // Construir equipo completo desde catálogo
          const teamToSend = [];
          
          for (const cardUniqueId of mainTeam) {
            // Determinar cardId base
            let baseCardId = cardUniqueId;
            if (cardUniqueId.includes('_notrait_') || cardUniqueId.includes('_notrait')) {
              baseCardId = cardUniqueId.split('_notrait')[0];
            } else if (cardUniqueId.includes('trait_')) {
              const traitData = cardTraitsMap[cardUniqueId];
              baseCardId = traitData?.cardId || cardUniqueId;
            }
            
            // Buscar carta en catálogo
            const fullCard = cardsList.find(c => c.id === baseCardId);
            if (!fullCard) {
              console.error('[GAME] ❌ Carta no encontrada:', baseCardId, 'de uniqueId:', cardUniqueId);
              continue;
            }
            
            // Buscar trait
            const traitData = cardTraitsMap[cardUniqueId];
            const traitId = traitData?.traitId || traitData || null;
            
            // Construir objeto completo
            const cardData = {
              id: fullCard.id,
              uniqueId: cardUniqueId,
              name: fullCard.name,
              nombre: fullCard.nombre || fullCard.name,
              media: fullCard.media,
              stats: fullCard.stats || fullCard.parametros || [],
              imageUrl: fullCard.imageUrl || fullCard.imagen || fullCard.image || '',
              quality: fullCard.quality,
              calidad: fullCard.calidad || fullCard.quality,
              procedencia: fullCard.procedencia,
              owner: fullCard.owner,
              traitId: traitId
            };
            
            console.log('[GAME] ✅ Carta preparada:', cardData.name, '| imageUrl:', cardData.imageUrl?.substring(0, 60), '| stats:', cardData.stats?.length);
            teamToSend.push(cardData);
          }
          
          if (teamToSend.length === 0) {
            throw new Error('No se pudo construir ninguna carta del equipo');
          }
          
          // CRÍTICO: Añadir carta de reserva (8ª carta, index 7) al equipo
          const reserveSlotOnline = window.selectedTeam[7];
          if (reserveSlotOnline) {
            let reserveBaseId = reserveSlotOnline;
            if (reserveSlotOnline.includes('_notrait_') || reserveSlotOnline.includes('_notrait')) {
              reserveBaseId = reserveSlotOnline.split('_notrait')[0];
            } else if (reserveSlotOnline.includes('trait_')) {
              const traitData = cardTraitsMap[reserveSlotOnline];
              reserveBaseId = traitData?.cardId || reserveSlotOnline;
            }
            
            const reserveFullCard = cardsList.find(c => c.id === reserveBaseId);
            if (reserveFullCard) {
              const reserveTraitData = cardTraitsMap[reserveSlotOnline];
              const reserveTraitId = reserveTraitData?.traitId || reserveTraitData || null;
              
              const reserveCardData = {
                id: reserveFullCard.id,
                uniqueId: reserveSlotOnline,
                name: reserveFullCard.name,
                nombre: reserveFullCard.nombre || reserveFullCard.name,
                media: reserveFullCard.media,
                stats: reserveFullCard.stats || reserveFullCard.parametros || [],
                imageUrl: reserveFullCard.imageUrl || reserveFullCard.imagen || reserveFullCard.image || '',
                quality: reserveFullCard.quality,
                calidad: reserveFullCard.calidad || reserveFullCard.quality,
                procedencia: reserveFullCard.procedencia,
                owner: reserveFullCard.owner,
                traitId: reserveTraitId,
                isReserve: true  // Marcar como carta de reserva
              };
              
              teamToSend.push(reserveCardData);
              console.log('[GAME] ✅ Carta de reserva añadida:', reserveCardData.name, '(index 7)');
            } else {
              console.warn('[GAME] ⚠️ Carta de reserva no encontrada en catálogo:', reserveBaseId);
            }
          } else {
            console.log('[GAME] Sin carta de reserva seleccionada');
          }
          
          console.log('[GAME] ✅ Equipo completo:', teamToSend.length, 'cartas listas para envío');
          
          // Calcular buffs con el equipo preparado
          const teamBuffs = calculateBattleBuffs(teamToSend);
          console.log('[GAME] Buffs calculados:', teamBuffs);
          
          // Filtrar traits
          const traitsForServer = availableTraits.map(t => ({
            id: t.id,
            name: t.name,
            effect: t.effect
          }));
          
          // Enviar al servidor
          if (!window.onlineState?.socket) {
            throw new Error('No hay socket conectado');
          }

          if (window.onlineState.teamReadySent) {
            console.log('[GAME] ⚠️ player-ready ya fue enviado para este match. Ignorando clic duplicado.');
            return;
          }
          
          console.log('[GAME] 📤 Emitiendo player-ready con', teamToSend.length, 'cartas');
          window.onlineState.socket.emit('player-ready', {
            matchId: window.onlineState.matchId,
            team: teamToSend,
            powers: window.selectedTeamPowers || [],
            availableTraits: traitsForServer,
            buffs: teamBuffs
          });
          window.onlineState.teamReadySent = true;
          
          // Guardar localmente
          window.battleState.playerTeam = teamToSend;
          window.battleState.playerPowers = window.selectedTeamPowers || [];
          window.battleState.playerBuffs = teamBuffs;
          window.battleState.cardTraitsMap = cardTraitsMap;
          window.battleState.availableTraits = availableTraits;
          setBattlePrestigeEligibleCardIds();
          
          console.log('[GAME] ✅ Equipo enviado y guardado localmente');
          
        } catch (error) {
          console.error('[GAME] ❌ ERROR CRÍTICO al enviar equipo:', error);
          console.error('[GAME] ❌ Stack:', error.stack);
          alert('Error al enviar equipo al servidor. Por favor, recarga el juego.\n\nDetalles: ' + error.message);
        }
      })();
      
      return;
    }
    
    // Solo para batallas offline:
    // Obtener la carta de reserva con su uniqueId e instanceId correctos
    let reserveCard = window.teamBuilderCards.find(card => (card.uniqueId || card.id) === reserveSlot);
    if (!reserveCard) {
      // Fallback: buscar por id base
      const baseId = reserveSlot.includes('_notrait') ? reserveSlot.split('_notrait')[0] : 
                     reserveSlot.includes('trait_') ? (cardTraitsMap[reserveSlot]?.cardId || reserveSlot) : reserveSlot;
      const baseCard = window.teamBuilderCards.find(c => c.id === baseId && !c.hasTrait);
      if (baseCard) {
        reserveCard = {
          ...baseCard,
          uniqueId: reserveSlot,
          instanceId: reserveSlot.includes('trait_') ? reserveSlot : null
        };
      }
    }
    console.log('[GAME] Carta de reserva:', reserveCard);
    
    startBattle(teamCards, reserveCard);
  }
}

// Exponer funciones clave globalmente
window.saveTeam = saveTeam;
window.loadSavedTeam = loadSavedTeam;
window.sanitizeNormalTeamsFromInfiniteResidue = sanitizeNormalTeamsFromInfiniteResidue;

/* ========================================
   SISTEMA DE BATALLA
   ======================================== */

// Iniciar batalla
// Renderizar poderes en la pantalla de batalla
