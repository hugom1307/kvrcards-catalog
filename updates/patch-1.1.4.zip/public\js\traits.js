// ==================== SISTEMA DE TRAITS ====================

// Usar variable global window para evitar problemas de scope
if (typeof window.availableTraits === 'undefined') {
  window.availableTraits = [];
}
var availableTraits = window.availableTraits;

if (typeof window.traitsSystemInitialized === 'undefined') {
  window.traitsSystemInitialized = false;
}
var initTraitsSystem = typeof window !== 'undefined' ? window.initTraitsSystem : undefined;

// Carga directa y exclusiva desde el JSON remoto oficial en GitHub
async function fetchRemoteTraitsDirectly() {
  const urls = [
    `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/traits.json?t=${Date.now()}`,
    `https://hugom1307.github.io/kvrcards-catalog/traits.json?t=${Date.now()}`
  ];
  for (const url of urls) {
    try {
      const res = await fetch(url, { cache: 'no-store' });
      if (res.ok) {
        const json = await res.json();
        const list = Array.isArray(json) ? json : (Array.isArray(json?.traits) ? json.traits : []);
        if (list.length > 0) {
          console.log(`[TRAITS] ${list.length} rasgos cargados directamente del JSON remoto oficial (${url})`);
          return list;
        }
      }
    } catch (err) {
      console.warn(`[TRAITS] Error consultando ${url}:`, err);
    }
  }
  return [];
}
window.fetchRemoteTraitsDirectly = fetchRemoteTraitsDirectly;
window.fetchFallbackTraits = fetchRemoteTraitsDirectly;

async function initTraitsSystem() {
  if (window.traitsSystemInitialized) {
    console.log('[TRAITS] Sistema ya inicializado, omitiendo...');
    return;
  }

  console.log('[TRAITS] Inicializando sistema...');
  const traitsPanel = document.getElementById('traits-panel');
  const traitCardSlot = document.getElementById('trait-card-slot');
  const applyTraitBtn = document.getElementById('apply-trait-btn');
  
  // Cargar traits disponibles
  try {
    if (window.kvrcards && window.kvrcards.getAllTraits) {
      const loaded = await window.kvrcards.getAllTraits();
      availableTraits = Array.isArray(loaded) ? loaded : (Array.isArray(loaded?.traits) ? loaded.traits : []);
      if (availableTraits.length === 0) {
        availableTraits = await fetchFallbackTraits();
      }
      window.availableTraits = availableTraits;
      console.log('[TRAITS] Cargados:', availableTraits.length);
    } else {
      console.warn('[TRAITS] window.kvrcards.getAllTraits no disponible');
      availableTraits = await fetchFallbackTraits();
      window.availableTraits = availableTraits;
    }
  } catch (e) {
    console.error('[TRAITS] Error cargando traits:', e);
    availableTraits = await fetchFallbackTraits();
    window.availableTraits = availableTraits;
  }
  
  // Cargar cardTraitsMap desde inventario
  try {
    const inv = await window.kvrcards.getInventory();
    if (inv.ok && inv.cardTraits) {
      cardTraitsMap = inv.cardTraits;
      console.log('[TRAITS] cardTraitsMap cargado:', Object.keys(cardTraitsMap).length);
    }
  } catch (e) {
    console.error('[TRAITS] Error cargando cardTraitsMap:', e);
  }
  
  // Seleccionar carta
  if (traitCardSlot) {
    // Remover listeners anteriores para evitar duplicados
    const newSlot = traitCardSlot.cloneNode(true);
    if (traitCardSlot.parentNode) {
      traitCardSlot.parentNode.replaceChild(newSlot, traitCardSlot);
      
      newSlot.addEventListener('click', () => {
        if (isTraitRouletteSpinning) return;
        openCardSelectorForTraits();
      });
    }
  }
  
  // Aplicar trait
  if (applyTraitBtn) {
    // Remover listeners anteriores
    const newBtn = applyTraitBtn.cloneNode(true);
    if (applyTraitBtn.parentNode) {
      applyTraitBtn.parentNode.replaceChild(newBtn, applyTraitBtn);
      
      newBtn.addEventListener('click', () => {
        if (!selectedTraitCard || isTraitRouletteSpinning) return;
        startTraitRoulette();
      });
    }
  }

  // Listener para cerrar index de rasgos
  const closeIndexBtn = document.getElementById('close-traits-index-btn');
  if (closeIndexBtn) {
    closeIndexBtn.addEventListener('click', () => {
      const indexPanel = document.getElementById('traits-index-panel');
      if (indexPanel) indexPanel.style.display = 'none';
      const indexBtn = document.getElementById('traits-index-btn');
      if (indexBtn) indexBtn.classList.remove('active');
    });
  }

  window.traitsSystemInitialized = true;
  console.log('[TRAITS] Sistema inicializado correctamente');
}

async function renderTraitsPanel() {
  const balanceValue = document.getElementById('traits-balance-value');
  const applyBtn = document.getElementById('apply-trait-btn');
  
  // Actualizar saldo
  let traitsBalance = 0;
  try {
    if (window.kvrcards && typeof window.kvrcards.getWallet === 'function') {
      const wallet = await window.kvrcards.getWallet();
      traitsBalance = Number(wallet?.traits) || 0;
    }
  } catch (errWallet) {
    console.warn('[TRAITS] Error obteniendo saldo de traits:', errWallet);
  }
  if (balanceValue) balanceValue.textContent = traitsBalance;
  
  // Actualizar estado del botón
  if (applyBtn) {
    if (isTraitRouletteSpinning) {
      applyBtn.disabled = true;
      applyBtn.textContent = 'Girando...';
    } else if (traitsBalance < 1) {
      applyBtn.disabled = true;
      applyBtn.innerHTML = 'Sin Traits suficientes (1 <img src="./trait.png" class="currency-icon-small" style="vertical-align: middle;">)';
    } else if (!selectedTraitCard) {
      applyBtn.disabled = true;
      applyBtn.textContent = 'Selecciona una carta';
    } else {
      applyBtn.disabled = false;
      applyBtn.innerHTML = 'Aplicar Rasgo (1 <img src="./trait.png" class="currency-icon-small" style="vertical-align: middle;">)';
    }
  }
  
  // Actualizar slot de carta
  updateTraitCardSlot();

  // Si el panel de índice está visible, actualizarlo también
  const indexPanel = document.getElementById('traits-index-panel');
  if (indexPanel && indexPanel.style.display !== 'none' && typeof renderTraitsIndex === 'function') {
    renderTraitsIndex();
  }
}
window.renderTraitsPanel = renderTraitsPanel;
if (typeof globalThis !== 'undefined') globalThis.renderTraitsPanel = renderTraitsPanel;
window.initTraitsSystem = initTraitsSystem;
if (typeof globalThis !== 'undefined') globalThis.initTraitsSystem = initTraitsSystem;

function updateTraitCardSlot() {
  const slot = document.getElementById('trait-card-slot');
  const img = document.getElementById('trait-selected-card-img');
  const placeholder = slot.querySelector('.slot-placeholder');
  const currentTraitDisplay = document.getElementById('current-trait-display');
  const currentTraitIcon = document.getElementById('current-trait-icon');
  const currentTraitName = document.getElementById('current-trait-name');
  
  if (selectedTraitCard) {
    slot.classList.add('has-card');
    img.src = selectedTraitCard.imageUrl;
    img.style.display = 'block';
    placeholder.style.display = 'none';
    
    // Mostrar rasgo actual si tiene
    let currentTraitId = selectedTraitCard.currentTraitId;
    if (!currentTraitId && selectedTraitCard.uniqueId) {
      const traitEntry = cardTraitsMap[selectedTraitCard.uniqueId];
      currentTraitId = traitEntry?.traitId || (typeof traitEntry === 'string' ? traitEntry : null);
    }
    if (!currentTraitId && selectedTraitCard.id) {
      const entry = Object.values(cardTraitsMap).find(t => (t && (t.cardId === selectedTraitCard.id || t === selectedTraitCard.id)));
      currentTraitId = entry?.traitId || (typeof entry === 'string' ? entry : null);
    }

    if (currentTraitId && availableTraits && availableTraits.length > 0) {
      const trait = availableTraits.find(t => t.id === currentTraitId);
      if (trait) {
        currentTraitDisplay.style.display = 'flex';
        currentTraitIcon.src = trait.imageUrl;
        currentTraitName.textContent = trait.name;
      } else {
        currentTraitDisplay.style.display = 'none';
      }
    } else {
      currentTraitDisplay.style.display = 'flex';
      currentTraitIcon.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="%23fbbf24" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>';
      currentTraitName.textContent = 'Sin Rasgo';
    }
  } else {
    slot.classList.remove('has-card');
    img.style.display = 'none';
    placeholder.style.display = 'flex';
    currentTraitDisplay.style.display = 'none';
  }
}

function openCardSelectorForTraits() {
  const modal = document.getElementById('trait-card-selector-modal');
  const grid = document.getElementById('trait-card-selector-grid');
  const searchInput = document.getElementById('trait-card-search');
  const closeBtn = document.getElementById('close-trait-selector');
  
  if (!modal || !grid) return;
  
  // Cargar cartas del inventario
  loadTraitSelectorCards('');
  
  // Mostrar modal
  modal.style.display = 'flex';
  
  // Buscar
  searchInput.value = '';
  searchInput.oninput = () => {
    loadTraitSelectorCards(searchInput.value.toLowerCase());
  };
  
  // Cerrar
  closeBtn.onclick = () => {
    modal.style.display = 'none';
  };
  
  // Cerrar al hacer clic fuera
  modal.onclick = (e) => {
    if (e.target === modal) {
      modal.style.display = 'none';
    }
  };
}

async function loadTraitSelectorCards(searchQuery) {
  const grid = document.getElementById('trait-card-selector-grid');
  if (!grid) return;
  
  grid.innerHTML = '<div style="color:#9ca3af;text-align:center;padding:40px;">Cargando cartas...</div>';
  
  try {
    const [allCards, inv] = await Promise.all([
      window.kvrcards.getAllCards(),
      window.kvrcards.getInventory()
    ]);
    
    const ownedCardIds = inv.ok ? inv.cards : {};
    cardTraitsMap = inv.ok && inv.cardTraits ? inv.cardTraits : {};
    
    console.log('[TRAIT SELECTOR] cardTraitsMap:', cardTraitsMap);
    
    // Filtrar cartas que el usuario posee
    const userCards = allCards.filter(card => {
      const count = ownedCardIds[card.id] || 0;
      if (count <= 0) return false;
      if (searchQuery && !card.name.toLowerCase().includes(searchQuery)) return false;
      return true;
    });

    // Ordenar automáticamente por media descendente (más altas primero)
    userCards.sort((a, b) => {
      const mediaA = Number(a.media) || 0;
      const mediaB = Number(b.media) || 0;
      if (mediaB !== mediaA) return mediaB - mediaA;
      return String(a.name || '').localeCompare(String(b.name || ''));
    });
    
    if (userCards.length === 0) {
      grid.innerHTML = '<div style="color:#9ca3af;text-align:center;padding:40px;">No tienes cartas</div>';
      return;
    }
    
    grid.innerHTML = '';
    
    // NUEVO SISTEMA: Organizar traits por cardId
    const traitsByCard = {};
    for (const [instanceId, data] of Object.entries(cardTraitsMap)) {
      if (data && data.cardId && data.traitId) {
        if (!traitsByCard[data.cardId]) {
          traitsByCard[data.cardId] = [];
        }
        traitsByCard[data.cardId].push({ instanceId, traitId: data.traitId });
      } else if (typeof data === 'string') {
        let cardId = instanceId;
        if (instanceId.includes('_')) {
          const parts = instanceId.split('_');
          if (parts.length >= 3 && !isNaN(parts[parts.length - 1]) && !isNaN(parts[parts.length - 2])) {
            cardId = parts.slice(0, -2).join('_');
          }
        }
        if (!traitsByCard[cardId]) traitsByCard[cardId] = [];
        traitsByCard[cardId].push({ instanceId, traitId: data });
      }
    }
    
    const processedCards = [];
    
    for (const card of userCards) {
      const count = ownedCardIds[card.id] || 0;
      const traitsForThisCard = (traitsByCard[card.id] || []).slice(0, count);
      const countWithTrait = traitsForThisCard.length;
      const countWithoutTrait = Math.max(0, count - countWithTrait);
      
      console.log(`[TRAIT SELECTOR] Card ${card.name} (${card.id}) - Total: ${count}, With trait: ${countWithTrait}, Without: ${countWithoutTrait}`);
      
      // Añadir cada instancia con trait (pueden sobrescribirse)
      traitsForThisCard.forEach(({ instanceId, traitId }) => {
        processedCards.push({ 
          cardWithTrait: { ...card, instanceId: instanceId }, 
          traitId: traitId, 
          isUnique: true,
          hasExistingTrait: true
        });
      });
      
      // Añadir cartas sin trait
      if (countWithoutTrait > 0) {
        processedCards.push({ 
          cardWithoutTrait: card,
          traitId: null, 
          isUnique: false,
          count: countWithoutTrait,
          hasExistingTrait: false
        });
      }
    }

    // Ordenar processedCards estrictamente por media descendente
    processedCards.sort((a, b) => {
      const cardA = a.cardWithTrait || a.cardWithoutTrait;
      const cardB = b.cardWithTrait || b.cardWithoutTrait;
      const mediaA = Number(cardA?.media) || 0;
      const mediaB = Number(cardB?.media) || 0;
      if (mediaB !== mediaA) return mediaB - mediaA;
      return String(cardA?.name || '').localeCompare(String(cardB?.name || ''));
    });
    
    // Renderizar todas las cartas procesadas
    for (const item of processedCards) {
      const { cardWithTrait, cardWithoutTrait, traitId, isUnique, count, hasExistingTrait } = item;
      const card = cardWithTrait || cardWithoutTrait; // Usar el objeto correcto
      
      const div = document.createElement('div');
      div.className = 'trait-selector-card';
      if (isUnique) div.classList.add('has-trait');
      
      const img = document.createElement('img');
      img.src = card.imageUrl || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="140"><rect fill="%23374151" width="100%" height="100%"/></svg>';
      img.alt = card.name;
      
      const name = document.createElement('div');
      name.className = 'card-name';
      name.textContent = count && count > 1 ? `${card.name} x${count}` : card.name;
      
      // Mostrar indicador de trait si tiene
      if (traitId && availableTraits && availableTraits.length > 0) {
        const trait = availableTraits.find(t => t.id === traitId);
        if (trait) {
          const indicator = document.createElement('div');
          indicator.className = 'trait-indicator';
          const traitImg = document.createElement('img');
          traitImg.src = trait.imageUrl;
          traitImg.alt = trait.name;
          traitImg.title = trait.name;
          indicator.appendChild(traitImg);
          div.appendChild(indicator);
        }
      }
      
      div.appendChild(img);
      div.appendChild(name);
      
      // Al hacer clic, seleccionar carta
      div.onclick = () => {
        const selectedCard = hasExistingTrait ? cardWithTrait : cardWithoutTrait;
        console.log('[TRAIT SELECTOR CLICK] hasExistingTrait:', hasExistingTrait);
        console.log('[TRAIT SELECTOR CLICK] Selected card:', selectedCard);
        console.log('[TRAIT SELECTOR CLICK] Has instanceId:', selectedCard?.instanceId);
        console.log('[TRAIT SELECTOR CLICK] Trait ID to pass:', traitId);
        selectCardForTrait(selectedCard, traitId);
      };
      
      grid.appendChild(div);
    }
  } catch (e) {
    console.error('[TRAITS] Error cargando cartas:', e);
    grid.innerHTML = '<div style="color:#ef4444;text-align:center;padding:40px;">Error al cargar cartas</div>';
  }
}

function selectCardForTrait(card, existingTraitId) {
  let targetId;
  let createNew = false;
  
  console.log('[SELECT CARD] Received card:', card);
  console.log('[SELECT CARD] card.instanceId:', card?.instanceId);
  console.log('[SELECT CARD] existingTraitId:', existingTraitId);
  
  if (existingTraitId && card && card.instanceId) {
    // Carta con trait existente - sobrescribir usando el mismo instanceId
    targetId = card.instanceId;
    createNew = false;
    console.log('[TRAITS] Overwriting trait on existing instance:', targetId);
  } else {
    // Carta sin trait - enviar ID BASE al servidor con flag createNew=true
    // El servidor creará un NUEVO instanceId
    targetId = card.id;
    createNew = true;
    console.log('[TRAITS] Creating NEW trait instance for card:', targetId);
  }
  
  selectedTraitCard = {
    ...card,
    uniqueId: targetId, // Mantener compatibilidad con código existente
    createNew: createNew,
    currentTraitId: existingTraitId || null
  };
  
  console.log('[TRAITS] Selected card for trait:', selectedTraitCard);
  
  // Cerrar modal
  const modal = document.getElementById('trait-card-selector-modal');
  if (modal) modal.style.display = 'none';
  
  // Actualizar UI
  updateTraitCardSlot();
  renderTraitsPanel();
}

async function startTraitRoulette() {
  if (isTraitRouletteSpinning || !selectedTraitCard) return;
  
  // Validación de seguridad
  if (!availableTraits || availableTraits.length === 0) {
    alert('No hay rasgos disponibles en el catálogo.');
    return;
  }

  const rouletteContainer = document.getElementById('traits-roulette-container');
  const rouletteStrip = document.getElementById('traits-roulette-strip');
  const resultDiv = document.getElementById('trait-result');
  
  // Validar que los elementos DOM existen
  if (!rouletteContainer || !rouletteStrip || !resultDiv) {
    console.error('[TRAITS] Elementos de ruleta no encontrados');
    alert('Error: Elementos de la ruleta no están listos. Intenta abrir el panel de traits primero.');
    return;
  }
  
  try {
    // Cancelar cualquier timeout anterior
    if (activeRouletteTimeout) {
      clearTimeout(activeRouletteTimeout);
      activeRouletteTimeout = null;
    }
    if (activeHideTimeout) {
      clearTimeout(activeHideTimeout);
      activeHideTimeout = null;
    }
    
    isTraitRouletteSpinning = true;
    // Actualizar UI inmediatamente para deshabilitar el botón
    await renderTraitsPanel();
    
    rouletteContainer.style.display = 'block';
    resultDiv.style.display = 'none';
    
    // Generar items para la ruleta ponderada según las probabilidades calculadas
    const traitsWithProbs = calculateTraitProbabilities(availableTraits);
    const winnerTrait = rollWeightedTrait(traitsWithProbs) || availableTraits[Math.floor(Math.random() * availableTraits.length)];
    
    // Construir tira de ruleta
    rouletteStrip.innerHTML = '';
    const totalItems = 50;
    const winnerPosition = 20;
    
    for (let i = 0; i < totalItems; i++) {
      let trait;
      if (i === winnerPosition) {
        trait = winnerTrait;
      } else {
        trait = rollWeightedTrait(traitsWithProbs) || availableTraits[Math.floor(Math.random() * availableTraits.length)];
      }
      
      const item = document.createElement('div');
      item.className = 'roulette-item';
      const img = document.createElement('img');
      img.src = trait.imageUrl;
      img.onerror = () => { img.src = './trait.png'; };
      item.appendChild(img);
      rouletteStrip.appendChild(item);
    }
    
    const itemWidth = 100;
    const realWidth = rouletteContainer.offsetWidth || Math.min(600, window.innerWidth - 40);
    const finalPosition = -(winnerPosition * itemWidth) + (realWidth / 2) - (itemWidth / 2);
    
    // Resetear posición
    rouletteStrip.style.transition = 'none';
    rouletteStrip.style.transform = 'translateX(0)';
    
    // Forzar reflow
    rouletteStrip.offsetHeight;
    
    // Reproducir sonido de ruleta
    const traitSpinSound = new Audio('music/sfx/traitspin.wav');
    traitSpinSound.volume = 0.5;
    traitSpinSound.play().catch(err => console.log('Error reproduciendo sonido:', err));
    
    // Iniciar animación
    requestAnimationFrame(() => {
      rouletteStrip.style.transition = 'transform 5s linear';
      rouletteStrip.style.transform = `translateX(${finalPosition}px)`;
    });
    
    // Esperar a que termine
    activeRouletteTimeout = setTimeout(async () => {
      // Aplicar trait en backend
      try {
        const result = await window.kvrcards.assignTrait(selectedTraitCard.uniqueId, winnerTrait.id, selectedTraitCard.createNew);
        if (result.ok) {
          console.log('[TRAITS] Trait assigned successfully. createNew:', selectedTraitCard.createNew, 'instanceId:', result.newUniqueId);
          
          // Actualizar selectedTraitCard inmediatamente con la nueva instancia y createNew=false
          if (selectedTraitCard) {
            selectedTraitCard.uniqueId = result.newUniqueId;
            selectedTraitCard.instanceId = result.newUniqueId;
            selectedTraitCard.createNew = false;
            selectedTraitCard.currentTraitId = winnerTrait.id;
          }
          
          // Recargar inventario completo desde el servidor
          const inv = await window.kvrcards.getInventory();
          if (inv) {
            userInv = inv;
            ownedCardIds = inv.cards || {};
            cardTraitsMap = inv.cardTraits || {};
            
            console.log('[TRAITS] Inventory reloaded. Total traits:', Object.keys(cardTraitsMap).length);
            
            // Actualizar colección SIEMPRE (incluso si no está visible)
            console.log('[TRAITS] Updating collection view...');
            if (typeof renderCollection === 'function') await renderCollection();
            console.log('[TRAITS] Collection updated!');
          }
          
          // Actualizar UI del panel de traits
          updateTraitCardSlot();
          await renderTraitsPanel();
          
          // Mostrar resultado
          showTraitResult(winnerTrait);
        } else {
          alert('Error aplicando rasgo: ' + result.error);
          isTraitRouletteSpinning = false;
          rouletteContainer.style.display = 'none';
        }
      } catch (e) {
        console.error('Error:', e);
        alert('Error al procesar el rasgo');
        isTraitRouletteSpinning = false;
        rouletteContainer.style.display = 'none';
      }
      
      // Nota: isTraitRouletteSpinning se resetea en el callback del resultado o aquí si falló
      if (!isTraitRouletteSpinning) return; // Si ya se reseteó por error, salir

      isTraitRouletteSpinning = false;
      activeRouletteTimeout = null;
      // Actualizar UI para rehabilitar el botón
      await renderTraitsPanel();
      
      // Ocultar ruleta después de un tiempo
      activeHideTimeout = setTimeout(() => {
        rouletteContainer.style.display = 'none';
        // Limpiar la tira de ruleta para la próxima vez
        rouletteStrip.innerHTML = '';
        rouletteStrip.style.transition = 'none';
        rouletteStrip.style.transform = 'translateX(0)';
        activeHideTimeout = null;
      }, 3000);
      
    }, 5000);

  } catch (err) {
    console.error('Error iniciando ruleta:', err);
    isTraitRouletteSpinning = false;
    activeRouletteTimeout = null;
    activeHideTimeout = null;
    rouletteContainer.style.display = 'none';
    rouletteStrip.innerHTML = '';
    rouletteStrip.style.transition = 'none';
    rouletteStrip.style.transform = 'translateX(0)';
    await renderTraitsPanel();
    alert('Error iniciando la animación de la ruleta.');
  }
}

function showTraitResult(trait) {
  const resultDiv = document.getElementById('trait-result');
  const icon = document.getElementById('result-trait-icon');
  const name = document.getElementById('result-trait-name');
  const desc = document.getElementById('result-trait-desc');
  
  icon.src = trait.imageUrl;
  name.textContent = trait.name;
  desc.textContent = trait.description;
  
  resultDiv.style.display = 'block';
  
  // Actualizar colección cuando se cierre el resultado
  const closeResult = () => {
    resultDiv.style.display = 'none';
    // Refresh colección si está visible
    const collectionSection = document.getElementById('collection-section');
    if (collectionSection && collectionSection.style.display !== 'none') {
      renderCollection();
    }
    resultDiv.removeEventListener('click', closeResult);
  };
  
  // Click en cualquier parte del resultado para cerrar
  resultDiv.addEventListener('click', closeResult);
  
  // Auto-cerrar después de 3 segundos
  setTimeout(closeResult, 3000);
}

// ==================== ÍNDICE Y PROBABILIDADES DE RASGOS ====================

/**
 * Calcula la probabilidad de cada rasgo según traits.json.
 * Si un rasgo tiene 'probability' (o 'probabilidad'/'chance') manual, se respeta ese valor.
 * El porcentaje restante (100% - suma de manuales) se reparte equitativamente entre los demás.
 */
function calculateTraitProbabilities(traits) {
  if (!Array.isArray(traits) || traits.length === 0) return [];
  const N = traits.length;

  const RARITY_DEFAULT_WEIGHTS = {
    common: 50,
    rare: 25,
    epic: 10,
    legendary: 3,
    mythic: 1
  };

  const getRarityWeight = (t) => {
    const r = String(t.rarity || 'common').toLowerCase().trim();
    return RARITY_DEFAULT_WEIGHTS[r] !== undefined ? RARITY_DEFAULT_WEIGHTS[r] : 10;
  };

  const parsed = traits.map(t => {
    let raw = t.probability ?? t.probabilidad ?? t.chance ?? t.prob ?? null;
    let val = null;
    if (raw !== null && raw !== undefined && raw !== '') {
      if (typeof raw === 'string') raw = raw.replace('%', '').trim();
      const num = parseFloat(raw);
      if (!isNaN(num) && num >= 0) {
        val = num;
      }
    }
    return { trait: t, manualProb: val, weight: getRarityWeight(t) };
  });

  // Detectar si se expresaron como decimales menores o iguales a 1 (ej: 0.05 en vez de 5)
  const manualValues = parsed.filter(p => p.manualProb !== null).map(p => p.manualProb);
  const isDecimal = manualValues.length > 0 &&
                    manualValues.every(v => v <= 1) &&
                    manualValues.reduce((a, b) => a + b, 0) <= 1 &&
                    manualValues.some(v => v < 0.2);

  if (isDecimal) {
    parsed.forEach(p => {
      if (p.manualProb !== null) p.manualProb *= 100;
    });
  }

  const manualCount = parsed.filter(p => p.manualProb !== null).length;
  const autoCount = N - manualCount;
  const manualSum = parsed.filter(p => p.manualProb !== null).reduce((sum, p) => sum + p.manualProb, 0);

  let result = [];

  if (manualCount === 0) {
    // Ninguno tiene probabilidad manual: repartir segun peso de rareza
    const totalWeight = parsed.reduce((sum, p) => sum + p.weight, 0) || 1;
    result = parsed.map(p => ({
      ...p.trait,
      calculatedProbability: (p.weight / totalWeight) * 100,
      isManual: false
    }));
  } else if (autoCount === 0) {
    // Todos tienen probabilidad manual: normalizar a 100%
    const scale = manualSum > 0 ? (100 / manualSum) : 1;
    result = parsed.map(p => ({
      ...p.trait,
      calculatedProbability: p.manualProb * scale,
      isManual: true
    }));
  } else {
    if (manualSum < 100) {
      // Repartir proporcionalmente el resto entre los rasgos automaticos segun su rareza
      const remaining = 100 - manualSum;
      const autoTotalWeight = parsed.filter(p => p.manualProb === null).reduce((sum, p) => sum + p.weight, 0) || 1;
      result = parsed.map(p => {
        if (p.manualProb !== null) {
          return { ...p.trait, calculatedProbability: p.manualProb, isManual: true };
        } else {
          const autoProb = remaining * (p.weight / autoTotalWeight);
          return { ...p.trait, calculatedProbability: autoProb, isManual: false };
        }
      });
    } else {
      // Caso limite: manual >= 100, asignar piso pequeño a los automaticos y normalizar
      const autoFloor = 0.5;
      const totalWeight = manualSum + (autoFloor * autoCount);
      const scale = 100 / totalWeight;
      result = parsed.map(p => {
        const raw = p.manualProb !== null ? p.manualProb : autoFloor;
        return {
          ...p.trait,
          calculatedProbability: raw * scale,
          isManual: p.manualProb !== null
        };
      });
    }
  }

  return result;
}
window.calculateTraitProbabilities = calculateTraitProbabilities;

/**
 * Selecciona un rasgo de forma ponderada según su probabilidad calculada
 */
function rollWeightedTrait(traitsWithProbs) {
  if (!Array.isArray(traitsWithProbs) || traitsWithProbs.length === 0) return null;
  const rand = Math.random() * 100;
  let cumulative = 0;
  for (const t of traitsWithProbs) {
    cumulative += t.calculatedProbability;
    if (rand <= cumulative) {
      return t;
    }
  }
  return traitsWithProbs[traitsWithProbs.length - 1];
}
window.rollWeightedTrait = rollWeightedTrait;

/**
 * Formato amigable de porcentaje
 */
function formatProbability(prob) {
  if (typeof prob !== 'number' || isNaN(prob)) return '0%';
  if (prob >= 10) {
    return (prob % 1 === 0 ? prob.toFixed(0) : prob.toFixed(1)) + '%';
  } else if (prob >= 1) {
    return (prob % 1 === 0 ? prob.toFixed(0) : prob.toFixed(2)) + '%';
  } else {
    return prob.toFixed(2) + '%';
  }
}
window.formatTraitProbability = formatProbability;

/**
 * Muestra u oculta el panel de Index de Rasgos desplegado a la izquierda
 */
async function toggleTraitsIndex(e) {
  if (e && typeof e.stopPropagation === 'function') {
    e.stopPropagation();
  }
  const indexPanel = document.getElementById('traits-index-panel');
  const indexBtn = document.getElementById('traits-index-btn');
  if (!indexPanel) return;

  const isHidden = indexPanel.style.display === 'none' || indexPanel.style.display === '';
  if (isHidden) {
    indexPanel.style.display = 'flex';
    if (indexBtn) indexBtn.classList.add('active');
    await renderTraitsIndex();
  } else {
    indexPanel.style.display = 'none';
    if (indexBtn) indexBtn.classList.remove('active');
  }
}
window.toggleTraitsIndex = toggleTraitsIndex;

/**
 * Renderiza la tabla de rasgos con su probabilidad en grande
 */
async function renderTraitsIndex() {
  const tbody = document.getElementById('traits-index-tbody');
  if (!tbody) return;

  tbody.innerHTML = '<tr><td colspan="3" style="text-align:center; padding: 24px; color:#fbbf24;">Cargando rasgos desde el servidor remoto...</td></tr>';

  // 1. Cargar directamente desde el JSON remoto oficial en GitHub
  const remoteList = await fetchRemoteTraitsDirectly();
  if (Array.isArray(remoteList) && remoteList.length > 0) {
    window.availableTraits = remoteList;
    availableTraits = remoteList;
  } else if (window.kvrcards && typeof window.kvrcards.getAllTraits === 'function') {
    try {
      const loaded = await window.kvrcards.getAllTraits();
      const arr = Array.isArray(loaded) ? loaded : (Array.isArray(loaded?.traits) ? loaded.traits : []);
      if (arr.length > 0) {
        window.availableTraits = arr;
        availableTraits = arr;
      }
    } catch (e) {
      console.error('[TRAITS] Error cargando traits para index:', e);
    }
  }

  const traits = window.availableTraits || availableTraits || [];

  if (!traits || traits.length === 0) {
    tbody.innerHTML = '<tr><td colspan="3" style="text-align:center; padding: 24px; color:#ef4444;">No se pudieron cargar los rasgos del servidor remoto.</td></tr>';
    return;
  }

  const traitsWithProbs = calculateTraitProbabilities(availableTraits);
  const escapeFn = typeof window.escapeHtml === 'function' ? window.escapeHtml : (s => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'));

  tbody.innerHTML = '';
  const fragment = document.createDocumentFragment();

  traitsWithProbs.forEach(t => {
    const tr = document.createElement('tr');
    tr.className = 'traits-index-row';

    const probFormatted = formatProbability(t.calculatedProbability);
    const traitImg = t.imageUrl || t.image || t.imagen || t.icon || t.icono || './trait.png';
    const traitDesc = t.description || t.descripcion || t.desc || 'Sin descripción';

    tr.innerHTML = `
      <td class="traits-index-cell-name">
        <div class="traits-index-item-box">
          <img src="${traitImg}" class="traits-index-icon" onerror="this.src='./trait.png'" alt="${escapeFn(t.name || t.id)}">
          <div class="traits-index-name-wrap">
            <span class="traits-index-name">${escapeFn(t.name || t.id)}</span>
          </div>
        </div>
      </td>
      <td class="traits-index-cell-desc">
        <span class="traits-index-desc">${escapeFn(traitDesc)}</span>
      </td>
      <td class="traits-index-cell-prob">
        <span class="traits-prob-large">${probFormatted}</span>
      </td>
    `;
    fragment.appendChild(tr);
  });

  tbody.appendChild(fragment);
}
window.renderTraitsIndex = renderTraitsIndex;

console.log('🟢🟢🟢 CHECKPOINT 1: Llegando a línea 16023 - Antes de definir sistema online');

