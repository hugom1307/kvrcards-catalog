// KVRCards - MODO DE JUEGO: SOBRE LEGENDARIO (AUDIO & VISUAL POLISHED)

(function() {
  // Parámetros de estado
  let attemptsLeft = 5;
  let currentRarityIndex = 0; // 0: Común -> 4: Legendario
  let isProcessing = false;
  
  const rarities = ['Común', 'Poco Común', 'Raro', 'Épico', 'Legendario'];
  const rarityTextClasses = ['rarity-text-common', 'rarity-text-uncommon', 'rarity-text-rare', 'rarity-text-epic', 'rarity-text-legendary'];
  const packClasses = ['rarity-common', 'rarity-uncommon', 'rarity-rare', 'rarity-epic', 'rarity-legendary'];
  const particleColors = ['#94a3b8', '#4caf50', '#2196f3', '#a855f7', '#facc15'];

  // Audio Context y Sintetizador
  let audioCtx = null;

  function getAudioContext() {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
    return audioCtx;
  }

  function playFailSound() {
    try {
      const ctx = getAudioContext();
      const now = ctx.currentTime;
      
      // Thud de baja frecuencia
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sawtooth';
      osc1.frequency.setValueAtTime(180, now);
      osc1.frequency.linearRampToValueAtTime(30, now + 0.35);
      gain1.gain.setValueAtTime(0.35, now);
      gain1.gain.linearRampToValueAtTime(0.001, now + 0.4);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      
      // Ruptura de cristal/glitch (frecuencias altas desordenadas)
      for (let i = 0; i < 5; i++) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(700 + Math.random() * 2200, now + i * 0.035);
        osc.frequency.linearRampToValueAtTime(120, now + 0.12 + i * 0.035);
        
        gain.gain.setValueAtTime(0.14, now + i * 0.035);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18 + i * 0.035);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.start(now + i * 0.035);
        osc.stop(now + 0.28);
      }
      
      osc1.start(now);
      osc1.stop(now + 0.45);
    } catch (e) {
      console.error('Audio fail error:', e);
    }
  }

  function playUpgradeSound(step) {
    try {
      const ctx = getAudioContext();
      const now = ctx.currentTime;
      const frequencies = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99]; // C4, E4, G4, C5, E5, G5
      const baseFreq = frequencies[step] || 440;
      
      // Tono fundamental sine
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(baseFreq, now);
      osc1.frequency.exponentialRampToValueAtTime(baseFreq * 2.2, now + 0.45);
      gain1.gain.setValueAtTime(0.28, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.55);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      
      // Tono armónico triangle
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(baseFreq * 1.5, now + 0.04);
      osc2.frequency.exponentialRampToValueAtTime(baseFreq * 3, now + 0.45);
      gain2.gain.setValueAtTime(0.15, now + 0.04);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      
      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.6);
      osc2.stop(now + 0.6);
    } catch (e) {
      console.error('Audio upgrade error:', e);
    }
  }

  function playRareSound() {
    try {
      const ctx = getAudioContext();
      const now = ctx.currentTime;
      const frequencies = [523.25, 659.25, 783.99, 1046.50, 1318.51]; // Acorde brillante C5, E5, G5, C6, E6
      
      frequencies.forEach((freq, index) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        osc.type = index % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now + index * 0.03);
        osc.frequency.exponentialRampToValueAtTime(freq * 1.5, now + 0.5);
        
        gain.gain.setValueAtTime(0.16, now + index * 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.75);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.start(now + index * 0.03);
        osc.stop(now + 0.95);
      });
    } catch (e) {
      console.error('Audio rare error:', e);
    }
  }

  function playNeutralSound() {
    try {
      const ctx = getAudioContext();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(130, now);
      osc.frequency.exponentialRampToValueAtTime(45, now + 0.08);
      
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start(now);
      osc.stop(now + 0.1);
    } catch (e) {
      console.error('Audio neutral error:', e);
    }
  }

  function playJackpotSound() {
    try {
      const ctx = getAudioContext();
      const now = ctx.currentTime;
      
      // 1. Impacto de subgraves
      const bass = ctx.createOscillator();
      const bassGain = ctx.createGain();
      bass.type = 'triangle';
      bass.frequency.setValueAtTime(80, now);
      bass.frequency.linearRampToValueAtTime(30, now + 0.6);
      bassGain.gain.setValueAtTime(0.5, now);
      bassGain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
      bass.connect(bassGain);
      bassGain.connect(ctx.destination);
      bass.start(now);
      bass.stop(now + 0.7);
      
      // 2. Arpegio ascendente rápido de Jackpot
      const notes = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99, 1046.50, 1318.51, 1567.98]; // C4 -> G6
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);
        osc.frequency.exponentialRampToValueAtTime(freq * 1.15, now + idx * 0.08 + 0.35);
        
        gain.gain.setValueAtTime(0.32, now + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.45);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.55);
      });
      
      // 3. Shimmer trémolo al final (brillo sostenido)
      const vibratoOsc = ctx.createOscillator();
      const vibratoGain = ctx.createGain();
      vibratoOsc.type = 'sine';
      vibratoOsc.frequency.setValueAtTime(1046.50, now + 0.6); // C6
      vibratoOsc.frequency.linearRampToValueAtTime(1065, now + 1.3);
      vibratoGain.gain.setValueAtTime(0.22, now + 0.6);
      vibratoGain.gain.exponentialRampToValueAtTime(0.001, now + 1.6);
      vibratoOsc.connect(vibratoGain);
      vibratoGain.connect(ctx.destination);
      vibratoOsc.start(now + 0.6);
      vibratoOsc.stop(now + 1.7);
      
    } catch (e) {
      console.error('Audio jackpot error:', e);
    }
  }

  // Flash suave de pantalla en mejoras
  function triggerFlash(color) {
    const modal = document.querySelector('.legendary-pack-modal-content');
    if (!modal) return;
    
    const flash = document.createElement('div');
    flash.style.position = 'absolute';
    flash.style.inset = '0';
    flash.style.backgroundColor = color;
    flash.style.opacity = '0.35';
    flash.style.pointerEvents = 'none';
    flash.style.zIndex = '9999';
    flash.style.borderRadius = '20px';
    flash.style.transition = 'opacity 0.2s ease-out';
    
    modal.appendChild(flash);
    flash.offsetHeight; // Forzar reflujo
    
    flash.style.opacity = '0';
    setTimeout(() => flash.remove(), 200);
  }

  // Motor de Partículas en Canvas (con floaters sutiles)
  let particles = [];
  let animationFrameId = null;

  function startParticleAnimation() {
    const canvas = document.getElementById('legendary-pack-particles-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    
    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width;
      canvas.height = rect.height;
    };
    resizeCanvas();
    
    particles = [];
    
    function animate() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Partículas flotantes sutiles hacia arriba
      if (Math.random() < 0.15 && particles.length < 80) {
        particles.push({
          x: Math.random() * canvas.width,
          y: canvas.height + 10,
          vx: (Math.random() - 0.5) * 0.6,
          vy: -0.6 - Math.random() * 1.2,
          gravity: 0,
          size: 1.5 + Math.random() * 3,
          color: particleColors[currentRarityIndex],
          alpha: 0.6,
          decay: 0.003 + Math.random() * 0.004
        });
      }
      
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.vy += p.gravity;
        p.alpha -= p.decay;
        p.size *= 0.985;
        
        if (p.alpha <= 0 || p.size <= 0.5) {
          particles.splice(i, 1);
          continue;
        }
        
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.shadowBlur = 10;
        ctx.shadowColor = p.color;
        ctx.fill();
        ctx.restore();
      }
      
      animationFrameId = requestAnimationFrame(animate);
    }
    
    if (animationFrameId) cancelAnimationFrame(animationFrameId);
    animate();
  }

  function spawnParticles(color) {
    const canvas = document.getElementById('legendary-pack-particles-canvas');
    if (!canvas) return;
    
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    
    for (let i = 0; i < 50; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 2.5 + Math.random() * 6.5;
      particles.push({
        x: centerX,
        y: centerY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        gravity: 0.08,
        size: 3.5 + Math.random() * 6.5,
        color: color,
        alpha: 1,
        decay: 0.012 + Math.random() * 0.02
      });
    }
  }

  // Helper local para obtener URL base de la API de Gambling
  async function getGamblingBaseUrl() {
    if (window.kvrcards && typeof window.kvrcards.getInventoryServerInfo === 'function') {
      try {
        const serverInfo = await window.kvrcards.getInventoryServerInfo();
        if (serverInfo && serverInfo.ok && serverInfo.effectiveBaseUrl) {
          let base = serverInfo.effectiveBaseUrl;
          if (base.endsWith('/')) base = base.slice(0, -1);
          return base;
        }
        if (serverInfo && serverInfo.baseUrl) {
          let base = serverInfo.baseUrl;
          if (base.endsWith('/')) base = base.slice(0, -1);
          return base;
        }
      } catch (e) {
        console.error('[GAMBLING] Error al obtener getInventoryServerInfo:', e);
      }
    }
    if (window.kvrcards) {
      return 'http://localhost:4321';
    }
    return '';
  }

  // Cargar inventario del usuario y actualizar contador
  async function refreshGoldPackCount() {
    if (window.kvrcards && typeof window.kvrcards.getInventory === 'function') {
      try {
        const inv = await window.kvrcards.getInventory();
        const goldCount = inv.packs?.['sobre_oro'] || 0;
        
        const countSpan = document.getElementById('legendary-pack-gold-count');
        const startBtn = document.getElementById('legendary-pack-start-btn');
        const slotEl = document.getElementById('legendary-pack-slot');
        
        if (countSpan) countSpan.textContent = goldCount;
        
        if (goldCount <= 0) {
          if (startBtn) startBtn.disabled = true;
          if (slotEl) {
            slotEl.classList.remove('has-pack');
            slotEl.innerHTML = `
              <div class="legendary-pack-placeholder" style="width: 100%; height: 100%; padding: 10px; box-sizing: border-box; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                <img src="https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/sobre_oro.png" alt="Sobre Oro" style="width: auto; height: 80%; object-fit: contain; border-radius: 8px; filter: grayscale(1); opacity: 0.35;">
                <span class="placeholder-text" style="color: #64748b; font-size: 13px; margin-top: 8px;">No tienes sobres de oro</span>
              </div>
            `;
          }
        } else {
          if (startBtn) startBtn.disabled = false;
          if (slotEl) {
            slotEl.classList.add('has-pack');
            slotEl.innerHTML = `
              <div class="legendary-pack-placeholder" style="width: 100%; height: 100%; padding: 10px; box-sizing: border-box; display: flex; flex-direction: column; align-items: center; justify-content: center;">
                <img src="https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/sobre_oro.png" alt="Sobre Oro" style="width: auto; height: 80%; object-fit: contain; border-radius: 8px; filter: drop-shadow(0 0 10px rgba(251,191,36,0.3));">
                <span class="placeholder-text" style="color: #fbbf24; font-weight: bold; font-size: 13px; margin-top: 8px;">Sobre de Oro listo</span>
              </div>
            `;
          }
        }
      } catch (e) {
        console.error('[GAMBLING] Error cargando sobres:', e);
      }
    }
  }

  // Cambiar vista del modal
  function showScreen(screenId) {
    document.querySelectorAll('.legendary-pack-screen').forEach(scr => {
      scr.style.display = 'none';
    });
    const target = document.getElementById(screenId);
    if (target) target.style.display = 'flex';
  }

  // Abrir Modal
  window.openLegendaryPackModal = async function() {
    const modal = document.getElementById('gambling-legendary-pack-modal');
    if (!modal) return;
    
    // Ocultar panel de Gambling principal
    const gamblingPanel = document.getElementById('gambling-panel');
    if (gamblingPanel) gamblingPanel.style.display = 'none';
    
    modal.classList.add('active');
    await refreshGoldPackCount();
    showScreen('legendary-pack-setup-screen');
  };

  // Cerrar Modal
  window.closeLegendaryPackModal = function() {
    if (isProcessing) return; // Impedir cerrar a mitad de apuesta
    const modal = document.getElementById('gambling-legendary-pack-modal');
    if (modal) modal.classList.remove('active');
    
    // Volver a abrir panel de Gambling principal
    const gamblingPanel = document.getElementById('gambling-panel');
    if (gamblingPanel) gamblingPanel.style.display = 'block';
    
    // Refrescar UI del juego principal al cerrar el modal para reflejar cambios
    if (typeof renderOwnedPacks === 'function') {
      renderOwnedPacks().catch(e => console.error('[GAMBLING] Error al refrescar sobres al cerrar modal:', e));
    }
    if (typeof renderCollection === 'function') {
      renderCollection().catch(e => console.error('[GAMBLING] Error al refrescar colección al cerrar modal:', e));
    }
    if (typeof renderWallet === 'function') {
      renderWallet().catch(e => console.error('[GAMBLING] Error al refrescar cartera al cerrar modal:', e));
    }
  };

  // Iniciar la Apuesta
  window.startLegendaryPackGame = async function() {
    if (isProcessing) return;
    isProcessing = true;
    
    try {
      if (!window.kvrcards || typeof window.kvrcards.deductPack !== 'function') {
        throw new Error('Función window.kvrcards.deductPack no disponible');
      }
      
      const res = await window.kvrcards.deductPack('sobre_oro');
      if (res.error) {
        alert(res.error);
        isProcessing = false;
        return;
      }
      
      // Deducción exitosa
      attemptsLeft = 5;
      currentRarityIndex = 0; // Común
      
      // Refrescar UI del juego principal inmediatamente para borrar el sobre consumido de la vista
      if (typeof renderOwnedPacks === 'function') {
        renderOwnedPacks().catch(e => console.error('[GAMBLING] Error al refrescar sobres al iniciar juego:', e));
      }
      if (typeof renderWallet === 'function') {
        renderWallet().catch(e => console.error('[GAMBLING] Error al refrescar cartera al iniciar juego:', e));
      }
      
      // Actualizar UI de juego
      updateRarityDisplay();
      updateAttemptsDisplay();
      
      // Resetear visuales del sobre
      const interactivePack = document.getElementById('legendary-pack-interactive');
      if (interactivePack) {
        interactivePack.className = 'legendary-pack-3d rarity-common';
        interactivePack.style.pointerEvents = 'auto';
        
        const frontFace = interactivePack.querySelector('.pack-front');
        if (frontFace) {
          frontFace.className = 'pack-face pack-front rarity-common';
        }
      }
      
      showScreen('legendary-pack-game-screen');
      startParticleAnimation();
      
      isProcessing = false;
    } catch (e) {
      console.error('[GAMBLING] Error al iniciar apuesta:', e);
      alert('Error al consumir sobre de oro: ' + String(e));
      isProcessing = false;
    }
  };

  // Actualizar vidas/intentos en UI
  function updateAttemptsDisplay() {
    const wrapper = document.getElementById('legendary-pack-attempts-wrapper');
    if (!wrapper) return;
    
    wrapper.innerHTML = '';
    for (let i = 0; i < 5; i++) {
      const ball = document.createElement('div');
      ball.className = 'attempt-ball';
      if (i >= attemptsLeft) {
        ball.classList.add('spent');
      }
      wrapper.appendChild(ball);
    }
  }

  // Actualizar rareza actual en UI
  function updateRarityDisplay() {
    const label = document.getElementById('legendary-pack-current-rarity');
    if (!label) return;
    
    label.textContent = rarities[currentRarityIndex];
    label.className = rarityTextClasses[currentRarityIndex];
  }

  // Click en el sobre
  window.clickLegendaryPack = function() {
    if (attemptsLeft <= 0 || isProcessing) return;
    isProcessing = true;
    
    attemptsLeft--;
    updateAttemptsDisplay();
    
    const interactivePack = document.getElementById('legendary-pack-interactive');
    
    // Generar resultado de mejora
    const rand = Math.random();
    
    if (rand < 0.02) {
      // Fallo Crítico (2%)
      playFailSound();
      if (interactivePack) {
        interactivePack.className = 'legendary-pack-3d glitch-fail';
        interactivePack.style.pointerEvents = 'none';
      }
      
      setTimeout(() => {
        currentRarityIndex = 0; // Común
        finishGame(true); // Se rompió
      }, 650);
      
    } else if (rand < 0.28) {
      // Upgrade (26%)
      if (currentRarityIndex < 4) {
        currentRarityIndex++;
      }
      
      if (currentRarityIndex === 4) {
        playRareSound();
      } else {
        playUpgradeSound(currentRarityIndex);
      }
      
      spawnParticles(particleColors[currentRarityIndex]);
      triggerFlash(particleColors[currentRarityIndex]);
      
      if (interactivePack) {
        interactivePack.className = 'legendary-pack-3d ' + packClasses[currentRarityIndex] + ' click-pulse';
        setTimeout(() => interactivePack.classList.remove('click-pulse'), 200);
        
        const frontFace = interactivePack.querySelector('.pack-front');
        if (frontFace) {
          frontFace.className = 'pack-face pack-front ' + packClasses[currentRarityIndex];
        }
      }
      
      updateRarityDisplay();
      
      // Si llegamos a Legendario (máximo nivel), auto-finalizar con victoria máxima
      if (currentRarityIndex === 4) {
        setTimeout(() => {
          finishGame(false);
        }, 800);
        return;
      }
      
      isProcessing = false;
      
      // Auto cashout si no quedan intentos
      if (attemptsLeft <= 0) {
        setTimeout(() => finishGame(false), 500);
      }
      
    } else {
      // Stay Same (72% restante)
      playNeutralSound();
      if (interactivePack) {
        interactivePack.classList.add('shake-neutral', 'click-pulse');
        setTimeout(() => interactivePack.classList.remove('shake-neutral', 'click-pulse'), 300);
      }
      
      isProcessing = false;
      
      // Auto cashout si no quedan intentos
      if (attemptsLeft <= 0) {
        setTimeout(() => finishGame(false), 500);
      }
    }
  };

  // Retirarse voluntariamente
  window.cashoutLegendaryPack = function() {
    if (isProcessing) return;
    finishGame(false);
  };

  // Finalizar el juego (Cobra y otorga premios)
  async function finishGame(isBroken) {
    isProcessing = true;
    
    // Detener animación de partículas
    if (animationFrameId) {
      cancelAnimationFrame(animationFrameId);
      animationFrameId = null;
    }
    
    const cardContainer = document.getElementById('legendary-pack-result-card-container');
    const resultTitle = document.getElementById('legendary-pack-result-title');
    const resultSubtitle = document.getElementById('legendary-pack-result-subtitle');
    
    if (cardContainer) cardContainer.innerHTML = '<div style="color: #94a3b8;">Cargando recompensa...</div>';
    showScreen('legendary-pack-result-screen');
    
    if (isBroken || currentRarityIndex === 0) {
      // Común o roto -> Sin recompensa
      if (resultTitle) resultTitle.textContent = '💥 SOBRE PERDIDO';
      if (resultSubtitle) resultSubtitle.textContent = 'Mala suerte...';
      if (cardContainer) {
        cardContainer.innerHTML = `<div class="loss-message">Has perdido el sobre</div>`;
      }
      isProcessing = false;
      return;
    }
    
    // De lo contrario, obtener la carta ganadora
    try {
      const rarityLabel = rarities[currentRarityIndex]; // Poco Común, Raro, Épico, Legendario, Knight
      
      if (!window.kvrcards || typeof window.kvrcards.getLegendaryUpgradeRewardCard !== 'function') {
        throw new Error('Función window.kvrcards.getLegendaryUpgradeRewardCard no disponible');
      }
      
      const card = await window.kvrcards.getLegendaryUpgradeRewardCard(rarityLabel);
      if (card.error) {
        throw new Error(card.error);
      }
      
      const qualityColors = {
        'Bronce': '#b45309',
        'Plata': '#64748b',
        'Oro': '#d97706',
        'Icono': '#a855f7',
        'Heroe': '#a855f7',
        'Evo': '#ec4899',
        'Knight': '#1d4ed8'
      };
      const qColor = qualityColors[card.calidad] || '#64748b';
      
      // Mostrar placeholder de revelación con efecto glow y partículas
      if (resultTitle) resultTitle.textContent = '⚡ REVELANDO CARTA...';
      if (resultSubtitle) resultSubtitle.textContent = 'Preparando tu recompensa...';
      if (cardContainer) {
        cardContainer.innerHTML = `
          <div class="reward-card-clean-wrapper" style="--rare-color: ${qColor}; filter: brightness(0.6) blur(2px);">
            <div style="width: 220px; height: 310px; border-radius: 12px; background: linear-gradient(135deg, #1e293b 0%, #020617 100%); display: flex; align-items: center; justify-content: center; font-size: 50px; box-shadow: 0 0 35px ${qColor}; border: 3px solid ${qColor};">❓</div>
          </div>
        `;
      }
      
      // Iniciar partículas de fondo en canvas
      startParticleAnimation();
      
      // Lanzar ráfagas de chispas
      const interval = setInterval(() => {
        spawnParticles(qColor);
      }, 250);
      
      // Esperar 1.5 segundos para la revelación épica final
      setTimeout(async () => {
        clearInterval(interval);
        
        // Agregar carta físicamente al inventario
        if (typeof window.kvrcards.addCard !== 'function') {
          throw new Error('Función window.kvrcards.addCard no disponible');
        }
        await window.kvrcards.addCard(card.id);
        
        // Sincronizar remotamente
        if (typeof window.kvrcards.syncInventoryRemote === 'function') {
          await window.kvrcards.syncInventoryRemote().catch(e => {
            console.error('[GAMBLING] Error al sincronizar tras añadir recompensa:', e);
          });
        }
        
        // Refrescar UI del juego principal al obtener la recompensa
        if (typeof renderCollection === 'function') {
          renderCollection().catch(e => console.error('[GAMBLING] Error al refrescar colección tras ganar recompensa:', e));
        }
        if (typeof renderOwnedPacks === 'function') {
          renderOwnedPacks().catch(e => console.error('[GAMBLING] Error al refrescar sobres tras ganar recompensa:', e));
        }
        if (typeof renderWallet === 'function') {
          renderWallet().catch(e => console.error('[GAMBLING] Error al refrescar cartera tras ganar recompensa:', e));
        }
        
        // Registrar en el Leaderboard mundial si es Épico o Legendario
        if (currentRarityIndex === 3 || currentRarityIndex === 4) {
          const cat = currentRarityIndex === 3 ? 'epic' : 'legendary';
          let username = (typeof currentUser === 'string' && currentUser.trim()) ? currentUser.trim() : (localStorage.getItem('kvrUsername') || '');
          if (!username && window.kvrcards && typeof window.kvrcards.getProfile === 'function') {
            try {
              const prof = await window.kvrcards.getProfile();
              if (prof && prof.username) username = prof.username.trim();
            } catch {}
          }
          if (!username) username = 'Invitado';
          
          try {
            const baseUrl = await getGamblingBaseUrl();
            console.log(`[GAMBLING] Enviando victoria de Sobre Legendario (${cat}) para ${username} a ${baseUrl}`);
            const response = await fetch(`${baseUrl}/api/gambling/legendary-pack/win/${encodeURIComponent(username)}`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({ rarity: cat })
            });
            
            if (response.ok) {
              const rankRes = await response.json();
              console.log('[GAMBLING] Ranking de Sobre Legendario actualizado con éxito:', rankRes);
              if (rankRes.ok && typeof window.refreshGamblingLeaderboardData === 'function') {
                await window.refreshGamblingLeaderboardData();
              }
            } else {
              console.warn('[GAMBLING] Error response when posting legendary-pack win:', response.status);
            }
          } catch (err) {
            console.warn('[GAMBLING] Failed to connect to server for legendary-pack leaderboard:', err);
          }
        }
        
        // Efecto sonoro de Jackpot y flash de pantalla
        playJackpotSound();
        triggerFlash(qColor);
        
        // Renderizar la carta limpia final
        if (resultTitle) resultTitle.textContent = '🎉 ¡RECOMPENSA OBTENIDA!';
        if (resultSubtitle) resultSubtitle.textContent = `¡Has alcanzado la rareza ${rarityLabel}!`;
        if (cardContainer) {
          cardContainer.innerHTML = renderRewardCard(card);
        }
        isProcessing = false;
      }, 1500);
      
    } catch (e) {
      console.error('[GAMBLING] Error al resolver recompensa:', e);
      if (resultTitle) resultTitle.textContent = '❌ ERROR';
      if (resultSubtitle) resultSubtitle.textContent = 'Ocurrió un problema';
      if (cardContainer) {
        cardContainer.innerHTML = `<div class="loss-message" style="font-size:16px;">Error: ${String(e)}</div>`;
      }
      isProcessing = false;
    }
  }

  // Renderizar la imagen limpia de la carta
  function renderRewardCard(card) {
    if (!card) return '';
    
    const qualityColors = {
      'Bronce': '#b45309',
      'Plata': '#64748b',
      'Oro': '#d97706',
      'Icono': '#a855f7',
      'Heroe': '#a855f7',
      'Icono Prime': '#facc15',
      'Icono Super Prime': '#facc15'
    };
    
    const qColor = qualityColors[card.calidad] || '#64748b';
    const cardSrc = card.imageUrl || card.image || card.imagen || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="220" height="310"><rect width="100%" height="100%" fill="%23222"/></svg>';
      
    return `
      <div class="reward-card-clean-wrapper" style="--rare-color: ${qColor};">
        <img src="${cardSrc}" alt="${card.name || card.nombre || 'Carta'}" class="reward-card-clean-img">
      </div>
    `;
  }

  // Volver al lobby / Reiniciar
  window.resetLegendaryPackGame = async function() {
    if (isProcessing) return;
    await refreshGoldPackCount();
    showScreen('legendary-pack-setup-screen');
    
    // Refrescar UI de sobres al reiniciar/volver
    if (typeof renderOwnedPacks === 'function') {
      renderOwnedPacks().catch(e => console.error('[GAMBLING] Error al refrescar sobres al reiniciar:', e));
    }
  };

})();
