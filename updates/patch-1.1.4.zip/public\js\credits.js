/* ==========================================================================
   KVRCARDS - MOTOR DE INTRO Y CRÉDITOS CINEMÁTICOS
   Secuencia de arranque: Video INTRO -> Créditos Cinemáticos -> Juego Principal
   ========================================================================== */
(function () {
  'use strict';

  // Bandera global para evitar que la música de fondo interrumpa el vídeo
  window.isIntroPlaying = true;

  let animFrameId = null;
  let isRunningCredits = false;
  let currentScrollY = 0;
  let currentSpeed = 1.0;
  const speedLevels = [1.0, 2.2, 4.5];
  let speedIndex = 0;

  let isIntroActive = true;
  let isCreditsActive = false;

  function initIntroAndCredits() {
    const introOverlay = document.getElementById('intro-overlay');
    const introVideo = document.getElementById('intro-video-player');
    const introSkipBtn = document.getElementById('intro-skip-prompt');

    const creditsModal = document.getElementById('credits-cinema-modal');
    const viewport = document.getElementById('cinema-scroll-viewport');
    const speedBtn = document.getElementById('cinema-speed-toggle-btn');
    const creditsSkipBtn = document.getElementById('credits-skip-prompt');
    const openCreditsBtn = document.getElementById('open-credits-btn');

    function updateSpeedButtonText() {
      if (!speedBtn) return;
      if (speedIndex === 0) {
        speedBtn.textContent = 'Velocidad: 1x';
      } else if (speedIndex === 1) {
        speedBtn.textContent = 'Velocidad: 2x';
      } else {
        speedBtn.textContent = 'Velocidad: 4x';
      }
    }

    function stopCreditsScroll() {
      isRunningCredits = false;
      if (animFrameId) {
        cancelAnimationFrame(animFrameId);
        animFrameId = null;
      }
    }

    function creditsLoop() {
      if (!isRunningCredits || !viewport) return;

      const maxScroll = viewport.scrollHeight - viewport.clientHeight;
      if (currentScrollY >= maxScroll) {
        stopCreditsScroll();
        setTimeout(finishCredits, 1200);
        return;
      }

      currentScrollY += currentSpeed;
      viewport.scrollTop = currentScrollY;

      animFrameId = requestAnimationFrame(creditsLoop);
    }

    function startCreditsScroll() {
      if (!viewport) return;
      stopCreditsScroll();
      isRunningCredits = true;
      currentSpeed = speedLevels[speedIndex];
      animFrameId = requestAnimationFrame(creditsLoop);
    }

    function openCreditsCinema() {
      isIntroActive = false;
      isCreditsActive = true;
      window.isIntroPlaying = false;

      // Asegurar bloqueo de scroll en el html/body
      document.documentElement.classList.add('intro-active');
      document.body.classList.add('intro-active');
      document.body.style.overflow = 'hidden';
      document.body.style.background = '#000000';

      if (!creditsModal || !viewport) return;

      stopCreditsScroll();

      speedIndex = 0;
      updateSpeedButtonText();
      currentSpeed = speedLevels[speedIndex];
      currentScrollY = 0;
      viewport.scrollTop = 0;

      // Mostrar créditos directamente en negro sólido sin parpadeos
      creditsModal.style.display = 'flex';

      try {
        if (typeof window.startMusicAfterInteraction === 'function') {
          window.startMusicAfterInteraction();
        }
      } catch (err) {}

      setTimeout(() => {
        if (creditsModal.style.display !== 'none') {
          currentScrollY = viewport.scrollTop;
          startCreditsScroll();
        }
      }, 300);
    }

    function finishCredits() {
      isCreditsActive = false;
      stopCreditsScroll();

      if (creditsModal) {
        creditsModal.style.display = 'none';
      }
      if (introOverlay) {
        introOverlay.style.display = 'none';
      }

      // Quitar clase intro-active y restaurar estilos de página normal
      document.documentElement.classList.remove('intro-active');
      document.body.classList.remove('intro-active');
      document.body.style.overflow = '';
      document.body.style.background = '';

      try {
        if (typeof window.startMusicAfterInteraction === 'function') {
          window.startMusicAfterInteraction();
        }
      } catch (err) {}

      console.log('[CREDITS] ✅ Créditos finalizados, bienvenido a KVRCards');
    }

    function skipIntro() {
      if (!isIntroActive) return;
      isIntroActive = false;

      if (introVideo) {
        try {
          introVideo.pause();
        } catch (e) {}
      }

      // Abrir créditos primero para que ya esté visible la pantalla oscura sin que se vea el menú
      openCreditsCinema();

      // Y ocultar el overlay de intro
      if (introOverlay) {
        introOverlay.style.display = 'none';
      }
    }

    if (introVideo) {
      introVideo.addEventListener('ended', skipIntro);

      const playPromise = introVideo.play();
      if (playPromise !== undefined) {
        playPromise.catch(err => {
          console.warn('[INTRO] Autoplay con sonido restringido, intentando silenciado o esperando interacción:', err);
          introVideo.muted = true;
          introVideo.play().catch(() => {});
          
          const unmute = () => {
            introVideo.muted = false;
            window.removeEventListener('click', unmute);
            window.removeEventListener('keydown', unmute);
          };
          window.addEventListener('click', unmute, { once: true });
          window.addEventListener('keydown', unmute, { once: true });
        });
      }
    }

    window.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        if (isIntroActive) {
          e.preventDefault();
          skipIntro();
        } else if (isCreditsActive) {
          e.preventDefault();
          finishCredits();
        }
      } else if (e.key === 'Escape') {
        if (isIntroActive) {
          e.preventDefault();
          skipIntro();
        } else if (isCreditsActive) {
          e.preventDefault();
          finishCredits();
        }
      }
    });

    if (introSkipBtn) {
      introSkipBtn.addEventListener('click', skipIntro);
    }
    if (creditsSkipBtn) {
      creditsSkipBtn.addEventListener('click', finishCredits);
    }

    if (viewport) {
      viewport.addEventListener('scroll', () => {
        if (Math.abs(viewport.scrollTop - currentScrollY) > 8) {
          currentScrollY = viewport.scrollTop;
        }
      }, { passive: true });
    }

    if (speedBtn) {
      speedBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        speedIndex = (speedIndex + 1) % speedLevels.length;
        currentSpeed = speedLevels[speedIndex];
        updateSpeedButtonText();
        if (!isRunningCredits) {
          startCreditsScroll();
        }
      });
    }

    if (openCreditsBtn) {
      openCreditsBtn.addEventListener('click', () => {
        openCreditsCinema();
      });
    }

    console.log('[INTRO & CREDITS] ✅ Sistema de arranque con INTRO y Créditos inicializado');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initIntroAndCredits);
  } else {
    initIntroAndCredits();
  }
})();
