// ==================== electron/modules/MODULE_MAP.md ====================
// This file documents the logical modules inside main.js
// In a future iteration, each section can be extracted into its own file
//
// CURRENT STRUCTURE:
// L1-50:      Requires, app setup
// L51-200:    State variables (Maps, Sets, objects)
// L201-400:   Persistence functions (readJSON, writeJSON, paths)
// L401-600:   Catalog management
// L601-1200:  Cards & Packs IPC handlers
// L1201-1600: Inventory, Wallet IPC handlers
// L1601-2000: Profile, Powers, Traits IPC handlers
// L2001-2400: Missions, Rankings IPC handlers
// L2401-2800: Shop, Codes, Cloud Sync IPC handlers
// L2801-3200: Infinite Mode, Evolutions IPC handlers
// L3201-3600: System, Window, Maintenance IPC handlers
// L3601-4000: Remote Config, Inventory Server lifecycle
// L4001-4583: App initialization, window creation, menu
//
// IPC Channels (93 total):
//   handle('upload:image') — L503
//   handle('cards:add') — L522
//   handle('cards:getAll') — L546
//   handle('cards:delete') — L547
//   handle('cards:sell') — L555
//   handle('packs:create') — L605
//   handle('packs:open') — L616
//   handle('packs:saveCards') — L651
//   handle('packs:sellAllCards') — L675
//   handle('packs:getAll') — L701
//   handle('packs:delete') — L708
//   handle('inventory:get') — L716
//   handle('wallet:get') — L729
//   handle('wallet:updateInfiniteCurrencies') — L733
//   handle('inventory:addPack') — L740
//   handle('window:forceFocus') — L751
//   handle('powers:getAll') — L769
//   handle('powers:getInventory') — L772
//   handle('traits:getAll') — L782
//   handle('traits:debugModify') — L785
//   handle('traits:assign') — L793
//   handle('powers:add') — L859
//   handle('powers:use') — L895
//   handle('missions:getStats') — L934
//   handle('missions:addBattleWon') — L939
//   handle('missions:addCoins') — L947
//   handle('missions:addKvR') — L957
//   handle('missions:addPack') — L966
//   handle('missions:addCard') — L975
//   handle('rankings:getWeekly') — L1057
//   handle('rankings:getHistorical') — L1121
//   handle('profile:getUserProfile') — L1172
//   handle('profile:updateUserProfile') — L1236
//   handle('catalog:summary') — L2095
//   handle('catalog:refresh') — L2098
//   handle('catalog:clearCache') — L2103
//   handle('titles:get') — L2109
//   handle('profile:get') — L2745
//   handle('profile:setUsername') — L2750
//   handle('inventory:syncRemote') — L2801
//   handle('inventory:getRemote') — L2809
//   handle('infinite:loadRunState') — L2817
//   handle('infinite:saveRunState') — L2829
//   handle('infinite:resetRunState') — L2845
//   handle('infinite:getRankingsOverview') — L2857
//   handle('missions:getState') — L2867
//   handle('missions:saveState') — L2871
//   handle('settings:get') — L2881
//   handle('settings:save') — L2885
//   handle('shop:buyPack') — L2895
//   handle('admin:clearCommandHistory') — L2943
//   handle('admin:syncCommands') — L2958
//   handle('admin:syncCommandsForce') — L2968
//   handle('codes:redeem') — L2978
//   handle('codes:getRedeemed') — L3115
//   handle('music:getAvailableTracks') — L3167
//   handle('music:uploadTrack') — L3213
//   handle('music:deleteTrack') — L3252
//   handle('cloud:register') — L3288
//   handle('cloud:login') — L3300
//   handle('cloud:upload') — L3317
//   handle('cloud:download') — L3348
//   handle('cloud:applyData') — L3354
//   handle('system:clearCache') — L3409
//   handle('system:openDataFolder') — L3437
//   handle('friends:sendRequest') — L3461
//   handle('friends:acceptRequest') — L3488
//   handle('friends:rejectRequest') — L3515
//   handle('friends:removeFriend') — L3542
//   handle('friends:getFriendsList') — L3569
//   handle('friends:getRequests') — L3596
//   handle('friends:searchUsers') — L3623
//   handle('trades:sendRequest') — L3651
//   handle('trades:joinRandomQueue') — L3675
//   handle('trades:checkRandomMatch') — L3699
//   handle('trades:acceptTrade') — L3721
//   handle('trades:rejectTrade') — L3745
//   handle('trades:updateOffer') — L3769
//   handle('trades:confirmTrade') — L3802
//   handle('trades:cancelConfirm') — L3853
//   handle('trades:cancelTrade') — L3877
//   handle('trades:getStatus') — L3901
//   handle('trades:getPending') — L3918
//   handle('trades:acceptRequest') — L3941
//   handle('trades:rejectRequest') — L3966
//   handle('inventory:reloadFromServer') — L3991
//   handle('inventory:serverInfo') — L4440
//   handle('evolutions:load') — L4450
//   handle('evolutions:saveState') — L4464
//   handle('evolutions:loadState') — L4479
//   handle('maintenance:check') — L4538
//   handle('app:getVersion') — L4543
//   handle('shell:openExternal') — L4555
