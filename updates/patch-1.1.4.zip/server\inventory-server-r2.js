// Simple inventory server for viewing and storing users' inventories online
// Now with Cloudflare R2 storage support (S3-compatible)
// Usage: node server/inventory-server.js

const express = require('express');
const { S3Client, PutObjectCommand, GetObjectCommand, ListObjectsV2Command } = require('@aws-sdk/client-s3');
const http = require('http');
const https = require('https');

const app = express();
// Aumentar límite de payload para soportar imágenes de perfil grandes (hasta 10MB)
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// CORS básico para permitir llamadas desde otros orígenes (apps o navegadores externos)
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// ---- Cloudflare R2 Configuration ----
const R2_ACCOUNT_ID = process.env.R2_ACCOUNT_ID || '';
const R2_ACCESS_KEY_ID = process.env.R2_ACCESS_KEY_ID || '';
const R2_SECRET_ACCESS_KEY = process.env.R2_SECRET_ACCESS_KEY || '';
const R2_BUCKET_NAME = process.env.R2_BUCKET_NAME || 'kvrcards-inventory';

// Initialize S3 Client for R2
let s3Client = null;
if (R2_ACCOUNT_ID && R2_ACCESS_KEY_ID && R2_SECRET_ACCESS_KEY) {
  s3Client = new S3Client({
    region: 'auto',
    endpoint: `https://${R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
    credentials: {
      accessKeyId: R2_ACCESS_KEY_ID,
      secretAccessKey: R2_SECRET_ACCESS_KEY,
    },
  });
  console.log('[inventory-server] R2 storage enabled, bucket:', R2_BUCKET_NAME);
} else {
  console.warn('[inventory-server] R2 not configured - set R2_ACCOUNT_ID, R2_ACCESS_KEY_ID, R2_SECRET_ACCESS_KEY, R2_BUCKET_NAME');
}

function userFileKey(username) {
  const safe = String(username || '').replace(/[^a-zA-Z0-9_-]/g, '_');
  return `users/${safe}.json`;
}

// Helper: Read from R2
async function readFromR2(key) {
  if (!s3Client) throw new Error('R2 not configured');
  try {
    const command = new GetObjectCommand({
      Bucket: R2_BUCKET_NAME,
      Key: key,
    });
    const response = await s3Client.send(command);
    const str = await response.Body.transformToString();
    return JSON.parse(str);
  } catch (err) {
    if (err.name === 'NoSuchKey' || err.$metadata?.httpStatusCode === 404) {
      return null; // File doesn't exist
    }
    throw err;
  }
}

// Helper: Write to R2
async function writeToR2(key, data) {
  if (!s3Client) throw new Error('R2 not configured');
  const command = new PutObjectCommand({
    Bucket: R2_BUCKET_NAME,
    Key: key,
    Body: JSON.stringify(data, null, 2),
    ContentType: 'application/json',
  });
  await s3Client.send(command);
}

// Helper: List all users from R2
async function listUsersFromR2() {
  if (!s3Client) throw new Error('R2 not configured');
  try {
    const command = new ListObjectsV2Command({
      Bucket: R2_BUCKET_NAME,
      Prefix: 'users/',
    });
    const response = await s3Client.send(command);
    const users = (response.Contents || [])
      .map(obj => obj.Key.replace('users/', '').replace('.json', ''))
      .filter(u => u.length > 0);
    return users;
  } catch (err) {
    console.error('[R2] Error listing users:', err);
    return [];
  }
}

// ---- Catálogo (para resolver IDs -> nombres) ----
const CATALOG_BASE_URL = process.env.CATALOG_BASE_URL || '';
let catalogIndex = { cards: {}, packs: {}, lastLoaded: 0 };

function ensureSlash(u) { return u.endsWith('/') ? u : u + '/'; }

function fetchJson(url) {
  const lib = url.startsWith('https') ? https : http;
  return new Promise((resolve, reject) => {
    const req = lib.get(url, (res) => {
      if (res.statusCode < 200 || res.statusCode >= 300) {
        return reject(new Error('HTTP ' + res.statusCode));
      }
      let data = '';
      res.on('data', (c) => data += c.toString('utf-8'));
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } });
    });
    req.on('error', reject);
  });
}

async function loadCatalogIndex() {
  if (!CATALOG_BASE_URL) return;
  try {
    const base = ensureSlash(CATALOG_BASE_URL);
    const [cardsArr, packsArr] = await Promise.all([
      fetchJson(base + 'cards.json').catch(() => []),
      fetchJson(base + 'packs.json').catch(() => []),
    ]);
    const cardMap = {};
    if (Array.isArray(cardsArr)) {
      cardsArr.forEach((c, idx) => {
        const id = c && c.id ? String(c.id) : ('idx-' + idx);
        const name = c && c.name ? String(c.name) : ('Carta ' + idx);
        cardMap[id] = name;
      });
    }
    const packMap = {};
    if (Array.isArray(packsArr)) {
      packsArr.forEach((p, idx) => {
        const id = p && p.id ? String(p.id) : ('pack-' + idx);
        const name = p && p.name ? String(p.name) : ('Pack ' + idx);
        packMap[id] = name;
      });
    }
    catalogIndex.cards = cardMap;
    catalogIndex.packs = packMap;
    catalogIndex.lastLoaded = Date.now();
  } catch (e) {
    // no-op
  }
}

if (CATALOG_BASE_URL) {
  loadCatalogIndex();
  setInterval(loadCatalogIndex, 5 * 60 * 1000);
}

function expandInventory(base) {
  const cards = Object.keys(base.cards || {}).map(id => ({
    id,
    count: Number(base.cards[id]) || 0,
    name: catalogIndex.cards[id] || id
  }));
  const packs = Object.keys(base.packs || {}).map(id => ({
    id,
    count: Number(base.packs[id]) || 0,
    name: catalogIndex.packs[id] || id
  }));
  return {
    ...base,
    cardsExpanded: cards,
    packsExpanded: packs
  };
}

// ---- Endpoints ----

app.get('/api/inventory/:username', async (req, res) => {
  const expanded = String(req.query.expanded || '').toLowerCase() === '1';
  try {
    const key = userFileKey(req.params.username);
    let data = await readFromR2(key);
    
    if (!data) {
      // User doesn't exist, return empty
      data = {
        username: req.params.username,
        cards: {},
        packs: {},
        wallet: { coins: 0, kvr: 0 },
        stats: { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0 },
        weeklyStats: { cards: 0, packs: 0, coins: 0 },
        profileImage: '',
        currentTitle: '',
        showcaseCards: [null, null, null],
        updatedAt: 0
      };
    }
    
    if (!expanded) {
      return res.json(data);
    }
    return res.json(expandInventory(data));
  } catch (e) {
    console.error('[R2] Error getting user:', e);
    res.status(500).json({ error: String(e) });
  }
});

app.post('/api/inventory/:username', async (req, res) => {
  const body = req.body || {};
  const username = String(req.params.username || body.username || '').trim();
  if (!username) return res.status(400).json({ error: 'username required' });
  
  const payload = {
    username,
    cards: body.cards || {},
    packs: body.packs || {},
    wallet: (body.wallet && typeof body.wallet === 'object') 
      ? { coins: Math.max(0, Number(body.wallet.coins)||0), kvr: Math.max(0, Number(body.wallet.kvr)||0) } 
      : { coins: 0, kvr: 0 },
    stats: body.stats || { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0 },
    weeklyStats: body.weeklyStats || { cards: 0, packs: 0, coins: 0, weekStart: null },
    profileImage: body.profileImage || '',
    currentTitle: body.currentTitle || '',
    showcaseCards: Array.isArray(body.showcaseCards) ? body.showcaseCards : [null, null, null],
    updatedAt: Date.now(),
  };
  
  try {
    const key = userFileKey(username);
    await writeToR2(key, payload);
    console.log('[inventory-server] Saved snapshot for', username, 'to R2');
    res.json({ ok: true });
  } catch (e) {
    console.error('[R2] Error saving user:', e);
    res.status(500).json({ error: String(e) });
  }
});

// List all users
app.get('/api/inventory', async (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    const users = await listUsersFromR2();
    console.log('[inventory-server] List users from R2:', users);
    res.json({ users });
  } catch (e) {
    console.error('[R2] Error listing users:', e);
    res.status(500).json({ error: String(e) });
  }
});

// Healthcheck
app.get('/api/health', async (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    const users = await listUsersFromR2();
    res.json({ 
      ok: true, 
      storage: 'cloudflare-r2',
      bucket: R2_BUCKET_NAME,
      count: users.length 
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Basic UI (legacy, mainly for debugging)
app.get('/', async (_req, res) => {
  try {
    const users = await listUsersFromR2();
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>KVRCards Inventory (R2)</title></head>
<body style="font-family:sans-serif;max-width:900px;margin:2rem auto;padding:1rem;">
<h1>KVRCards Inventory Server (R2)</h1>
<p><strong>Storage:</strong> Cloudflare R2 (${R2_BUCKET_NAME})</p>
<p><strong>Users:</strong> ${users.length}</p>
<ul>${users.map(u => `<li><a href="/api/inventory/${u}">${u}</a></li>`).join('')}</ul>
</body></html>`;
    res.send(html);
  } catch (e) {
    res.status(500).send('Error: ' + String(e));
  }
});

// ---- Start server ----
// Usar variable de entorno PORT (para Render/Heroku) o 5005 localmente
let PORT = Number(process.env.PORT || 5005);

function startServer(p) {
  const server = app.listen(p, () => {
    console.log('Inventory server listening on http://localhost:' + p);
    console.log('Using Cloudflare R2 for storage');
  });
  server.on('error', (err) => {
    if (err && err.code === 'EADDRINUSE' && p === 4321) {
      PORT = 5005;
      console.log('[inventory-server] Port 4321 occupied, trying 5005...');
      setTimeout(() => startServer(PORT), 1000);
    } else {
      console.error('[inventory-server] Server error:', err);
      process.exit(1);
    }
  });
}

startServer(PORT);
