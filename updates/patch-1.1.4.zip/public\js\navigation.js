
function show(view) {
  console.log(`[SHOW] Mostrando vista: ${view}`);
  
  const mainMenu = document.getElementById('main-menu');
  const gameView = document.getElementById('game-view');
  
  if (view === 'play') {
    mainMenu.style.display = 'none';
    gameView.style.display = 'block';
    sections.collection.style.display = 'none';
    sections.packs.style.display = 'none';
    sections.shop.style.display = 'none';
    sections.missions.style.display = 'none';
    
    // Asegurar limpieza de subvistas de game-view para evitar solapamientos
    const subViews = [
      'game-mode-selection',
      'game-type-selection',
      'online-friendly-selection',
      'matchmaking-screen',
      'friend-battle-screen',
      'difficulty-selection',
      'team-builder'
    ];
    subViews.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = id === 'game-mode-selection' ? 'block' : 'none';
    });
  } else {
    mainMenu.style.display = 'block';
    gameView.style.display = 'none';
    sections.collection.style.display = view === 'collection' ? 'block' : 'none';
    sections.packs.style.display = view === 'packs' ? 'block' : 'none';
    sections.shop.style.display = view === 'shop' ? 'block' : 'none';
    sections.missions.style.display = view === 'missions' ? 'block' : 'none';
    
    if (view === 'missions') {
      if (typeof window.updateGlobalNotificationBadges === 'function') {
        window.updateGlobalNotificationBadges();
      }
      const activeTab = document.querySelector('.collectible-tab.active')?.dataset?.tab;
      if (activeTab === 'titles' && typeof renderTitlesCollectibleView === 'function') {
        renderTitlesCollectibleView();
      } else if (activeTab === 'backgrounds' && typeof renderBackgroundsCollectibleView === 'function') {
        renderBackgroundsCollectibleView();
      } else if (activeTab === 'kizuna' && typeof renderKizunas === 'function') {
        renderKizunas();
      } else if (activeTab === 'deliverables' && typeof initEvents === 'function') {
        initEvents();
      } else {
        renderMissions();
        loadMissions().then(() => renderMissions()).catch(console.error);
      }
    }
  }
  
  console.log(`[SHOW] Vista ${view} mostrada`);
}

document.querySelectorAll('.main-menu button[data-view]').forEach(btn => {
  btn.addEventListener('click', () => {
    const view = btn.getAttribute('data-view');
    show(view);
  });
});

// Hook menú nativo
if (window.kvrcards) {
  window.kvrcards.onNavigate((view) => {
    const clickBtn = (dataView) => document.querySelector(`.main-menu button[data-view="${dataView}"]`)?.click();
    if (view === 'main' || view === 'cards') clickBtn('collection');
    if (view === 'packs') clickBtn('packs');
  });
  window.kvrcards.onOpenPack(async () => {
    // Abrir el primer pack disponible
    const inv = await window.kvrcards.getInventory();
    if (!inv.ok) return;
    const packId = Object.keys(inv.packs).find(id => inv.packs[id] > 0);
    if (!packId) return;
    await openPack(packId);
  });
  // Refrescar vistas cuando recargamos el catálogo desde el menú nativo
  window.kvrcards.onCatalogReloaded(async () => {
    await Promise.all([renderCollection(), renderOwnedPacks(), renderShop(), renderWallet()]);
  });
}

// Render colección
const collectionDiv = document.getElementById('collection-cards');
const ownedPacksDiv = document.getElementById('owned-packs');

// Navegación de retorno al menú principal
function returnToMainMenu() {
  console.log('[NAV] Volviendo al menú principal...');

  if (typeof cleanUpBattleCompletely === 'function') {
    cleanUpBattleCompletely({ isFullReset: true, resumeMenuMusic: true });
  }

  // Ocultar defensivamente todas las vistas y subvistas
  const viewsToHide = [
    'battle-result-screen',
    'battle-screen',
    'battle-intro',
    'team-builder',
    'game-view',
    'game-type-selection',
    'online-friendly-selection',
    'matchmaking-screen',
    'friend-battle-screen',
    'difficulty-selection',
    'traits-panel',
    'draft-view'
  ];

  viewsToHide.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });

  const classViews = ['collection', 'packs', 'shop', 'missions'];
  classViews.forEach(cls => {
    const el = document.querySelector(`.${cls}`);
    if (el) el.style.display = 'none';
  });

  document.querySelectorAll('.trades-modal, .friends-modal, .rankings-modal, .settings-modal, .modal-backdrop').forEach(m => {
    m.classList.remove('show', 'active');
  });

  const gameModeSelection = document.getElementById('game-mode-selection');
  if (gameModeSelection) gameModeSelection.style.display = 'block';

  const mainMenu = document.getElementById('main-menu');
  if (mainMenu) mainMenu.style.display = 'flex';

  if (typeof window.updateGlobalNotificationBadges === 'function') {
    window.updateGlobalNotificationBadges();
  }
}

if (!window.returnToMainMenu) {
  window.returnToMainMenu = returnToMainMenu;
}

// Botón de salir del juego en el menú principal
function setupExitGameButton() {
  const exitBtn = document.getElementById('exit-game-btn');
  if (!exitBtn) return;
  exitBtn.addEventListener('click', (e) => {
    e.preventDefault();
    console.log('[APP] Solicitud de cerrar el juego...');
    if (typeof playSFX === 'function') {
      try { playSFX('buttonClick'); } catch {}
    }
    if (window.kvrcards && typeof window.kvrcards.quitApp === 'function') {
      window.kvrcards.quitApp();
    } else {
      window.close();
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setupExitGameButton);
} else {
  setupExitGameButton();
}

