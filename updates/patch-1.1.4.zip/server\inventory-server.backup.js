// Simple inventory server for viewing and storing users' inventories online
// Usage: node server/inventory-server.js

const express = require('express');
const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const os = require('os');

const app = express();
// Aumentar límite de payload para soportar imágenes de perfil grandes (hasta 10MB)
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));

// CORS básico para permitir llamadas desde otros orígenes (apps o navegadores externos)
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// Directorio de datos: por defecto en APPDATA para compartir entre instancias (dev/packaged)
const DEFAULT_BASE = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
const DATA_DIR = process.env.KVRCARDS_DATA_DIR || path.join(DEFAULT_BASE, 'KVRCards', 'inventory-data');
fs.mkdirSync(DATA_DIR, { recursive: true });
console.log('[inventory-server] DATA_DIR =', DATA_DIR);

function userFile(username) {
  const safe = String(username || '').replace(/[^a-zA-Z0-9_-]/g, '_');
  return path.join(DATA_DIR, safe + '.json');
}

// ---- Catálogo (para resolver IDs -> nombres) ----
const CATALOG_BASE_URL = process.env.CATALOG_BASE_URL || '';
let catalogIndex = { cards: {}, packs: {}, lastLoaded: 0 };

function ensureSlash(u) { return u.endsWith('/') ? u : u + '/'; }

function fetchJson(url) {
  const lib = url.startsWith('https') ? https : http;
  return new Promise((resolve, reject) => {
    const req = lib.get(url, (res) => {
      if (res.statusCode < 200 || res.statusCode >= 300) {
        return reject(new Error('HTTP ' + res.statusCode));
      }
      let data = '';
      res.on('data', (c) => data += c.toString('utf-8'));
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } });
    });
    req.on('error', reject);
  });
}

async function loadCatalogIndex() {
  if (!CATALOG_BASE_URL) return; // opcional
  try {
    const base = ensureSlash(CATALOG_BASE_URL);
    const [cardsArr, packsArr] = await Promise.all([
      fetchJson(base + 'cards.json').catch(() => []),
      fetchJson(base + 'packs.json').catch(() => []),
    ]);
    const cardMap = {};
    if (Array.isArray(cardsArr)) {
      cardsArr.forEach((c, idx) => {
        const id = c && c.id ? String(c.id) : ('idx-' + idx);
        const name = c && c.name ? String(c.name) : ('Carta ' + idx);
        cardMap[id] = name;
      });
    }
    const packMap = {};
    if (Array.isArray(packsArr)) {
      packsArr.forEach((p, idx) => {
        const id = p && p.id ? String(p.id) : ('pack-' + idx);
        const name = p && p.name ? String(p.name) : ('Pack ' + idx);
        packMap[id] = name;
      });
    }
    catalogIndex.cards = cardMap;
    catalogIndex.packs = packMap;
    catalogIndex.lastLoaded = Date.now();
  } catch (e) {
    // no-op, se mantiene lo previo
  }
}

// Recarga cada 5 minutos si hay base URL
if (CATALOG_BASE_URL) {
  loadCatalogIndex();
  setInterval(loadCatalogIndex, 5 * 60 * 1000);
}

app.get('/api/inventory/:username', (req, res) => {
  const file = userFile(req.params.username);
  const expanded = String(req.query.expanded || '').toLowerCase() === '1';
  if (!fs.existsSync(file)) {
    const base = { username: req.params.username, cards: {}, packs: {}, wallet: { coins: 0, kvr: 0 }, updatedAt: 0 };
    if (!expanded) return res.json(base);
    return res.json(expandInventory(base));
  }
  try {
    const data = JSON.parse(fs.readFileSync(file, 'utf-8'));
    if (!expanded) return res.json(data);
    res.json(expandInventory(data));
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

app.post('/api/inventory/:username', (req, res) => {
  const body = req.body || {};
  const username = String(req.params.username || body.username || '').trim();
  if (!username) return res.status(400).json({ error: 'username required' });
  const payload = {
    username,
    cards: body.cards || {},
    packs: body.packs || {},
    wallet: (body.wallet && typeof body.wallet === 'object') ? { coins: Math.max(0, Number(body.wallet.coins)||0), kvr: Math.max(0, Number(body.wallet.kvr)||0) } : { coins: 0, kvr: 0 },
    stats: body.stats || { totalCardsObtained: 0, totalPacksOpened: 0, totalCoinsEarned: 0 }, // Estadísticas históricas
    weeklyStats: body.weeklyStats || { cards: 0, packs: 0, coins: 0, weekStart: null }, // Estadísticas semanales
    profileImage: body.profileImage || '', // Foto de perfil
    currentTitle: body.currentTitle || '', // Título actual
    showcaseCards: Array.isArray(body.showcaseCards) ? body.showcaseCards : [null, null, null], // Cartas destacadas
    updatedAt: Date.now(),
  };
  try {
    fs.writeFileSync(userFile(username), JSON.stringify(payload, null, 2));
    console.log('[inventory-server] Saved snapshot for', username, 'with profile data');
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// List all users (basic admin)
app.get('/api/inventory', (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    const files = fs.readdirSync(DATA_DIR).filter(f => f.endsWith('.json'));
    const users = files.map(f => path.basename(f, '.json'));
    console.log('[inventory-server] List users:', users);
    res.json({ users });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Healthcheck
app.get('/api/health', (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    const files = fs.readdirSync(DATA_DIR).filter(f => f.endsWith('.json'));
    res.json({ ok: true, dataDir: DATA_DIR, count: files.length });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e), dataDir: DATA_DIR });
  }
});

// Expansión de inventario a nombres legibles
function expandInventory(data) {
  const cardsObj = data.cards || {};
  const packsObj = data.packs || {};
  const cards = Object.entries(cardsObj).map(([id, count]) => ({ id, name: catalogIndex.cards[id] || id, count }));
  const packs = Object.entries(packsObj).map(([id, count]) => ({ id, name: catalogIndex.packs[id] || id, count }));
  const wallet = data.wallet && typeof data.wallet === 'object' ? data.wallet : { coins: 0, kvr: 0 };
  return { username: data.username, updatedAt: data.updatedAt || 0, cards, packs, wallet };
}

// Simple HTML UI
app.get('/', (_req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  let initialUsers = [];
  try {
    const files = fs.readdirSync(DATA_DIR).filter(f => f.endsWith('.json'));
    initialUsers = files.map(f => path.basename(f, '.json')).sort((a,b)=>a.localeCompare(b));
  } catch {}
  const initialUsersHtml = initialUsers.map(u=>`<li><a href="/user/${encodeURIComponent(u)}" data-username="${u}">${u}</a></li>`).join('');
  res.type('html').send(`<!doctype html>
  <html><head><meta charset="utf-8"/><title>Inventarios</title>
  <style>body{font-family:system-ui,Arial;background:#0d1117;color:#c9d1d9;padding:20px} a{color:#58a6ff} pre{background:#161b22;padding:12px;border-radius:8px;border:1px solid #30363d;overflow:auto}
  .box{background:#161b22;padding:12px;border-radius:8px;border:1px solid #30363d;margin:8px 0}
  table{width:100%;border-collapse:collapse}
  th,td{border:1px solid #30363d;padding:6px;text-align:left}
  </style></head><body>
  <h1>Inventarios</h1>
  <div class="box">
    <button onclick="loadUsers()">Refrescar</button>
    <div id="usersEmpty" style="display:none;opacity:.8">(no hay usuarios todavía)</div>
    <div id="usersCount" style="opacity:.7;margin:6px 0"></div>
  <ul id="users">${initialUsersHtml}</ul>
    <div style="margin-top:6px;opacity:.7;font-size:12px">Ver JSON: <a href="/api/inventory" target="_blank">/api/inventory</a> · Health: <a href="/api/health" target="_blank">/api/health</a></div>
    <pre id="debug" style="display:none;margin-top:8px"></pre>
  </div>
  <div class="box">
    <h3 id="title">Detalle</h3>
    <div id="detail">(selecciona un usuario)</div>
  </div>
  <script>
  const initialUsers = ${JSON.stringify(initialUsers)};
  let currentUser = null;
  // Si viene ?user= en la URL, cargar su detalle al iniciar (opcional)
  (function(){ try { const p=new URLSearchParams(location.search); const u=p.get('user'); if(u){ currentUser=u; loadDetail(u); } } catch(e){} })();
  async function loadUsers(){
    const ul=document.getElementById('users'); const emptyMsg=document.getElementById('usersEmpty'); const dbg=document.getElementById('debug'); const cnt=document.getElementById('usersCount');
    ul.innerHTML='';
    try{
      // Si hay usuarios iniciales renderizados por el servidor, úsalos primero
      if (Array.isArray(initialUsers) && initialUsers.length > 0) {
        initialUsers.forEach(name=>{ const li=document.createElement('li'); const a=document.createElement('a'); a.href='/user/'+encodeURIComponent(name); a.setAttribute('data-username', name); a.textContent=name; li.appendChild(a); ul.appendChild(li); });
        emptyMsg.style.display='none'; dbg.style.display='none'; cnt.textContent = 'Usuarios: ' + initialUsers.length;
        // Si no hay usuario seleccionado, no forzar; al hacer clic navegamos a /user/:username
      }
      const r=await fetch('/api/inventory', { cache:'no-store' });
      const j=await r.json();
      let u = j && Array.isArray(j.users) ? j.users : (j && j.users && typeof j.users === 'object' ? Object.keys(j.users) : []);
      if(!Array.isArray(u)) u = [];
      if(u.length===0 && ul.children.length===0){
        emptyMsg.style.display='block';
        dbg.style.display='block'; dbg.textContent = 'Debug: response=' + JSON.stringify(j); cnt.textContent='Usuarios: 0';
        return;
      } else {
        emptyMsg.style.display='none'; dbg.style.display='none'; cnt.textContent = 'Usuarios: ' + u.length;
      }
      if (u.length > 0) {
        ul.innerHTML='';
        u.forEach(name=>{ const li=document.createElement('li'); const a=document.createElement('a'); a.href='/user/'+encodeURIComponent(name); a.setAttribute('data-username', name); a.textContent=name; li.appendChild(a); ul.appendChild(li); });
      }
    } catch(e){
      emptyMsg.style.display='block'; emptyMsg.textContent='(error cargando usuarios)';
      dbg.style.display='block'; dbg.textContent=String(e);
      cnt.textContent='Usuarios: ?';
    }
  }
  function formatTable(items,label){
    const rows = items.map(function(it){
      return '<tr><td>' + escapeHtml(it.id) + '</td><td>' + escapeHtml(it.name) + '</td><td>' + it.count + '</td></tr>';
    }).join('');
    return '<h4>' + label + '</h4><table><thead><tr><th>ID</th><th>Nombre</th><th>Cantidad</th></tr></thead><tbody>' + (rows || '<tr><td colspan=3>(vacío)</td></tr>') + '</tbody></table>';
  }
  function escapeHtml(s){ return String(s).replace(/[&<>\"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c])); }
  async function loadDetail(name){
    document.getElementById('title').textContent='Detalle: '+name;
    try {
      const r=await fetch('/api/inventory/'+encodeURIComponent(name)+'?expanded=1', { cache:'no-store' });
      if(!r.ok){ throw new Error('HTTP '+r.status); }
      const j=await r.json();
      const cards = Array.isArray(j.cards) ? j.cards : [];
      const packs = Array.isArray(j.packs) ? j.packs : [];
      const html = formatTable(cards, 'Cartas') + formatTable(packs, 'Sobres');
      document.getElementById('detail').innerHTML = html;
    } catch(e) {
      document.getElementById('detail').innerHTML = '<div style="opacity:.8">(no se pudo cargar el inventario)</div>';
    }
  }
  loadUsers();
  setInterval(loadUsers, 10000);
  setInterval(()=>{ if(currentUser){ loadDetail(currentUser); } }, 10000);
  </script>
  </body></html>`);
});

// Usar variable de entorno PORT (para Render/Heroku) o 5005 localmente
let PORT = Number(process.env.PORT || 5005);
function startServer(p){
  const server = app.listen(p, () => {
    try {
      const ifaces = os.networkInterfaces();
      const addrs = [];
      Object.values(ifaces).forEach(list => (list||[]).forEach(info => { if (!info.internal && info.family === 'IPv4') addrs.push(info.address); }));
      const lan = addrs[0] ? `http://${addrs[0]}:${p}` : null;
      console.log('Inventory server listening on http://localhost:' + p + (lan ? `  (LAN: ${lan})` : ''));
    } catch {
      console.log('Inventory server listening on http://localhost:' + p);
    }
  });
  server.on('error', (err) => {
    if (err && err.code === 'EADDRINUSE' && p === 4321) {
      // puerto ocupado, probar 5005
      PORT = 5005;
      startServer(PORT);
    } else {
      console.error('[inventory-server] Failed to listen on', p, err);
      process.exit(1);
    }
  });
}
startServer(PORT);

// Página de detalle renderizada en servidor
app.get('/user/:username', (req, res) => {
  const username = String(req.params.username || '').trim();
  let data = { username, cards: {}, packs: {}, updatedAt: 0 };
  try {
    const file = userFile(username);
    if (fs.existsSync(file)) {
      const raw = JSON.parse(fs.readFileSync(file, 'utf-8'));
      data = raw || data;
    }
  } catch {}
  const expanded = expandInventory(data);
  const rowsCards = (expanded.cards||[]).map(it => `<tr><td>${it.id}</td><td>${it.name}</td><td>${it.count}</td></tr>`).join('') || '<tr><td colspan=3>(vacío)</td></tr>';
  const rowsPacks = (expanded.packs||[]).map(it => `<tr><td>${it.id}</td><td>${it.name}</td><td>${it.count}</td></tr>`).join('') || '<tr><td colspan=3>(vacío)</td></tr>';
  const w = expanded.wallet || { coins: 0, kvr: 0 };
  res.type('html').send(`<!doctype html>
  <html><head><meta charset="utf-8"/><title>Inventario de ${username}</title>
  <style>body{font-family:system-ui,Arial;background:#0d1117;color:#c9d1d9;padding:20px} a{color:#58a6ff} table{width:100%;border-collapse:collapse} th,td{border:1px solid #30363d;padding:6px;text-align:left}</style>
  </head><body>
  <h2>Inventario de ${username}</h2>
  <p><a href="/">← Volver</a></p>
  <h3>Monedas</h3>
  <ul><li>Coins: ${w.coins||0}</li><li>KvR Coins: ${w.kvr||0}</li></ul>
  <h3>Cartas</h3>
  <table><thead><tr><th>ID</th><th>Nombre</th><th>Cantidad</th></tr></thead><tbody>${rowsCards}</tbody></table>
  <h3>Sobres</h3>
  <table><thead><tr><th>ID</th><th>Nombre</th><th>Cantidad</th></tr></thead><tbody>${rowsPacks}</tbody></table>
  </body></html>`);
});
