# KVR Cards Online PVP Server - Render Configuration

## 🚀 Desplegar en Render

Este archivo contiene las instrucciones para desplegar el servidor online en Render.

### 1. Crear cuenta en Render
- Ve a https://render.com
- Crea una cuenta gratuita

### 2. Crear nuevo Web Service
- Click en "New +" → "Web Service"
- Conecta tu repositorio de GitHub o usa "Public Git repository"
- O sube los archivos manualmente

### 3. Configuración del servicio

**Build Command:**
```bash
cd server && npm install
```

**Start Command:**
```bash
cd server && node online-pvp-server.js
```

**Environment:**
- Runtime: Node
- Node Version: 18.x o superior

### 4. Variables de Entorno (opcional)
```
PORT=3001
NODE_ENV=production
```

### 5. Obtener URL del servidor
Después del despliegue, Render te dará una URL como:
```
https://kvrcards-online.onrender.com
```

### 6. Actualizar cliente
Cambia la URL en `public/app.js` línea ~16099:
```javascript
const SERVER_URL = 'https://TU-URL-DE-RENDER.onrender.com';
```

## 📁 Archivos necesarios en el repositorio

Tu repositorio debe tener esta estructura:
```
/
├── server/
│   ├── online-pvp-server.js
│   └── package.json
└── (otros archivos del proyecto)
```

## 🔧 Configuración Automática

### Usar archivo render.yaml

Crea `render.yaml` en la raíz del proyecto:

```yaml
services:
  - type: web
    name: kvrcards-online
    env: node
    region: oregon
    plan: free
    buildCommand: cd server && npm install
    startCommand: cd server && node online-pvp-server.js
    envVars:
      - key: NODE_ENV
        value: production
```

## 🆓 Plan Gratuito de Render

El plan gratuito incluye:
- 750 horas/mes de tiempo de ejecución
- El servicio se apaga después de 15 minutos de inactividad
- Se reactiva automáticamente al recibir una petición
- Suficiente para desarrollo y pruebas

## ⚡ Mantener el servidor activo

Si quieres que el servidor esté siempre activo, puedes:

1. **Usar cron-job.org (gratuito)**:
   - Crea un cron job que haga ping cada 10 minutos
   - URL: `https://tu-servidor.onrender.com/health`

2. **Usar UptimeRobot (gratuito)**:
   - Monitorea tu servicio cada 5 minutos
   - Te alerta si el servidor está caído

## 🔍 Verificar despliegue

Una vez desplegado, verifica que funciona:

```bash
curl https://tu-servidor.onrender.com/status
```

Deberías ver:
```json
{
  "status": "online",
  "connectedPlayers": 0,
  "matchmakingQueue": 0,
  "activeMatches": 0,
  "pendingRequests": 0
}
```

## 🐛 Troubleshooting

### Problema: "Service Unavailable"
- El servidor está iniciándose (tarda ~30 segundos la primera vez)
- Espera y vuelve a intentar

### Problema: "Build Failed"
- Verifica que `package.json` esté en la carpeta `server/`
- Verifica que el build command sea correcto

### Problema: "Application Error"
- Revisa los logs en el dashboard de Render
- Verifica que todas las dependencias estén instaladas

## 📊 Monitoreo

Render proporciona:
- Logs en tiempo real
- Métricas de CPU y memoria
- Historial de despliegues
- Alertas automáticas

## 🔐 Seguridad

Para producción, considera:
- Agregar autenticación de usuarios
- Rate limiting para prevenir spam
- Validación de datos del lado del servidor
- HTTPS habilitado por defecto en Render

## 💰 Costos

**Plan Gratuito** (Recomendado para empezar):
- $0/mes
- 750 horas/mes
- Suficiente para ~100 jugadores simultáneos

**Plan Starter** (Si necesitas más):
- $7/mes
- Siempre activo
- Sin límite de horas

## 🚀 Alternativas a Render

Si Render no funciona, puedes usar:
- **Railway.app** - Similar a Render
- **Fly.io** - Muy rápido, plan gratuito
- **Heroku** - Clásico, pero ya no tiene plan gratuito
- **Vercel** - Para APIs serverless

## 📱 Conectar desde el juego

Una vez desplegado:
1. Los jugadores solo abren el juego
2. Click en "Online Amistoso"
3. El juego se conecta automáticamente al servidor
4. ¡Listo para jugar!

No necesitan instalar nada ni ejecutar comandos.

## ✅ Checklist de Despliegue

- [ ] Cuenta en Render creada
- [ ] Repositorio con código subido
- [ ] Web Service creado en Render
- [ ] Build y Start commands configurados
- [ ] Despliegue completado exitosamente
- [ ] URL del servidor obtenida
- [ ] URL actualizada en `app.js`
- [ ] Cliente recompilado con nueva URL
- [ ] Prueba de conexión exitosa
- [ ] Documentación actualizada

---

¡Tu servidor online está listo para recibir jugadores de todo el mundo! 🌍
