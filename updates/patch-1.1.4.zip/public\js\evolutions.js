// ============================================
// SISTEMA DE EVOLUCIONES
// ============================================

var EVOLUTIONS_REMOTE_URL = 'https://hugom1307.github.io/kvrcards-catalog/evolutions.json';
var EVOLUTIONS_CACHE_KEY = 'kvr_evolutions_cache';
var EVOLUTIONS_CACHE_TIME_KEY = 'kvr_evolutions_cache_time';
var EVOLUTIONS_CACHE_DURATION = 10 * 60 * 1000;
var USER_EVOLUTIONS_KEY = 'kvr_user_evolutions_v2'; // Cambiado para evitar conflictos

var availableEvolutions = [];
var userEvolutions = {};
var allCardsCache = [];

async function loadEvolutions(force = false) {
  console.log('[EVOLUTIONS] Cargando evoluciones... (force=' + force + ')');
  
  if (!force) {
    const cachedEvolutions = localStorage.getItem(EVOLUTIONS_CACHE_KEY);
    const cachedTime = localStorage.getItem(EVOLUTIONS_CACHE_TIME_KEY);
    
    if (cachedEvolutions && cachedTime) {
      const elapsed = Date.now() - parseInt(cachedTime);
      if (elapsed < EVOLUTIONS_CACHE_DURATION) {
        try {
          const parsed = JSON.parse(cachedEvolutions);
          // IMPORTANTE: Solo usar caché si es un arreglo con elementos
          if (Array.isArray(parsed) && parsed.length > 0) {
            availableEvolutions = parsed;
            window.availableEvolutions = availableEvolutions;
            console.log('[EVOLUTIONS] Cargadas desde caché:', availableEvolutions.length);
            return;
          }
        } catch (e) {
          console.warn('[EVOLUTIONS] Error al parsear caché:', e);
        }
      }
    }
  }
  
  let loaded = false;

  // 1. Intentar a través de Electron IPC
  if (window.kvrcards && typeof window.kvrcards.loadEvolutions === 'function') {
    try {
      console.log('[EVOLUTIONS] Cargando via Electron IPC...');
      const result = await window.kvrcards.loadEvolutions();
      
      if (result && result.ok && Array.isArray(result.evolutions) && result.evolutions.length > 0) {
        availableEvolutions = result.evolutions;
        window.availableEvolutions = availableEvolutions;
        localStorage.setItem(EVOLUTIONS_CACHE_KEY, JSON.stringify(availableEvolutions));
        localStorage.setItem(EVOLUTIONS_CACHE_TIME_KEY, Date.now().toString());
        console.log('[EVOLUTIONS] ✅ Cargadas desde Electron IPC:', availableEvolutions.length);
        console.log('[EVOLUTIONS] Evoluciones:', availableEvolutions.map(e => e.id).join(', '));
        loaded = true;
      } else {
        console.warn('[EVOLUTIONS] Electron IPC retornó vacío o error:', result?.error);
      }
    } catch (error) {
      console.warn('[EVOLUTIONS] Error llamando a IPC loadEvolutions:', error);
    }
  }

  // 2. Si IPC no cargó evoluciones o no está disponible, intentar fetch directo desde el navegador
  if (!loaded) {
    const urls = [
      `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/evolutions.json?t=${Date.now()}`,
      `https://hugom1307.github.io/kvrcards-catalog/evolutions.json?t=${Date.now()}`,
      `./game-data/evolutions.json?t=${Date.now()}`
    ];
    for (const url of urls) {
      try {
        console.log('[EVOLUTIONS] Intentando fetch directo a:', url);
        const res = await fetch(url, { cache: 'no-store' });
        if (res.ok) {
          const json = await res.json();
          const list = Array.isArray(json) ? json : (Array.isArray(json?.evolutions) ? json.evolutions : []);
          if (list.length > 0) {
            availableEvolutions = list;
            window.availableEvolutions = availableEvolutions;
            localStorage.setItem(EVOLUTIONS_CACHE_KEY, JSON.stringify(availableEvolutions));
            localStorage.setItem(EVOLUTIONS_CACHE_TIME_KEY, Date.now().toString());
            console.log(`[EVOLUTIONS] ✅ Cargadas exitosamente por fetch directo (${url}):`, availableEvolutions.length);
            console.log('[EVOLUTIONS] Evoluciones:', availableEvolutions.map(e => e.id).join(', '));
            loaded = true;
            break;
          }
        }
      } catch (fErr) {
        console.warn('[EVOLUTIONS] Error en fetch directo a ' + url + ':', fErr);
      }
    }
  }

  if (!loaded && availableEvolutions.length === 0) {
    console.error('[EVOLUTIONS] ❌ No se pudieron cargar las evoluciones desde ninguna fuente');
  }
}

async function loadUserEvolutionsState() {
  console.log('[EVOLUTIONS] Cargando estado desde archivo...');
  
  try {
    const result = await window.kvrcards.loadEvolutionState();
    console.log('[EVOLUTIONS] Resultado de carga:', result);
    
    if (result.ok && result.data && typeof result.data === 'object' && !Array.isArray(result.data)) {
      userEvolutions = result.data;
      console.log('[EVOLUTIONS] Estado cargado correctamente:', Object.keys(userEvolutions));
    } else {
      console.log('[EVOLUTIONS] No hay estado guardado o es inválido, inicializando vacío');
      userEvolutions = {};
    }
  } catch (error) {
    console.error('[EVOLUTIONS] Error al cargar estado:', error);
    userEvolutions = {};
  }
}

async function saveUserEvolutionsState() {
  console.log('[EVOLUTIONS] Guardando estado:', userEvolutions);
  
  // Verificar que userEvolutions sea un objeto válido
  if (!userEvolutions || typeof userEvolutions !== 'object' || Array.isArray(userEvolutions)) {
    console.error('[EVOLUTIONS] ERROR: userEvolutions no es un objeto válido:', typeof userEvolutions);
    userEvolutions = {};
  }
  
  try {
    const result = await window.kvrcards.saveEvolutionState(userEvolutions);
    if (result.ok) {
      console.log('[EVOLUTIONS] Estado guardado correctamente en archivo');
    } else {
      console.error('[EVOLUTIONS] Error al guardar estado:', result.error);
    }
  } catch (error) {
    console.error('[EVOLUTIONS] Error al guardar estado:', error);
  }
}

function getEvolutionProgress(evolutionId) {
  const progress = userEvolutions[evolutionId];
  return progress || {
    started: false,
    cardId: null,
    targetCardTo: null,
    selectedCardOption: null,
    currentPhase: 1,
    totalPhases: 1,
    missionsCompleted: {},
    missionsProgress: {},
    startedAt: null,
    claimedAt: null,
    completionsCount: 0
  };
}

function getEvolutionPhases(evolution, progress = {}) {
  // 1. Si el usuario ya inició y guardó la opción elegida con sus propias fases:
  if (progress?.selectedCardOption?.phases && Array.isArray(progress.selectedCardOption.phases) && progress.selectedCardOption.phases.length > 0) {
    return progress.selectedCardOption.phases;
  }

  // 2. Si la opción elegida tiene misiones propias (fase única personalizada):
  if (progress?.selectedCardOption?.missions && Array.isArray(progress.selectedCardOption.missions) && progress.selectedCardOption.missions.length > 0) {
    return [{
      phase: 1,
      name: progress.selectedCardOption.name || evolution?.name || 'Fase 1',
      cardFrom: progress.selectedCardOption.cardFrom,
      cardTo: progress.selectedCardOption.cardTo,
      missions: progress.selectedCardOption.missions
    }];
  }

  // 3. Si el usuario ya inició con un cardId (o selectedCardFrom), buscar en cardOptions si esa carta tiene fases o misiones propias:
  const activeCardId = progress?.selectedCardFrom || progress?.cardId;
  if (activeCardId && Array.isArray(evolution?.cardOptions)) {
    const matchedOpt = evolution.cardOptions.find(opt => 
      opt && (opt.cardFrom === activeCardId || String(opt.cardFrom).toLowerCase() === String(activeCardId).toLowerCase())
    );
    if (matchedOpt) {
      if (Array.isArray(matchedOpt.phases) && matchedOpt.phases.length > 0) {
        return matchedOpt.phases;
      }
      if (Array.isArray(matchedOpt.missions) && matchedOpt.missions.length > 0) {
        return [{
          phase: 1,
          name: matchedOpt.name || evolution?.name || 'Fase 1',
          cardFrom: matchedOpt.cardFrom,
          cardTo: matchedOpt.cardTo,
          missions: matchedOpt.missions
        }];
      }
    }
  }

  // 4. Fases a nivel raíz de la evolución (si las hay):
  if (Array.isArray(evolution?.phases) && evolution.phases.length > 0) {
    return evolution.phases;
  }

  // 5. Fallback estándar a nivel raíz:
  return [{
    phase: 1,
    name: evolution?.name || 'Fase 1',
    cardFrom: evolution?.cardFrom,
    cardTo: evolution?.cardTo,
    missions: Array.isArray(evolution?.missions) ? evolution.missions : []
  }];
}

function getCurrentPhaseData(evolution, progress = {}) {
  const phases = getEvolutionPhases(evolution, progress);
  const currentPhaseNum = Math.max(1, Math.min(progress.currentPhase || 1, phases.length));
  const phaseIndex = currentPhaseNum - 1;
  const phase = phases[phaseIndex] || phases[0] || {};

  let cardFromId = phase.cardFrom || evolution.cardFrom;
  let cardToId = phase.cardTo || evolution.cardTo;

  if (progress.started) {
    if (progress.cardId) cardFromId = progress.cardId;
    if (progress.targetCardTo) cardToId = progress.targetCardTo;
  } else if (!cardFromId && Array.isArray(evolution.cardOptions) && evolution.cardOptions.length > 0) {
    const firstOpt = evolution.cardOptions[0];
    cardFromId = firstOpt.cardFrom;
    if (Array.isArray(firstOpt.phases) && firstOpt.phases.length > 0) {
      cardToId = firstOpt.phases[0].cardTo;
    } else if (firstOpt.phaseRewards && firstOpt.phaseRewards.length > 0) {
      cardToId = firstOpt.phaseRewards[0];
    } else {
      cardToId = firstOpt.cardTo;
    }
  }

  return {
    phaseIndex,
    phaseNumber: currentPhaseNum,
    totalPhases: phases.length,
    phaseName: phase.name || `Fase ${currentPhaseNum}`,
    cardFrom: cardFromId,
    cardTo: cardToId,
    missions: Array.isArray(phase.missions) ? phase.missions : []
  };
}

async function renderEvolutions() {
  console.log('[EVOLUTIONS] Renderizando...');
  
  const featuredContainer = document.getElementById('evolutions-featured');
  const eventContainer = document.getElementById('evolutions-event');
  
  if (!featuredContainer || !eventContainer) return;
  
  featuredContainer.innerHTML = '';
  eventContainer.innerHTML = '';
  
  if (availableEvolutions.length === 0) {
    featuredContainer.innerHTML = '<p class="info-message">No hay evoluciones destacadas disponibles</p>';
    eventContainer.innerHTML = '<p class="info-message">No hay evoluciones de evento disponibles</p>';
    return;
  }
  
  for (const evolution of availableEvolutions) {
    const card = createEvolutionCard(evolution);
    if (evolution.type === 'featured') {
      featuredContainer.appendChild(card);
    } else if (evolution.type === 'event') {
      eventContainer.appendChild(card);
    }
  }
}

function createEvolutionCard(evolution) {
  const progress = getEvolutionProgress(evolution.id);
  const phaseInfo = getCurrentPhaseData(evolution, progress);

  let cardFromObj = allCardsCache?.find(c => c && (c.id === phaseInfo.cardFrom || String(c.id).toLowerCase() === String(phaseInfo.cardFrom).toLowerCase()));
  let cardToObj = allCardsCache?.find(c => c && (c.id === phaseInfo.cardTo || String(c.id).toLowerCase() === String(phaseInfo.cardTo).toLowerCase()));

  // Fallback si es multi-carta antes de iniciar
  if (!cardFromObj && !progress.started && Array.isArray(evolution.cardOptions)) {
    for (const opt of evolution.cardOptions) {
      const cF = allCardsCache?.find(c => c && (c.id === opt.cardFrom || String(c.id).toLowerCase() === String(opt.cardFrom).toLowerCase()));
      if (cF) {
        cardFromObj = cF;
        const targetId = opt.phaseRewards ? opt.phaseRewards[opt.phaseRewards.length - 1] : opt.cardTo;
        cardToObj = allCardsCache?.find(c => c && (c.id === targetId || String(c.id).toLowerCase() === String(targetId).toLowerCase()));
        break;
      }
    }
  }

  const isRepeatable = Boolean(evolution.repeatable);
  const maxCompletions = Number(evolution.maxCompletions) || 0;
  const completionsCount = Number(progress.completionsCount) || 0;
  const isCompletelyFinished = progress.claimedAt && (!isRepeatable || (maxCompletions > 0 && completionsCount >= maxCompletions));

  const totalMissions = phaseInfo.missions.length;
  const completedMissions = phaseInfo.missions.filter(m => progress.missionsCompleted && progress.missionsCompleted[m.id]).length;
  const progressPercent = totalMissions > 0 ? (completedMissions / totalMissions) * 100 : 0;

  let status = 'locked';
  let statusText = '🔒 Bloqueado';
  let buttonText = 'Iniciar Evolución';
  let buttonClass = 'start';
  let buttonDisabled = false;

  if (isCompletelyFinished) {
    status = 'completed';
    statusText = maxCompletions > 0 ? `✅ Completado (${completionsCount}/${maxCompletions})` : '✅ Completado';
    buttonText = 'Evolución Reclamada';
    buttonDisabled = true;
  } else if (progress.started) {
    status = 'in-progress';
    const isLastPhase = phaseInfo.phaseNumber >= phaseInfo.totalPhases;
    statusText = `⏳ En Progreso (${completedMissions}/${totalMissions})`;

    if (completedMissions === totalMissions && totalMissions > 0) {
      status = 'claimable';
      if (isLastPhase) {
        statusText = '🎉 ¡Listo para Reclamar!';
        buttonText = 'Reclamar Evolución';
      } else {
        statusText = `✨ ¡Fase ${phaseInfo.phaseNumber} Completada!`;
        buttonText = `Completar Fase ${phaseInfo.phaseNumber}`;
      }
      buttonClass = 'claim';
    } else {
      buttonText = 'Continuar';
      buttonClass = 'start';
    }
  } else if (completionsCount > 0 && isRepeatable) {
    statusText = maxCompletions > 0 ? `🔄 Repetible (${completionsCount}/${maxCompletions})` : `🔄 Repetible (${completionsCount} veces)`;
    buttonText = 'Reiniciar Evolución';
  }

  const card = document.createElement('div');
  card.className = `evolution-card ${status}`;
  card.innerHTML = `
    <div class="evolution-card-header">
      <div class="evolution-badges-container">
        ${phaseInfo.totalPhases > 1 ? `<span class="evolution-phase-badge">⚡ Fase ${phaseInfo.phaseNumber}/${phaseInfo.totalPhases}</span>` : ''}
        ${isRepeatable ? `<span class="evolution-repeatable-badge">🔄 Repetible ${maxCompletions > 0 ? `(${completionsCount}/${maxCompletions})` : ''}</span>` : ''}
        ${Array.isArray(evolution.cardOptions) && evolution.cardOptions.length > 1 ? `<span class="evolution-branch-badge">🔀 Multi-Carta</span>` : ''}
      </div>
      <h4 class="evolution-name">${evolution.name}</h4>
      <p class="evolution-card-name">${progress.started ? (cardFromObj?.name || 'Carta activa') : (Array.isArray(evolution.cardOptions) ? `${evolution.cardOptions.length} cartas elegibles` : (cardFromObj?.name || phaseInfo.phaseName))}</p>
    </div>
    
    <div class="evolution-display">
      <div class="evolution-card-preview-wrap">
        <img src="${cardFromObj?.imageUrl || './assets/default-card.png'}" 
             alt="${cardFromObj?.name || 'Carta Base'}" 
             class="evolution-card-img"
             onclick="openLightbox('${cardFromObj?.imageUrl || './assets/default-card.png'}')">
        <span class="evolution-mini-label">${cardFromObj?.name || 'Base'}</span>
      </div>
      <span class="evolution-arrow">→</span>
      <div class="evolution-card-preview-wrap">
        <img src="${cardToObj?.imageUrl || './assets/default-card.png'}" 
             alt="${cardToObj?.name || 'Carta Destino'}" 
             class="evolution-card-img"
             onclick="openLightbox('${cardToObj?.imageUrl || './assets/default-card.png'}')">
        <span class="evolution-mini-label">${cardToObj?.name || 'Evolución'}</span>
      </div>
    </div>
    
    <div class="evolution-status ${status}">${statusText}</div>
    
    ${progress.started && !progress.claimedAt ? `
      <div class="evolution-progress">
        <div class="progress-header">
          <p class="progress-title">${phaseInfo.phaseName} - Misiones</p>
          <span class="progress-count">${completedMissions}/${totalMissions}</span>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width: ${progressPercent}%"></div>
        </div>
      </div>
      
      <div class="evolution-missions">
        ${phaseInfo.missions.map(mission => {
          const targetAmount = mission.target || 
            (Array.isArray(mission.requirements) ? mission.requirements[0]?.amount : null) || 
            (Array.isArray(mission.requirement) ? mission.requirement[0]?.amount : null) || 
            mission.requirement?.amount || 1;
          const missionProgress = progress.missionsProgress?.[mission.id] || { current: 0, target: targetAmount };
          const displayTarget = missionProgress.target || targetAmount;
          const isCompleted = Boolean(progress.missionsCompleted?.[mission.id] || (missionProgress.current || 0) >= displayTarget);
          const progressText = `${Math.min(missionProgress.current || 0, displayTarget)}/${displayTarget}`;
          return `
            <div class="evolution-mission-item">
              <div class="mission-checkbox ${isCompleted ? 'completed' : ''}"></div>
              <span class="mission-text ${isCompleted ? 'completed' : ''}">${mission.description}</span>
              <span class="mission-progress ${isCompleted ? 'completed' : ''}">${progressText}</span>
            </div>
          `;
        }).join('')}
      </div>
    ` : ''}
    
    <div class="evolution-action">
      <button class="evolution-btn ${buttonClass}" 
              data-evolution-id="${evolution.id}"
              ${buttonDisabled ? 'disabled' : ''}>
        ${buttonText}
      </button>
    </div>
  `;
  
  const button = card.querySelector('.evolution-btn');
  button.addEventListener('click', () => handleEvolutionAction(evolution, progress));
  
  return card;
}

async function handleEvolutionAction(evolution, progress) {
  const isRepeatable = Boolean(evolution.repeatable);
  const maxCompletions = Number(evolution.maxCompletions) || 0;
  const completionsCount = Number(progress.completionsCount) || 0;
  const isCompletelyFinished = progress.claimedAt && (!isRepeatable || (maxCompletions > 0 && completionsCount >= maxCompletions));

  if (isCompletelyFinished) return;
  
  const phaseInfo = getCurrentPhaseData(evolution, progress);
  const totalMissions = phaseInfo.missions.length;
  const completedMissions = phaseInfo.missions.filter(m => progress.missionsCompleted && progress.missionsCompleted[m.id]).length;
  
  if (!progress.started) {
    await openCardSelectionModal(evolution);
  } else if (completedMissions === totalMissions && totalMissions > 0) {
    await claimEvolution(evolution, progress);
  } else {
    alert(`Progreso de ${phaseInfo.phaseName}: ${completedMissions}/${totalMissions} misiones completadas.`);
  }
}

async function openCardSelectionModal(evolution) {
  const modal = document.getElementById('evolution-card-select-modal');
  const inventoryContainer = document.getElementById('evolution-card-inventory');
  const closeBtn = document.getElementById('evolution-select-close');
  
  if (!modal || !inventoryContainer) return;
  
  const inv = await window.kvrcards.getInventory();
  if (!inv.ok) {
    alert('❌ Error al cargar el inventario');
    return;
  }

  // Si allCardsCache no está listo, cargarlo
  if (!Array.isArray(allCardsCache) || allCardsCache.length === 0) {
    allCardsCache = await window.kvrcards.getAllCards();
  }

  // Recopilar opciones elegibles
  const defaultPhases = getEvolutionPhases(evolution);
  const firstPhase = defaultPhases[0] || {};
  let eligibleOptions = [];

  if (Array.isArray(evolution.cardOptions) && evolution.cardOptions.length > 0) {
    eligibleOptions = evolution.cardOptions;
  } else {
    eligibleOptions = [{
      cardFrom: firstPhase.cardFrom || evolution.cardFrom,
      cardTo: firstPhase.cardTo || evolution.cardTo,
      phases: defaultPhases
    }];
  }

  const validCards = [];
  for (const opt of eligibleOptions) {
    const cardId = opt.cardFrom;
    const count = inv.cards ? (inv.cards[cardId] || 0) : 0;
    if (count > 0) {
      const baseCard = allCardsCache.find(c => c && (c.id === cardId || String(c.id).toLowerCase() === String(cardId).toLowerCase()));
      
      let optPhases = [];
      if (Array.isArray(opt.phases) && opt.phases.length > 0) {
        optPhases = opt.phases;
      } else if (Array.isArray(opt.missions) && opt.missions.length > 0) {
        optPhases = [{ phase: 1, name: opt.name || 'Fase 1', cardFrom: opt.cardFrom, cardTo: opt.cardTo, missions: opt.missions }];
      } else if (Array.isArray(evolution.phases) && evolution.phases.length > 0) {
        optPhases = evolution.phases;
      }

      let finalTargetId = null;
      let firstTargetId = null;
      if (optPhases.length > 0) {
        firstTargetId = optPhases[0].cardTo;
        finalTargetId = optPhases[optPhases.length - 1].cardTo;
      } else if (opt.phaseRewards && opt.phaseRewards.length > 0) {
        firstTargetId = opt.phaseRewards[0];
        finalTargetId = opt.phaseRewards[opt.phaseRewards.length - 1];
      } else {
        firstTargetId = opt.cardTo || firstPhase.cardTo || evolution.cardTo;
        finalTargetId = opt.cardTo || firstPhase.cardTo || evolution.cardTo;
      }

      const targetCard = allCardsCache.find(c => c && (c.id === finalTargetId || String(c.id).toLowerCase() === String(finalTargetId).toLowerCase()));
      const totalPhases = optPhases.length || 1;

      if (baseCard) {
        validCards.push({
          cardId,
          count,
          card: baseCard,
          targetCard,
          firstTargetId,
          finalTargetId,
          totalPhases,
          cardOption: opt
        });
      }
    }
  }

  if (validCards.length === 0) {
    const cardNames = eligibleOptions.map(o => {
      const c = allCardsCache?.find(x => x.id === o.cardFrom);
      return c ? c.name : o.cardFrom;
    }).join(', ');
    alert(`❌ No tienes ninguna de las cartas requeridas en tu inventario.\nRequiere: ${cardNames}`);
    return;
  }

  inventoryContainer.innerHTML = validCards.map((item, idx) => {
    return `
      <div class="evolution-inventory-card" data-card-id="${item.cardId}" data-option-index="${idx}">
        <img src="${item.card.imageUrl || './assets/default-card.png'}" alt="${item.card.name}">
        <p class="inv-card-name" style="color: white; font-weight: 600; margin: 5px 0 2px 0;">${item.card.name}</p>
        <p class="card-media" style="color: #cbd5e1; font-size: 13px; margin: 2px 0;">Media: ${item.card.media || item.card.stats?.media || '??'}</p>
        <p class="card-count" style="color: #94a3b8; font-size: 12px; margin: 2px 0;">En inventario: ${item.count}</p>
        ${item.totalPhases > 1 ? `<span style="display:inline-block; margin-top:4px; font-size:10px; font-weight:bold; color:#a78bfa; background:rgba(139,92,246,0.25); border:1px solid #8b5cf6; padding:2px 8px; border-radius:10px;">${item.totalPhases} Fases</span>` : ''}
        ${item.targetCard ? `
          <div class="card-option-reward-preview" style="font-size: 11px; color: #38bdf8; font-weight: 600; margin-top: 4px;">
            Evoluciona a:<br>➔ ${item.targetCard.name}
          </div>
        ` : ''}
      </div>
    `;
  }).join('');

  inventoryContainer.querySelectorAll('.evolution-inventory-card').forEach(cardEl => {
    const cardId = cardEl.getAttribute('data-card-id');
    const optIndex = parseInt(cardEl.getAttribute('data-option-index'), 10);
    const chosenItem = validCards[optIndex];
    
    cardEl.addEventListener('click', () => {
      startEvolution(evolution, cardId, chosenItem?.cardOption);
      modal.style.display = 'none';
    });
  });

  modal.style.display = 'flex';
  closeBtn.onclick = () => modal.style.display = 'none';
  modal.onclick = (e) => {
    if (e.target === modal) modal.style.display = 'none';
  };
}

function startEvolution(evolution, cardId, cardOption = null, silent = false) {
  console.log('[EVOLUTIONS] Iniciando evolución:', evolution.id, 'con carta:', cardId, 'opción:', cardOption);
  
  if (userEvolutions[evolution.id]?.started && !userEvolutions[evolution.id]?.claimedAt) {
    if (!silent) alert('⚠️ Ya has iniciado esta evolución');
    return;
  }

  const phases = getEvolutionPhases(evolution, { selectedCardOption: cardOption, cardId: cardId });
  const firstPhase = phases[0] || {};
  
  let targetCardTo = firstPhase.cardTo;
  if (!targetCardTo) {
    if (cardOption) {
      targetCardTo = (cardOption.phaseRewards && cardOption.phaseRewards[0]) ? cardOption.phaseRewards[0] : (cardOption.cardTo || evolution.cardTo);
    } else {
      targetCardTo = evolution.cardTo;
    }
  }

  const missionsCompleted = {};
  const missionsProgress = {};
  (firstPhase.missions || []).forEach(mission => {
    missionsCompleted[mission.id] = false;
    const targetValue = mission.target || 
      (Array.isArray(mission.requirements) ? mission.requirements[0]?.amount : null) || 
      (Array.isArray(mission.requirement) ? mission.requirement[0]?.amount : null) || 
      mission.requirement?.amount || 1;
    missionsProgress[mission.id] = {
      current: 0,
      target: targetValue,
      completed: false
    };
  });

  const previousCompletions = userEvolutions[evolution.id]?.completionsCount || 0;

  const evolutionState = {
    started: true,
    cardId: cardId,
    selectedCardFrom: cardId,
    targetCardTo: targetCardTo,
    selectedCardOption: cardOption,
    currentPhase: 1,
    totalPhases: phases.length,
    missionsCompleted: missionsCompleted,
    missionsProgress: missionsProgress,
    startedAt: Date.now(),
    claimedAt: null,
    completionsCount: previousCompletions
  };

  userEvolutions[evolution.id] = evolutionState;
  saveUserEvolutionsState();
  renderEvolutions();
  if (!silent) {
    alert(`✅ ¡Evolución iniciada con ${cardId}! Completa las misiones de ${firstPhase.name || 'la Fase 1'}.`);
  }
}

async function claimEvolution(evolution, progress, silent = false) {
  try {
    const phases = getEvolutionPhases(evolution, progress);
    const currentPhaseNum = progress.currentPhase || 1;
    const currentPhaseIndex = currentPhaseNum - 1;
    const currentPhaseData = phases[currentPhaseIndex] || phases[0];
    const missions = currentPhaseData.missions || [];

    const allCompleted = missions.every(mission => 
      progress.missionsCompleted[mission.id]
    );
    
    if (!allCompleted) {
      alert('❌ Aún no has completado todas las misiones de esta fase');
      return;
    }
    
    const currentCardId = progress.cardId;
    const targetCardId = progress.targetCardTo;

    // Vender (eliminar) la carta original usando el cardId
    const removeResult = await window.kvrcards.sellCard(currentCardId);
    if (!removeResult.ok) {
      alert('❌ Error al eliminar la carta original');
      return;
    }
    
    const addResult = await window.kvrcards.addCard(targetCardId);
    if (!addResult.ok) {
      alert('❌ Error al añadir la carta evolucionada');
      return;
    }

    // Notificar al sistema de evoluciones la carta obtenida
    if (typeof window.recordEvolutionCardObtained === 'function') {
      window.recordEvolutionCardObtained(targetCardId, 1);
    }

    // Asegurar que allCardsCache esté disponible para obtener la carta evolucionada exacta
    if (!Array.isArray(allCardsCache) || allCardsCache.length === 0) {
      if (typeof window.kvrcards?.getAllCards === 'function') {
        const res = await window.kvrcards.getAllCards();
        allCardsCache = Array.isArray(res) ? res : (Array.isArray(res?.cards) ? res.cards : (res ? Object.values(res) : []));
      }
    }

    const cardTo = (Array.isArray(allCardsCache) ? allCardsCache : []).find(c => c && (c.id === targetCardId || String(c.id).toLowerCase() === String(targetCardId).toLowerCase()));
    const cardToName = cardTo?.name || cardTo?.nombre || 'Carta Evolucionada';
    const cardToImage = cardTo?.imageUrl || cardTo?.image || cardTo?.imagen || '';

    const isFinalPhase = currentPhaseNum >= phases.length;

    if (!isFinalPhase) {
      // Avanzar a la siguiente fase
      const nextPhaseIndex = currentPhaseNum; // 0-indexed para la siguiente
      const nextPhaseData = phases[nextPhaseIndex];
      const nextCardBase = targetCardId; // La carta evolucionada pasa a ser la base automáticamente

      let nextTargetCardTo = nextPhaseData.cardTo;
      if (!nextTargetCardTo && progress.selectedCardOption && Array.isArray(progress.selectedCardOption.phaseRewards) && progress.selectedCardOption.phaseRewards[nextPhaseIndex]) {
        nextTargetCardTo = progress.selectedCardOption.phaseRewards[nextPhaseIndex];
      }
      if (!nextTargetCardTo) {
        nextTargetCardTo = evolution.cardTo;
      }

      const nextMissionsCompleted = {};
      const nextMissionsProgress = {};
      (nextPhaseData.missions || []).forEach(mission => {
        nextMissionsCompleted[mission.id] = false;
        const targetValue = mission.target || 
          (Array.isArray(mission.requirements) ? mission.requirements[0]?.amount : null) || 
          (Array.isArray(mission.requirement) ? mission.requirement[0]?.amount : null) || 
          mission.requirement?.amount || 1;
        nextMissionsProgress[mission.id] = {
          current: 0,
          target: targetValue,
          completed: false
        };
      });

      progress.currentPhase = currentPhaseNum + 1;
      progress.cardId = nextCardBase;
      progress.targetCardTo = nextTargetCardTo;
      progress.missionsCompleted = nextMissionsCompleted;
      progress.missionsProgress = nextMissionsProgress;

      saveUserEvolutionsState();
      renderEvolutions();
      if (typeof window.updateGlobalNotificationBadges === 'function') {
        window.updateGlobalNotificationBadges();
      }

      if (!silent) {
        if (typeof window.showUnifiedRewardsHUD === 'function') {
          await window.showUnifiedRewardsHUD([{
            type: 'card',
            cardId: targetCardId,
            id: targetCardId,
            amount: 1,
            name: cardToName,
            imageUrl: cardToImage
          }], `¡FASE ${currentPhaseNum} COMPLETADA!`);
        } else {
          alert(`🎉 ¡Fase ${currentPhaseNum} completada! Has obtenido: ${cardToName}. ¡Comienza la Fase ${progress.currentPhase}!`);
        }
      }

    } else {
      // Fase final completada
      const newCompletions = (progress.completionsCount || 0) + 1;
      const isRepeatable = Boolean(evolution.repeatable);
      const maxCompletions = Number(evolution.maxCompletions) || 0;
      const canRepeat = isRepeatable && (!maxCompletions || newCompletions < maxCompletions);

      if (canRepeat) {
        userEvolutions[evolution.id] = {
          started: false,
          cardId: null,
          targetCardTo: null,
          selectedCardOption: null,
          currentPhase: 1,
          totalPhases: phases.length,
          missionsCompleted: {},
          missionsProgress: {},
          startedAt: null,
          claimedAt: null,
          completionsCount: newCompletions
        };
      } else {
        userEvolutions[evolution.id].claimedAt = Date.now();
        userEvolutions[evolution.id].completionsCount = newCompletions;
      }

      saveUserEvolutionsState();
      renderEvolutions();
      if (typeof window.updateGlobalNotificationBadges === 'function') {
        window.updateGlobalNotificationBadges();
      }

      if (!silent) {
        if (typeof window.showUnifiedRewardsHUD === 'function') {
          await window.showUnifiedRewardsHUD([{
            type: 'card',
            cardId: targetCardId,
            id: targetCardId,
            amount: 1,
            name: cardToName,
            imageUrl: cardToImage
          }], '¡EVOLUCIÓN COMPLETADA!');
        } else {
          alert(`🎉 ¡Evolución completada! Has obtenido: ${cardToName}`);
        }
      }
    }
    
  } catch (error) {
    console.error('[EVOLUTIONS] Error al reclamar:', error);
    if (!silent) alert('❌ Error al reclamar la evolución');
  }
}

function setupEvolutionCategoryButtons() {
  const buttons = document.querySelectorAll('.evolution-category-btn');
  console.log('[EVOLUTIONS] Configurando botones:', buttons.length);
  
  buttons.forEach(btn => {
    // Clonar el botón para eliminar event listeners previos
    const newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);
    
    newBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      const category = newBtn.getAttribute('data-category');
      console.log('[EVOLUTIONS] Click en categoría:', category);
      
      // Actualizar botones activos
      document.querySelectorAll('.evolution-category-btn').forEach(b => b.classList.remove('active'));
      newBtn.classList.add('active');
      
      // Ocultar todos los contenedores
      document.querySelectorAll('.evolutions-container').forEach(container => {
        container.style.display = 'none';
        container.classList.remove('active');
      });
      
      // Mostrar el contenedor seleccionado
      const targetContainer = document.getElementById(`evolutions-${category}`);
      console.log('[EVOLUTIONS] Mostrando contenedor:', category, targetContainer);
      if (targetContainer) {
        targetContainer.style.display = 'grid';
        targetContainer.classList.add('active');
        console.log('[EVOLUTIONS] Contenedor visible:', targetContainer.style.display);
      }
    });
  });
}

async function checkEvolutionMissions(shouldRender = false) {
  console.log('[EVOLUTIONS] Verificando progreso de misiones...');
  
  if (!availableEvolutions || !Array.isArray(availableEvolutions)) {
    console.log('[EVOLUTIONS] availableEvolutions no está disponible aún');
    return false;
  }
  
  if (typeof userEvolutions === 'undefined' || !userEvolutions) {
    console.log('[EVOLUTIONS] userEvolutions no está disponible aún');
    return false;
  }
  
  let updated = false;
  let progressChanged = false;
  
  for (const evolution of availableEvolutions) {
    const progress = userEvolutions[evolution.id];
    if (!progress || !progress.started || progress.claimedAt) continue;
    
    const currentPhaseData = getCurrentPhaseData(evolution, progress);
    
    if (!progress.missionsProgress) {
      progress.missionsProgress = {};
      updated = true;
    }
    
    for (const mission of currentPhaseData.missions) {
      const target = mission.target || 
        (Array.isArray(mission.requirements) ? mission.requirements[0]?.amount : null) || 
        (Array.isArray(mission.requirement) ? mission.requirement[0]?.amount : null) || 
        mission.requirement?.amount || 1;
      
      // Inicializar progreso si no existe
      if (!progress.missionsProgress[mission.id] || !progress.missionsProgress[mission.id].target) {
        progress.missionsProgress[mission.id] = { current: 0, target: target, completed: false };
        updated = true;
      }
      
      // Actualizar target si cambió
      if (progress.missionsProgress[mission.id].target !== target) {
        progress.missionsProgress[mission.id].target = target;
        updated = true;
      }
      
      // Si ya está completada, continuar
      if (progress.missionsCompleted[mission.id]) {
        progress.missionsProgress[mission.id].completed = true;
        continue;
      }
      
      // Si es un evento manejado en tiempo real, solo verificar si ya alcanzó el target
      const liveEventTypes = [
        'rounds_won', 'card_rounds_won', 'rounds_won_with_filter',
        'play_games_with_card', 'games_played_with_card',
        'win_games_with_card', 'win_games_with_filter',
        'obtain_card', 'duplicate_card'
      ];

      if (liveEventTypes.includes(mission.type)) {
        const curr = progress.missionsProgress[mission.id]?.current || 0;
        if (curr >= target && !progress.missionsCompleted[mission.id]) {
          progress.missionsCompleted[mission.id] = true;
          progress.missionsProgress[mission.id].completed = true;
          updated = true;
          progressChanged = true;
        }
        continue;
      }
      
      // Añadir evolutionId para misiones evaluadas por missions.js
      mission.evolutionId = evolution.id;
      
      const currentProgress = await checkMissionProgress(mission);
      
      if (progress.missionsProgress[mission.id].current !== currentProgress) {
        progress.missionsProgress[mission.id].current = currentProgress;
        updated = true;
        progressChanged = true;
      }
      
      if (currentProgress >= target && !progress.missionsCompleted[mission.id]) {
        console.log(`[EVOLUTIONS] ✅ Misión completada: ${mission.description}`);
        progress.missionsCompleted[mission.id] = true;
        progress.missionsProgress[mission.id].completed = true;
        updated = true;
        progressChanged = true;
      }
    }
  }
  
  if (updated) {
    saveUserEvolutionsState();
  }
  
  if (progressChanged && shouldRender) {
    await renderEvolutions();
  }
  
  return updated;
}

// ============================================
// HOOKS Y DISPATCHERS DE EVENTOS EN VIVO
// ============================================

window.recordEvolutionRoundWon = function(playerCard) {
  if (!availableEvolutions || !userEvolutions) return;
  let updated = false;

  for (const evolution of availableEvolutions) {
    const progress = userEvolutions[evolution.id];
    if (!progress || !progress.started || progress.claimedAt) continue;

    const currentPhaseData = getCurrentPhaseData(evolution, progress);
    for (const mission of currentPhaseData.missions) {
      if (progress.missionsCompleted[mission.id]) continue;

      let isMatch = false;
      const mType = mission.type;

      if (mType === 'rounds_won' || mType === 'card_rounds_won') {
        if (mission.cardRequired !== false) {
          isMatch = Boolean(playerCard && (playerCard.id === progress.cardId || playerCard.uniqueCardId === progress.cardId || String(playerCard.id).toLowerCase() === String(progress.cardId).toLowerCase()));
        } else {
          isMatch = true;
        }
      } else if (mType === 'rounds_won_with_filter') {
        isMatch = true;
        if (mission.origin && playerCard?.origin !== mission.origin && playerCard?.procedencia !== mission.origin) {
          isMatch = false;
        }
        if (mission.owner && playerCard?.owner !== mission.owner && playerCard?.dueno !== mission.owner) {
          isMatch = false;
        }
        if (mission.quality) {
          const cardQuality = (playerCard?.quality || playerCard?.calidad || '').toLowerCase();
          if (cardQuality !== mission.quality.toLowerCase()) isMatch = false;
        }
      }

      if (isMatch) {
        if (!progress.missionsProgress[mission.id]) {
          progress.missionsProgress[mission.id] = { current: 0, target: mission.target || 1, completed: false };
        }
        progress.missionsProgress[mission.id].current = (progress.missionsProgress[mission.id].current || 0) + 1;
        const target = progress.missionsProgress[mission.id].target || mission.target || 1;
        if (progress.missionsProgress[mission.id].current >= target) {
          progress.missionsProgress[mission.id].completed = true;
          progress.missionsCompleted[mission.id] = true;
        }
        updated = true;
        console.log(`[EVOLUTIONS] 🎯 Ronda ganada sumada a ${evolution.id}.${mission.id}: ${progress.missionsProgress[mission.id].current}/${target}`);
      }
    }
  }

  if (updated) {
    saveUserEvolutionsState();
    const activeTab = document.querySelector('.collectible-tab.active');
    if (activeTab && activeTab.getAttribute('data-tab') === 'evolutions') {
      renderEvolutions();
    }
  }
};

window.recordEvolutionBattleEnded = function(playerTeam, playerWon) {
  if (!availableEvolutions || !userEvolutions) return;
  let updated = false;

  const teamCards = Array.isArray(playerTeam) ? playerTeam : [];

  for (const evolution of availableEvolutions) {
    const progress = userEvolutions[evolution.id];
    if (!progress || !progress.started || progress.claimedAt) continue;

    const currentPhaseData = getCurrentPhaseData(evolution, progress);
    const hasEvolutionCardInTeam = teamCards.some(c => c && (c.id === progress.cardId || c.uniqueCardId === progress.cardId || c === progress.cardId || String(c.id).toLowerCase() === String(progress.cardId).toLowerCase()));

    for (const mission of currentPhaseData.missions) {
      if (progress.missionsCompleted[mission.id]) continue;

      let isMatch = false;
      const mType = mission.type;

      if (mType === 'play_games_with_card' || mType === 'games_played_with_card') {
        isMatch = hasEvolutionCardInTeam;
      } else if (mType === 'win_games_with_card') {
        isMatch = Boolean(playerWon && hasEvolutionCardInTeam);
      } else if (mType === 'win_games_with_filter') {
        if (playerWon) {
          isMatch = teamCards.some(card => {
            if (!card) return false;
            let match = true;
            if (mission.origin && card.origin !== mission.origin && card.procedencia !== mission.origin) match = false;
            if (mission.owner && card.owner !== mission.owner && card.dueno !== mission.owner) match = false;
            if (mission.quality) {
              const q = (card.quality || card.calidad || '').toLowerCase();
              if (q !== mission.quality.toLowerCase()) match = false;
            }
            return match;
          });
        }
      }

      if (isMatch) {
        if (!progress.missionsProgress[mission.id]) {
          progress.missionsProgress[mission.id] = { current: 0, target: mission.target || 1, completed: false };
        }
        progress.missionsProgress[mission.id].current = (progress.missionsProgress[mission.id].current || 0) + 1;
        const target = progress.missionsProgress[mission.id].target || mission.target || 1;
        if (progress.missionsProgress[mission.id].current >= target) {
          progress.missionsProgress[mission.id].completed = true;
          progress.missionsCompleted[mission.id] = true;
        }
        updated = true;
        console.log(`[EVOLUTIONS] ⚔️ Partida procesada en ${evolution.id}.${mission.id}: ${progress.missionsProgress[mission.id].current}/${target}`);
      }
    }
  }

  if (updated) {
    saveUserEvolutionsState();
    const activeTab = document.querySelector('.collectible-tab.active');
    if (activeTab && activeTab.getAttribute('data-tab') === 'evolutions') {
      renderEvolutions();
    }
  }
};

window.recordEvolutionCardObtained = function(cardId, quantity = 1) {
  if (!availableEvolutions || !userEvolutions || !cardId) return;
  let updated = false;

  for (const evolution of availableEvolutions) {
    const progress = userEvolutions[evolution.id];
    if (!progress || !progress.started || progress.claimedAt) continue;

    const currentPhaseData = getCurrentPhaseData(evolution, progress);
    for (const mission of currentPhaseData.missions) {
      if (progress.missionsCompleted[mission.id]) continue;

      if (mission.type === 'obtain_card' || mission.type === 'duplicate_card') {
        const targetId = mission.cardId || progress.cardId;
        if (cardId === targetId || String(cardId).toLowerCase() === String(targetId).toLowerCase()) {
          if (!progress.missionsProgress[mission.id]) {
            progress.missionsProgress[mission.id] = { current: 0, target: mission.target || 1, completed: false };
          }
          progress.missionsProgress[mission.id].current = (progress.missionsProgress[mission.id].current || 0) + Number(quantity || 1);
          const target = progress.missionsProgress[mission.id].target || mission.target || 1;
          if (progress.missionsProgress[mission.id].current >= target) {
            progress.missionsProgress[mission.id].completed = true;
            progress.missionsCompleted[mission.id] = true;
          }
          updated = true;
          console.log(`[EVOLUTIONS] 🃏 Carta obtenida sumada a ${evolution.id}.${mission.id}: ${progress.missionsProgress[mission.id].current}/${target}`);
        }
      }
    }
  }

  if (updated) {
    saveUserEvolutionsState();
    const activeTab = document.querySelector('.collectible-tab.active');
    if (activeTab && activeTab.getAttribute('data-tab') === 'evolutions') {
      renderEvolutions();
    }
  }
};

window.recordEvolutionMissionCompleted = function(missionId) {
  if (!availableEvolutions || !userEvolutions || !missionId) return;
  let updated = false;

  for (const evolution of availableEvolutions) {
    const progress = userEvolutions[evolution.id];
    if (!progress || !progress.started || progress.claimedAt) continue;

    const currentPhaseData = getCurrentPhaseData(evolution, progress);
    for (const mission of currentPhaseData.missions) {
      if (progress.missionsCompleted[mission.id]) continue;

      if (mission.type === 'complete_specific_mission') {
        const requiredId = mission.targetMissionId || mission.missionId;
        if (requiredId === missionId) {
          if (!progress.missionsProgress[mission.id]) {
            progress.missionsProgress[mission.id] = { current: 0, target: 1, completed: false };
          }
          progress.missionsProgress[mission.id].current = 1;
          progress.missionsProgress[mission.id].completed = true;
          progress.missionsCompleted[mission.id] = true;
          updated = true;
          console.log(`[EVOLUTIONS] 📜 Misión específica completada en ${evolution.id}.${mission.id}`);
        }
      }
    }
  }

  if (updated) {
    saveUserEvolutionsState();
    const activeTab = document.querySelector('.collectible-tab.active');
    if (activeTab && activeTab.getAttribute('data-tab') === 'evolutions') {
      renderEvolutions();
    }
  }
};

async function initEvolutions(forceReload = false) {
  try {
    if (window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
      const rawCards = await window.kvrcards.getAllCards();
      allCardsCache = Array.isArray(rawCards) ? rawCards : (rawCards?.cards || []);
      window.allCardsCache = allCardsCache;
      console.log('[EVOLUTIONS] Cartas cargadas:', allCardsCache.length);
    }
  } catch (cErr) {
    console.warn('[EVOLUTIONS] Error cargando cartas:', cErr);
  }
  
  await loadEvolutions(forceReload);
  await loadUserEvolutionsState();
  
  // Verificar progreso antes de renderizar
  await checkEvolutionMissions();
  
  await renderEvolutions();
  setupEvolutionCategoryButtons();

  // Conectar botón de recarga manual si existe en el DOM
  const refreshBtn = document.getElementById('refresh-evolutions-btn');
  if (refreshBtn && !refreshBtn.dataset.listenerAttached) {
    refreshBtn.dataset.listenerAttached = 'true';
    refreshBtn.addEventListener('click', async () => {
      refreshBtn.disabled = true;
      refreshBtn.style.opacity = '0.5';
      refreshBtn.style.pointerEvents = 'none';
      try {
        await initEvolutions(true);
      } catch (e) {
        console.error('[EVOLUTIONS] Error al recargar:', e);
      } finally {
        refreshBtn.disabled = false;
        refreshBtn.style.opacity = '1';
        refreshBtn.style.pointerEvents = '';
      }
    });
  }
  
  // Inicializar sistema de traits si está disponible
  try {
    const initTraits = (typeof initTraitsSystem === 'function')
      ? initTraitsSystem
      : (typeof window !== 'undefined' && typeof window.initTraitsSystem === 'function' ? window.initTraitsSystem : null);

    if (initTraits && !window.traitsSystemInitialized) {
      await initTraits();
    }
  } catch (err) {
    console.warn('[EVOLUTIONS] Error opcional inicializando Traits:', err);
  }
}

// Función para contar Evoluciones listas para reclamar o avanzar de fase
function getClaimableEvolutionsCount() {
  let list = Array.isArray(availableEvolutions) && availableEvolutions.length > 0 ? availableEvolutions : null;
  if (!list) {
    try {
      const cached = localStorage.getItem(EVOLUTIONS_CACHE_KEY);
      if (cached) list = JSON.parse(cached);
    } catch {}
  }
  if (!Array.isArray(list)) return 0;
  let uEvos = userEvolutions;
  if (!uEvos || Object.keys(uEvos).length === 0) {
    try {
      const evoUserKey = (typeof currentUser === 'string' && currentUser.trim()) ? `${USER_EVOLUTIONS_KEY}_${currentUser.trim()}` : USER_EVOLUTIONS_KEY;
      const cachedState = localStorage.getItem(evoUserKey) || localStorage.getItem(USER_EVOLUTIONS_KEY);
      if (cachedState) uEvos = JSON.parse(cachedState);
    } catch {}
  }
  uEvos = uEvos || {};

  let count = 0;
  for (const evo of list) {
    if (!evo || !evo.id) continue;
    const progress = uEvos[evo.id];
    if (!progress || !progress.started) continue;

    const isRepeatable = Boolean(evo.repeatable);
    const maxCompletions = Number(evo.maxCompletions) || 0;
    const completionsCount = Number(progress.completionsCount) || 0;
    const isCompletelyFinished = progress.claimedAt && (!isRepeatable || (maxCompletions > 0 && completionsCount >= maxCompletions));
    if (isCompletelyFinished) continue;

    const phaseInfo = getCurrentPhaseData(evo, progress);
    const totalMissions = phaseInfo && phaseInfo.missions ? phaseInfo.missions.length : 0;
    const completedMissions = totalMissions > 0 
      ? phaseInfo.missions.filter(m => progress.missionsCompleted && progress.missionsCompleted[m.id]).length 
      : 0;

    if (totalMissions > 0 && completedMissions === totalMissions) {
      count++;
    }
  }
  return count;
}
window.getClaimableEvolutionsCount = getClaimableEvolutionsCount;

// Exponer funciones y variables clave al scope global
window.availableEvolutions = availableEvolutions;
window.userEvolutions = userEvolutions;
window.allCardsCache = allCardsCache;
window.loadEvolutions = loadEvolutions;
window.loadUserEvolutionsState = loadUserEvolutionsState;
window.saveUserEvolutionsState = saveUserEvolutionsState;
window.getEvolutionPhases = getEvolutionPhases;
window.startEvolution = startEvolution;
window.claimEvolution = claimEvolution;
window.renderEvolutions = renderEvolutions;
window.initEvolutions = initEvolutions;


