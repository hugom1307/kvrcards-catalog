const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('updaterBridge', {
  onUpdateState: (callback) => ipcRenderer.on('updater:state', (_event, data) => callback(data)),
  retryUpdate: () => ipcRenderer.send('updater:retry'),
  skipUpdate: () => ipcRenderer.send('updater:skip'),
  finishAndLaunch: () => ipcRenderer.send('updater:launch')
});
