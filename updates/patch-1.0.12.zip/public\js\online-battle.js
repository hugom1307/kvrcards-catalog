// ==================== BATALLA ONLINE ====================

function startOnlineBattle() {
  console.log('[ONLINE-BATTLE] Iniciando batalla online...');

  if (window.onlineState) {
    window.onlineState.teamReadySent = false;
  }
  
  const mode = window.onlineState.opponentData?.gameMode || window.selectedGameMode || 'clasico7v7';
  
  // Limpieza exhaustiva antes de cualquier modo online
  if (typeof window.cleanUpBattleCompletely === 'function') {
    window.cleanUpBattleCompletely({ gameMode: mode, isOnline: true, resetDraft: false });
  }

  // INTERCEPCIÓN MODULAR: Fase de Elección (Draft)
  if (mode === 'eleccion_clasico' || mode === 'eleccion_alternativo') {
    console.log('[ONLINE-BATTLE] 🗳️ Interceptado para FASE DE ELECCIÓN (DRAFT) - Modo:', mode);
    window.battleState = window.battleState || {};
    window.battleState.isOnline = true;
    window.battleState.onlineOpponent = window.onlineState.opponentData;
    window.battleState.gameMode = mode;

    // Llamar al inicio de la fase de elección modular
    if (typeof window.startDraftPhase === 'function') {
      window.startDraftPhase(mode);
    } else {
      console.error('[ONLINE-BATTLE] Error: startDraftPhase no cargado en window');
      alert('Error al iniciar el Draft. Por favor, recarga el juego.');
    }
    return;
  }

  // Cambiar a modo online en el estado de batalla estándar
  window.battleState = window.battleState || {};
  window.battleState.isOnline = true;
  window.battleState.onlineOpponent = window.onlineState.opponentData;
  window.battleState.gameMode = mode;
  console.log('[ONLINE-BATTLE] Modo de batalla online:', window.battleState.gameMode);
  
  // Mostrar game view
  document.getElementById('main-menu').style.display = 'none';
  document.getElementById('game-view').style.display = 'block';
  
  // Ocultar todas las pantallas de selección
  document.getElementById('game-mode-selection').style.display = 'none';
  document.getElementById('game-type-selection').style.display = 'none';
  document.getElementById('online-friendly-selection').style.display = 'none';
  document.getElementById('matchmaking-screen').style.display = 'none';
  document.getElementById('friend-battle-screen').style.display = 'none';
  
  // Ir al team builder
  document.getElementById('team-builder').style.display = 'block';
  
  // Cargar inventario
  if (typeof loadTeamBuilderInventory === 'function') {
    loadTeamBuilderInventory();
  }
  
  // Configurar botón continuar para batalla online
  setupOnlineContinueButton();
}

function setupOnlineContinueButton() {
  console.log('[ONLINE-BATTLE] Configurando botón continuar para online...');
  
  // NOTA: El flujo de online ahora usa validateAndStartBattle() del team builder
  // Este código ya no se usa pero se mantiene la función para compatibilidad
  console.log('[ONLINE-BATTLE] Usando flujo de validateAndStartBattle() automáticamente');
}

function handleOpponentReady(data) {
  console.log('[ONLINE-BATTLE] Oponente listo, iniciando batalla...');
  console.log('[ONLINE-BATTLE] Datos del oponente:', data);
  
  // Las cartas ya vienen con imageUrl y stats desde el servidor
  const opponentTeamWithImages = data.team.map(card => {
    console.log('[ONLINE-BATTLE] Carta recibida:', card.name);
    console.log('[ONLINE-BATTLE] - imageUrl:', card.imageUrl);
    console.log('[ONLINE-BATTLE] - stats:', card.stats);
    console.log('[ONLINE-BATTLE] - uniqueId:', card.uniqueId);
    
    let cardImg = card.imageUrl;
    if (!cardImg || cardImg.startsWith('data:image/') || cardImg.length > 500) {
      const catalog = window.allCardsCache || window.allCardsPool || [];
      const localCard = catalog.find(c => c && c.id === card.id);
      cardImg = localCard?.imageUrl || localCard?.imagen || localCard?.image || '';
    }

    const processedCard = {
      ...card,
      imageUrl: cardImg,
      imagen: cardImg,          // Por compatibilidad
      image: cardImg,           // Por compatibilidad
      nombre: card.nombre || card.name,
      parametros: card.stats || [],   // Por compatibilidad
      stats: card.stats || []         // Asegurar que stats existe
    };
    
    console.log('[ONLINE-BATTLE] Carta procesada:', processedCard.name, 'tiene imageUrl:', !!processedCard.imageUrl, 'tiene stats:', !!processedCard.stats);
    return processedCard;
  });
  
  // Guardar equipo del oponente con buffs e imágenes
  window.battleState.opponentTeam = opponentTeamWithImages;
  console.log('[ONLINE-BATTLE] opponentTeam guardado con', opponentTeamWithImages.length, 'cartas');
  window.battleState.opponentPowers = data.powers;
  window.battleState.opponentName = window.onlineState.opponentData?.username || 'Rival';
  
  // NUEVO: Guardar buffs del oponente si vienen del servidor
  if (data.buffs) {
    window.battleState.opponentBuffs = data.buffs;
    console.log('[ONLINE-BATTLE] Buffs del oponente:', data.buffs);
  } else {
    // Fallback: calcular buffs localmente si no vienen del servidor
    window.battleState.opponentBuffs = calculateBattleBuffs(data.team);
    console.log('[ONLINE-BATTLE] Buffs del oponente calculados localmente:', window.battleState.opponentBuffs);
  }
  
  // CRITICO: Confirmar al servidor que estamos listos para iniciar batalla
  if (window.onlineState?.socket && window.onlineState?.matchId) {
    console.log('[ONLINE-BATTLE] Enviando confirm-battle-ready al servidor');
    window.onlineState.socket.emit('confirm-battle-ready', {
      matchId: window.onlineState.matchId,
      buffs: window.battleState.playerBuffs || { buffs: [], byProcedencia: {}, byOwner: {} }
    });
  }
  
  // Ocultar team builder
  document.getElementById('team-builder').style.display = 'none';
  
  // Iniciar batalla (adaptar la función existente startBattle)
  startOnlineBattlePhase();
}

function handleBothCardsSelected(data) {
  console.log('[ONLINE-BATTLE] Ambos jugadores han seleccionado carta, iniciando batalla...');
  
  // Guardar carta del oponente
  window.battleState.opponentCurrentCard = data.opponentCard;
  
  // Actualizar UI
  const instruction = document.getElementById('battle-intro-instruction');
  if (instruction) {
    instruction.innerHTML = '<h1>✅ Ambos jugadores han elegido. ¡Comienza la batalla!</h1>';
  }
  
  // Esperar un momento antes de la transición
  setTimeout(() => {
    transitionToBattleScreen();
  }, 1500);
}

function handleOnlineStatSelection(stat) {
  console.log('[ONLINE-BATTLE] Jugador selecciona stat:', stat);
  
  // Guardar la selección localmente
  window.battleState.selectedStat = stat;
  
  // Deshabilitar botones de stats para evitar doble selección
  const statButtons = document.querySelectorAll('.battle-stat-btn');
  statButtons.forEach(btn => btn.disabled = true);
  
  // ===== CALCULAR VALOR CON TODOS LOS MODIFICADORES =====
  const playerCard = window.battleState.playerCurrentCard;
  
  console.log(`[ONLINE-BATTLE-DEBUG] Antes de llamar getStatValue():`);
  console.log(`[ONLINE-BATTLE-DEBUG] playerCard.nombre: ${playerCard.nombre}`);
  console.log(`[ONLINE-BATTLE-DEBUG] playerCard.id: ${playerCard.id}`);
  console.log(`[ONLINE-BATTLE-DEBUG] playerCard.uniqueId: ${playerCard.uniqueId}`);
  console.log(`[ONLINE-BATTLE-DEBUG] window.battleState.statModifiers COMPLETO:`, window.battleState.statModifiers);
  
  // Fuente de verdad: el valor visual mostrado en UI. Fallback a getStatValue() si no existe.
  const displayedPlayerValue = typeof getDisplayedBattleStatValue === 'function' ? getDisplayedBattleStatValue('player', stat) : null;
  const playerValue = displayedPlayerValue !== null ? displayedPlayerValue : getStatValue(playerCard, stat, 'player');
  
  console.log(`[ONLINE-BATTLE] Valor de stat enviado al servidor: ${stat} = ${playerValue} (UI=${displayedPlayerValue}, fallback=${displayedPlayerValue === null})`);
  
  // Mostrar indicador visual de que se está esperando
  console.log('[ONLINE-BATTLE] Enviando selección al servidor y esperando oponente...');
  
  // Enviar selección al servidor CON valor calculado y estado de poderes
  if (window.onlineState.socket) {
    window.onlineState.socket.emit('stat-selected', {
      matchId: window.onlineState.matchId,
      stat: stat,
      value: playerValue,  // ✅ AHORA ENVÍA EL VALOR CALCULADO
      powerState: {
        powerUpActive: window.battleState.playerPowerUpActive || false,
        nerfActive: window.battleState.playerNerfActive || false,
        nerfTargetStat: window.battleState.opponentSelectedStat || null
      }
    });
  }
  
  // La función handleOpponentStatSelected se llamará cuando el oponente elija
}

function handleOpponentStatSelected(data) {
  // El oponente seleccionó una estadística
  console.log('[ONLINE-BATTLE] Oponente seleccionó:', data.stat);
  window.battleState.opponentSelectedStat = data.stat;
  
  // Registrar la stat como usada por el oponente (para marcarla en rondas siguientes)
  if (!window.battleState.opponentUsedStats.includes(data.stat)) {
    window.battleState.opponentUsedStats.push(data.stat);
    console.log('[ONLINE-BATTLE] opponentUsedStats actualizado:', window.battleState.opponentUsedStats);
  }
  
  // Reutilizar la animación existente del modo offline (clase .highlighted)
  const opponentStatDisplay = document.querySelector(`.battle-side-opponent .battle-stat-display[data-stat="${data.stat}"]`);
  if (opponentStatDisplay) {
    opponentStatDisplay.classList.add('highlighted');
    console.log('[ONLINE-BATTLE] Aplicada animación .highlighted a stat del oponente');
  }
  
  // Si era turno del rival y ahora me toca a mí (o aún no elijo stat, ej. tras ANULO), habilitar mis stats
  if (!window.battleState.selectedStat || window.battleState.currentTurn === 'opponent' || data.isFirstPlayerChoice) {
    window.battleState.currentTurn = 'player';
    window.battleState.gamePhase = 'stat-selection';
    console.log('[ONLINE-BATTLE] Rival ya eligió, ahora es MI turno de elegir stat');
    enableStatSelection();
    
    const instruction = document.getElementById('battle-intro-instruction');
    if (instruction) {
      instruction.innerHTML = `<h1>⚔️ Rival seleccionó: ${data.stat.toUpperCase()}</h1><p>¡Ahora elige tú!</p>`;
    }
  } else {
    // Ya elegí yo, mostrar qué eligió el rival
    const instruction = document.getElementById('battle-intro-instruction');
    if (instruction) {
      instruction.innerHTML = `<h1>⚔️ Rival seleccionó: ${data.stat.toUpperCase()}</h1><p>Esperando resultado...</p>`;
    }
  }
}

async function setupBattleProfiles() {
  console.log('[BATTLE] Configurando perfiles para batalla online...');
  
  // Perfil del jugador
  let playerUsername = (typeof getEffectiveOnlineUsername === 'function') 
    ? getEffectiveOnlineUsername() 
    : (localStorage.getItem('username') || localStorage.getItem('kvrUsername') || 'Jugador');
  let playerAvatar = 'https://api.dicebear.com/7.x/avataaars/svg?seed=default';
  
  try {
    if (isElectron) {
      const userResult = await window.kvrcards.getUserProfile();
      if (userResult?.ok && userResult?.profile) {
        playerUsername = userResult.profile.username || playerUsername;
        playerAvatar = userResult.profile.profileImage || playerAvatar;
      } else if (userResult?.username) {
        playerUsername = userResult.username;
        playerAvatar = userResult.profileImage || playerAvatar;
      }
    }
  } catch (error) {
    console.error('[BATTLE] Error obteniendo perfil del jugador:', error);
  }
  
  // Actualizar UI del jugador
  const playerAvatarEl = document.getElementById('battle-player-avatar');
  const playerUsernameEl = document.getElementById('battle-player-username');
  if (playerAvatarEl) playerAvatarEl.src = playerAvatar;
  if (playerUsernameEl) playerUsernameEl.textContent = playerUsername;
  
  // Perfil del oponente (desde onlineState)
  const opponentUsername = (window.battleState.opponentName && window.battleState.opponentName !== 'Jugador') 
    ? window.battleState.opponentName 
    : ((window.onlineState.opponentData?.username && window.onlineState.opponentData.username !== 'Jugador') 
        ? window.onlineState.opponentData.username 
        : (window.onlineState.opponentId && !window.onlineState.opponentId.startsWith('user_') ? window.onlineState.opponentId : 'Rival'));
  const opponentAvatar = window.onlineState.opponentData?.profileImage || window.onlineState.opponentData?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${opponentUsername}`;
  
  const opponentAvatarEl = document.getElementById('battle-opponent-avatar');
  const opponentUsernameEl = document.getElementById('battle-opponent-username');
  if (opponentAvatarEl) opponentAvatarEl.src = opponentAvatar;
  if (opponentUsernameEl) opponentUsernameEl.textContent = opponentUsername;
  
  // Configurar avatares de la ruleta
  const roulettePlayerAvatar = document.getElementById('roulette-player-avatar');
  const rouletteOpponentAvatar = document.getElementById('roulette-opponent-avatar');
  if (roulettePlayerAvatar) roulettePlayerAvatar.src = playerAvatar;
  if (rouletteOpponentAvatar) rouletteOpponentAvatar.src = opponentAvatar;
  
  // Configurar título del oponente para online
  const opponentTitleEl = document.getElementById('battle-opponent-title');
  if (opponentTitleEl) {
    opponentTitleEl.textContent = '🌐 Jugador Online';
    opponentTitleEl.style.display = 'inline';
  }
  
  console.log('[BATTLE] Perfiles configurados:', playerUsername, 'vs', opponentUsername);
}

function startOnlineBattlePhase() {
  console.log('[ONLINE-BATTLE] Iniciando fase de batalla...');
  
  // RESETEAR battleState para evitar conflictos con batallas offline previas
  window.battleState.playerScore = 0;
  window.battleState.opponentScore = 0;
  window.battleState.playerCurrentCard = null;
  window.battleState.opponentCurrentCard = null;
  window.battleState.currentTurn = null;
  window.battleState.roundWinner = null;
  window.battleState.playerUsedStats = [];
  window.battleState.opponentUsedStats = [];
  window.battleState.playerUsedCards = [];
  window.battleState.opponentUsedCards = [];
  window.battleState.selectedStat = null;
  window.battleState.opponentSelectedStat = null;
  window.battleState.waitingForCardSelection = false;
  window.battleState.gamePhase = 'roulette';
  window.battleState.canChangeCard = true;
  window.battleState.wasTie = false;
  window.battleState.playerTotalInTie = 0;
  window.battleState.opponentTotalInTie = 0;
  
  // Resetear poderes
  window.battleState.playerPowersUsed = {
    swap: false,
    powerup: false,
    nerf: false,
    anulo: false,
    intercambio: false
  };
  window.battleState.opponentPowersUsed = {
    swap: false,
    powerup: false,
    nerf: false,
    anulo: false,
    intercambio: false
  };
  window.battleState.playerPowerUpActive = false;
  window.battleState.opponentPowerUpActive = false;
  window.battleState.playerNerfActive = false;
  window.battleState.opponentNerfActive = false;
  window.battleState.playerReserveCardUsed = false;
  window.battleState.opponentReserveCardUsed = false;
  window.battleState.playerConsecutiveLosses = 0;
  window.battleState.opponentConsecutiveLosses = 0;
  
  // Asegurar inicialización robusta de poderes del jugador para online
  if (!window.battleState.playerPowers || window.battleState.playerPowers.length === 0) {
    const selectedPowers = (window.selectedTeamPowers || []).filter(p => p !== null && p !== undefined && p !== '');
    window.battleState.playerPowers = selectedPowers.length > 0 ? selectedPowers : ['swap', 'powerup', 'nerf'];
  }
  
  // CRÍTICO: Configurar carta de reserva para online (8ª carta del equipo, index 7)
  if (window.battleState.playerTeam && window.battleState.playerTeam.length >= 8) {
    window.battleState.playerReserveCard = window.battleState.playerTeam[7];
    window.battleState.playerReserveCardIndex = 7;
    console.log('[ONLINE-BATTLE] Carta de reserva configurada:', window.battleState.playerReserveCard.name || window.battleState.playerReserveCard.nombre);
  } else {
    window.battleState.playerReserveCard = null;
    window.battleState.playerReserveCardIndex = -1;
    console.log('[ONLINE-BATTLE] Sin carta de reserva (equipo tiene', window.battleState.playerTeam?.length || 0, 'cartas)');
  }

  // CRÍTICO: Configurar carta de reserva del oponente para online (8ª carta del equipo del rival, index 7)
  if (window.battleState.opponentTeam && window.battleState.opponentTeam.length >= 8) {
    window.battleState.opponentReserveCard = window.battleState.opponentTeam[7];
    console.log('[ONLINE-BATTLE] Carta de reserva del oponente configurada:', window.battleState.opponentReserveCard.name || window.battleState.opponentReserveCard.nombre);
  } else {
    window.battleState.opponentReserveCard = null;
    console.log('[ONLINE-BATTLE] Sin carta de reserva para el oponente (equipo tiene', window.battleState.opponentTeam?.length || 0, 'cartas)');
  }
  
  // Configurar batalla online
  window.battleState.difficulty = 'online';
  window.battleState.isOnline = true;
  
  // Guardar traits si existen
  window.battleState.cardTraitsMap = window.battleState.cardTraitsMap || (typeof cardTraitsMap !== 'undefined' ? cardTraitsMap : {});
  window.battleState.availableTraits = window.battleState.availableTraits || (typeof availableTraits !== 'undefined' ? availableTraits : []);

  // Limpiar clases residuales en botones y displays de stats
  document.querySelectorAll('.battle-stat-btn, .battle-stat-display').forEach(el => {
    el.classList.remove('used', 'highlighted', 'annulled', 'disabled', 'selected', 'nerfed');
    el.disabled = false;
    el.style.opacity = '';
    el.style.borderColor = '';
    el.style.background = '';
    el.style.boxShadow = '';
    const label = el.querySelector('.stat-label');
    if (label) {
      label.innerHTML = label.innerHTML.replace(/🔒\s*/g, '');
    }
  });
  
  console.log('[ONLINE-BATTLE] battleState reseteado para modo online');
  
  // Mostrar intro de batalla (igual que en offline)
  // En online también se elige primera carta de forma visual
  showBattleIntro();
  
  // El resto usa la lógica existente de batalla
  // pero con sincronización online
}

// Sincronización de acciones durante la batalla
function syncCardSelection(cardIndex) {
  if (window.onlineState.socket && window.battleState.isOnline) {
    window.onlineState.socket.emit('card-selected', {
      matchId: window.onlineState.matchId,
      cardIndex: cardIndex
    });
  }
}

function syncPowerUsage(powerType, targetData) {
  if (window.onlineState.socket && window.battleState.isOnline) {
    window.onlineState.socket.emit('power-used', {
      matchId: window.onlineState.matchId,
      powerType: powerType,
      targetData: targetData
    });
  }
}

function handleOpponentPowerUsed(data) {
  if (window.BattlePowers && typeof window.BattlePowers.handleOpponentPowerUsed === 'function') {
    return window.BattlePowers.handleOpponentPowerUsed(data);
  }
  console.warn('[ONLINE-BATTLE] BattlePowers module no disponible para handleOpponentPowerUsed');
}

// Nueva función: Manejar confirmación de poder propio (online)
// NOTA: Con optimistic update, esta función puede ser llamada DESPUÉS de que el poder
// ya fue aplicado localmente. En ese caso, simplemente confirma sin duplicar efectos.
async function handlePowerConfirmed(data) {
  if (window.BattlePowers && typeof window.BattlePowers.handlePowerConfirmed === 'function') {
    return window.BattlePowers.handlePowerConfirmed(data);
  }
  console.warn('[ONLINE-BATTLE] BattlePowers module no disponible para handlePowerConfirmed');
}

function handlePowerError(data) {
  if (window.BattlePowers && typeof window.BattlePowers.handlePowerError === 'function') {
    return window.BattlePowers.handlePowerError(data);
  }
  console.warn('[ONLINE-BATTLE] BattlePowers module no disponible para handlePowerError');
}

function handleOpponentDisconnected() {
  console.log('[ONLINE] ⚠️ Oponente desconectado');
  
  // El servidor enviará un evento 'battle-finished' con reason: 'disconnect'
  // Si estamos en batalla, esperar a que el servidor procese la victoria automática
  if (window.onlineState && window.onlineState.inBattle) {
    console.log('[ONLINE] Esperando confirmación del servidor (battle-finished)...');
    clearTimeout(window.__opponentDisconnectFallbackTimer);
    window.__opponentDisconnectFallbackTimer = setTimeout(() => {
      if (window.onlineState && window.onlineState.inBattle) {
        console.warn('[ONLINE] Timeout esperando battle-finished del servidor tras desconexión del oponente.');
        resetOnlineBattleStateAndReturnToMenu();
      }
    }, 6000);
  } else {
    // Si no estamos en batalla, resetear y volver al menú
    resetOnlineBattleStateAndReturnToMenu();
  }
}

/**
 * Resetea estado online y vuelve al menú (cuando no hay batalla activa)
 */
function resetOnlineBattleStateAndReturnToMenu() {
  console.log('[ONLINE] Reseteando estado online y volviendo al menú...');
  
  // Resetear estado online
  if (window.onlineState) {
    window.onlineState.inBattle = false;
    window.onlineState.inQueue = false;
    window.onlineState.matchId = null;
    window.onlineState.opponentId = null;
    window.onlineState.teamReadySent = false;
  }
  
  // Resetear completamente estado de batalla y limpiar DOM (stats, cartas, poderes)
  if (typeof window.cleanUpBattleCompletely === 'function') {
    window.cleanUpBattleCompletely({ isOnline: false, isFullReset: true, resetDraft: true, resumeMenuMusic: true });
  }

  if (typeof window.cleanAllBattleStatButtonsAndDisplays === 'function') {
    window.cleanAllBattleStatButtonsAndDisplays();
  }

  if (typeof window.resetDraftState === 'function') {
    window.resetDraftState();
  }
  
  // Ocultar todas las pantallas de juego
  const gameScreens = [
    'game-mode-selection',
    'game-type-selection',
    'difficulty-selection',
    'team-builder',
    'battle-screen',
    'online-friendly-selection',
    'matchmaking-screen',
    'friend-battle-screen'
  ];
  
  gameScreens.forEach(screenId => {
    const screen = document.getElementById(screenId);
    if (screen) screen.style.display = 'none';
  });
  
  // Ocultar también game-view, battle-intro y battle-result
  const extraScreens = ['game-view', 'battle-intro', 'battle-result-screen'];
  extraScreens.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });
  
  // Limpiar pantallas de batalla online dinámicas
  const battleEndScreens = document.querySelectorAll('.battle-end-screen');
  battleEndScreens.forEach(screen => screen.remove());
  
  // Mostrar menú principal
  const mainMenu = document.getElementById('main-menu');
  if (mainMenu) mainMenu.style.display = 'flex';
  
  // Mostrar alerta DESPUÉS de cambiar las pantallas
  setTimeout(() => {
    alert('❌ Tu oponente se ha desconectado. Has sido devuelto al menú principal.');
  }, 100);
}

function resolveOnlineRound() {
  // Usar la lógica existente de resolución de ronda
  // pero adaptada para online (sin IA)
  console.log('[ONLINE-BATTLE] Resolviendo ronda online...');
  
  if (typeof playRound === 'function') {
    playRound();
  }
}

function handleStatAutoAssigned(data) {
  const stat = data.stat;
  console.log('[ONLINE-BATTLE] Auto-asignando nuestra única stat disponible:', stat);
  
  window.battleState.selectedStat = stat;
  if (!window.battleState.playerUsedStats.includes(stat)) {
    window.battleState.playerUsedStats.push(stat);
  }
  
  const btn = document.querySelector(`.battle-side-player .battle-stat-btn[data-stat="${stat}"]`);
  if (btn) {
    btn.classList.add('used');
  }
  
  if (typeof showNotification === 'function') {
    showNotification(data.message || `ℹ️ Se ha auto-asignado tu única estadística restante: ${stat.toUpperCase()}`, 'info');
  }
  
  const instruction = document.getElementById('battle-intro-instruction');
  if (instruction) {
    instruction.innerHTML = `<h1>ℹ️ Se auto-asignó: ${stat.toUpperCase()}</h1><p>Esperando resultado...</p>`;
  }
}

function handleOpponentStatAutoAssigned(data) {
  const stat = data.stat;
  console.log('[ONLINE-BATTLE] Al oponente se le ha auto-asignado la stat:', stat);
  
  window.battleState.opponentSelectedStat = stat;
  if (!window.battleState.opponentUsedStats.includes(stat)) {
    window.battleState.opponentUsedStats.push(stat);
  }
  
  const display = document.querySelector(`.battle-side-opponent .battle-stat-display[data-stat="${stat}"]`);
  if (display) {
    display.classList.add('highlighted', 'used');
  }
  
  if (typeof showNotification === 'function') {
    showNotification(data.message || `ℹ️ Al rival se le ha auto-asignado su única estadística restante: ${stat.toUpperCase()}`, 'info');
  }
  
  window.battleState.currentTurn = 'player';
  if (typeof enableStatSelection === 'function') {
    enableStatSelection();
  }
  
  const instruction = document.getElementById('battle-intro-instruction');
  if (instruction) {
    instruction.innerHTML = `<h1>⚔️ Rival auto-seleccionó: ${stat.toUpperCase()}</h1><p>¡Ahora elige tú!</p>`;
  }
}

window.handleStatAutoAssigned = handleStatAutoAssigned;
window.handleOpponentStatAutoAssigned = handleOpponentStatAutoAssigned;

