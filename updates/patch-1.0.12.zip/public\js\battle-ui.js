async function endBattle(options = {}) {
  if (window.__battleEnded && (!options || !options.force)) {
    console.warn('[BATTLE] endBattle ignorado: la batalla ya habia finalizado previamente');
    return;
  }
  window.__battleEnded = true;
  window.__battleCancelled = true;
  if (typeof clearAllBattleTimeouts === 'function') {
    clearAllBattleTimeouts();
  }

  console.log('[BATTLE] Batalla finalizada');
  console.log('[BATTLE] Score - Jugador:', window.battleState?.playerScore, 'Oponente:', window.battleState?.opponentScore);
  
  // 1. Ocultar inmediatamente battle-screen y game-view para que nunca quede nada residual en pantalla
  const battleScreen = document.getElementById('battle-screen');
  if (battleScreen) battleScreen.style.display = 'none';
  const gameView = document.getElementById('game-view');
  if (gameView) gameView.style.display = 'none';

  // Al terminar batalla, detener musica de batalla y volver a musica de fondo.
  resumeMenuMusic();
  
  // Elementos de la pantalla de resultado
  const resultScreen = document.getElementById('battle-result-screen');
  const resultTitle = document.getElementById('battle-result-title');
  const playerScoreEl = document.getElementById('result-player-score');
  const opponentScoreEl = document.getElementById('result-opponent-score');
  const rewardDiv = document.getElementById('battle-result-reward');
  const rewardAmountEl = document.getElementById('reward-amount');
  const returnBtn = document.getElementById('battle-return-menu-btn');
  const rematchBtn = document.getElementById('battle-rematch-btn');
  
  const playerScore = Number(window.battleState?.playerScore) || 0;
  const opponentScore = Number(window.battleState?.opponentScore) || 0;
  
  if (playerScoreEl) playerScoreEl.textContent = playerScore;
  if (opponentScoreEl) opponentScoreEl.textContent = opponentScore;
  
  // Mapeo de dificultades a multiplicadores
  const difficultyMultipliers = {
    'principiante': 1,
    'amateur': 2,
    'experimentado': 4,
    'profesional': 8,
    'dios-antiguo': 16,
    'inmo': 50
  };
  
  const isInfiniteOffline = !!(
    (window.__infiniteBattleContext?.active || window.battleState?.infiniteModifier || window.selectedDifficulty === 'inmo' || window.battleState?.difficulty === 'inmo') &&
    !window.battleState?.isOnline
  );
  if (isInfiniteOffline) {
    window.isEventBattle = false;
    window.currentEventBattle = null;
  }
  const isEventBattle = !isInfiniteOffline && !!(
    (window.isEventBattle && window.currentEventBattle) ||
    (typeof window.selectedDifficulty === 'string' && window.selectedDifficulty.startsWith('evento_')) ||
    (typeof window.battleState?.difficulty === 'string' && window.battleState.difficulty.startsWith('evento_'))
  );
  if (isEventBattle && !window.currentEventBattle && typeof window.getEventBattleById === 'function') {
    window.currentEventBattle = window.getEventBattleById(window.selectedDifficulty || window.battleState?.difficulty);
    if (window.currentEventBattle) window.isEventBattle = true;
  }
  const playerWonBattle = playerScore > opponentScore;

  // Determinar título según resultado y calcular recompensa
  let coinsEarned = 0;

  if (playerWonBattle) {
    console.log('[BATTLE] ¡VICTORIA!');
    if (resultTitle) {
      resultTitle.textContent = '¡VICTORIA!';
      resultTitle.style.color = '#fbbf24';
    }
    
    if (!isInfiniteOffline && !isEventBattle) {
      const baseReward = 250;
      const difficulty = window.battleState?.difficulty || window.selectedDifficulty || 'principiante';
      const multiplier = difficultyMultipliers[difficulty] || 1;
      coinsEarned = baseReward * multiplier;
      console.log('[BATTLE] Calculando recompensa:', baseReward, 'x', multiplier, '=', coinsEarned);
      
      if (rewardAmountEl) rewardAmountEl.textContent = coinsEarned;
      if (rewardDiv) rewardDiv.style.display = 'flex';
    } else {
      if (rewardDiv) rewardDiv.style.display = 'none';
    }
  } else if (opponentScore > playerScore) {
    console.log('[BATTLE] Derrota');
    if (resultTitle) {
      resultTitle.textContent = 'DERROTA';
      resultTitle.style.color = '#ef4444';
    }
    if (rewardDiv) rewardDiv.style.display = 'none';
  } else {
    console.log('[BATTLE] Empate');
    if (resultTitle) {
      resultTitle.textContent = 'EMPATE';
      resultTitle.style.color = '#9ca3af';
    }
    if (rewardDiv) rewardDiv.style.display = 'none';
  }
  
  // 2. MOSTRAR PANTALLA DE RESULTADO INMEDIATAMENTE
  console.log('[BATTLE] Mostrando pantalla de resultado...');
  if (resultScreen) {
    resultScreen.style.display = 'flex';
  }
  
  // 3. Configurar botones (Modo Infinito tiene prioridad absoluta para evitar solapamiento)
  if (isInfiniteOffline) {
    if (returnBtn) {
      returnBtn.innerHTML = '<img src="./assets/botones/volver.png" alt="Volver" class="battle-btn-img" draggable="false" />';
      returnBtn.classList.add('has-img');
      returnBtn.title = 'Volver';
      returnBtn.onclick = () => {
        if (resultScreen) resultScreen.style.display = 'none';
        if (typeof window.infiniteReturnFromBattle === 'function') {
          window.infiniteReturnFromBattle(playerWonBattle);
        } else if (typeof window.openInfiniteModePanel === 'function') {
          window.openInfiniteModePanel();
        }
      };
    }

    if (rematchBtn) {
      rematchBtn.style.display = 'inline-flex';
      if (playerWonBattle) {
        rematchBtn.textContent = 'Siguiente piso';
        rematchBtn.classList.remove('has-img');
        rematchBtn.onclick = () => {
          if (resultScreen) resultScreen.style.display = 'none';
          if (typeof window.infiniteGoToNextFloorAndPlay === 'function') {
            window.infiniteGoToNextFloorAndPlay();
          }
        };
      } else {
        rematchBtn.innerHTML = '<img src="./assets/botones/revancha.png" alt="Revancha" class="battle-btn-img" draggable="false" />';
        rematchBtn.classList.add('has-img');
        rematchBtn.title = 'Revancha';
        rematchBtn.onclick = () => {
          if (resultScreen) resultScreen.style.display = 'none';
          startRematch();
        };
      }
    }
  } else if (isEventBattle) {
    if (returnBtn) {
      returnBtn.innerHTML = '<img src="./assets/botones/volver.png" alt="Volver al Menú Principal" class="battle-btn-img" draggable="false" />';
      returnBtn.classList.add('has-img');
      returnBtn.title = 'Volver al Menú Principal';
      returnBtn.onclick = () => {
        if (resultScreen) resultScreen.style.display = 'none';
        resumeMenuMusic();
        returnToMainMenu();
      };
    }

    if (rematchBtn) {
      rematchBtn.style.display = 'inline-flex';
      rematchBtn.innerHTML = '<img src="./assets/botones/revancha.png" alt="Revancha" class="battle-btn-img" draggable="false" />';
      rematchBtn.classList.add('has-img');
      rematchBtn.title = 'Revancha';
      rematchBtn.onclick = () => {
        const battle = window.currentEventBattle || (typeof window.getEventBattleById === 'function' ? window.getEventBattleById(window.selectedDifficulty || window.battleState?.difficulty) : null);
        const attemptsStatus = battle && typeof window.getBattleAttemptsStatus === 'function'
          ? window.getBattleAttemptsStatus(battle)
          : null;

        if (attemptsStatus && (attemptsStatus.isExhausted || attemptsStatus.remaining <= 0)) {
          alert('te quedan 0 intentos diarios a este combate');
          return;
        }

        if (resultScreen) resultScreen.style.display = 'none';
        startRematch();
      };
    }
  } else {
    if (returnBtn) {
      returnBtn.innerHTML = '<img src="./assets/botones/volver.png" alt="Volver al Menú Principal" class="battle-btn-img" draggable="false" />';
      returnBtn.classList.add('has-img');
      returnBtn.title = 'Volver al Menú Principal';
      returnBtn.onclick = () => {
        if (resultScreen) resultScreen.style.display = 'none';
        resumeMenuMusic();
        returnToMainMenu();
      };
    }

    if (rematchBtn) {
      rematchBtn.style.display = 'inline-flex';
      rematchBtn.innerHTML = '<img src="./assets/botones/revancha.png" alt="Revancha" class="battle-btn-img" draggable="false" />';
      rematchBtn.classList.add('has-img');
      rematchBtn.title = 'Revancha';
      rematchBtn.onclick = () => {
        if (resultScreen) resultScreen.style.display = 'none';
        startRematch();
      };
    }
  }

  // 4. Operaciones asíncronas de guardado, recompensas y progreso
  (async () => {
    try {
      // Prestigio
      try {
        if (typeof recordPrestigeBattleOutcome === 'function') {
          await recordPrestigeBattleOutcome(playerWonBattle);
        }
      } catch (error) {
        console.warn('[PRESTIGE] No se pudo registrar resultado de batalla:', error?.message || error);
      }

      // Recompensas de victoria: Modo Infinito tiene prioridad absoluta
      if (playerWonBattle && isInfiniteOffline) {
        try {
          const infContext = window.__infiniteBattleContext || {};
          const displayFloor = Number(infContext.floor) || 1;
          const trainerRole = String(infContext.trainerRole || 'normal').toLowerCase();

          // 1. Calcular drops del piso
          let floorRewards = [];
          if (typeof window.computeInfiniteFloorRewards === 'function') {
            floorRewards = window.computeInfiniteFloorRewards(displayFloor, trainerRole);
          } else {
            floorRewards = [{ type: 'infinite-coins', amount: 1, name: '1 Infinite Coin' }];
          }

          // 2. Comprobar recompensas de hito de temporada si aplica
          let milestoneRewards = [];
          if (typeof window.checkAndClaimInfiniteMilestone === 'function') {
            milestoneRewards = await window.checkAndClaimInfiniteMilestone(displayFloor);
          }

          const allRewards = [...floorRewards, ...(Array.isArray(milestoneRewards) ? milestoneRewards : [])];

          // 3. Otorgar recompensas en inventario y persistencia
          if (typeof window.grantPrestigeRewards === 'function') {
            await window.grantPrestigeRewards(allRewards);
          } else {
            for (const item of allRewards) {
              const itemType = String(item.type || '').toLowerCase();
              const itemAmt = Number(item.amount) || 1;
              if (itemType === 'infinite-coins' || itemType === 'infinite-coin') {
                if (typeof window.infiniteAddCurrency === 'function') window.infiniteAddCurrency('infinite-coins', itemAmt);
              } else if (itemType === 'infinite-cardpoints' || itemType === 'infinite-cardpoint') {
                if (typeof window.infiniteAddCurrency === 'function') window.infiniteAddCurrency('infinite-cardpoints', itemAmt);
              } else if (itemType === 'coins' && window.kvrcards?.addCoins) {
                await window.kvrcards.addCoins(itemAmt);
              } else if ((itemType === 'traits' || itemType === 'trait')) {
                let traitGiven = false;
                if (window.kvrcards?.addTraits) {
                  const res = await window.kvrcards.addTraits(itemAmt);
                  if (res?.ok) traitGiven = true;
                }
                if (!traitGiven && window.kvrcards?.debugModifyTraits) {
                  const res = await window.kvrcards.debugModifyTraits(itemAmt);
                  if (res?.ok) traitGiven = true;
                }
                if (!traitGiven) {
                  if (window.userProfile) {
                    window.userProfile.traits = (Number(window.userProfile.traits) || 0) + itemAmt;
                    traitGiven = true;
                    if (typeof saveUserProfile === 'function') await saveUserProfile();
                  }
                  try {
                    const cur = Number(localStorage.getItem('kvr_wallet_traits')) || 0;
                    localStorage.setItem('kvr_wallet_traits', String(cur + itemAmt));
                  } catch {}
                }
              }
            }
          }

          if (isElectron && window.kvrcards?.addBattleWon) {
            try {
              await window.kvrcards.addBattleWon();
            } catch (e) {
              console.warn('[BATTLE] Error al registrar victoria en modo infinito:', e);
            }
          }

          if (typeof renderWallet === 'function') {
            await renderWallet().catch(() => {});
          }
          if (typeof renderTraitsPanel === 'function') {
            renderTraitsPanel();
          }
          if (typeof window.renderTraitsPanel === 'function') {
            window.renderTraitsPanel();
          }

          // 4. Mostrar animacion de reclamar recompensa (showUnifiedRewardsHUD)
          if (typeof window.showUnifiedRewardsHUD === 'function' && allRewards.length > 0) {
            setTimeout(async () => {
              try {
                await window.showUnifiedRewardsHUD(allRewards, `¡NIVEL ${displayFloor} SUPERADO!`);
              } catch (hudErr) {
                console.warn('[BATTLE] Error en HUD de recompensas infinitas:', hudErr);
              }
            }, 600);
          }
        } catch (infErr) {
          console.error('[BATTLE] Error otorgando recompensas de modo infinito:', infErr);
        }
      } else if (playerWonBattle && isEventBattle) {
        try {
          const eventBattle = window.currentEventBattle;
          let wonRewards = [];
          if (eventBattle && typeof window.rollEventBattleRewards === 'function' && Array.isArray(eventBattle.rewards)) {
            wonRewards = window.rollEventBattleRewards(eventBattle.rewards);
          } else if (eventBattle && Array.isArray(eventBattle.rewards)) {
            wonRewards = eventBattle.rewards;
          }

          console.log('[EVENT-BATTLE] Recompensas obtenidas:', wonRewards);

          if (wonRewards.length > 0 && typeof window.grantPrestigeRewards === 'function') {
            await window.grantPrestigeRewards(wonRewards);
          }

          if (isElectron && window.kvrcards?.addBattleWon) {
            await window.kvrcards.addBattleWon().catch(() => {});
          }

          if (typeof renderWallet === 'function') {
            await renderWallet().catch(() => {});
          }

          if (typeof window.showUnifiedRewardsHUD === 'function' && wonRewards.length > 0) {
            setTimeout(async () => {
              try {
                await window.showUnifiedRewardsHUD(wonRewards, 'VICTORIA EN EVENTO');
              } catch (hudErr) {
                console.warn('[EVENT-BATTLE] Error en HUD de recompensas:', hudErr);
              }
            }, 600);
          }
        } catch (eventErr) {
          console.error('[EVENT-BATTLE] Error procesando recompensas:', eventErr);
        }
      } else if (playerWonBattle && !isInfiniteOffline && coinsEarned > 0) {
        if (isElectron && window.kvrcards) {
          try {
            const result = await window.kvrcards.addCoins(coinsEarned);
            if (result?.ok) {
              console.log(`[BATTLE] Monedas ganadas y guardadas: ${coinsEarned}`);
            }
          } catch (e) {
            console.error('[BATTLE] Error al guardar monedas:', e);
          }

          try {
            const battleResult = await window.kvrcards.addBattleWon();
            if (battleResult?.ok) {
              console.log('[BATTLE] Victoria registrada, total:', battleResult.battlesWon);
            }
          } catch (e) {
            console.error('[BATTLE] Error al registrar victoria:', e);
          }

          if (typeof renderWallet === 'function') {
            await renderWallet().catch(() => {});
          }
        }

        // Mostrar HUD unificado de reclamar recompensa animada
        if (typeof window.showUnifiedRewardsHUD === 'function') {
          setTimeout(async () => {
            try {
              await window.showUnifiedRewardsHUD([{ type: 'coins', amount: coinsEarned }], '¡VICTORIA EN BATALLA!');
            } catch (hudErr) {
              console.warn('[BATTLE] Error en HUD de recompensas:', hudErr);
            }
          }, 600);
        }
      }

      // Actualizar progreso de misiones, kizunas y evoluciones
      if (isInfiniteOffline && typeof window.recordInfiniteLevelPlayed === 'function') {
        try {
          window.recordInfiniteLevelPlayed();
        } catch (infErr) {
          console.warn('[MISSIONS] Error registrando nivel infinito jugado:', infErr);
        }
      }
      if (window.kvrcards && typeof window.kvrcards.addBattlePlayed === 'function') {
        try {
          await window.kvrcards.addBattlePlayed();
        } catch (bpErr) {
          console.warn('[STATS] Error incrementando batalla jugada:', bpErr);
        }
      }
      if (typeof window.recordGenericMissionProgress === 'function') {
        try {
          await window.recordGenericMissionProgress('battles_played', 1);
          await window.recordGenericMissionProgress('play_games', 1);
          if (playerWonBattle) {
            await window.recordGenericMissionProgress('battles_won', 1);
            await window.recordGenericMissionProgress('win_games', 1);
          }
        } catch (gmErr) {
          console.warn('[MISSIONS] Error registrando progreso genérico de combate:', gmErr);
        }
      }
      if (typeof updateMissionsProgress === 'function') {
        updateMissionsProgress().catch(e => console.warn('[MISSIONS] Error actualizando progreso:', e));
      }
      if (typeof updateKizunasProgress === 'function') {
        updateKizunasProgress().catch(e => console.warn('[KIZUNAS] Error actualizando progreso:', e));
      }
      if (typeof window.recordEvolutionBattleEnded === 'function') {
        try {
          window.recordEvolutionBattleEnded(window.battleState?.playerTeam || [], playerWonBattle);
        } catch (evoEndErr) {
          console.warn('[EVOLUTIONS] Error registrando fin de batalla:', evoEndErr);
        }
      }
      if (typeof checkEvolutionMissions === 'function') {
        setTimeout(() => checkEvolutionMissions(true), 500);
      }
    } catch (bgError) {
      console.error('[BATTLE] Error en proceso de fondo post-batalla:', bgError);
    }
  })();
}

// Gestor de timeouts activos de batalla para cancelación al abandonar/limpiar
window.__activeBattleTimeouts = window.__activeBattleTimeouts || [];
function clearAllBattleTimeouts() {
  if (Array.isArray(window.__activeBattleTimeouts)) {
    window.__activeBattleTimeouts.forEach(t => clearTimeout(t));
    window.__activeBattleTimeouts = [];
  }
}
window.clearAllBattleTimeouts = clearAllBattleTimeouts;

function cleanAllBattleStatButtonsAndDisplays() {
  console.log('[BATTLE] Limpiando todos los botones y displays de stats (DOM)...');
  const statElements = document.querySelectorAll(
    '.battle-stat-btn, .battle-stat-display, .stat-item, .stat-btn, .roulette-stat-item, button[data-stat], [data-stat]'
  );
  statElements.forEach(el => {
    el.classList.remove(
      'used', 'highlighted', 'highlighted-static', 'highlight-opponent', 'highlight-player',
      'annulled', 'disabled', 'selected', 'nerfed', 'boosted',
      'stat-winner', 'stat-loser', 'winner', 'loser', 'active', 'animating', 'disabled-stat'
    );
    el.disabled = false;
    el.style.opacity = '';
    el.style.borderColor = '';
    el.style.background = '';
    el.style.backgroundColor = '';
    el.style.boxShadow = '';
    el.style.color = '';
    el.style.pointerEvents = '';
    el.style.cursor = '';
    el.style.transform = '';
    el.style.filter = '';
    const label = el.querySelector('.stat-label');
    if (label) {
      label.innerHTML = label.innerHTML.replace(/\(BLOQUEADO\)\s*/g, '').replace(/\u{1F512}\s*/gu, '');
    }
  });
}
window.cleanAllBattleStatButtonsAndDisplays = cleanAllBattleStatButtonsAndDisplays;

/**
 * Master Battle Cleanup Function
 * Limpia absolutamente TODO el estado de batalla (scores, stats, cartas, poderes, DOM, overlays)
 * para evitar fugas entre batallas clásicas, alternativas, draft y modo infinito.
 */
function cleanUpBattleCompletely(options = {}) {
  console.log('[BATTLE] Ejecutando limpieza exhaustiva de batalla (cleanUpBattleCompletely)...', options);

  // 0. Cancelar cualquier timeout o temporizador pendiente de combate
  clearAllBattleTimeouts();

  // Resetear flags globales de estado de batalla
  window.__battleEnded = false;
  window.__battleCancelled = false;

  // 1. Limpieza de Audio de batalla
  if (typeof stopBattleIntroMusic === 'function') {
    stopBattleIntroMusic();
  } else if (typeof window.stopBattleIntroMusic === 'function') {
    window.stopBattleIntroMusic();
  }
  if (options.resumeMenuMusic && typeof resumeMenuMusic === 'function') {
    resumeMenuMusic();
  }

  // 2. Limpieza de Marcadores y Puntuaciones en DOM
  const scoreElements = [
    'score-player-value',
    'score-opponent-value',
    'result-player-score',
    'result-opponent-score',
    'round-result-player-value',
    'round-result-opponent-value',
    'tie-total-player-value',
    'tie-total-opponent-value'
  ];
  scoreElements.forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.textContent = '0';
    }
  });

  // 3. Limpieza de Botones y Displays de Estadísticas (Stats)
  cleanAllBattleStatButtonsAndDisplays();

  // 4. Limpieza de Slots de Cartas, Displays y Sidebar
  document.querySelectorAll('.battle-side-player .battle-card-display, .battle-side-opponent .battle-card-display, #player-card-display, #opponent-card-display').forEach(el => {
    el.classList.remove('winner', 'swapping-out', 'swapping-in', 'active', 'animating');
    el.classList.add('empty');
  });

  const playerCardImg = document.getElementById('battle-player-card');
  if (playerCardImg) {
    playerCardImg.style.display = 'none';
    playerCardImg.src = '';
    playerCardImg.classList.remove('battle-card-winner');
  }
  const opponentCardImg = document.getElementById('battle-opponent-card');
  if (opponentCardImg) {
    opponentCardImg.style.display = 'none';
    opponentCardImg.src = '';
    opponentCardImg.classList.remove('battle-card-winner');
  }

  // Limpiar tema de fondo personalizado del entrenador
  const battleScreenElement = document.getElementById('battle-screen');
  if (battleScreenElement) {
    battleScreenElement.classList.remove('trainer-theme');
    battleScreenElement.style.removeProperty('--trainer-battle-bg');
    battleScreenElement.style.backgroundImage = '';
    battleScreenElement.style.backgroundSize = '';
    battleScreenElement.style.backgroundPosition = '';
  }
  const introBgElement = document.querySelector('.battle-intro-background');
  if (introBgElement) {
    introBgElement.style.backgroundImage = '';
    introBgElement.style.backgroundSize = '';
    introBgElement.style.backgroundPosition = '';
  }

  // Remover iconos de traits adheridos a las cartas de combate
  document.querySelectorAll('.card-trait-icon').forEach(el => el.remove());

  document.querySelectorAll('.team-card-slot, .battle-team-card').forEach(el => {
    el.classList.remove('used', 'selected', 'active', 'disabled', 'animating');
  });

  const teamCardsContainer = document.getElementById('battle-team-cards');
  if (teamCardsContainer) {
    teamCardsContainer.innerHTML = '';
  }

  const introCardsContainer = document.getElementById('battle-intro-cards');
  if (introCardsContainer) {
    introCardsContainer.innerHTML = '';
  }

  // 5. Limpieza de Botones de Poderes
  document.querySelectorAll('.battle-power-btn').forEach(btn => {
    btn.classList.remove('used', 'activating', 'active', 'disabled');
    btn.disabled = false;
    btn.style.opacity = '';
    btn.style.pointerEvents = '';
    btn.style.transform = '';
    btn.style.filter = '';
  });

  // 6. Limpieza y Cierre de Overlays y Modales de Batalla
  const overlaysToHide = [
    'round-result-overlay',
    'tie-total-overlay',
    'comparison-modal',
    'battle-roulette',
    'battle-intro',
    'battle-result-screen',
    'battle-team-sidebar'
  ];
  overlaysToHide.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });

  // Reset roulette wheel state completely to prevent bugs on rapid re-entry
  const rouletteWheel = document.getElementById('roulette-wheel');
  if (rouletteWheel) {
    rouletteWheel.style.transition = 'none';
    rouletteWheel.style.transform = 'rotate(0deg)';
  }
  const rouletteResult = document.getElementById('roulette-result');
  if (rouletteResult) rouletteResult.textContent = '';
  if (battleScreenElement) {
    battleScreenElement.classList.remove('blurred');
    battleScreenElement.style.pointerEvents = '';
  }

  const powerOverlay = document.getElementById('power-activation-overlay');
  if (powerOverlay) {
    powerOverlay.classList.remove('show', 'hiding');
    powerOverlay.style.pointerEvents = 'none';
  }

  if (!options.preserveEndScreen) {
    document.querySelectorAll('#confirm-abandon-overlay, .battle-end-screen, .battle-comparison-overlay').forEach(el => {
      el.remove();
    });
  } else {
    document.querySelectorAll('#confirm-abandon-overlay, .battle-comparison-overlay').forEach(el => {
      el.remove();
    });
  }

  // 7. Resetear Estado JS (window.battleState)
  const previousState = window.battleState || {};
  const gameModeToKeep = options.gameMode || previousState.gameMode || window.selectedGameMode || 'clasico7v7';
  const playerTeamToKeep = options.playerTeam || (options.preserveTeam ? previousState.playerTeam : []) || [];
  const opponentTeamToKeep = options.opponentTeam || (options.preserveTeam ? previousState.opponentTeam : []) || [];
  const difficultyToKeep = options.difficulty || (options.preserveTeam ? previousState.difficulty : null);
  const playerPowersToKeep = options.playerPowers || (options.preserveTeam ? previousState.playerPowers : []) || [];
  const opponentPowersToKeep = options.opponentPowers || (options.preserveTeam ? previousState.opponentPowers : []) || [];
  const reserveCardToKeep = options.playerReserveCard !== undefined ? options.playerReserveCard : (options.preserveTeam ? previousState.playerReserveCard : null);

  window.battleState = {
    playerTeam: playerTeamToKeep,
    opponentTeam: opponentTeamToKeep,
    playerCurrentCard: null,
    opponentCurrentCard: null,
    playerScore: 0,
    opponentScore: 0,
    currentRound: 1,
    difficulty: difficultyToKeep,
    opponentName: null,
    opponentTitle: null,
    opponentAvatar: null,
    opponentBackground: null,
    opponentSong: null,
    selectedTrainer: null,
    currentTurn: null,
    roundWinner: null,
    playerUsedStats: [],
    opponentUsedStats: [],
    playerUsedCards: [],
    opponentUsedCards: [],
    selectedStat: null,
    opponentSelectedStat: null,
    annulledStat: null,
    waitingForCardSelection: false,
    gamePhase: 'roulette',
    canChangeCard: true,
    wasTie: false,
    playerTotalInTie: 0,
    opponentTotalInTie: 0,
    playerPowers: playerPowersToKeep,
    opponentPowers: opponentPowersToKeep,
    playerPowersUsed: {
      swap: false,
      powerup: false,
      nerf: false,
      anulo: false,
      intercambio: false
    },
    opponentPowersUsed: {
      swap: false,
      powerup: false,
      nerf: false,
      anulo: false,
      intercambio: false
    },
    playerPowerUpActive: false,
    opponentPowerUpActive: false,
    playerNerfActive: false,
    opponentNerfActive: false,
    playerReserveCard: reserveCardToKeep,
    opponentReserveCard: null,
    playerReserveCardUsed: false,
    opponentReserveCardUsed: false,
    playerConsecutiveLosses: 0,
    opponentConsecutiveLosses: 0,
    statModifiers: {},
    powerUpStats: { player: 0, opponent: 0 },
    nerfedStat: null,
    gameMode: gameModeToKeep,
    isOnline: !!options.isOnline,
    cardTraitsMap: window.cardTraitsMap || previousState.cardTraitsMap || {},
    availableTraits: window.availableTraits || previousState.availableTraits || [],
    infiniteCardBuffs: window.__infiniteRunCardBuffs || (previousState && previousState.infiniteCardBuffs) || {},
    playerSupportPermanentBuff: 0,
    playerSupportTempBuff: 0,
    opponentSupportPermanentBuff: 0,
    opponentSupportTempBuff: 0,
    playerMimoCopiedBuffs: null,
    opponentMimoCopiedBuffs: null,
    playerDecoyCard: null,
    playerImpostorRevealed: false,
    opponentDecoyCard: null,
    opponentImpostorRevealed: false,
    isAbandoned: false
  };

  // 8. Reseteos Auxiliares (Draft, Online)
  if (options.resetDraft !== false && typeof window.resetDraftState === 'function') {
    window.resetDraftState();
  }
  if (options.isFullReset) {
    window.isEventBattle = false;
    window.currentEventBattle = null;
    if (window.onlineState) {
      window.onlineState.inBattle = false;
      window.onlineState.inQueue = false;
      window.onlineState.matchId = null;
      window.onlineState.opponentId = null;
      window.onlineState.teamReadySent = false;
    }
  }

  console.log('[BATTLE] Limpieza exhaustiva completada. Modo actual en battleState:', window.battleState.gameMode);
}

// Registrar explícitamente en el objeto window para accesibilidad global
window.cleanUpBattleCompletely = cleanUpBattleCompletely;

// Iniciar revancha (misma dificultad)
async function startRematch() {
  window.__battleEnded = false;
  window.__battleCancelled = false;
  if (typeof clearAllBattleTimeouts === 'function') {
    clearAllBattleTimeouts();
  }

  // Consumir intento de Batalla de Evento si procede
  const isEventRematch = !window.__infiniteBattleContext?.active && (
    (window.isEventBattle && window.currentEventBattle) ||
    (typeof window.selectedDifficulty === 'string' && window.selectedDifficulty.startsWith('evento_')) ||
    (typeof window.battleState?.difficulty === 'string' && window.battleState.difficulty.startsWith('evento_'))
  );

  if (isEventRematch) {
    const battle = window.currentEventBattle || (typeof window.getEventBattleById === 'function' ? window.getEventBattleById(window.selectedDifficulty || window.battleState?.difficulty) : null);
    if (battle) {
      window.currentEventBattle = battle;
      window.isEventBattle = true;
      if (typeof window.getBattleAttemptsStatus === 'function') {
        const attemptsStatus = window.getBattleAttemptsStatus(battle);
        if (attemptsStatus && (attemptsStatus.isExhausted || attemptsStatus.remaining <= 0)) {
          alert('te quedan 0 intentos diarios a este combate');
          return;
        }
      }
      if (typeof window.recordBattleAttemptCompletion === 'function') {
        window.recordBattleAttemptCompletion(battle.id);
        console.log('[EVENT-BATTLE] Intento consumido en revancha:', battle.id);
      }
    }
  }

  console.log('[BATTLE] Iniciando revancha con dificultad:', window.battleState.difficulty);
  
  // Guardar dificultad, equipo del jugador, carta de reserva Y PODERES
  const savedDifficulty = window.battleState.difficulty;
  const savedPlayerTeam = window.battleState.playerTeam;
  const savedPlayerReserveCard = window.battleState.playerReserveCard;
  const savedPlayerPowers = window.battleState.playerPowers;
  const savedOpponentPowers = window.battleState.opponentPowers;
  const savedGameMode = window.battleState.gameMode || window.selectedGameMode || 'clasico7v7';
  
  console.log('[BATTLE] Guardando poderes y modo para revancha:', savedGameMode, savedPlayerPowers, savedOpponentPowers);
  
  // Limpieza completa antes de inicializar la revancha
  cleanUpBattleCompletely({
    playerTeam: savedPlayerTeam,
    playerReserveCard: savedPlayerReserveCard,
    difficulty: savedDifficulty,
    playerPowers: savedPlayerPowers,
    opponentPowers: savedOpponentPowers,
    gameMode: savedGameMode,
    preserveTeam: true
  });

  window.battleState.playerBuffs = calculateBattleBuffs(savedPlayerTeam);
  window.selectedDifficulty = savedDifficulty;
  window.selectedGameMode = savedGameMode;
  
  // Generar nuevo equipo oponente (puede salir otro entrenador)
  await generateOpponentTeam();
  
  // Recalcular buffeos del oponente después de generar su equipo
  window.battleState.opponentBuffs = calculateBattleBuffs(window.battleState.opponentTeam);
  console.log('[BATTLE] Buffeos del oponente recalculados:', window.battleState.opponentBuffs);
  
  // Mostrar animación de inicio
  showBattleIntro();
}

// Volver al menú principal (Master Reset Function)
function returnToMainMenu() {
  console.log('[BATTLE] Volviendo al menú principal...');

  window.__battleEnded = false;
  window.__battleCancelled = false;
  window.isEventBattle = false;
  window.currentEventBattle = null;
  cleanUpBattleCompletely({ isFullReset: true, resumeMenuMusic: true });
  
  // Limpiar dificultad seleccionada y estado infinito
  window.__infiniteBattleContext = null;
  window.selectedDifficulty = null;
  window.isInfiniteModeTeamBuilding = false;
  if (typeof window.loadSavedTeam === 'function') {
    window.loadSavedTeam();
  }
  if (typeof window.updateTeamBuilderModeUI === 'function') {
    window.updateTeamBuilderModeUI();
  }
  
  console.log('[MENU] Limpiando pantallas y sub-vistas...');
  
  // Ocultar defensivamente todas las vistas y sub-vistas del juego
  const viewsToHide = [
    'battle-result-screen',
    'battle-screen',
    'battle-intro',
    'team-builder',
    'game-view',
    'game-type-selection',
    'online-friendly-selection',
    'matchmaking-screen',
    'friend-battle-screen',
    'difficulty-selection',
    'traits-panel',
    'draft-view'
  ];
  
  viewsToHide.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  });

  // Ocultar también vistas de clases (coleccion, packs, tienda, misiones)
  const classViews = ['collection', 'packs', 'shop', 'missions'];
  classViews.forEach(cls => {
    const el = document.querySelector(`.${cls}`);
    if (el) el.style.display = 'none';
  });
  
  // Cerrar todos los modales activos
  document.querySelectorAll('.trades-modal, .friends-modal, .rankings-modal, .settings-modal, .modal-backdrop').forEach(m => {
    m.classList.remove('show', 'active');
  });
  
  // Resetear la selección de modo de juego para la próxima entrada
  const gameModeSelection = document.getElementById('game-mode-selection');
  if (gameModeSelection) gameModeSelection.style.display = 'block';
  
  // Mostrar menú principal
  const mainMenu = document.getElementById('main-menu');
  if (mainMenu) mainMenu.style.display = 'flex';
  
  console.log('[MENU] Master Reset completado. Menú principal activo.');
}

// Registrar explícitamente en el objeto window para accesibilidad global
window.returnToMainMenu = returnToMainMenu;

// Abandonar batalla
function abandonBattle() {
  if (window.__battleEnded) {
    console.log('[BATTLE] La batalla ya ha finalizado, no se puede abandonar.');
    return;
  }
  console.log('[BATTLE] Jugador intenta abandonar la batalla');
  
  // Evitar duplicados de overlay de confirmación
  if (document.getElementById('confirm-abandon-overlay')) {
    console.log('[BATTLE] El overlay de confirmación ya existe, ignorando llamada duplicada.');
    return;
  }
  
  // Crear overlay de confirmación
  const confirmOverlay = document.createElement('div');
  confirmOverlay.id = 'confirm-abandon-overlay';
  confirmOverlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10000;
  `;
  
  const confirmBox = document.createElement('div');
  confirmBox.style.cssText = `
    background: linear-gradient(135deg, #1e1b4b, #312e81);
    border: 3px solid #ef4444;
    border-radius: 20px;
    padding: 40px;
    max-width: 500px;
    text-align: center;
    box-shadow: 0 10px 50px rgba(239, 68, 68, 0.5);
  `;
  
  confirmBox.innerHTML = `
    <h2 style="color: #ef4444; font-size: 28px; margin-bottom: 20px; text-shadow: 0 0 10px rgba(239, 68, 68, 0.8);">
      ¿Estás seguro?
    </h2>
    <p style="color: white; font-size: 18px; line-height: 1.6; margin-bottom: 30px;">
      ¿Estás seguro de que quieres abandonar la batalla?<br>
      <span style="color: #fca5a5;">Perderás tu progreso y contará como una derrota 7-0 para tu rival.</span>
    </p>
    <div style="display: flex; gap: 20px; justify-content: center;">
      <button id="confirm-abandon-yes" style="
        background: linear-gradient(135deg, #dc2626, #991b1b);
        color: white;
        border: 2px solid #ef4444;
        border-radius: 10px;
        padding: 12px 30px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: all 0.3s ease;
      ">Sí, quiero abandonar</button>
      <button id="confirm-abandon-no" style="
        background: linear-gradient(135deg, #059669, #047857);
        color: white;
        border: 2px solid #10b981;
        border-radius: 10px;
        padding: 12px 30px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: all 0.3s ease;
      ">No</button>
    </div>
  `;
  
  confirmOverlay.appendChild(confirmBox);
  document.body.appendChild(confirmOverlay);
  
  // Event listeners
  document.getElementById('confirm-abandon-yes').addEventListener('click', () => {
    console.log('[BATTLE] Batalla abandonada por el jugador');
    document.body.removeChild(confirmOverlay);

    // Cancelar cualquier timeout o temporizador pendiente de combate
    window.__battleCancelled = true;
    if (window.battleState) {
      window.battleState.isAbandoned = true;
    }
    if (typeof clearAllBattleTimeouts === 'function') {
      clearAllBattleTimeouts();
    }

    const isOnlineBattle = !!(window.battleState?.isOnline && window.onlineState?.inBattle && window.onlineState?.socket && window.onlineState?.matchId);

    if (isOnlineBattle) {
      // En online, notificar al servidor y resetear estado completo del cliente
      window.onlineState.socket.emit('leave-match', {
        matchId: window.onlineState.matchId,
        reason: 'surrender'
      });

      showNotification('Abandonando batalla... contará como derrota 7-0', 'warning');
      
      // Limpieza exhaustiva inmediata para que no queden datos en memoria/DOM
      cleanUpBattleCompletely({ isOnline: false, isFullReset: true, resumeMenuMusic: true });
      returnToMainMenu();
      return;
    }
    
    // En batalla offline: limpiar estado residual de combate
    cleanUpBattleCompletely({
      preserveTeam: true,
      difficulty: window.battleState?.difficulty,
      gameMode: window.battleState?.gameMode
    });

    // Establecer puntuación 0-7 para resultado de derrota
    window.battleState.playerScore = 0;
    window.battleState.opponentScore = 7;
    
    // Finalizar batalla con derrota forzada garantizando que no se sobreescriba
    endBattle({ force: true, isAbandon: true });
  });
  
  document.getElementById('confirm-abandon-no').addEventListener('click', () => {
    console.log('[BATTLE] Jugador cancela abandono');
    document.body.removeChild(confirmOverlay);
  });
}

// ==================== SISTEMA DE PODERES ====================

// Usar poder de intercambio de carta
async function usePowerSwap(isPlayer) {
  const side = isPlayer ? 'player' : 'opponent';
  const powerKey = 'swap';
  
  console.log(`[POWER] ${side} intenta usar poder de intercambio`);
  
  // Verificar si ya fue usado
  if (window.battleState[`${side}PowersUsed`][powerKey]) {
    console.log(`[POWER] Poder ya usado por ${side}`);
    return;
  }
  
  // Obtener la carta de reserva guardada
  const reserveCard = window.battleState[`${side}ReserveCard`];
  
  if (!reserveCard) {
    console.log(`[POWER] No hay carta de reserva guardada para ${side}`);
    return;
  }
  
  console.log(`[POWER] Carta de reserva encontrada:`, reserveCard.nombre || reserveCard.name);
  
  // Verificar si la carta de reserva ya fue usada
  if (window.battleState[`${side}ReserveCardUsed`]) {
    console.log(`[POWER] La carta de reserva ya fue usada por ${side}`);
    return;
  }
  
  // Marcar poder como usado
  window.battleState[`${side}PowersUsed`][powerKey] = true;
  window.battleState[`${side}ReserveCardUsed`] = true;
  
  // Actualizar botón visualmente
  const powerBtn = document.getElementById(`${side}-power-swap`);
  if (powerBtn) {
    powerBtn.classList.add('used', 'activating');
    setTimeout(() => powerBtn.classList.remove('activating'), 600);
  }
  
  console.log(`[POWER] ${side} activa poder de intercambio`);
  
  // Mostrar animación de activación
  const userName = isPlayer ? (currentUser || 'Jugador') : (window.battleState.opponentName || 'IA');
  await showPowerActivation('swap', userName, isPlayer);
  
  // Obtener carta actual
  const currentCard = window.battleState[`${side}CurrentCard`];
  const team = isPlayer ? window.battleState.playerTeam : window.battleState.opponentTeam;
  const currentCardIndex = team.indexOf(currentCard);
  
  console.log(`[POWER] Intercambiando carta actual (${currentCard.nombre || currentCard.name}) por carta de reserva (${reserveCard.nombre || reserveCard.name})`);
  
  // Animación de intercambio
  const cardDisplay = document.querySelector(`.battle-side-${side} .battle-card-display`);
  
  if (cardDisplay) {
    // Animar salida de carta actual
    cardDisplay.classList.add('swapping-out');
    
    await new Promise(resolve => setTimeout(resolve, 600));
    
    // Marcar carta actual como usada (inutilizada) en el array de cartas usadas
    const usedCards = isPlayer ? window.battleState.playerUsedCards : window.battleState.opponentUsedCards;
    if (!usedCards.includes(currentCardIndex)) {
      usedCards.push(currentCardIndex);
    }
    
    // Cambiar a carta de reserva
    window.battleState[`${side}CurrentCard`] = reserveCard;
    
    // Actualizar cartas en pantalla
    updateBattleCards();
    
    // Remover clase de salida y agregar clase de entrada
    cardDisplay.classList.remove('swapping-out');
    cardDisplay.classList.add('swapping-in');
    
    await new Promise(resolve => setTimeout(resolve, 600));
    
    // Limpiar clases de animación
    cardDisplay.classList.remove('swapping-in');
  }
  
  console.log(`[POWER] Intercambio completado para ${side}`);
}

// Usar poder de Power Up (+3 a todas las stats)
async function usePowerUp(isPlayer) {
  const side = isPlayer ? 'player' : 'opponent';
  const powerKey = 'powerup';
  
  console.log(`[POWER] ${side} intenta usar Power Up`);
  
  // Verificar si ya fue usado
  if (window.battleState[`${side}PowersUsed`][powerKey]) {
    console.log(`[POWER] Power Up ya usado por ${side}`);
    return;
  }
  
  // Verificar que estamos en fase de selección de stat
  if (window.battleState.gamePhase !== 'stat-selection') {
    console.log(`[POWER] No se puede usar Power Up fuera de la fase de selección de stat`);
    return;
  }
  
  // Marcar poder como usado y activado (+3 se gestiona mediante playerPowerUpActive / opponentPowerUpActive)
  window.battleState[`${side}PowersUsed`][powerKey] = true;
  window.battleState[`${side}PowerUpActive`] = true;
  
  // Actualizar botón visualmente
  const powerBtn = document.getElementById(`${side}-power-powerup`);
  if (powerBtn) {
    powerBtn.classList.add('used', 'activating');
    setTimeout(() => powerBtn.classList.remove('activating'), 600);
  }
  
  console.log(`[POWER] ${side} activa Power Up (+3 a todas las stats)`);
  
  // Mostrar animación de activación
  const userName = isPlayer ? (currentUser || 'Jugador') : (window.battleState.opponentName || 'IA');
  await showPowerActivation('powerup', userName, isPlayer);
  
  // Actualizar visualmente la carta y buffeos mediante la función canónica
  if (typeof updateBattleCards === 'function') {
    updateBattleCards();
  }
  if (typeof updateBattleBuffsDisplay === 'function') {
    updateBattleBuffsDisplay();
  }
  
  console.log(`[POWER] Power Up aplicado canónicamente para ${side}`);
}

// Aplicar efecto visual de NERF a la stat elegida por el enemigo
function applyNerfVisual(isPlayer) {
  const side = isPlayer ? 'player' : 'opponent';
  const enemySide = isPlayer ? 'opponent' : 'player';
  
  console.log(`[POWER] Aplicando visual de NERF de ${side}`);
  
  // Obtener la stat elegida por el enemigo
  // ONLINE FIX: 'selectedStat' es la propiedad para el jugador local, 'opponentSelectedStat' para el oponente
  const enemySelectedStat = enemySide === 'player' 
    ? (window.battleState.selectedStat || window.battleState.playerSelectedStat)
    : window.battleState.opponentSelectedStat;
  if (!enemySelectedStat) {
    console.error(`[POWER] El enemigo (${enemySide}) no ha elegido stat todavía`);
    return false;
  }
  
  console.log(`[POWER] ${side} aplica NERF a stat ${enemySelectedStat} del enemigo`);
  
  // Obtener la carta del enemigo
  const enemyCard = window.battleState[`${enemySide}CurrentCard`];
  if (!enemyCard) {
    console.error(`[POWER] No hay carta actual para ${enemySide}`);
    return false;
  }
  
  // Inmunidad a debuffs por rasgos Especialista y Monarch
  if (typeof isCardDebuffImmune === 'function' && isCardDebuffImmune(enemyCard, enemySide)) {
    console.log(`[POWER] ${enemySide} es inmune a debuffs y NERF por trait (Especialista/Monarch)`);
    if (typeof showNotification === 'function') {
      showNotification('Inmune a debuffs por trait', 'warning');
    }
    return true;
  }
  
  // Aplicar nerf (-5 a la stat elegida por el enemigo)
  const enemyPrefix = enemySide === 'player' ? 'battle-player' : 'battle-opponent';
  
  // Determinar qué elemento actualizar según la stat elegida
  let statElement;
  let statContainer;
  if (enemySelectedStat === 'media') {
    statElement = document.getElementById(`${enemyPrefix}-media`);
    // Buscar el contenedor padre (btn para player, display para opponent)
    statContainer = document.querySelector(`.battle-side-${enemySide} .battle-stat-btn[data-stat="media"]`) ||
                    document.querySelector(`.battle-side-${enemySide} .battle-stat-display[data-stat="media"]`);
  } else {
    // Obtener el índice de la stat usando el nombre
    const statNames = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
    const statIndex = statNames.indexOf(enemySelectedStat);
    statElement = document.getElementById(`${enemyPrefix}-stat${statIndex + 1}`);
    // Buscar el contenedor padre (btn para player, display para opponent)
    statContainer = document.querySelector(`.battle-side-${enemySide} .battle-stat-btn[data-stat="${enemySelectedStat}"]`) ||
                    document.querySelector(`.battle-side-${enemySide} .battle-stat-display[data-stat="${enemySelectedStat}"]`);
  }
  
  // Obtener el valor calculado de la stat (incluye modificadores activos)
  const originalValue = (typeof getDisplayedBattleStatValue === 'function' ? getDisplayedBattleStatValue(enemySide, enemySelectedStat) : null) ?? getStatValue(enemyCard, enemySelectedStat, enemySide);
  
  // ===== REGISTRAR MODIFICADOR DE NERF =====
  // Guardar el modificador de -5 en la stat específica para todos los identificadores de la carta
  // Se usa Set para evitar duplicar la clave cuando uniqueId esta vacio (id y String(id) son iguales)
  const cardKeys = [...new Set([enemyCard.uniqueId, enemyCard.id, String(enemyCard.id)].filter(Boolean))];
  cardKeys.forEach(k => {
    if (!window.battleState.statModifiers[k]) {
      window.battleState.statModifiers[k] = {};
    }
    window.battleState.statModifiers[k][enemySelectedStat] = (window.battleState.statModifiers[k][enemySelectedStat] || 0) - 5;
  });
  console.log(`[STATS-MOD] NERF registrado para ${enemyCard.nombre || enemyCard.name} en stat ${enemySelectedStat}: -5`);

  // Actualizar cartas canónicamente con los modificadores calculados
  if (typeof updateBattleCards === 'function') {
    updateBattleCards();
  }

  // Obtener valor resultante tras la actualización (incluye tanto Nerf como Power Up u otros buffs)
  const nerfedValue = (statElement && Number.isFinite(parseInt(statElement.textContent, 10)))
    ? parseInt(statElement.textContent, 10)
    : Math.max(1, ((typeof getDisplayedBattleStatValue === 'function' ? getDisplayedBattleStatValue(enemySide, enemySelectedStat) : null) ?? getStatValue(enemyCard, enemySelectedStat, enemySide)));

  console.log(`[POWER] ===== APLICANDO NERF VISUAL =====`);
  console.log(`[POWER] statElement:`, statElement);
  console.log(`[POWER] statContainer:`, statContainer);
  console.log(`[POWER] Valor original: ${originalValue}, Nuevo valor: ${nerfedValue}`);

  if (statElement) {
    console.log(`[POWER] Actualizando statElement con Nerf visual (-5 en rojo)`);
    // Mostrar solo valor final con color rojo
    statElement.textContent = `${nerfedValue}`;
    statElement.style.setProperty('color', '#ef4444', 'important'); // Rojo para nerf
    statElement.style.fontWeight = 'bold';
    console.log(`[POWER] Después de actualizar:`, statElement.innerHTML);
  } else {
    console.error(`[POWER] statElement es null`);
  }
  
  // Añadir clase CSS 'nerfed' al contenedor y forzar visibilidad sin grayscale
  if (statContainer) {
    console.log(`[POWER] Añadiendo clase 'nerfed' al contenedor`);
    statContainer.classList.add('nerfed');
    statContainer.style.setProperty('filter', 'none', 'important');
    statContainer.style.setProperty('opacity', '1', 'important');
    statContainer.style.setProperty('background-color', '#7f1d1d', 'important');
    statContainer.style.setProperty('border-color', '#ef4444', 'important');
    console.log(`[POWER] Clases del contenedor:`, statContainer.classList);
  } else {
    console.error(`[POWER] statContainer es null`);
  }
  
  console.log(`[POWER] NERF aplicado visualmente: ${originalValue} → ${nerfedValue} en ${enemySelectedStat} de ${enemySide}`);
  console.log(`[POWER] ===== FIN NERF VISUAL =====`);
  
  // Guardar referencia para poder re-aplicar si algo sobrescribe
  window.battleState.nerfAppliedTo = {
    side: enemySide,
    stat: enemySelectedStat,
    value: nerfedValue
  };
  
  return true;
}

// Re-aplicar NERF visual si está activo (llamar después de updateBattleCards)
function reapplyNerfVisualIfActive() {
  const statNames = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];

  if (window.battleState.playerNerfActive && window.battleState.nerfAppliedTo) {
    const { side, stat } = window.battleState.nerfAppliedTo;
    if (side === 'opponent') {
      const opponentCard = window.battleState.opponentCurrentCard;
      if (typeof isCardDebuffImmune === 'function' && isCardDebuffImmune(opponentCard, 'opponent')) {
        return;
      }
      console.log('[POWER] Re-aplicando NERF visual del jugador');
      const statIdx = statNames.indexOf(stat);
      const statEl = stat === 'media'
        ? document.getElementById('battle-opponent-media')
        : (statIdx !== -1 ? document.getElementById(`battle-opponent-stat${statIdx + 1}`) : null);
      const statContainer = document.querySelector(`.battle-side-opponent .battle-stat-btn[data-stat="${stat}"]`) ||
                           document.querySelector(`.battle-side-opponent .battle-stat-display[data-stat="${stat}"]`);
      
      const effectiveVal = (statEl && Number.isFinite(parseInt(statEl.textContent, 10)))
        ? parseInt(statEl.textContent, 10)
        : (opponentCard && typeof getStatValue === 'function'
            ? getStatValue(opponentCard, stat, 'opponent')
            : window.battleState.nerfAppliedTo.value);

      if (Number.isFinite(effectiveVal)) {
        window.battleState.nerfAppliedTo.value = effectiveVal;
        if (statEl) {
          statEl.textContent = `${effectiveVal}`;
        }
      }

      if (statEl) {
        statEl.style.setProperty('color', '#ef4444', 'important');
        statEl.style.fontWeight = 'bold';
      }
      if (statContainer) {
        statContainer.classList.add('nerfed');
        statContainer.style.setProperty('filter', 'none', 'important');
        statContainer.style.setProperty('opacity', '1', 'important');
        statContainer.style.setProperty('background-color', '#7f1d1d', 'important');
        statContainer.style.setProperty('border-color', '#ef4444', 'important');
      }
    }
  }
  
  if (window.battleState.opponentNerfActive && window.battleState.nerfAppliedTo) {
    const { side, stat } = window.battleState.nerfAppliedTo;
    if (side === 'player') {
      const playerCard = window.battleState.playerCurrentCard;
      if (typeof isCardDebuffImmune === 'function' && isCardDebuffImmune(playerCard, 'player')) {
        return;
      }
      console.log('[POWER] Re-aplicando NERF visual de la IA');
      const statIdx = statNames.indexOf(stat);
      const statEl = stat === 'media'
        ? document.getElementById('battle-player-media')
        : (statIdx !== -1 ? document.getElementById(`battle-player-stat${statIdx + 1}`) : null);
      const statContainer = document.querySelector(`.battle-side-player .battle-stat-btn[data-stat="${stat}"]`) ||
                           document.querySelector(`.battle-side-player .battle-stat-display[data-stat="${stat}"]`);
      
      const effectiveVal = (statEl && Number.isFinite(parseInt(statEl.textContent, 10)))
        ? parseInt(statEl.textContent, 10)
        : (playerCard && typeof getStatValue === 'function'
            ? getStatValue(playerCard, stat, 'player')
            : window.battleState.nerfAppliedTo.value);

      if (Number.isFinite(effectiveVal)) {
        window.battleState.nerfAppliedTo.value = effectiveVal;
        if (statEl) {
          statEl.textContent = `${effectiveVal}`;
        }
      }

      if (statEl) {
        statEl.style.setProperty('color', '#ef4444', 'important');
        statEl.style.fontWeight = 'bold';
      }
      if (statContainer) {
        statContainer.classList.add('nerfed');
        statContainer.style.setProperty('filter', 'none', 'important');
        statContainer.style.setProperty('opacity', '1', 'important');
        statContainer.style.setProperty('background-color', '#7f1d1d', 'important');
        statContainer.style.setProperty('border-color', '#ef4444', 'important');
      }
    }
  }
}

// Animacion de revelacion de carta para el rasgo Impostor
async function revealImpostorCard(side) {
  const cardDisplay = document.querySelector(`.battle-side-${side} .battle-card-display`);
  if (cardDisplay) {
    cardDisplay.classList.add('swapping-out');
    await new Promise(resolve => setTimeout(resolve, 600));
    
    if (side === 'player') {
      window.battleState.playerImpostorRevealed = true;
    } else {
      window.battleState.opponentImpostorRevealed = true;
    }
    
    if (typeof updateBattleCards === 'function') {
      updateBattleCards();
    }
    
    cardDisplay.classList.remove('swapping-out');
    cardDisplay.classList.add('swapping-in');
    await new Promise(resolve => setTimeout(resolve, 600));
    cardDisplay.classList.remove('swapping-in');
  } else {
    if (side === 'player') {
      window.battleState.playerImpostorRevealed = true;
    } else {
      window.battleState.opponentImpostorRevealed = true;
    }
    if (typeof updateBattleCards === 'function') {
      updateBattleCards();
    }
  }
}
window.revealImpostorCard = revealImpostorCard;

// Restaurar colores originales de las stats después de desactivar Power Up
function restoreStatsColors(side) {
  console.log(`[POWER] Restaurando colores originales para ${side}`);
  
  const card = window.battleState[`${side}CurrentCard`];
  if (!card) return;
  
  const stats = card.stats || card.parametros || [];
  const media = parseInt(card.media) || 0;
  const prefix = side === 'player' ? 'battle-player' : 'battle-opponent';
  
  // Obtener boosts de traits si existen (deben mantenerse después de quitar Power Up)
  const cardTraitsMap = window.battleState.cardTraitsMap || {};
  const availableTraits = window.battleState.availableTraits || [];
  let traitBoosts = {}; // {stat: value} o {all: value}
  
  const cardKey = card.uniqueId || card.id;
  const traitId = (typeof getCardActiveTraitId === 'function') ? getCardActiveTraitId(card, side) : (side === 'opponent' ? card.opponentTraitId : (card.traitId || (cardTraitsMap[cardKey]?.traitId || cardTraitsMap[cardKey])));
  const trait = traitId ? ((typeof window.getTraitById === 'function') ? window.getTraitById(traitId) : availableTraits.find(t => t.id === traitId)) : null;
  if (trait && trait.effect) {
    if (trait.effect.type === 'boost_stat') {
      traitBoosts[trait.effect.stat] = trait.effect.value || 0;
    } else if (trait.effect.type === 'boost_all') {
      traitBoosts.all = trait.effect.value || 0;
    }
  }
  
  // Modificadores de Modo Infinito para la carta del jugador
  const baseId = card.id ? String(card.id).replace(/_notrait.*$/, '') : cardKey;
  const infiniteBuffMap = (side === 'player') ? (window.battleState?.infiniteCardBuffs || window.__infiniteRunCardBuffs) : null;
  const infiniteCardBuffs = infiniteBuffMap ? (infiniteBuffMap[cardKey] || infiniteBuffMap[card.id] || infiniteBuffMap[baseId] || {}) : {};

  // Restaurar media (con trait boost e infinite delta si existen)
  const mediaEl = document.getElementById(`${prefix}-media`);
  if (mediaEl) {
    const traitBoost = traitBoosts.all || 0;
    const infiniteStatValues = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'].map((s) => Number(infiniteCardBuffs[s]) || 0);
    const infiniteMediaDelta = Math.round(infiniteStatValues.reduce((a, b) => a + b, 0) / (infiniteStatValues.length || 1));
    const totalMediaBoost = traitBoost + infiniteMediaDelta;
    mediaEl.textContent = Math.max(1, media + totalMediaBoost);
    if (totalMediaBoost > 0) {
      mediaEl.style.color = '#22c55e';
      mediaEl.style.fontWeight = 'bold';
    } else if (totalMediaBoost < 0) {
      mediaEl.style.color = '#ef4444';
      mediaEl.style.fontWeight = 'bold';
    } else {
      mediaEl.style.color = '';
      mediaEl.style.fontWeight = '';
    }
  }
  
  // Restaurar contenedor de media (btn o display)
  const mediaContainer = document.querySelector(`.battle-side-${side} .battle-stat-btn[data-stat="media"]`) ||
                         document.querySelector(`.battle-side-${side} .battle-stat-display[data-stat="media"]`);
  if (mediaContainer) {
    mediaContainer.classList.remove('nerfed');
    mediaContainer.style.filter = '';
    mediaContainer.style.opacity = '';
    mediaContainer.style.backgroundColor = '';
    mediaContainer.style.borderColor = '';
  }
  
  // Restaurar stats individuales (con trait boosts e infinite delta si existen)
  const statNames = ['ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico'];
  for (let i = 0; i < 6; i++) {
    const statEl = document.getElementById(`${prefix}-stat${i + 1}`);
    if (statEl) {
      const originalValue = parseInt(stats[i]) || 0;
      const traitBoost = (traitBoosts.all || 0) + (traitBoosts[statNames[i]] || 0);
      const statInfiniteDelta = Number(infiniteCardBuffs[statNames[i]]) || 0;
      const totalStatBoost = traitBoost + statInfiniteDelta;
      statEl.textContent = Math.max(1, originalValue + totalStatBoost);
      if (totalStatBoost > 0) {
        statEl.style.color = '#22c55e';
        statEl.style.fontWeight = 'bold';
      } else if (totalStatBoost < 0) {
        statEl.style.color = '#ef4444';
        statEl.style.fontWeight = 'bold';
      } else {
        statEl.style.color = '';
        statEl.style.fontWeight = '';
      }
    }
    
    // Restaurar contenedor de stat (btn o display)
    const statContainer = document.querySelector(`.battle-side-${side} .battle-stat-btn[data-stat="${statNames[i]}"]`) ||
                          document.querySelector(`.battle-side-${side} .battle-stat-display[data-stat="${statNames[i]}"]`);
    if (statContainer) {
      statContainer.classList.remove('nerfed');
      statContainer.style.filter = '';
      statContainer.style.opacity = '';
      statContainer.style.backgroundColor = '';
      statContainer.style.borderColor = '';
    }
  }
  
  console.log(`[POWER] Colores restaurados para ${side}`);
}

// Configurar event listeners de poderes
function setupPowerButtons() {
  if (window.BattlePowers && typeof window.BattlePowers.setupPowerButtons === 'function') {
    return window.BattlePowers.setupPowerButtons();
  }
  console.warn('[POWER] BattlePowers module no disponible; setupPowerButtons no ejecutado');
}

// Helper: Comprobar si el oponente realmente tiene equipado un poder específico
function opponentHasPower(powerName) {
  const powers = (window.battleState && Array.isArray(window.battleState.opponentPowers)) 
    ? window.battleState.opponentPowers.map(p => String(p).toLowerCase().trim()) 
    : [];
  
  if (powerName === 'swap' || powerName === 'reserva') {
    return powers.some(p => ['swap', 'reserva', 'reserve_card'].includes(p));
  }
  if (powerName === 'powerup') {
    return powers.some(p => ['powerup', 'power_up'].includes(p));
  }
  if (powerName === 'nerf') {
    return powers.includes('nerf');
  }
  if (powerName === 'anulo') {
    return powers.includes('anulo');
  }
  if (powerName === 'intercambio') {
    return powers.some(p => ['intercambio', 'exchange', 'swap_cards'].includes(p));
  }
  return powers.includes(powerName.toLowerCase().trim());
}

// La IA decide si usa el poder de intercambio (ESTRATÉGICAMENTE)
async function opponentConsidersPowerSwap() {
  // Solo considerar si el oponente tiene el poder, no lo ha usado y es su turno de elegir stat
  if (!opponentHasPower('swap') || window.battleState.opponentPowersUsed.swap || window.battleState.gamePhase !== 'stat-selection') {
    return false;
  }
  
  // SOLO usar el poder si el JUGADOR ya eligió primero
  if (!window.battleState.selectedStat) {
    console.log('[POWER] IA espera - jugador no ha elegido stat aún');
    return false;
  }
  
  // Verificar si tiene carta de reserva y no la ha usado
  if (!window.battleState.opponentReserveCard || window.battleState.opponentReserveCardUsed) {
    console.log('[POWER] IA no puede usar poder - no hay carta de reserva o ya fue usada');
    return false;
  }
  
  // Obtener el stat elegido por el jugador y su valor
  const playerCard = window.battleState.playerCurrentCard;
  const playerStatValue = (typeof getDisplayedBattleStatValue === 'function' ? getDisplayedBattleStatValue('player', window.battleState.selectedStat) : null) ?? getStatValue(playerCard, window.battleState.selectedStat, 'player');
  
  console.log('[POWER] IA analiza situación:');
  console.log('[POWER] - Jugador eligió:', window.battleState.selectedStat, 'con valor', playerStatValue);
  
  // Obtener carta actual del oponente y carta de reserva
  const currentCard = window.battleState.opponentCurrentCard;
  const reserveCard = window.battleState.opponentReserveCard;
  
  // Obtener el valor del mismo stat en ambas cartas
  const currentCardStatValue = (typeof getDisplayedBattleStatValue === 'function' ? getDisplayedBattleStatValue('opponent', window.battleState.selectedStat) : null) ?? getStatValue(currentCard, window.battleState.selectedStat, 'opponent');
  const reserveCardStatValue = getStatValue(reserveCard, window.battleState.selectedStat, 'opponent');
  
  console.log('[POWER] - Carta actual del oponente:', currentCard.nombre || currentCard.name, '- valor:', currentCardStatValue);
  console.log('[POWER] - Carta de reserva:', reserveCard.nombre || reserveCard.name, '- valor:', reserveCardStatValue);
  
  // LÓGICA ESTRATÉGICA:
  // 1. Si la carta actual NO puede ganar (currentCardStatValue <= playerStatValue)
  // 2. Y la carta de reserva SÍ puede ganar (reserveCardStatValue > playerStatValue)
  // 3. Entonces usar el poder
  
  const currentCardWins = currentCardStatValue > playerStatValue;
  const reserveCardWins = reserveCardStatValue > playerStatValue;
  
  if (!currentCardWins && reserveCardWins) {
    console.log('[POWER] IA DECIDE USAR PODER - Carta actual pierde pero reserva gana');
    console.log('[POWER] - Carta actual:', currentCardStatValue, '≤', playerStatValue, '(pierde)');
    console.log('[POWER] - Carta reserva:', reserveCardStatValue, '>', playerStatValue, '(gana)');
    await usePowerSwap(false);
    return true;
  } else {
    if (currentCardWins) {
      console.log('[POWER] IA NO usa poder - carta actual ya gana');
    } else if (!reserveCardWins) {
      console.log('[POWER] IA NO usa poder - carta de reserva tampoco ganaría');
    }
    return false;
  }
}

// La IA decide si usa el poder de Power Up (ESTRATÉGICAMENTE)
async function opponentConsidersPowerUp() {
  // Solo considerar si el oponente tiene el poder, no lo ha usado y está en fase de selección
  if (!opponentHasPower('powerup') || window.battleState.opponentPowersUsed.powerup || window.battleState.gamePhase !== 'stat-selection') {
    return false;
  }
  
  // SOLO usar el poder si el JUGADOR ya eligió primero
  if (!window.battleState.selectedStat) {
    console.log('[POWER] IA espera - jugador no ha elegido stat aún para Power Up');
    return false;
  }
  
  console.log('[POWER] IA considera usar Power Up');
  
  // Obtener el stat elegido por el jugador y su valor
  const playerCard = window.battleState.playerCurrentCard;
  const playerStatValue = (typeof getDisplayedBattleStatValue === 'function' ? getDisplayedBattleStatValue('player', window.battleState.selectedStat) : null) ?? getStatValue(playerCard, window.battleState.selectedStat, 'player');
  
  // Obtener carta actual del oponente
  const opponentCard = window.battleState.opponentCurrentCard;
  
  // Obtener stats disponibles de la IA (o la ya seleccionada si el oponente eligió primero)
  const availableStats = window.battleState.opponentSelectedStat
    ? [window.battleState.opponentSelectedStat]
    : ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
        .filter(s => !window.battleState.opponentUsedStats.includes(s));
  
  console.log('[POWER] IA analiza Power Up:');
  console.log('[POWER] - Stat elegido por jugador:', window.battleState.selectedStat);
  console.log('[POWER] - Valor del jugador:', playerStatValue);
  console.log('[POWER] - Stats disponibles para IA:', availableStats);
  
  // Evaluar si alguna stat disponible con Power Up puede ganar
  let canWinWithoutPowerUp = false;
  let canWinWithPowerUp = false;
  
  for (const stat of availableStats) {
    const statValue = getStatValue(opponentCard, stat, 'opponent');
    const statValueWithPowerUp = statValue + 3;
    
    console.log(`[POWER] - ${stat}: ${statValue} (sin boost) / ${statValueWithPowerUp} (con boost)`);
    
    // Si alguna stat puede ganar sin Power Up
    if (statValue > playerStatValue) {
      canWinWithoutPowerUp = true;
      console.log(`[POWER]   ${stat} puede ganar sin Power Up (${statValue} > ${playerStatValue})`);
    }
    
    // Si alguna stat puede ganar CON Power Up
    if (statValueWithPowerUp > playerStatValue) {
      canWinWithPowerUp = true;
      console.log(`[POWER]   ${stat} puede ganar con Power Up (${statValueWithPowerUp} > ${playerStatValue})`);
    }
  }
  
  // LÓGICA ESTRATÉGICA:
  // Usar Power Up si:
  // 1. NO puede ganar con ninguna stat sin Power Up
  // 2. Pero SÍ puede ganar con al menos una stat con Power Up
  
  if (!canWinWithoutPowerUp && canWinWithPowerUp) {
    console.log('[POWER] IA DECIDE USAR POWER UP');
    console.log('[POWER] - Sin Power Up: No puede ganar');
    console.log('[POWER] - Con Power Up: Puede ganar');
    
    await usePowerUp(false);
    return true;
  }
  
  console.log('[POWER] IA decide NO usar Power Up');
  return false;
}

// La IA decide si usa el poder de NERF (cuando va perdiendo en la partida)
async function opponentConsidersNerfPower() {
  // Solo considerar si el oponente tiene el poder, no lo ha usado, está en fase de selección y está perdiendo
  if (!opponentHasPower('nerf') || 
      window.battleState.opponentPowersUsed.nerf || 
      window.battleState.gamePhase !== 'stat-selection' ||
      window.battleState.opponentScore >= window.battleState.playerScore) {
    return false;
  }
  
  // Verificar que el jugador ya eligió su stat
  if (!window.battleState.selectedStat) {
    console.log('[POWER] IA espera - jugador no ha elegido stat aún para NERF');
    return false;
  }
  
  console.log('[POWER] IA considera usar NERF (va perdiendo la partida)');
  
  // Obtener el stat elegido por el jugador y su valor
  const playerCard = window.battleState.playerCurrentCard;
  const playerStatValue = (typeof getDisplayedBattleStatValue === 'function' ? getDisplayedBattleStatValue('player', window.battleState.selectedStat) : null) ?? getStatValue(playerCard, window.battleState.selectedStat, 'player');
  
  const playerStatValueWithNerf = Math.max(1, playerStatValue - 5); // Valor después de aplicar NERF
  
  console.log('[POWER] IA analiza NERF:');
  console.log('[POWER] - Stat elegido por jugador:', window.battleState.selectedStat);
  console.log('[POWER] - Valor actual del jugador:', playerStatValue);
  console.log('[POWER] - Valor con NERF:', playerStatValueWithNerf);
  
  // Obtener carta actual del oponente
  const opponentCard = window.battleState.opponentCurrentCard;
  
  // Obtener stats disponibles de la IA (o la ya seleccionada si el oponente eligió primero)
  const availableStats = window.battleState.opponentSelectedStat
    ? [window.battleState.opponentSelectedStat]
    : ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
        .filter(s => !window.battleState.opponentUsedStats.includes(s));
  
  // Evaluar si puede ganar SIN NERF y CON NERF
  let canWinWithoutNerf = false;
  let canWinWithNerf = false;
  
  for (const stat of availableStats) {
    const statValue = getStatValue(opponentCard, stat, 'opponent');
    
    // Si puede ganar SIN NERF
    if (statValue > playerStatValue) {
      canWinWithoutNerf = true;
      console.log(`[POWER] ${stat}: ${statValue} puede ganar SIN NERF (vs ${playerStatValue})`);
    }
    
    // Si esta stat puede ganar DESPUÉS de aplicar NERF al jugador
    if (statValue > playerStatValueWithNerf) {
      canWinWithNerf = true;
      console.log(`[POWER] ${stat}: ${statValue} puede ganar CON NERF (vs ${playerStatValueWithNerf})`);
    }
  }
  
  // LÓGICA: Usar NERF solo si:
  // 1. NO puede ganar sin NERF
  // 2. Pero SÍ puede ganar con NERF
  if (!canWinWithoutNerf && canWinWithNerf) {
    console.log('[POWER] IA DECIDE USAR NERF');
    console.log('[POWER] - Sin NERF: No puede ganar');
    console.log('[POWER] - Con NERF: Puede ganar');
    
    // Marcar NERF como usado
    window.battleState.opponentPowersUsed.nerf = true;
    window.battleState.opponentNerfActive = true;
    
    // Mostrar animación de activación
    const opponentName = window.battleState.opponentName || 'IA';
    await showPowerActivation('nerf', opponentName, false);
    
    // Actualizar botón visualmente
    const powerBtn = document.getElementById('opponent-power-nerf');
    if (powerBtn) {
      powerBtn.classList.add('used', 'activating');
      setTimeout(() => powerBtn.classList.remove('activating'), 600);
    }
    
    // Esperar 800ms para que se vea el botón
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // APLICAR VISUAL DESPUÉS de la animación
    applyNerfVisual(false);
    
    // Esperar otro momento para que se vea el efecto antes de proceder
    await new Promise(resolve => setTimeout(resolve, 800));
    
    return true;
  } else {
    if (canWinWithoutNerf) {
      console.log('[POWER] IA NO usa NERF - ya puede ganar sin él');
    } else {
      console.log('[POWER] IA NO usa NERF - no es suficiente para ganar esta ronda');
    }
    return false;
  }
}

// ==================== LÓGICA DEL PODER ANULO ====================

// Usar poder ANULO
async function usePowerAnulo(isPlayer, stat) {
  const side = isPlayer ? 'player' : 'opponent';
  const enemySide = isPlayer ? 'opponent' : 'player';
  const powerKey = 'anulo';
  
  if (!isPlayer && !opponentHasPower('anulo')) {
    console.log(`[POWER] El oponente no tiene equipado el poder ANULO`);
    return;
  }
  
  console.log(`[POWER] ${side} intenta usar poder ANULO para bloquear stat ${stat}`);
  
  // Verificar si ya fue usado
  if (window.battleState[`${side}PowersUsed`][powerKey]) {
    console.log(`[POWER] ANULO ya usado por ${side}`);
    return;
  }
  
  // Marcar poder como usado y registrar stat anulada
  window.battleState[`${side}PowersUsed`][powerKey] = true;
  window.battleState.annulledStat = stat;
  
  // CANCELAR la elección del rival
  if (isPlayer) {
    window.battleState.opponentSelectedStat = null;
    const index = window.battleState.opponentUsedStats.indexOf(stat);
    if (index !== -1) {
      window.battleState.opponentUsedStats.splice(index, 1);
    }
    const display = document.querySelector(`.battle-side-opponent .battle-stat-display[data-stat="${stat}"]`);
    if (display) {
      display.classList.remove('highlighted', 'used');
    }
  } else {
    window.battleState.selectedStat = null;
    const index = window.battleState.playerUsedStats.indexOf(stat);
    if (index !== -1) {
      window.battleState.playerUsedStats.splice(index, 1);
    }
    const btn = document.querySelector(`.battle-side-player .battle-stat-btn[data-stat="${stat}"]`);
    if (btn) {
      btn.classList.remove('highlighted', 'used');
    }
  }

  // Actualizar botón visualmente
  const powerBtn = document.getElementById(`${side}-power-anulo`);
  if (powerBtn) {
    powerBtn.classList.add('used', 'activating');
    setTimeout(() => powerBtn.classList.remove('activating'), 600);
  }
  
  console.log(`[POWER] ${side} activa poder ANULO para stat:`, stat);
  
  // Mostrar animación de activación
  const userName = isPlayer ? (currentUser || 'Jugador') : (window.battleState.opponentName || 'IA');
  await showPowerActivation('anulo', userName, isPlayer);
  
  // Aplicar efecto de bloqueo visual a la stat anulada del oponente (o del jugador)
  applyAnuloVisual(isPlayer, stat);

  // OBLIGAR al rival a elegir otra stat disponible
  if (isPlayer) {
    const opponentUsed = window.battleState.opponentUsedStats;
    const opponentAvailable = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
      .filter(s => !opponentUsed.includes(s) && s !== stat);

    if (opponentAvailable.length === 1) {
      const remainingStat = opponentAvailable[0];
      console.log(`[POWER-ANULO] Solo queda una stat para la IA: ${remainingStat}. Auto-asignando.`);
      showNotification(`ℹ️ Solo queda 1 stat para el oponente. Se auto-asigna: ${remainingStat.toUpperCase()}`, 'info');
      
      window.battleState.opponentSelectedStat = remainingStat;
      window.battleState.opponentUsedStats.push(remainingStat);
      
      const opponentStatBtn = document.querySelector(`.battle-side-opponent .battle-stat-display[data-stat="${remainingStat}"]`);
      if (opponentStatBtn) {
        opponentStatBtn.classList.add('highlighted', 'used');
      }
      
      // El jugador debe elegir su propia stat
      window.battleState.currentTurn = 'player';
      enableStatSelection();
    } else {
      // Re-elegir usando la IA
      window.battleState.currentTurn = 'opponent';
      opponentSelectsStat();
    }
  } else {
    // Si la IA usó ANULO contra el jugador
    const playerUsed = window.battleState.playerUsedStats;
    const playerAvailable = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
      .filter(s => !playerUsed.includes(s) && s !== stat);

    if (playerAvailable.length === 1) {
      const remainingStat = playerAvailable[0];
      console.log(`[POWER-ANULO] Solo queda una stat para el jugador: ${remainingStat}. Auto-asignando.`);
      showNotification(`Solo te queda 1 estadística. Se ha auto-asignado: ${remainingStat.toUpperCase()}`, 'info');
      
      window.battleState.selectedStat = remainingStat;
      window.battleState.playerUsedStats.push(remainingStat);
      
      const playerBtn = document.querySelector(`.battle-side-player .battle-stat-btn[data-stat="${remainingStat}"]`);
      if (playerBtn) {
        playerBtn.classList.add('used');
      }
      
      // Proceder al turno de la IA
      window.battleState.currentTurn = 'opponent';
      opponentSelectsStat();
    } else {
      window.battleState.currentTurn = 'player';
      enableStatSelection();
      showNotification('¡La IA ha anulado tu estadística! Elige otra.', 'warning');
    }
  }
}

// Aplicar efecto visual de bloqueo de ANULO
function applyAnuloVisual(isPlayer, stat) {
  const targetSide = isPlayer ? 'opponent' : 'player';
  
  console.log(`[POWER] Aplicando visual de ANULO sobre la stat ${stat} de ${targetSide}`);
  
  if (targetSide === 'opponent') {
    const statDisplay = document.querySelector(`.battle-side-opponent .battle-stat-display[data-stat="${stat}"]`);
    if (statDisplay) {
      statDisplay.classList.add('annulled');
      statDisplay.style.opacity = '0.4';
      statDisplay.style.pointerEvents = 'none';
      const label = statDisplay.querySelector('.stat-label');
      if (label && !label.innerHTML.includes('(BLOQUEADO)')) {
        label.innerHTML = '(BLOQUEADO) ' + label.innerHTML;
      }
    }
  } else {
    const statBtn = document.querySelector(`.battle-side-player .battle-stat-btn[data-stat="${stat}"]`);
    if (statBtn) {
      statBtn.classList.add('annulled');
      statBtn.disabled = true;
      statBtn.style.opacity = '0.4';
      const label = statBtn.querySelector('.stat-label');
      if (label && !label.innerHTML.includes('(BLOQUEADO)')) {
        label.innerHTML = '(BLOQUEADO) ' + label.innerHTML;
      }
    }
  }
}

// ==================== LÓGICA DEL PODER INTERCAMBIO ====================

// Usar poder de Intercambio (copiar carta aleatoria del rival)
async function usePowerIntercambio(isPlayer) {
  const side = isPlayer ? 'player' : 'opponent';
  const enemySide = isPlayer ? 'opponent' : 'player';
  const powerKey = 'intercambio';
  
  if (!isPlayer && !opponentHasPower('intercambio')) {
    console.log(`[POWER] El oponente no tiene equipado el poder INTERCAMBIO`);
    return;
  }
  
  console.log(`[POWER] ${side} intenta usar poder INTERCAMBIO`);
  
  // Verificar si ya fue usado
  if (window.battleState[`${side}PowersUsed`][powerKey]) {
    console.log(`[POWER] INTERCAMBIO ya usado por ${side}`);
    return;
  }
  
  // Obtener el equipo del enemigo
  const enemyTeam = window.battleState[`${enemySide}Team`];
  if (!enemyTeam || enemyTeam.length === 0) {
    console.log(`[POWER] No hay cartas en el equipo de ${enemySide}`);
    return;
  }
  
  // Seleccionar carta aleatoria del rival
  const randomCard = enemyTeam[Math.floor(Math.random() * enemyTeam.length)];
  
  console.log(`[POWER] Carta rival seleccionada para copiar:`, randomCard.nombre || randomCard.name);
  
  // Marcar poder como usado
  window.battleState[`${side}PowersUsed`][powerKey] = true;
  
  // Actualizar botón visualmente
  const powerBtn = document.getElementById(`${side}-power-intercambio`);
  if (powerBtn) {
    powerBtn.classList.add('used', 'activating');
    setTimeout(() => powerBtn.classList.remove('activating'), 600);
  }
  
  console.log(`[POWER] ${side} activa poder INTERCAMBIO`);
  
  // Mostrar animación de activación (reutiliza la animación 'swap')
  const userName = isPlayer ? (currentUser || 'Jugador') : (window.battleState.opponentName || 'IA');
  await showPowerActivation('intercambio', userName, isPlayer);
  
  // Animación de intercambio en el slot
  const cardDisplay = document.querySelector(`.battle-side-${side} .battle-card-display`);
  
  if (cardDisplay) {
    cardDisplay.classList.add('swapping-out');
    await new Promise(resolve => setTimeout(resolve, 600));
    
    // Transformar la carta activa en la carta copiada (copia profunda)
    const clonedCard = JSON.parse(JSON.stringify(randomCard));
    window.battleState[`${side}CurrentCard`] = clonedCard;
    
    // Actualizar cartas en pantalla
    updateBattleCards();
    
    cardDisplay.classList.remove('swapping-out');
    cardDisplay.classList.add('swapping-in');
    
    await new Promise(resolve => setTimeout(resolve, 600));
    cardDisplay.classList.remove('swapping-in');
  } else {
    const clonedCard = JSON.parse(JSON.stringify(randomCard));
    window.battleState[`${side}CurrentCard`] = clonedCard;
    updateBattleCards();
  }
  
  console.log(`[POWER] INTERCAMBIO completado para ${side}`);
}

// ==================== CONSIDERACIONES ESTRATÉGICAS IA ====================

// La IA decide si usa el poder ANULO sobre el jugador (después de que el jugador eligió stat)
async function opponentConsidersPowerAnulo() {
  if (!opponentHasPower('anulo') ||
      window.battleState.opponentPowersUsed.anulo || 
      window.battleState.gamePhase !== 'stat-selection' || 
      !window.battleState.selectedStat) { // Debe haber elegido
    return false;
  }
  
  const playerCard = window.battleState.playerCurrentCard;
  if (!playerCard) return false;
  
  // Obtener la stat elegida por el jugador
  const playerStat = window.battleState.selectedStat;
  const playerVal = (typeof getDisplayedBattleStatValue === 'function' ? getDisplayedBattleStatValue('player', playerStat) : null) ?? getStatValue(playerCard, playerStat, 'player');
  
  // Stats disponibles del jugador (incluyendo la seleccionada actual)
  const playerAvailableStats = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
    .filter(s => !window.battleState.playerUsedStats.includes(s) || s === playerStat);
    
  if (playerAvailableStats.length <= 1) {
    return false;
  }
  
  // Estrategia: Si la stat elegida por el jugador es alta (>= 80) y hay suerte (40%), la anulamos
  if (playerVal >= 80 && Math.random() < 0.40) {
    console.log(`[POWER-AI] IA decide usar ANULO sobre la stat elegida por el jugador: ${playerStat} (${playerVal})`);
    await usePowerAnulo(false, playerStat);
    return true;
  }
  
  return false;
}

// La IA decide si usa el poder de INTERCAMBIO (durante su propio turno de elegir stat)
async function opponentConsidersPowerIntercambio() {
  if (!opponentHasPower('intercambio') ||
      window.battleState.opponentPowersUsed.intercambio || 
      window.battleState.gamePhase !== 'stat-selection' || 
      window.battleState.currentTurn !== 'opponent') {
    return false;
  }
  
  const currentCard = window.battleState.opponentCurrentCard;
  const playerCard = window.battleState.playerCurrentCard;
  if (!currentCard || !playerCard) return false;
  
  // Obtener las stats disponibles de la IA
  const availableStats = ['media', 'ninjutsu', 'taijutsu', 'resistencia', 'velocidad', 'defensa', 'fisico']
    .filter(s => !window.battleState.opponentUsedStats.includes(s));
    
  let maxVal = -Infinity;
  for (const stat of availableStats) {
    const val = getStatValue(currentCard, stat, 'opponent');
    if (val > maxVal) {
      maxVal = val;
    }
  }
  
  // Estrategia: Si su mejor estadística disponible es pobre (< 72) y tiene 35% de probabilidad, copia una carta del jugador
  if (maxVal < 72 && Math.random() < 0.35) {
    console.log(`[POWER-AI] IA decide usar INTERCAMBIO porque su mejor stat disponible es baja: ${maxVal}`);
    
    const playerTeam = window.battleState.playerTeam;
    if (!playerTeam || playerTeam.length === 0) return false;
    
    const randomCard = playerTeam[Math.floor(Math.random() * playerTeam.length)];
    
    window.battleState.opponentPowersUsed.intercambio = true;
    
    const powerBtn = document.getElementById('opponent-power-intercambio');
    if (powerBtn) {
      powerBtn.classList.add('used', 'activating');
      setTimeout(() => powerBtn.classList.remove('activating'), 600);
    }
    
    const opponentName = window.battleState.opponentName || 'IA';
    await showPowerActivation('intercambio', opponentName, false);
    
    const cardDisplay = document.querySelector('.battle-side-opponent .battle-card-display');
    if (cardDisplay) {
      cardDisplay.classList.add('swapping-out');
      await new Promise(resolve => setTimeout(resolve, 600));
      
      const clonedCard = JSON.parse(JSON.stringify(randomCard));
      window.battleState.opponentCurrentCard = clonedCard;
      
      updateBattleCards();
      
      cardDisplay.classList.remove('swapping-out');
      cardDisplay.classList.add('swapping-in');
      await new Promise(resolve => setTimeout(resolve, 600));
      cardDisplay.classList.remove('swapping-in');
    } else {
      window.battleState.opponentCurrentCard = JSON.parse(JSON.stringify(randomCard));
      updateBattleCards();
    }
    
    return true;
  }
  
  return false;
}


