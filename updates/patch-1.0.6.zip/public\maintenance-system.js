// ==================== SISTEMA DE MANTENIMIENTO Y ACTUALIZACIONES ====================

let maintenanceCheckInterval = null;
let currentAppVersion = '1.0.0';

// Función para verificar estado de mantenimiento
async function checkMaintenanceStatus() {
  try {
    // Hacer petición directa a GitHub Pages
    const configUrl = 'https://hugom1307.github.io/kvrcards-catalog/remote-config.json?t=' + Date.now();
    console.log('[MAINTENANCE] Verificando desde:', configUrl);
    
    const response = await fetch(configUrl);
    if (!response.ok) {
      console.log('[MAINTENANCE] No se pudo obtener config remota');
      return null;
    }
    
    const config = await response.json();
    console.log('[MAINTENANCE] Estado:', config);
    
    return {
      maintenance: config.maintenance || { enabled: false },
      version: config.version || { current: '1.0.0', minimumRequired: '1.0.0' }
    };
  } catch (error) {
    console.error('[MAINTENANCE] Error al verificar:', error);
    return null;
  }
}

// Función para comparar versiones semánticas
function compareVersions(v1, v2) {
  // Retorna: -1 si v1 < v2, 0 si v1 == v2, 1 si v1 > v2
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);
  
  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const num1 = parts1[i] || 0;
    const num2 = parts2[i] || 0;
    
    if (num1 < num2) return -1;
    if (num1 > num2) return 1;
  }
  
  return 0;
}

// Función para mostrar/ocultar pantalla de mantenimiento
function showMaintenanceScreen(maintenanceData) {
  const screen = document.getElementById('maintenance-screen');
  const title = document.getElementById('maintenance-title');
  const message = document.getElementById('maintenance-message');
  const time = document.getElementById('maintenance-time');
  
  if (!screen) return;
  
  // Ocultar pantalla de versión desactualizada si está visible
  hideOutdatedVersionScreen();
  
  title.textContent = maintenanceData.title || '🔧 Mantenimiento en Curso';
  message.textContent = maintenanceData.message || 'Estamos actualizando el juego. Volveremos pronto.';
  
  if (maintenanceData.estimatedTime) {
    time.textContent = 'Tiempo estimado: ' + maintenanceData.estimatedTime;
    time.style.display = 'block';
  } else {
    time.style.display = 'none';
  }
  
  screen.style.display = 'flex';
  console.log('[MAINTENANCE] Pantalla de mantenimiento mostrada');
}

function hideMaintenanceScreen() {
  const screen = document.getElementById('maintenance-screen');
  if (screen) {
    screen.style.display = 'none';
    console.log('[MAINTENANCE] Pantalla de mantenimiento ocultada');
  }
}

// Función para mostrar pantalla de versión desactualizada (BLOQUEANTE)
function showOutdatedVersionScreen(currentVersion, remoteVersion, downloadUrl, changelog) {
  const screen = document.getElementById('outdated-version-screen');
  const currentVersionEl = document.getElementById('current-version-display');
  const latestVersionEl = document.getElementById('latest-version-display');
  const changelogEl = document.getElementById('update-changelog');
  const closeBtn = document.getElementById('outdated-close-btn');
  
  if (!screen) return;
  
  // Ocultar pantalla de mantenimiento si está visible
  hideMaintenanceScreen();
  
  if (currentVersionEl) currentVersionEl.textContent = 'v' + currentVersion;
  if (latestVersionEl) latestVersionEl.textContent = 'v' + remoteVersion;
  
  if (changelog && changelogEl) {
    changelogEl.textContent = 'Novedades:\n\n' + changelog;
    changelogEl.style.display = 'block';
  } else if (changelogEl) {
    changelogEl.style.display = 'none';
  }
  
  if (closeBtn) {
    closeBtn.onclick = () => {
      if (window.kvrcards && typeof window.kvrcards.quitApp === 'function') {
        window.kvrcards.quitApp();
      } else {
        window.close();
      }
    };
  }
  
  screen.style.display = 'flex';
  console.log('[VERSION] Pantalla bloqueante: Version desactualizada mostrada:', currentVersion, '->', remoteVersion);
}

function hideOutdatedVersionScreen() {
  const screen = document.getElementById('outdated-version-screen');
  if (screen) {
    screen.style.display = 'none';
    console.log('[VERSION] Pantalla de versión desactualizada ocultada');
  }
}

// Función para verificar actualizaciones y decidir si bloquear o notificar
async function checkForUpdatesAndVersionCompatibility() {
  try {
    const status = await checkMaintenanceStatus();
    if (!status) return;
    
    // Obtener versión actual del archivo version.json local
    try {
      const versionResponse = await fetch('./version.json?t=' + Date.now());
      if (versionResponse.ok) {
        const versionData = await versionResponse.json();
        currentAppVersion = versionData.version || '1.0.0';
        console.log('[VERSION] Versión local leída desde version.json:', currentAppVersion);
      }
    } catch (e) {
      console.log('[VERSION] No se pudo leer version.json local, usando 1.0.0');
      currentAppVersion = '1.0.0';
    }
    
    const remoteVersion = status.version?.current || '1.0.0';
    const minimumRequired = status.version?.minimumRequired || '1.0.0';
    const downloadUrl = status.version?.downloadUrl || '';
    const changelog = status.version?.changelog || '';
    const forceUpdate = status.version?.forceUpdate || false;
    
    console.log('[VERSION] ========================================');
    console.log('[VERSION] Versión local:', currentAppVersion);
    console.log('[VERSION] Versión remota (GitHub):', remoteVersion);
    console.log('[VERSION] Versión mínima requerida:', minimumRequired);
    console.log('[VERSION] Actualización forzada:', forceUpdate);
    console.log('[VERSION] ========================================');
    
    // Comparar versiones
    const comparison = compareVersions(currentAppVersion, remoteVersion);
    const meetsMinimum = compareVersions(currentAppVersion, minimumRequired) >= 0;
    
    // CASO 1: Versión desactualizada - BLOQUEAR COMPLETAMENTE (pantalla bloqueante)
    // Solo si la versión local es MENOR que la remota y (no cumple el mínimo o forceUpdate está activo)
    if (comparison < 0 && (!meetsMinimum || forceUpdate)) {
      console.log('[VERSION] BLOQUEO ACTIVADO: Tu versión (' + currentAppVersion + ') es menor a la requerida (' + minimumRequired + ')');
      console.log('[VERSION] ACCESO AL JUEGO BLOQUEADO - Debes reiniciar para actualizar');
      showOutdatedVersionScreen(currentAppVersion, remoteVersion, downloadUrl, changelog);
      return;
    }
    
    // CASO 2: Hay actualización disponible pero no es obligatoria - NOTIFICAR (banner)
    if (comparison < 0 && downloadUrl) {
      console.log('[VERSION] ℹ️ Nueva versión disponible (opcional) - Mostrando notificación');
      showUpdateNotification(remoteVersion, downloadUrl, changelog);
      return;
    }
    
    // CASO 3: Versión actual o superior - Todo OK
    console.log('[VERSION] ✅ Versión actualizada - Acceso permitido');
    hideOutdatedVersionScreen();
    
  } catch (error) {
    console.error('[VERSION] Error al verificar actualizaciones:', error);
  }
}

// Función para mostrar notificación de actualización (NO bloqueante)
function showUpdateNotification(version, downloadUrl, changelog) {
  const notification = document.getElementById('update-notification');
  const versionEl = document.getElementById('update-notification-version');
  const btn = document.getElementById('update-notification-btn');
  const closeBtn = document.getElementById('update-notification-close');
  
  if (!notification) return;
  
  versionEl.textContent = 'v' + version;
  
  btn.onclick = () => {
    // Abrir directamente en el navegador
    window.open(downloadUrl, '_blank');
  };
  
  closeBtn.onclick = () => {
    notification.style.display = 'none';
  };
  
  notification.style.display = 'block';
  console.log('[UPDATE] Notificación de actualización mostrada:', version);
}

// Función principal para inicializar el sistema de mantenimiento
async function initMaintenanceSystem() {

  console.log('[MAINTENANCE] ========================================');
  console.log('[MAINTENANCE] Inicializando sistema de mantenimiento y versiones...');
  console.log('[MAINTENANCE] ========================================');
  
  // Verificación inicial
  const status = await checkMaintenanceStatus();
  
  // PRIORIDAD 1: Verificar mantenimiento
  if (status && status.maintenance && status.maintenance.enabled) {
    console.log('[MAINTENANCE] ⚠️ Modo mantenimiento activo - BLOQUEANDO acceso');
    showMaintenanceScreen(status.maintenance);
    
    // Botón de reintentar en pantalla de mantenimiento
    const retryBtn = document.getElementById('maintenance-retry-btn');
    if (retryBtn) {
      retryBtn.onclick = async () => {
        console.log('[MAINTENANCE] Reintentando verificación...');
        const newStatus = await checkMaintenanceStatus();
        
        if (newStatus && newStatus.maintenance && newStatus.maintenance.enabled) {
          console.log('[MAINTENANCE] Aún en mantenimiento');
        } else {
          hideMaintenanceScreen();
          console.log('[MAINTENANCE] Mantenimiento finalizado, verificando versión...');
          await checkForUpdatesAndVersionCompatibility();
        }
      };
    }
    
    return; // No continuar si hay mantenimiento activo
  }
  
  // PRIORIDAD 2: Verificar versión y compatibilidad
  console.log('[MAINTENANCE] ✅ No hay mantenimiento activo, verificando versión...');
  hideMaintenanceScreen();
  await checkForUpdatesAndVersionCompatibility();
  
  // Configurar chequeo periódico (cada 5 minutos)
  if (maintenanceCheckInterval) {
    clearInterval(maintenanceCheckInterval);
  }
  
  maintenanceCheckInterval = setInterval(async () => {
    console.log('[MAINTENANCE] ⏰ Chequeo periódico automático...');
    const status = await checkMaintenanceStatus();
    
    // Prioridad: mantenimiento > versión desactualizada
    if (status && status.maintenance && status.maintenance.enabled) {
      showMaintenanceScreen(status.maintenance);
    } else {
      hideMaintenanceScreen();
      await checkForUpdatesAndVersionCompatibility();
    }
  }, 5 * 60 * 1000); // 5 minutos
}

// Función para esperar a que la página esté lista
function waitForPageReady(callback) {
  // No necesitamos esperar por window.kvrcards, el sistema funciona con fetch directo
  console.log('[MAINTENANCE] ✅ Sistema listo, inicializando...');
  callback();
}

// Inicializar sistema de mantenimiento cuando el DOM esté listo
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    waitForPageReady(initMaintenanceSystem);
  });
} else {
  waitForPageReady(initMaintenanceSystem);
}

console.log('[MAINTENANCE] 📦 Sistema de mantenimiento y versiones cargado');

// ==================== FIN SISTEMA DE MANTENIMIENTO ====================
