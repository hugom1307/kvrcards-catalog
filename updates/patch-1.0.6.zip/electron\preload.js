const { contextBridge, ipcRenderer } = require('electron');

console.log('[PRELOAD] 🚀 Preload.js ejecutándose...');

contextBridge.exposeInMainWorld('kvrcards', {
  onNavigate: (handler) => ipcRenderer.on('menu:navigate', (_event, view) => handler(view)),
  onOpenPack: (handler) => ipcRenderer.on('menu:open-pack', () => handler()),
  onCatalogReloaded: (handler) => ipcRenderer.on('catalog:reloaded', () => handler()),
  // Offline API
  getAllCards: () => ipcRenderer.invoke('cards:getAll'),
  getQualities: () => ipcRenderer.invoke('qualities:getAll'),
  openPack: (packId) => ipcRenderer.invoke('packs:open', packId),
  savePackCards: (cardIds) => ipcRenderer.invoke('packs:saveCards', cardIds),
  sellAllPackCards: (cardIds) => ipcRenderer.invoke('packs:sellAllCards', cardIds),
  getAllPacks: () => ipcRenderer.invoke('packs:getAll'),
  deletePack: (id) => ipcRenderer.invoke('packs:delete', id),
  sellCard: (cardId) => ipcRenderer.invoke('cards:sell', cardId),
  // Inventario (colección)
  getInventory: () => ipcRenderer.invoke('inventory:get'),
  addInventoryPack: (packId, count) => ipcRenderer.invoke('inventory:addPack', { packId, count }),
  getWallet: () => ipcRenderer.invoke('wallet:get'),
  walletUpdateInfiniteCurrencies: (currencies) => ipcRenderer.invoke('wallet:updateInfiniteCurrencies', currencies),
  catalogSummary: () => ipcRenderer.invoke('catalog:summary'),
  refreshCatalog: () => ipcRenderer.invoke('catalog:refresh'),
  clearCatalogCache: () => ipcRenderer.invoke('catalog:clearCache'),
  // Perfil de usuario
  getProfile: () => ipcRenderer.invoke('profile:get'),
  getUserProfile: () => ipcRenderer.invoke('profile:get'),
  setUsername: (username) => ipcRenderer.invoke('profile:setUsername', username),
  logout: () => ipcRenderer.invoke('profile:logout'),
  // Admin remota/local: sincronizar comandos (GitHub Pages o game-data)
  syncCommands: () => ipcRenderer.invoke('admin:syncCommands'),
  syncCommandsForce: () => ipcRenderer.invoke('admin:syncCommandsForce'),
  clearCommandHistory: () => ipcRenderer.invoke('admin:clearCommandHistory'),
  buyPack: (packId, preferred, amount = 1) => ipcRenderer.invoke('shop:buyPack', packId, preferred, amount),
  // Inventario remoto (opcional)
  syncInventoryRemote: () => ipcRenderer.invoke('inventory:syncRemote'),
  getRemoteInventory: () => ipcRenderer.invoke('inventory:getRemote'),
  loadInfiniteRunState: () => ipcRenderer.invoke('infinite:loadRunState'),
  saveInfiniteRunState: (run) => ipcRenderer.invoke('infinite:saveRunState', run),
  resetInfiniteRunState: () => ipcRenderer.invoke('infinite:resetRunState'),
  getInfiniteRankingsOverview: (limit) => ipcRenderer.invoke('infinite:getRankingsOverview', limit),
  getInventoryServerInfo: () => ipcRenderer.invoke('inventory:serverInfo'),
  // Códigos canjeables y Bendición Supporter
  redeemCode: (code) => ipcRenderer.invoke('codes:redeem', code),
  getRedeemedCodes: () => ipcRenderer.invoke('codes:getRedeemed'),
  getBlessingStatus: () => ipcRenderer.invoke('blessing:getStatus'),
  claimBlessingDaily: () => ipcRenderer.invoke('blessing:claimDaily'),
  // Música
  getAvailableMusicTracks: () => ipcRenderer.invoke('music:getAvailableTracks'),
  uploadMusicTrack: (data) => ipcRenderer.invoke('music:uploadTrack', data),
  deleteMusicTrack: (filename) => ipcRenderer.invoke('music:deleteTrack', filename),
  // Cloud Sync
  cloudRegister: (username, password) => ipcRenderer.invoke('cloud:register', username, password),
  cloudLogin: (username, password) => ipcRenderer.invoke('cloud:login', username, password),
  cloudUpload: (username, password) => ipcRenderer.invoke('cloud:upload', username, password),
  cloudDownload: (username, password) => ipcRenderer.invoke('cloud:download', username, password),
  cloudApplyData: (data) => ipcRenderer.invoke('cloud:applyData', data),
  // Títulos y perfil extendido
  getTitles: () => ipcRenderer.invoke('titles:get'),
  // Entrenadores Modo Offline
  getAllTrainers: () => ipcRenderer.invoke('trainers:getAll'),
  // Sistema
  systemClearCache: () => ipcRenderer.invoke('system:clearCache'),
  systemOpenDataFolder: () => ipcRenderer.invoke('system:openDataFolder'),
  // Misiones
  getUserStats: () => ipcRenderer.invoke('missions:getStats'),
  addCoins: (amount) => ipcRenderer.invoke('missions:addCoins', amount),
  addKvR: (amount) => ipcRenderer.invoke('missions:addKvR', amount),
  addPack: (packId, count = 1) => ipcRenderer.invoke('missions:addPack', packId, count),
  addCard: (cardId) => ipcRenderer.invoke('missions:addCard', cardId),
  addBattleWon: () => ipcRenderer.invoke('missions:addBattleWon'),
  // Rankings
  getWeeklyRankings: (category) => ipcRenderer.invoke('rankings:getWeekly', category),
  getHistoricalRankings: (category) => ipcRenderer.invoke('rankings:getHistorical', category),
  getUserProfileData: (username) => ipcRenderer.invoke('profile:getUserProfile', username),
  updateUserProfile: (data) => ipcRenderer.invoke('profile:updateUserProfile', data),
  // Friends System
  friendsSendRequest: (targetUsername) => ipcRenderer.invoke('friends:sendRequest', targetUsername),
  friendsAcceptRequest: (friendUsername) => ipcRenderer.invoke('friends:acceptRequest', friendUsername),
  friendsRejectRequest: (friendUsername) => ipcRenderer.invoke('friends:rejectRequest', friendUsername),
  friendsRemoveFriend: (friendUsername) => ipcRenderer.invoke('friends:removeFriend', friendUsername),
  friendsGetFriendsList: () => ipcRenderer.invoke('friends:getFriendsList'),
  friendsGetRequests: () => ipcRenderer.invoke('friends:getRequests'),
  friendsSearchUsers: (query) => ipcRenderer.invoke('friends:searchUsers', query),
  // Trades System
  tradesSendRequest: (targetUsername) => ipcRenderer.invoke('trades:sendRequest', targetUsername),
  tradesJoinRandomQueue: () => ipcRenderer.invoke('trades:joinRandomQueue'),
  tradesCheckRandomMatch: () => ipcRenderer.invoke('trades:checkRandomMatch'),
  tradesAcceptTrade: (tradeId) => ipcRenderer.invoke('trades:acceptTrade', tradeId),
  tradesRejectTrade: (tradeId) => ipcRenderer.invoke('trades:rejectTrade', tradeId),
  tradesUpdateOffer: (tradeId, cards, packs, coins, traits, cardTraits) => ipcRenderer.invoke('trades:updateOffer', tradeId, cards, packs, coins, traits, cardTraits),
  tradesConfirmTrade: (tradeId) => ipcRenderer.invoke('trades:confirmTrade', tradeId),
  tradesCancelConfirm: (tradeId) => ipcRenderer.invoke('trades:cancelConfirm', tradeId),
  tradesCancelTrade: (tradeId) => ipcRenderer.invoke('trades:cancelTrade', tradeId),
  tradesGetStatus: (tradeId) => ipcRenderer.invoke('trades:getStatus', tradeId),
  tradesGetPending: () => ipcRenderer.invoke('trades:getPending'),
  tradesAcceptRequest: (tradeId) => ipcRenderer.invoke('trades:acceptRequest', tradeId),
  tradesRejectRequest: (tradeId) => ipcRenderer.invoke('trades:rejectRequest', tradeId),
  // Recargar inventario desde servidor (después de trade)
  inventoryReloadFromServer: () => ipcRenderer.invoke('inventory:reloadFromServer'),
  // Missions state (remote)
  getMissionsState: () => ipcRenderer.invoke('missions:getState'),
  saveMissionsState: (missions) => ipcRenderer.invoke('missions:saveState', missions),
  // Settings (remote)
  getSettings: () => ipcRenderer.invoke('settings:get'),
  saveSettings: (settings) => ipcRenderer.invoke('settings:save', settings),
  // Powers System
  getAllPowers: () => ipcRenderer.invoke('powers:getAll'),
  getPowersInventory: () => ipcRenderer.invoke('powers:getInventory'),
  addPower: (powerId) => ipcRenderer.invoke('powers:add', powerId),
  usePower: (powerId) => ipcRenderer.invoke('powers:use', powerId),
  // Window Focus
  windowForceFocus: () => ipcRenderer.invoke('window:forceFocus'),
  // Traits System
  getAllTraits: () => ipcRenderer.invoke('traits:getAll'),
  assignTrait: (uniqueCardId, traitId, createNew) => ipcRenderer.invoke('traits:assign', { uniqueCardId, traitId, createNew }),
  debugModifyTraits: (amount) => ipcRenderer.invoke('traits:debugModify', amount),
  addTraits: (amount) => ipcRenderer.invoke('traits:debugModify', amount),
  // Evolutions System
  loadEvolutions: () => ipcRenderer.invoke('evolutions:load'),
  saveEvolutionState: (data) => ipcRenderer.invoke('evolutions:saveState', data),
  loadEvolutionState: () => ipcRenderer.invoke('evolutions:loadState'),
  removeCard: (cardInstanceId) => ipcRenderer.invoke('cards:removeInstance', cardInstanceId),
  // Deliverables / Eventos System
  getCompletedDeliverables: () => ipcRenderer.invoke('deliverables:getCompleted'),
  completeDeliverable: (payload) => ipcRenderer.invoke('deliverables:complete', payload),
  // Maintenance & Version Check
  checkMaintenance: () => ipcRenderer.invoke('maintenance:check'),
  getAppVersion: () => ipcRenderer.invoke('app:getVersion'),
  openExternal: (url) => ipcRenderer.invoke('shell:openExternal', url),
  gamblingBet: (amount) => ipcRenderer.invoke('gambling:bet', amount),
  gamblingPayout: (amount) => ipcRenderer.invoke('gambling:payout', amount),
  deductPack: (packId) => ipcRenderer.invoke('packs:deduct', packId),
  getLegendaryUpgradeRewardCard: (rarity) => ipcRenderer.invoke('packs:getLegendaryUpgradeRewardCard', rarity),
  // App lifecycle
  quitApp: () => ipcRenderer.invoke('app:quit'),
  // Display / Window mode
  setDisplayMode: (payload) => ipcRenderer.invoke('window:setDisplayMode', payload),
  getDisplayMode: () => ipcRenderer.invoke('window:getDisplayMode'),
});

console.log('[PRELOAD] [OK] window.kvrcards expuesto correctamente');
