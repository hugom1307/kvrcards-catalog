const path = require('path');
const fs = require('fs');
const http = require('http');
const https = require('https');
const childProcess = require('child_process');

/**
 * Compara dos versiones semánticas (ej: '1.0.1' y '1.0.2')
 * Retorna: -1 si v1 < v2, 0 si v1 == v2, 1 si v1 > v2
 */
function compareVersions(v1, v2) {
  const parts1 = String(v1 || '0').split('.').map(n => parseInt(n, 10) || 0);
  const parts2 = String(v2 || '0').split('.').map(n => parseInt(n, 10) || 0);
  const len = Math.max(parts1.length, parts2.length);

  for (let i = 0; i < len; i++) {
    const num1 = parts1[i] || 0;
    const num2 = parts2[i] || 0;
    if (num1 < num2) return -1;
    if (num1 > num2) return 1;
  }
  return 0;
}

/**
 * Obtiene la versión local instalada
 */
function getLocalVersion(appRoot) {
  const exeDir = path.dirname(process.execPath);
  const candidates = [
    path.join(appRoot, 'public', 'version.json'),
    path.join(appRoot, 'version.json'),
    path.join(exeDir, 'resources', 'app', 'public', 'version.json'),
    path.join(exeDir, 'resources', 'app', 'version.json'),
    path.join(exeDir, 'version.json')
  ];

  for (const p of candidates) {
    if (fs.existsSync(p)) {
      try {
        const data = JSON.parse(fs.readFileSync(p, 'utf8'));
        if (data && data.version) return String(data.version).trim();
      } catch (e) {
        console.warn('[AUTO-PATCHER] Error leyendo version.json en:', p, e.message);
      }
    }
  }
  return '1.0.0';
}

/**
 * Actualiza los archivos version.json locales tras aplicar un parche
 */
function setLocalVersion(appRoot, newVersion) {
  const exeDir = path.dirname(process.execPath);
  const payload = JSON.stringify({ version: String(newVersion).trim() }, null, 2);
  const targets = [
    path.join(appRoot, 'public', 'version.json'),
    path.join(appRoot, 'version.json'),
    path.join(exeDir, 'resources', 'app', 'public', 'version.json'),
    path.join(exeDir, 'resources', 'app', 'version.json')
  ];

  for (const t of targets) {
    try {
      const dir = path.dirname(t);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(t, payload, 'utf8');
      console.log('[AUTO-PATCHER] version.json actualizado en:', t, 'a v' + newVersion);
    } catch (e) {
      console.warn('[AUTO-PATCHER] No se pudo escribir version.json en:', t, e.message);
    }
  }
}

/**
 * Descarga un archivo siguiendo redirecciones HTTP/HTTPS
 */
function downloadFileWithProgress(url, destPath, onProgress) {
  return new Promise((resolve, reject) => {
    function get(currentUrl, redirectCount = 0) {
      if (redirectCount > 8) {
        return reject(new Error('Demasiadas redirecciones al descargar la actualización'));
      }

      const client = currentUrl.startsWith('https:') ? https : http;
      const req = client.get(currentUrl, (res) => {
        // Manejar redirecciones (GitHub Releases usa 302 hacia AWS S3 / Fastly CDN)
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          const nextUrl = new URL(res.headers.location, currentUrl).toString();
          return get(nextUrl, redirectCount + 1);
        }

        if (res.statusCode !== 200) {
          return reject(new Error(`Servidor devolvió HTTP ${res.statusCode} al descargar parche`));
        }

        const totalBytes = parseInt(res.headers['content-length'] || '0', 10);
        let downloadedBytes = 0;

        const fileStream = fs.createWriteStream(destPath);

        res.on('data', (chunk) => {
          downloadedBytes += chunk.length;
          const percent = totalBytes > 0 ? (downloadedBytes / totalBytes) * 100 : 0;
          if (onProgress) {
            onProgress({ downloadedBytes, totalBytes, percent });
          }
        });

        res.pipe(fileStream);

        fileStream.on('finish', () => {
          fileStream.close(() => resolve(destPath));
        });

        fileStream.on('error', (err) => {
          fs.unlink(destPath, () => {});
          reject(err);
        });
      });

      req.on('error', (err) => {
        fs.unlink(destPath, () => {});
        reject(err);
      });

      req.setTimeout(45000, () => {
        req.destroy();
        reject(new Error('Tiempo de espera agotado al descargar la actualización'));
      });
    }

    get(url);
  });
}

/**
 * Extrae un archivo .zip sobre el directorio de la aplicación
 * Usa tar (nativo en Windows 10/11) con fallback a PowerShell Expand-Archive
 */
function extractPatch(zipPath, destDir) {
  return new Promise((resolve, reject) => {
    console.log(`[AUTO-PATCHER] Extrayendo ${zipPath} en ${destDir}...`);

    // Intentar primero con tar (ultra-rápido en Windows 10/11)
    const tarCmd = `tar -xf "${zipPath}" -C "${destDir}"`;
    childProcess.exec(tarCmd, (err, stdout, stderr) => {
      if (!err) {
        console.log('[AUTO-PATCHER] [OK] Parche extraido exitosamente con tar');
        return resolve();
      }

      console.warn('[AUTO-PATCHER] tar fallo o no disponible, probando Expand-Archive de PowerShell...', err.message);
      // Fallback a PowerShell
      const psCmd = `powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '${zipPath}' -DestinationPath '${destDir}' -Force"`;
      childProcess.exec(psCmd, (psErr, psOut, psErrOut) => {
        if (!psErr) {
          console.log('[AUTO-PATCHER] [OK] Parche extraido exitosamente con PowerShell');
          return resolve();
        }
        reject(new Error(`Fallo al extraer parche: ${psErr.message || psErrOut}`));
      });
    });
  });
}

function fetchJsonWithRedirects(urlStr, redirectCount = 0) {
  return new Promise((resolve) => {
    if (redirectCount > 5) return resolve(null);

    try {
      const parsedUrl = new URL(urlStr);
      const client = parsedUrl.protocol === 'https:' ? https : http;
      const options = {
        headers: {
          'User-Agent': 'KVRCards-Patcher/1.0',
          'Accept': 'application/json, text/plain, */*',
          'Cache-Control': 'no-cache'
        },
        timeout: 12000
      };

      const req = client.get(urlStr, options, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          const nextUrl = new URL(res.headers.location, urlStr).toString();
          return resolve(fetchJsonWithRedirects(nextUrl, redirectCount + 1));
        }

        if (res.statusCode !== 200) {
          return resolve(null);
        }

        let raw = '';
        res.setEncoding('utf8');
        res.on('data', chunk => raw += chunk);
        res.on('end', () => {
          try {
            resolve(JSON.parse(raw));
          } catch {
            resolve(null);
          }
        });
      });

      req.on('error', () => resolve(null));
      req.on('timeout', () => {
        req.destroy();
        resolve(null);
      });
    } catch {
      resolve(null);
    }
  });
}

/**
 * Consulta el archivo remote-config.json del catálogo remoto con soporte de redirecciones y fallback
 */
async function fetchRemoteConfig(baseUrl) {
  const urls = [];
  if (baseUrl) {
    const cleanBase = baseUrl.endsWith('/') ? baseUrl : baseUrl + '/';
    urls.push(new URL('remote-config.json?t=' + Date.now(), cleanBase).toString());
  }
  urls.push('https://hugom1307.github.io/kvrcards-catalog/remote-config.json?t=' + Date.now());
  urls.push('https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/remote-config.json?t=' + Date.now());

  for (const u of urls) {
    try {
      const cfg = await fetchJsonWithRedirects(u);
      if (cfg && (cfg.version || cfg.catalog)) {
        return cfg;
      }
    } catch {}
  }
  return null;
}

/**
 * Orquestador principal del Auto-Patcher en Electron
 */
async function checkAndApplyAutoPatch({ app, BrowserWindow, ipcMain, catalogBaseUrl, onLaunchGame }) {
  const appRoot = (app && typeof app.getAppPath === 'function') ? app.getAppPath() : path.join(__dirname, '..', '..');
  const localVersion = getLocalVersion(appRoot);

  console.log('[AUTO-PATCHER] ========================================');
  console.log('[AUTO-PATCHER] Directorio de aplicación:', appRoot);
  console.log('[AUTO-PATCHER] Versión local detectada:', localVersion);
  console.log('[AUTO-PATCHER] Verificando en catálogo:', catalogBaseUrl);
  console.log('[AUTO-PATCHER] ========================================');

  const remoteConfig = await fetchRemoteConfig(catalogBaseUrl);
  if (!remoteConfig) {
    console.log('[AUTO-PATCHER] No se pudo obtener remote-config.json. Continuando con el juego...');
    return onLaunchGame();
  }

  const verConfig = remoteConfig.version || {};
  const remoteVersion = String(verConfig.current || localVersion).trim();
  const patchUrl = String(verConfig.patchUrl || verConfig.downloadUrl || '').trim();
  const changelog = String(verConfig.changelog || '').trim();

  const comparison = compareVersions(localVersion, remoteVersion);
  console.log(`[AUTO-PATCHER] Comparación: Local(${localVersion}) vs Remota(${remoteVersion}) -> ${comparison}`);

  // Si la versión remota es mayor y hay un patchUrl disponible
  const isZipPatch = patchUrl && (patchUrl.toLowerCase().endsWith('.zip') || patchUrl.includes('/download/'));
  if (comparison < 0 && isZipPatch) {
    console.log(`[AUTO-PATCHER] [UPDATE] Nueva version detectada: v${localVersion} -> v${remoteVersion}`);
    console.log('[AUTO-PATCHER] URL del parche:', patchUrl);

    const possiblePreloads = [
      path.join(__dirname, '..', 'preload-updater.js'),
      path.join(appRoot, 'electron', 'preload-updater.js'),
      path.join(appRoot, 'preload-updater.js')
    ];
    const preloadPath = possiblePreloads.find(p => fs.existsSync(p)) || path.join(__dirname, '..', 'preload-updater.js');

    const possibleSplashes = [
      path.join(appRoot, 'public', 'updater-splash.html'),
      path.join(appRoot, 'updater-splash.html'),
      path.join(__dirname, '..', '..', 'public', 'updater-splash.html')
    ];
    const splashPath = possibleSplashes.find(p => fs.existsSync(p)) || path.join(appRoot, 'public', 'updater-splash.html');

    // Crear ventana splash de actualización
    const splashWin = new BrowserWindow({
      width: 520,
      height: 380,
      frame: false,
      transparent: true,
      resizable: false,
      center: true,
      alwaysOnTop: true,
      icon: path.join(appRoot, 'build', 'kvcards.ico'),
      webPreferences: {
        nodeIntegration: false,
        contextIsolation: true,
        preload: preloadPath
      }
    });

    splashWin.loadFile(splashPath);

    function sendState(state) {
      if (!splashWin.isDestroyed()) {
        splashWin.webContents.send('updater:state', state);
      }
    }

    async function executePatchDownloadAndInstall() {
      try {
        sendState({
          currentVersion: localVersion,
          targetVersion: remoteVersion,
          changelog,
          status: 'Descargando actualización...',
          progress: 5
        });

        const tempZip = path.join(app.getPath('temp'), `kvr-patch-${remoteVersion}-${Date.now()}.zip`);

        // 1. Descargar archivo
        await downloadFileWithProgress(patchUrl, tempZip, ({ downloadedBytes, totalBytes, percent }) => {
          const mbDown = (downloadedBytes / (1024 * 1024)).toFixed(1);
          const mbTotal = totalBytes > 0 ? (totalBytes / (1024 * 1024)).toFixed(1) + ' MB' : '...';
          sendState({
            status: `Descargando actualización... (${mbDown} MB / ${mbTotal})`,
            progress: totalBytes > 0 ? Math.min(85, percent * 0.85) : 40
          });
        });

        // 2. Extraer archivo sobre la app
        sendState({
          status: 'Extrayendo e instalando archivos...',
          progress: 90
        });

        await extractPatch(tempZip, appRoot);

        // 3. Actualizar version.json
        setLocalVersion(appRoot, remoteVersion);

        // 4. Limpiar temporal
        try { fs.unlinkSync(tempZip); } catch {}

        // 5. Notificar finalización (el usuario debe pulsar Iniciar Juego)
        sendState({
          status: '¡Actualización completada!',
          progress: 100,
          completed: true
        });

      } catch (err) {
        console.error('[AUTO-PATCHER] [ERROR] Error durante la actualizacion:', err);
        sendState({
          error: err.message || 'Error desconocido al descargar o aplicar el parche',
          status: 'Fallo la actualizacion'
        });
      }
    }

    // Escuchar acciones del usuario en la ventana splash
    ipcMain.once('updater:launch', () => {
      console.log('[AUTO-PATCHER] Usuario pulso Iniciar Juego. Reiniciando aplicacion...');
      app.relaunch();
      app.exit(0);
    });

    ipcMain.once('updater:retry', () => {
      executePatchDownloadAndInstall();
    });

    ipcMain.once('updater:skip', () => {
      console.log('[AUTO-PATCHER] Usuario decidio omitir la actualizacion');
      if (!splashWin.isDestroyed()) splashWin.close();
      onLaunchGame();
    });

    splashWin.webContents.once('did-finish-load', () => {
      executePatchDownloadAndInstall();
    });

    return;
  }

  // Si no hay actualizacion requerida
  console.log('[AUTO-PATCHER] [OK] El juego esta al dia. Iniciando normalmente.');
  onLaunchGame();
}

module.exports = {
  compareVersions,
  getLocalVersion,
  setLocalVersion,
  checkAndApplyAutoPatch
};
