const fallbackPrestigeConfig = {
  xpRules: {
    battlePlayed: 20,
    battleWinBonus: 10,
    duplicateFromPackOrTrade: 500,
    duplicatePlata: 250,
    duplicateBronce: 100
  },
  levels: []
};

function getDefaultPrestigeConfig() {
  if (typeof defaultPrestigeConfig !== 'undefined' && defaultPrestigeConfig) {
    return defaultPrestigeConfig;
  }
  return fallbackPrestigeConfig;
}

function getPrestigeProgressStorageKey() {
  if (typeof PRESTIGE_PROGRESS_STORAGE_KEY !== 'undefined') {
    return PRESTIGE_PROGRESS_STORAGE_KEY;
  }
  return 'kvrcards_prestige_progress_v1';
}

async function getPrestigeConfig() {
  if (prestigeConfigCache) return prestigeConfigCache;

  try {
    const remoteRes = await fetch(REMOTE_PRESTIGE_CONFIG_URL, { cache: 'no-store' });
    if (remoteRes.ok) {
      const remoteConfig = await remoteRes.json();
      if (remoteConfig && (Array.isArray(remoteConfig) || Array.isArray(remoteConfig.levels) || Array.isArray(remoteConfig?.default?.levels) || Array.isArray(remoteConfig?.cards))) {
        prestigeConfigCache = remoteConfig;
        return prestigeConfigCache;
      }
    }
  } catch (e) {
    console.warn('[PRESTIGE] No se pudo cargar config remota:', e?.message || e);
  }

  try {
    const localRes = await fetch('./prestige-config.json', { cache: 'no-store' });
    if (localRes.ok) {
      const localConfig = await localRes.json();
      if (localConfig && (Array.isArray(localConfig) || Array.isArray(localConfig.levels) || Array.isArray(localConfig?.default?.levels) || Array.isArray(localConfig?.cards))) {
        prestigeConfigCache = localConfig;
        return prestigeConfigCache;
      }
    }
  } catch (e) {
    console.warn('[PRESTIGE] No se pudo cargar config local:', e?.message || e);
  }

  prestigeConfigCache = getDefaultPrestigeConfig();
  return prestigeConfigCache;
}

const PRESTIGE_QUALITY_SUFFIX_REGEX = /_(?:iconoprime|icono_prime|icon_prime|prime_icon|diosantiguo|dios_antiguo|ancientgod|superheroe|super_heroe|iconosuperprime|superprime|legendaria|legendario|legend|inmortal|inmo|icono|icon|heroe|hero|oro|gold|plata|silver|bronce|bronze|especiales|especial\d*|comun|evolucion|evolution|evoe|evochad|evosamurai|evo\d*|prime|tots|toty|evento|event|sbc|sbcevo|flashback|cota\d*|tsukirocota\d*|au|exclusive|shadow|recompensa|promo)$/i;

const prestigeCharKeyCache = new Map();
function getPrestigeCharacterKey(cardOrId, cardObj = null) {
  if (!cardOrId && !cardObj) return '';

  const cacheKey = (typeof cardOrId === 'string')
    ? cardOrId.toLowerCase().trim()
    : ((cardOrId && typeof cardOrId === 'object') ? String(cardOrId.id || cardOrId.uniqueId || cardOrId.cardId || '').toLowerCase().trim() : '');

  if (cacheKey && !cardObj && prestigeCharKeyCache.has(cacheKey)) {
    return prestigeCharKeyCache.get(cacheKey);
  }

  let id = '';
  let name = '';

  if (typeof cardOrId === 'object' && cardOrId !== null) {
    id = String(cardOrId.id || cardOrId.uniqueId || cardOrId.cardId || '').toLowerCase().trim();
    name = String(cardOrId.name || cardOrId.nombre || '').toLowerCase().trim();
  } else {
    id = String(cardOrId || '').toLowerCase().trim();
  }

  if (cardObj && typeof cardObj === 'object') {
    if (!name) name = String(cardObj.name || cardObj.nombre || '').toLowerCase().trim();
    if (!id) id = String(cardObj.id || cardObj.uniqueId || cardObj.cardId || '').toLowerCase().trim();
  }

  if (!name && id && typeof findCardInCatalog === 'function') {
    const found = findCardInCatalog(id);
    if (found) {
      name = String(found.name || found.nombre || '').toLowerCase().trim();
    }
  }

  let baseId = id.split('_notrait')[0].split('_trait')[0];
  if (baseId.startsWith('trait_')) baseId = baseId.replace(/^trait_/, '');
  while (PRESTIGE_QUALITY_SUFFIX_REGEX.test(baseId)) {
    baseId = baseId.replace(PRESTIGE_QUALITY_SUFFIX_REGEX, '').replace(/_+$/, '');
  }

  let cleanName = '';
  if (name) {
    let n = name.replace(/\([^)]*\)/g, '').replace(/\[[^\]]*\]/g, '').trim();
    const qualityWords = [
      'icono prime', 'iconoprime', 'prime icon', 'dios antiguo', 'diosantiguo',
      'super heroe', 'superheroe', 'super héroe',
      'especiales', 'especial', 'special',
      'icono', 'icon', 'héroe', 'heroe', 'hero',
      'bronce', 'bronze', 'plata', 'silver', 'oro', 'gold',
      'evolucion', 'evolución', 'evolution', 'evoe', 'evo 1', 'evo 2', 'evo 3', 'evo 4', 'evo 5', 'evo',
      'legendario', 'legendaria', 'legend', 'prime', 'inmortal', 'inmo', 'tots', 'toty',
      'sbc evo', 'sbcevo', 'sbc', 'flashback', 'cota 1', 'cota 2', 'cota 3', 'cota',
      'exclusive', 'au', 'shadow', 'promo', 'recompensa'
    ];
    let wordStripped = true;
    while (wordStripped) {
      wordStripped = false;
      for (const word of qualityWords) {
        const regex = new RegExp(`\\s+${word}$`, 'i');
        if (regex.test(n)) {
          n = n.replace(regex, '').trim();
          wordStripped = true;
          break;
        }
      }
    }
    cleanName = n.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
  }

  const cleanId = baseId.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]/g, '');
  const res = cleanName || cleanId;
  if (cacheKey && !cardObj) {
    prestigeCharKeyCache.set(cacheKey, res);
  }
  return res;
}
window.getPrestigeCharacterKey = getPrestigeCharacterKey;

let characterVariantsMap = null;
function getCharacterVariants(charKey) {
  if (!charKey) return [];
  if (!characterVariantsMap) {
    characterVariantsMap = new Map();
  }

  if (!characterVariantsMap.has(charKey)) {
    const list = new Set();

    // 1. From store
    const store = (typeof prestigeProgressStoreCache !== 'undefined' && prestigeProgressStoreCache)
      ? prestigeProgressStoreCache
      : loadPrestigeProgressStore();
    for (const storedId of Object.keys(store || {})) {
      if (getPrestigeCharacterKey(storedId) === charKey) {
        list.add(storedId);
      }
    }

    // 2. From catalog in memory
    const catalogCards = (Array.isArray(rewardHudCatalogCache?.cards) && rewardHudCatalogCache.cards.length > 0)
      ? rewardHudCatalogCache.cards
      : (Array.isArray(window.allCardsCache) && window.allCardsCache.length > 0
        ? window.allCardsCache
        : (Array.isArray(window.availableCards) && window.availableCards.length > 0
          ? window.availableCards
          : (Array.isArray(window.allCards) ? window.allCards : [])));
    for (const c of catalogCards) {
      if (c && c.id && getPrestigeCharacterKey(c) === charKey) {
        list.add(c.id);
      }
    }

    // 3. From user inventory cards
    const invCards = window.userInventoryCache?.cards || window.userInventory?.cards;
    if (invCards && typeof invCards === 'object') {
      for (const invId of Object.keys(invCards)) {
        if (getPrestigeCharacterKey(invId) === charKey) {
          list.add(invId);
        }
      }
    }

    // 4. From PRESTIGE_SYSTEM_BACKUP
    if (typeof PRESTIGE_SYSTEM_BACKUP === 'object' && PRESTIGE_SYSTEM_BACKUP) {
      for (const bId of Object.keys(PRESTIGE_SYSTEM_BACKUP)) {
        if (getPrestigeCharacterKey(bId) === charKey) {
          list.add(bId);
        }
      }
    }

    // 5. From claims in memory & localStorage
    const allClaims = { ...(window.userPrestigeClaims || {}) };
    for (const k of Object.keys(allClaims)) {
      const m = k.match(/^prestige_(?:mission_)?claim_(?:char_)?([^_]+(?:_[^_]+)*?)_(\d+|p\d+.*)$/);
      if (m && m[1]) {
        const idOrChar = m[1];
        if (getPrestigeCharacterKey(idOrChar) === charKey) {
          list.add(idOrChar);
        }
      }
    }

    characterVariantsMap.set(charKey, Array.from(list));
  }
  return characterVariantsMap.get(charKey) || [];
}
window.getCharacterVariants = getCharacterVariants;

function matchPrestigeCardEntry(entry, card) {
  if (!entry) return false;
  const entryId = String(entry.cardId || entry.id || '').trim().toLowerCase();
  if (!entryId || entryId === 'default') return false;
  const cId = String(card?.id || '').trim().toLowerCase();
  if (entryId === cId) return true;

  const entryCharKey = getPrestigeCharacterKey(entry);
  const cardCharKey = getPrestigeCharacterKey(card);
  if (entryCharKey && cardCharKey && entryCharKey === cardCharKey) return true;

  const entryStripped = entryId.replace(PRESTIGE_QUALITY_SUFFIX_REGEX, '');
  const cStripped = cId.replace(PRESTIGE_QUALITY_SUFFIX_REGEX, '');
  if (entryStripped === cStripped || entryStripped === cId || entryId === cStripped) return true;
  const entryName = String(entry.name || '').trim().toLowerCase();
  const cName = String(card?.name || card?.nombre || '').trim().toLowerCase();
  if (entryName && cName && entryName === cName) return true;
  return false;
}

function resolvePrestigeProfile(config, card) {
  const fallback = getDefaultPrestigeConfig();
  const root = config || fallback;
  const cardId = String(card?.id || '').trim();

  // 1. Si la configuración es directamente un Array [ { cardId, levels }, ... ]
  if (Array.isArray(root)) {
    const foundCard = root.find(entry => matchPrestigeCardEntry(entry, card));
    if (foundCard && Array.isArray(foundCard.levels)) {
      return {
        isCustom: true,
        profileId: String(foundCard.cardId || foundCard.id || '').trim().toLowerCase(),
        xpRules: foundCard.xpRules || fallback.xpRules,
        levels: foundCard.levels
      };
    }
    const defaultEntry = root.find(entry => entry && (String(entry.cardId || entry.id || '').toLowerCase() === 'default' || !entry.cardId));
    if (defaultEntry && Array.isArray(defaultEntry.levels)) {
      return {
        isCustom: false,
        profileId: 'default',
        xpRules: defaultEntry.xpRules || fallback.xpRules,
        levels: defaultEntry.levels
      };
    }
  }

  // 2. Si root.cards es un Array [ { cardId, levels }, ... ]
  if (root?.cards && Array.isArray(root.cards)) {
    const foundCard = root.cards.find(entry => matchPrestigeCardEntry(entry, card));
    if (foundCard && Array.isArray(foundCard.levels)) {
      return {
        isCustom: true,
        profileId: String(foundCard.cardId || foundCard.id || '').trim().toLowerCase(),
        xpRules: foundCard.xpRules || root?.default?.xpRules || root?.xpRules || fallback.xpRules,
        levels: foundCard.levels
      };
    }
  }

  // 3. Si root.cards es un Objeto { "card_id": { levels: [...] } }
  const cardProfile = (cardId && root?.cards && typeof root.cards === 'object' && !Array.isArray(root.cards))
    ? root.cards[cardId]
    : null;

  if (cardProfile && Array.isArray(cardProfile.levels)) {
    return {
      isCustom: true,
      profileId: cardId.toLowerCase(),
      xpRules: cardProfile.xpRules || root?.default?.xpRules || root?.xpRules || fallback.xpRules,
      levels: cardProfile.levels
    };
  }

  // 4. Si tiene bloque "default" con levels
  if (root?.default && Array.isArray(root.default.levels)) {
    return {
      isCustom: false,
      profileId: 'default',
      xpRules: root.default.xpRules || root.xpRules || fallback.xpRules,
      levels: root.default.levels
    };
  }

  // 5. Si root tiene levels directamente en la raíz
  if (Array.isArray(root.levels)) {
    return {
      isCustom: false,
      profileId: 'default',
      xpRules: root.xpRules || fallback.xpRules,
      levels: root.levels
    };
  }

  return {
    isCustom: false,
    profileId: 'default',
    xpRules: fallback.xpRules,
    levels: fallback.levels
  };
}

function getPrestigeThresholds(levels) {
  const raw = Array.isArray(levels)
    ? levels
        .map(l => Number(l?.xpRequired) || 0)
        .filter(v => v > 0)
    : [];
  return raw.length > 0 ? raw : [...PRESTIGE_XP_THRESHOLDS];
}

function getPrestigeClaimKey(cardId, prestigeLevel) {
  const safeCardId = String(cardId || 'unknown_card').trim() || 'unknown_card';
  return `prestige_claim_${safeCardId}_${prestigeLevel}`;
}

function getPrestigeMissionClaimKey(cardId, missionId) {
  const safeCardId = String(cardId || 'unknown_card').trim() || 'unknown_card';
  const safeMissionId = String(missionId || 'unknown_mission').trim() || 'unknown_mission';
  return `prestige_mission_claim_${safeCardId}_${safeMissionId}`;
}

window.userPrestigeClaims = window.userPrestigeClaims || {};
let prestigeClaimsLoaded = false;

async function loadUserPrestigeClaims() {
  if (window.kvrcards && typeof window.kvrcards.getPrestigeClaimsState === 'function') {
    try {
      const res = await window.kvrcards.getPrestigeClaimsState();
      if (res && res.ok && res.claims && typeof res.claims === 'object') {
        window.userPrestigeClaims = { ...(window.userPrestigeClaims || {}), ...res.claims };
        for (const [k, v] of Object.entries(res.claims)) {
          try { localStorage.setItem(k, String(v)); } catch {}
        }
        prestigeClaimsLoaded = true;
        return window.userPrestigeClaims;
      }
    } catch (e) {
      console.warn('[PRESTIGE] Error loading prestige claims from backend:', e);
    }
  }
  prestigeClaimsLoaded = true;
  return window.userPrestigeClaims;
}
window.loadUserPrestigeClaims = loadUserPrestigeClaims;

if (typeof window !== 'undefined') {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { loadUserPrestigeClaims().catch(() => {}); });
  } else {
    setTimeout(() => { loadUserPrestigeClaims().catch(() => {}); }, 100);
  }
}

function clearPrestigeClaimsForCharacter(charKey, cardId) {
  const safeId = normalizePrestigeCardId(cardId);
  const safeCharKey = String(charKey || '').toLowerCase().trim();
  try {
    for (let lvl = 1; lvl <= 20; lvl++) {
      if (safeId) {
        localStorage.removeItem(`prestige_claim_${safeId}_${lvl}`);
        if (window.userPrestigeClaims) delete window.userPrestigeClaims[`prestige_claim_${safeId}_${lvl}`];
      }
      if (safeCharKey) {
        localStorage.removeItem(`prestige_claim_char_${safeCharKey}_${lvl}`);
        if (window.userPrestigeClaims) delete window.userPrestigeClaims[`prestige_claim_char_${safeCharKey}_${lvl}`];
      }
    }
    const keysToRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!k) continue;
      if (safeId && (k.startsWith(`prestige_claim_${safeId}_`) || k.startsWith(`prestige_mission_claim_${safeId}_`))) {
        keysToRemove.push(k);
      }
      if (safeCharKey && (k.startsWith(`prestige_claim_char_${safeCharKey}_`) || k.startsWith(`prestige_mission_claim_char_${safeCharKey}_`))) {
        keysToRemove.push(k);
      }
    }
    keysToRemove.forEach(k => {
      localStorage.removeItem(k);
      if (window.userPrestigeClaims) delete window.userPrestigeClaims[k];
    });
  } catch (e) {
    console.warn('[PRESTIGE] Error limpiando claims de prestigio:', e);
  }
}
window.clearPrestigeClaimsForCharacter = clearPrestigeClaimsForCharacter;

function isPrestigeLevelRewardClaimed(cardOrId, prestigeLevel) {
  const safeCardId = normalizePrestigeCardId(typeof cardOrId === 'object' ? cardOrId?.id : cardOrId) || 'unknown_card';
  const charKey = getPrestigeCharacterKey(cardOrId);
  const lvl = Number(prestigeLevel) || 1;
  const claims = window.userPrestigeClaims || {};

  try {
    // 1. Direct card claim check
    const k1 = `prestige_claim_${safeCardId}_${lvl}`;
    if (claims[k1] === '1' || localStorage.getItem(k1) === '1') return true;

    // 2. Canonical character key check
    if (charKey) {
      const kChar = `prestige_claim_char_${charKey}_${lvl}`;
      if (claims[kChar] === '1' || localStorage.getItem(kChar) === '1') return true;

      // 3. Known sibling variants check
      const siblings = getCharacterVariants(charKey);
      for (let i = 0; i < siblings.length; i++) {
        const kSib = `prestige_claim_${siblings[i]}_${lvl}`;
        if (claims[kSib] === '1' || localStorage.getItem(kSib) === '1') {
          claims[kChar] = '1';
          claims[k1] = '1';
          try { localStorage.setItem(kChar, '1'); localStorage.setItem(k1, '1'); } catch {}
          return true;
        }
      }

      // 4. Exhaustive search in claims object and localStorage for any claim of the same level
      for (const [k, v] of Object.entries(claims)) {
        if (v !== '1' && v !== 1 && v !== true && v !== 'true') continue;
        const match = k.match(/^prestige_claim_(?:char_)?(.+)_(\d+)$/);
        if (match && Number(match[2]) === lvl) {
          const claimedIdOrChar = match[1];
          if (claimedIdOrChar === charKey || claimedIdOrChar === safeCardId) {
            claims[kChar] = '1';
            claims[k1] = '1';
            try { localStorage.setItem(kChar, '1'); localStorage.setItem(k1, '1'); } catch {}
            return true;
          }
          const claimedCharKey = getPrestigeCharacterKey(claimedIdOrChar);
          if (claimedCharKey && claimedCharKey === charKey) {
            claims[kChar] = '1';
            claims[k1] = '1';
            try { localStorage.setItem(kChar, '1'); localStorage.setItem(k1, '1'); } catch {}
            return true;
          }
        }
      }

      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (!k || !k.startsWith('prestige_claim_')) continue;
        if (localStorage.getItem(k) !== '1') continue;
        const match = k.match(/^prestige_claim_(?:char_)?(.+)_(\d+)$/);
        if (match && Number(match[2]) === lvl) {
          const claimedIdOrChar = match[1];
          if (claimedIdOrChar === charKey || claimedIdOrChar === safeCardId) {
            claims[kChar] = '1';
            claims[k1] = '1';
            try { localStorage.setItem(kChar, '1'); localStorage.setItem(k1, '1'); } catch {}
            return true;
          }
          const claimedCharKey = getPrestigeCharacterKey(claimedIdOrChar);
          if (claimedCharKey && claimedCharKey === charKey) {
            claims[kChar] = '1';
            claims[k1] = '1';
            try { localStorage.setItem(kChar, '1'); localStorage.setItem(k1, '1'); } catch {}
            return true;
          }
        }
      }
    }
  } catch (e) {
    console.warn('[PRESTIGE] Error checking isPrestigeLevelRewardClaimed:', e);
  }
  return false;
}
window.isPrestigeLevelRewardClaimed = isPrestigeLevelRewardClaimed;

function setPrestigeLevelRewardClaimed(cardOrId, prestigeLevel) {
  const safeCardId = normalizePrestigeCardId(typeof cardOrId === 'object' ? cardOrId?.id : cardOrId) || 'unknown_card';
  const charKey = getPrestigeCharacterKey(cardOrId);
  const lvl = Number(prestigeLevel) || 1;
  window.userPrestigeClaims = window.userPrestigeClaims || {};
  const batch = {};

  const saveKey = (key) => {
    try { localStorage.setItem(key, '1'); } catch {}
    window.userPrestigeClaims[key] = '1';
    batch[key] = '1';
  };

  try {
    saveKey(`prestige_claim_${safeCardId}_${lvl}`);

    if (charKey) {
      saveKey(`prestige_claim_char_${charKey}_${lvl}`);

      const siblings = getCharacterVariants(charKey);
      for (let i = 0; i < siblings.length; i++) {
        saveKey(`prestige_claim_${siblings[i]}_${lvl}`);
      }
    }
  } catch (e) {
    console.warn('[PRESTIGE] Error saving prestige level claim:', e);
  }

  if (window.kvrcards && typeof window.kvrcards.savePrestigeClaimsBatch === 'function') {
    window.kvrcards.savePrestigeClaimsBatch(batch).catch(e => console.warn('[PRESTIGE] Error saving claims to backend:', e));
  }
}
window.setPrestigeLevelRewardClaimed = setPrestigeLevelRewardClaimed;

function isPrestigeMissionClaimed(cardOrId, missionKey, legacyMissionId = '') {
  const safeCardId = normalizePrestigeCardId(typeof cardOrId === 'object' ? cardOrId?.id : cardOrId) || 'unknown_card';
  const charKey = getPrestigeCharacterKey(cardOrId);
  const safeMissionKey = String(missionKey || '').trim();
  const safeLegacy = String(legacyMissionId || '').trim();
  const claims = window.userPrestigeClaims || {};

  try {
    if (safeMissionKey) {
      const k1 = `prestige_mission_claim_${safeCardId}_${safeMissionKey}`;
      if (claims[k1] === '1' || localStorage.getItem(k1) === '1') return true;
    }
    if (safeLegacy) {
      const kLeg = `prestige_mission_claim_${safeCardId}_${safeLegacy}`;
      if (claims[kLeg] === '1' || localStorage.getItem(kLeg) === '1') return true;
    }

    if (charKey) {
      if (safeMissionKey) {
        const kChar = `prestige_mission_claim_char_${charKey}_${safeMissionKey}`;
        if (claims[kChar] === '1' || localStorage.getItem(kChar) === '1') return true;
      }
      if (safeLegacy) {
        const kCharLeg = `prestige_mission_claim_char_${charKey}_${safeLegacy}`;
        if (claims[kCharLeg] === '1' || localStorage.getItem(kCharLeg) === '1') return true;
      }

      const siblings = getCharacterVariants(charKey);
      for (let i = 0; i < siblings.length; i++) {
        const storedId = siblings[i];
        if (safeMissionKey) {
          const kSib = `prestige_mission_claim_${storedId}_${safeMissionKey}`;
          if (claims[kSib] === '1' || localStorage.getItem(kSib) === '1') return true;
        }
        if (safeLegacy) {
          const kSibLeg = `prestige_mission_claim_${storedId}_${safeLegacy}`;
          if (claims[kSibLeg] === '1' || localStorage.getItem(kSibLeg) === '1') return true;
        }
      }

      const targets = [safeMissionKey, safeLegacy].filter(Boolean);
      for (const targetM of targets) {
        for (const [k, v] of Object.entries(claims)) {
          if (v !== '1' && v !== 1 && v !== true && v !== 'true') continue;
          if (k.startsWith('prestige_mission_claim_') && k.endsWith(`_${targetM}`)) {
            const middle = k.replace(/^prestige_mission_claim_(?:char_)?/, '').slice(0, -(targetM.length + 1));
            if (middle === charKey || middle === safeCardId) return true;
            if (getPrestigeCharacterKey(middle) === charKey) return true;
          }
        }
        for (let i = 0; i < localStorage.length; i++) {
          const k = localStorage.key(i);
          if (!k || !k.startsWith('prestige_mission_claim_') || !k.endsWith(`_${targetM}`)) continue;
          if (localStorage.getItem(k) !== '1') continue;
          const middle = k.replace(/^prestige_mission_claim_(?:char_)?/, '').slice(0, -(targetM.length + 1));
          if (middle === charKey || middle === safeCardId) return true;
          if (getPrestigeCharacterKey(middle) === charKey) return true;
        }
      }
    }
  } catch (err) {
    console.warn('[PRESTIGE] Error checking isPrestigeMissionClaimed:', err);
  }
  return false;
}
window.isPrestigeMissionClaimed = isPrestigeMissionClaimed;

function setPrestigeMissionClaimed(cardOrId, missionKey, legacyMissionId = '') {
  const safeCardId = normalizePrestigeCardId(typeof cardOrId === 'object' ? cardOrId?.id : cardOrId) || 'unknown_card';
  const charKey = getPrestigeCharacterKey(cardOrId);
  const safeMissionKey = String(missionKey || '').trim();
  const safeLegacy = String(legacyMissionId || '').trim();
  window.userPrestigeClaims = window.userPrestigeClaims || {};
  const batch = {};

  const saveKey = (key) => {
    try { localStorage.setItem(key, '1'); } catch {}
    window.userPrestigeClaims[key] = '1';
    batch[key] = '1';
  };

  try {
    if (safeMissionKey) {
      saveKey(`prestige_mission_claim_${safeCardId}_${safeMissionKey}`);
      if (charKey) {
        saveKey(`prestige_mission_claim_char_${charKey}_${safeMissionKey}`);
      }
    }
    if (safeLegacy) {
      saveKey(`prestige_mission_claim_${safeCardId}_${safeLegacy}`);
      if (charKey) {
        saveKey(`prestige_mission_claim_char_${charKey}_${safeLegacy}`);
      }
    }

    if (charKey) {
      const siblings = getCharacterVariants(charKey);
      for (let i = 0; i < siblings.length; i++) {
        const storedId = siblings[i];
        if (safeMissionKey) {
          saveKey(`prestige_mission_claim_${storedId}_${safeMissionKey}`);
        }
        if (safeLegacy) {
          saveKey(`prestige_mission_claim_${storedId}_${safeLegacy}`);
        }
      }
    }
  } catch (e) {
    console.warn('[PRESTIGE] Error saving prestige mission claim:', e);
  }

  if (window.kvrcards && typeof window.kvrcards.savePrestigeClaimsBatch === 'function') {
    window.kvrcards.savePrestigeClaimsBatch(batch).catch(e => console.warn('[PRESTIGE] Error saving claims to backend:', e));
  }
}
window.setPrestigeMissionClaimed = setPrestigeMissionClaimed;

function normalizePrestigeCardId(cardId) {
  return String(cardId || '').trim();
}

function unifyPrestigeStore(store, config = null) {
  if (!store || typeof store !== 'object') return {};

  const cfg = config || (typeof prestigeConfigCache !== 'undefined' ? prestigeConfigCache : null) || (typeof defaultPrestigeConfig !== 'undefined' ? defaultPrestigeConfig : null);

  // 1. Group entries by canonical character key
  const groups = {};
  for (const cardId of Object.keys(store)) {
    const entry = store[cardId];
    if (!entry || typeof entry !== 'object') continue;
    const charKey = getPrestigeCharacterKey(cardId);
    if (!charKey) continue;
    if (!groups[charKey]) groups[charKey] = [];
    groups[charKey].push({ cardId, entry });
  }

  // 2. Unify each group and synchronize activeProfileId safely without resetting XP
  for (const [charKey, items] of Object.entries(groups)) {
    if (items.length === 0) continue;

    if (cfg) {
      const sampleCard = { id: items[0].cardId };
      const resolved = resolvePrestigeProfile(cfg, sampleCard);
      const targetProfileId = (resolved && resolved.isCustom)
        ? (resolved.profileId || items[0].cardId)
        : 'default';
      items.forEach(item => {
        if (!item.entry.activeProfileId) item.entry.activeProfileId = targetProfileId;
      });
    }

    // Find entry with max total XP
    const calcTotalXp = (e) => (Math.max(0, Number(e.battleXp) || 0) + Math.max(0, Number(e.missionXp) || 0));
    let maxItem = items[0];
    for (let i = 1; i < items.length; i++) {
      if (calcTotalXp(items[i].entry) > calcTotalXp(maxItem.entry)) {
        maxItem = items[i];
      }
    }

    const maxBattlesPlayed = Math.max(...items.map(it => Number(it.entry.battlesPlayed) || 0));
    const maxBattlesWon = Math.max(...items.map(it => Number(it.entry.battlesWon) || 0));
    const maxRoundsWon = Math.max(...items.map(it => Number(it.entry.roundsWon) || 0));
    const mergedMissionProgress = {};
    items.forEach(it => {
      const mp = it.entry.missionProgress || {};
      for (const [k, v] of Object.entries(mp)) {
        mergedMissionProgress[k] = Math.max(mergedMissionProgress[k] || 0, Number(v) || 0);
      }
    });

    // Sync all variants in this character group
    items.forEach(it => {
      it.entry.battleXp = maxItem.entry.battleXp;
      it.entry.missionXp = maxItem.entry.missionXp;
      it.entry.battlesPlayed = maxBattlesPlayed;
      it.entry.battlesWon = maxBattlesWon;
      it.entry.roundsWon = maxRoundsWon;
      it.entry.missionProgress = { ...mergedMissionProgress };
      it.entry.activeProfileId = maxItem.entry.activeProfileId || it.entry.activeProfileId;
      it.entry.updatedAt = Math.max(...items.map(i => Number(i.entry.updatedAt) || 0), Date.now());
    });
  }

  return store;
}

const PRESTIGE_SYSTEM_BACKUP = {"cactus":{"battlesPlayed":0,"battlesWon":0,"battleXp":200,"missionXp":0,"updatedAt":1790515021485},"bazzor_sylvaro":{"battlesPlayed":0,"battlesWon":0,"battleXp":250,"missionXp":0,"updatedAt":1790473783140},"aniel":{"battlesPlayed":0,"battlesWon":0,"battleXp":1000,"missionXp":0,"updatedAt":1790520791609},"kelsier":{"battlesPlayed":0,"battlesWon":0,"battleXp":1000,"missionXp":0,"updatedAt":1790520748371},"sukui_uzumaki":{"battlesPlayed":11,"battlesWon":11,"battleXp":2330,"missionXp":750,"updatedAt":1790523859797},"kyokai":{"battlesPlayed":0,"battlesWon":0,"battleXp":4500,"missionXp":0,"updatedAt":1790523250256},"vivar":{"battlesPlayed":2,"battlesWon":2,"battleXp":810,"missionXp":0,"updatedAt":1790523877318},"raiden_fuutaro":{"battlesPlayed":0,"battlesWon":0,"battleXp":2000,"missionXp":0,"updatedAt":1790523923662},"alex_petrov":{"battlesPlayed":0,"battlesWon":0,"battleXp":250,"missionXp":0,"updatedAt":1790509112264},"koro_tsume":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790509150144},"one":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790509163312},"josefina_de_la_rosa":{"battlesPlayed":0,"battlesWon":0,"battleXp":400,"missionXp":0,"updatedAt":1790515095624},"isamu":{"battlesPlayed":0,"battlesWon":0,"battleXp":200,"missionXp":0,"updatedAt":1790514013772},"zeku":{"battlesPlayed":0,"battlesWon":0,"battleXp":200,"missionXp":0,"updatedAt":1790515021485},"hana_uzumaki":{"battlesPlayed":0,"battlesWon":0,"battleXp":200,"missionXp":0,"updatedAt":1790515021485},"mario":{"battlesPlayed":0,"battlesWon":0,"battleXp":300,"missionXp":0,"updatedAt":1790515095624},"donmaya":{"battlesPlayed":0,"battlesWon":0,"battleXp":250,"missionXp":0,"updatedAt":1790513088139},"0011":{"battlesPlayed":0,"battlesWon":0,"battleXp":1500,"missionXp":0,"updatedAt":1790523202810},"aya":{"battlesPlayed":0,"battlesWon":0,"battleXp":1500,"missionXp":0,"updatedAt":1790515324096},"yokubo":{"battlesPlayed":0,"battlesWon":0,"battleXp":1000,"missionXp":0,"updatedAt":1790523948675},"conillo":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790515288110},"pedro_maya":{"battlesPlayed":0,"battlesWon":0,"battleXp":250,"missionXp":0,"updatedAt":1790513469664},"shinko":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790513561503},"yuki_hatake":{"battlesPlayed":0,"battlesWon":0,"battleXp":1000,"missionXp":0,"updatedAt":1790515254625},"tv":{"battlesPlayed":0,"battlesWon":0,"battleXp":1000,"missionXp":0,"updatedAt":1790514148141},"makoto_hyuga":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790514013772},"cocinero":{"battlesPlayed":0,"battlesWon":0,"battleXp":200,"missionXp":0,"updatedAt":1790515288110},"kirio_tsume":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790514013772},"kyo":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790514054264},"el_maya":{"battlesPlayed":0,"battlesWon":0,"battleXp":300,"missionXp":0,"updatedAt":1790516776639},"azumi_kowai":{"battlesPlayed":0,"battlesWon":0,"battleXp":200,"missionXp":0,"updatedAt":1790515288110},"camarero":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790514054264},"leonardo_martinez":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790514112831},"nihiro":{"battlesPlayed":0,"battlesWon":0,"battleXp":1000,"missionXp":0,"updatedAt":1790515371709},"terepo_noso":{"battlesPlayed":0,"battlesWon":0,"battleXp":1000,"missionXp":0,"updatedAt":1790520671577},"peyan_uzumaki_icono":{"battlesPlayed":2,"battlesWon":2,"battleXp":600,"missionXp":120,"updatedAt":1790523147439},"shitara":{"battlesPlayed":1,"battlesWon":1,"battleXp":550,"missionXp":120,"updatedAt":1790523136757},"hozon":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790514284152},"ayane_hatake":{"battlesPlayed":0,"battlesWon":0,"battleXp":200,"missionXp":0,"updatedAt":1790515095624},"eustacio":{"battlesPlayed":0,"battlesWon":0,"battleXp":200,"missionXp":0,"updatedAt":1790515021485},"dario_maya":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790515021485},"zilya_chin":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790515021485},"pablo":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790515021485},"kira_hyuga":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790515021485},"maria":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790515021485},"mikhail_hoot":{"battlesPlayed":0,"battlesWon":0,"battleXp":200,"missionXp":0,"updatedAt":1790515095624},"kosuke_kowai":{"battlesPlayed":0,"battlesWon":0,"battleXp":200,"missionXp":0,"updatedAt":1790516776639},"musashi":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790515095624},"lai":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790515288110},"lilia_inazuma":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790515288110},"kenta_kowai":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790515288110},"betoks_hatake":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790515288110},"iku_tsumori":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790515371709},"hashin_otsutsuki":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790515388942},"raiden_senjuro":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790515400991},"fernando_caballero":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790515414401},"aranion_noroi":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790515429098},"jose_carmona":{"battlesPlayed":0,"battlesWon":0,"battleXp":100,"missionXp":0,"updatedAt":1790516776639},"kozue_ikari":{"battlesPlayed":0,"battlesWon":0,"battleXp":250,"missionXp":0,"updatedAt":1790516776639},"shiroku_kowai":{"battlesPlayed":11,"battlesWon":11,"battleXp":550,"missionXp":770,"updatedAt":1790523830194},"ryuki":{"battlesPlayed":10,"battlesWon":10,"battleXp":500,"missionXp":770,"updatedAt":1790523833808},"zack_ryuga_iconoprime":{"battlesPlayed":11,"battlesWon":11,"battleXp":550,"missionXp":770,"updatedAt":1790523845570},"ronan_hatake_cota1":{"battlesPlayed":11,"battlesWon":11,"battleXp":550,"missionXp":750,"updatedAt":1790523848331},"kurushimi":{"battlesPlayed":2,"battlesWon":2,"battleXp":100,"missionXp":120,"updatedAt":1790521050989},"akarui_hoshi":{"battlesPlayed":1,"battlesWon":1,"battleXp":50,"missionXp":120,"updatedAt":1790521048569},"buer":{"battlesPlayed":1,"battlesWon":1,"battleXp":550,"missionXp":120,"updatedAt":1790520700304},"takeshi_hyuga_heroe":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790520653682},"kurai_tenro":{"battlesPlayed":11,"battlesWon":11,"battleXp":1330,"missionXp":750,"updatedAt":1790523874014},"saisho_no_kanmon":{"battlesPlayed":0,"battlesWon":0,"battleXp":1500,"missionXp":0,"updatedAt":1790523948675},"hokori":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790520748371},"raiden_senjuro_au":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790520748371},"yasumi_noroi":{"battlesPlayed":0,"battlesWon":0,"battleXp":1000,"missionXp":0,"updatedAt":1790523948675},"akarui_noroi":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790520791609},"mamoru":{"battlesPlayed":1,"battlesWon":1,"battleXp":50,"missionXp":120,"updatedAt":1790523163710},"jenue_bogai":{"battlesPlayed":1,"battlesWon":1,"battleXp":50,"missionXp":120,"updatedAt":1790523179724},"dankha_sagi":{"battlesPlayed":2,"battlesWon":2,"battleXp":100,"missionXp":120,"updatedAt":1790521292396},"sekitan":{"battlesPlayed":11,"battlesWon":11,"battleXp":330,"missionXp":750,"updatedAt":1790523855839},"taka_uzumaki":{"battlesPlayed":11,"battlesWon":11,"battleXp":330,"missionXp":750,"updatedAt":1790523864981},"ezio_siam":{"battlesPlayed":2,"battlesWon":2,"battleXp":100,"missionXp":120,"updatedAt":1790523150475},"kinan_hatake":{"battlesPlayed":2,"battlesWon":2,"battleXp":100,"missionXp":120,"updatedAt":1790523158943},"kenji_ikari":{"battlesPlayed":0,"battlesWon":0,"battleXp":250,"missionXp":0,"updatedAt":1790523205731},"suru_sagi":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790523221383},"donyoku":{"battlesPlayed":0,"battlesWon":0,"battleXp":1000,"missionXp":0,"updatedAt":1790523964139},"noroi_beast":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790523888972},"kenji_nara":{"battlesPlayed":0,"battlesWon":0,"battleXp":500,"missionXp":0,"updatedAt":1790523948675}};
const PRESTIGE_SYSTEM_CLAIMS = {"prestige_claim_0011_1":"1","prestige_claim_donyoku_1":"1","prestige_claim_kurai_tenro_3":"1","prestige_claim_noroi_beast_1":"1","prestige_claim_noroi_beast_2":"1","prestige_claim_taka_uzumaki_2":"1","prestige_mission_claim_taka_uzumaki_p2_mission_2":"1","prestige_claim_kenji_nara_1":"1","prestige_claim_kenji_nara_2":"1","prestige_claim_raiden_fuutaro_3":"1","prestige_claim_sekitan_2":"1"};

function isHugoUser() {
  try {
    const rawUser = (typeof currentUser === 'string' && currentUser)
      || (typeof window !== 'undefined' && window.currentUser)
      || localStorage.getItem('kvrUsername')
      || localStorage.getItem('userId')
      || '';
    const safe = String(rawUser).toLowerCase().trim();
    return safe === 'hugoman' || safe === 'hugom1307';
  } catch {
    return false;
  }
}
window.isHugoUser = isHugoUser;

function invalidatePrestigeCache() {
  prestigeProgressStoreCache = null;
  characterVariantsMap = null;
  prestigeBackupRestored = false;
}
window.invalidatePrestigeCache = invalidatePrestigeCache;

function ensurePrestigeBackupRestored(store) {
  let changed = false;
  if (!store || typeof store !== 'object') store = {};

  const isHugo = isHugoUser();

  // If NOT Hugo, NEVER inject Hugo's backup! Purge any previously injected backup entries
  if (!isHugo) {
    try {
      if (localStorage.getItem('prestige_foreign_cleaned_v3') !== 'true') {
        localStorage.setItem('prestige_foreign_cleaned_v3', 'true');
        let cleaned = false;
        if (typeof PRESTIGE_SYSTEM_BACKUP === 'object' && PRESTIGE_SYSTEM_BACKUP) {
          for (const [bId, bVal] of Object.entries(PRESTIGE_SYSTEM_BACKUP)) {
            const cur = store[bId];
            if (cur && (cur.updatedAt === bVal.updatedAt || (cur.battleXp === bVal.battleXp && cur.battlesPlayed === bVal.battlesPlayed))) {
              delete store[bId];
              cleaned = true;
            }
          }
        }
        if (typeof PRESTIGE_SYSTEM_CLAIMS === 'object' && PRESTIGE_SYSTEM_CLAIMS) {
          for (const claimKey of Object.keys(PRESTIGE_SYSTEM_CLAIMS)) {
            try { localStorage.removeItem(claimKey); } catch {}
          }
        }
        if (cleaned) {
          try { localStorage.setItem(getPrestigeProgressStorageKey(), JSON.stringify(store)); } catch {}
        }
      }
    } catch {}
    return store;
  }

  if (typeof PRESTIGE_SYSTEM_BACKUP === 'object' && PRESTIGE_SYSTEM_BACKUP) {
    for (const [cardId, bEntry] of Object.entries(PRESTIGE_SYSTEM_BACKUP)) {
      const cur = store[cardId];
      const bTotalXp = (Number(bEntry?.battleXp) || 0) + (Number(bEntry?.missionXp) || 0);
      const curTotalXp = cur ? ((Number(cur?.battleXp) || 0) + (Number(cur?.missionXp) || 0)) : 0;
      const bBattles = Number(bEntry?.battlesPlayed) || 0;
      const curBattles = Number(cur?.battlesPlayed) || 0;

      if (!cur || curTotalXp < bTotalXp || curBattles < bBattles) {
        store[cardId] = {
          battlesPlayed: Math.max(curBattles, bBattles),
          battlesWon: Math.max(Number(cur?.battlesWon) || 0, Number(bEntry?.battlesWon) || 0),
          roundsWon: Math.max(Number(cur?.roundsWon) || 0, Number(bEntry?.roundsWon) || 0),
          battleXp: Math.max(Number(cur?.battleXp) || 0, Number(bEntry?.battleXp) || 0),
          missionXp: Math.max(Number(cur?.missionXp) || 0, Number(bEntry?.missionXp) || 0),
          missionProgress: { ...(bEntry?.missionProgress || {}), ...(cur?.missionProgress || {}) },
          activeProfileId: cur?.activeProfileId || bEntry?.activeProfileId || undefined,
          updatedAt: Math.max(Number(cur?.updatedAt) || 0, Number(bEntry?.updatedAt) || 0, Date.now())
        };
        changed = true;
      }
    }
  }

  if (typeof PRESTIGE_SYSTEM_CLAIMS === 'object' && PRESTIGE_SYSTEM_CLAIMS) {
    try {
      for (const [claimKey, val] of Object.entries(PRESTIGE_SYSTEM_CLAIMS)) {
        if (localStorage.getItem(claimKey) !== '1') {
          localStorage.setItem(claimKey, String(val));
        }
      }
    } catch {}
  }

  if (changed) {
    try {
      localStorage.setItem(getPrestigeProgressStorageKey(), JSON.stringify(store));
    } catch {}
  }
  return store;
}

let prestigeProgressStoreCache = null;
let prestigeBackupRestored = false;
let isUnifyingStore = false;

function loadPrestigeProgressStore() {
  if (prestigeProgressStoreCache) return prestigeProgressStoreCache;
  try {
    const raw = localStorage.getItem(getPrestigeProgressStorageKey());
    const parsed = raw ? JSON.parse(raw) : null;
    let store = (parsed && typeof parsed === 'object') ? parsed : {};

    if (!prestigeBackupRestored) {
      prestigeBackupRestored = true;
      store = ensurePrestigeBackupRestored(store);
    }

    if (!isUnifyingStore) {
      isUnifyingStore = true;
      try {
        unifyPrestigeStore(store);
      } finally {
        isUnifyingStore = false;
      }
    }
    prestigeProgressStoreCache = store;
    return store;
  } catch {
    prestigeProgressStoreCache = ensurePrestigeBackupRestored({});
    return prestigeProgressStoreCache;
  }
}

function savePrestigeProgressStore(store) {
  prestigeProgressStoreCache = store;
  characterVariantsMap = null;
  try {
    localStorage.setItem(getPrestigeProgressStorageKey(), JSON.stringify(store || {}));
  } catch {}
}

function getPrestigeProgressEntry(cardId, createIfMissing = false) {
  const normalizedId = normalizePrestigeCardId(cardId);
  if (!normalizedId) {
    return { cardId: '', battlesPlayed: 0, battlesWon: 0, roundsWon: 0, battleXp: 0, missionXp: 0, missionProgress: {} };
  }

  const store = loadPrestigeProgressStore();
  let existing = (store[normalizedId] && typeof store[normalizedId] === 'object')
    ? store[normalizedId]
    : null;

  const charKey = getPrestigeCharacterKey(normalizedId);

  // If this specific variant doesn't have an entry yet, inherit from any character sibling
  if (!existing && charKey) {
    const siblings = getCharacterVariants(charKey);
    for (let i = 0; i < siblings.length; i++) {
      const sId = siblings[i];
      if (store[sId] && typeof store[sId] === 'object') {
        existing = { ...store[sId] };
        store[normalizedId] = existing;
        savePrestigeProgressStore(store);
        break;
      }
    }
  }

  if (!existing && createIfMissing) {
    store[normalizedId] = {
      battlesPlayed: 0,
      battlesWon: 0,
      roundsWon: 0,
      battleXp: 0,
      missionXp: 0,
      missionProgress: {},
      updatedAt: Date.now()
    };
    savePrestigeProgressStore(store);
  }

  const current = store[normalizedId] || existing || {};
  return {
    cardId: normalizedId,
    battlesPlayed: Math.max(0, Number(current.battlesPlayed) || 0),
    battlesWon: Math.max(0, Number(current.battlesWon) || 0),
    roundsWon: Math.max(0, Number(current.roundsWon) || 0),
    battleXp: Math.max(0, Number(current.battleXp) || 0),
    missionXp: Math.max(0, Number(current.missionXp) || 0),
    missionProgress: current.missionProgress || {}
  };
}

function parseMissionTargetValue(mission) {
  const directTarget = Number(mission?.target ?? mission?.goal ?? mission?.required ?? mission?.count ?? mission?.value);
  if (Number.isFinite(directTarget) && directTarget > 0) return Math.floor(directTarget);

  const text = String(mission?.name || mission?.text || mission?.description || '');
  const numberMatch = text.match(/(\d+)/);
  if (numberMatch) {
    const parsed = Number(numberMatch[1]);
    if (Number.isFinite(parsed) && parsed > 0) return Math.floor(parsed);
  }

  return 1;
}

function resolveMissionMetric(mission) {
  const missionType = String(mission?.type || mission?.metric || mission?.action || '').toLowerCase();
  const missionText = String(mission?.name || mission?.text || mission?.description || '').toLowerCase();

  if (missionType === 'winsrounds' || missionType === 'rounds_won' || /(ronda|round)/.test(missionType) || /(ronda|round)/.test(missionText)) {
    return 'winsRounds';
  }
  if (missionType.includes('win') || missionType.includes('victory') || /(ganar|gana|victoria)/.test(missionText)) {
    return 'wins';
  }
  if (missionType.includes('battle') || missionType.includes('play') || /(jugar|juega|batalla|partida)/.test(missionText)) {
    return 'played';
  }

  return null;
}

function getMissionProgressForCard(mission, cardProgress, card = null, missionKey = null) {
  const metric = resolveMissionMetric(mission);
  const target = parseMissionTargetValue(mission);
  if (!metric) return null;

  if (metric === 'played') {
    const current = Math.max(0, Number(cardProgress?.battlesPlayed) || 0);
    return { current, target, metric };
  }

  if (metric === 'wins') {
    const current = Math.max(0, Number(cardProgress?.battlesWon) || 0);
    return { current, target, metric };
  }

  if (metric === 'winsRounds') {
    let current = 0;
    const mp = cardProgress?.missionProgress || {};

    if (missionKey && typeof mp[missionKey] !== 'undefined') {
      current = Math.max(current, Number(mp[missionKey]) || 0);
    }
    if (mission?.id && typeof mp[mission.id] !== 'undefined') {
      current = Math.max(current, Number(mp[mission.id]) || 0);
    }

    const reqProc = mission?.procedencia || mission?.origin || mission?.Procedencia;
    const reqOwner = mission?.owner || mission?.Owner || mission?.dueno || mission?.dueño;
    const isSelfCardMission = !reqProc && !reqOwner;

    if (isSelfCardMission) {
      current = Math.max(current, Number(cardProgress?.roundsWon) || 0);
    }

    return { current, target, metric };
  }

  return null;
}

function getEquippedBaseCardIdsForPrestige() {
  const teamFromIndex = Array.isArray(window.allTeams)
    ? window.allTeams[window.currentTeamIndex || 0]
    : null;
  const sourceTeam = Array.isArray(window.selectedTeam) && window.selectedTeam.length > 0
    ? window.selectedTeam
    : (Array.isArray(teamFromIndex) ? teamFromIndex : []);
  const ids = new Set();

  sourceTeam.forEach((teamCardId) => {
    if (!teamCardId) return;
    let baseId = String(teamCardId);

    if (baseId.includes('_notrait')) {
      baseId = baseId.split('_notrait')[0];
    } else if (typeof cardTraitsMap !== 'undefined' && cardTraitsMap?.[baseId]?.cardId) {
      baseId = String(cardTraitsMap[baseId].cardId);
    } else if (baseId.includes('trait_')) {
      const traitData = typeof cardTraitsMap !== 'undefined' ? cardTraitsMap?.[baseId] : null;
      baseId = String(traitData?.cardId || baseId);
    }

    const normalized = normalizePrestigeCardId(baseId);
    if (normalized) ids.add(normalized);
  });

  return Array.from(ids);
}

function setBattlePrestigeEligibleCardIds() {
  if (!window.battleState) return;
  window.battleState.prestigeEligibleCardIds = getEquippedBaseCardIdsForPrestige();
}

async function recordPrestigeBattleOutcome(didWin) {
  const eligibleIds = Array.isArray(window.battleState?.prestigeEligibleCardIds)
    ? window.battleState.prestigeEligibleCardIds
    : getEquippedBaseCardIdsForPrestige();

  if (!Array.isArray(eligibleIds) || eligibleIds.length === 0) return;

  const cfg = await getPrestigeConfig();
  const store = loadPrestigeProgressStore();

  eligibleIds.forEach((cardId) => {
    const normalizedId = normalizePrestigeCardId(cardId);
    if (!normalizedId) return;

    const profile = resolvePrestigeProfile(cfg, { id: normalizedId });
    const xpRules = profile?.xpRules || defaultPrestigeConfig.xpRules;
    const playedXp = Math.max(0, Number(xpRules?.battlePlayed) || 0);
    const winBonusXp = didWin ? Math.max(0, Number(xpRules?.battleWinBonus) || 0) : 0;
    const gainedXp = playedXp + winBonusXp;

    const current = store[normalizedId] && typeof store[normalizedId] === 'object'
      ? store[normalizedId]
      : { battlesPlayed: 0, battlesWon: 0, battleXp: 0, missionXp: 0 };

    current.battlesPlayed = Math.max(0, Number(current.battlesPlayed) || 0) + 1;
    if (didWin) current.battlesWon = Math.max(0, Number(current.battlesWon) || 0) + 1;
    current.battleXp = Math.max(0, Number(current.battleXp) || 0) + gainedXp;
    current.missionXp = Math.max(0, Number(current.missionXp) || 0);
    current.updatedAt = Date.now();

    store[normalizedId] = current;

    // Sync to all variants of this character in store
    const charKey = getPrestigeCharacterKey(normalizedId);
    if (charKey) {
      Object.keys(store).forEach(k => {
        if (getPrestigeCharacterKey(k) === charKey) {
          store[k].battlesPlayed = current.battlesPlayed;
          store[k].battlesWon = current.battlesWon;
          store[k].battleXp = current.battleXp;
          store[k].missionXp = current.missionXp;
          store[k].roundsWon = current.roundsWon;
          store[k].updatedAt = Date.now();
        }
      });
    }
  });

  savePrestigeProgressStore(store);
}

async function recordPrestigeRoundWon(winningCard) {
  if (!winningCard) return;

  try {
    let fullCard = null;
    if (typeof winningCard === 'object' && winningCard !== null) {
      fullCard = winningCard;
    } else if (typeof winningCard === 'string') {
      fullCard = (typeof findCardInCatalog === 'function') ? findCardInCatalog(winningCard) : null;
    }
    if (!fullCard && winningCard) {
      fullCard = (typeof findCardInCatalog === 'function') ? findCardInCatalog(winningCard) : { id: winningCard };
    }

    const playedCardId = normalizePrestigeCardId(fullCard?.id || (typeof winningCard === 'string' ? winningCard : ''));
    if (!playedCardId) return;

    const playedCharKey = getPrestigeCharacterKey(fullCard || playedCardId);
    const playedProc = String(fullCard?.procedencia || fullCard?.Procedencia || fullCard?.origin || fullCard?.origen || '').toLowerCase().trim();
    const playedOwner = String(fullCard?.owner || fullCard?.Owner || fullCard?.dueno || fullCard?.dueño || fullCard?.creator || fullCard?.autor || '').toLowerCase().trim();

    const cfg = await getPrestigeConfig();
    const store = loadPrestigeProgressStore();

    // 1. Update roundsWon for played card and all character variants in store
    let playedEntry = store[playedCardId];
    if (!playedEntry || typeof playedEntry !== 'object') {
      playedEntry = getPrestigeProgressEntry(playedCardId, true);
    }
    playedEntry.roundsWon = Math.max(0, Number(playedEntry.roundsWon) || 0) + 1;
    playedEntry.updatedAt = Date.now();
    store[playedCardId] = playedEntry;

    if (playedCharKey) {
      Object.keys(store).forEach(k => {
        if (getPrestigeCharacterKey(k) === playedCharKey) {
          store[k].roundsWon = playedEntry.roundsWon;
          store[k].updatedAt = Date.now();
        }
      });
    }

    // 2. Collect all configured card profiles from config
    let cardConfigs = [];
    if (Array.isArray(cfg)) {
      cardConfigs = cfg;
    } else if (cfg?.cards && Array.isArray(cfg.cards)) {
      cardConfigs = cfg.cards;
    } else if (cfg?.cards && typeof cfg.cards === 'object') {
      cardConfigs = Object.entries(cfg.cards).map(([id, data]) => ({ cardId: id, ...data }));
    }

    let anyMissionUpdated = false;

    // 3. For each configured card, check its missions for round win conditions
    cardConfigs.forEach(entry => {
      const targetCardId = normalizePrestigeCardId(entry.cardId || entry.id);
      if (!targetCardId || targetCardId === 'default') return;

      const targetCharKey = getPrestigeCharacterKey(targetCardId);
      const levels = Array.isArray(entry.levels) ? entry.levels : [];

      levels.forEach((lvl, lvlIdx) => {
        const sourcePrestige = Number(lvl?.prestige) || (lvlIdx + 1);
        const missions = Array.isArray(lvl?.missions) ? lvl.missions : [];

        missions.forEach((m, mIdx) => {
          const mType = String(m?.type || m?.metric || '').toLowerCase();
          const mName = String(m?.name || m?.text || '').toLowerCase();
          const isRoundMission = mType === 'winsrounds' || mType === 'rounds_won' || /(ronda|round)/i.test(mType) || /(ronda|round)/i.test(mName);

          if (!isRoundMission) return;

          let reqProc = String(m.procedencia || m.origin || m.Procedencia || '').toLowerCase().trim();
          let reqOwner = String(m.owner || m.Owner || m.dueno || m.dueño || '').toLowerCase().trim();

          // Fallback parsing from mission name if not explicitly set
          if (!reqProc && !reqOwner) {
            const procMatch = mName.match(/cartas?\s+de\s+([A-Za-z0-9_]+)/i);
            if (procMatch) {
              const candidate = procMatch[1].toLowerCase().trim();
              const availProcs = (typeof availableProcedencias !== 'undefined' && Array.isArray(availableProcedencias))
                ? availableProcedencias.map(p => String(p).toLowerCase().trim())
                : [];
              if (availProcs.includes(candidate)) {
                reqProc = candidate;
              }
            }
          }

          let isMatch = true;

          if (reqProc) {
            if (!playedProc || (playedProc !== reqProc && !playedProc.includes(reqProc) && !reqProc.includes(playedProc))) {
              isMatch = false;
            }
          }

          if (reqOwner) {
            if (!playedOwner || (playedOwner !== reqOwner && !playedOwner.includes(reqOwner) && !reqOwner.includes(playedOwner))) {
              isMatch = false;
            }
          }

          // If neither procedencia nor owner is specified, it requires winning with this specific character
          if (!reqProc && !reqOwner) {
            if (playedCharKey !== targetCharKey && playedCardId !== targetCardId) {
              isMatch = false;
            }
          }

          if (isMatch) {
            const baseMissionId = String(m?.id || `mission_${mIdx + 1}`);
            const missionKey = `p${sourcePrestige}_${baseMissionId}`;

            if (!store[targetCardId] || typeof store[targetCardId] !== 'object') {
              store[targetCardId] = {
                battlesPlayed: 0,
                battlesWon: 0,
                roundsWon: 0,
                battleXp: 0,
                missionXp: 0,
                missionProgress: {},
                updatedAt: Date.now()
              };
            }

            const targetEntry = store[targetCardId];
            targetEntry.missionProgress = targetEntry.missionProgress || {};
            targetEntry.missionProgress[missionKey] = Math.max(0, Number(targetEntry.missionProgress[missionKey]) || 0) + 1;
            if (m.id) {
              targetEntry.missionProgress[m.id] = Math.max(0, Number(targetEntry.missionProgress[m.id]) || 0) + 1;
            }
            targetEntry.updatedAt = Date.now();

            // Sync to all variants of targetCharKey in store
            if (targetCharKey) {
              Object.keys(store).forEach(k => {
                if (getPrestigeCharacterKey(k) === targetCharKey) {
                  store[k].missionProgress = store[k].missionProgress || {};
                  store[k].missionProgress[missionKey] = targetEntry.missionProgress[missionKey];
                  if (m.id) store[k].missionProgress[m.id] = targetEntry.missionProgress[m.id];
                  store[k].updatedAt = Date.now();
                }
              });
            }

            anyMissionUpdated = true;
          }
        });
      });
    });

    savePrestigeProgressStore(store);

    if (anyMissionUpdated || playedEntry) {
      if (typeof window.updateGlobalNotificationBadges === 'function') {
        window.updateGlobalNotificationBadges();
      }
      if (typeof window.updateCardPrestigeRewardBadge === 'function') {
        window.updateCardPrestigeRewardBadge(playedCardId);
      }
    }
  } catch (err) {
    console.warn('[PRESTIGE] Error en recordPrestigeRoundWon:', err);
  }
}
window.recordPrestigeRoundWon = recordPrestigeRoundWon;

function getRewardName(reward) {
  return String(
    reward?.name || reward?.title || reward?.label || reward?.text || 'Recompensa'
  );
}

const CARD_QUALITY_SUFFIX_REGEX = /_(?:iconoprime|icono_prime|icon_prime|prime_icon|diosantiguo|dios_antiguo|ancientgod|superheroe|super_heroe|iconosuperprime|superprime|legendaria|legendario|legend|inmortal|inmo|icono|icon|heroe|hero|oro|gold|plata|silver|bronce|bronze|especiales|especial\d*|comun|evolucion|evolution|evoe|evochad|evosamurai|evo\d*|prime|tots|toty|evento|event|sbc|sbcevo|flashback|cota\d*|tsukirocota\d*|au|exclusive|shadow|recompensa|promo)$/i;

function normalizePrestigeAssetUrl(url) {
  if (!url || typeof url !== 'string') return url;
  return url.replace(/^https?:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/main\/(.*)$/i, 'https://$1.github.io/$2/$3');
}

function findCardInCatalog(cardIdOrReward, allCards = null) {
  const cards = (Array.isArray(allCards) && allCards.length > 0)
    ? allCards
    : ((Array.isArray(rewardHudCatalogCache.cards) && rewardHudCatalogCache.cards.length > 0)
      ? rewardHudCatalogCache.cards
      : (Array.isArray(window.allCardsCache) && window.allCardsCache.length > 0
        ? window.allCardsCache
        : (Array.isArray(window.availableCards) ? window.availableCards : [])));

  if (!cards || cards.length === 0) return null;

  let rawId = '';
  let rawName = '';
  if (typeof cardIdOrReward === 'string') {
    rawId = cardIdOrReward.trim();
  } else if (cardIdOrReward && typeof cardIdOrReward === 'object') {
    rawId = String(cardIdOrReward.cardId || cardIdOrReward.id || cardIdOrReward.card || cardIdOrReward.card_id || '').trim();
    rawName = String(cardIdOrReward.name || cardIdOrReward.title || cardIdOrReward.label || cardIdOrReward.nombre || '').trim();
  }

  const cleanReqName = rawName.replace(/^(?:🃏|\s)*(?:carta)\s*:\s*/i, '').trim().toLowerCase();
  const lowerId = rawId.toLowerCase();
  const withoutSuffix = lowerId.replace(CARD_QUALITY_SUFFIX_REGEX, '');

  // 1. Coincidencia exacta por ID
  if (lowerId) {
    let found = cards.find(c => c && String(c.id || '').toLowerCase() === lowerId);
    if (found) return found;

    // 2. Coincidencia quitando sufijo de calidad (ej: kinan_hatake_icono -> kinan_hatake)
    if (withoutSuffix && withoutSuffix !== lowerId) {
      found = cards.find(c => c && String(c.id || '').toLowerCase() === withoutSuffix);
      if (found) return found;
    }

    // 3. Coincidencia si la carta en catálogo tiene sufijo pero el ID no
    found = cards.find(c => {
      if (!c) return false;
      const cId = String(c.id || '').toLowerCase();
      const cWithoutSuffix = cId.replace(CARD_QUALITY_SUFFIX_REGEX, '');
      return cWithoutSuffix === lowerId || cWithoutSuffix === withoutSuffix;
    });
    if (found) return found;
  }

  // 4. Coincidencia por nombre limpio
  if (cleanReqName) {
    let found = cards.find(c => c && String(c.name || c.nombre || '').trim().toLowerCase() === cleanReqName);
    if (found) return found;

    found = cards.find(c => {
      const cName = String(c?.name || c?.nombre || '').trim().toLowerCase();
      return cName && (cleanReqName.includes(cName) || cName.includes(cleanReqName));
    });
    if (found) return found;
  }

  // 5. Coincidencia ID a nombre (ej: "kinan_hatake" -> "kinan hatake")
  if (withoutSuffix) {
    const idAsName = withoutSuffix.replace(/_/g, ' ').trim();
    const found = cards.find(c => {
      const cName = String(c?.name || c?.nombre || '').trim().toLowerCase();
      return cName === idAsName;
    });
    if (found) return found;
  }

  return null;
}
window.findCardInCatalog = findCardInCatalog;

function getCardQualityCategory(cardOrId) {
  let cardObj = null;
  let id = '';
  if (cardOrId && typeof cardOrId === 'object') {
    cardObj = cardOrId;
    id = String(cardOrId.id || cardOrId.cardId || cardOrId.card || cardOrId.card_id || '').trim();
  } else if (typeof cardOrId === 'string') {
    id = cardOrId.trim();
  }

  const lowerId = id.toLowerCase();
  if (lowerId.endsWith('_bronce') || lowerId === 'bronce') return 'bronce';
  if (lowerId.endsWith('_plata') || lowerId === 'plata') return 'plata';
  if (lowerId.endsWith('_oro') || lowerId === 'oro') return 'oro';

  let rawQuality = String(cardObj?.calidad || cardObj?.quality || cardObj?.calidadId || '').toLowerCase().trim();
  if (rawQuality.includes('bronce')) return 'bronce';
  if (rawQuality.includes('plata')) return 'plata';
  if (rawQuality.includes('oro')) return 'oro';

  if (id && typeof findCardInCatalog === 'function') {
    const found = findCardInCatalog(id);
    if (found) {
      const fQuality = String(found.calidad || found.quality || found.calidadId || '').toLowerCase().trim();
      const fId = String(found.id || '').toLowerCase().trim();
      if (fQuality.includes('bronce') || fId.endsWith('_bronce')) return 'bronce';
      if (fQuality.includes('plata') || fId.endsWith('_plata')) return 'plata';
      if (fQuality.includes('oro') || fId.endsWith('_oro')) return 'oro';
      if (fQuality) return fQuality;
    }
  }

  return rawQuality || 'otro';
}
window.getCardQualityCategory = getCardQualityCategory;

function getDuplicatePrestigeXp(cardOrId, xpRules = null) {
  const rules = xpRules || (typeof defaultPrestigeConfig !== 'undefined' ? defaultPrestigeConfig.xpRules : null) || {};
  const quality = getCardQualityCategory(cardOrId);
  if (quality === 'bronce') {
    const bronzeVal = Number(rules?.duplicateBronce ?? rules?.duplicateBronze);
    return Number.isFinite(bronzeVal) && bronzeVal >= 0 ? bronzeVal : 100;
  }
  if (quality === 'plata') {
    const silverVal = Number(rules?.duplicatePlata ?? rules?.duplicateSilver);
    return Number.isFinite(silverVal) && silverVal >= 0 ? silverVal : 250;
  }
  const defaultVal = Number(rules?.duplicateFromPackOrTrade);
  return Number.isFinite(defaultVal) && defaultVal >= 0 ? defaultVal : 500;
}
window.getDuplicatePrestigeXp = getDuplicatePrestigeXp;

function findTitleInCatalog(titleIdOrReward, allTitles = null) {
  const titles = (Array.isArray(allTitles) && allTitles.length > 0)
    ? allTitles
    : ((Array.isArray(rewardHudCatalogCache.titles) && rewardHudCatalogCache.titles.length > 0)
      ? rewardHudCatalogCache.titles
      : (Array.isArray(window.availableTitles) && window.availableTitles.length > 0
        ? window.availableTitles
        : []));

  let rawId = '';
  let rawName = '';
  if (typeof titleIdOrReward === 'string') {
    rawId = titleIdOrReward.trim();
  } else if (titleIdOrReward && typeof titleIdOrReward === 'object') {
    rawId = String(titleIdOrReward.titleId || titleIdOrReward.id || titleIdOrReward.title || '').trim();
    rawName = stripRewardTitleName(titleIdOrReward.name || titleIdOrReward.title || titleIdOrReward.label || '');
  }

  const normalizeStr = s => String(s || '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const normId = normalizeStr(rawId);
  const normName = normalizeStr(rawName);

  if (!titles || titles.length === 0) return null;

  // 1. Coincidencia exacta por ID normalizado
  if (normId) {
    let found = titles.find(t => t && normalizeStr(t.id) === normId);
    if (found) return found;
  }

  // 2. Coincidencia por nombre
  if (normName) {
    let found = titles.find(t => t && (normalizeStr(t.name) === normName || normalizeStr(t.titulo) === normName));
    if (found) return found;
  }

  // 3. Coincidencia ID contra nombre (ej: "dueño_electrones" -> "dueno electrones")
  if (normId) {
    const idWords = normId.replace(/_/g, ' ');
    let found = titles.find(t => {
      const tNorm = normalizeStr(t?.name || t?.titulo);
      return tNorm === idWords || tNorm.includes(idWords) || idWords.includes(tNorm);
    });
    if (found) return found;
  }

  return null;
}
window.findTitleInCatalog = findTitleInCatalog;

function resolveRewardTitleGradient(titleId, titleName, reward = null) {
  if (reward?.gradient) return reward.gradient;
  const found = findTitleInCatalog(reward || { titleId, name: titleName });
  if (found?.gradient) return found.gradient;
  return 'linear-gradient(135deg, #fef3c7 0%, #facc15 50%, #d4af37 100%)';
}

function resolveRewardCardImage(reward, allCards = null) {
  const explicit = reward?.imageUrl || reward?.iconUrl || reward?.image || reward?.icon || reward?.img;
  if (explicit && typeof explicit === 'string' && !explicit.includes('default-card') && !explicit.includes('icon-especiales')) {
    return normalizePrestigeAssetUrl(explicit);
  }

  const card = findCardInCatalog(reward, allCards);
  if (card) {
    const img = card.imageUrl || card.image || card.imagen;
    if (img && typeof img === 'string') {
      return normalizePrestigeAssetUrl(img);
    }
  }

  if (explicit && typeof explicit === 'string' && !explicit.includes('default-card')) {
    return normalizePrestigeAssetUrl(explicit);
  }

  return '';
}

function stripRewardTitleName(rawText) {
  if (typeof window.stripTitleFormatting === 'function') {
    return window.stripTitleFormatting(rawText);
  }
  if (!rawText) return '';
  let str = String(rawText);
  str = str.replace(/^(?:🏆|🃏|🎖️|🥇|🥈|🥉|\s)*(?:título|titulo)\s*:\s*/i, '');
  const emojiRegex = /(?:\p{Extended_Pictographic}|\p{Emoji_Presentation})(?:(?:\uFE0F|\uFE0E)|(?:\uD83C[\uDFFB-\uDFFF])|(?:\u200D(?:\p{Extended_Pictographic}|\p{Emoji_Presentation}))*)*/gu;
  str = str.replace(emojiRegex, '');
  str = str.replace(/^["'«»“”]+|["'«»“”]+$/g, '');
  return str.trim();
}

function getRewardImage(reward) {
  const type = String(reward?.type || reward?.tipo || '').toLowerCase();
  const name = String(reward?.name || reward?.title || reward?.label || '').toLowerCase();

  if (type === 'title' || type === 'titulo' || type === 'título' || reward?.titleId || name.includes('título') || name.includes('titulo')) {
    return ''; // Los títulos no llevan imagen
  }

  if (type === 'buff' || name.includes('buff') || reward?.stats) {
    return ''; // Los buffs llevan emoji de rayo ⚡
  }

  if (type === 'card' || type === 'carta' || reward?.cardId || name.includes('carta') || name.includes('card')) {
    const cardImg = resolveRewardCardImage(reward);
    if (cardImg) return cardImg;
  }

  const explicit = reward?.imageUrl || reward?.iconUrl || reward?.image || reward?.icon || reward?.img;
  if (explicit && !explicit.includes('default-card.png')) return String(explicit);

  if (type === 'infinite-coins' || type === 'infinite-coin' || name.includes('infinite-coin') || name.includes('infinite coin')) return './infinite-coin.png';
  if (type === 'infinite-cardpoints' || type === 'infinite-cardpoint' || name.includes('infinite-cardpoint') || name.includes('infinite cardpoint')) return './infinite-cardpoint.png';
  if (type === 'traits' || type === 'trait' || name.includes('trait')) return './trait.png';
  if (type === 'coins' || (!name.includes('infinite') && (name.includes('coin') || name.includes('moneda')))) return './coin.png';
  if (type === 'kvr' || name.includes('kvr')) return './kvr.png';
  if (type === 'pack' || name.includes('sobre') || name.includes('pack')) return './icon-especiales.png';

  return './icon-especiales.png';
}

const rewardHudCatalogCache = {
  cards: null,
  packs: null,
  titles: null
};

async function ensureRewardHudCatalogCache() {
  try {
    if (!Array.isArray(rewardHudCatalogCache.cards) || rewardHudCatalogCache.cards.length === 0) {
      if (typeof window.kvrcards?.getAllCards === 'function') {
        const res = await window.kvrcards.getAllCards();
        rewardHudCatalogCache.cards = Array.isArray(res) ? res : (Array.isArray(res?.cards) ? res.cards : (res ? Object.values(res) : []));
      }
    }
  } catch {
    rewardHudCatalogCache.cards = rewardHudCatalogCache.cards || [];
  }
  try {
    if (!Array.isArray(rewardHudCatalogCache.packs) || rewardHudCatalogCache.packs.length === 0) {
      if (typeof window.kvrcards?.getAllPacks === 'function') {
        const pRes = await window.kvrcards.getAllPacks();
        rewardHudCatalogCache.packs = Array.isArray(pRes) ? pRes : (Array.isArray(pRes?.packs) ? pRes.packs : (pRes ? Object.values(pRes) : []));
      }
    }
  } catch {
    rewardHudCatalogCache.packs = rewardHudCatalogCache.packs || [];
  }
  try {
    if (!Array.isArray(rewardHudCatalogCache.titles) || rewardHudCatalogCache.titles.length === 0) {
      if (typeof window.kvrcards?.getTitles === 'function') {
        const tRes = await window.kvrcards.getTitles();
        if (tRes && tRes.ok && Array.isArray(tRes.titles) && tRes.titles.length > 0) {
          rewardHudCatalogCache.titles = tRes.titles;
        }
      }
      if ((!rewardHudCatalogCache.titles || rewardHudCatalogCache.titles.length === 0) && Array.isArray(window.availableTitles) && window.availableTitles.length > 0) {
        rewardHudCatalogCache.titles = window.availableTitles;
      }
      if ((!rewardHudCatalogCache.titles || rewardHudCatalogCache.titles.length === 0) && typeof window.loadTitles === 'function') {
        const loaded = await window.loadTitles().catch(() => null);
        if (Array.isArray(loaded) && loaded.length > 0) {
          rewardHudCatalogCache.titles = loaded;
        }
      }
    }
  } catch {
    rewardHudCatalogCache.titles = rewardHudCatalogCache.titles || (Array.isArray(window.availableTitles) ? window.availableTitles : []);
  }
  try {
    if ((!Array.isArray(window.availableBackgrounds) || window.availableBackgrounds.length === 0) && typeof window.loadBackgrounds === 'function') {
      await window.loadBackgrounds();
    }
  } catch {}
}


function extractPrestigeLevelRewards(level) {
  if (!level) return [];
  const raw = level.rewards ?? level.reward ?? level.recompensas ?? level.recompensa;
  if (!raw) return [];
  if (Array.isArray(raw)) return raw;
  if (typeof raw === 'object') return [raw];
  return [];
}

function normalizePrestigeRewardItem(reward) {
  if (!reward) return null;
  if (typeof reward === 'string') {
    const text = reward.trim().toLowerCase();
    const num = Number((text.match(/(\d+)/) || [])[1]) || 1;
    if (text.includes('coin') || text.includes('moneda')) return { type: 'coins', amount: num, name: `${num} Coins` };
    if (text.includes('kvr')) return { type: 'kvr', amount: num, name: `${num} KvR` };
    if (text.includes('sobre') || text.includes('pack')) return { type: 'pack', packId: text.replace(/\d+/g, '').trim(), amount: num };
    if (text.includes('fondo') || text.includes('background')) return { type: 'background', backgroundId: text.replace(/\d+/g, '').trim() };
    if (text.includes('trait') || text.includes('rasgo')) return { type: 'traits', amount: num, name: `${num} Traits` };
    return { type: 'coins', amount: num, name: reward };
  }

  let type = String(reward.type || reward.tipo || reward.rewardType || reward.categoria || '').toLowerCase().trim();
  if (type === 'trait') type = 'traits';
  if (type === 'coin') type = 'coins';
  let amount = Number(reward.amount || reward.cantidad || reward.quantity || reward.count || reward.valor || 0);
  const rawName = String(reward.name || reward.nombre || reward.title || reward.label || reward.id || '').trim();

  if (!type) {
    const lower = rawName.toLowerCase();
    if (lower.includes('coin') || lower.includes('moneda')) type = 'coins';
    else if (lower.includes('kvr')) type = 'kvr';
    else if (lower.includes('sobre') || lower.includes('pack')) type = 'pack';
    else if (lower.includes('carta') || lower.includes('card')) type = 'card';
    else if (lower.includes('título') || lower.includes('titulo') || lower.includes('title')) type = 'title';
    else if (lower.includes('fondo') || lower.includes('background')) type = 'background';
    else if (lower.includes('trait') || lower.includes('rasgo')) type = 'traits';
    else if (reward.packId || reward.pack) type = 'pack';
    else if (reward.cardId || reward.card) type = 'card';
    else if (reward.titleId || reward.title) type = 'title';
    else if (reward.backgroundId || reward.fondoId) type = 'background';
  }

  if (!amount || amount <= 0) {
    const match = rawName.match(/(\d+)/);
    if (match) amount = Number(match[1]);
    else amount = 1;
  }

  const packId = String(reward.packId || reward.pack || (type === 'pack' ? (reward.id || rawName) : '')).trim();
  const cardId = String(reward.cardId || reward.card || (type === 'card' ? (reward.id || rawName) : '')).trim();
  const titleId = String(reward.titleId || reward.title || (type === 'title' ? (reward.id || rawName) : '')).trim();
  const backgroundId = String(reward.backgroundId || reward.fondoId || (type === 'background' ? (reward.id || rawName) : '')).trim();

  return {
    ...reward,
    type,
    amount,
    packId,
    cardId,
    titleId,
    backgroundId,
    name: rawName || reward.name
  };
}

async function buildRewardsHudItems(rawRewards = []) {
  await ensureRewardHudCatalogCache();
  const allCards = Array.isArray(rewardHudCatalogCache.cards) ? rewardHudCatalogCache.cards : [];
  const allPacks = Array.isArray(rewardHudCatalogCache.packs) ? rewardHudCatalogCache.packs : [];
  const allTitles = Array.isArray(rewardHudCatalogCache.titles) ? rewardHudCatalogCache.titles : (Array.isArray(window.availableTitles) ? window.availableTitles : []);
  const allBackgrounds = Array.isArray(window.availableBackgrounds) ? window.availableBackgrounds : [];

  const list = (Array.isArray(rawRewards) ? rawRewards : [rawRewards])
    .map(normalizePrestigeRewardItem)
    .filter(Boolean);

  return list.map((reward) => {
    const type = String(reward?.type || '').toLowerCase();
    const amount = Number(reward?.amount || reward?.cantidad || reward?.quantity || 1);

    if (type === 'coins') {
      return {
        type,
        name: `${Number(reward.amount || 0).toLocaleString('es-ES')} Coins`,
        imageUrl: './coin.png',
        amount: amount
      };
    }

    if (type === 'kvr') {
      return {
        type,
        name: `${Number(reward.amount || 0).toLocaleString('es-ES')} KvR`,
        imageUrl: './kvr.png',
        amount: amount
      };
    }

    if (type === 'traits' || type === 'trait') {
      return {
        type: 'traits',
        name: `${Number(reward.amount || 0).toLocaleString('es-ES')} Traits`,
        imageUrl: './trait.png',
        amount: amount
      };
    }

    if (type === 'infinite-coins' || type === 'infinite-coin') {
      return {
        type: 'infinite-coins',
        name: `${Number(reward.amount || 0).toLocaleString('es-ES')} Infinite Coins`,
        imageUrl: './infinite-coin.png',
        amount: amount
      };
    }

    if (type === 'infinite-cardpoints' || type === 'infinite-cardpoint') {
      return {
        type: 'infinite-cardpoints',
        name: `${Number(reward.amount || 0).toLocaleString('es-ES')} Infinite Card Points`,
        imageUrl: './infinite-cardpoint.png',
        amount: amount
      };
    }

    if (type === 'pack' || type === 'packs') {
      const packId = reward.packId || reward.id;
      const pack = allPacks.find(p => p.id === packId || String(p.id).toLowerCase() === String(packId).toLowerCase());
      const rawName = pack?.name || String(reward.packId || '').replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
      const baseName = rawName.replace(/^(?:sobre|pack)\s+/i, '').trim();
      const displayName = amount > 1 ? `${amount} Sobres ${baseName}` : `Sobre ${baseName}`;
      let packImg = pack?.imageUrl || pack?.image || reward?.imageUrl || reward?.iconUrl || '';
      if (!packImg) {
        const lower = String(reward.packId || '').toLowerCase();
        if (lower.includes('bronce') || lower.includes('bronze')) packImg = './icon-bronce.png';
        else if (lower.includes('plata') || lower.includes('silver')) packImg = './icon-plata.png';
        else if (lower.includes('oro') || lower.includes('gold')) packImg = './icon-oro.png';
        else if (lower.includes('heroe') || lower.includes('hero')) packImg = './icon-heroe.png';
        else if (lower.includes('icono') || lower.includes('icon')) packImg = './icon-icono.png';
        else packImg = './icon-especiales.png';
      }
      return {
        type,
        name: displayName,
        imageUrl: packImg,
        amount: amount
      };
    }

    if (type === 'card') {
      const rawCardId = String(reward.cardId || reward.id || reward.card || reward.card_id || '').trim();
      const card = findCardInCatalog(reward, allCards);
      const targetCardId = card?.id || rawCardId;
      const cardName = card?.name || card?.nombre || reward.name || rawCardId;
      const cleanCardName = String(cardName).replace(/^(?:🃏|\s)*(?:carta)\s*:\s*/i, '').trim();
      const displayName = amount > 1 ? `${amount}x Carta: ${cleanCardName}` : `Carta: ${cleanCardName}`;
      const cardImg = (reward.imageUrl && !reward.imageUrl.includes('default-card') && !reward.imageUrl.includes('icon-especiales'))
        ? normalizePrestigeAssetUrl(reward.imageUrl)
        : (card?.imageUrl ? normalizePrestigeAssetUrl(card.imageUrl) : (card?.image || card?.imagen || resolveRewardCardImage(reward, allCards)));
      return {
        type: 'card',
        name: displayName,
        cleanName: cleanCardName,
        imageUrl: cardImg || './icon-especiales.png',
        cardId: targetCardId,
        rawCardId: rawCardId,
        card,
        quality: card?.calidad || card?.quality || 'oro',
        amount: amount
      };
    }

    if (type === 'title') {
      const rawTitleId = String(reward.titleId || reward.id || reward.title || '').trim();
      const title = findTitleInCatalog(reward, allTitles);
      const targetTitleId = title?.id || rawTitleId;
      const rawName = title?.name || title?.titulo || reward.name || String(rawTitleId || '').replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
      const cleanName = stripRewardTitleName(rawName);
      const gradient = title?.gradient || reward?.gradient || resolveRewardTitleGradient(rawTitleId, cleanName, reward);
      return {
        type: 'title',
        name: cleanName,
        cleanTitle: cleanName,
        titleId: targetTitleId,
        rawTitleId: rawTitleId,
        gradient: gradient,
        titleObj: title,
        amount: 1
      };
    }

    if (type === 'background' || type === 'fondo') {
      const bgId = String(reward.backgroundId || reward.fondoId || reward.id || '').trim();
      const bg = allBackgrounds.find(b => b.id === bgId || String(b.id).toLowerCase() === bgId.toLowerCase());
      const bgName = bg?.nombre || bg?.name || reward.name || bgId;
      const bgImg = bg?.imagen || bg?.image || bg?.imageUrl || reward?.imageUrl || './assets/backgrounds/bg_default.jpg';
      return {
        type: 'background',
        name: `Fondo: ${bgName}`,
        imageUrl: bgImg,
        amount: 1
      };
    }

    if (type === 'buff') {
      const buffName = reward.name || 'Buff Kizuna';
      const statsObj = reward.stats || reward.efecto || {};
      const statParts = [];
      for (const [sKey, sVal] of Object.entries(statsObj)) {
        const sName = sKey.charAt(0).toUpperCase() + sKey.slice(1);
        statParts.push(`+${sVal}% ${sName}`);
      }
      const desc = reward.description || (statParts.length > 0 ? statParts.join(', ') : 'Buff exclusivo');
      return {
        type: 'buff',
        name: buffName,
        cleanName: buffName,
        description: desc,
        emoji: '⚡',
        imageUrl: '',
        amount: 1
      };
    }

    if (type === 'item' || type === 'items' || type === 'objeto' || type === 'objetos') {
      const rawItemId = String(reward.itemId || reward.id || reward.item || reward.objetoId || '').trim();
      const itemObj = (typeof window.findItemInCatalog === 'function')
        ? window.findItemInCatalog(rawItemId || reward)
        : null;
      const itemName = itemObj?.name || itemObj?.nombre || reward.name || reward.nombre || rawItemId || 'Objeto';
      const itemImg = itemObj?.imageUrl || itemObj?.image || itemObj?.imagen || reward.imageUrl || reward.image || reward.imagen || './assets/default-item.png';
      const cleanItemName = String(itemName).replace(/^(?:🎒|\s)*(?:objeto)\s*:\s*/i, '').trim();
      const displayName = amount > 1 ? `${amount}x ${cleanItemName}` : cleanItemName;
      const quality = itemObj?.calidad || itemObj?.quality || reward.calidad || reward.quality || 'Común';

      return {
        type: 'item',
        name: displayName,
        cleanName: cleanItemName,
        imageUrl: itemImg,
        itemId: rawItemId,
        item: itemObj,
        quality: quality,
        amount: amount
      };
    }

    return {
      type,
      name: getRewardName(reward),
      imageUrl: getRewardImage(reward),
      amount: amount
    };
  });
}

function ensureRewardsClaimHud() {
  let overlay = document.getElementById('rewards-claim-overlay');
  if (overlay) return overlay;

  overlay = document.createElement('div');
  overlay.id = 'rewards-claim-overlay';
  overlay.className = 'rewards-claim-overlay';
  overlay.innerHTML = `
    <div class="rewards-claim-modal" role="dialog" aria-modal="true" aria-label="Recompensas reclamadas">
      <h2 class="rewards-claim-title">RECOMPENSAS RECLAMADAS</h2>
      <div class="rewards-claim-grid"></div>
      <div class="rewards-claim-selected">Haz clic en una recompensa para ver su nombre.</div>
      <button type="button" class="rewards-claim-close">Continuar</button>
    </div>
  `;

  const triggerHudCloseRefresh = () => {
    overlay.classList.remove('show');
    if (typeof renderWallet === 'function') renderWallet().catch(() => {});
    if (typeof renderOwnedPacks === 'function') renderOwnedPacks().catch(() => {});
    if (typeof currentSortMode !== 'undefined' && currentSortMode === 'prestige' && typeof renderCollection === 'function') {
      renderCollection();
    }
  };

  const closeBtn = overlay.querySelector('.rewards-claim-close');
  closeBtn?.addEventListener('click', triggerHudCloseRefresh);

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) triggerHudCloseRefresh();
  });

  document.body.appendChild(overlay);
  return overlay;
}

function showRewardsClaimHUD(rewards, titleText = 'RECOMPENSAS RECLAMADAS') {
  const normalizedRewards = Array.isArray(rewards) && rewards.length > 0
    ? rewards
    : [{ name: 'Recompensa' }];

  const overlay = ensureRewardsClaimHud();
  const title = overlay.querySelector('.rewards-claim-title');
  const grid = overlay.querySelector('.rewards-claim-grid');
  const selected = overlay.querySelector('.rewards-claim-selected');

  if (title) title.textContent = String(titleText || 'RECOMPENSAS RECLAMADAS');
  if (selected) selected.textContent = 'Haz clic en una recompensa para ver su nombre.';

  if (grid) {
    grid.innerHTML = '';
    normalizedRewards.forEach((reward, idx) => {
      const rawType = String(reward.type || reward.tipo || '').toLowerCase();
      const rawName = String(reward.name || reward.title || reward.label || reward.text || 'Recompensa');
      const amount = Number(reward.amount || reward.cantidad || reward.quantity || 1);

      const isTitle = rawType === 'title' || rawType === 'titulo' || rawType === 'título'
        || Boolean(reward.titleId)
        || /^(?:🏆|\s)*(?:título|titulo)\s*:/i.test(rawName);

      const isCard = !isTitle && (rawType === 'card' || rawType === 'carta'
        || Boolean(reward.cardId)
        || /^(?:🃏|\s)*(?:carta)\s*:/i.test(rawName));

      const isBuff = !isTitle && !isCard && (
        rawType === 'buff'
        || Boolean(reward.stats)
        || /^(?:⚡|\s)*(?:buff)\s*:/i.test(rawName)
        || rawName.toLowerCase().includes('buff')
      );

      const isItem = !isTitle && !isCard && !isBuff && (
        rawType === 'item' || rawType === 'items' || rawType === 'objeto' || rawType === 'objetos'
        || Boolean(reward.itemId)
        || /^(?:🎒|\s)*(?:objeto)\s*:/i.test(rawName)
      );

      const card = document.createElement('button');
      card.type = 'button';
      card.style.animationDelay = `${idx * 60}ms`;

      if (isTitle) {
        // ==================== TÍTULO ====================
        // Sin emoji ni imagen, recuadro rectangular, nombre centrado con gradiente
        card.className = 'rewards-claim-item rewards-claim-item-title';
        const cleanTitle = stripRewardTitleName(reward.cleanTitle || reward.cleanName || rawName);
        const titleId = reward.titleId || reward.id || '';
        const gradient = resolveRewardTitleGradient(titleId, cleanTitle, reward);

        card.innerHTML = `
          <div class="rewards-claim-title-inner">
            <span class="rewards-claim-title-text" style="background-image: ${gradient};">${escapeHtml(cleanTitle)}</span>
          </div>
        `;

        card.addEventListener('click', () => {
          if (selected) selected.textContent = `Título: ${cleanTitle}`;
        });

      } else if (isCard) {
        // ==================== CARTA ====================
        // Imagen propia de la carta, recuadro adaptado a carta
        card.className = 'rewards-claim-item rewards-claim-item-card';
        const cleanCardName = String(reward.cleanName || rawName).replace(/^(?:🃏|\s)*(?:carta)\s*:\s*/i, '').trim();
        const displayName = amount > 1 ? `${amount}x Carta: ${cleanCardName}` : `Carta: ${cleanCardName}`;

        let cardImage = (reward.imageUrl && !reward.imageUrl.includes('default-card') && !reward.imageUrl.includes('icon-especiales'))
          ? reward.imageUrl
          : resolveRewardCardImage(reward);

        const badgeHtml = (amount > 1)
          ? `<div class="reward-amount-badge">${amount}</div>`
          : '';

        card.innerHTML = `<img src="${cardImage || './icon-especiales.png'}" alt="${cleanCardName}">${badgeHtml}`;

        // Si la imagen aún no estaba en caché síncrono, resolverla asíncronamente
        if (!cardImage && window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
          window.kvrcards.getAllCards().then(res => {
            const cards = Array.isArray(res) ? res : (Array.isArray(res?.cards) ? res.cards : (res ? Object.values(res) : []));
            rewardHudCatalogCache.cards = cards;
            const asyncImage = resolveRewardCardImage(reward, cards);
            if (asyncImage) {
              const imgEl = card.querySelector('img');
              if (imgEl) imgEl.src = asyncImage;
            }
          }).catch(() => {});
        }

        card.addEventListener('click', () => {
          if (selected) selected.textContent = displayName;
        });

      } else if (isBuff) {
        // ==================== BUFF DE KIZUNA ====================
        // Emoji de rayo ⚡ en lugar de imagen estática
        card.className = 'rewards-claim-item rewards-claim-item-buff';
        const cleanBuffName = String(reward.cleanName || reward.name || rawName).replace(/^(?:⚡|\s)*(?:buff)\s*:\s*/i, '').trim();
        const buffDesc = reward.description || reward.desc || '';
        const displayName = `⚡ Buff: ${cleanBuffName}`;

        card.innerHTML = `
          <div class="rewards-claim-buff-inner">
            <span class="rewards-claim-buff-emoji">⚡</span>
            <span class="rewards-claim-buff-label">${escapeHtml(cleanBuffName)}</span>
          </div>
        `;

        card.addEventListener('click', () => {
          if (selected) {
            selected.textContent = buffDesc ? `${displayName} (${buffDesc})` : displayName;
          }
        });

      } else if (isItem) {
        // ==================== OBJETO (ITEM) ====================
        card.className = 'rewards-claim-item rewards-claim-item-item';
        const cleanItemName = String(reward.cleanName || rawName).replace(/^(?:🎒|\s)*(?:objeto)\s*:\s*/i, '').trim();
        const displayName = amount > 1 ? `${amount}x Objeto: ${cleanItemName}` : `Objeto: ${cleanItemName}`;

        let itemImage = reward.imageUrl;
        if (!itemImage && typeof window.findItemInCatalog === 'function') {
          const it = window.findItemInCatalog(reward.itemId || reward.id || cleanItemName);
          if (it?.imageUrl) itemImage = it.imageUrl;
        }
        if (!itemImage) itemImage = './assets/default-item.png';

        const badgeHtml = (amount > 1)
          ? `<div class="reward-amount-badge">${amount}</div>`
          : '';

        card.innerHTML = `<img src="${itemImage}" alt="${cleanItemName}" onerror="this.src='./assets/default-item.png'">${badgeHtml}`;

        card.addEventListener('click', () => {
          if (selected) selected.textContent = displayName;
        });

      } else {
        // ==================== OTRAS RECOMPENSAS ====================
        card.className = 'rewards-claim-item';
        const image = getRewardImage(reward);
        const isCurrency = rawType === 'coins' || rawType === 'kvr' || rawName.toLowerCase().includes('coin') || rawName.toLowerCase().includes('kvr');

        const badgeHtml = (amount > 1 && !isCurrency)
          ? `<div class="reward-amount-badge">${amount}</div>`
          : '';

        card.innerHTML = `<img src="${image}" alt="${rawName}">${badgeHtml}`;
        card.addEventListener('click', () => {
          if (selected) selected.textContent = rawName;
        });
      }

      grid.appendChild(card);
    });
  }

  // Forzar reflow para que la animación siempre dispare desde cero
  overlay.classList.remove('show');
  void overlay.offsetHeight;
  requestAnimationFrame(() => {
    overlay.classList.add('show');
  });
}

window.showRewardsClaimHUD = showRewardsClaimHUD;

async function showUnifiedRewardsHUD(claimedRewards, title = 'RECOMPENSAS RECLAMADAS') {
  if (!Array.isArray(claimedRewards) || claimedRewards.length === 0) {
    console.warn('[REWARDS] No hay recompensas para mostrar en el HUD');
    return;
  }
  try {
    const hudRewards = await buildRewardsHudItems(claimedRewards);
    showRewardsClaimHUD(hudRewards, title);
  } catch (error) {
    console.error('[REWARDS] Error al mostrar HUD de recompensas unificado:', error);
  }
}
window.showUnifiedRewardsHUD = showUnifiedRewardsHUD;

async function grantPrestigeRewards(rewards = []) {
  const normRewards = (Array.isArray(rewards) ? rewards : [rewards])
    .map(normalizePrestigeRewardItem)
    .filter(Boolean);

  if (normRewards.length === 0) return;

  await ensureRewardHudCatalogCache();
  const allCards = Array.isArray(rewardHudCatalogCache.cards) ? rewardHudCatalogCache.cards : [];
  const allTitles = Array.isArray(rewardHudCatalogCache.titles) ? rewardHudCatalogCache.titles : (Array.isArray(window.availableTitles) ? window.availableTitles : []);

  let walletUpdated = false;
  let collectionUpdated = false;
  let titlesUpdated = false;

  for (const reward of normRewards) {
    const type = String(reward?.type || '').toLowerCase();
    const amount = Number(reward?.amount || reward?.cantidad || reward?.quantity || reward?.count || 1) || 1;

    try {
      if (type === 'coins') {
        if (window.kvrcards?.addCoins) {
          const res = await window.kvrcards.addCoins(amount);
          if (res?.ok) walletUpdated = true;
        } else if (window.userProfile) {
          window.userProfile.coins = (Number(window.userProfile.coins) || 0) + amount;
          walletUpdated = true;
          if (typeof saveUserProfile === 'function') await saveUserProfile();
        }
        console.log(`[PRESTIGE] [OK] +${amount} Coins otorgadas`);

      } else if (type === 'kvr') {
        if (window.kvrcards?.addKvR) {
          const res = await window.kvrcards.addKvR(amount);
          if (res?.ok) walletUpdated = true;
        } else if (window.userProfile) {
          window.userProfile.kvr = (Number(window.userProfile.kvr) || 0) + amount;
          walletUpdated = true;
          if (typeof saveUserProfile === 'function') await saveUserProfile();
        }
        console.log(`[PRESTIGE] [OK] +${amount} KvR otorgados`);

      } else if (type === 'traits' || type === 'trait') {
        let traitGiven = false;
        if (window.kvrcards?.addTraits) {
          const res = await window.kvrcards.addTraits(amount);
          if (res?.ok) {
            walletUpdated = true;
            traitGiven = true;
          }
        }
        if (!traitGiven && window.kvrcards?.debugModifyTraits) {
          const res = await window.kvrcards.debugModifyTraits(amount);
          if (res?.ok) {
            walletUpdated = true;
            traitGiven = true;
          }
        }
        if (!traitGiven) {
          if (window.userProfile) {
            window.userProfile.traits = (Number(window.userProfile.traits) || 0) + amount;
            walletUpdated = true;
            traitGiven = true;
            if (typeof saveUserProfile === 'function') await saveUserProfile();
          }
          try {
            const cur = Number(localStorage.getItem('kvr_wallet_traits')) || 0;
            localStorage.setItem('kvr_wallet_traits', String(cur + amount));
            walletUpdated = true;
            traitGiven = true;
          } catch {}
        }
        console.log(`[PRESTIGE] [OK] +${amount} Traits otorgados`);

      } else if (type === 'infinite-coins' || type === 'infinite-coin') {
        if (typeof window.infiniteAddCurrency === 'function') {
          window.infiniteAddCurrency('infinite-coins', amount);
        }
        console.log(`[PRESTIGE] [OK] +${amount} Infinite Coins otorgadas`);

      } else if (type === 'infinite-cardpoints' || type === 'infinite-cardpoint') {
        if (typeof window.infiniteAddCurrency === 'function') {
          window.infiniteAddCurrency('infinite-cardpoints', amount);
        }
        console.log(`[PRESTIGE] [OK] +${amount} Infinite Cardpoints otorgados`);

      } else if (type === 'pack' || type === 'packs') {
        const packId = String(reward?.packId || reward?.id || '').trim();
        if (packId) {
          if (window.kvrcards?.addPack) {
            const res = await window.kvrcards.addPack(packId, amount);
            if (res?.ok) walletUpdated = true;
          }
          console.log(`[PRESTIGE] [OK] Sobre ${packId} x${amount} otorgado`);
        }

      } else if (type === 'card') {
        const matchedCard = findCardInCatalog(reward, allCards);
        const cardId = matchedCard?.id || String(reward?.cardId || reward?.id || '').trim();
        if (cardId) {
          if (window.kvrcards?.addCard) {
            for (let i = 0; i < amount; i++) {
              await window.kvrcards.addCard(cardId);
            }
            collectionUpdated = true;
          } else {
            try {
              const stored = localStorage.getItem('kvr_owned_cards') || '{}';
              const inv = JSON.parse(stored);
              inv[cardId] = (inv[cardId] || 0) + amount;
              localStorage.setItem('kvr_owned_cards', JSON.stringify(inv));
              collectionUpdated = true;
            } catch {}
          }
          console.log(`[PRESTIGE] [OK] Carta ${cardId} (original: ${reward.cardId || cardId}) x${amount} otorgada`);
        }

      } else if (type === 'title') {
        const matchedTitle = findTitleInCatalog(reward, allTitles);
        const tId = matchedTitle?.id || String(reward?.titleId || reward?.id || '').trim();
        const tName = matchedTitle?.name || String(reward?.name || '').trim();

        let prof = window.userProfile;
        if (!prof && typeof userProfile !== 'undefined') prof = userProfile;
        if (!prof) {
          try {
            const stored = localStorage.getItem('kvr_user_profile') || localStorage.getItem('userProfile');
            if (stored) prof = JSON.parse(stored);
          } catch {}
        }
        if (!prof) prof = {};
        if (!Array.isArray(prof.unlockedTitles)) prof.unlockedTitles = ['novato'];

        let added = false;
        if (tId && !prof.unlockedTitles.includes(tId)) {
          prof.unlockedTitles.push(tId);
          added = true;
        }
        if (tName && !prof.unlockedTitles.includes(tName)) {
          prof.unlockedTitles.push(tName);
          added = true;
        }

        window.userProfile = prof;
        if (typeof userProfile !== 'undefined') userProfile = prof;

        try {
          if (typeof saveUserProfile === 'function') {
            await saveUserProfile();
          } else if (typeof window.saveUserProfile === 'function') {
            await window.saveUserProfile();
          } else {
            localStorage.setItem('kvr_user_profile', JSON.stringify(prof));
          }
          titlesUpdated = true;
          console.log(`[PRESTIGE] [OK] Título "${tName || tId}" (ID: ${tId}) desbloqueado con éxito`);
        } catch (e) {
          console.warn('[PRESTIGE] Error guardando título:', e);
        }

      } else if (type === 'background' || type === 'fondo') {
        const bgId = String(reward?.backgroundId || reward?.fondoId || reward?.id || '').trim();
        if (bgId) {
          if (typeof window.unlockProfileBackground === 'function') {
            await window.unlockProfileBackground(bgId);
          } else if (typeof unlockProfileBackground === 'function') {
            await unlockProfileBackground(bgId);
          } else if (window.userProfile) {
            if (!Array.isArray(window.userProfile.unlockedBackgrounds)) window.userProfile.unlockedBackgrounds = ['default'];
            if (!window.userProfile.unlockedBackgrounds.includes(bgId)) {
              window.userProfile.unlockedBackgrounds.push(bgId);
              if (typeof saveUserProfile === 'function') await saveUserProfile();
            }
          }
          console.log(`[PRESTIGE] [OK] Fondo de perfil ${bgId} desbloqueado`);
        }
      } else if (type === 'item' || type === 'items' || type === 'objeto' || type === 'objetos') {
        const itemId = String(reward?.itemId || reward?.id || reward?.item || '').trim();
        if (itemId) {
          if (window.kvrcards && typeof window.kvrcards.addItem === 'function') {
            await window.kvrcards.addItem(itemId, amount);
          }
          collectionUpdated = true;
          console.log(`[PRESTIGE] [OK] Objeto ${itemId} x${amount} otorgado`);
        }
      }
    } catch (err) {
      console.warn('[PRESTIGE] Error al otorgar recompensa:', reward, err);
    }
  }

  if (walletUpdated) {
    if (typeof renderWallet === 'function') renderWallet().catch(() => {});
    if (typeof renderOwnedPacks === 'function') renderOwnedPacks().catch(() => {});
    if (typeof renderTraitsPanel === 'function') renderTraitsPanel();
    if (typeof window.renderTraitsPanel === 'function') window.renderTraitsPanel();
  }
  if (collectionUpdated) {
    if (typeof renderCollection === 'function') renderCollection().catch(() => {});
  }
  if (titlesUpdated) {
    if (typeof updateProfileDisplay === 'function') updateProfileDisplay();
    if (typeof updateTitleSelector === 'function') updateTitleSelector();
    if (typeof renderTitles === 'function') renderTitles();
  }
}
window.grantPrestigeRewards = grantPrestigeRewards;

function renderPrestigeMissionsAndRewards(prestigePanel, prestigeData, config, card) {
  if (!prestigePanel) return;
  const missionsContainer = prestigePanel.querySelector('.inventory-prestige-missions-list');
  const giftsContainer = prestigePanel.querySelector('.inventory-prestige-gifts');
  const profile = resolvePrestigeProfile(config, card);
  const levels = Array.isArray(profile?.levels) ? profile.levels : [];
  const numericLevel = Math.max(0, Number(prestigeData?.level) || 0);
  const currentPrestigeForMissions = Math.max(1, numericLevel <= 0 ? 1 : numericLevel);
  const missionLevels = levels
    .filter((lvl) => (Number(lvl?.prestige) || 0) <= currentPrestigeForMissions)
    .sort((a, b) => (Number(a?.prestige) || 0) - (Number(b?.prestige) || 0));

  if (missionLevels.length === 0 && levels.length > 0) {
    missionLevels.push(levels[0]);
  }

  const refreshPrestigePanel = () => {
    const thresholds = getPrestigeThresholds(levels);
    const updatedPrestigeData = getInventoryPrestigeData(0, thresholds, card?.id);

    const currentLabel = prestigePanel.querySelector('.inventory-prestige-current-label');
    if (currentLabel) currentLabel.textContent = `Prestigio ${updatedPrestigeData.level}`;

    const xpLabel = prestigePanel.querySelector('.inventory-prestige-progress-header span:last-child');
    if (xpLabel) xpLabel.textContent = `${updatedPrestigeData.xp.toLocaleString('es-ES')} XP`;

    const fillLarge = prestigePanel.querySelector('.inventory-prestige-progress-fill');
    if (fillLarge) fillLarge.style.width = `${updatedPrestigeData.progress}%`;

    const fillTop = document.querySelector('.inventory-card-meta .inventory-prestige-bar-fill');
    if (fillTop) fillTop.style.width = `${updatedPrestigeData.progress}%`;

    const metaValue = document.querySelector('.inventory-card-meta-row.inventory-prestige-block .inventory-card-meta-value');
    if (metaValue) metaValue.textContent = `Prestigio ${updatedPrestigeData.level}`;

    const thresholdsText = prestigePanel.querySelector('.inventory-prestige-thresholds');
    if (thresholdsText) thresholdsText.textContent = `${updatedPrestigeData.thresholds.join(' | ')} XP`;

    renderPrestigeMissionsAndRewards(prestigePanel, updatedPrestigeData, config, card);
  };

  if (missionsContainer) {
    const stackedMissions = missionLevels.flatMap((lvl) => {
      const sourcePrestige = Number(lvl?.prestige) || 1;
      const levelMissions = Array.isArray(lvl?.missions) ? lvl.missions : [];
      return levelMissions.map((mission, idx) => ({
        mission,
        sourcePrestige,
        idx
      }));
    });

    if (stackedMissions.length === 0) {
      missionsContainer.classList.remove('stacked-scroll');
      missionsContainer.innerHTML = '<div class="inventory-prestige-mission-item">Sin misiones configuradas para este prestigio.</div>';
    } else {
      const cardProgress = getPrestigeProgressEntry(card?.id, false);
      const missionRows = stackedMissions
        .map(({ mission: m, sourcePrestige, idx }) => {
          const missionName = String(m?.name || m?.text || 'Mision sin nombre');
          const missionXp = Math.max(0, Number(m?.xp) || 0);
          const baseMissionId = String(m?.id || `mission_${idx + 1}`);
          const missionKey = `p${sourcePrestige}_${baseMissionId}`;
          const legacyClaimKey = m?.id ? String(m.id) : '';
          const claimed = isPrestigeMissionClaimed(card, missionKey, legacyClaimKey);
          const missionProgress = getMissionProgressForCard(m, cardProgress, card, missionKey);
          if (!missionProgress) {
            const keepVisible = sourcePrestige === currentPrestigeForMissions;
            if (!keepVisible) return '';
            return `
              <div class="inventory-prestige-mission-item">
                <span><span class="inventory-prestige-mission-level">P${sourcePrestige}</span>${missionName}</span>
                <span class="inventory-prestige-mission-counter">Sin progreso</span>
              </div>
            `;
          }

          const current = Math.min(missionProgress.current, missionProgress.target);
          const completed = current >= missionProgress.target;
          const canClaim = completed && !claimed;
          const keepVisible = sourcePrestige === currentPrestigeForMissions || !completed || !claimed;
          if (!keepVisible) return '';

          const statusText = claimed
            ? 'Reclamada'
            : (canClaim ? `Reclamar +${missionXp} XP` : `${current}/${missionProgress.target}`);

          return `
            <div class="inventory-prestige-mission-item">
              <span><span class="inventory-prestige-mission-level">P${sourcePrestige}</span>${missionName}${missionXp > 0 ? ` (+${missionXp} XP)` : ''}</span>
              ${canClaim
                ? `<button type="button" class="inventory-prestige-mission-claim" data-mission-id="${missionKey}" data-legacy-claim-key="${legacyClaimKey}" data-mission-xp="${missionXp}">${statusText}</button>`
                : `<span class="inventory-prestige-mission-counter ${claimed ? 'claimed' : ''}">${statusText}</span>`}
            </div>
          `;
        })
        .filter(Boolean);

      if (missionRows.length === 0) {
        missionsContainer.classList.remove('stacked-scroll');
        missionsContainer.innerHTML = '<div class="inventory-prestige-mission-item">No hay misiones pendientes en prestigios anteriores.</div>';
      } else {
        missionsContainer.classList.toggle('stacked-scroll', missionRows.length > 5);
        missionsContainer.innerHTML = missionRows.join('');
      }

      missionsContainer.querySelectorAll('.inventory-prestige-mission-claim').forEach((claimBtn) => {
        claimBtn.addEventListener('click', () => {
          const missionId = String(claimBtn.getAttribute('data-mission-id') || '').trim();
          const legacyClaimKey = String(claimBtn.getAttribute('data-legacy-claim-key') || '').trim();
          const missionXp = Math.max(0, Number(claimBtn.getAttribute('data-mission-xp')) || 0);
          if (!missionId || !card?.id) return;

          if (isPrestigeMissionClaimed(card, missionId, legacyClaimKey)) return;
          setPrestigeMissionClaimed(card, missionId, legacyClaimKey);

          const store = loadPrestigeProgressStore();
          const cardId = normalizePrestigeCardId(card.id);
          if (!cardId) return;

          const current = store[cardId] && typeof store[cardId] === 'object'
            ? store[cardId]
            : { battlesPlayed: 0, battlesWon: 0, roundsWon: 0, battleXp: 0, missionXp: 0, missionProgress: {} };

          current.battlesPlayed = Math.max(0, Number(current.battlesPlayed) || 0);
          current.battlesWon = Math.max(0, Number(current.battlesWon) || 0);
          current.roundsWon = Math.max(0, Number(current.roundsWon) || 0);
          current.battleXp = Math.max(0, Number(current.battleXp) || 0);
          current.missionXp = Math.max(0, Number(current.missionXp) || 0) + missionXp;
          current.updatedAt = Date.now();
          store[cardId] = current;

          // Sync to all variants of this character in store
          const charKey = getPrestigeCharacterKey(card);
          if (charKey) {
            Object.keys(store).forEach(k => {
              if (getPrestigeCharacterKey(k) === charKey) {
                store[k].missionXp = current.missionXp;
                store[k].updatedAt = Date.now();
              }
            });
          }

          savePrestigeProgressStore(store);

          refreshPrestigePanel();
          if (typeof window.updateCardPrestigeRewardBadge === 'function') {
            window.updateCardPrestigeRewardBadge(card?.id);
            if (charKey) {
              const siblings = getCharacterVariants(charKey);
              for (const sibId of siblings) {
                window.updateCardPrestigeRewardBadge(sibId);
              }
            }
          }
          if (typeof window.updateGlobalNotificationBadges === 'function') {
            window.updateGlobalNotificationBadges();
          }
        });
      });
    }
  }

  if (giftsContainer) {
    const closeGiftPreviewBubble = () => {
      giftsContainer.querySelectorAll('.inventory-prestige-gift-bubble').forEach((bubble) => bubble.remove());
      giftsContainer.dataset.previewPrestige = '';
    };

    if (window.__inventoryPrestigeGiftPreviewVisibilityHandler) {
      document.removeEventListener('visibilitychange', window.__inventoryPrestigeGiftPreviewVisibilityHandler);
    }
    window.__inventoryPrestigeGiftPreviewVisibilityHandler = () => {
      if (document.hidden) closeGiftPreviewBubble();
    };
    document.addEventListener('visibilitychange', window.__inventoryPrestigeGiftPreviewVisibilityHandler);

    let hoverTimeout = null;

    const renderGiftPreviewBubble = async (targetBtn, prestige, rawRewards = [], options = {}) => {
      if (!targetBtn || !giftsContainer) return;
      const claimedPreview = options?.claimed === true;
      const unlocked = options?.unlocked === true;

      closeGiftPreviewBubble();

      const bubble = document.createElement('div');
      bubble.className = 'inventory-prestige-gift-bubble';
      if (claimedPreview) bubble.classList.add('claimed-preview');
      else if (unlocked) bubble.classList.add('unlocked-preview');

      const bubbleTitle = document.createElement('div');
      bubbleTitle.className = 'inventory-prestige-gift-bubble-title';
      bubbleTitle.textContent = claimedPreview
        ? `Recompensa reclamada - Prestigio ${prestige}`
        : (unlocked ? `🎁 ¡Prestigio ${prestige} Desbloqueado! (Clic para reclamar)` : `Recompensas Prestigio ${prestige}`);
      bubble.appendChild(bubbleTitle);

      const bubbleGrid = document.createElement('div');
      bubbleGrid.className = 'inventory-prestige-gift-bubble-grid';

      const normRewards = (Array.isArray(rawRewards) ? rawRewards : [rawRewards])
        .map(normalizePrestigeRewardItem)
        .filter(Boolean);

      const items = await buildRewardsHudItems(normRewards);
      if (items.length === 0) {
        const emptyItem = document.createElement('div');
        emptyItem.className = 'inventory-prestige-gift-bubble-empty';
        emptyItem.textContent = 'Sin recompensas configuradas';
        bubbleGrid.appendChild(emptyItem);
      } else {
        items.forEach((item) => {
          const rewardBox = document.createElement('div');
          rewardBox.className = 'inventory-prestige-gift-bubble-item';

          if (item.type === 'title') {
            rewardBox.classList.add('inventory-prestige-gift-bubble-item-title');

            const crownEl = document.createElement('span');
            crownEl.className = 'inventory-prestige-gift-bubble-crown';
            crownEl.textContent = '👑';
            rewardBox.appendChild(crownEl);

            const infoWrap = document.createElement('div');
            infoWrap.className = 'inventory-prestige-gift-bubble-info inventory-prestige-gift-bubble-info-title';

            const typeTag = document.createElement('span');
            typeTag.className = 'inventory-prestige-gift-bubble-type-tag';
            typeTag.textContent = 'Título: ';
            infoWrap.appendChild(typeTag);

            const titleName = item.cleanTitle || String(item.name || 'Título').replace(/^Título:\s*/i, '');
            const nameSpan = document.createElement('span');
            nameSpan.className = 'inventory-prestige-gift-bubble-name inventory-prestige-gift-bubble-title-text';
            nameSpan.style.backgroundImage = item.gradient || 'linear-gradient(135deg, #fef3c7 0%, #facc15 50%, #d4af37 100%)';
            nameSpan.style.webkitBackgroundClip = 'text';
            nameSpan.style.backgroundClip = 'text';
            nameSpan.style.color = 'transparent';
            nameSpan.style.fontWeight = '800';
            nameSpan.textContent = titleName;
            infoWrap.appendChild(nameSpan);

            rewardBox.appendChild(infoWrap);

          } else if (item.type === 'card') {
            rewardBox.classList.add('inventory-prestige-gift-bubble-item-card');

            const rewardImg = document.createElement('img');
            rewardImg.className = 'inventory-prestige-gift-bubble-card-img';
            const cardImgSrc = (item.imageUrl && !item.imageUrl.includes('default-card'))
              ? item.imageUrl
              : (resolveRewardCardImage(item) || './icon-especiales.png');
            rewardImg.src = cardImgSrc;
            rewardImg.alt = String(item?.cleanName || item?.name || 'Carta');
            rewardBox.appendChild(rewardImg);

            const infoWrap = document.createElement('div');
            infoWrap.className = 'inventory-prestige-gift-bubble-info';

            const nameSpan = document.createElement('span');
            nameSpan.className = 'inventory-prestige-gift-bubble-name';
            const cleanName = item?.cleanName || String(item?.name || 'Carta').replace(/^(?:\d+x\s*)?Carta:\s*/i, '');
            const displayName = item?.amount > 1 ? `${item.amount}x Carta: ${cleanName}` : `Carta: ${cleanName}`;
            nameSpan.textContent = displayName;
            infoWrap.appendChild(nameSpan);

            const quality = item?.quality || item?.card?.calidad || item?.card?.quality;
            if (quality) {
              const qBadge = document.createElement('span');
              qBadge.className = `inventory-prestige-gift-bubble-quality-badge quality-${String(quality).toLowerCase()}`;
              qBadge.textContent = String(quality).toUpperCase();
              infoWrap.appendChild(qBadge);
            }

            rewardBox.appendChild(infoWrap);

          } else if (item.type === 'buff') {
            rewardBox.classList.add('inventory-prestige-gift-bubble-item-buff');

            const buffIcon = document.createElement('span');
            buffIcon.className = 'inventory-prestige-gift-bubble-crown';
            buffIcon.textContent = '⚡';
            rewardBox.appendChild(buffIcon);

            const infoWrap = document.createElement('div');
            infoWrap.className = 'inventory-prestige-gift-bubble-info';

            const nameSpan = document.createElement('span');
            nameSpan.className = 'inventory-prestige-gift-bubble-name';
            nameSpan.textContent = String(item?.name || 'Buff');
            infoWrap.appendChild(nameSpan);

            rewardBox.appendChild(infoWrap);

          } else {
            const rewardImg = document.createElement('img');
            rewardImg.src = String(item?.imageUrl || (item.type === 'kvr' ? './kvr.png' : './coin.png'));
            rewardImg.alt = String(item?.name || 'Recompensa');
            rewardBox.appendChild(rewardImg);

            const infoWrap = document.createElement('div');
            infoWrap.className = 'inventory-prestige-gift-bubble-info';

            const nameSpan = document.createElement('span');
            nameSpan.className = 'inventory-prestige-gift-bubble-name';
            nameSpan.textContent = String(item?.name || 'Recompensa');
            infoWrap.appendChild(nameSpan);

            rewardBox.appendChild(infoWrap);
          }

          bubbleGrid.appendChild(rewardBox);
        });
      }

      bubble.appendChild(bubbleGrid);
      giftsContainer.appendChild(bubble);

      const targetRect = targetBtn.getBoundingClientRect();
      const giftsRect = giftsContainer.getBoundingClientRect();
      const targetCenter = (targetRect.left - giftsRect.left) + (targetRect.width / 2);

      bubble.style.left = `${targetCenter}px`;

      const halfWidth = bubble.offsetWidth / 2;
      const minCenter = Math.max(halfWidth + 8, 8);
      const maxCenter = Math.max(minCenter, giftsRect.width - halfWidth - 8);
      const clampedCenter = Math.max(minCenter, Math.min(targetCenter, maxCenter));
      bubble.style.left = `${clampedCenter}px`;
      giftsContainer.dataset.previewPrestige = String(prestige);

      requestAnimationFrame(() => {
        bubble.classList.add('show');
      });
    };

    const total = Math.max(1, levels.length);
    giftsContainer.innerHTML = levels.map((lvl, idx) => {
      const prestige = Number(lvl?.prestige) || idx + 1;
      const unlocked = prestigeData.xp >= (Number(lvl?.xpRequired) || 0);
      const claimed = isPrestigeLevelRewardClaimed(card, prestige);
      const left = ((idx + 1) / total) * 100;
      const stateClass = claimed ? 'claimed' : (unlocked ? 'unlocked' : 'locked');
      return `<button type="button" class="inventory-prestige-gift ${stateClass}" data-prestige="${prestige}" style="left:${left}%;" title="Prestigio ${prestige}">🎁</button>`;
    }).join('');

    giftsContainer.querySelectorAll('.inventory-prestige-gift').forEach((btn) => {
      const prestige = Number(btn.getAttribute('data-prestige')) || 0;
      const level = levels.find(l => Number(l?.prestige) === prestige);
      if (!level) return;

      const xpRequired = Number(level?.xpRequired) || 0;
      const rawRewards = extractPrestigeLevelRewards(level);
      const unlocked = prestigeData.xp >= xpRequired;

      const isClaimed = () => isPrestigeLevelRewardClaimed(card, prestige);

      // Hover: al pasar el ratón por encima del regalo sale el recuadro con las recompensas
      btn.addEventListener('mouseenter', () => {
        clearTimeout(hoverTimeout);
        renderGiftPreviewBubble(btn, prestige, rawRewards, {
          claimed: isClaimed(),
          unlocked
        });
      });

      btn.addEventListener('mouseleave', () => {
        clearTimeout(hoverTimeout);
        hoverTimeout = setTimeout(() => {
          const cur = Number(giftsContainer.dataset.previewPrestige || 0);
          if (cur === prestige) {
            closeGiftPreviewBubble();
          }
        }, 150);
      });

      btn.addEventListener('click', async () => {
        const alreadyClaimed = isClaimed();

        if (unlocked && !alreadyClaimed) {
          closeGiftPreviewBubble();

          setPrestigeLevelRewardClaimed(card, prestige);
          btn.classList.remove('unlocked');
          btn.classList.add('claimed');

          if (typeof window.updateCardPrestigeRewardBadge === 'function') {
            window.updateCardPrestigeRewardBadge(card?.id);
            const charKey = getPrestigeCharacterKey(card);
            if (charKey) {
              const siblings = getCharacterVariants(charKey);
              for (const sibId of siblings) {
                window.updateCardPrestigeRewardBadge(sibId);
              }
            }
          }
          if (typeof window.updateGlobalNotificationBadges === 'function') {
            window.updateGlobalNotificationBadges();
          }

          // ✅ Mostrar HUD INMEDIATAMENTE: buildRewardsHudItems usa caché en memoria, no hace fetch
          buildRewardsHudItems(rawRewards).then(hudRewards => {
            showRewardsClaimHUD(hudRewards, 'RECOMPENSAS RECLAMADAS');
          }).catch(() => {
            // Fallback síncrono si falla el caché
            showRewardsClaimHUD(rawRewards.map(r => ({
              ...r,
              name: String(r.name || (r.amount && `${r.amount} ${r.type}`) || 'Recompensa'),
              amount: Number(r.amount || 1)
            })), 'RECOMPENSAS RECLAMADAS');
          });
          // Otorgar recompensas en background
          grantPrestigeRewards(rawRewards).catch(e => console.warn('[PRESTIGE] Error otorgando recompensas:', e));
          return;
        }

        const currentPreviewPrestige = Number(giftsContainer.dataset.previewPrestige || 0);
        if (currentPreviewPrestige === prestige) {
          closeGiftPreviewBubble();
          return;
        }

        try {
          await renderGiftPreviewBubble(btn, prestige, rawRewards, {
            claimed: alreadyClaimed,
            unlocked
          });
        } catch {}
      });
    });
  }
}

async function applyDuplicatePrestigeXp(receivedCardsCount = {}, inventoryBefore = {}) {
  const entries = Object.entries(receivedCardsCount || {}).filter(([cardId, qty]) => String(cardId).trim() && Number(qty) > 0);
  if (entries.length === 0) return;

  try {
    if (typeof ensureRewardHudCatalogCache === 'function') {
      await ensureRewardHudCatalogCache();
    }
  } catch (_) {}

  const cfg = await getPrestigeConfig();
  const store = loadPrestigeProgressStore();
  let anyApplied = false;

  entries.forEach(([rawCardId, qtyRaw]) => {
    const cardId = normalizePrestigeCardId(rawCardId);
    const gained = Math.max(0, Number(qtyRaw) || 0);
    if (!cardId || gained <= 0) return;

    const beforeCount = Math.max(0, Number((inventoryBefore || {})[cardId]) || 0);
    const afterCount = beforeCount + gained;

    const duplicatesBefore = Math.max(0, beforeCount - 1);
    const duplicatesAfter = Math.max(0, afterCount - 1);
    const newDuplicates = Math.max(0, duplicatesAfter - duplicatesBefore);
    if (newDuplicates <= 0) return;

    const profile = resolvePrestigeProfile(cfg, { id: cardId });
    const xpRules = profile?.xpRules || defaultPrestigeConfig.xpRules;
    const duplicateXpPerCopy = getDuplicatePrestigeXp({ id: cardId }, xpRules);
    if (duplicateXpPerCopy <= 0) return;

    const current = store[cardId] && typeof store[cardId] === 'object'
      ? store[cardId]
      : { battlesPlayed: 0, battlesWon: 0, roundsWon: 0, battleXp: 0, missionXp: 0, missionProgress: {} };

    current.battlesPlayed = Math.max(0, Number(current.battlesPlayed) || 0);
    current.battlesWon = Math.max(0, Number(current.battlesWon) || 0);
    current.roundsWon = Math.max(0, Number(current.roundsWon) || 0);
    current.missionXp = Math.max(0, Number(current.missionXp) || 0);
    current.battleXp = Math.max(0, Number(current.battleXp) || 0) + (newDuplicates * duplicateXpPerCopy);
    current.updatedAt = Date.now();

    store[cardId] = current;

    // Sync to all variants of this character in store
    const charKey = getPrestigeCharacterKey(cardId);
    if (charKey) {
      Object.keys(store).forEach(k => {
        if (getPrestigeCharacterKey(k) === charKey) {
          store[k].battlesPlayed = current.battlesPlayed;
          store[k].battlesWon = current.battlesWon;
          store[k].roundsWon = current.roundsWon;
          store[k].battleXp = current.battleXp;
          store[k].missionXp = current.missionXp;
          store[k].updatedAt = Date.now();
        }
      });
    }

    anyApplied = true;
  });

  if (anyApplied) {
    savePrestigeProgressStore(store);
    if (typeof window.updateGlobalNotificationBadges === 'function') {
      window.updateGlobalNotificationBadges();
    }
  }
}

function getInventoryPrestigeData(inventoryCount, thresholds = PRESTIGE_XP_THRESHOLDS, cardId = null) {
  const baseXp = 0;
  const cardProgress = cardId ? getPrestigeProgressEntry(cardId, false) : null;
  const xp = baseXp
    + Math.max(0, Number(cardProgress?.battleXp) || 0)
    + Math.max(0, Number(cardProgress?.missionXp) || 0);

  const validThresholds = Array.isArray(thresholds) && thresholds.length > 0
    ? thresholds.map(v => Number(v) || 0).filter(v => v > 0)
    : [...PRESTIGE_XP_THRESHOLDS];

  let level = 0;
  for (let i = 0; i < validThresholds.length; i += 1) {
    if (xp >= validThresholds[i]) level = i + 1;
  }

  const segmentCount = Math.max(1, validThresholds.length);
  let progress = 0;
  if (xp >= validThresholds[segmentCount - 1]) {
    progress = 100;
  } else {
    let prev = 0;
    for (let i = 0; i < segmentCount; i += 1) {
      const current = validThresholds[i];
      if (xp < current) {
        const segmentRange = Math.max(1, current - prev);
        const segmentProgress = Math.max(0, Math.min(1, (xp - prev) / segmentRange));
        progress = ((i + segmentProgress) / segmentCount) * 100;
        break;
      }
      prev = current;
    }
  }

  return {
    level,
    progress,
    xp,
    thresholds: validThresholds,
    baseXp,
    battlesPlayed: Math.max(0, Number(cardProgress?.battlesPlayed) || 0),
    battlesWon: Math.max(0, Number(cardProgress?.battlesWon) || 0),
    roundsWon: Math.max(0, Number(cardProgress?.roundsWon) || 0)
  };
}

window.getInventoryPrestigeData = getInventoryPrestigeData;
window.getMissionProgressForCard = getMissionProgressForCard;
window.getPrestigeMissionClaimKey = getPrestigeMissionClaimKey;
window.getPrestigeProgressEntry = getPrestigeProgressEntry;
window.loadPrestigeProgressStore = loadPrestigeProgressStore;
window.resolvePrestigeProfile = resolvePrestigeProfile;
window.getPrestigeThresholds = getPrestigeThresholds;
window.isPrestigeLevelRewardClaimed = isPrestigeLevelRewardClaimed;
window.setPrestigeLevelRewardClaimed = setPrestigeLevelRewardClaimed;
window.isPrestigeMissionClaimed = isPrestigeMissionClaimed;
window.setPrestigeMissionClaimed = setPrestigeMissionClaimed;
window.clearPrestigeClaimsForCharacter = clearPrestigeClaimsForCharacter;
window.getPrestigeCharacterKey = getPrestigeCharacterKey;
window.recordPrestigeRoundWon = recordPrestigeRoundWon;
window.normalizePrestigeCardId = normalizePrestigeCardId;

function applyAdminPrestigeUpdate(pu) {
  if (!pu || !pu.cardId) return;
  const normalizedId = normalizePrestigeCardId(pu.cardId);
  if (!normalizedId) return;
  const store = loadPrestigeProgressStore() || {};
  if (pu.type === 'reset-prestige') {
    delete store[normalizedId];
    const charKey = getPrestigeCharacterKey(normalizedId);
    if (charKey) {
      const siblings = getCharacterVariants(charKey);
      for (let i = 0; i < siblings.length; i++) delete store[siblings[i]];
      if (typeof clearPrestigeClaimsForCharacter === 'function') {
        clearPrestigeClaimsForCharacter(charKey);
      }
    }
  } else {
    const cur = store[normalizedId] || {};
    const newXp = Math.max(0, Number(pu.xp || pu.battleXp) || 0);
    store[normalizedId] = {
      ...cur,
      cardId: normalizedId,
      battleXp: newXp,
      updatedAt: Date.now()
    };
    const charKey = getPrestigeCharacterKey(normalizedId);
    if (charKey) {
      const siblings = getCharacterVariants(charKey);
      for (let i = 0; i < siblings.length; i++) {
        const s = siblings[i];
        const sCur = store[s] || {};
        store[s] = {
          ...sCur,
          cardId: s,
          battleXp: newXp,
          updatedAt: Date.now()
        };
      }
    }
  }
  savePrestigeProgressStore(store);
  invalidatePrestigeCache();
  if (typeof window.updateGlobalNotificationBadges === 'function') {
    window.updateGlobalNotificationBadges();
  }
  if (typeof renderCollection === 'function') {
    renderCollection();
  }
}

function mergeRemotePrestigeProgress(remotePrestige) {
  if (!remotePrestige || typeof remotePrestige !== 'object') return;
  const store = loadPrestigeProgressStore() || {};
  let changed = false;
  for (const [cardId, rEntry] of Object.entries(remotePrestige)) {
    if (!rEntry || typeof rEntry !== 'object') continue;
    const nId = normalizePrestigeCardId(cardId);
    if (!nId) continue;
    const cur = store[nId] || {};
    const rXp = Math.max(0, Number(rEntry.battleXp || rEntry.xp) || 0);
    const curXp = Math.max(0, Number(cur.battleXp) || 0);
    if (rXp > curXp) {
      store[nId] = {
        ...cur,
        cardId: nId,
        battleXp: rXp,
        updatedAt: Math.max(Number(cur.updatedAt) || 0, Number(rEntry.updatedAt) || 0, Date.now())
      };
      changed = true;
    }
  }
  if (changed) {
    savePrestigeProgressStore(store);
    invalidatePrestigeCache();
    if (typeof window.updateGlobalNotificationBadges === 'function') {
      window.updateGlobalNotificationBadges();
    }
    if (typeof renderCollection === 'function') {
      renderCollection();
    }
  }
}

window.applyAdminPrestigeUpdate = applyAdminPrestigeUpdate;
window.mergeRemotePrestigeProgress = mergeRemotePrestigeProgress;


