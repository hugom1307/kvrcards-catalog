// ==========================================================================
// SISTEMA DE EVENTOS ESPECIALES (special-events.js)
// Basado en Propuesta de Estructura de Eventos (Mundos, Progresión, Tienda & Servidor)
// ==========================================================================

(function () {
  'use strict';

  // Configuración de endpoints remotos centralizados en GitHub (sin seeds locales)
  const REMOTE_CONFIG_URLS = [
    `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/special-events.json?t=${Date.now()}`,
    `https://hugom1307.github.io/kvrcards-catalog/special-events.json?t=${Date.now()}`
  ];

  const REMOTE_SHOP_CONFIG_URLS = [
    `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/special-event-shop.json?t=${Date.now()}`,
    `https://hugom1307.github.io/kvrcards-catalog/special-event-shop.json?t=${Date.now()}`
  ];

  const REMOTE_TITLES_URLS = [
    `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/titles.json?t=${Date.now()}`,
    `https://hugom1307.github.io/kvrcards-catalog/titles.json?t=${Date.now()}`
  ];

  const INVENTORY_SERVER_URL = 'https://kvrcards-server.onrender.com';

  let cachedSpecialEventsConfig = null;
  let cachedSpecialEventShopConfig = null;
  let cachedTitlesCatalog = null;
  let currentActiveWorldId = null;
  let currentShopFilterCategory = 'all';

  // Estado del usuario en memoria
  let userSpecialEventsData = {
    worlds: {},
    shopPurchases: {}
  };

  const KNOWN_ITEM_IMAGES = {
    'sombrero_sospechoso': 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/sombrero_sospechoso.png',
    'deseo': 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/deseo.png',
    'alma_del_sol': 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Alma_del_Sol.png',
    'capa_baryon_yang': 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Capa_Baryon_Yang.png',
    'capa_baryon_ying': 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Capa_Baryon_Ying.png',
    'octava_puerta': 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Octava_Puerta.png',
    'pergamino_elemental_agua': 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Pergamino_elemental_agua.png',
    'pergamino_elemental_fuego': 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Pergamino_elemental_fuego.png',
    'pergamino_elemental_rayo': 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/Pergamino_elemental_rayo.png',
    'bankakyo_byakugan': 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/bankaikio_byakugan.png',
    'puertas_internas': 'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/puertasinternas.png'
  };

  function safeParseJson(rawText) {
    if (typeof rawText !== 'string') return rawText;
    try {
      return JSON.parse(rawText);
    } catch (err) {
      // 1. Limpieza inicial: BOM y comentarios
      let cleaned = rawText.replace(/^\uFEFF/, '');
      cleaned = cleaned.replace(/\/\*[\s\S]*?\*\/|([^\\:]|^)\/\/.*$/gm, '$1');

      // 2. Auto-reparación inteligente de comas faltantes habituales en JSONs editados a mano:
      // Coma faltante entre objetos: } \n { -> }, \n {
      cleaned = cleaned.replace(/}\s*(\r?\n\s*[{])/g, '},\n$1');
      // Coma faltante entre objeto y propiedad o cadena: } \n " -> }, \n "
      cleaned = cleaned.replace(/}\s*(\r?\n\s*")/g, '},\n$1');
      // Coma faltante entre arrays: ] \n [ o ] \n " -> ], \n
      cleaned = cleaned.replace(/]\s*(\r?\n\s*[{"])/g, '],\n$1');
      // Coma faltante entre cadenas: " \n " -> ", \n "
      cleaned = cleaned.replace(/"\s*(\r?\n\s*")/g, '",\n$1');
      // Coma faltante tras números o booleanos: 1 \n " o true \n " -> 1, \n "
      cleaned = cleaned.replace(/(\d+|true|false|null)\s*(\r?\n\s*[{"])/g, '$1,\n$2');

      // 3. Limpieza de comas dobles y comas sobrantes antes de ] o }
      let prev;
      do {
        prev = cleaned;
        cleaned = cleaned.replace(/,\s*([\]}])/g, '$1');
        cleaned = cleaned.replace(/,\s*,/g, ',');
      } while (cleaned !== prev);

      try {
        const parsed = JSON.parse(cleaned);
        console.log('[SPECIAL-EVENTS] JSON reparado y parseado con éxito tras fallo inicial de sintaxis');
        return parsed;
      } catch (secondErr) {
        console.warn('[SPECIAL-EVENTS] Error parseando JSON remoto:', secondErr.message);
        return null;
      }
    }
  }

  function getActiveUsername() {
    if (typeof currentUser === 'string' && currentUser.trim() && currentUser.trim() !== 'Jugador') {
      return currentUser.trim();
    }
    const kvr = localStorage.getItem('kvrUsername');
    if (kvr && kvr.trim() && kvr.trim() !== 'Jugador') return kvr.trim();
    const raw = localStorage.getItem('username');
    if (raw && raw.trim() && raw.trim() !== 'Jugador') return raw.trim();
    return 'guest';
  }

  function getProgressStorageKey() {
    const user = getActiveUsername();
    return `kvr_special_events_progress_${user}`;
  }

  // --------------------------------------------------------------------------
  // PERSISTENCIA EN SERVIDOR Y LOCALSTORAGE
  // --------------------------------------------------------------------------
  function loadLocalProgressCache() {
    try {
      const raw = localStorage.getItem(getProgressStorageKey());
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
          // Soporte formato antiguo { mundoId: { ... } } vs nuevo { worlds: {}, shopPurchases: {} }
          if (parsed.worlds || parsed.shopPurchases) {
            userSpecialEventsData.worlds = parsed.worlds || {};
            userSpecialEventsData.shopPurchases = parsed.shopPurchases || {};
          } else {
            userSpecialEventsData.worlds = parsed;
            userSpecialEventsData.shopPurchases = {};
          }
        }
      }
    } catch (e) {
      console.warn('[SPECIAL-EVENTS] Error cargando caché local:', e);
    }
  }

  function saveLocalProgressCache() {
    try {
      localStorage.setItem(getProgressStorageKey(), JSON.stringify(userSpecialEventsData));
    } catch (e) {
      console.warn('[SPECIAL-EVENTS] Error guardando caché local:', e);
    }
  }

  async function syncUserProgressWithServer() {
    loadLocalProgressCache();
    const username = getActiveUsername();
    if (!username || username === 'guest') return;

    // 1. Intentar cargar desde el servidor (IPC o HTTP)
    let remoteData = null;
    if (window.kvrcards && typeof window.kvrcards.loadSpecialEventsProgress === 'function') {
      try {
        const res = await window.kvrcards.loadSpecialEventsProgress();
        if (res && res.ok) remoteData = res;
      } catch (err) {
        console.warn('[SPECIAL-EVENTS] IPC load error:', err);
      }
    }

    if (!remoteData) {
      try {
        const res = await fetch(`${INVENTORY_SERVER_URL}/api/special-events/progress/${encodeURIComponent(username)}?t=${Date.now()}`);
        if (res.ok) {
          remoteData = await res.json();
        }
      } catch (err) {
        // Modo offline
      }
    }

    if (remoteData && remoteData.ok) {
      const serverWorlds = remoteData.progress || {};
      const serverShop = remoteData.shopPurchases || {};

      // Mergear mundos (preservando el nivel más alto alcanzado)
      const mergedWorlds = { ...userSpecialEventsData.worlds };
      for (const [wId, sData] of Object.entries(serverWorlds)) {
        if (!mergedWorlds[wId]) {
          mergedWorlds[wId] = sData;
        } else {
          const localW = mergedWorlds[wId];
          const highestUnlocked = Math.max(Number(localW.highestUnlocked) || 1, Number(sData.highestUnlocked) || 1);
          const completedLevels = Array.from(new Set([
            ...(Array.isArray(localW.completedLevels) ? localW.completedLevels : []),
            ...(Array.isArray(sData.completedLevels) ? sData.completedLevels : [])
          ]));
          const mergedCounts = { ...(localW.levelClearCounts || {}) };
          if (sData.levelClearCounts) {
            for (const [lvlId, cnt] of Object.entries(sData.levelClearCounts)) {
              mergedCounts[lvlId] = Math.max(Number(mergedCounts[lvlId]) || 0, Number(cnt) || 0);
            }
          }
          mergedWorlds[wId] = {
            ...localW,
            ...sData,
            highestUnlocked,
            completedLevels,
            levelClearCounts: mergedCounts
          };
        }
      }

      // Mergear compras de la tienda
      const mergedShop = { ...userSpecialEventsData.shopPurchases };
      for (const [itemId, count] of Object.entries(serverShop)) {
        mergedShop[itemId] = Math.max(Number(mergedShop[itemId]) || 0, Number(count) || 0);
      }

      userSpecialEventsData.worlds = mergedWorlds;
      userSpecialEventsData.shopPurchases = mergedShop;
      saveLocalProgressCache();
      console.log('[SPECIAL-EVENTS] Progreso sincronizado exitosamente con el servidor');
    }
  }

  async function saveUserProgressToServer() {
    saveLocalProgressCache();
    const username = getActiveUsername();
    if (!username || username === 'guest') return;

    const payload = {
      progress: userSpecialEventsData.worlds,
      shopPurchases: userSpecialEventsData.shopPurchases
    };

    if (window.kvrcards && typeof window.kvrcards.saveSpecialEventsProgress === 'function') {
      try {
        const res = await window.kvrcards.saveSpecialEventsProgress(payload);
        if (res && res.ok) return;
      } catch (err) {
        console.warn('[SPECIAL-EVENTS] IPC save error:', err);
      }
    }

    try {
      await fetch(`${INVENTORY_SERVER_URL}/api/special-events/progress/${encodeURIComponent(username)}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } catch (err) {
      console.warn('[SPECIAL-EVENTS] HTTP save error:', err);
    }
  }

  function getWorldProgress(worldId) {
    if (!userSpecialEventsData.worlds[worldId]) {
      userSpecialEventsData.worlds[worldId] = {
        highestUnlocked: 1, // El primer nivel siempre está desbloqueado por defecto
        completedLevels: [],
        levelClearCounts: {}
      };
    }
    return userSpecialEventsData.worlds[worldId];
  }

  function isLevelUnlocked(worldId, levelNumber) {
    const wp = getWorldProgress(worldId);
    const highest = Number(wp.highestUnlocked) || 1;
    return Number(levelNumber) <= highest;
  }

  function isLevelCompleted(worldId, levelId) {
    const wp = getWorldProgress(worldId);
    return Array.isArray(wp.completedLevels) && wp.completedLevels.includes(levelId);
  }

  function getLevelClearCount(worldId, levelId) {
    const wp = getWorldProgress(worldId);
    return Number(wp.levelClearCounts?.[levelId]) || 0;
  }

  async function recordSpecialEventLevelVictory(worldId, levelId, levelNumber) {
    if (!worldId || !levelId) return;
    const wp = getWorldProgress(worldId);
    if (!Array.isArray(wp.completedLevels)) wp.completedLevels = [];
    if (!wp.levelClearCounts) wp.levelClearCounts = {};

    if (!wp.completedLevels.includes(levelId)) {
      wp.completedLevels.push(levelId);
    }

    const curHighest = Number(wp.highestUnlocked) || 1;
    const num = Number(levelNumber) || 1;
    if (num >= curHighest) {
      wp.highestUnlocked = num + 1;
      console.log(`[SPECIAL-EVENTS] ¡Desbloqueado nivel ${num + 1} para el mundo ${worldId}!`);
    }

    wp.levelClearCounts[levelId] = (Number(wp.levelClearCounts[levelId]) || 0) + 1;
    await saveUserProgressToServer();
  }

  // --------------------------------------------------------------------------
  // CARGA REMOTA DE CONFIGURACIÓN DEL EVENTO (special-events.json)
  // --------------------------------------------------------------------------
  async function loadSpecialEventsConfig(forceRefresh = false) {
    if (!forceRefresh && cachedSpecialEventsConfig) {
      return cachedSpecialEventsConfig;
    }

    for (const url of REMOTE_CONFIG_URLS) {
      try {
        const resp = await fetch(url, { cache: 'no-store' });
        if (resp.ok) {
          const text = await resp.text();
          const parsed = safeParseJson(text);
          const rawEvent = parsed?.event || parsed?.evento || parsed;
          if (rawEvent && Array.isArray(rawEvent.worlds || rawEvent.mundos)) {
            console.log(`[SPECIAL-EVENTS] Configuración de evento cargada desde: ${url}`);
            cachedSpecialEventsConfig = {
              version: parsed.version || 1,
              event: normalizeEventData(rawEvent)
            };
            return cachedSpecialEventsConfig;
          }
        }
      } catch (err) {
        console.warn(`[SPECIAL-EVENTS] Error cargando desde ${url}:`, err.message);
      }
    }

    console.warn('[SPECIAL-EVENTS] No se pudo obtener la configuración remota de special-events.json');
    return null;
  }

  function normalizeEventData(raw) {
    const worlds = Array.isArray(raw.worlds || raw.mundos) ? (raw.worlds || raw.mundos) : [];

    return {
      id: raw.id || 'special_event_1',
      name: raw.name || raw.nombre || 'Eventos Especiales',
      subtitle: raw.subtitle || raw.subtitulo || '',
      description: raw.description || raw.descripcion || 'Supera los niveles de cada mundo para obtener recompensas.',
      backgroundImage: raw.backgroundImage || raw.fondo || '',
      worlds: worlds.map((w, wIdx) => {
        const rawLevels = Array.isArray(w.levels || w.niveles) ? (w.levels || w.niveles) : [];
        return {
          id: w.id || `mundo_${wIdx + 1}`,
          name: w.name || w.nombre || `Mundo ${wIdx + 1}`,
          description: w.description || w.descripcion || '',
          image: w.image || w.imagen || '',
          backgroundImage: w.backgroundImage || w.fondo || '',
          materialItemId: w.materialItemId || w.materialId || 'material_evento_base',
          materialName: w.materialName || 'Material de Evento',
          levels: rawLevels.map((lvl, lIdx) => {
            const rawFirstRewards = lvl.firstClearRewards || lvl.firstTimeRewards || lvl.recompensasPrimeraVez || lvl.rewards || lvl.recompensas || [];
            const rawRepeatRewards = lvl.repeatRewards || lvl.repeatClearRewards || lvl.recompensasRepetir || lvl.farmRewards || [];

            return {
              id: lvl.id || `${w.id || 'mundo'}_nivel_${lIdx + 1}`,
              levelNumber: Number(lvl.levelNumber || lvl.nivel || (lIdx + 1)),
              name: lvl.name || lvl.nombre || `Nivel ${lIdx + 1}`,
              description: lvl.description || lvl.descripcion || '',
              image: lvl.image || lvl.imagen || '',
              bossCardId: lvl.bossCardId || lvl.boss || null,
              firstClearRewards: Array.isArray(rawFirstRewards) ? rawFirstRewards : [],
              repeatRewards: Array.isArray(rawRepeatRewards) ? rawRepeatRewards : []
            };
          })
        };
      })
    };
  }

  // --------------------------------------------------------------------------
  // RENDERIZADO DE MUNDOS Y NIVELES (PUNTOS 1 Y 2)
  // --------------------------------------------------------------------------
  async function renderWorldsView() {
    const panel = document.getElementById('special-events-panel');
    if (!panel) return;

    currentActiveWorldId = null;

    const config = await loadSpecialEventsConfig();
    const event = config?.event;

    // Actualizar fondo si existe
    if (event?.backgroundImage) {
      panel.style.setProperty('--special-panel-bg', `url('${event.backgroundImage}')`);
    } else {
      panel.style.setProperty('--special-panel-bg', 'none');
    }

    const titleEl = document.getElementById('special-events-main-title') || document.getElementById('special-events-title');
    if (titleEl) {
      titleEl.textContent = event?.name || 'EVENTOS ESPECIALES';
    }

    const descEl = document.getElementById('special-events-main-desc') || document.getElementById('special-events-desc');
    if (descEl) {
      const parts = [];
      if (event?.subtitle) parts.push(event.subtitle);
      if (event?.description) parts.push(event.description);
      descEl.textContent = parts.length > 0 ? parts.join(' — ') : 'Selecciona un mundo para explorar y avanzar en sus niveles.';
    }

    // Ocultar barra de navegación si existiese
    const worldNav = document.getElementById('special-events-world-nav');
    if (worldNav) worldNav.style.display = 'none';

    // Mostrar vista de mundos y ocultar vista de niveles
    const worldsView = document.getElementById('special-events-worlds-view') || document.getElementById('special-events-worlds-container');
    const levelsView = document.getElementById('special-events-levels-view') || document.getElementById('special-events-levels-container');
    if (worldsView) worldsView.style.display = 'block';
    if (levelsView) levelsView.style.display = 'none';

    const worldsGrid = document.getElementById('special-events-worlds-grid');
    if (!worldsGrid) return;
    worldsGrid.innerHTML = '';

    const worlds = event?.worlds || [];
    if (worlds.length === 0) {
      worldsGrid.innerHTML = '<p style="color:#94a3b8; grid-column: 1 / -1; text-align:center;">No hay mundos disponibles en este evento actualmente.</p>';
      return;
    }

    worlds.forEach((world) => {
      const card = document.createElement('div');
      card.className = 'special-world-card';

      const wp = getWorldProgress(world.id);
      const levels = world.levels || [];
      const totalLevels = levels.length;
      const completedCount = levels.filter((lvl) => isLevelCompleted(world.id, lvl.id)).length;
      const progressPercent = totalLevels > 0 ? Math.round((completedCount / totalLevels) * 100) : 0;

      const bgStyle = world.image ? `background-image: url('${world.image}');` : '';

      card.innerHTML = `
        <div class="special-world-card-banner" style="${bgStyle}">
          ${world.image ? `<img src="${world.image}" alt="${escapeHtml(world.name)}" class="special-world-card-banner-img" />` : ''}
          <div class="special-world-card-banner-overlay"></div>
          <div class="special-world-card-badge">${totalLevels} Niveles</div>
        </div>
        <div class="special-world-info">
          <h3 class="special-world-title">${escapeHtml(world.name)}</h3>
          <p class="special-world-desc">${escapeHtml(world.description || '')}</p>
          <div class="special-world-progress-bar-wrap">
            <div class="special-world-progress-bar-fill" style="width: ${progressPercent}%;"></div>
          </div>
          <div class="special-world-progress-text">
            <span>Progreso</span>
            <span>${completedCount}/${totalLevels} Superados (${progressPercent}%)</span>
          </div>
          <button type="button" class="special-world-action-btn">Entrar al Mundo</button>
        </div>
      `;

      const enterBtn = card.querySelector('.special-world-action-btn');
      if (enterBtn) {
        enterBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          openWorldLevels(world.id);
        });
      }

      card.addEventListener('click', () => {
        openWorldLevels(world.id);
      });

      worldsGrid.appendChild(card);
    });
  }

  async function openWorldLevels(worldId) {
    currentActiveWorldId = worldId;

    const config = await loadSpecialEventsConfig();
    const event = config?.event;
    const world = (event?.worlds || []).find((w) => w.id === worldId);

    if (!world) {
      console.warn(`[SPECIAL-EVENTS] No se encontró el mundo con id: ${worldId}`);
      renderWorldsView();
      return;
    }

    const panel = document.getElementById('special-events-panel');
    if (panel) {
      const bg = world.backgroundImage || world.image || event?.backgroundImage;
      if (bg) {
        panel.style.setProperty('--special-panel-bg', `url('${bg}')`);
      }
    }

    // Actualizar título y descripción del mundo en la vista de niveles
    const currentWorldTitle = document.getElementById('special-world-levels-title') || document.getElementById('special-events-current-world-title');
    if (currentWorldTitle) {
      currentWorldTitle.textContent = world.name;
    }

    const currentWorldDesc = document.getElementById('special-world-levels-desc') || document.getElementById('special-events-current-world-desc');
    if (currentWorldDesc) {
      currentWorldDesc.textContent = world.description || 'Desafíos de nivel progresivos';
    }

    // Ocultar mundos y mostrar vista de niveles
    const worldsView = document.getElementById('special-events-worlds-view') || document.getElementById('special-events-worlds-container');
    const levelsView = document.getElementById('special-events-levels-view') || document.getElementById('special-events-levels-container');
    if (worldsView) worldsView.style.display = 'none';
    if (levelsView) levelsView.style.display = 'block';

    const levelsGrid = document.getElementById('special-levels-grid') || document.getElementById('special-events-levels-grid');
    if (!levelsGrid) {
      console.warn('[SPECIAL-EVENTS] Contenedor de niveles no encontrado');
      return;
    }
    levelsGrid.innerHTML = '';

    const levels = world.levels || [];
    if (levels.length === 0) {
      levelsGrid.innerHTML = '<p style="color:#94a3b8; grid-column: 1 / -1; text-align:center;">No hay niveles configurados para este mundo.</p>';
      return;
    }

    levels.forEach((lvl, idx) => {
      const levelNumber = Number(lvl.levelNumber || (idx + 1));
      const unlocked = isLevelUnlocked(world.id, levelNumber);
      const completed = isLevelCompleted(world.id, lvl.id);
      const clearCount = getLevelClearCount(world.id, lvl.id);

      const box = document.createElement('div');
      let statusClass = 'locked';
      if (completed) {
        statusClass = 'completed';
      } else if (unlocked) {
        statusClass = 'unlocked';
      }

      box.className = `special-level-box ${statusClass}`;

      let statusBadge = '';
      if (completed) {
        statusBadge = `<div class="special-level-badge completed">Completado (x${clearCount})</div>`;
      } else if (unlocked) {
        statusBadge = '<div class="special-level-badge unlocked">Disponible</div>';
      } else {
        statusBadge = '<div class="special-level-badge locked">Bloqueado</div>';
      }

      box.innerHTML = `
        <div class="special-level-number-circle">${levelNumber}</div>
        ${statusBadge}
        <h4 class="special-level-title">${escapeHtml(lvl.name)}</h4>
        <p class="special-level-desc">${escapeHtml(lvl.description)}</p>
        <div class="special-level-actions">
          <button type="button" class="special-level-rewards-btn">Ver Recompensas</button>
          <button type="button" class="special-level-play-btn" ${!unlocked ? 'disabled' : ''}>
            ${completed ? 'Rejugar' : (unlocked ? 'Desafiar' : 'Bloqueado')}
          </button>
        </div>
      `;

      const rewardsBtn = box.querySelector('.special-level-rewards-btn');
      if (rewardsBtn) {
        rewardsBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          openLevelRewardsModal(world, lvl);
        });
      }

      const playBtn = box.querySelector('.special-level-play-btn');
      if (playBtn && unlocked) {
        playBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          startSpecialEventBattle(world, lvl);
        });
      }

      levelsGrid.appendChild(box);
    });
  }

  // Helper para resolver icono y nombre legible de recompensa
  function resolveRewardDisplay(reward) {
    const type = String(reward.type || reward.tipo || 'item').toLowerCase();
    const amount = Number(reward.amount || reward.cantidad || 1);
    let name = reward.name || reward.nombre || '';
    let icon = reward.icon || reward.image || reward.imageUrl || './icon-especiales.png';

    if (type === 'coins') {
      name = name || 'Monedas Coins';
      icon = './coin.png';
    } else if (type === 'traits') {
      name = name || 'Puntos Trait';
      icon = './trait.png';
    } else if (type === 'kvr') {
      name = name || 'Moneda KvR';
      icon = './kvr.png';
    } else if (type === 'pack' || type === 'packs' || type === 'sobre') {
      const packId = reward.packId || reward.id || '';
      name = name || `Sobre: ${packId.replace(/_/g, ' ')}`;
      if (!reward.icon && !reward.image) {
        icon = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${packId}.png`;
      }
    } else if (type === 'card' || type === 'carta') {
      const cardId = reward.cardId || reward.id || '';
      name = name || `Carta: ${cardId.replace(/_/g, ' ')}`;
      if (!reward.icon && !reward.image) {
        icon = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${cardId}.png`;
      }
    } else if (type === 'item' || type === 'items' || type === 'objeto') {
      const itemId = reward.itemId || reward.id || '';
      const itemData = (typeof window.findItemInCatalog === 'function')
        ? window.findItemInCatalog(itemId || reward)
        : null;
      if (itemData) {
        name = name || itemData.name || itemData.nombre;
        icon = itemData.image || itemData.imageUrl || itemData.imagen || icon;
      }
      name = name || `Objeto: ${itemId.replace(/_/g, ' ')}`;
      if (!reward.icon && !reward.image && (!itemData || (!itemData.image && !itemData.imageUrl))) {
        icon = KNOWN_ITEM_IMAGES[itemId] || KNOWN_ITEM_IMAGES[itemId.toLowerCase()] || `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/${itemId}.png`;
      }
    } else if (type === 'title' || type === 'titulo') {
      const titleId = reward.titleId || reward.id || '';
      name = name || `Título: ${titleId.replace(/_/g, ' ')}`;
      icon = './icon-especiales.png';
    }

    const rawProb = reward.probability ?? reward.prob ?? reward.probabilidad;
    let prob = 100;
    let isGuaranteed = true;
    if (rawProb !== undefined && rawProb !== null) {
      let p = Number(rawProb);
      if (p <= 1 && p > 0) p = p * 100;
      prob = p;
      if (prob < 100) {
        isGuaranteed = false;
      }
    }

    return { type, name, amount, icon, isGuaranteed, probability: prob };
  }

  // --------------------------------------------------------------------------
  // MODAL DE RECOMPENSAS: PRIMERA VEZ VS REPETICIÓN
  // --------------------------------------------------------------------------
  function openLevelRewardsModal(world, level) {
    const modal = document.getElementById('special-event-rewards-modal');
    if (!modal) return;

    const titleEl = document.getElementById('special-event-rewards-modal-title');
    if (titleEl) {
      titleEl.textContent = `Recompensas: ${level.name}`;
    }

    const body = document.getElementById('special-event-rewards-modal-body');
    if (!body) return;
    body.innerHTML = '';

    const isCompleted = isLevelCompleted(world.id, level.id);

    // SECCIÓN 1: RECOMPENSAS PRIMERA VICTORIA
    const firstSection = document.createElement('div');
    firstSection.className = 'special-rewards-section first-clear';

    const firstHeader = document.createElement('div');
    firstHeader.className = 'special-rewards-section-header';
    firstHeader.innerHTML = `
      <h4 class="special-rewards-section-title">⭐ Recompensas de Primera Victoria</h4>
      ${isCompleted
        ? '<span class="special-rewards-section-badge claimed">✓ Ya Reclamada</span>'
        : '<span class="special-rewards-section-badge active">⭐ Recompensa Única</span>'}
    `;
    firstSection.appendChild(firstHeader);

    const firstRewards = level.firstClearRewards || [];
    if (firstRewards.length === 0) {
      firstSection.innerHTML += '<div class="special-rewards-empty-note">Sin recompensas de primera victoria configuradas.</div>';
    } else {
      firstRewards.forEach((r) => {
        const info = resolveRewardDisplay(r);
        firstSection.appendChild(createRewardRowElement(info));
      });
    }
    body.appendChild(firstSection);

    // SECCIÓN 2: RECOMPENSAS POR REPETICIÓN (FARMEO)
    const repeatSection = document.createElement('div');
    repeatSection.className = 'special-rewards-section repeat';

    const repeatHeader = document.createElement('div');
    repeatHeader.className = 'special-rewards-section-header';
    repeatHeader.innerHTML = `
      <h4 class="special-rewards-section-title">🔁 Recompensas por Repetición (Farmeo)</h4>
      ${isCompleted
        ? '<span class="special-rewards-section-badge active">🔥 Recompensas Activas</span>'
        : '<span class="special-rewards-section-badge pending">🔒 Se activan tras superarlo 1 vez</span>'}
    `;
    repeatSection.appendChild(repeatHeader);

    const repeatRewards = level.repeatRewards || [];
    if (repeatRewards.length === 0) {
      repeatSection.innerHTML += '<div class="special-rewards-empty-note">No hay recompensas repetibles para este nivel.</div>';
    } else {
      repeatRewards.forEach((r) => {
        const info = resolveRewardDisplay(r);
        repeatSection.appendChild(createRewardRowElement(info));
      });
    }
    body.appendChild(repeatSection);

    modal.style.display = 'flex';
  }

  function createRewardRowElement(info) {
    const row = document.createElement('div');
    row.className = 'special-reward-row';

    let badgeHtml = '';
    if (info.isGuaranteed) {
      badgeHtml = '<span class="special-reward-chance-pill guaranteed">100% Asegurada</span>';
    } else if (info.probability <= 5) {
      badgeHtml = `<span class="special-reward-chance-pill rare">🔥 ${info.probability}% Drop Raro</span>`;
    } else {
      badgeHtml = `<span class="special-reward-chance-pill probabilistic">${info.probability}% Probabilidad</span>`;
    }

    row.innerHTML = `
      <div class="special-reward-left">
        <div class="special-reward-icon-box">
          <img src="${escapeHtml(info.icon)}" alt="${escapeHtml(info.name)}" class="special-reward-icon-img" onerror="this.src='./icon-especiales.png'" />
        </div>
        <div class="special-reward-details">
          <span class="special-reward-name">${escapeHtml(info.name)}</span>
          <span class="special-reward-amount">Cantidad: x${info.amount.toLocaleString('es-ES')}</span>
        </div>
      </div>
      ${badgeHtml}
    `;
    return row;
  }

  function closeLevelRewardsModal() {
    const modal = document.getElementById('special-event-rewards-modal');
    if (modal) modal.style.display = 'none';
  }

  // --------------------------------------------------------------------------
  // GESTIÓN DE TÍTULOS Y CATÁLOGO DE TÍTULOS (titles.json)
  // --------------------------------------------------------------------------
  async function ensureTitlesCatalog() {
    if (Array.isArray(cachedTitlesCatalog) && cachedTitlesCatalog.length > 0) {
      return cachedTitlesCatalog;
    }

    // 1. Array global en memoria
    if (Array.isArray(window.availableTitles) && window.availableTitles.length > 0) {
      cachedTitlesCatalog = window.availableTitles;
      return cachedTitlesCatalog;
    }

    // 2. window.loadTitles si está disponible en profile.js
    if (typeof window.loadTitles === 'function') {
      try {
        const loaded = await window.loadTitles();
        if (Array.isArray(loaded) && loaded.length > 0) {
          cachedTitlesCatalog = loaded;
          return cachedTitlesCatalog;
        }
      } catch (e) {}
    }

    // 3. Electron IPC
    if (window.kvrcards && typeof window.kvrcards.getTitles === 'function') {
      try {
        const res = await window.kvrcards.getTitles();
        if (res && res.ok && Array.isArray(res.titles) && res.titles.length > 0) {
          cachedTitlesCatalog = res.titles;
          window.availableTitles = res.titles;
          return cachedTitlesCatalog;
        }
      } catch (e) {}
    }

    // 4. Catálogo remoto en GitHub
    for (const url of REMOTE_TITLES_URLS) {
      try {
        const resp = await fetch(url, { cache: 'no-store' });
        if (resp.ok) {
          const list = await resp.json();
          if (Array.isArray(list) && list.length > 0) {
            cachedTitlesCatalog = list;
            window.availableTitles = list;
            return cachedTitlesCatalog;
          }
        }
      } catch (e) {}
    }

    // 5. Fallback local a seeds
    try {
      const resp = await fetch('./seeds/titles.json');
      if (resp.ok) {
        const list = await resp.json();
        if (Array.isArray(list) && list.length > 0) {
          cachedTitlesCatalog = list;
          window.availableTitles = list;
          return cachedTitlesCatalog;
        }
      }
    } catch (e) {}

    return cachedTitlesCatalog || [];
  }

  function findTitleInCatalog(identifier, catalog = []) {
    if (!identifier) return null;
    const clean = String(identifier).trim().toLowerCase();
    // 1. Coincidencia por ID exacta o insensible
    let match = catalog.find((t) => t && String(t.id).toLowerCase() === clean);
    if (match) return match;

    // 2. Coincidencia por nombre (ignorando mayúsculas, comillas, emojis)
    const strippedClean = typeof window.stripTitleFormatting === 'function'
      ? window.stripTitleFormatting(clean).toLowerCase()
      : clean;

    match = catalog.find((t) => {
      if (!t) return false;
      const tName = String(t.name || '').trim().toLowerCase();
      const strippedTName = typeof window.stripTitleFormatting === 'function'
        ? window.stripTitleFormatting(tName).toLowerCase()
        : tName;
      return tName === clean || (strippedClean && strippedTName === strippedClean);
    });
    return match || null;
  }

  function formatTitleGradientSafe(text, gradient) {
    if (!text) return '';
    if (typeof window.formatTitleWithGradient === 'function') {
      return window.formatTitleWithGradient(text, gradient);
    }
    if (!gradient) return escapeHtml(text);
    return `<span style="background-image:${gradient};-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;color:transparent;">${escapeHtml(text)}</span>`;
  }

  function isTitleUnlockedByPlayer(titleId, titleName) {
    let unlocked = null;
    if (window.userProfile && Array.isArray(window.userProfile.unlockedTitles)) {
      unlocked = window.userProfile.unlockedTitles;
    } else {
      try {
        const stored = localStorage.getItem('kvr_user_profile') || localStorage.getItem('userProfile');
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed?.unlockedTitles)) unlocked = parsed.unlockedTitles;
        }
      } catch (e) {}
    }
    if (!Array.isArray(unlocked) || unlocked.length === 0) return false;

    const cleanId = String(titleId || '').trim().toLowerCase();
    const cleanName = String(titleName || '').trim().toLowerCase();
    const strippedName = typeof window.stripTitleFormatting === 'function'
      ? window.stripTitleFormatting(cleanName).toLowerCase()
      : cleanName;

    return unlocked.some((t) => {
      const s = String(t || '').trim().toLowerCase();
      const strippedS = typeof window.stripTitleFormatting === 'function'
        ? window.stripTitleFormatting(s).toLowerCase()
        : s;
      return (cleanId && s === cleanId) || (cleanName && s === cleanName) || (strippedName && strippedS === strippedName);
    });
  }

  // --------------------------------------------------------------------------
  // TIENDA DEL EVENTO REMOTA (special-event-shop.json) CON CONTROL DE STOCK
  // --------------------------------------------------------------------------
  const SHOP_CATEGORY_LABELS = {
    all: 'Todos',
    card: 'Cartas',
    pack: 'Sobres',
    title: 'Títulos',
    item: 'Objetos / Evolución',
    coins: 'Monedas',
    traits: 'Rasgos'
  };

  function normalizeShopData(raw, titlesCatalog = []) {
    if (!raw) return { currencies: [], items: [] };

    const rawCurrencies = Array.isArray(raw.currencies || raw.monedas || raw.materiales)
      ? (raw.currencies || raw.monedas || raw.materiales)
      : [];

    const rawItems = Array.isArray(raw.items || raw.articulos || raw.shop || raw.tienda)
      ? (raw.items || raw.articulos || raw.shop || raw.tienda)
      : [];

    const currencies = rawCurrencies.map((c, idx) => ({
      id: c.id || `currency_${idx + 1}`,
      name: c.name || c.nombre || 'Material de Evento',
      description: c.description || c.descripcion || '',
      icon: c.icon || c.image || c.icono || c.imagen || './icon-especiales.png'
    }));

    const extractStock = (it, defaultVal) => {
      const rawVal = it.stock ?? it.limit ?? it.limite ?? it.maxPurchases ?? it.maxCompras ?? it.max ?? it.existencias ?? it.stockLimit;
      if (rawVal === undefined || rawVal === null || rawVal === '') return defaultVal;
      const num = Number(rawVal);
      return isNaN(num) ? defaultVal : Math.max(0, num);
    };

    const items = rawItems.map((item, idx) => {
      const rawCost = item.cost || item.costo || {};
      const costCurrencyId = rawCost.currencyId || rawCost.itemId || rawCost.id || 'material_evento';
      const costCurrencyName = rawCost.name || rawCost.nombre || '';
      const costAmount = Number(rawCost.amount || rawCost.cantidad || 1);

      const rawReward = item.reward || item.recompensa || {};

      // Detección automática de categoría si no viene explícita
      let category = String(item.category || item.categoria || rawReward.type || rawReward.tipo || '').toLowerCase();
      if (!category) {
        if (item.titleId || item.tituloId || rawReward.titleId || rawReward.tituloId) {
          category = 'title';
        } else if (item.cardId || item.cartaId || rawReward.cardId) {
          category = 'card';
        } else if (item.packId || item.sobreId || rawReward.packId) {
          category = 'pack';
        } else if (item.traits !== undefined || rawReward.traits !== undefined || rawReward.type === 'traits' || rawReward.type === 'trait') {
          category = 'traits';
        } else if (item.itemId || item.objetoId || rawReward.itemId) {
          category = 'item';
        } else if (item.coins !== undefined || rawReward.coins !== undefined || rawReward.type === 'coins' || rawReward.type === 'coin') {
          category = 'coins';
        } else {
          category = 'item';
        }
      }
      if (category === 'titulo') category = 'title';
      if (category === 'carta') category = 'card';
      if (category === 'sobre') category = 'pack';
      if (category === 'objeto' || category === 'material') category = 'item';
      if (category === 'monedas' || category === 'coin') category = 'coins';
      if (category === 'rasgos' || category === 'rasgo' || category === 'trait' || category === 'traits') category = 'traits';

      const isTitle = category === 'title';

      // ==================== 1. CATEGORÍA TÍTULO ====================
      if (isTitle) {
        const rawTitleId = item.titleId || item.tituloId || rawReward.titleId || rawReward.tituloId || item.id || rawReward.id || '';
        const titleMatch = findTitleInCatalog(rawTitleId || item.name, titlesCatalog);

        const targetTitleId = titleMatch?.id || rawTitleId || `title_${idx + 1}`;
        const titleName = item.name || item.nombre || titleMatch?.name || (rawTitleId ? String(rawTitleId).replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase()) : 'Título de Evento');
        const titleDesc = item.description || item.descripcion || titleMatch?.description || titleMatch?.unlockDescription || 'Título exclusivo de evento';
        const titleGradient = item.gradient || item.gradiente || titleMatch?.gradient || 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)';
        const stock = extractStock(item, 1);

        const rewardPayload = {
          ...rawReward,
          type: 'title',
          titleId: targetTitleId,
          id: targetTitleId,
          name: titleName,
          cleanTitle: titleName,
          gradient: titleGradient,
          amount: 1
        };

        return {
          id: item.id || `shop_title_${targetTitleId}`,
          titleId: targetTitleId,
          name: titleName,
          description: titleDesc,
          gradient: titleGradient,
          category: 'title',
          image: '', // Sin imagen para títulos: se muestra su gradiente
          stock,
          cost: {
            currencyId: costCurrencyId,
            name: costCurrencyName,
            amount: costAmount
          },
          reward: rewardPayload
        };
      }

      // ==================== 2. OTRAS CATEGORÍAS ====================
      const stock = extractStock(item, 0);
      let rewardPayload = { ...rawReward };

      if (category === 'card') {
        const cardId = item.cardId || rawReward.cardId || rawReward.id || item.id;
        const cardName = item.name || rawReward.name || cardId;
        const cardImg = item.image || item.icon || rawReward.imageUrl || rawReward.image || `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${cardId}.png`;
        rewardPayload = {
          ...rawReward,
          type: 'card',
          cardId: cardId,
          id: cardId,
          name: cardName,
          imageUrl: cardImg,
          amount: Number(rawReward.amount || item.amount || 1)
        };
      } else if (category === 'pack') {
        const packId = item.packId || rawReward.packId || rawReward.id || item.id;
        const packName = item.name || rawReward.name || `Sobre ${packId}`;
        const packImg = item.image || item.icon || rawReward.imageUrl || rawReward.image || `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${packId}.png`;
        rewardPayload = {
          ...rawReward,
          type: 'pack',
          packId: packId,
          id: packId,
          name: packName,
          imageUrl: packImg,
          amount: Number(rawReward.amount || item.amount || 1)
        };
      } else if (category === 'item') {
        const itemId = item.itemId || rawReward.itemId || rawReward.id || item.id;
        const itemName = item.name || rawReward.name || itemId;
        const itemImg = item.image || item.icon || rawReward.imageUrl || rawReward.image || `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/${itemId}.png`;
        rewardPayload = {
          ...rawReward,
          type: 'item',
          itemId: itemId,
          id: itemId,
          name: itemName,
          imageUrl: itemImg,
          amount: Number(rawReward.amount || item.amount || 1)
        };
      } else if (category === 'coins') {
        const coinAmount = Number(rawReward.amount || item.amount || item.coins || 1000);
        rewardPayload = {
          ...rawReward,
          type: 'coins',
          amount: coinAmount,
          name: rawReward.name || item.name || `${coinAmount.toLocaleString('es-ES')} Coins`,
          imageUrl: './coin.png'
        };
      } else if (category === 'traits') {
        const traitAmount = Number(rawReward.amount || item.amount || item.traits || 1);
        rewardPayload = {
          ...rawReward,
          type: 'traits',
          amount: traitAmount,
          name: rawReward.name || item.name || `${traitAmount.toLocaleString('es-ES')} Rasgos`,
          imageUrl: './trait.png'
        };
      }

      let defaultImage = './icon-especiales.png';
      if (category === 'traits' || rewardPayload.type === 'traits' || rewardPayload.type === 'trait') {
        defaultImage = './trait.png';
      } else if (category === 'coins' || rewardPayload.type === 'coins' || rewardPayload.type === 'coin') {
        defaultImage = './coin.png';
      }

      const itemImg = item.image || item.icon || item.imagen || item.icono || rewardPayload.imageUrl || defaultImage;

      return {
        id: item.id || `shop_item_${idx + 1}`,
        name: item.name || item.nombre || rewardPayload.name || 'Artículo de Evento',
        description: item.description || item.descripcion || '',
        category,
        image: itemImg,
        stock,
        cost: {
          currencyId: costCurrencyId,
          name: costCurrencyName,
          amount: costAmount
        },
        reward: rewardPayload
      };
    });

    return {
      version: raw.version || 1,
      eventId: raw.eventId || 'evento_especial',
      title: raw.title || raw.titulo || 'Tienda del Evento',
      description: raw.description || raw.descripcion || '',
      currencies,
      items
    };
  }

  async function loadSpecialEventShopConfig(forceRefresh = false) {
    if (!forceRefresh && cachedSpecialEventShopConfig) {
      return cachedSpecialEventShopConfig;
    }

    const titlesCatalog = await ensureTitlesCatalog();

    for (const url of REMOTE_SHOP_CONFIG_URLS) {
      try {
        const resp = await fetch(url, { cache: 'no-store' });
        if (resp.ok) {
          const text = await resp.text();
          const parsed = safeParseJson(text);
          if (parsed && (Array.isArray(parsed.items) || Array.isArray(parsed.currencies))) {
            console.log(`[SPECIAL-EVENTS-SHOP] Tienda remota cargada desde: ${url}`);
            cachedSpecialEventShopConfig = normalizeShopData(parsed, titlesCatalog);
            return cachedSpecialEventShopConfig;
          }
        }
      } catch (err) {
        console.warn(`[SPECIAL-EVENTS-SHOP] Error cargando tienda desde ${url}:`, err.message);
      }
    }

    console.warn('[SPECIAL-EVENTS-SHOP] No se pudo cargar special-event-shop.json remoto');
    return null;
  }

  // Helpers para consultar/consumir items en inventario (Divisas de Evento)
  async function getPlayerItemCount(itemId) {
    if (!itemId) return 0;
    const cleanId = String(itemId).trim();

    // 1. Inventario de Objetos en Electron IPC (ownedItems sincronizado)
    if (window.kvrcards && typeof window.kvrcards.getItemsInventory === 'function') {
      try {
        const res = await window.kvrcards.getItemsInventory();
        if (res && res.items && typeof res.items === 'object') {
          if (res.items[cleanId] !== undefined) {
            return Number(res.items[cleanId]) || 0;
          }
          const lower = cleanId.toLowerCase();
          const foundKey = Object.keys(res.items).find((k) => k.toLowerCase() === lower);
          if (foundKey && res.items[foundKey] !== undefined) {
            return Number(res.items[foundKey]) || 0;
          }
        }
      } catch (e) {}
    }

    // 2. Caché local en localStorage (kvr_user_items)
    try {
      const raw = localStorage.getItem('kvr_user_items');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
          if (parsed[cleanId] !== undefined) return Number(parsed[cleanId]) || 0;
          const lower = cleanId.toLowerCase();
          const foundKey = Object.keys(parsed).find((k) => k.toLowerCase() === lower);
          if (foundKey && parsed[foundKey] !== undefined) return Number(parsed[foundKey]) || 0;
        }
      }
    } catch {}

    // 3. Objeto en memoria userProfile.items
    if (window.userProfile?.items && typeof window.userProfile.items === 'object') {
      if (window.userProfile.items[cleanId] !== undefined) {
        return Number(window.userProfile.items[cleanId]) || 0;
      }
      const lower = cleanId.toLowerCase();
      const foundKey = Object.keys(window.userProfile.items).find((k) => k.toLowerCase() === lower);
      if (foundKey && window.userProfile.items[foundKey] !== undefined) {
        return Number(window.userProfile.items[foundKey]) || 0;
      }
    }

    // 4. Divisas del sistema general en caso de reutilizar coins, traits o kvr
    const lowerId = cleanId.toLowerCase();
    if (lowerId === 'coins' || lowerId === 'coin') {
      return Number(window.userProfile?.coins ?? localStorage.getItem('kvr_wallet_coins') ?? 0) || 0;
    }
    if (lowerId === 'traits' || lowerId === 'trait') {
      return Number(window.userProfile?.traits ?? localStorage.getItem('kvr_wallet_traits') ?? 0) || 0;
    }
    if (lowerId === 'kvr') {
      return Number(window.userProfile?.kvr ?? localStorage.getItem('kvr_wallet_kvr') ?? 0) || 0;
    }

    return 0;
  }

  async function consumePlayerItem(itemId, amount) {
    if (!itemId || amount <= 0) return false;
    const cleanId = String(itemId).trim();
    let consumed = false;

    // 1. IPC de Electron
    if (window.kvrcards && typeof window.kvrcards.consumeItem === 'function') {
      try {
        const res = await window.kvrcards.consumeItem(cleanId, amount);
        if (res && res.ok) consumed = true;
      } catch (e) {}
    }

    // 2. LocalStorage y memoria
    try {
      const raw = localStorage.getItem('kvr_user_items') || '{}';
      const parsed = JSON.parse(raw);
      const targetKey = parsed[cleanId] !== undefined
        ? cleanId
        : Object.keys(parsed).find((k) => k.toLowerCase() === cleanId.toLowerCase()) || cleanId;

      const cur = Number(parsed[targetKey]) || 0;
      if (cur >= amount) {
        parsed[targetKey] = cur - amount;
        if (parsed[targetKey] <= 0) delete parsed[targetKey];
        localStorage.setItem('kvr_user_items', JSON.stringify(parsed));
        consumed = true;
      }
    } catch {}

    if (window.userProfile?.items && typeof window.userProfile.items === 'object') {
      const targetKey = window.userProfile.items[cleanId] !== undefined
        ? cleanId
        : Object.keys(window.userProfile.items).find((k) => k.toLowerCase() === cleanId.toLowerCase()) || cleanId;
      const cur = Number(window.userProfile.items[targetKey]) || 0;
      if (cur >= amount) {
        window.userProfile.items[targetKey] = cur - amount;
        if (window.userProfile.items[targetKey] <= 0) delete window.userProfile.items[targetKey];
      }
    }

    // 3. Fallback de divisas estándar
    const lowerId = cleanId.toLowerCase();
    if (!consumed) {
      if (lowerId === 'coins' && window.kvrcards?.consumeCoins) {
        const r = await window.kvrcards.consumeCoins(amount);
        if (r?.ok) consumed = true;
      } else if (lowerId === 'traits' && window.kvrcards?.consumeTraits) {
        const r = await window.kvrcards.consumeTraits(amount);
        if (r?.ok) consumed = true;
      } else if (lowerId === 'kvr' && window.kvrcards?.consumeKvR) {
        const r = await window.kvrcards.consumeKvR(amount);
        if (r?.ok) consumed = true;
      }
    }

    return consumed;
  }

  async function openSpecialEventsShop() {
    const modal = document.getElementById('special-events-shop-modal');
    if (!modal) return;

    modal.style.display = 'flex';

    await syncUserProgressWithServer();

    const shopConfig = await loadSpecialEventShopConfig(true);
    if (!shopConfig) {
      console.warn('[SPECIAL-EVENTS-SHOP] Configuración de tienda no disponible');
      return;
    }

    const titleEl = document.getElementById('special-events-shop-modal-title');
    if (titleEl && shopConfig.title) {
      titleEl.textContent = shopConfig.title;
    }

    await renderShopContents(shopConfig);
  }

  async function renderShopContents(shopConfig) {
    const materialsBar = document.getElementById('special-shop-materials-list');
    const tabsContainer = document.getElementById('special-shop-filter-tabs');
    const grid = document.getElementById('special-shop-items-grid');

    const currencies = shopConfig.currencies || [];
    const items = shopConfig.items || [];

    // 1. Obtener balance de monedas del jugador
    const currencyBalances = {};
    for (const curr of currencies) {
      currencyBalances[curr.id] = await getPlayerItemCount(curr.id);
    }

    const currencyMap = {};
    currencies.forEach((c) => {
      currencyMap[c.id] = c;
    });

    // 2. Renderizar píldoras de materiales/currencies
    if (materialsBar) {
      materialsBar.innerHTML = '';
      if (currencies.length === 0) {
        materialsBar.innerHTML = '<span style="color:#94a3b8; font-size:0.85rem;">No hay divisas registradas.</span>';
      } else {
        currencies.forEach((curr) => {
          const balance = currencyBalances[curr.id] || 0;
          const pill = document.createElement('div');
          pill.className = 'special-shop-material-pill';
          pill.title = curr.description ? `${curr.description} (Click para ampliar)` : `${curr.name} (Click para ampliar)`;
          pill.style.cursor = 'pointer';
          pill.innerHTML = `
            <img src="${escapeHtml(curr.icon)}" alt="${escapeHtml(curr.name)}" onerror="this.src='./icon-especiales.png'" style="cursor:zoom-in;" />
            <span>${escapeHtml(curr.name)}: <strong>${balance.toLocaleString('es-ES')}</strong></span>
          `;
          pill.addEventListener('click', () => {
            openSpecialShopImagePreview(curr.icon, curr.name, curr.description || '');
          });
          materialsBar.appendChild(pill);
        });
      }
    }

    // 3. Renderizar pestañas de categorías
    if (tabsContainer) {
      tabsContainer.innerHTML = '';
      const availableCategories = ['all'];
      items.forEach((item) => {
        if (item.category && !availableCategories.includes(item.category)) {
          availableCategories.push(item.category);
        }
      });

      availableCategories.forEach((cat) => {
        const tabBtn = document.createElement('button');
        tabBtn.type = 'button';
        tabBtn.className = `special-shop-filter-tab ${cat === currentShopFilterCategory ? 'active' : ''}`;
        tabBtn.textContent = SHOP_CATEGORY_LABELS[cat] || cat.toUpperCase();
        tabBtn.addEventListener('click', () => {
          currentShopFilterCategory = cat;
          renderShopContents(shopConfig);
        });
        tabsContainer.appendChild(tabBtn);
      });
    }

    // 4. Renderizar artículos en grid con control de stock persistente
    if (grid) {
      grid.innerHTML = '';
      const filteredItems = currentShopFilterCategory === 'all'
        ? items
        : items.filter((it) => it.category === currentShopFilterCategory);

      if (filteredItems.length === 0) {
        grid.innerHTML = '<p style="color:#94a3b8; grid-column: 1 / -1; text-align:center; padding: 30px 0;">No hay artículos en esta categoría.</p>';
        return;
      }

      filteredItems.forEach((offer) => {
        const card = document.createElement('div');
        card.className = 'special-shop-item-card';

        const costCurrencyId = offer.cost?.currencyId || 'material_evento';
        const costAmount = Number(offer.cost?.amount) || 1;
        const currDef = currencyMap[costCurrencyId];
        const costCurrencyName = currDef?.name || offer.cost?.name || 'Material';
        let costCurrencyIcon = currDef?.icon || currDef?.image || offer.cost?.icon || offer.cost?.image || '';
        if (!costCurrencyIcon) {
          if (costCurrencyId === 'coins' || costCurrencyId === 'coin') {
            costCurrencyIcon = './coin.png';
          } else if (costCurrencyId === 'traits' || costCurrencyId === 'trait') {
            costCurrencyIcon = './trait.png';
          } else if (costCurrencyId === 'kvr') {
            costCurrencyIcon = './kvr.png';
          } else {
            const itDef = typeof window.findItemInCatalog === 'function' ? window.findItemInCatalog(costCurrencyId) : null;
            costCurrencyIcon = itDef?.image || itDef?.imageUrl || KNOWN_ITEM_IMAGES[costCurrencyId] || KNOWN_ITEM_IMAGES[costCurrencyId?.toLowerCase()] || './icon-especiales.png';
          }
        }

        const playerHas = currencyBalances[costCurrencyId] || 0;
        const canAfford = playerHas >= costAmount;

        const catKey = offer.category || 'item';
        const isTitle = catKey === 'title';
        const alreadyOwnsTitle = isTitle && isTitleUnlockedByPlayer(offer.reward?.titleId || offer.titleId || offer.id, offer.name);

        // Comprobar existencias/stock
        const purchasedCount = Number(userSpecialEventsData.shopPurchases?.[offer.id] || 0);
        const hasStockLimit = Number(offer.stock) > 0;
        const isSoldOut = hasStockLimit && purchasedCount >= Number(offer.stock);
        const remainingStock = hasStockLimit ? Math.max(0, Number(offer.stock) - purchasedCount) : null;

        const catBadgeLabel = SHOP_CATEGORY_LABELS[catKey] || catKey.toUpperCase();
        const catBadgeClass = `category-${catKey}`;

        let stockBadgeHtml = '';
        if (alreadyOwnsTitle) {
          stockBadgeHtml = `<span class="special-shop-stock-pill owned">✓ DESBLOQUEADO</span>`;
        } else if (isSoldOut) {
          stockBadgeHtml = `<span class="special-shop-stock-pill soldout">AGOTADO (0/${offer.stock})</span>`;
        } else if (hasStockLimit) {
          stockBadgeHtml = `<span class="special-shop-stock-pill">Disponibles: ${remainingStock}/${offer.stock}</span>`;
        }

        const isButtonDisabled = !canAfford || isSoldOut || alreadyOwnsTitle;
        let buttonText = 'Canjear';
        if (alreadyOwnsTitle) {
          buttonText = 'Desbloqueado';
        } else if (isSoldOut) {
          buttonText = 'Agotado';
        } else if (!canAfford) {
          buttonText = 'Material Insuficiente';
        }

        let iconOrShowcaseHtml = '';
        let resolvedOfferImg = '';
        if (isTitle) {
          const gradientStyle = offer.gradient || 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)';
          const formattedTitlePreview = formatTitleGradientSafe(offer.name, gradientStyle);
          iconOrShowcaseHtml = `
            <div class="special-shop-item-title-box" style="border: 2px solid transparent; background: linear-gradient(135deg, rgba(15, 23, 42, 0.95), rgba(2, 6, 23, 0.98)) padding-box, ${gradientStyle} border-box;">
              <div class="special-shop-title-showcase">
                <span class="special-shop-title-crown">👑</span>
                <span class="special-shop-title-gradient-preview">${formattedTitlePreview}</span>
              </div>
            </div>
          `;
        } else {
          let offerImg = offer.image || offer.imageUrl || '';
          if (!offerImg) {
            if (catKey === 'traits' || offer.reward?.type === 'traits') {
              offerImg = './trait.png';
            } else if (catKey === 'coins' || offer.reward?.type === 'coins') {
              offerImg = './coin.png';
            } else if (catKey === 'item' || offer.reward?.type === 'item' || offer.reward?.type === 'objeto') {
              const itId = offer.reward?.itemId || offer.reward?.id || offer.id || '';
              const itObj = typeof window.findItemInCatalog === 'function' ? window.findItemInCatalog(itId) : null;
              offerImg = itObj?.image || itObj?.imageUrl || KNOWN_ITEM_IMAGES[itId] || KNOWN_ITEM_IMAGES[itId?.toLowerCase()] || `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/${itId}.png`;
            } else if (catKey === 'card' || offer.reward?.type === 'card' || offer.reward?.type === 'carta') {
              const cId = offer.reward?.cardId || offer.reward?.id || offer.id || '';
              let cardObj = null;
              if (Array.isArray(window.allCardsCache)) {
                cardObj = window.allCardsCache.find((c) => c.id === cId);
              }
              offerImg = cardObj?.image || cardObj?.imageUrl || `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/cards/${cId}.png`;
            } else if (catKey === 'pack' || offer.reward?.type === 'pack' || offer.reward?.type === 'sobre') {
              const packId = offer.reward?.packId || offer.reward?.id || offer.id || '';
              offerImg = `./assets/packs/${packId}.png`;
            }
          }
          resolvedOfferImg = offerImg;
          iconOrShowcaseHtml = `
            <div class="special-shop-item-icon-box" title="Click para ampliar imagen">
              <img src="${escapeHtml(offerImg)}" alt="${escapeHtml(offer.name)}" class="special-shop-item-icon-img" onerror="this.src='./icon-especiales.png'" />
            </div>
          `;
        }

        const titleHeadingHtml = isTitle
          ? formatTitleGradientSafe(offer.name, offer.gradient)
          : escapeHtml(offer.name);

        card.innerHTML = `
          <div class="special-shop-item-header">
            ${stockBadgeHtml}
            <span class="special-shop-item-badge ${catBadgeClass}">${escapeHtml(catBadgeLabel)}</span>
          </div>
          ${iconOrShowcaseHtml}
          <h4 class="special-shop-item-title">${titleHeadingHtml}</h4>
          <p class="special-shop-item-desc">${escapeHtml(offer.description)}</p>
          <div class="special-shop-item-cost">
            <img src="${escapeHtml(costCurrencyIcon)}" alt="${escapeHtml(costCurrencyName)}" class="special-shop-item-cost-img" onerror="this.src='./icon-especiales.png'" />
            <span>${costAmount.toLocaleString('es-ES')}x ${escapeHtml(costCurrencyName)}</span>
            <span class="special-shop-item-cost-balance">(Tienes: ${playerHas.toLocaleString('es-ES')})</span>
          </div>
          <button type="button" class="special-shop-item-buy-btn" ${isButtonDisabled ? 'disabled' : ''}>
            ${escapeHtml(buttonText)}
          </button>
        `;

        // Click en la imagen para ampliar en grande
        const iconBox = card.querySelector('.special-shop-item-icon-box');
        if (iconBox && resolvedOfferImg) {
          iconBox.addEventListener('click', (e) => {
            e.stopPropagation();
            openSpecialShopImagePreview(resolvedOfferImg, offer.name, offer.description);
          });
        }

        // Click en la divisa/moneda para ampliar
        const costImg = card.querySelector('.special-shop-item-cost-img');
        if (costImg && costCurrencyIcon) {
          costImg.title = `Click para ampliar ${costCurrencyName}`;
          costImg.style.cursor = 'zoom-in';
          costImg.addEventListener('click', (e) => {
            e.stopPropagation();
            openSpecialShopImagePreview(costCurrencyIcon, costCurrencyName, currDef?.description || '');
          });
        }

        const buyBtn = card.querySelector('.special-shop-item-buy-btn');
        if (buyBtn && !isButtonDisabled) {
          buyBtn.addEventListener('click', async () => {
            if (hasStockLimit && Number(userSpecialEventsData.shopPurchases?.[offer.id] || 0) >= Number(offer.stock)) {
              alert('Este artículo ya ha alcanzado el límite máximo de compras.');
              return;
            }

            buyBtn.disabled = true;
            buyBtn.textContent = 'Canjeando...';

            const consumed = await consumePlayerItem(costCurrencyId, costAmount);
            if (consumed) {
              // 1. Registrar compra y guardar en servidor de inmediato
              if (!userSpecialEventsData.shopPurchases) userSpecialEventsData.shopPurchases = {};
              userSpecialEventsData.shopPurchases[offer.id] = (userSpecialEventsData.shopPurchases[offer.id] || 0) + 1;
              await saveUserProgressToServer();

              // 2. Otorgar recompensa al inventario / perfil
              const rewardToGrant = { ...offer.reward };
              if (typeof window.grantPrestigeRewards === 'function' && rewardToGrant && rewardToGrant.type) {
                await window.grantPrestigeRewards([rewardToGrant]);
              }

              // 3. Audio SFX
              if (typeof playSFX === 'function') {
                try {
                  playSFX('packSparkle');
                } catch (e) {
                  try { playSFX('buttonClick'); } catch (e2) {}
                }
              }

              // 4. Refrescar carteras, colecciones y títulos
              if (typeof renderWallet === 'function') {
                renderWallet().catch(() => {});
              }
              if (typeof updateProfileDisplay === 'function') updateProfileDisplay();
              if (typeof updateTitleSelector === 'function') updateTitleSelector();

              // 5. Mostrar HUD animado de recompensa unificado
              if (rewardToGrant && rewardToGrant.type) {
                if (typeof window.showUnifiedRewardsHUD === 'function') {
                  await window.showUnifiedRewardsHUD([rewardToGrant], '¡ARTÍCULO ADQUIRIDO!');
                } else if (typeof window.showRewardsClaimHUD === 'function') {
                  window.showRewardsClaimHUD([rewardToGrant], '¡ARTÍCULO ADQUIRIDO!');
                }
              }

              // 6. Refrescar tienda con balances y existencias actualizadas
              const refreshedConfig = await loadSpecialEventShopConfig(true);
              if (refreshedConfig) {
                await renderShopContents(refreshedConfig);
              }
            } else {
              alert('No se pudo completar el canje. Verifica que tienes suficientes materiales.');
              const refreshedConfig = await loadSpecialEventShopConfig(true);
              if (refreshedConfig) {
                await renderShopContents(refreshedConfig);
              }
            }
          });
        }

        grid.appendChild(card);
      });
    }
  }

  function closeSpecialEventsShop() {
    closeSpecialShopImagePreview();
    const modal = document.getElementById('special-events-shop-modal');
    if (modal) modal.style.display = 'none';
  }

  function openSpecialShopImagePreview(imgSrc, title, desc) {
    if (!imgSrc) return;
    let modal = document.getElementById('special-shop-image-preview-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'special-shop-image-preview-modal';
      modal.className = 'special-shop-image-modal-overlay';
      modal.onclick = (e) => {
        if (e.target === modal) closeSpecialShopImagePreview();
      };
      modal.innerHTML = `
        <div class="special-shop-image-modal-content">
          <button type="button" class="special-shop-image-modal-close" onclick="closeSpecialShopImagePreview()" title="Cerrar">&times;</button>
          <div class="special-shop-image-modal-body">
            <div class="special-shop-preview-img-container">
              <img id="special-shop-preview-img" src="" alt="Vista previa" class="special-shop-preview-img" onclick="closeSpecialShopImagePreview()" onerror="this.src='./icon-especiales.png'" title="Click para cerrar" />
            </div>
            <div id="special-shop-preview-info" class="special-shop-preview-info">
              <h3 id="special-shop-preview-title" class="special-shop-preview-title"></h3>
              <p id="special-shop-preview-desc" class="special-shop-preview-desc"></p>
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(modal);
    }

    const imgEl = modal.querySelector('#special-shop-preview-img');
    const titleEl = modal.querySelector('#special-shop-preview-title');
    const descEl = modal.querySelector('#special-shop-preview-desc');

    if (imgEl) {
      imgEl.src = imgSrc;
      imgEl.alt = title || 'Vista previa ampliada';
    }
    if (titleEl) {
      titleEl.textContent = title || '';
      titleEl.style.display = title ? 'block' : 'none';
    }
    if (descEl) {
      descEl.textContent = desc || '';
      descEl.style.display = desc ? 'block' : 'none';
    }

    modal.style.display = 'flex';
  }

  function closeSpecialShopImagePreview() {
    const modal = document.getElementById('special-shop-image-preview-modal');
    if (modal) {
      modal.style.display = 'none';
    }
  }

  // --------------------------------------------------------------------------
  // FLUJO DE BATALLA Y RECOMPENSAS ANIMADAS
  // --------------------------------------------------------------------------
  function startSpecialEventBattle(world, level) {
    console.log(`[SPECIAL-EVENTS] Iniciando batalla para Nivel: ${level.id} (${level.name}) en Mundo: ${world.id}`);

    window.selectedDifficulty = level.id;
    window.currentSpecialEventWorld = world;
    window.currentSpecialEventLevel = level;
    window.isSpecialEventBattle = true;
    window.isEventBattle = true;
    window.isInfiniteModeTeamBuilding = false;

    // Ocultar panel de eventos especiales
    const panel = document.getElementById('special-events-panel');
    if (panel) panel.style.display = 'none';

    // Abrir Team Builder
    const teamBuilder = document.getElementById('team-builder');
    if (teamBuilder) teamBuilder.style.display = 'block';

    if (typeof updateTeamBuilderModeUI === 'function') {
      updateTeamBuilderModeUI();
    }
    if (typeof loadTeamBuilderInventory === 'function') {
      loadTeamBuilderInventory();
    }

    setTimeout(() => {
      if (typeof setupContinueButton === 'function') {
        setupContinueButton();
      }
    }, 400);
  }

  function rollSpecialEventRewards(rewardsList) {
    if (!Array.isArray(rewardsList) || rewardsList.length === 0) return [];
    const granted = [];

    rewardsList.forEach((r) => {
      const rawProb = r.probability ?? r.prob ?? r.probabilidad;
      let prob = 100;
      if (rawProb !== undefined && rawProb !== null) {
        let p = Number(rawProb);
        if (p <= 1 && p > 0) p = p * 100;
        prob = p;
      }

      const roll = Math.random() * 100;
      if (prob >= 100 || roll <= prob) {
        const clone = { ...r };
        // Normalización enriquecida para que showUnifiedRewardsHUD muestre imagen y animación
        if (!clone.imageUrl && clone.icon) clone.imageUrl = clone.icon;
        if (!clone.imageUrl && clone.image) clone.imageUrl = clone.image;
        if (!clone.imageUrl && (clone.type === 'item' || clone.type === 'objeto')) {
          const itId = clone.itemId || clone.id || '';
          const itObj = (typeof window.findItemInCatalog === 'function')
            ? window.findItemInCatalog(itId || clone)
            : null;
          clone.imageUrl = itObj?.image || itObj?.imageUrl || itObj?.imagen || KNOWN_ITEM_IMAGES[itId] || KNOWN_ITEM_IMAGES[itId?.toLowerCase()] || `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/items/${itId}.png`;
        }
        if (!clone.imageUrl && (clone.type === 'pack' || clone.type === 'sobre')) {
          const pId = clone.packId || clone.id || '';
          clone.imageUrl = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${pId}.png`;
        }
        if (!clone.imageUrl && (clone.type === 'card' || clone.type === 'carta')) {
          const cId = clone.cardId || clone.id || '';
          clone.imageUrl = `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${cId}.png`;
        }
        granted.push(clone);
      }
    });

    return granted;
  }

  // Llamado al ganar la batalla desde battle-ui.js
  async function onSpecialEventBattleVictory(worldId, levelId, levelNumber) {
    const world = window.currentSpecialEventWorld;
    const level = window.currentSpecialEventLevel;
    const targetWorldId = worldId || world?.id;
    const targetLevelId = levelId || level?.id;
    const targetLevelNumber = levelNumber || level?.levelNumber || 1;

    console.log(`[SPECIAL-EVENTS] Victoria registrada en Mundo: ${targetWorldId}, Nivel: ${targetLevelId} (#${targetLevelNumber})`);

    const wasCompletedBefore = isLevelCompleted(targetWorldId, targetLevelId);

    // 1. Guardar progreso de desbloqueo y sincronizar al servidor
    await recordSpecialEventLevelVictory(targetWorldId, targetLevelId, targetLevelNumber);

    // 2. Determinar pool de recompensas: Primera victoria vs Repetición
    const activeRewardsPool = !wasCompletedBefore
      ? (level?.firstClearRewards || level?.rewards || [])
      : (level?.repeatRewards || []);

    const hudTitle = !wasCompletedBefore
      ? '¡PRIMERA VICTORIA EN NIVEL!'
      : '¡NIVEL SUPERADO! (REPETICIÓN)';

    // 3. Tira de recompensas
    const wonRewards = rollSpecialEventRewards(activeRewardsPool);

    // 4. Otorgar recompensas al jugador
    if (wonRewards.length > 0 && typeof window.grantPrestigeRewards === 'function') {
      await window.grantPrestigeRewards(wonRewards);
    }

    if (window.kvrcards && typeof window.kvrcards.addBattleWon === 'function') {
      await window.kvrcards.addBattleWon().catch(() => {});
    }

    if (typeof renderWallet === 'function') {
      await renderWallet().catch(() => {});
    }

    // 5. Registrar progreso en Misiones y Evoluciones
    if (typeof window.recordGenericMissionProgress === 'function') {
      const missionPayload = {
        levelId: targetLevelId,
        worldId: targetWorldId,
        levelNumber: targetLevelNumber,
        eventId: cachedSpecialEventsConfig?.id || 'special_event',
        battleId: targetLevelId
      };
      await window.recordGenericMissionProgress('win_special_event_level', 1, missionPayload);
      await window.recordGenericMissionProgress('complete_special_event_level', 1, missionPayload);
      await window.recordGenericMissionProgress('special_event_level', 1, missionPayload);
    }

    if (typeof window.recordEvolutionSpecialEventLevelWon === 'function') {
      try {
        window.recordEvolutionSpecialEventLevelWon(window.battleState?.playerTeam || [], {
          levelId: targetLevelId,
          worldId: targetWorldId,
          levelNumber: targetLevelNumber,
          eventId: cachedSpecialEventsConfig?.id || 'special_event'
        });
      } catch (evoErr) {
        console.warn('[SPECIAL-EVENTS] Error registrando nivel en evoluciones:', evoErr);
      }
    }

    // 5. Disparar HUD animado unificado del juego para todo tipo de recompensas
    if (typeof window.showUnifiedRewardsHUD === 'function' && wonRewards.length > 0) {
      setTimeout(async () => {
        try {
          await window.showUnifiedRewardsHUD(wonRewards, hudTitle);
        } catch (e) {
          console.warn('[SPECIAL-EVENTS] Error mostrando HUD animado de recompensas:', e);
        }
      }, 600);
    }
  }

  // --------------------------------------------------------------------------
  // APERTURA Y CIERRE DEL PANEL
  // --------------------------------------------------------------------------
  async function openSpecialEventsPanel(options = {}) {
    window.isSpecialEventBattle = false;
    window.currentSpecialEventLevel = null;

    const gameView = document.getElementById('game-view');
    if (gameView) gameView.style.display = 'block';

    const mainMenu = document.getElementById('main-menu');
    if (mainMenu) mainMenu.style.display = 'none';

    const typeSelection = document.getElementById('game-type-selection');
    if (typeSelection) typeSelection.style.display = 'none';

    const eventModeSel = document.getElementById('event-mode-selection');
    if (eventModeSel) eventModeSel.style.display = 'none';

    const classicPanel = document.getElementById('event-battles-panel');
    if (classicPanel) classicPanel.style.display = 'none';

    const panel = document.getElementById('special-events-panel');
    if (panel) panel.style.display = 'block';

    // Sincronizar progreso guardado con el servidor al abrir
    await syncUserProgressWithServer();
    await loadSpecialEventsConfig(true);

    if (typeof window.loadAllItems === 'function') {
      window.loadAllItems().catch(() => {});
    }

    if (options && options.worldId) {
      openWorldLevels(options.worldId);
    } else {
      renderWorldsView();
    }
  }

  function closeSpecialEventsPanel() {
    window.isSpecialEventBattle = false;
    window.currentSpecialEventLevel = null;

    const panel = document.getElementById('special-events-panel');
    if (panel) panel.style.display = 'none';

    const eventModeSel = document.getElementById('event-mode-selection');
    if (eventModeSel) {
      eventModeSel.style.display = 'block';
    } else {
      const typeSelection = document.getElementById('game-type-selection');
      if (typeSelection) typeSelection.style.display = 'block';
    }
  }

  function escapeHtml(str) {
    if (typeof str !== 'string') return String(str ?? '');
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Cerrar preview con la tecla Escape
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const modal = document.getElementById('special-shop-image-preview-modal');
      if (modal && modal.style.display !== 'none') {
        closeSpecialShopImagePreview();
      }
    }
  });

  // Exponer API global
  window.openSpecialEventsPanel = openSpecialEventsPanel;
  window.closeSpecialEventsPanel = closeSpecialEventsPanel;
  window.openSpecialEventsWorldsView = renderWorldsView;
  window.openWorldLevels = openWorldLevels;
  window.openSpecialEventsShop = openSpecialEventsShop;
  window.closeSpecialEventsShop = closeSpecialEventsShop;
  window.openSpecialShopImagePreview = openSpecialShopImagePreview;
  window.closeSpecialShopImagePreview = closeSpecialShopImagePreview;
  window.closeLevelRewardsModal = closeLevelRewardsModal;
  window.onSpecialEventBattleVictory = onSpecialEventBattleVictory;
  window.rollSpecialEventRewards = rollSpecialEventRewards;
  window.loadSpecialEventsConfig = loadSpecialEventsConfig;
  window.loadSpecialEventShopConfig = loadSpecialEventShopConfig;
  window.syncUserSpecialEventsProgress = syncUserProgressWithServer;
})();
