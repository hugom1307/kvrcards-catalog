// ==================== HANDLERS PARA EVENTOS DEL SERVIDOR (SERVIDOR COMO ÁRBITRO) ====================

/**
 * Maneja el inicio de una nueva ronda desde el servidor
 * @param {Object} data - { roundNumber, player1Username, player2Username }
 */
function handleServerRoundStart(data) {
  console.log(`[ONLINE-BATTLE] Iniciando ronda ${data.roundNumber} de 7`);
  
  // Actualizar estado de batalla
  if (window.battleState) {
    window.battleState.currentRound = data.roundNumber;
    window.battleState.gamePhase = 'card-selection';
    window.battleState.canChangeCard = true;
    window.battleState.playerCurrentCard = null;
    window.battleState.opponentCurrentCard = null;
    window.battleState.selectedStat = null;
    window.battleState.opponentSelectedStat = null;
    window.battleState.annulledStat = null;
    window.battleState.currentTurn = 'player'; // Online: ambos eligen simultáneamente
    
    // Actualizar scores si vienen en el data
    if (data.scores) {
      const isPlayer1 = window.onlineState.isHost;
      if (isPlayer1) {
        window.battleState.playerScore = data.scores.player1;
        window.battleState.opponentScore = data.scores.player2;
      } else {
        window.battleState.playerScore = data.scores.player2;
        window.battleState.opponentScore = data.scores.player1;
      }
    }
    
    // Actualizar cartas usadas si vienen en el data
    if (data.usedCards) {
      const isPlayer1 = window.onlineState.isHost;
      window.battleState.playerUsedCards = isPlayer1 ? (data.usedCards.player1 || []) : (data.usedCards.player2 || []);
      window.battleState.opponentUsedCards = isPlayer1 ? (data.usedCards.player2 || []) : (data.usedCards.player1 || []);
    }
    
    // Guardar quién empieza (para saber quién ganó la ronda anterior)
    if (data.firstPlayer) {
      const playerStarts = (data.firstPlayer === 'player1' && data.isPlayer1) || 
                           (data.firstPlayer === 'player2' && !data.isPlayer1);
      window.battleState.firstPlayer = playerStarts;
      console.log(`[ONLINE-BATTLE] Primero juega: ${playerStarts ? 'Jugador' : 'Oponente'}`);
    }
    
    // Resetear poderes de ronda
    window.battleState.playerPowerUpActive = false;
    window.battleState.opponentPowerUpActive = false;
    window.battleState.playerNerfActive = false;
    window.battleState.opponentNerfActive = false;
  }
  
  // Mostrar pantalla de batalla con sidebar de selección de cartas
  // EXCEPCIÓN: En ronda 1, NO ocultar intro - showBattleIntro ya la maneja con animación
  const teamBuilder = document.getElementById('team-builder');
  const battleScreen = document.getElementById('battle-screen');
  const intro = document.getElementById('battle-intro');
  
  if (teamBuilder) teamBuilder.style.display = 'none';
  
  if (data.roundNumber === 1) {
    // Ronda 1: Resetear estrictamente stats usadas de la partida anterior tanto en memoria como en DOM
    if (window.battleState) {
      window.battleState.playerUsedStats = [];
      window.battleState.opponentUsedStats = [];
      window.battleState.playerUsedCards = [];
      window.battleState.opponentUsedCards = [];
      window.battleState.selectedStat = null;
      window.battleState.opponentSelectedStat = null;
      window.battleState.annulledStat = null;
    }
    if (typeof window.cleanAllBattleStatButtonsAndDisplays === 'function') {
      window.cleanAllBattleStatButtonsAndDisplays();
    }
    console.log('[ONLINE-BATTLE] Ronda 1: preservando intro de batalla para animación de cartas y reseteadas stats previas');
    return; // El flujo continúa con selectFirstCard → card-selected → select-stat
  }
  
  if (intro) intro.style.display = 'none';
  if (battleScreen) battleScreen.style.display = 'flex';
  ensureAbandonBattleButtonBound();
  
  // Limpiar cartas visuales de la ronda anterior
  if (typeof clearBattleCards === 'function') {
    clearBattleCards();
  }
  
  // Limpiar efectos visuales previos
  const playerCardDisplay = document.querySelector('.battle-side-player .battle-card-display');
  const opponentCardDisplay = document.querySelector('.battle-side-opponent .battle-card-display');
  if (playerCardDisplay) playerCardDisplay.classList.remove('winner');
  if (opponentCardDisplay) opponentCardDisplay.classList.remove('winner');
  
  // Limpiar el parpadeo activo si quedó alguno
  document.querySelectorAll('.battle-stat-display.highlighted, .battle-stat-btn.highlighted').forEach(el => {
    el.classList.remove('highlighted');
  });

  // Asegurar que las stats NO usadas no mantengan highlighted-static, used ni estilos de bloqueo
  document.querySelectorAll('.battle-side-player .battle-stat-btn').forEach(btn => {
    const stat = btn.dataset?.stat;
    if (!window.battleState?.playerUsedStats?.includes(stat)) {
      btn.classList.remove('used', 'highlighted', 'highlighted-static', 'selected');
      btn.style.borderColor = '';
      btn.style.background = '';
      btn.style.boxShadow = '';
      btn.style.pointerEvents = '';
      btn.style.cursor = '';
    }
  });
  document.querySelectorAll('.battle-side-opponent .battle-stat-display').forEach(display => {
    const stat = display.dataset?.stat;
    if (!window.battleState?.opponentUsedStats?.includes(stat)) {
      display.classList.remove('used', 'highlighted', 'highlighted-static', 'selected');
      display.style.borderColor = '';
      display.style.background = '';
      display.style.boxShadow = '';
    }
  });

  // Limpiar inline styles residuales y estados de anulación de rondas anteriores
  document.querySelectorAll('.battle-stat-display, .battle-stat-btn').forEach(el => {
    el.classList.remove('annulled');
    const label = el.querySelector('.stat-label');
    if (label) {
      label.innerHTML = label.innerHTML.replace('(BLOQUEADO) ', '').replace(/\u{1F512}\s*/gu, '');
    }
  });
  
  // Mostrar sidebar según turno (el ganador de la ronda anterior elige carta primero)
  const sidebar = document.getElementById('battle-team-sidebar');
  const iGoFirst = window.battleState.firstPlayer === true; // true = yo empiezo
  if (sidebar) {
    if (iGoFirst) {
      sidebar.style.display = 'flex';
      console.log('[ONLINE-BATTLE] Sidebar mostrado: yo elijo carta primero');
    } else {
      sidebar.style.display = 'none';
      console.log('[ONLINE-BATTLE] Sidebar oculto: esperando a que el rival elija carta primero');
    }
  }
  
  // Renderizar cartas disponibles (excluir usadas)
  if (typeof renderTeamSidebar === 'function') {
    renderTeamSidebar();
  }
  
  // Actualizar marcador
  const scorePlayerEl = document.getElementById('score-player-value');
  const scoreOpponentEl = document.getElementById('score-opponent-value');
  if (scorePlayerEl) scorePlayerEl.textContent = window.battleState.playerScore || 0;
  if (scoreOpponentEl) scoreOpponentEl.textContent = window.battleState.opponentScore || 0;
  
  // Resetear UI de stats
  resetBattleUIForNewRound();
  
  // Mostrar instrucción según turno
  const instruction = document.getElementById('battle-intro-instruction');
  if (instruction) {
    if (iGoFirst) {
      instruction.innerHTML = `<h1>Ronda ${data.roundNumber} de 7</h1><p>Selecciona tu carta para esta ronda</p>`;
    } else {
      instruction.innerHTML = `<h1>Ronda ${data.roundNumber} de 7</h1><p>Esperando a que el rival elija carta...</p>`;
    }
  }
  
  console.log(`[ONLINE-BATTLE] Ronda ${data.roundNumber} lista - esperando selección de carta`);
}

/**
 * El servidor solicita selección de stat (después de que ambos jugadores seleccionaron carta)
 * @param {Object} data - { playerCard, opponentCard, showRoulette, firstPlayer, isYourTurn }
 */
function handleServerSelectStat(data) {
  if (window.OnlineBattleRoundHandlers && typeof window.OnlineBattleRoundHandlers.handleServerSelectStat === 'function') {
    return window.OnlineBattleRoundHandlers.handleServerSelectStat(data);
  }
  console.warn('[ONLINE-BATTLE] OnlineBattleRoundHandlers no disponible para handleServerSelectStat');
}

/**
 * El servidor envía el resultado de una ronda
 * @param {Object} data - { round, winner: 'player1'|'player2'|'draw', card1: {name,stat,value,cardIndex}, card2: {name,stat,value,cardIndex}, scores: {player1,player2} }
 */
function handleServerRoundResult(data) {
  if (window.OnlineBattleRoundHandlers && typeof window.OnlineBattleRoundHandlers.handleServerRoundResult === 'function') {
    return window.OnlineBattleRoundHandlers.handleServerRoundResult(data);
  }
  console.warn('[ONLINE-BATTLE] OnlineBattleRoundHandlers no disponible para handleServerRoundResult');
}

async function handleServerBattleFinished(data) {
  console.log('[ONLINE-BATTLE] Batalla terminada:', data);
  clearTimeout(window.__opponentDisconnectFallbackTimer);
  
  // Determinar si ganamos o perdimos usando isHost
  const isPlayer1 = window.onlineState.isHost;
  const finalScores = data.scores || data.finalScores || { player1: 0, player2: 0 };
  const playerFinalScore = isPlayer1 ? finalScores.player1 : finalScores.player2;
  const opponentFinalScore = isPlayer1 ? finalScores.player2 : finalScores.player1;
  
  let didWin = false;
  
  if (data.winner === 'player1' && isPlayer1) {
    didWin = true;
  } else if (data.winner === 'player2' && !isPlayer1) {
    didWin = true;
  } else if (data.winner === 'draw') {
    didWin = null; // Empate
  }

  recordPrestigeBattleOutcome(didWin === true).catch((error) => {
    console.warn('[PRESTIGE] No se pudo registrar resultado online:', error?.message || error);
  });
  
  // Mostrar pantalla de victoria/derrota
  showBattleEndScreen(didWin, playerFinalScore, opponentFinalScore, data.reason);
  
  // Guardar resultado en historial y otorgar recompensas
  const opponentName = window.battleState.opponentName || window.onlineState.opponentData?.username || 'Rival Online';
  
  if (didWin === true) {
    console.log('[ONLINE-BATTLE] Victoria online de 7-0 o similar detectada - Otorgando recompensas...');
    
    // Guardar resultado local
    saveBattleResult({
      mode: 'online',
      difficulty: 'online',
      result: 'win',
      score: playerFinalScore,
      opponentScore: opponentFinalScore,
      opponent: opponentName
    });
    
    // Otorgar recompensas en la base de datos local y remota
    if (isElectron) {
      try {
        // Otorgar 300 Coins
        const coinRes = await window.kvrcards.addCoins(300);
        if (coinRes.ok) {
          console.log('[ONLINE-BATTLE] +300 Coins otorgadas con éxito');
          if (typeof renderWallet === 'function') {
            await renderWallet();
          }
        }
        
        // Incrementar victorias
        const winRes = await window.kvrcards.addBattleWon();
        if (winRes.ok) {
          console.log('[ONLINE-BATTLE] Victoria registrada. Total de victorias:', winRes.battlesWon);
        }

        // Mostrar HUD unificado de recompensa
        if (typeof window.showUnifiedRewardsHUD === 'function') {
          setTimeout(async () => {
            try {
              await window.showUnifiedRewardsHUD([{ type: 'coins', amount: 300 }], '¡VICTORIA ONLINE!');
            } catch (e) {
              console.warn('[ONLINE-BATTLE] Error en HUD de recompensas:', e);
            }
          }, 600);
        }

        // Actualizar progreso de misiones y kizunas
        if (typeof updateMissionsProgress === 'function') {
          updateMissionsProgress().catch(() => {});
        }
        if (typeof updateKizunasProgress === 'function') {
          updateKizunasProgress().catch(() => {});
        }
      } catch (err) {
        console.error('[ONLINE-BATTLE] Error al guardar estadísticas en Electron:', err);
      }
    }
  } else if (didWin === false) {
    console.log('[ONLINE-BATTLE] Derrota online de 0-7 o similar detectada - Guardando en historial...');
    
    // Guardar resultado local de derrota
    saveBattleResult({
      mode: 'online',
      difficulty: 'online',
      result: 'lose',
      score: playerFinalScore,
      opponentScore: opponentFinalScore,
      opponent: opponentName
    });
  } else {
    console.log('[ONLINE-BATTLE] Empate online detectada - Guardando en historial...');
    
    // Guardar resultado local de empate
    saveBattleResult({
      mode: 'online',
      difficulty: 'online',
      result: 'draw',
      score: playerFinalScore,
      opponentScore: opponentFinalScore,
      opponent: opponentName
    });
  }

  // Limpiar timers de combate pendientes y banderas de conexión
  if (typeof clearAllBattleTimeouts === 'function') {
    clearAllBattleTimeouts();
  }
  if (window.onlineState) {
    window.onlineState.inBattle = false;
    window.onlineState.inQueue = false;
    window.onlineState.matchId = null;
    window.onlineState.teamReadySent = false;
  }
}

// ==================== FUNCIONES AUXILIARES ====================

/**
 * Resetea la UI de batalla para una nueva ronda
 */
function resetBattleUIForNewRound() {
  // Limpiar cartas seleccionadas visualmente
  const selectedCards = document.querySelectorAll('.team-card-slot.selected');
  selectedCards.forEach(card => card.classList.remove('selected'));
  
  // Deshabilitar botones de stats
  const statButtons = document.querySelectorAll('.battle-stat-btn');
  statButtons.forEach(btn => {
    btn.disabled = true;
    btn.classList.remove('selected');
  });
  
  // Limpiar resultado de ronda anterior
  const resultContainer = document.getElementById('round-result-container');
  if (resultContainer) {
    resultContainer.innerHTML = '';
    resultContainer.style.display = 'none';
  }
}

/**
 * Muestra ambas cartas en la pantalla de batalla
 */
function displayBothCardsInBattle(playerCard, opponentCard) {
  console.log('[ONLINE-BATTLE] Mostrando cartas en batalla');
  
  // Guardar las cartas en el estado
  window.battleState.playerCurrentCard = playerCard;
  window.battleState.opponentCurrentCard = opponentCard;
}

/**
 * Habilita los botones de selección de stats (solo visual, para uso online)
 * NOTA: NO redefinir enableStatSelection aquí - la definición principal está en la sección offline
 */
function enableOnlineStatButtonsUI() {
  const statButtons = document.querySelectorAll('.battle-stat-btn');
  statButtons.forEach(btn => {
    btn.disabled = false;
    btn.classList.remove('disabled');
  });
}

/**
 * Muestra el resultado visual de una ronda
 * Server envía: { round, winner: 'player1'|'player2'|'draw', card1: {name,stat,value}, card2: {name,stat,value}, scores }
 */
function displayRoundResult(data) {
  const resultContainer = document.getElementById('round-result-container') || createResultContainer();
  
  // Determinar perspectiva local: somos player1 si somos host
  const isPlayer1 = window.onlineState && window.onlineState.isHost;
  const myCard = isPlayer1 ? data.card1 : data.card2;
  const oppCard = isPlayer1 ? data.card2 : data.card1;
  
  // Determinar si ganamos esta ronda
  const isDraw = (data.winner === 'draw');
  const isWinner = (data.winner === 'player1' && isPlayer1) || (data.winner === 'player2' && !isPlayer1);
  
  // Extraer datos de stats
  const myStat = myCard ? myCard.stat : '?';
  const myValue = myCard ? myCard.value : 0;
  const oppStat = oppCard ? oppCard.stat : '?';
  const oppValue = oppCard ? oppCard.value : 0;
  
  let resultHTML = '';
  
  if (isDraw) {
    // Mostrar totales si hubo empate por stats y se resolvió por suma total
    const tieInfo = (data.player1Total !== undefined && data.player2Total !== undefined)
      ? `<p class="tie-totals">Total cartas: ${isPlayer1 ? data.player1Total : data.player2Total} vs ${isPlayer1 ? data.player2Total : data.player1Total}</p>`
      : '';
    resultHTML = `
      <div class="round-result draw">
        <h2>EMPATE</h2>
        <p>${myStat.toUpperCase()}: ${myValue} vs ${oppStat.toUpperCase()}: ${oppValue}</p>
        ${tieInfo}
      </div>
    `;
  } else if (isWinner) {
    resultHTML = `
      <div class="round-result win">
        <h2>¡GANASTE LA RONDA!</h2>
        <p>Tu ${myStat.toUpperCase()}: ${myValue} vs ${oppStat.toUpperCase()}: ${oppValue}</p>
      </div>
    `;
  } else {
    resultHTML = `
      <div class="round-result lose">
        <h2>Perdiste la ronda</h2>
        <p>Tu ${myStat.toUpperCase()}: ${myValue} vs ${oppStat.toUpperCase()}: ${oppValue}</p>
      </div>
    `;
  }
  
  resultContainer.innerHTML = resultHTML;
  resultContainer.style.display = 'block';
  
  // Animar entrada
  setTimeout(() => {
    const resultEl = resultContainer.querySelector('.round-result');
    if (resultEl) resultEl.classList.add('show');
  }, 100);
}

/**
 * Crea un contenedor para mostrar resultados de ronda
 */
function createResultContainer() {
  let container = document.getElementById('round-result-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'round-result-container';
    container.className = 'round-result-overlay';
    document.body.appendChild(container);
  }
  return container;
}

/**
 * Actualiza el marcador en la UI
 */
function updateScoreDisplay() {
  const playerScoreEl = document.getElementById('player-score');
  const opponentScoreEl = document.getElementById('opponent-score');
  
  if (playerScoreEl && window.battleState) {
    playerScoreEl.textContent = window.battleState.playerScore || 0;
  }
  
  if (opponentScoreEl && window.battleState) {
    opponentScoreEl.textContent = window.battleState.opponentScore || 0;
  }
}

/**
 * Muestra la pantalla de fin de batalla
 */
function showBattleEndScreen(didWin, playerScore, opponentScore, reason) {
  // Ocultar battle screen
  const battleScreen = document.getElementById('battle-screen');
  if (battleScreen) battleScreen.style.display = 'none';

  // Batalla online terminada: restaurar musica de menu.
  resumeMenuMusic();
  
  // Limpiar cualquier pantalla de fin previa para evitar duplicados
  document.querySelectorAll('.battle-end-screen').forEach(el => el.remove());

  // Crear pantalla de resultado
  const resultScreen = document.createElement('div');
  resultScreen.className = 'battle-end-screen show';
  resultScreen.style.opacity = '1';
  
  let title = '';
  let message = '';
  let rewardHtml = '';
  
  if (didWin === null) {
    title = 'EMPATE';
    message = `Batalla finalizada: ${playerScore} - ${opponentScore}`;
  } else if (didWin) {
    title = '¡VICTORIA!';
    message = `Has ganado ${playerScore} - ${opponentScore}`;
    rewardHtml = '<p style="color: #fbbf24; font-size: 20px; font-weight: bold; margin-top: -10px; margin-bottom: 25px;">+300 Monedas ganadas</p>';
  } else {
    title = 'DERROTA';
    message = `Has perdido ${playerScore} - ${opponentScore}`;
  }
  
  if (reason === 'disconnect') {
    message += '<br><small>Tu oponente se desconectó</small>';
  }
  
  resultScreen.innerHTML = `
    <div class="battle-end-content">
      <h2>${title}</h2>
      <p>${message}</p>
      ${rewardHtml}
      <button id="battle-end-return-btn" class="btn-primary" onclick="returnToMainMenuFromOnline()">Volver al menú</button>
    </div>
  `;
  
  document.body.appendChild(resultScreen);
  
  const returnBtn = resultScreen.querySelector('#battle-end-return-btn');
  if (returnBtn) {
    returnBtn.addEventListener('click', returnToMainMenuFromOnline);
  }
}

/**
 * Resetea el estado de batalla online
 */
function resetOnlineBattleState(preserveEndScreen = false) {
  if (window.onlineState) {
    window.onlineState.inBattle = false;
    window.onlineState.inQueue = false;
    window.onlineState.matchId = null;
    window.onlineState.opponentId = null;
    window.onlineState.teamReadySent = false;
  }
  
  if (typeof window.cleanUpBattleCompletely === 'function') {
    window.cleanUpBattleCompletely({ isOnline: false, isFullReset: true, resetDraft: true, resumeMenuMusic: true, preserveEndScreen });
  }

  // Limpieza exhaustiva de botones y displays de stats en el DOM
  if (typeof window.cleanAllBattleStatButtonsAndDisplays === 'function') {
    window.cleanAllBattleStatButtonsAndDisplays();
  } else {
    document.querySelectorAll('.battle-stat-btn, .battle-stat-display').forEach(el => {
      el.classList.remove('used', 'highlighted', 'highlighted-static', 'annulled', 'disabled', 'selected', 'nerfed');
      el.disabled = false;
      el.style.opacity = '';
      el.style.borderColor = '';
      el.style.background = '';
      el.style.boxShadow = '';
      el.style.pointerEvents = '';
      el.style.cursor = '';
      const label = el.querySelector('.stat-label');
      if (label) {
        label.innerHTML = label.innerHTML.replace(/\(BLOQUEADO\)\s*/g, '').replace(/\u{1F512}\s*/gu, '');
      }
    });
  }

  // Resetear el estado de la fase de elección (Draft) si está activo
  if (typeof window.resetDraftState === 'function') {
    window.resetDraftState();
  }
}

/**
 * Renderiza una carta para la batalla
 */
function renderBattleCard(card, side) {
  if (!card) return '<div class="empty-card">Sin carta</div>';
  
  return `
    <div class="battle-card ${side}">
      <div class="card-header">
        <h3>${card.name}</h3>
        <span class="card-quality ${card.quality}">${card.quality}</span>
      </div>
      <img src="${card.image}" alt="${card.name}" />
      <div class="card-stats">
        <div class="stat"><span>POT:</span> ${card.stats.potential}</div>
        <div class="stat"><span>PAC:</span> ${card.stats.pace}</div>
        <div class="stat"><span>DEF:</span> ${card.stats.defense}</div>
        <div class="stat"><span>PHY:</span> ${card.stats.physical}</div>
      </div>
    </div>
  `;
}

/**
 * Guarda el resultado de una batalla en el historial
 */
function saveBattleResult(battleData) {
  try {
    let history = JSON.parse(localStorage.getItem('battleHistory') || '[]');
    
    const result = {
      timestamp: new Date().toISOString(),
      mode: battleData.mode,
      difficulty: battleData.difficulty,
      result: battleData.result,
      playerScore: battleData.score,
      opponentScore: battleData.opponentScore,
      opponent: battleData.opponent,
      modo_de_juego: battleData.modo_de_juego || window.battleState?.gameMode || 'clasico7v7'
    };
    
    history.push(result);
    
    // Mantener solo los últimos 100 resultados
    if (history.length > 100) {
      history = history.slice(-100);
    }
    
    localStorage.setItem('battleHistory', JSON.stringify(history));
    console.log('[ONLINE-BATTLE] Resultado guardado en historial');
  } catch (error) {
    console.error('[ONLINE-BATTLE] Error al guardar resultado:', error);
  }
}

/**
 * Vuelve al menú principal (versión online - llama a la función principal)
 * NOTA: NO redefinir returnToMainMenu aquí - la definición principal está en la sección offline
 */
function returnToMainMenuFromOnline() {
  console.log('[ONLINE-BATTLE] Volviendo al menú principal desde fin de batalla online...');
  // Ocultar overlay de recompensas unificadas si estuviera abierto
  const rewardsOverlay = document.getElementById('rewards-claim-overlay');
  if (rewardsOverlay) {
    rewardsOverlay.classList.remove('show');
    rewardsOverlay.style.display = 'none';
  }

  // Limpiar pantallas de batalla online dinámicas
  const battleEndScreens = document.querySelectorAll('.battle-end-screen');
  battleEndScreens.forEach(screen => screen.remove());
  
  // Resetear estado online y de combate completamente
  resetOnlineBattleState(false);
  
  // Usar la función principal de retorno al menú
  if (typeof returnToMainMenu === 'function') {
    returnToMainMenu();
  } else if (typeof window.returnToMainMenu === 'function') {
    window.returnToMainMenu();
  }
}
window.returnToMainMenuFromOnline = returnToMainMenuFromOnline;

console.log('[ONLINE] Sistema online PVP cargado con servidor como árbitro');
