console.log('[OWNER BUFF CONFIG] Configuración de buffeos por owner cargada al inicio');

// Definir función global para traits al inicio para evitar ReferenceError
window.toggleTraitsPanel = async function() {
  const traitsPanel = document.getElementById('traits-panel');
  if (!traitsPanel) {
    console.error('[TRAITS] Panel no encontrado');
    return;
  }
  
  console.log('[TRAITS] Toggle panel activado');
  
  if (traitsPanel.style.display === 'none' || traitsPanel.style.display === '') {
    traitsPanel.style.display = 'block';
    
    // Ocultar panel de Gambling si está abierto
    const gamblingPanel = document.getElementById('gambling-panel');
    if (gamblingPanel) gamblingPanel.style.display = 'none';
    
    // Asegurar que el sistema esté inicializado
    if (typeof window.traitsSystemInitialized === 'undefined') {
      window.traitsSystemInitialized = false;
    }
    
    const initFn = typeof window.initTraitsSystem === 'function' ? window.initTraitsSystem : (typeof initTraitsSystem === 'function' ? initTraitsSystem : null);
    if (!window.traitsSystemInitialized && initFn) {
      await initFn();
    }
    
    if (typeof window.renderTraitsPanel === 'function') {
      await window.renderTraitsPanel();
    } else if (typeof renderTraitsPanel === 'function') {
      await renderTraitsPanel();
    }
  } else {
    traitsPanel.style.display = 'none';
    const indexPanel = document.getElementById('traits-index-panel');
    if (indexPanel) indexPanel.style.display = 'none';
    const indexBtn = document.getElementById('traits-index-btn');
    if (indexBtn) indexBtn.classList.remove('active');
  }
};

// ==================== ÍNDICE Y PROBABILIDADES DE RASGOS (REMOTO OFICIAL) ====================

window.fetchRemoteTraitsDirectly = async function() {
  const urls = [
    `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/traits.json?t=${Date.now()}`,
    `https://hugom1307.github.io/kvrcards-catalog/traits.json?t=${Date.now()}`
  ];
  for (const url of urls) {
    try {
      const res = await fetch(url, { cache: 'no-store' });
      if (res.ok) {
        const json = await res.json();
        const list = Array.isArray(json) ? json : (Array.isArray(json?.traits) ? json.traits : []);
        if (list.length > 0) {
          console.log(`[TRAITS] ${list.length} rasgos cargados exitosamente desde ${url}`);
          return list;
        }
      }
    } catch (e) {
      console.warn('[TRAITS] Error consultando', url, e);
    }
  }
  // Fallback IPC si falla la red externa
  if (window.kvrcards && typeof window.kvrcards.getAllTraits === 'function') {
    try {
      const ipcTraits = await window.kvrcards.getAllTraits();
      const arr = Array.isArray(ipcTraits) ? ipcTraits : (Array.isArray(ipcTraits?.traits) ? ipcTraits.traits : []);
      if (arr.length > 0) return arr;
    } catch {}
  }
  return [];
};

window.calculateTraitProbabilities = function(traits) {
  if (!Array.isArray(traits) || traits.length === 0) return [];
  const N = traits.length;

  const parsed = traits.map(t => {
    let raw = t.probability ?? t.probabilidad ?? t.chance ?? t.prob ?? null;
    let val = null;
    if (raw !== null && raw !== undefined && raw !== '') {
      if (typeof raw === 'string') raw = raw.replace('%', '').trim();
      const num = parseFloat(raw);
      if (!isNaN(num) && num >= 0) {
        val = num;
      }
    }
    return { trait: t, manualProb: val };
  });

  const manualValues = parsed.filter(p => p.manualProb !== null).map(p => p.manualProb);
  const isDecimal = manualValues.length > 0 &&
                    manualValues.every(v => v <= 1) &&
                    manualValues.reduce((a, b) => a + b, 0) <= 1 &&
                    manualValues.some(v => v < 0.2);

  if (isDecimal) {
    parsed.forEach(p => {
      if (p.manualProb !== null) p.manualProb *= 100;
    });
  }

  const manualCount = parsed.filter(p => p.manualProb !== null).length;
  const autoCount = N - manualCount;
  const manualSum = parsed.filter(p => p.manualProb !== null).reduce((sum, p) => sum + p.manualProb, 0);

  let result = [];

  if (manualCount === 0) {
    const equalProb = 100 / N;
    result = parsed.map(p => ({
      ...p.trait,
      calculatedProbability: equalProb,
      isManual: false
    }));
  } else if (autoCount === 0) {
    const scale = manualSum > 0 ? (100 / manualSum) : 1;
    result = parsed.map(p => ({
      ...p.trait,
      calculatedProbability: p.manualProb * scale,
      isManual: true
    }));
  } else {
    if (manualSum < 100) {
      const remaining = 100 - manualSum;
      const autoProb = remaining / autoCount;
      result = parsed.map(p => {
        if (p.manualProb !== null) {
          return { ...p.trait, calculatedProbability: p.manualProb, isManual: true };
        } else {
          return { ...p.trait, calculatedProbability: autoProb, isManual: false };
        }
      });
    } else {
      const autoFloor = 0.5;
      const totalWeight = manualSum + (autoFloor * autoCount);
      const scale = 100 / totalWeight;
      result = parsed.map(p => {
        const raw = p.manualProb !== null ? p.manualProb : autoFloor;
        return {
          ...p.trait,
          calculatedProbability: raw * scale,
          isManual: p.manualProb !== null
        };
      });
    }
  }

  return result;
};

window.formatTraitProbability = function(prob) {
  if (typeof prob !== 'number' || isNaN(prob)) return '0%';
  if (prob >= 10) {
    return (prob % 1 === 0 ? prob.toFixed(0) : prob.toFixed(1)) + '%';
  } else if (prob >= 1) {
    return (prob % 1 === 0 ? prob.toFixed(0) : prob.toFixed(2)) + '%';
  } else {
    return prob.toFixed(2) + '%';
  }
};

window.renderTraitsIndex = async function() {
  const tbody = document.getElementById('traits-index-tbody');
  if (!tbody) {
    console.warn('[TRAITS] No se encontró #traits-index-tbody');
    return;
  }

  tbody.innerHTML = '<tr><td colspan="3" style="text-align:center; padding: 24px; color:#fbbf24;">Cargando rasgos desde el servidor remoto...</td></tr>';

  // Leer directamente del json remoto
  const traits = await window.fetchRemoteTraitsDirectly();
  if (Array.isArray(traits) && traits.length > 0) {
    window.availableTraits = traits;
  }

  const listToRender = window.availableTraits || traits || [];
  if (!listToRender || listToRender.length === 0) {
    tbody.innerHTML = '<tr><td colspan="3" style="text-align:center; padding: 24px; color:#ef4444;">No se pudieron cargar los rasgos del servidor remoto.</td></tr>';
    return;
  }

  const traitsWithProbs = window.calculateTraitProbabilities(listToRender);
  const escapeFn = typeof window.escapeHtml === 'function' ? window.escapeHtml : (s => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'));

  tbody.innerHTML = '';
  const fragment = document.createDocumentFragment();

  traitsWithProbs.forEach(t => {
    const tr = document.createElement('tr');
    tr.className = 'traits-index-row';

    const probFormatted = window.formatTraitProbability(t.calculatedProbability);
    const traitImg = t.imageUrl || t.image || t.imagen || t.icon || t.icono || './trait.png';
    const traitDesc = t.description || t.descripcion || t.desc || 'Sin descripción';

    tr.innerHTML = `
      <td class="traits-index-cell-name">
        <div class="traits-index-item-box">
          <img src="${traitImg}" class="traits-index-icon" onerror="this.src='./trait.png'" alt="${escapeFn(t.name || t.id)}">
          <div class="traits-index-name-wrap">
            <span class="traits-index-name">${escapeFn(t.name || t.id)}</span>
          </div>
        </div>
      </td>
      <td class="traits-index-cell-desc">
        <span class="traits-index-desc">${escapeFn(traitDesc)}</span>
      </td>
      <td class="traits-index-cell-prob">
        <span class="traits-prob-large">${probFormatted}</span>
      </td>
    `;
    fragment.appendChild(tr);
  });

  tbody.appendChild(fragment);
  console.log('[TRAITS] Tabla de index renderizada con éxito:', traitsWithProbs.length, 'rasgos');
};

window.toggleTraitsIndex = async function(e) {
  if (e && typeof e.stopPropagation === 'function') {
    e.stopPropagation();
  }
  const indexPanel = document.getElementById('traits-index-panel');
  const indexBtn = document.getElementById('traits-index-btn');
  if (!indexPanel) return;

  const isHidden = indexPanel.style.display === 'none' || indexPanel.style.display === '';
  if (isHidden) {
    indexPanel.style.display = 'flex';
    if (indexBtn) indexBtn.classList.add('active');
    await window.renderTraitsIndex();
  } else {
    indexPanel.style.display = 'none';
    if (indexBtn) indexBtn.classList.remove('active');
  }
};

window.toggleGamblingPanel = function() {
  const gamblingPanel = document.getElementById('gambling-panel');
  if (!gamblingPanel) {
    console.error('[GAMBLING] Panel no encontrado');
    return;
  }
  
  console.log('[GAMBLING] Toggle panel activado');
  
  if (gamblingPanel.style.display === 'none' || gamblingPanel.style.display === '') {
    gamblingPanel.style.display = 'block';
    
    // Ocultar panel de Rasgos si está abierto
    const traitsPanel = document.getElementById('traits-panel');
    if (traitsPanel) traitsPanel.style.display = 'none';
  } else {
    gamblingPanel.style.display = 'none';
  }
};

// Variable global para almacenar el modo de juego seleccionado antes de la batalla
window.selectedGameMode = 'clasico7v7';

// Variables globales de batalla - Inicializar al principio
window.battleState = {
  playerTeam: [],
  opponentTeam: [],
  playerCurrentCard: null,
  opponentCurrentCard: null,
  playerScore: 0,
  opponentScore: 0,
  difficulty: null,
  opponentName: null,
  opponentTitle: null,
  opponentAvatar: null,
  // Nuevo: control de turnos y jugabilidad
  currentTurn: null, // 'player' o 'opponent'
  roundWinner: null, // quien ganó la ronda anterior
  playerUsedStats: [], // stats ya usadas por el JUGADOR
  opponentUsedStats: [], // stats ya usadas por la IA (independientes)
  playerUsedCards: [], // índices de cartas ya usadas por el jugador
  opponentUsedCards: [], // índices de cartas ya usadas por el oponente
  selectedStat: null, // LA stat elegida para esta ronda (solo una)
  opponentSelectedStat: null, // La stat elegida por la IA (para el highlight)
  waitingForCardSelection: false,
  gamePhase: 'roulette', // 'roulette', 'card-selection', 'stat-selection', 'comparing', 'round-end'
  canChangeCard: true, // control para evitar cambio de carta hasta siguiente ronda
  wasTie: false, // flag para mostrar marcador de totales
  playerTotalInTie: 0, // total del jugador en caso de empate
  opponentTotalInTie: 0, // total del oponente en caso de empate
  // Poderes de batalla
  playerPowersUsed: {
    swap: false,
    powerup: false,
    nerf: false
  },
  opponentPowersUsed: {
    swap: false,
    powerup: false,
    nerf: false
  },
  playerReserveCard: null, // carta de reserva del jugador
  opponentReserveCard: null, // carta de reserva del oponente
  playerReserveCardUsed: false, // flag para saber si ya usó la carta de reserva
  opponentReserveCardUsed: false, // flag para saber si ya usó la carta de reserva
  playerPowerUpActive: false, // flag para saber si el power up está activo
  opponentPowerUpActive: false, // flag para saber si el power up está activo
  playerNerfActive: false, // flag para saber si el nerf está activo
  opponentNerfActive: false, // flag para saber si el nerf está activo
  playerConsecutiveLosses: 0, // contador de rondas perdidas consecutivas
  opponentConsecutiveLosses: 0, // contador de rondas perdidas consecutivas
  // ===== MODIFICADORES DE STATS POR PODERES =====
  // Sistema para rastrear cambios en stats causados por POWER UP y NERF
  // Estructura: { cardId: { ninjutsu: 3, velocidad: -5, all: 0 } }
  statModifiers: {},
  powerUpStats: { player: 0, opponent: 0 }, // +3 a todas las stats cuando está activo
  nerfedStat: null // { side: 'opponent', stat: 'ninjutsu', reduction: 5 }
};

// Estado de vista completa de colección
let showCompleteCollection = false;
let collectionViewType = 'cards'; // 'cards' o 'powers'

// Estado de ordenación de colección
let currentSortMode = 'media';
const sortModeNames = {
  obtained: 'Obtención',
  alphabetic: 'Alfabético',
  quality: 'Calidad',
  media: 'Media',
  duplicates: 'Repetidos'
};

// Modos de ordenación para poderes
const powerSortModeNames = {
  obtained: 'Obtención',
  quality: 'Calidad',
  alphabetic: 'Alfabético',
  uses: 'Usos'
};

// Estado de filtrado de colección
let currentFilterType = 'none';
let currentFilterValue = null;
let currentFilterType2 = 'none';
let currentFilterValue2 = null;
let availableProcedencias = [];
let availableOwners = [];
const REMOTE_CATALOG_CARDS_URL = 'https://hugom1307.github.io/kvrcards-catalog/cards.json';
let refreshCollectionFilterMenus = null;
let remoteFilterOptionsCache = {
  fetchedAt: 0,
  procedencias: [],
  owners: [],
  pending: null
};
let collectionSearchText = '';
const filterNames = {
  none: '----',
  quality: 'Calidad',
  media: 'Media',
  procedencia: 'Procedencia',
  owner: 'Owner'
};

// Nombres de filtros para poderes
const powerFilterNames = {
  none: '----',
  quality: 'Calidad',
  uses: 'Usos'
};


// ==================== DEFINICIONES DE PODERES ====================
// IMPORTANTE: Debe estar al principio para evitar errores de inicialización

const POWER_DEFINITIONS = {
  swap: {
    name: 'RESERVA',
    description: 'Cambia tu carta actual por tu carta de reserva, pudiendo ser usada en cualquier momento y dando la ventaja táctica en el momento decisivo.'
  },
  powerup: {
    name: 'POWER UP',
    description: 'Aumenta todas las estadísticas de tu carta en +3 puntos durante un turno dándole un Power Up a tu personaje.'
  },
  nerf: {
    name: 'NERF',
    description: 'Reduce la estadística elegida por tu oponente en -5 puntos, saboteando su estrategia. Para utilizarlo debes ir perdiendo la partida.'
  },
  anulo: {
    name: 'ANULO',
    description: 'Bloquea una estadística del rival durante este turno, obligándolo a elegir una diferente.'
  },
  intercambio: {
    name: 'INTERCAMBIO',
    description: 'Copia temporalmente una carta aleatoria del mazo inicial del rival durante este turno.'
  }
};

// Mostrar animación de activación de poder
const collectionCountDisplay = document.getElementById('collection-count-display');
const cardsDiv = document.getElementById('cards');
const shopDiv = document.getElementById('shop-packs');
// Contenedores de misiones por categoría
const missionsFundamentalsContainer = document.getElementById('missions-fundamentals-container');
const missionsDailyContainer = document.getElementById('missions-daily-container');
const missionsWeeklyContainer = document.getElementById('missions-weekly-container');
const missionsFeaturedContainer = document.getElementById('missions-featured-container');
const missionsLimitedContainer = document.getElementById('missions-limited-container');
const missionsContainer = document.getElementById('missions-container'); // Legacy, puede no existir
const refreshMissionsBtn = document.getElementById('refresh-missions');
const kizunasContainer = document.getElementById('kizunas-container');
const refreshKizunasBtn = document.getElementById('refresh-kizunas');
const completedMissionsSection = document.getElementById('completed-missions-section');
const completedMissionsContainer = document.getElementById('completed-missions-container');
const toggleCompletedBtn = document.getElementById('toggle-completed-missions');
const toggleCompletedIcon = document.getElementById('toggle-completed-icon');
const completedCount = document.getElementById('completed-count');
// Debug refs
const debugModal = document.getElementById('debug-modal');
const closeDebugBtn = document.getElementById('close-debug');
const hudDebugBtn = document.getElementById('hud-debug-mode');
// Rankings refs
const rankingsModal = document.getElementById('rankings-modal');
const closeRankingsBtn = document.getElementById('close-rankings');
const rankingsList = document.getElementById('rankings-list');
const weeklyResetTimer = document.getElementById('weekly-reset-timer');
const resetCountdown = document.getElementById('reset-countdown');
// User Profile Modal refs
const userProfileModal = document.getElementById('user-profile-modal');
const closeUserProfileBtn = document.getElementById('close-user-profile');
// Wallet refs
const wCoins = document.getElementById('wallet-coins-amt');
const wKvr = document.getElementById('wallet-kvr-amt');
const wCoinsIcon = document.getElementById('wallet-coins-icon');
const wKvrIcon = document.getElementById('wallet-kvr-icon');
// HUD & perfil refs
const hudToggle = document.getElementById('hud-toggle');
const settingsToggle = document.getElementById('settings-btn');
const rankingsToggle = document.getElementById('rankings-btn');
// Filter refs
const sortButton = document.getElementById('sort-button');
const sortOptions = document.getElementById('sort-options');
const filterButton = document.getElementById('filter-button');
const filterOptions = document.getElementById('filter-options');
const mediaInput = document.getElementById('media-input');
const applyMediaFilter = document.getElementById('apply-media-filter');
const filterButton2 = document.getElementById('filter-button-2');
const filterOptions2 = document.getElementById('filter-options-2');
const mediaInput2 = document.getElementById('media-input-2');
const applyMediaFilter2 = document.getElementById('apply-media-filter-2');
const collectionSearchInput = document.getElementById('collection-search');
const hudPanel = document.getElementById('hud-panel');
const hudUsername = document.getElementById('hud-username');
const hudChangeName = document.getElementById('hud-change-name');
const hudSyncCommands = document.getElementById('hud-sync-commands');
// Lightbox refs
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxClose = document.getElementById('lightbox-close');
const lightboxSell = document.getElementById('lightbox-sell');
// Pack details modal refs
const packDetailsModal = document.getElementById('pack-details-modal');
const packDetailsTitle = document.getElementById('pack-details-title');
const packDetailsContent = document.getElementById('pack-details-content');
const packDetailsClose = document.getElementById('pack-details-close');
// Pack overlay refs
const packOverlay = document.getElementById('pack-overlay');
const packCard = document.getElementById('pack-card');
const packCardImg = document.getElementById('pack-card-img');
const packCardMaskImg = document.getElementById('pack-card-mask-img');
const specialRevealBanner = document.getElementById('special-reveal-banner');
const specialRevealOwnerBanner = (() => {
  const existing = document.getElementById('special-reveal-owner-banner');
  if (existing) return existing;
  if (!packOverlay) return null;

  const banner = document.createElement('div');
  banner.id = 'special-reveal-owner-banner';
  banner.className = 'special-reveal-banner secondary';
  packOverlay.appendChild(banner);
  return banner;
})();
const specialRevealContinueHint = (() => {
  const existing = document.getElementById('special-reveal-continue-hint');
  if (existing) return existing;
  if (!packOverlay) return null;

  const hint = document.createElement('div');
  hint.id = 'special-reveal-continue-hint';
  hint.className = 'special-reveal-continue-hint';
  hint.textContent = '(click para continuar)';
  packOverlay.appendChild(hint);
  return hint;
})();
const revealViewport = document.getElementById('reveal-viewport');
const packBody = document.getElementById('pack-body');
const sparksEl = document.getElementById('sparks');
const skipAnimationBtn = document.getElementById('skip-animation');
// Buy modal refs
const buyModal = document.getElementById('buy-modal');
const buyTitle = document.getElementById('buy-title');
const buyMsg = document.getElementById('buy-message');
const buyCoinsBtn = document.getElementById('buy-coins');
const buyKvrBtn = document.getElementById('buy-kvr');
const buyCancelBtn = document.getElementById('buy-cancel');
let buyCtx = { packId: '', price: { coins: 0, kvr: 0 } };

// Sell modal refs
const sellModal = document.getElementById('sell-modal');
const sellTitle = document.getElementById('sell-title');
const sellMessage = document.getElementById('sell-message');
const sellConfirm = document.getElementById('sell-confirm');
const sellCancel = document.getElementById('sell-cancel');
let sellCtx = { cardId: '', cardName: '', cardValue: 0 };

// Pack results action buttons
const saveAllBtn = document.getElementById('save-all-btn');
const sellAllBtn = document.getElementById('sell-all-btn');
const sellAllModal = document.getElementById('sell-all-modal');
const sellAllMessage = document.getElementById('sell-all-message');
const sellAllValue = document.getElementById('sell-all-value');
const sellAllConfirm = document.getElementById('sell-all-confirm');
const sellAllCancel = document.getElementById('sell-all-cancel');
let pendingCards = []; // Cartas del sobre pendientes de guardar/vender
let pendingCardIds = []; // IDs de las cartas pendientes

// Settings modal refs
const settingsModal = document.getElementById('settings-modal');
const settingsClose = document.getElementById('settings-close');
const settingsTabs = document.querySelectorAll('.settings-tab');
const settingsPanels = document.querySelectorAll('.settings-panel');

// Code redemption refs
const codeInput = document.getElementById('code-input');
const redeemCodeBtn = document.getElementById('redeem-code-btn');
const codeMessage = document.getElementById('code-message');
const redeemedCodesList = document.getElementById('redeemed-codes-list');

