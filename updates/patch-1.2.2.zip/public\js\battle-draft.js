// ==================== CONTROLADOR DE FASE DE ELECCIÓN (DRAFT) — V2 REDESIGN ====================

(function() {
  'use strict';

  // Estado del draft local
  let draftState = {
    round: 1,
    team: [],
    currentChoices: [],
    selectedGameMode: 'eleccion_clasico',
    isWaitingForRound: false
  };

  // Inicializar listeners del sistema de Draft
  function initDraftSocketListeners() {
    if (!window.onlineState || !window.onlineState.socket) {
      console.warn('[DRAFT] Socket no disponible todavía. Se reintentará al conectar.');
      return;
    }

    const socket = window.onlineState.socket;

    console.log('[DRAFT] 🔌 Configurando socket listeners para Draft...');

    // Evento: Inicio del Draft
    socket.off('draft-start').on('draft-start', (data) => {
      console.log('[DRAFT] Evento draft-start recibido:', data);
      
      // Registrar información en estado online
      window.onlineState.matchId = data.matchId;
      draftState.selectedGameMode = data.gameMode || 'eleccion_clasico';
      draftState.round = data.round || 1;
      draftState.team = [];
      draftState.isWaitingForRound = false;
      draftState.assignedPowers = null;

      // Iniciar UI
      startDraftPhase(draftState.selectedGameMode);
      handleIncomingRoundOptions(data.choices);
    });

    // Evento: Siguientes opciones de ronda (ahora asíncrono — llega individualmente)
    socket.off('draft-round-options').on('draft-round-options', (data) => {
      console.log('[DRAFT] Evento draft-round-options recibido:', data);
      draftState.round = data.round || draftState.round + 1;
      draftState.isWaitingForRound = false;
      handleIncomingRoundOptions(data.choices);
    });

    // Evento: Draft completado en el servidor (individual por jugador)
    socket.off('draft-complete').on('draft-complete', (data) => {
      console.log('[DRAFT] Evento draft-complete recibido:', data);
      draftState.isWaitingForRound = false;
      
      // Mostrar HUD de confirmación de poderes
      showPowersConfirmationHUD();
    });

    // Evento: Oponente listo (estándar, actualiza UI de espera)
    socket.on('opponent-ready', (data) => {
      console.log('[DRAFT] Oponente listo. Actualizando waiting overlay...');
      const oppStatusEl = document.getElementById('draft-opponent-ready-status');
      if (oppStatusEl) {
        oppStatusEl.textContent = 'RIVAL: Listo';
        oppStatusEl.className = 'player-ready-badge ready';
      }
    });
  }

  // Hook para registrar listeners en la reconexión/conexión
  document.addEventListener('DOMContentLoaded', () => {
    // Si ya hay socket conectado, inicializar de inmediato
    if (window.onlineState && window.onlineState.socket) {
      initDraftSocketListeners();
    } else {
      // Monitorear cuando se asigne el socket
      const checkInterval = setInterval(() => {
        if (window.onlineState && window.onlineState.socket) {
          initDraftSocketListeners();
          clearInterval(checkInterval);
        }
      }, 500);
    }
  });

  // Exportar función initDraftSocketListeners al contexto global por si se reconecta
  window.initDraftSocketListeners = initDraftSocketListeners;

  /**
   * Inicia la visualización e intercepción del Draft
   */
  function startDraftPhase(gameMode) {
    console.log('[DRAFT] Iniciando Fase de Elección de Modo:', gameMode);
    
    // Configurar estado
    draftState.selectedGameMode = gameMode;
    draftState.round = draftState.round || 1;
    draftState.isWaitingForRound = false;
    draftState.assignedPowers = null;

    // CRÍTICO: Limpiar exhaustivamente cualquier estado de batalla residual
    if (typeof window.cleanUpBattleCompletely === 'function') {
      window.cleanUpBattleCompletely({ gameMode: gameMode, isOnline: true, resetDraft: false });
    }
    if (typeof window.cleanAllBattleStatButtonsAndDisplays === 'function') {
      window.cleanAllBattleStatButtonsAndDisplays();
    } else {
      window.battleState = window.battleState || {};
      window.battleState.playerUsedStats = [];
      window.battleState.opponentUsedStats = [];
      window.battleState.playerUsedCards = [];
      window.battleState.opponentUsedCards = [];
      window.battleState.selectedStat = null;
      window.battleState.opponentSelectedStat = null;
      window.battleState.annulledStat = null;
      window.battleState.playerScore = 0;
      window.battleState.opponentScore = 0;
      window.battleState.gameMode = gameMode;
      window.battleState.isOnline = true;
    }

    // Actualizar badges e instrucciones de UI
    const modeBadge = document.getElementById('draft-mode-badge');
    if (modeBadge) {
      modeBadge.textContent = gameMode === 'eleccion_alternativo' ? 'Elección Alternativo' : 'Elección Clásico';
    }

    const counterEl = document.getElementById('draft-current-round');
    if (counterEl) counterEl.textContent = draftState.round;

    // Ocultar vistas de juego anteriores
    const screensToHide = [
      'main-menu',
      'game-mode-selection',
      'game-type-selection',
      'online-friendly-selection',
      'matchmaking-screen',
      'friend-battle-screen',
      'team-builder'
    ];
    screensToHide.forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = 'none';
    });

    // Mostrar contenedor principal de juego y draft view
    const gameView = document.getElementById('game-view');
    if (gameView) gameView.style.display = 'block';

    const draftView = document.getElementById('draft-view');
    if (draftView) draftView.style.display = 'flex';

    // Ocultar overlays y HUDs finales
    const popover = document.getElementById('draft-trait-popover');
    if (popover) popover.style.display = 'none';
    
    const confirmationHUD = document.getElementById('draft-confirmation-panel');
    if (confirmationHUD) confirmationHUD.style.display = 'none';

    const waitingOverlay = document.getElementById('draft-waiting-overlay');
    if (waitingOverlay) waitingOverlay.style.display = 'none';

    // Mostrar center stage y cartas
    const centerStage = document.querySelector('.draft-center-stage');
    if (centerStage) centerStage.style.display = 'flex';

    const choicesCtn = document.querySelector('.draft-choices-container');
    if (choicesCtn) choicesCtn.style.display = 'flex';

    // Música de tensión al comenzar el draft
    if (typeof playBackgroundMusic === 'function') {
      console.log('[DRAFT] Iniciando música de tensión para fase de elección...');
      playBackgroundMusic('music/sfx/riser.mp3');
    }

    const instructionEl = document.getElementById('draft-instruction');
    if (instructionEl) {
      instructionEl.textContent = 'Elige una carta';
      instructionEl.style.display = 'block';
    }

    // Dibujar slots vacíos en la barra lateral (miniaturas)
    renderDraftSlots();
  }

  window.startDraftPhase = startDraftPhase;

  /**
   * Dibuja la barra de slots de equipo como miniaturas visuales
   */
  function renderDraftSlots() {
    const slots = document.querySelectorAll('.draft-slot-thumb');
    slots.forEach((slot, index) => {
      slot.classList.remove('filled', 'draft-slot-pop');
      slot.style.backgroundImage = '';
      
      const numberOverlay = slot.querySelector('.slot-number-overlay');
      if (numberOverlay) {
        numberOverlay.style.opacity = '1';
        if (index === 7) {
          numberOverlay.textContent = 'R';
        } else {
          numberOverlay.textContent = String(index + 1);
        }
      }
      
      // Si la carta ya existe en el equipo temporal, dibujarla
      if (draftState.team && draftState.team[index]) {
        const card = draftState.team[index];
        fillSlotWithThumbnail(slot, card);
      }
    });
  }

  /**
   * Rellena un slot con la miniatura de la carta
   */
  function fillSlotWithThumbnail(slot, card) {
    slot.classList.add('filled');
    slot.style.backgroundImage = `url('${card.imageUrl || card.imagen || ''}')`;
    
    const numberOverlay = slot.querySelector('.slot-number-overlay');
    if (numberOverlay) {
      numberOverlay.style.opacity = '0';
    }
  }

  /**
   * Carga y procesa la pareja de opciones recibidas de la ronda actual
   */
  function handleIncomingRoundOptions(choices) {
    if (!choices || choices.length < 2) return;
    
    draftState.currentChoices = choices;
    
    // Actualizar contador
    const counterEl = document.getElementById('draft-current-round');
    if (counterEl) counterEl.textContent = draftState.round;

    // Renderizar opciones (solo imagen + trait)
    renderChoiceCard('draft-choice-a', choices[0], 0);
    renderChoiceCard('draft-choice-b', choices[1], 1);
  }

  /**
   * Renderiza una carta de opción en el DOM — SOLO IMAGEN + TRAIT ICON (sin texto, stats, nombre ni media)
   */
  function renderChoiceCard(containerId, card, choiceIndex) {
    const cardEl = document.getElementById(containerId);
    if (!cardEl) return;

    // Limpiar clases de calidad anteriores
    cardEl.className = 'draft-choice-card clickable-card';
    cardEl.style.opacity = '1';
    cardEl.style.cursor = 'pointer';
    
    // Asignar clase de calidad para el borde con glow dinámico (sanitizar para evitar espacios en DOMTokenList)
    const rawQuality = String(card.quality || card.calidad || 'Plata').toLowerCase().trim();
    rawQuality.split(/\s+/).filter(Boolean).forEach(cls => {
      cardEl.classList.add(cls);
    });
    const hyphenated = rawQuality.replace(/\s+/g, '-');
    if (hyphenated) {
      cardEl.classList.add(hyphenated);
    }

    // Construir icono de Trait (si existe)
    let traitIconHTML = '';
    if (card.trait) {
      traitIconHTML = `
        <div class="card-trait-icon" title="Habilidad: ${card.trait.name}">
          <img src="${card.trait.imageUrl}" alt="${card.trait.name}">
        </div>
      `;
    }

    // SOLO imagen artística a pantalla completa + icono de trait
    cardEl.innerHTML = `
      <img src="${card.imageUrl || card.imagen || ''}" alt="Carta" class="draft-card-img" onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=%22http://www.w3.org/2000/svg%22 width=%22300%22 height=%22420%22><rect fill=%22%23374151%22 width=%22100%25%22 height=%22100%25%22/><text fill=%22%239CA3AF%22 font-size=%2216%22 x=%2250%25%22 y=%2250%25%22 dominant-baseline=%22middle%22 text-anchor=%22middle%22>?</text></svg>'">
      ${traitIconHTML}
    `;

    // Configurar click en la carta (para elegirla)
    cardEl.onclick = (e) => {
      // Si hizo clic en el icono de Trait, no elegir la carta (se gestiona por separado)
      if (e.target.closest('.card-trait-icon')) {
        return;
      }
      
      selectDraftCard(card, choiceIndex);
    };

    // Configurar hover en el icono de Trait si existe
    if (card.trait) {
      const traitIcon = cardEl.querySelector('.card-trait-icon');
      if (traitIcon) {
        traitIcon.onmouseenter = (e) => {
          showTraitPopover(card.trait, e);
        };
        traitIcon.onmousemove = (e) => {
          showTraitPopover(card.trait, e);
        };
        traitIcon.onmouseleave = (e) => {
          const popover = document.getElementById('draft-trait-popover');
          if (popover) popover.style.display = 'none';
        };
      }
    }
  }

  /**
   * Muestra la mini pestaña flotante a la derecha con la información del Trait
   */
  function showTraitPopover(trait, e) {
    const popover = document.getElementById('draft-trait-popover');
    const popoverIcon = document.getElementById('popover-trait-icon');
    const popoverName = document.getElementById('popover-trait-name');
    const popoverDesc = document.getElementById('popover-trait-desc');
    const closeBtn = document.getElementById('close-trait-popover');

    if (!popover || !popoverIcon || !popoverName || !popoverDesc || !closeBtn) return;

    popoverIcon.src = trait.imageUrl || '';
    popoverIcon.onerror = () => { popoverIcon.src = './trait.png'; };
    popoverName.textContent = trait.name || 'Rasgo';
    popoverDesc.textContent = trait.description || 'Efecto de habilidad especial.';

    // Calcular posición dinámica según coordenadas de cursor e
    if (e && typeof e.clientX === 'number') {
      let x = e.clientX + 20;
      let y = e.clientY - 80; // Offset hacia arriba para centrar popover con cursor

      const popoverWidth = 280;
      const popoverHeight = 220; // Estimación
      const screenWidth = window.innerWidth;
      const screenHeight = window.innerHeight;

      // Evitar salirse horizontalmente
      if (x + popoverWidth > screenWidth) {
        x = e.clientX - popoverWidth - 20;
      }
      // Evitar salirse verticalmente
      if (y + popoverHeight > screenHeight) {
        y = screenHeight - popoverHeight - 20;
      }
      if (y < 10) {
        y = 10;
      }

      popover.style.left = `${x}px`;
      popover.style.top = `${y}px`;
      popover.style.right = 'auto';
      popover.style.transform = 'none';
    }

    // Mostrar popover
    popover.style.display = 'flex';

    // Cerrar al pulsar el botón close
    closeBtn.onclick = (event) => {
      event.stopPropagation();
      popover.style.display = 'none';
    };
  }

  /**
   * Procesa la elección de una carta
   */
  function selectDraftCard(card, choiceIndex) {
    if (draftState.isWaitingForRound) return;
    
    // Protección anti-duplicados por personaje canónico (incluyendo diferentes versiones y calidades)
    const isDuplicate = draftState.team.some(t => {
      if (!t) return false;
      if (typeof window.areSamePlayerCards === 'function') {
        return window.areSamePlayerCards(t, card);
      }
      return t.id === card.id || (t.name && card.name && t.name.toLowerCase().trim() === card.name.toLowerCase().trim());
    });

    if (isDuplicate) {
      console.warn('[DRAFT] Personaje ya seleccionado previamente en el equipo:', card.name);
      alert(`⚠️ Ya tienes una versión de ${card.name || 'este personaje'} en tu equipo de Draft.\n\nNo se permiten personajes duplicados.`);
      return;
    }
    
    console.log('[DRAFT] Carta seleccionada:', card.name, 'Índice de elección:', choiceIndex);
    draftState.isWaitingForRound = true;

    // Cerrar pestaña de traits
    const popover = document.getElementById('draft-trait-popover');
    if (popover) popover.style.display = 'none';

    // Añadir carta al equipo temporal
    const currentRoundIndex = draftState.round - 1;
    draftState.team[currentRoundIndex] = card;

    // Animación visual de miniatura en la barra lateral
    const slots = document.querySelectorAll('.draft-slot-thumb');
    const activeSlot = slots[currentRoundIndex];
    
    if (activeSlot) {
      fillSlotWithThumbnail(activeSlot, card);
      // Trigger pop animation
      activeSlot.classList.remove('draft-slot-pop');
      void activeSlot.offsetWidth; // Forzar reflow
      activeSlot.classList.add('draft-slot-pop');
    }

    // Deshabilitar los clics de las opciones brevemente (se reactivarán con las nuevas opciones)
    document.querySelectorAll('.draft-choice-card').forEach(el => {
      el.style.opacity = '0.4';
      el.style.cursor = 'default';
      el.onclick = null;
    });

    // Si es la primera carta elegida (ronda 1), cortar la música de tensión
    if (draftState.round === 1) {
      if (typeof stopBackgroundMusic === 'function') {
        console.log('[DRAFT] Primera carta seleccionada. Deteniendo música de tensión.');
        stopBackgroundMusic();
      }
    }

    // Reproducir sonido de selección
    if (typeof playSFX === 'function') {
      playSFX('cardSelect');
    }

    // Emitir elección al servidor
    if (window.onlineState && window.onlineState.socket && window.onlineState.matchId) {
      window.onlineState.socket.emit('draft-card-chosen', {
        matchId: window.onlineState.matchId,
        cardId: card.id,
        round: draftState.round,
        traitId: card.trait ? card.trait.id : null
      });
      console.log('[DRAFT] Choice emitido al servidor:', card.id, 'ronda:', draftState.round);
    }
  }

  /**
   * Muestra el panel final con los 3 poderes tácticos pre-asignados
  /**
   * Genera o devuelve los 3 poderes aleatorios distintos seleccionados para este Draft
   */
  function getRandomDraftPowers() {
    if (Array.isArray(draftState.assignedPowers) && draftState.assignedPowers.length === 3) {
      return draftState.assignedPowers;
    }
    const pool = ['swap', 'powerup', 'nerf', 'anulo', 'intercambio'];
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    draftState.assignedPowers = shuffled.slice(0, 3);
    console.log('[DRAFT] 🎲 3 Poderes aleatorios generados para esta partida:', draftState.assignedPowers);
    return draftState.assignedPowers;
  }

  /**
   * Muestra el HUD de confirmación de equipo completo y poderes asignados
   */
  async function showPowersConfirmationHUD() {
    console.log('[DRAFT] Draft completado con 8 cartas. Mostrando HUD de poderes...');
    
    // Ocultar el center stage completo (cartas, instrucción, VS divider)
    const centerStage = document.querySelector('.draft-center-stage');
    if (centerStage) centerStage.style.display = 'none';

    // Mostrar panel de confirmación (posicionado absoluto en el centro)
    const confirmationPanel = document.getElementById('draft-confirmation-panel');
    if (confirmationPanel) confirmationPanel.style.display = 'flex';

    // Obtener los 3 poderes aleatorios asignados para esta run
    const chosenPowers = getRandomDraftPowers();

    // Poblar dinámicamente el listado de poderes desde el catálogo remoto/local
    try {
      const allPowersRes = (window.kvrcards && typeof window.kvrcards.getAllPowers === 'function')
        ? await window.kvrcards.getAllPowers()
        : [];
      const listCtn = confirmationPanel.querySelector('.assigned-powers-list');
      if (listCtn) {
        listCtn.innerHTML = chosenPowers.map(pId => {
          const powerDef = (typeof POWER_DEFINITIONS !== 'undefined' && POWER_DEFINITIONS[pId])
            ? POWER_DEFINITIONS[pId]
            : { name: String(pId).toUpperCase(), description: 'Poder táctico' };

          let fromCatalog = null;
          if (Array.isArray(allPowersRes)) {
            fromCatalog = allPowersRes.find(p => {
              const pid = (p.id || '').toLowerCase().trim();
              if (pId === 'swap') return ['swap', 'reserva', 'reserve_card'].includes(pid);
              if (pId === 'powerup') return ['powerup', 'power_up'].includes(pid);
              return pid === pId;
            });
          }

          const imgUrl = fromCatalog?.imageUrl || `./assets/powers/${pId}.svg`;
          const name = fromCatalog?.name || powerDef.name;
          const desc = fromCatalog?.description || powerDef.description;

          return `
            <div class="power-item-badge">
              <div class="power-icon">
                <img src="${imgUrl}" alt="${name}" onerror="this.onerror=null; this.src='./assets/powers/ultimate_power.svg';">
              </div>
              <div class="power-info">
                <strong>${name}</strong>
                <small>${desc}</small>
              </div>
            </div>
          `;
        }).join('');
      }
    } catch (e) {
      console.error('[DRAFT] Error cargando los detalles dinámicos de los poderes:', e);
    }

    // Configurar botón continuar
    const btnContinue = document.getElementById('draft-continue-btn');
    if (btnContinue) {
      btnContinue.onclick = () => {
        confirmAndSendDraftTeam();
      };
    }
  }

  /**
   * Calcula buffs, prepara el payload estándar de player-ready y se bloquea en espera de red (Overlay rojo)
   */
  function confirmAndSendDraftTeam() {
    console.log('[DRAFT] Confirmando equipo del draft...');

    try {
      // 1. Validar que tengamos las 8 cartas
      if (draftState.team.length < 8) {
        alert('Error: No has completado las 8 elecciones de equipo.');
        return;
      }

      // 2. Mapear las cartas al formato estándar que el motor de batalla requiere
      const teamToSend = draftState.team.map((card, index) => {
        const uniqueId = `draft_${index}_` + Date.now();
        const traitId = card.trait ? card.trait.id : null;
        
        return {
          id: card.id,
          uniqueId: uniqueId,
          name: card.name,
          nombre: card.name,
          media: Number(card.media) || 75,
          stats: card.stats || [60, 60, 60, 60, 60, 60],
          imageUrl: (typeof card.imageUrl === 'string' && !card.imageUrl.startsWith('data:image/') && card.imageUrl.length <= 500) ? card.imageUrl : '',
          quality: card.quality || 'Plata',
          calidad: card.quality || 'Plata',
          procedencia: card.procedencia || 'Desconocido',
          owner: card.owner || 'Nadie',
          traitId: traitId,
          opponentTraitId: traitId, // Duplicar para compatibilidad total de battle-core
          isReserve: index === 7 // La octava carta es la de reserva
        };
      });

      console.log('[DRAFT] Cartas preparadas para player-ready:', teamToSend);

      // 3. Asignar los 3 poderes tácticos aleatorios generados
      const powersToSend = draftState.assignedPowers || getRandomDraftPowers();
      console.log('[DRAFT] Enviando 3 poderes tácticos aleatorios a la batalla:', powersToSend);

      if (window.battleState) {
        window.battleState.playerPowers = [...powersToSend];
      }
      window.selectedTeamPowers = [...powersToSend];

      // 4. Calcular buffs tácticos locales para pasarlos al servidor
      let teamBuffs = { buffs: [], byProcedencia: {}, byOwner: {} };
      if (typeof calculateBattleBuffs === 'function') {
        teamBuffs = calculateBattleBuffs(teamToSend);
        console.log('[DRAFT] Buffs calculados para el equipo drafteado:', teamBuffs);
      }

      // 5. Preparar Traits para el servidor
      const traitsForServer = [];
      const traitsMap = {};
      
      draftState.team.forEach((card, index) => {
        if (card.trait) {
          const uniqueId = teamToSend[index].uniqueId;
          traitsMap[uniqueId] = card.trait.id;
          
          if (!traitsForServer.some(t => t.id === card.trait.id)) {
            traitsForServer.push({
              id: card.trait.id,
              name: card.trait.name,
              effect: card.trait.effect,
              imageUrl: card.trait.imageUrl
            });
          }
        }
      });

      console.log('[DRAFT] Map de traits drafteados:', traitsMap);

      // 6. Guardar todo localmente en window.battleState antes de enviar para reuso modular
      window.battleState = window.battleState || {};
      window.battleState.isOnline = true;
      window.battleState.gameMode = draftState.selectedGameMode;
      window.battleState.playerTeam = teamToSend;
      window.battleState.playerPowers = powersToSend;
      window.battleState.playerBuffs = teamBuffs;
      window.battleState.cardTraitsMap = traitsMap;
      window.battleState.availableTraits = traitsForServer;

      // Resetear estrictamente stats y cartas usadas para la batalla que va a comenzar
      window.battleState.playerUsedStats = [];
      window.battleState.opponentUsedStats = [];
      window.battleState.playerUsedCards = [];
      window.battleState.opponentUsedCards = [];
      window.battleState.selectedStat = null;
      window.battleState.opponentSelectedStat = null;
      window.battleState.annulledStat = null;
      window.battleState.playerScore = 0;
      window.battleState.opponentScore = 0;
      window.battleState.currentRound = 0;
      window.battleState.playerPowersUsed = { swap: false, powerup: false, nerf: false, anulo: false, intercambio: false };
      window.battleState.opponentPowersUsed = { swap: false, powerup: false, nerf: false, anulo: false, intercambio: false };

      if (typeof window.cleanAllBattleStatButtonsAndDisplays === 'function') {
        window.cleanAllBattleStatButtonsAndDisplays();
      }

      // Configurar carta de reserva local
      window.battleState.playerReserveCard = teamToSend[7];
      window.battleState.playerReserveCardIndex = 7;

      console.log('[DRAFT] 💾 battleState local guardado con éxito!');

      // 7. Mostrar la pantalla de bloqueo en ROJO (draft-waiting-overlay)
      const waitingOverlay = document.getElementById('draft-waiting-overlay');
      if (waitingOverlay) {
        waitingOverlay.style.display = 'flex';
      }

      // Poner mi badge en Listo
      const myStatusEl = document.getElementById('draft-player-ready-status');
      if (myStatusEl) {
        myStatusEl.textContent = 'TÚ: Listo';
        myStatusEl.className = 'player-ready-badge ready';
      }

      // 8. Emitir el evento estándar player-ready
      if (window.onlineState && window.onlineState.socket && window.onlineState.matchId) {
        console.log('[DRAFT] 📤 Emitiendo player-ready al servidor...');
        window.onlineState.socket.emit('player-ready', {
          matchId: window.onlineState.matchId,
          team: teamToSend,
          powers: powersToSend,
          availableTraits: traitsForServer,
          buffs: teamBuffs
        });
        window.onlineState.teamReadySent = true;
      } else {
        throw new Error('Socket o MatchId no disponible al enviar player-ready');
      }

    } catch (err) {
      console.error('[DRAFT] Error crítico al confirmar equipo:', err);
      alert('❌ Error al enviar el equipo drafteado al servidor. Por favor, recarga el juego.\n\nDetalles: ' + err.message);
    }
  }

  function resetDraftState() {
    console.log('[DRAFT] Resetting local draft state...');
    draftState.round = 1;
    draftState.team = [];
    draftState.currentChoices = [];
    draftState.isWaitingForRound = false;

    // Resetear battleState residual
    if (window.battleState) {
      window.battleState.playerUsedStats = [];
      window.battleState.opponentUsedStats = [];
      window.battleState.playerUsedCards = [];
      window.battleState.opponentUsedCards = [];
      window.battleState.selectedStat = null;
      window.battleState.opponentSelectedStat = null;
      window.battleState.annulledStat = null;
    }

    if (typeof window.cleanAllBattleStatButtonsAndDisplays === 'function') {
      window.cleanAllBattleStatButtonsAndDisplays();
    }

    // Resetear opacidades y clics de las cartas de elección
    document.querySelectorAll('.draft-choice-card').forEach(el => {
      el.style.opacity = '1';
      el.style.cursor = 'pointer';
    });

    // Ocultar overlays y HUDs
    const popover = document.getElementById('draft-trait-popover');
    if (popover) popover.style.display = 'none';
    
    const confirmationHUD = document.getElementById('draft-confirmation-panel');
    if (confirmationHUD) confirmationHUD.style.display = 'none';

    const waitingOverlay = document.getElementById('draft-waiting-overlay');
    if (waitingOverlay) waitingOverlay.style.display = 'none';

    const draftView = document.getElementById('draft-view');
    if (draftView) draftView.style.display = 'none';
  }

  window.resetDraftState = resetDraftState;

})();
