// ============================================
// SISTEMA DE OBJETOS (ITEMS SYSTEM)
// ============================================

(function () {
  'use strict';

  var itemCatalog = [];
  var itemCatalogMap = new Map();
  var isItemsLoading = false;

  // Calidades de objetos en orden estricto de mayor a menor:
  // Knight > Mítico > Legendario > Épico > Raro > Común
  var QUALITY_RANKS = {
    'knight': 1,
    'mitico': 2,
    'mítico': 2,
    'mythic': 2,
    'legendario': 3,
    'legendary': 3,
    'epico': 4,
    'épico': 4,
    'epic': 4,
    'raro': 5,
    'rare': 5,
    'comun': 6,
    'común': 6,
    'common': 6
  };

  var QUALITY_NAMES = {
    1: 'Knight',
    2: 'Mítico',
    3: 'Legendario',
    4: 'Épico',
    5: 'Raro',
    6: 'Común'
  };

  function normalizeQualityKey(calidad) {
    if (!calidad) return 'comun';
    return String(calidad)
      .toLowerCase()
      .trim()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');
  }

  function getItemQualityRank(calidad) {
    var key = normalizeQualityKey(calidad);
    return QUALITY_RANKS[key] !== undefined ? QUALITY_RANKS[key] : 99;
  }

  function getItemQualityDisplayName(calidad) {
    var rank = getItemQualityRank(calidad);
    if (QUALITY_NAMES[rank]) return QUALITY_NAMES[rank];
    if (calidad && typeof calidad === 'string') {
      return calidad.charAt(0).toUpperCase() + calidad.slice(1);
    }
    return 'Común';
  }

  function getItemQualityCssClass(calidad) {
    var key = normalizeQualityKey(calidad);
    if (key.includes('knight')) return 'quality-knight';
    if (key.includes('mitic') || key.includes('mythic')) return 'quality-mitico';
    if (key.includes('legend')) return 'quality-legendario';
    if (key.includes('epic')) return 'quality-epico';
    if (key.includes('rar')) return 'quality-raro';
    return 'quality-comun';
  }

  // Cargar catálogo de objetos desde electron o URL remota de respaldo
  async function loadAllItems(force) {
    if (force === void 0) force = false;
    if (!force && itemCatalog.length > 0) {
      return itemCatalog;
    }
    if (isItemsLoading) {
      return itemCatalog;
    }
    isItemsLoading = true;

    try {
      var rawItems = null;
      if (window.kvrcards && typeof window.kvrcards.getAllItems === 'function') {
        try {
          rawItems = await window.kvrcards.getAllItems();
        } catch (ipcErr) {
          console.warn('[ITEMS] Error en window.kvrcards.getAllItems():', ipcErr);
        }
      }

      // Si no hay items desde Electron (por ejemplo si la red o cache aún no descargó), fallback remoto
      if (!Array.isArray(rawItems) || rawItems.length === 0) {
        var remoteUrls = [
          'https://hugom1307.github.io/kvrcards-catalog/items.json',
          'https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/items.json'
        ];
        for (var i = 0; i < remoteUrls.length; i++) {
          try {
            var res = await fetch(remoteUrls[i] + '?t=' + Date.now());
            if (res.ok) {
              var data = await res.json();
              if (Array.isArray(data)) {
                rawItems = data;
                break;
              } else if (data && Array.isArray(data.items)) {
                rawItems = data.items;
                break;
              } else if (data && typeof data === 'object' && data.id) {
                rawItems = [data];
                break;
              } else if (data && typeof data === 'object') {
                var vals = Object.values(data).filter(function (v) { return v && v.id; });
                if (vals.length > 0) {
                  rawItems = vals;
                  break;
                }
              }
            }
          } catch (fetchErr) {
            // Ignorar y probar siguiente url
          }
        }
      }

      var itemsList = Array.isArray(rawItems) ? rawItems : [];
      itemCatalog = itemsList;
      itemCatalogMap.clear();

      for (var j = 0; j < itemsList.length; j++) {
        var it = itemsList[j];
        if (it && it.id) {
          var idStr = String(it.id).trim();
          itemCatalogMap.set(idStr, it);
          itemCatalogMap.set(idStr.toLowerCase(), it);
        }
      }

      window.itemCatalog = itemCatalog;
      window.itemCatalogMap = itemCatalogMap;
      console.log('[ITEMS] Catálogo de objetos cargado:', itemCatalog.length);
      return itemCatalog;
    } catch (err) {
      console.error('[ITEMS] Error fatal cargando objetos:', err);
      return itemCatalog;
    } finally {
      isItemsLoading = false;
    }
  }

  // Buscar objeto en catálogo
  function findItemInCatalog(identifier) {
    if (!identifier) return null;
    var id = '';
    if (typeof identifier === 'string') {
      id = identifier.trim();
    } else if (typeof identifier === 'object') {
      id = String(identifier.id || identifier.itemId || identifier.item || '').trim();
      if (!id && identifier.name) {
        // Búsqueda por nombre
        var targetName = String(identifier.name).toLowerCase().trim();
        for (var k = 0; k < itemCatalog.length; k++) {
          var entry = itemCatalog[k];
          var eName = String(entry.name || entry.nombre || '').toLowerCase().trim();
          if (eName === targetName) return entry;
        }
      }
    }
    if (!id) return identifier && typeof identifier === 'object' ? identifier : null;

    if (itemCatalogMap.has(id)) return itemCatalogMap.get(id);
    if (itemCatalogMap.has(id.toLowerCase())) return itemCatalogMap.get(id.toLowerCase());

    // Si aún no está en catálogo, generar fallback estructurado
    if (identifier && typeof identifier === 'object') {
      return {
        id: id,
        name: identifier.name || identifier.nombre || id,
        description: identifier.description || identifier.descripcion || '',
        calidad: identifier.calidad || identifier.quality || 'Común',
        imageUrl: identifier.imageUrl || identifier.image || identifier.imagen || './assets/default-item.png'
      };
    }
    return {
      id: id,
      name: id,
      description: '',
      calidad: 'Común',
      imageUrl: './assets/default-item.png'
    };
  }

  // Ordenar lista de objetos por calidad (Knight > Mítico > Legendario > Épico > Raro > Común)
  function sortItemsByQuality(itemsList) {
    if (!Array.isArray(itemsList)) return [];
    return itemsList.slice().sort(function (a, b) {
      var qA = a.calidad || a.quality || '';
      var qB = b.calidad || b.quality || '';
      var rankA = getItemQualityRank(qA);
      var rankB = getItemQualityRank(qB);
      if (rankA !== rankB) {
        return rankA - rankB; // Menor rank = mayor calidad (1 = Knight)
      }
      var nameA = String(a.name || a.nombre || a.id || '').toLowerCase();
      var nameB = String(b.name || b.nombre || b.id || '').toLowerCase();
      return nameA.localeCompare(nameB);
    });
  }

  // Ventana modal / lightbox con detalles de un objeto
  function openItemLightbox(item, count) {
    if (!item) return;
    if (count === void 0) count = 1;

    var existingModal = document.getElementById('item-details-modal');
    if (existingModal) {
      existingModal.remove();
    }

    var name = item.name || item.nombre || item.id || 'Objeto';
    var desc = item.description || item.descripcion || 'Sin descripción disponible.';
    var calidad = item.calidad || item.quality || 'Común';
    var qualityDisplay = getItemQualityDisplayName(calidad);
    var qualityClass = getItemQualityCssClass(calidad);
    var imageUrl = item.imageUrl || item.image || item.imagen || './assets/default-item.png';

    var modal = document.createElement('div');
    modal.id = 'item-details-modal';
    modal.className = 'item-modal-overlay';
    modal.innerHTML = `
      <div class="item-modal-container ${qualityClass}" role="dialog" aria-modal="true" aria-label="${name}">
        <button type="button" class="item-modal-close" id="item-modal-close-btn">&times;</button>
        <div class="item-modal-body">
          <div class="item-modal-visual">
            <div class="item-modal-glow-wrap ${qualityClass}">
              <img src="${imageUrl}" alt="${name}" class="item-modal-img" onerror="this.src='./assets/default-item.png'">
            </div>
            <div class="item-modal-badges">
              <span class="item-quality-pill ${qualityClass}">${qualityDisplay}</span>
              <span class="item-count-pill">Posees: <strong>x${count}</strong></span>
            </div>
          </div>
          <div class="item-modal-info">
            <h2 class="item-modal-title ${qualityClass}">${name}</h2>
            <div class="item-modal-divider"></div>
            <div class="item-modal-description-wrapper">
              <h4 class="item-modal-section-title">Descripción</h4>
              <p class="item-modal-description">${desc}</p>
            </div>
            <div class="item-modal-actions">
              <button type="button" class="item-modal-btn-confirm" id="item-modal-close-action">Cerrar</button>
            </div>
          </div>
        </div>
      </div>
    `;

    function closeModal() {
      modal.classList.remove('active');
      document.removeEventListener('keydown', handleKeyDown);
      setTimeout(function () {
        modal.remove();
      }, 200);
    }

    function handleKeyDown(e) {
      if (e.key === 'Escape') closeModal();
    }

    modal.addEventListener('click', function (e) {
      if (e.target === modal) closeModal();
    });

    document.body.appendChild(modal);
    document.addEventListener('keydown', handleKeyDown);

    var closeBtn = modal.querySelector('#item-modal-close-btn');
    var actionBtn = modal.querySelector('#item-modal-close-action');
    if (closeBtn) closeBtn.onclick = closeModal;
    if (actionBtn) actionBtn.onclick = closeModal;

    requestAnimationFrame(function () {
      modal.classList.add('active');
    });
  }

  // Renderizar la colección de objetos del usuario
  async function renderItemsCollection(customContainer) {
    var container = customContainer || window.activeCollectionContainer || (typeof collectionDiv !== 'undefined' ? collectionDiv : null) || document.getElementById('collection-cards') || document.getElementById('collection');
    if (!container) {
      console.warn('[ITEMS] No se encontró el contenedor de la colección (#collection-cards)');
      return;
    }

    container.innerHTML = '<div class="items-loading-spinner" style="text-align:center; padding: 60px; color:#fbbf24; font-size:18px;">Cargando objetos...</div>';

    try {
      await loadAllItems();

      var inv = null;
      if (window.kvrcards && typeof window.kvrcards.getItemsInventory === 'function') {
        try {
          inv = await window.kvrcards.getItemsInventory();
        } catch (e) {
          console.warn('[ITEMS] Error obteniendo inventario de objetos:', e);
        }
      }

      var ownedMap = {};
      if (inv && inv.ok && inv.items && typeof inv.items === 'object') {
        ownedMap = inv.items;
      } else if (window.kvrcards && typeof window.kvrcards.getInventory === 'function') {
        var fullInv = await window.kvrcards.getInventory();
        if (fullInv && fullInv.items && typeof fullInv.items === 'object') {
          ownedMap = fullInv.items;
        }
      }

      // Filtrar items que el usuario posee con cantidad > 0
      var ownedList = [];
      var totalOwnedItemsCount = 0;

      for (var id in ownedMap) {
        if (!Object.prototype.hasOwnProperty.call(ownedMap, id)) continue;
        var count = Number(ownedMap[id]) || 0;
        if (count > 0) {
          var itemObj = findItemInCatalog(id);
          ownedList.push({
            item: itemObj,
            count: count
          });
          totalOwnedItemsCount += count;
        }
      }

      // Ordenar por calidad: Knight > Mítico > Legendario > Épico > Raro > Común
      ownedList.sort(function (a, b) {
        var rankA = getItemQualityRank(a.item.calidad || a.item.quality);
        var rankB = getItemQualityRank(b.item.calidad || b.item.quality);
        if (rankA !== rankB) return rankA - rankB;
        var nameA = String(a.item.name || a.item.nombre || a.item.id || '').toLowerCase();
        var nameB = String(b.item.name || b.item.nombre || b.item.id || '').toLowerCase();
        return nameA.localeCompare(nameB);
      });

      // Si el usuario no tiene ningún objeto en su inventario:
      if (ownedList.length === 0) {
        container.innerHTML = `
          <div class="items-empty-state">
            <div class="items-empty-icon">🎒</div>
            <div class="items-empty-text">Aún no tienes ningún objeto en tu inventario, obten objetos en eventos para fortalecer tus cartas y los podrás ver aquí a detalle.</div>
          </div>
        `;

        if (typeof updateCollectionCountDisplay === 'function') {
          updateCollectionCountDisplay(0, 0, false);
        }
        return;
      }

      // Aplicar filtro de búsqueda por texto si existe
      var searchInput = (typeof collectionSearchInput !== 'undefined' ? collectionSearchInput : null) || document.getElementById('collection-search') || document.getElementById('collection-search-input');
      var searchQuery = searchInput ? searchInput.value.trim().toLowerCase() : '';
      var filteredList = ownedList;

      if (searchQuery) {
        filteredList = ownedList.filter(function (entry) {
          var name = String(entry.item.name || entry.item.nombre || entry.item.id || '').toLowerCase();
          var desc = String(entry.item.description || entry.item.descripcion || '').toLowerCase();
          var qual = String(entry.item.calidad || entry.item.quality || '').toLowerCase();
          return name.includes(searchQuery) || desc.includes(searchQuery) || qual.includes(searchQuery);
        });
      }

      if (typeof updateCollectionCountDisplay === 'function') {
        updateCollectionCountDisplay(filteredList.length, ownedList.length, false);
      }

      if (filteredList.length === 0) {
        container.innerHTML = '<div style="text-align: center; padding: 60px; color: #94a3b8; font-size: 16px;">🔍 No se encontraron objetos que coincidan con la búsqueda.</div>';
        return;
      }

      // Renderizar grid de objetos
      var grid = document.createElement('div');
      grid.className = 'items-collection-grid';

      filteredList.forEach(function (entry) {
        var it = entry.item;
        var count = entry.count;
        var name = it.name || it.nombre || it.id || 'Objeto';
        var calidad = it.calidad || it.quality || 'Común';
        var qualityDisplay = getItemQualityDisplayName(calidad);
        var qualityClass = getItemQualityCssClass(calidad);
        var imageUrl = it.imageUrl || it.image || it.imagen || './assets/default-item.png';

        var card = document.createElement('div');
        card.className = `item-card ${qualityClass}`;
        card.setAttribute('data-item-id', it.id || '');
        card.title = `${name} (${qualityDisplay}) - Haz clic para ver detalles`;

        card.innerHTML = `
          <div class="item-card-inner">
            <div class="item-card-image-box">
              <img src="${imageUrl}" alt="${name}" class="item-card-image" onerror="this.src='./assets/default-item.png'">
              <span class="item-card-count-badge">x${count}</span>
              <span class="item-card-quality-tag ${qualityClass}">${qualityDisplay}</span>
            </div>
            <div class="item-card-name-wrapper">
              <span class="item-card-name">${name}</span>
            </div>
          </div>
        `;

        card.addEventListener('click', function () {
          openItemLightbox(it, count);
        });

        grid.appendChild(card);
      });

      container.innerHTML = '';
      container.appendChild(grid);
    } catch (renderErr) {
      console.error('[ITEMS] Error al renderizar colección de objetos:', renderErr);
      container.innerHTML = '<div style="text-align: center; padding: 40px; color: #ef4444;">Error al cargar tus objetos. Intenta nuevamente.</div>';
    }
  }

  // Exponer API global en window
  window.itemCatalog = itemCatalog;
  window.itemCatalogMap = itemCatalogMap;
  window.loadAllItems = loadAllItems;
  window.findItemInCatalog = findItemInCatalog;
  window.getItemQualityRank = getItemQualityRank;
  window.getItemQualityDisplayName = getItemQualityDisplayName;
  window.getItemQualityCssClass = getItemQualityCssClass;
  window.sortItemsByQuality = sortItemsByQuality;
  window.openItemLightbox = openItemLightbox;
  window.renderItemsCollection = renderItemsCollection;

  // Precargar catálogo de objetos en segundo plano
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      loadAllItems().catch(function () {});
    });
  } else {
    loadAllItems().catch(function () {});
  }
})();
