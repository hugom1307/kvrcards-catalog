// ==================== SISTEMA DE TRAITS ====================

// Usar variables globales en window para evitar problemas de scope
if (typeof window.availableTraits === 'undefined' || !Array.isArray(window.availableTraits) || window.availableTraits.length === 0) {
  window.availableTraits = typeof window.getKnownTraitsList === 'function' ? window.getKnownTraitsList() : [];
}
var availableTraits = window.availableTraits;

if (typeof window.cardTraitsMap === 'undefined') {
  window.cardTraitsMap = {};
}
var cardTraitsMap = window.cardTraitsMap;

if (typeof window.selectedTraitCard === 'undefined') {
  window.selectedTraitCard = null;
}
var selectedTraitCard = window.selectedTraitCard;

var isTraitRouletteSpinning = false;
var activeRouletteTimeout = null;
var activeHideTimeout = null;

if (typeof window.traitsSystemInitialized === 'undefined') {
  window.traitsSystemInitialized = false;
}

// Carga directa y exclusiva desde el JSON remoto oficial en GitHub
async function fetchRemoteTraitsDirectly() {
  const urls = [
    `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/traits.json?t=${Date.now()}`,
    `https://hugom1307.github.io/kvrcards-catalog/traits.json?t=${Date.now()}`
  ];
  for (const url of urls) {
    try {
      const res = await fetch(url, { cache: 'no-store' });
      if (res.ok) {
        const json = await res.json();
        const list = Array.isArray(json) ? json : (Array.isArray(json?.traits) ? json.traits : []);
        if (list.length > 0) {
          console.log(`[TRAITS] ${list.length} rasgos cargados directamente del JSON remoto oficial (${url})`);
          return list;
        }
      }
    } catch (err) {
      console.warn(`[TRAITS] Error consultando ${url}:`, err);
    }
  }
  return [];
}
window.fetchRemoteTraitsDirectly = fetchRemoteTraitsDirectly;
window.fetchFallbackTraits = fetchRemoteTraitsDirectly;

async function ensureTraitsLoaded() {
  if (Array.isArray(window.availableTraits) && window.availableTraits.length > 0) {
    availableTraits = window.availableTraits;
    return window.availableTraits;
  }
  try {
    if (window.kvrcards && typeof window.kvrcards.getAllTraits === 'function') {
      const loaded = await window.kvrcards.getAllTraits();
      const list = Array.isArray(loaded) ? loaded : (Array.isArray(loaded?.traits) ? loaded.traits : []);
      if (list.length > 0) {
        window.availableTraits = list;
        availableTraits = list;
        return list;
      }
    }
  } catch (e) {
    console.warn('[TRAITS] Error en ensureTraitsLoaded vía IPC:', e);
  }
  try {
    const remote = await fetchRemoteTraitsDirectly();
    if (Array.isArray(remote) && remote.length > 0) {
      window.availableTraits = remote;
      availableTraits = remote;
      return remote;
    }
  } catch (e) {
    console.warn('[TRAITS] Error en ensureTraitsLoaded vía remoto:', e);
  }
  if (typeof window.getKnownTraitsList === 'function') {
    window.availableTraits = window.getKnownTraitsList();
    availableTraits = window.availableTraits;
    return window.availableTraits;
  }
  return window.availableTraits || [];
}
window.ensureTraitsLoaded = ensureTraitsLoaded;

async function initTraitsSystem() {
  console.log('[TRAITS] Inicializando sistema...');
  const traitCardSlot = document.getElementById('trait-card-slot');
  const applyTraitBtn = document.getElementById('apply-trait-btn');
  const closeIndexBtn = document.getElementById('close-traits-index-btn');
  
  // 1. Asignar listeners inmediatamente para garantizar respuesta instantanea de UI
  if (traitCardSlot) {
    traitCardSlot.onclick = () => {
      if (isTraitRouletteSpinning) return;
      openCardSelectorForTraits();
    };
  }
  
  if (applyTraitBtn) {
    applyTraitBtn.onclick = () => {
      if (!window.selectedTraitCard || isTraitRouletteSpinning) return;
      startTraitRoulette();
    };
  }

  if (closeIndexBtn) {
    closeIndexBtn.onclick = () => {
      const indexPanel = document.getElementById('traits-index-panel');
      if (indexPanel) indexPanel.style.display = 'none';
      const indexBtn = document.getElementById('traits-index-btn');
      if (indexBtn) indexBtn.classList.remove('active');
    };
  }
  
  // 2. Cargar traits disponibles
  try {
    if (window.kvrcards && window.kvrcards.getAllTraits) {
      const loaded = await window.kvrcards.getAllTraits();
      availableTraits = Array.isArray(loaded) ? loaded : (Array.isArray(loaded?.traits) ? loaded.traits : []);
      if (availableTraits.length === 0) {
        availableTraits = await fetchFallbackTraits();
      }
    } else {
      availableTraits = await fetchFallbackTraits();
    }
  } catch (e) {
    console.warn('[TRAITS] Error cargando traits desde backend, usando fallback:', e);
    availableTraits = await fetchFallbackTraits();
  }
  if (!Array.isArray(availableTraits) || availableTraits.length === 0) {
    if (typeof window.getKnownTraitsList === 'function') {
      availableTraits = window.getKnownTraitsList();
    }
  }
  window.availableTraits = availableTraits;
  console.log('[TRAITS] Cargados:', availableTraits.length);
  
  // 3. Cargar cardTraitsMap desde inventario
  try {
    if (window.kvrcards && window.kvrcards.getInventory) {
      const inv = await window.kvrcards.getInventory();
      if (inv && (inv.cardTraits || (inv.ok && inv.cardTraits))) {
        cardTraitsMap = inv.cardTraits || {};
        window.cardTraitsMap = cardTraitsMap;
        console.log('[TRAITS] cardTraitsMap cargado:', Object.keys(cardTraitsMap).length);
      }
    }
  } catch (e) {
    console.error('[TRAITS] Error cargando cardTraitsMap:', e);
  }

  window.traitsSystemInitialized = true;
  console.log('[TRAITS] Sistema inicializado correctamente');
}

async function renderTraitsPanel() {
  selectedTraitCard = window.selectedTraitCard;
  const balanceValue = document.getElementById('traits-balance-value');
  const applyBtn = document.getElementById('apply-trait-btn');
  
  // Actualizar saldo
  let traitsBalance = 0;
  try {
    if (window.kvrcards && typeof window.kvrcards.getWallet === 'function') {
      const wallet = await window.kvrcards.getWallet();
      traitsBalance = Number(wallet?.traits) || 0;
    }
  } catch (errWallet) {
    console.warn('[TRAITS] Error obteniendo saldo de traits:', errWallet);
  }
  if (balanceValue) balanceValue.textContent = traitsBalance;

  // Banner informativo en el panel si el modo debug de calidad forzada está activo
  try {
    const forcedRarities = (typeof window.getForcedTraitRarities === 'function') ? window.getForcedTraitRarities() : [];
    let debugNoticeEl = document.getElementById('traits-debug-forced-notice');
    if (forcedRarities && forcedRarities.length > 0) {
      if (!debugNoticeEl) {
        debugNoticeEl = document.createElement('div');
        debugNoticeEl.id = 'traits-debug-forced-notice';
        debugNoticeEl.style.cssText = 'background: rgba(79, 70, 229, 0.35); border: 1px solid #6366f1; color: #e0e7ff; padding: 6px 12px; border-radius: 6px; font-size: 12px; font-weight: 700; text-align: center; margin: 8px 0; display: flex; align-items: center; justify-content: space-between;';
        const panelBox = document.querySelector('.traits-roulette-box') || document.getElementById('traits-panel');
        if (panelBox && panelBox.parentNode) {
          panelBox.parentNode.insertBefore(debugNoticeEl, panelBox);
        }
      }
      if (debugNoticeEl) {
        debugNoticeEl.innerHTML = '<span>🔧 DEBUG: Tiradas forzadas a [' + forcedRarities.map(r => r.toUpperCase()).join(', ') + ']</span><button id="btn-quick-disable-forced-traits" style="background:#ef4444; color:#fff; border:none; padding:2px 8px; border-radius:4px; font-size:11px; cursor:pointer;">Restablecer</button>';
        document.getElementById('btn-quick-disable-forced-traits')?.addEventListener('click', () => {
          if (typeof window.setForcedTraitRarities === 'function') {
            window.setForcedTraitRarities([]);
          }
          renderTraitsPanel();
        });
      }
    } else if (debugNoticeEl) {
      debugNoticeEl.remove();
    }
  } catch (eBanner) {}
  
  // Actualizar estado del botón
  if (applyBtn) {
    if (isTraitRouletteSpinning) {
      applyBtn.disabled = true;
      const isLegendaryOpen = document.getElementById('trait-result')?.style.display === 'block';
      const isMythicOpen = document.getElementById('mythic-trait-overlay')?.style.display === 'flex';
      const isKnightOpen = document.getElementById('knight-trait-overlay')?.style.display === 'flex';
      if (isLegendaryOpen || isMythicOpen || isKnightOpen) {
        applyBtn.textContent = 'Confirma el Rasgo...';
      } else {
        applyBtn.textContent = 'Girando...';
      }
    } else if (traitsBalance < 1) {
      applyBtn.disabled = true;
      applyBtn.innerHTML = 'Sin Traits suficientes (1 <img src="./trait.png" class="currency-icon-small" style="vertical-align: middle;">)';
    } else if (!selectedTraitCard) {
      applyBtn.disabled = true;
      applyBtn.textContent = 'Selecciona una carta';
    } else {
      applyBtn.disabled = false;
      applyBtn.innerHTML = 'Aplicar Rasgo (1 <img src="./trait.png" class="currency-icon-small" style="vertical-align: middle;">)';
    }
  }
  
  // Actualizar slot de carta
  updateTraitCardSlot();

  // Si el panel de índice está visible, actualizarlo también
  const indexPanel = document.getElementById('traits-index-panel');
  if (indexPanel && indexPanel.style.display !== 'none' && typeof renderTraitsIndex === 'function') {
    renderTraitsIndex();
  }
}
window.renderTraitsPanel = renderTraitsPanel;
if (typeof globalThis !== 'undefined') globalThis.renderTraitsPanel = renderTraitsPanel;
window.initTraitsSystem = initTraitsSystem;
if (typeof globalThis !== 'undefined') globalThis.initTraitsSystem = initTraitsSystem;

function updateTraitCardSlot() {
  selectedTraitCard = window.selectedTraitCard || selectedTraitCard;
  const slot = document.getElementById('trait-card-slot');
  if (!slot) return;
  const img = document.getElementById('trait-selected-card-img');
  const placeholder = slot.querySelector('.slot-placeholder');
  const currentTraitDisplay = document.getElementById('current-trait-display');
  const currentTraitIcon = document.getElementById('current-trait-icon');
  const currentTraitName = document.getElementById('current-trait-name');
  
  if (selectedTraitCard) {
    slot.classList.add('has-card');
    const rawImg = selectedTraitCard.imageUrl || selectedTraitCard.image || selectedTraitCard.imagen || '';
    if (img) {
      img.src = (typeof normalizeAssetUrl === 'function' ? normalizeAssetUrl(rawImg) : rawImg) || rawImg;
      img.style.display = 'block';
    }
    if (placeholder) placeholder.style.display = 'none';
    
    // Mostrar rasgo actual si tiene
    let currentTraitId = selectedTraitCard.currentTraitId;
    if (!currentTraitId && !selectedTraitCard.createNew) {
      if (selectedTraitCard.instanceId && cardTraitsMap[selectedTraitCard.instanceId]) {
        const traitEntry = cardTraitsMap[selectedTraitCard.instanceId];
        currentTraitId = traitEntry?.traitId || (typeof traitEntry === 'string' ? traitEntry : null);
      } else if (selectedTraitCard.uniqueId && cardTraitsMap[selectedTraitCard.uniqueId]) {
        const traitEntry = cardTraitsMap[selectedTraitCard.uniqueId];
        currentTraitId = traitEntry?.traitId || (typeof traitEntry === 'string' ? traitEntry : null);
      }
    }

    if (currentTraitId && availableTraits && availableTraits.length > 0) {
      const trait = availableTraits.find(t => t.id === currentTraitId);
      if (trait) {
        if (currentTraitDisplay) currentTraitDisplay.style.display = 'flex';
        if (currentTraitIcon) currentTraitIcon.src = trait.imageUrl;
        if (currentTraitName) currentTraitName.textContent = trait.name;
      } else {
        if (currentTraitDisplay) currentTraitDisplay.style.display = 'none';
      }
    } else {
      if (currentTraitDisplay) currentTraitDisplay.style.display = 'flex';
      if (currentTraitIcon) currentTraitIcon.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="%23fbbf24" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>';
      if (currentTraitName) currentTraitName.textContent = 'Sin Rasgo';
    }
  } else {
    slot.classList.remove('has-card');
    if (img) img.style.display = 'none';
    if (placeholder) placeholder.style.display = 'flex';
    if (currentTraitDisplay) currentTraitDisplay.style.display = 'none';
  }
}
window.updateTraitCardSlot = updateTraitCardSlot;
if (typeof globalThis !== 'undefined') globalThis.updateTraitCardSlot = updateTraitCardSlot;

function openCardSelectorForTraits() {
  const modal = document.getElementById('trait-card-selector-modal');
  const grid = document.getElementById('trait-card-selector-grid');
  const searchInput = document.getElementById('trait-card-search');
  const closeBtn = document.getElementById('close-trait-selector');
  
  if (!modal || !grid) return;
  
  // Cargar cartas del inventario
  loadTraitSelectorCards('');
  
  // Mostrar modal
  modal.style.display = 'flex';
  
  // Buscar
  searchInput.value = '';
  searchInput.oninput = () => {
    loadTraitSelectorCards(searchInput.value.toLowerCase());
  };
  
  // Cerrar
  closeBtn.onclick = () => {
    modal.style.display = 'none';
  };
  
  // Cerrar al hacer clic fuera
  modal.onclick = (e) => {
    if (e.target === modal) {
      modal.style.display = 'none';
    }
  };
}

async function loadTraitSelectorCards(searchQuery) {
  const grid = document.getElementById('trait-card-selector-grid');
  if (!grid) return;
  
  grid.innerHTML = '<div style="color:#9ca3af;text-align:center;padding:40px;">Cargando cartas...</div>';
  
  try {
    const [allCards, inv] = await Promise.all([
      window.kvrcards.getAllCards(),
      window.kvrcards.getInventory()
    ]);
    
    const ownedCardIds = inv.ok ? inv.cards : {};
    cardTraitsMap = inv.ok && inv.cardTraits ? inv.cardTraits : {};
    
    console.log('[TRAIT SELECTOR] cardTraitsMap:', cardTraitsMap);
    
    // Filtrar cartas que el usuario posee
    const userCards = allCards.filter(card => {
      const count = ownedCardIds[card.id] || 0;
      if (count <= 0) return false;
      if (searchQuery && !card.name.toLowerCase().includes(searchQuery)) return false;
      return true;
    });

    // Ordenar automáticamente por media descendente (más altas primero)
    userCards.sort((a, b) => {
      const mediaA = Number(a.media) || 0;
      const mediaB = Number(b.media) || 0;
      if (mediaB !== mediaA) return mediaB - mediaA;
      return String(a.name || '').localeCompare(String(b.name || ''));
    });
    
    if (userCards.length === 0) {
      grid.innerHTML = '<div style="color:#9ca3af;text-align:center;padding:40px;">No tienes cartas</div>';
      return;
    }
    
    grid.innerHTML = '';
    
    // NUEVO SISTEMA: Organizar traits por cardId
    const traitsByCard = {};
    for (const [instanceId, data] of Object.entries(cardTraitsMap)) {
      if (data && data.cardId && data.traitId) {
        if (!traitsByCard[data.cardId]) {
          traitsByCard[data.cardId] = [];
        }
        traitsByCard[data.cardId].push({ instanceId, traitId: data.traitId });
      } else if (typeof data === 'string') {
        let cardId = instanceId;
        if (instanceId.includes('_')) {
          const parts = instanceId.split('_');
          if (parts.length >= 3 && !isNaN(parts[parts.length - 1]) && !isNaN(parts[parts.length - 2])) {
            cardId = parts.slice(0, -2).join('_');
          }
        }
        if (!traitsByCard[cardId]) traitsByCard[cardId] = [];
        traitsByCard[cardId].push({ instanceId, traitId: data });
      }
    }
    
    const processedCards = [];
    
    for (const card of userCards) {
      const count = ownedCardIds[card.id] || 0;
      const traitsForThisCard = (traitsByCard[card.id] || []).slice(0, count);
      const countWithTrait = traitsForThisCard.length;
      const countWithoutTrait = Math.max(0, count - countWithTrait);
      
      console.log(`[TRAIT SELECTOR] Card ${card.name} (${card.id}) - Total: ${count}, With trait: ${countWithTrait}, Without: ${countWithoutTrait}`);
      
      // Añadir cada instancia con trait (pueden sobrescribirse)
      traitsForThisCard.forEach(({ instanceId, traitId }) => {
        processedCards.push({ 
          cardWithTrait: { ...card, instanceId: instanceId }, 
          traitId: traitId, 
          isUnique: true,
          hasExistingTrait: true
        });
      });
      
      // Añadir cartas sin trait
      if (countWithoutTrait > 0) {
        processedCards.push({ 
          cardWithoutTrait: card,
          traitId: null, 
          isUnique: false,
          count: countWithoutTrait,
          hasExistingTrait: false
        });
      }
    }

    // Ordenar processedCards estrictamente por media descendente
    processedCards.sort((a, b) => {
      const cardA = a.cardWithTrait || a.cardWithoutTrait;
      const cardB = b.cardWithTrait || b.cardWithoutTrait;
      const mediaA = Number(cardA?.media) || 0;
      const mediaB = Number(cardB?.media) || 0;
      if (mediaB !== mediaA) return mediaB - mediaA;
      return String(cardA?.name || '').localeCompare(String(cardB?.name || ''));
    });
    
    // Renderizar todas las cartas procesadas
    for (const item of processedCards) {
      const { cardWithTrait, cardWithoutTrait, traitId, isUnique, count, hasExistingTrait } = item;
      const card = cardWithTrait || cardWithoutTrait; // Usar el objeto correcto
      
      const div = document.createElement('div');
      div.className = 'trait-selector-card';
      if (isUnique) div.classList.add('has-trait');
      
      const img = document.createElement('img');
      const rawCardImg = card.imageUrl || card.image || card.imagen || '';
      img.src = (typeof normalizeAssetUrl === 'function' ? normalizeAssetUrl(rawCardImg) : rawCardImg) || 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="140"><rect fill="%23374151" width="100%" height="100%"/></svg>';
      img.alt = card.name || 'Carta';
      
      const name = document.createElement('div');
      name.className = 'card-name';
      name.textContent = count && count > 1 ? `${card.name} x${count}` : card.name;
      
      // Mostrar indicador de trait si tiene
      if (traitId && availableTraits && availableTraits.length > 0) {
        const trait = availableTraits.find(t => t.id === traitId);
        if (trait) {
          const indicator = document.createElement('div');
          indicator.className = 'trait-indicator';
          const traitImg = document.createElement('img');
          traitImg.src = trait.imageUrl;
          traitImg.alt = trait.name;
          traitImg.title = trait.name;
          indicator.appendChild(traitImg);
          div.appendChild(indicator);
        }
      }
      
      div.appendChild(img);
      div.appendChild(name);
      
      // Al hacer clic, seleccionar carta
      div.onclick = () => {
        const selectedCard = hasExistingTrait ? cardWithTrait : cardWithoutTrait;
        console.log('[TRAIT SELECTOR CLICK] hasExistingTrait:', hasExistingTrait);
        console.log('[TRAIT SELECTOR CLICK] Selected card:', selectedCard);
        console.log('[TRAIT SELECTOR CLICK] Has instanceId:', selectedCard?.instanceId);
        console.log('[TRAIT SELECTOR CLICK] Trait ID to pass:', traitId);
        selectCardForTrait(selectedCard, traitId);
      };
      
      grid.appendChild(div);
    }
  } catch (e) {
    console.error('[TRAITS] Error cargando cartas:', e);
    grid.innerHTML = '<div style="color:#ef4444;text-align:center;padding:40px;">Error al cargar cartas</div>';
  }
}
window.loadTraitSelectorCards = loadTraitSelectorCards;
window.openCardSelectorForTraits = openCardSelectorForTraits;
if (typeof globalThis !== 'undefined') {
  globalThis.loadTraitSelectorCards = loadTraitSelectorCards;
  globalThis.openCardSelectorForTraits = openCardSelectorForTraits;
}

function selectCardForTrait(card, existingTraitId) {
  if (!card) return;
  let targetId;
  let createNew = false;
  
  console.log('[SELECT CARD] Received card:', card);
  console.log('[SELECT CARD] card.instanceId:', card?.instanceId);
  console.log('[SELECT CARD] existingTraitId:', existingTraitId);
  
  if (existingTraitId && card && card.instanceId) {
    // Carta con trait existente - sobrescribir usando el mismo instanceId
    targetId = card.instanceId;
    createNew = false;
    console.log('[TRAITS] Overwriting trait on existing instance:', targetId);
  } else {
    // Carta sin trait - enviar ID BASE al servidor con flag createNew=true
    // El servidor creará un NUEVO instanceId
    targetId = card.id;
    createNew = true;
    console.log('[TRAITS] Creating NEW trait instance for card:', targetId);
  }
  
  selectedTraitCard = {
    ...card,
    uniqueId: targetId, // Mantener compatibilidad con código existente
    createNew: createNew,
    currentTraitId: existingTraitId || null
  };
  window.selectedTraitCard = selectedTraitCard;
  
  console.log('[TRAITS] Selected card for trait:', selectedTraitCard);
  
  // Cerrar modal
  const modal = document.getElementById('trait-card-selector-modal');
  if (modal) modal.style.display = 'none';
  
  // Actualizar UI
  updateTraitCardSlot();
  renderTraitsPanel();
}
window.selectCardForTrait = selectCardForTrait;
if (typeof globalThis !== 'undefined') globalThis.selectCardForTrait = selectCardForTrait;

async function startTraitRoulette() {
  selectedTraitCard = window.selectedTraitCard;
  if (isTraitRouletteSpinning || !selectedTraitCard) return;
  
  // Validación de seguridad
  if (!availableTraits || availableTraits.length === 0) {
    alert('No hay rasgos disponibles en el catálogo.');
    return;
  }

  const rouletteContainer = document.getElementById('traits-roulette-container');
  const rouletteStrip = document.getElementById('traits-roulette-strip');
  const resultDiv = document.getElementById('trait-result');
  
  // Validar que los elementos DOM existen
  if (!rouletteContainer || !rouletteStrip || !resultDiv) {
    console.error('[TRAITS] Elementos de ruleta no encontrados');
    alert('Error: Elementos de la ruleta no están listos. Intenta abrir el panel de traits primero.');
    return;
  }
  
  try {
    // Cancelar cualquier timeout anterior
    if (activeRouletteTimeout) {
      clearTimeout(activeRouletteTimeout);
      activeRouletteTimeout = null;
    }
    if (activeHideTimeout) {
      clearTimeout(activeHideTimeout);
      activeHideTimeout = null;
    }
    
    isTraitRouletteSpinning = true;
    // Actualizar UI inmediatamente para deshabilitar el botón
    await renderTraitsPanel();
    
    rouletteContainer.style.display = 'block';
    resultDiv.style.display = 'none';
    resultDiv.classList.remove('legendary-mode');
    const prevBadge = document.getElementById('result-trait-badge');
    if (prevBadge) {
      prevBadge.className = 'trait-result-badge';
      prevBadge.textContent = '';
      prevBadge.style.setProperty('display', 'none', 'important');
    }
    
    // Generar items para la ruleta ponderada según las probabilidades calculadas
    const traitsWithProbs = calculateTraitProbabilities(availableTraits);

    // Comprobar forzado de calidad desde el modo Debug
    let forcedRarities = [];
    if (typeof window.getForcedTraitRarities === 'function') {
      forcedRarities = window.getForcedTraitRarities();
    } else {
      try {
        const stored = localStorage.getItem('kvr_debug_forced_trait_rarities');
        if (stored) forcedRarities = JSON.parse(stored);
      } catch (e) {}
    }

    let winnerTrait = null;
    let matchingForcedTraits = [];
    if (Array.isArray(forcedRarities) && forcedRarities.length > 0) {
      matchingForcedTraits = availableTraits.filter(t => forcedRarities.includes(String(t.rarity || '').toLowerCase().trim()));
      if (matchingForcedTraits.length > 0) {
        // Calcular probabilidades relativas solo entre los rasgos de las calidades forzadas
        const forcedWithProbs = calculateTraitProbabilities(matchingForcedTraits);
        winnerTrait = rollWeightedTrait(forcedWithProbs) || matchingForcedTraits[Math.floor(Math.random() * matchingForcedTraits.length)];
        console.log('[DEBUG TRAITS] Tirada FORZADA a calidades [' + forcedRarities.join(', ') + ']. Ganador:', winnerTrait.name, winnerTrait.rarity);
      }
    }

    if (!winnerTrait) {
      winnerTrait = rollWeightedTrait(traitsWithProbs) || availableTraits[Math.floor(Math.random() * availableTraits.length)];
    }
    
    // Construir tira de ruleta
    rouletteStrip.innerHTML = '';
    const totalItems = 50;
    const winnerPosition = 20;
    
    for (let i = 0; i < totalItems; i++) {
      let trait = null;
      if (i === winnerPosition) {
        trait = winnerTrait;
      } else if (matchingForcedTraits && matchingForcedTraits.length > 0 && Math.random() < 0.45) {
        trait = matchingForcedTraits[Math.floor(Math.random() * matchingForcedTraits.length)];
      } else {
        trait = rollWeightedTrait(traitsWithProbs) || availableTraits[Math.floor(Math.random() * availableTraits.length)];
      }
      
      const item = document.createElement('div');
      const itemRarity = String(trait.rarity || '').toLowerCase().trim();
      item.className = 'roulette-item' + (itemRarity === 'knight' ? ' roulette-item-knight' : (itemRarity === 'mythic' ? ' roulette-item-mythic' : ''));
      const img = document.createElement('img');
      img.src = trait.imageUrl;
      img.onerror = () => { img.src = './trait.png'; };
      item.appendChild(img);
      rouletteStrip.appendChild(item);
    }
    
    const itemWidth = 100;
    const realWidth = rouletteContainer.offsetWidth || Math.min(600, window.innerWidth - 40);
    const finalPosition = -(winnerPosition * itemWidth) + (realWidth / 2) - (itemWidth / 2);
    
    // Resetear posición
    rouletteStrip.style.transition = 'none';
    rouletteStrip.style.transform = 'translateX(0)';
    
    // Forzar reflow
    rouletteStrip.offsetHeight;
    
    // Reproducir sonido de ruleta (respetando ajuste de usuario)
    const shouldPlayRollSound = (typeof window.isTraitRollSoundEnabled === 'function')
      ? window.isTraitRollSoundEnabled()
      : (typeof isTraitRollSoundEnabled === 'function' ? isTraitRollSoundEnabled() : true);

    if (shouldPlayRollSound) {
      const traitSpinSound = new Audio('music/sfx/traitspin.wav');
      const baseSfxVol = (typeof window.sfxVolume !== 'undefined') ? window.sfxVolume : (typeof sfxVolume !== 'undefined' ? sfxVolume : 1.0);
      traitSpinSound.volume = Math.max(0, Math.min(1, 0.5 * baseSfxVol));
      traitSpinSound.play().catch(err => console.log('Error reproduciendo sonido:', err));
    }
    
    // Iniciar animación
    requestAnimationFrame(() => {
      rouletteStrip.style.transition = 'transform 5s linear';
      rouletteStrip.style.transform = `translateX(${finalPosition}px)`;
    });
    
    // Esperar a que termine
    activeRouletteTimeout = setTimeout(async () => {
      // Aplicar trait en backend
      try {
        const result = await window.kvrcards.assignTrait(selectedTraitCard.uniqueId, winnerTrait.id, selectedTraitCard.createNew);
        if (result.ok) {
          console.log('[TRAITS] Trait assigned successfully. createNew:', selectedTraitCard.createNew, 'instanceId:', result.newUniqueId);
          
          // Actualizar selectedTraitCard inmediatamente con la nueva instancia y createNew=false
          if (selectedTraitCard) {
            selectedTraitCard.uniqueId = result.newUniqueId;
            selectedTraitCard.instanceId = result.newUniqueId;
            selectedTraitCard.createNew = false;
            selectedTraitCard.currentTraitId = winnerTrait.id;
            window.selectedTraitCard = selectedTraitCard;
          }
          
          // Recargar inventario completo desde el servidor
          const inv = await window.kvrcards.getInventory();
          if (inv) {
            userInv = inv;
            ownedCardIds = inv.cards || {};
            cardTraitsMap = inv.cardTraits || {};
            
            console.log('[TRAITS] Inventory reloaded. Total traits:', Object.keys(cardTraitsMap).length);
            
            // Actualizar colección SIEMPRE (incluso si no está visible)
            console.log('[TRAITS] Updating collection view...');
            if (typeof renderCollection === 'function') await renderCollection();
            console.log('[TRAITS] Collection updated!');
          }
          
          // Actualizar UI del panel de traits
          updateTraitCardSlot();
          await renderTraitsPanel();
          
          // Efecto de hit-stop / tensión antes del reveal si es de alta rareza
          const winnerRarity = String(winnerTrait.rarity || '').toLowerCase().trim();
          if (winnerRarity === 'knight') {
            rouletteContainer.classList.add('knight-freeze');
            playKnightTensionSound();
            await new Promise(r => setTimeout(r, 900));
            rouletteContainer.classList.remove('knight-freeze');
          } else if (winnerRarity === 'mythic') {
            rouletteContainer.classList.add('mythic-freeze');
            playMythicTensionSound();
            await new Promise(r => setTimeout(r, 650));
            rouletteContainer.classList.remove('mythic-freeze');
          } else if (winnerRarity === 'legendary') {
            rouletteContainer.classList.add('legendary-freeze');
            playLegendarySound();
            await new Promise(r => setTimeout(r, 350));
            rouletteContainer.classList.remove('legendary-freeze');
          }

          // Mostrar resultado con su respectiva animación
          showTraitResult(winnerTrait);
        } else {
          alert('Error aplicando rasgo: ' + result.error);
          isTraitRouletteSpinning = false;
          rouletteContainer.style.display = 'none';
        }
      } catch (e) {
        console.error('Error:', e);
        alert('Error al procesar el rasgo');
        isTraitRouletteSpinning = false;
        rouletteContainer.style.display = 'none';
      }
      
      // Si es legendario o mítico, no rehabilitamos la ruleta hasta que el usuario pulse Aceptar / Reclamar
      const isAwaitingAccept = (winnerTrait && (
        String(winnerTrait.rarity || '').toLowerCase().trim() === 'legendary' ||
        String(winnerTrait.rarity || '').toLowerCase().trim() === 'mythic' ||
        String(winnerTrait.rarity || '').toLowerCase().trim() === 'knight'
      ));
      if (!isAwaitingAccept) {
        isTraitRouletteSpinning = false;
        activeRouletteTimeout = null;
        // Actualizar UI para rehabilitar el botón
        await renderTraitsPanel();
      } else {
        activeRouletteTimeout = null;
        await renderTraitsPanel();
      }
      
      // Ocultar ruleta después de un tiempo
      activeHideTimeout = setTimeout(() => {
        rouletteContainer.style.display = 'none';
        // Limpiar la tira de ruleta para la próxima vez
        rouletteStrip.innerHTML = '';
        rouletteStrip.style.transition = 'none';
        rouletteStrip.style.transform = 'translateX(0)';
        activeHideTimeout = null;
      }, 3000);
      
    }, 5000);

  } catch (err) {
    console.error('Error iniciando ruleta:', err);
    isTraitRouletteSpinning = false;
    activeRouletteTimeout = null;
    activeHideTimeout = null;
    rouletteContainer.style.display = 'none';
    rouletteStrip.innerHTML = '';
    rouletteStrip.style.transition = 'none';
    rouletteStrip.style.transform = 'translateX(0)';
    await renderTraitsPanel();
    alert('Error iniciando la animación de la ruleta.');
  }
}

// ==================== AUDIO SINTETIZADO (WEB AUDIO API) ====================
let traitAudioCtx = null;
function getTraitAudioContext() {
  if (!traitAudioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) traitAudioCtx = new AudioContextClass();
  }
  if (traitAudioCtx && traitAudioCtx.state === 'suspended') {
    traitAudioCtx.resume().catch(() => {});
  }
  return traitAudioCtx;
}

function playLegendarySound() {
  try {
    const ctx = getTraitAudioContext();
    if (ctx) {
      const now = ctx.currentTime;
      // Arpegio brillante en pentatónica dorada: D5, F#5, A5, C#6, E6, F#6
      const notes = [587.33, 739.99, 880.00, 1108.73, 1318.51, 1479.98];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);

        gain.gain.setValueAtTime(0.001, now + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.24, now + idx * 0.08 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.08 + 1.2);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 1.3);
      });

      // Warm bell impact
      const sub = ctx.createOscillator();
      const subGain = ctx.createGain();
      sub.type = 'sine';
      sub.frequency.setValueAtTime(220, now);
      sub.frequency.exponentialRampToValueAtTime(110, now + 0.5);
      subGain.gain.setValueAtTime(0.3, now);
      subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
      sub.connect(subGain);
      subGain.connect(ctx.destination);
      sub.start(now);
      sub.stop(now + 0.9);
    }
  } catch (e) {
    console.warn('[TRAITS-AUDIO] Error sintetizando audio legendario:', e);
  }

  // Capa con audios complementarios del juego
  try {
    const chime = new Audio('music/sfx/chime.mp3');
    chime.volume = 0.6;
    chime.play().catch(() => {});
  } catch {}
  try {
    const sparkle = new Audio('music/sfx/sparkle.mp3');
    sparkle.volume = 0.5;
    sparkle.play().catch(() => {});
  } catch {}
}

function playMythicTensionSound() {
  try {
    const ctx = getTraitAudioContext();
    if (ctx) {
      const now = ctx.currentTime;
      // Riser de tensión cósmica
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(65, now);
      osc.frequency.exponentialRampToValueAtTime(440, now + 0.7);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(180, now);
      filter.frequency.exponentialRampToValueAtTime(4500, now + 0.7);
      filter.Q.value = 6;

      gain.gain.setValueAtTime(0.01, now);
      gain.gain.exponentialRampToValueAtTime(0.4, now + 0.65);
      gain.gain.linearRampToValueAtTime(0.001, now + 0.75);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.8);
    }
  } catch (e) {}

  try {
    const riser = new Audio('music/sfx/riser.mp3');
    riser.volume = 0.7;
    riser.play().catch(() => {});
  } catch {}
}

function playMythicExplosionSound() {
  try {
    const ctx = getTraitAudioContext();
    if (ctx) {
      const now = ctx.currentTime;
      // 1. Sub-Bass Drop (Boom / 808 sub shockwave)
      const sub = ctx.createOscillator();
      const subGain = ctx.createGain();
      sub.type = 'sine';
      sub.frequency.setValueAtTime(160, now);
      sub.frequency.exponentialRampToValueAtTime(32, now + 1.2);

      subGain.gain.setValueAtTime(0.85, now);
      subGain.gain.exponentialRampToValueAtTime(0.001, now + 1.8);

      sub.connect(subGain);
      subGain.connect(ctx.destination);
      sub.start(now);
      sub.stop(now + 1.9);

      // 2. Cosmic Chord Pad (D min9 celestial: 146.83, 220.00, 329.63, 440.00, 523.25, 659.25)
      const chord = [146.83, 220.00, 329.63, 440.00, 523.25, 659.25];
      chord.forEach(freq => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'sine';
        o.frequency.setValueAtTime(freq, now + 0.05);

        g.gain.setValueAtTime(0.001, now + 0.05);
        g.gain.exponentialRampToValueAtTime(0.12, now + 0.4);
        g.gain.exponentialRampToValueAtTime(0.0001, now + 4.2);

        o.connect(g);
        g.connect(ctx.destination);
        o.start(now + 0.05);
        o.stop(now + 4.3);
      });
    }
  } catch (e) {}

  try {
    const impact = new Audio('music/sfx/impact.mp3');
    impact.volume = 0.9;
    impact.play().catch(() => {});
  } catch {}
  try {
    const woosh = new Audio('music/sfx/woosh.mp3');
    woosh.volume = 0.7;
    woosh.play().catch(() => {});
  } catch {}
}

// ==================== PRESENTACIÓN Y ANIMACIONES DE RESULTADO ====================
function showStandardTraitResult(trait) {
  const resultDiv = document.getElementById('trait-result');
  const cardDiv = resultDiv?.querySelector('.trait-result-card');
  const badge = document.getElementById('result-trait-badge');
  const icon = document.getElementById('result-trait-icon');
  const name = document.getElementById('result-trait-name');
  const desc = document.getElementById('result-trait-desc');
  const acceptBtn = document.getElementById('result-trait-accept-btn');

  if (!resultDiv) return;

  if (acceptBtn) {
    acceptBtn.style.display = 'none';
    acceptBtn.onclick = null;
  }

  resultDiv.classList.remove('legendary-mode');
  if (cardDiv) cardDiv.classList.remove('card-legendary');
  const oldSunburst = resultDiv.querySelector('.trait-legendary-sunburst');
  if (oldSunburst) oldSunburst.remove();
  const oldShockwave = resultDiv.querySelector('.trait-legendary-shockwave');
  if (oldShockwave) oldShockwave.remove();

  if (badge) {
    badge.className = 'trait-result-badge';
    badge.textContent = '';
    badge.style.setProperty('display', 'none', 'important');
  }
  if (icon) icon.src = trait.imageUrl;
  if (name) {
    name.textContent = trait.name;
    name.style.color = '';
  }
  if (desc) desc.textContent = trait.description;

  resultDiv.style.display = 'block';

  const closeResult = () => {
    resultDiv.style.display = 'none';
    const collectionSection = document.getElementById('collection-section');
    if (collectionSection && collectionSection.style.display !== 'none') {
      renderCollection();
    }
    resultDiv.removeEventListener('click', closeResult);
  };

  resultDiv.addEventListener('click', closeResult);
  setTimeout(closeResult, 3000);
}

function showLegendaryTraitResult(trait) {
  const resultDiv = document.getElementById('trait-result');
  const cardDiv = resultDiv?.querySelector('.trait-result-card');
  const badge = document.getElementById('result-trait-badge');
  const icon = document.getElementById('result-trait-icon');
  const name = document.getElementById('result-trait-name');
  const desc = document.getElementById('result-trait-desc');
  const acceptBtn = document.getElementById('result-trait-accept-btn');

  if (!resultDiv) return;

  resultDiv.classList.add('legendary-mode');
  if (cardDiv) cardDiv.classList.add('card-legendary');

  // Sunburst de fondo
  let sunburst = resultDiv.querySelector('.trait-legendary-sunburst');
  if (!sunburst) {
    sunburst = document.createElement('div');
    sunburst.className = 'trait-legendary-sunburst';
    resultDiv.insertBefore(sunburst, resultDiv.firstChild);
  }

  // Shockwave expansivo
  let shockwave = resultDiv.querySelector('.trait-legendary-shockwave');
  if (shockwave) shockwave.remove();
  shockwave = document.createElement('div');
  shockwave.className = 'trait-legendary-shockwave';
  resultDiv.appendChild(shockwave);

  // Badge
  if (badge) {
    badge.className = 'trait-result-badge badge-legendary';
    badge.textContent = '★ RASGO LEGENDARIO ★';
    badge.style.display = 'inline-block';
  }

  if (icon) icon.src = trait.imageUrl;
  if (name) {
    name.textContent = trait.name;
    name.style.color = '';
  }
  if (desc) desc.textContent = trait.description;

  // Botón aceptar para legendario (requerido para continuar)
  if (acceptBtn) {
    acceptBtn.style.display = 'inline-block';
  }

  resultDiv.style.display = 'block';

  // Sonido especial legendario
  playLegendarySound();

  // Bloquea el botón de tirar rasgo hasta pulsar Aceptar
  isTraitRouletteSpinning = true;
  if (typeof renderTraitsPanel === 'function') {
    renderTraitsPanel();
  }

  const closeResult = async () => {
    resultDiv.style.display = 'none';
    resultDiv.classList.remove('legendary-mode');
    if (cardDiv) cardDiv.classList.remove('card-legendary');
    if (sunburst) sunburst.remove();
    if (shockwave) shockwave.remove();
    if (badge) {
    badge.className = 'trait-result-badge';
    badge.textContent = '';
    badge.style.setProperty('display', 'none', 'important');
  }
    if (name) name.style.color = '';
    if (acceptBtn) {
      acceptBtn.style.display = 'none';
      acceptBtn.onclick = null;
    }

    // Desbloquear tirada al darle a aceptar
    isTraitRouletteSpinning = false;
    await renderTraitsPanel();

    const collectionSection = document.getElementById('collection-section');
    if (collectionSection && collectionSection.style.display !== 'none') {
      renderCollection();
    }
  };

  if (acceptBtn) {
    acceptBtn.onclick = (e) => {
      e.stopPropagation();
      closeResult();
    };
  }
}

function showMythicTraitCinematic(trait) {
  const overlay = document.getElementById('mythic-trait-overlay');
  const rift = document.getElementById('mythic-rift');
  const flash = document.getElementById('mythic-flash');
  const shockwave = document.getElementById('mythic-shockwave');
  const content = document.getElementById('mythic-content');
  const particles = document.getElementById('mythic-particles');
  const icon = document.getElementById('mythic-trait-icon');
  const title = document.getElementById('mythic-trait-name');
  const desc = document.getElementById('mythic-trait-desc');
  const claimBtn = document.getElementById('mythic-claim-btn');

  if (!overlay) {
    showStandardTraitResult(trait);
    return;
  }

  // Preparar contenido
  if (icon) icon.src = trait.imageUrl;
  // El usuario especificó: "En vez de rasgo mitico despertado que el cartel ponga directamente el nombre del rasgo."
  if (title) title.textContent = trait.name.toUpperCase();
  if (desc) desc.textContent = trait.description;

  // Resetear estados visuales
  overlay.style.display = 'flex';
  if (content) {
    content.style.opacity = '0';
    content.classList.remove('screen-shake');
  }
  if (flash) flash.classList.remove('active');
  if (shockwave) shockwave.classList.remove('active');
  if (rift) rift.classList.remove('active');

  // Limpiar partículas previas
  if (particles) particles.innerHTML = '';

  // Bloquea el botón de tirar rasgo hasta reclamar poder
  isTraitRouletteSpinning = true;
  if (typeof renderTraitsPanel === 'function') {
    renderTraitsPanel();
  }

  // 1. Iniciar grieta dimensional y tensión
  if (rift) {
    rift.classList.add('active');
  }

  // 2. Detonación cósmica a los 950ms
  setTimeout(() => {
    // Sonido atronador
    playMythicExplosionSound();

    // Flash y shockwave
    if (flash) flash.classList.add('active');
    if (shockwave) shockwave.classList.add('active');

    // Screen Shake en el contenido
    if (content) {
      content.style.opacity = '1';
      content.classList.add('screen-shake');
    }

    // Generar partículas cósmicas
    if (particles) {
      const colors = ['#ec4899', '#c084fc', '#8b5cf6', '#38bdf8', '#ffffff'];
      for (let i = 0; i < 40; i++) {
        const p = document.createElement('div');
        p.className = 'mythic-cosmic-particle';
        const size = Math.random() * 6 + 4;
        p.style.width = `${size}px`;
        p.style.height = `${size}px`;
        p.style.left = `${Math.random() * 100}%`;
        p.style.top = `${Math.random() * 80 + 20}%`;
        p.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        p.style.boxShadow = `0 0 12px ${p.style.backgroundColor}`;
        p.style.animationDuration = `${Math.random() * 3 + 2.5}s`;
        p.style.animationDelay = `${Math.random() * 1.5}s`;
        particles.appendChild(p);
      }
    }
  }, 950);

  let isClosing = false;
  let canClose = false;
  setTimeout(() => { canClose = true; }, 1400);

  const closeCinematic = () => {
    if (isClosing) return;
    isClosing = true;
    overlay.style.transition = 'opacity 0.4s ease';
    overlay.style.opacity = '0';
    setTimeout(async () => {
      overlay.style.display = 'none';
      overlay.style.opacity = '1';
      overlay.style.transition = '';
      if (particles) particles.innerHTML = '';
      isTraitRouletteSpinning = false;
      await renderTraitsPanel();
      const collectionSection = document.getElementById('collection-section');
      if (collectionSection && collectionSection.style.display !== 'none') {
        renderCollection();
      }
    }, 400);
  };

  if (claimBtn) {
    claimBtn.onclick = (e) => {
      e.stopPropagation();
      closeCinematic();
    };
  }

  overlay.onclick = () => {
    if (canClose) closeCinematic();
  };
}

function playKnightTensionSound() {
  try {
    const ctx = getTraitAudioContext();
    if (ctx) {
      const now = ctx.currentTime;
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sawtooth';
      osc2.type = 'sine';
      osc1.frequency.setValueAtTime(220, now);
      osc1.frequency.exponentialRampToValueAtTime(880, now + 0.85);
      osc2.frequency.setValueAtTime(110, now);
      osc2.frequency.exponentialRampToValueAtTime(440, now + 0.85);

      gain.gain.setValueAtTime(0.01, now);
      gain.gain.exponentialRampToValueAtTime(0.4, now + 0.6);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.88);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 0.9);
      osc2.stop(now + 0.9);
    }
  } catch (e) {}
}
window.playKnightTensionSound = playKnightTensionSound;

function playKnightExplosionSound() {
  try {
    const ctx = getTraitAudioContext();
    if (ctx) {
      const now = ctx.currentTime;
      // 1. Heavy Divine Sub-Bass Drop
      const sub = ctx.createOscillator();
      const subGain = ctx.createGain();
      sub.type = 'sine';
      sub.frequency.setValueAtTime(220, now);
      sub.frequency.exponentialRampToValueAtTime(24, now + 1.4);

      subGain.gain.setValueAtTime(0.95, now);
      subGain.gain.exponentialRampToValueAtTime(0.001, now + 2.2);

      sub.connect(subGain);
      subGain.connect(ctx.destination);
      sub.start(now);
      sub.stop(now + 2.3);

      // 2. Grand Knight Celestial Silver Chords (E Maj)
      const chord = [164.81, 246.94, 329.63, 493.88, 659.25, 987.77];
      chord.forEach((freq, idx) => {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = idx % 2 === 0 ? 'sine' : 'triangle';
        o.frequency.setValueAtTime(freq, now + 0.04);

        g.gain.setValueAtTime(0.001, now + 0.04);
        g.gain.exponentialRampToValueAtTime(0.16, now + 0.35);
        g.gain.exponentialRampToValueAtTime(0.0001, now + 4.8);

        o.connect(g);
        g.connect(ctx.destination);
        o.start(now + 0.04);
        o.stop(now + 5.0);
      });
    }
  } catch (e) {}

  try {
    const impact = new Audio('music/sfx/impact.mp3');
    impact.volume = 1.0;
    impact.play().catch(() => {});
  } catch {}
  try {
    const woosh = new Audio('music/sfx/woosh.mp3');
    woosh.volume = 0.85;
    woosh.play().catch(() => {});
  } catch {}
}
window.playKnightExplosionSound = playKnightExplosionSound;

function showKnightTraitCinematic(trait) {
  const overlay = document.getElementById('knight-trait-overlay');
  const beam = document.getElementById('knight-beam');
  const flash = document.getElementById('knight-flash');
  const sw1 = document.getElementById('knight-shockwave-1');
  const sw2 = document.getElementById('knight-shockwave-2');
  const content = document.getElementById('knight-content');
  const particles = document.getElementById('knight-particles');
  const icon = document.getElementById('knight-trait-icon');
  const title = document.getElementById('knight-trait-name');
  const desc = document.getElementById('knight-trait-desc');
  const claimBtn = document.getElementById('knight-claim-btn');

  if (!overlay) {
    showStandardTraitResult(trait);
    return;
  }

  // Preparar contenido
  if (icon) icon.src = trait.imageUrl;
  if (title) title.textContent = trait.name.toUpperCase();
  if (desc) desc.textContent = trait.description;

  // Resetear estados visuales
  overlay.style.display = 'flex';
  if (content) {
    content.style.opacity = '0';
    content.classList.remove('screen-shake');
  }
  if (flash) flash.classList.remove('active');
  if (sw1) sw1.classList.remove('active');
  if (sw2) sw2.classList.remove('active');
  if (beam) beam.classList.remove('active');
  if (particles) particles.innerHTML = '';

  isTraitRouletteSpinning = true;
  if (typeof renderTraitsPanel === 'function') {
    renderTraitsPanel();
  }

  // 1. Rayo divino inicial y tensión
  if (beam) beam.classList.add('active');

  // 2. Detonación cósmica suprema a los 1000ms
  setTimeout(() => {
    playKnightExplosionSound();

    if (flash) flash.classList.add('active');
    if (sw1) sw1.classList.add('active');
    if (sw2) sw2.classList.add('active');

    if (content) {
      content.style.opacity = '1';
      content.classList.add('screen-shake');
    }

    // Partículas plateadas y azul real
    if (particles) {
      const colors = ['#ffffff', '#e2e8f0', '#93c5fd', '#3b82f6', '#1d4ed8'];
      for (let i = 0; i < 55; i++) {
        const p = document.createElement('div');
        p.className = 'knight-cosmic-particle';
        const size = Math.random() * 8 + 4;
        p.style.width = `${size}px`;
        p.style.height = `${size}px`;
        p.style.left = `${Math.random() * 100}%`;
        p.style.top = `${Math.random() * 85 + 15}%`;
        p.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        p.style.boxShadow = `0 0 14px ${p.style.backgroundColor}`;
        p.style.animationDuration = `${Math.random() * 3 + 2.5}s`;
        p.style.animationDelay = `${Math.random() * 1.5}s`;
        particles.appendChild(p);
      }
    }
  }, 1000);

  let isClosing = false;
  let canClose = false;
  setTimeout(() => { canClose = true; }, 1500);

  const closeCinematic = () => {
    if (isClosing) return;
    isClosing = true;
    overlay.style.transition = 'opacity 0.4s ease';
    overlay.style.opacity = '0';
    setTimeout(async () => {
      overlay.style.display = 'none';
      overlay.style.opacity = '1';
      overlay.style.transition = '';
      if (particles) particles.innerHTML = '';

      isTraitRouletteSpinning = false;
      activeRouletteTimeout = null;

      try {
        if (typeof applyTraitDirectly === 'function') {
          await applyTraitDirectly(trait);
        } else if (typeof applyTraitToCard === 'function') {
          await applyTraitToCard(trait);
        }
      } catch (err) {
        console.error('[TRAITS] Error al aplicar rasgo Knight:', err);
      }

      if (typeof renderTraitsPanel === 'function') {
        await renderTraitsPanel();
      }
      if (typeof renderCollection === 'function') {
        try { renderCollection(); } catch (_) {}
      }
    }, 400);
  };

  if (claimBtn) {
    claimBtn.onclick = (e) => {
      e.stopPropagation();
      closeCinematic();
    };
  }

  overlay.onclick = () => {
    if (canClose) closeCinematic();
  };
}
window.showKnightTraitCinematic = showKnightTraitCinematic;

function showTraitResult(trait) {
  if (!trait) return;
  const rarity = String(trait.rarity || 'common').toLowerCase().trim();
  if (rarity === 'knight') {
    showKnightTraitCinematic(trait);
  } else if (rarity === 'mythic') {
    showMythicTraitCinematic(trait);
  } else if (rarity === 'legendary') {
    showLegendaryTraitResult(trait);
  } else {
    showStandardTraitResult(trait);
  }
}

// ==================== ÍNDICE Y PROBABILIDADES DE RASGOS ====================

/**
 * Calcula la probabilidad de cada rasgo según traits.json.
 * Si un rasgo tiene 'probability' (o 'probabilidad'/'chance') manual, se respeta ese valor.
 * El porcentaje restante (100% - suma de manuales) se reparte equitativamente entre los demás.
 */
function calculateTraitProbabilities(traits) {
  if (!Array.isArray(traits) || traits.length === 0) return [];

  // Reglas de probabilidades oficiales:
  // - Knight (Inmo): 0.001%
  // - Mítico: 0.3% total (0.1% cada uno dividido entre sus 3 rasgos)
  // - Legendario: 1.0% total (dividido equitativamente entre los 3 rasgos legendarios = ~0.333% c/u)
  // - Resto (Común, Raro, Épico): 98.699% total repartido ponderadamente según pesos

  const KNIGHT_TOTAL = 0.001;
  const MYTHIC_TOTAL = 0.3;
  const LEGENDARY_TOTAL = 1.0;

  const RARITY_WEIGHTS = {
    common: 50,
    rare: 25,
    epic: 10
  };

  const parsed = traits.map(t => {
    let raw = t.probability ?? t.probabilidad ?? t.chance ?? t.prob ?? null;
    let manualVal = null;
    if (raw !== null && raw !== undefined && raw !== '') {
      if (typeof raw === 'string') raw = raw.replace('%', '').trim();
      const num = parseFloat(raw);
      if (!isNaN(num) && num >= 0) {
        manualVal = num;
      }
    }
    const rarity = String(t.rarity || 'common').toLowerCase().trim();
    return {
      trait: t,
      rarity: rarity,
      manualProb: manualVal
    };
  });

  const knightCount = parsed.filter(p => p.rarity === 'knight' && p.manualProb === null).length;
  const mythicCount = parsed.filter(p => p.rarity === 'mythic' && p.manualProb === null).length;
  const legendaryCount = parsed.filter(p => p.rarity === 'legendary' && p.manualProb === null).length;

  let assignedSum = 0;
  parsed.forEach(p => {
    if (p.manualProb !== null) {
      p.targetProb = p.manualProb;
      assignedSum += p.targetProb;
    } else if (p.rarity === 'knight') {
      p.targetProb = KNIGHT_TOTAL / Math.max(1, knightCount);
      assignedSum += p.targetProb;
    } else if (p.rarity === 'mythic') {
      p.targetProb = MYTHIC_TOTAL / Math.max(1, mythicCount);
      assignedSum += p.targetProb;
    } else if (p.rarity === 'legendary') {
      p.targetProb = LEGENDARY_TOTAL / Math.max(1, legendaryCount);
      assignedSum += p.targetProb;
    } else {
      p.targetProb = null;
    }
  });

  const remainingPercent = Math.max(0, 100 - assignedSum);
  const remainingTraits = parsed.filter(p => p.targetProb === null);
  const remainingWeightSum = remainingTraits.reduce((sum, p) => {
    return sum + (RARITY_WEIGHTS[p.rarity] || 10);
  }, 0) || 1;

  parsed.forEach(p => {
    if (p.targetProb === null) {
      const w = RARITY_WEIGHTS[p.rarity] || 10;
      p.targetProb = remainingPercent * (w / remainingWeightSum);
    }
  });

  return parsed.map(p => ({
    ...p.trait,
    calculatedProbability: p.targetProb,
    isManual: p.manualProb !== null
  }));
}
window.calculateTraitProbabilities = calculateTraitProbabilities;

/**
 * Selecciona un rasgo de forma ponderada según su probabilidad calculada
 */
function rollWeightedTrait(traitsWithProbs) {
  if (!Array.isArray(traitsWithProbs) || traitsWithProbs.length === 0) return null;
  const rand = Math.random() * 100;
  let cumulative = 0;
  for (const t of traitsWithProbs) {
    cumulative += t.calculatedProbability;
    if (rand <= cumulative) {
      return t;
    }
  }
  return traitsWithProbs[traitsWithProbs.length - 1];
}
window.rollWeightedTrait = rollWeightedTrait;

/**
 * Formato amigable de porcentaje (soporta desde 0.001% hasta 100%)
 */
function formatProbability(prob) {
  if (typeof prob !== 'number' || isNaN(prob)) return '0%';
  if (prob >= 10) {
    const s = prob.toFixed(1);
    return (s.endsWith('.0') ? prob.toFixed(0) : s) + '%';
  } else if (prob >= 1) {
    const s = prob.toFixed(2);
    return (s.endsWith('.00') ? prob.toFixed(0) : (s.endsWith('0') ? prob.toFixed(1) : s)) + '%';
  } else if (prob >= 0.01) {
    const s = prob.toFixed(2);
    return (s.endsWith('0') ? prob.toFixed(1) : s) + '%';
  } else {
    // Para probabilidades diminutas como 0.001%
    return prob.toFixed(3) + '%';
  }
}
window.formatTraitProbability = formatProbability;

/**
 * Muestra u oculta el panel de Index de Rasgos desplegado a la izquierda
 */
async function toggleTraitsIndex(e) {
  if (e && typeof e.stopPropagation === 'function') {
    e.stopPropagation();
  }
  const indexPanel = document.getElementById('traits-index-panel');
  const indexBtn = document.getElementById('traits-index-btn');
  if (!indexPanel) return;

  const isHidden = indexPanel.style.display === 'none' || indexPanel.style.display === '';
  if (isHidden) {
    indexPanel.style.display = 'flex';
    if (indexBtn) indexBtn.classList.add('active');
    await renderTraitsIndex();
  } else {
    indexPanel.style.display = 'none';
    if (indexBtn) indexBtn.classList.remove('active');
  }
}
window.toggleTraitsIndex = toggleTraitsIndex;

/**
 * Renderiza la tabla de rasgos con su probabilidad en grande
 */
async function renderTraitsIndex() {
  const tbody = document.getElementById('traits-index-tbody');
  if (!tbody) return;

  tbody.innerHTML = '<tr><td colspan="3" style="text-align:center; padding: 24px; color:#fbbf24;">Cargando rasgos desde el servidor remoto...</td></tr>';

  // 1. Cargar directamente desde el JSON remoto oficial en GitHub
  const remoteList = await fetchRemoteTraitsDirectly();
  if (Array.isArray(remoteList) && remoteList.length > 0) {
    window.availableTraits = remoteList;
    availableTraits = remoteList;
  } else if (window.kvrcards && typeof window.kvrcards.getAllTraits === 'function') {
    try {
      const loaded = await window.kvrcards.getAllTraits();
      const arr = Array.isArray(loaded) ? loaded : (Array.isArray(loaded?.traits) ? loaded.traits : []);
      if (arr.length > 0) {
        window.availableTraits = arr;
        availableTraits = arr;
      }
    } catch (e) {
      console.error('[TRAITS] Error cargando traits para index:', e);
    }
  }

  const traits = window.availableTraits || availableTraits || [];

  if (!traits || traits.length === 0) {
    tbody.innerHTML = '<tr><td colspan="3" style="text-align:center; padding: 24px; color:#ef4444;">No se pudieron cargar los rasgos del servidor remoto.</td></tr>';
    return;
  }

  const traitsWithProbs = calculateTraitProbabilities(availableTraits);
  const escapeFn = typeof window.escapeHtml === 'function' ? window.escapeHtml : (s => String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'));

  tbody.innerHTML = '';
  const fragment = document.createDocumentFragment();

  traitsWithProbs.forEach(t => {
    const tr = document.createElement('tr');
    tr.className = 'traits-index-row';

    const probFormatted = formatProbability(t.calculatedProbability);
    const traitImg = t.imageUrl || t.image || t.imagen || t.icon || t.icono || './trait.png';
    const traitDesc = t.description || t.descripcion || t.desc || 'Sin descripción';

    tr.innerHTML = `
      <td class="traits-index-cell-name">
        <div class="traits-index-item-box">
          <img src="${traitImg}" class="traits-index-icon" onerror="this.src='./trait.png'" alt="${escapeFn(t.name || t.id)}">
          <div class="traits-index-name-wrap">
            <span class="traits-index-name">${escapeFn(t.name || t.id)}</span>
          </div>
        </div>
      </td>
      <td class="traits-index-cell-desc">
        <span class="traits-index-desc">${escapeFn(traitDesc)}</span>
      </td>
      <td class="traits-index-cell-prob">
        <span class="traits-prob-large">${probFormatted}</span>
      </td>
    `;
    fragment.appendChild(tr);
  });

  tbody.appendChild(fragment);
}
window.renderTraitsIndex = renderTraitsIndex;

console.log('🟢🟢🟢 CHECKPOINT 1: Llegando a línea 16023 - Antes de definir sistema online');

