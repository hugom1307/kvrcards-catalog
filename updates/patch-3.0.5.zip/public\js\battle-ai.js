// ==================== SISTEMA DE ENTRENADORES Y BATALLA IA ====================

/**
 * Parser de JSON tolerante a errores de sintaxis comunes (comas finales, comentarios, espacios, BOM)
 */
function safeParseJson(rawText) {
  if (typeof rawText !== 'string') return rawText;
  try {
    return JSON.parse(rawText);
  } catch (initialErr) {
    try {
      let cleaned = rawText.replace(/^\uFEFF/, '');
      // 1. Quitar comentarios // y /* ... */
      cleaned = cleaned.replace(/\/\*[\s\S]*?\*\/|([^\\:]|^)\/\/.*$/gm, '$1');
      // 2. Quitar comas finales recursivamente antes de ] o }
      let prev;
      do {
        prev = cleaned;
        cleaned = cleaned.replace(/,\s*([\]}])/g, '$1');
        cleaned = cleaned.replace(/,\s*,/g, ',');
      } while (cleaned !== prev);
      return JSON.parse(cleaned);
    } catch (cleanErr) {
      console.error('[SAFE-JSON-PARSE] Error parseando JSON tras sanitizar:', cleanErr.message);
      throw initialErr;
    }
  }
}

// Entrenadores por defecto de respaldo (fallback sincronizado con el formato del catálogo remoto)
const DEFAULT_OFFLINE_TRAINERS = [
  { 
    id: 'doman_kurimonzoso',
    nombre: 'Doman Kurimonzoso', 
    titulo: 'Estratega de la Niebla',
    imagen: 'https://hugom1307.github.io/kvrcards-catalog/image/botsoffline/doman.png',
    dificultades: ['principiante', 'amateur', 'evento_combate_1'],
    fondo: 'https://hugom1307.github.io/kvrcards-catalog/image/fondos/fondo_ronan_hatake.png',
    song: null,
    intervaloMedias: [76, 85],
    cartasObligatorias: ['doman_kurimonzoso', 'kai_senju_icono'],
    cartasProhibidas: ['kiri_uzumaki_icono'],
    poderes: 'aleatorio'
  },
  { 
    id: 'zion_hatake', 
    nombre: 'Zion Hatake', 
    titulo: 'Maestro del Rayo',
    imagen: 'https://hugom1307.github.io/kvrcards-catalog/image/botsoffline/zion.png',
    dificultades: ['amateur', 'experimentado', 'evento_combate_2'],
    fondo: 'https://hugom1307.github.io/kvrcards-catalog/image/fondos/fondo_ronan_hatake.png',
    song: null,
    intervaloMedias: [79, 84],
    cartasObligatorias: ['zion_hatake', 'kinan_hatake_icono', 'betocs_hatake_icono'],
    cartasProhibidas: [],
    poderes: 'aleatorio'
  },
  { 
    id: 'tan_uzumaki', 
    nombre: 'Tan Uzumaki', 
    titulo: 'Heredero Carmesí',
    imagen: 'https://hugom1307.github.io/kvrcards-catalog/image/botsoffline/tan.png',
    dificultades: ['profesional'],
    fondo: null,
    song: null,
    intervaloMedias: [73, 87],
    cartasObligatorias: ['tan_uzumaki', 'manuel_hyuga_icono'],
    cartasProhibidas: ['kiri_uzumaki_icono'],
    poderes: 'aleatorio'
  },
  {
    id: 'shinobi_inmortal',
    nombre: 'Inmortal Shinobi',
    titulo: 'Deidad de las Sombras',
    imagen: 'https://api.dicebear.com/7.x/avataaars/svg?seed=inmo-legend',
    dificultades: ['dios-antiguo', 'inmo'],
    fondo: 'https://hugom1307.github.io/kvrcards-catalog/assets/backgrounds/inmo_arena.jpg',
    song: null,
    intervaloMedias: [90, 99],
    cartasObligatorias: ['kaguya_otsutsuki'],
    cartasProhibidas: [],
    poderes: 'aleatorio'
  }
];

window.DEFAULT_OFFLINE_TRAINERS = DEFAULT_OFFLINE_TRAINERS;
window.allTrainersCache = null;

/**
 * Carga remota directa de trainers.json desde GitHub con parser tolerante a fallos
 */
async function fetchRemoteTrainersDirectly(forceRefresh = false) {
  if (!forceRefresh && Array.isArray(window.allTrainersCache) && window.allTrainersCache.length > 0 && window.trainersLoadedFromRemote) {
    return window.allTrainersCache;
  }

  const urls = [
    `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/trainers.json?t=${Date.now()}`,
    `https://hugom1307.github.io/kvrcards-catalog/trainers.json?t=${Date.now()}`
  ];

  for (const url of urls) {
    try {
      const res = await fetch(url, { cache: 'no-store' });
      if (res.ok) {
        const text = await res.text();
        const json = safeParseJson(text);
        const list = Array.isArray(json) 
          ? json 
          : (Array.isArray(json?.trainers) ? json.trainers : (Array.isArray(json?.entrenadores) ? json.entrenadores : []));
        if (list.length > 0) {
          console.log(`[TRAINERS] ✅ ${list.length} entrenadores cargados exitosamente desde remoto (${url})`);
          window.allTrainersCache = list;
          window.trainersLoadedFromRemote = true;
          return list;
        }
      }
    } catch (e) {
      console.warn('[TRAINERS] Error parseando/cargando trainers.json desde', url, e.message);
    }
  }

  // Fallback IPC de Electron
  if (window.kvrcards && typeof window.kvrcards.getAllTrainers === 'function') {
    try {
      const ipcTrainers = await window.kvrcards.getAllTrainers();
      const arr = Array.isArray(ipcTrainers) 
        ? ipcTrainers 
        : (Array.isArray(ipcTrainers?.trainers) ? ipcTrainers.trainers : (Array.isArray(ipcTrainers?.entrenadores) ? ipcTrainers.entrenadores : []));
      if (arr.length > 0) {
        console.log(`[TRAINERS] Entrenadores cargados vía IPC (${arr.length})`);
        window.allTrainersCache = arr;
        window.trainersLoadedFromRemote = true;
        return arr;
      }
    } catch (err) {
      console.warn('[TRAINERS] Error al consultar getAllTrainers por IPC:', err);
    }
  }

  console.warn('[TRAINERS] No se pudo cargar remoto ni IPC, usando fallback temporal');
  return DEFAULT_OFFLINE_TRAINERS;
}

window.fetchRemoteTrainersDirectly = fetchRemoteTrainersDirectly;

// Precalentar caché de entrenadores en segundo plano
setTimeout(() => {
  fetchRemoteTrainersDirectly(true).catch(() => {});
}, 500);

/**
 * Algoritmo inteligente de coincidencia de cartas (soporta IDs, nombres, variantes de icono y tolerancia)
 */
function cardMatchesQuery(card, query) {
  if (!card || !query) return false;
  const qClean = String(query).toLowerCase().trim();
  const id = String(card.id || '').toLowerCase().trim();
  const name = String(card.name || card.nombre || '').toLowerCase().trim();

  // 1. Coincidencia exacta directa de ID o Nombre
  if (id === qClean || name === qClean) return true;

  // 2. Normalización sin espacios, guiones ni caracteres especiales
  const norm = s => s.replace(/[^a-z0-9]/g, '');
  const qNorm = norm(qClean);
  const idNorm = norm(id);
  const nameNorm = norm(name);
  if (idNorm === qNorm || nameNorm === qNorm) return true;

  // 3. Normalizar sufijos (_icono, _iconoprime, _iconosuperprime, _prime, _superprime, _evo, etc.)
  const stripSuffix = s => s.replace(/(iconosuperprime|iconoprime|icono|prime|superprime|notrait|evochad|evosamurai|sbcevo|evoe|evolucion|evolution|evo\d*|evo)$/g, '');
  const qBase = stripSuffix(qNorm);
  const idBase = stripSuffix(idNorm);

  if (qBase && idBase) {
    if (qBase === idBase) return true;
    if (idNorm.startsWith(qBase) || qNorm.startsWith(idBase)) return true;
  }

  // 4. Tolerancia vocal para variantes menores (ej. domankurimonzoso vs domankurimunzoso)
  const qVowels = qBase.replace(/[aeiou]/g, '*');
  const idVowels = idBase.replace(/[aeiou]/g, '*');
  if (qVowels.length > 8 && qVowels === idVowels) return true;

  return false;
}

/**
 * Obtener catálogo maestro de todas las cartas disponibles en el juego
 */
async function getAllAvailableCardsPool() {
  if (Array.isArray(window.allCardsCache) && window.allCardsCache.length > 0) {
    return window.allCardsCache;
  }

  if (window.kvrcards && typeof window.kvrcards.getAllCards === 'function') {
    try {
      const res = await window.kvrcards.getAllCards();
      const list = Array.isArray(res) ? res : (Array.isArray(res?.cards) ? res.cards : []);
      if (list.length > 0) {
        window.allCardsCache = list;
        return list;
      }
    } catch (e) {
      console.warn('[BATTLE-AI] Error con getAllCards IPC:', e);
    }
  }

  // Fetch directo desde GitHub si no estaba en caché
  try {
    const res = await fetch('https://hugom1307.github.io/kvrcards-catalog/cards.json?t=' + Date.now());
    if (res.ok) {
      const list = await res.json();
      if (Array.isArray(list) && list.length > 0) {
        window.allCardsCache = list;
        return list;
      }
    }
  } catch (e) {}

  if (Array.isArray(window.teamBuilderCards) && window.teamBuilderCards.length > 0) {
    const map = new Map();
    window.teamBuilderCards.forEach(c => {
      if (c && c.id && !map.has(c.id)) map.set(c.id, c);
    });
    return Array.from(map.values());
  }

  return [];
}

/**
 * Selecciona un entrenador acorde a la dificultad solicitada
 */
function selectTrainerForDifficulty(difficulty, trainersList) {
  const targetDiff = String(difficulty || 'principiante').toLowerCase().trim();
  const list = Array.isArray(trainersList) && trainersList.length > 0 ? trainersList : DEFAULT_OFFLINE_TRAINERS;

  // 1. Prioridad maxima: Coincidencia exacta con la dificultad o ID de combate
  const exactMatches = list.filter(t => {
    if (!t) return false;
    const diffs = t.dificultades || t.dificultad || t.difficulties || t.difficulty;
    if (!diffs) return false;
    if (Array.isArray(diffs)) {
      return diffs.some(d => String(d).toLowerCase().trim() === targetDiff);
    } else if (typeof diffs === 'string') {
      return diffs.toLowerCase().trim() === targetDiff;
    }
    return false;
  });

  if (exactMatches.length > 0) {
    const chosen = exactMatches[Math.floor(Math.random() * exactMatches.length)];
    console.log(`[TRAINERS] Entrenador exacto seleccionado para '${targetDiff}':`, chosen.nombre || chosen.name);
    return chosen;
  }

  // 1.5. Si es una batalla de evento activa (clásica o especial) y no hay coincidencia exacta en trainers.json, construir rival a partir del evento
  const activeEventData = (window.isSpecialEventBattle && window.currentSpecialEventLevel)
    ? window.currentSpecialEventLevel
    : (window.isEventBattle ? window.currentEventBattle : null);

  if (activeEventData) {
    const ev = activeEventData;
    const bossCard = ev.bossCardId || ev.boss || ev.bossCard || (Array.isArray(ev.cartasObligatorias) ? ev.cartasObligatorias[0] : null);
    const eventLabel = window.isSpecialEventBattle ? '(Evento Especial)' : '(Evento)';
    console.log(`[TRAINERS] Usando configuración de Batalla de Evento para rival:`, ev.name || ev.id);
    return {
      id: ev.id,
      nombre: ev.trainerName || ev.name || 'Rival de Evento',
      titulo: ev.trainerTitle || eventLabel,
      imagen: ev.trainerImage || ev.image || (bossCard ? `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${bossCard}.png` : `https://api.dicebear.com/7.x/avataaars/svg?seed=${ev.id}`),
      fondo: ev.trainerBackground || ev.fondo || ev.backgroundImage || (window.currentSpecialEventWorld?.backgroundImage || null),
      song: ev.song || ev.cancion || ev.battleSong || null,
      dificultades: [targetDiff],
      intervaloMedias: ev.intervaloMedias || [75, 88],
      cartasObligatorias: Array.isArray(ev.cartasObligatorias) ? ev.cartasObligatorias : (bossCard ? [bossCard] : []),
      cartasProhibidas: Array.isArray(ev.cartasProhibidas) ? ev.cartasProhibidas : [],
      poderes: ev.poderes || 'aleatorio',
      permitirEvo: ev.permitirEvo || ev.allowEvo || false,
      evosPermitidas: ev.evosPermitidas || ev.permitirEvos || [],
      traits: ev.traits || ev.traitsObligatorios || ev.cartasTraits || null,
      buff: ev.buff || ev.buffo || ev.trainerBuff || ev.customBuff || null,
      mode: ev.mode || (window.currentSpecialEvent?.mode || (window.battleState?.is7v1Mode ? '7v1' : null))
    };
  }

  // 2. Coincidencias generales (comodines o sin restriccion)
  const eligible = list.filter(t => {
    if (!t) return false;
    const diffs = t.dificultades || t.dificultad || t.difficulties || t.difficulty;
    if (!diffs) return true; // Si no especifica dificultad, puede salir en cualquiera
    if (Array.isArray(diffs)) {
      return diffs.some(d => {
        const norm = String(d).toLowerCase().trim();
        return norm === targetDiff || norm === 'todas' || norm === 'all' || norm === '*';
      });
    } else if (typeof diffs === 'string') {
      const norm = diffs.toLowerCase().trim();
      return norm === targetDiff || norm === 'todas' || norm === 'all' || norm === '*';
    }
    return false;
  });

  if (eligible.length > 0) {
    const chosen = eligible[Math.floor(Math.random() * eligible.length)];
    console.log(`[TRAINERS] Entrenador seleccionado para '${targetDiff}':`, chosen.nombre || chosen.name);
    return chosen;
  }

  console.warn(`[TRAINERS] No se encontró entrenador configurado para dificultad '${targetDiff}'. Generando perfil estándar.`);
  const defaultProfiles = {
    'principiante': { nombre: 'Novato', titulo: '(Principiante)', seed: 'rookie', intervaloMedias: [60, 75] },
    'amateur': { nombre: 'Bot Amateur', titulo: '(Amateur)', seed: 'challenger', intervaloMedias: [70, 80] },
    'experimentado': { nombre: 'Veterano', titulo: '(Experimentado)', seed: 'veteran', intervaloMedias: [78, 85] },
    'profesional': { nombre: 'Maestro', titulo: '(Profesional)', seed: 'master', intervaloMedias: [83, 90] },
    'dios-antiguo': { nombre: 'Leyenda', titulo: '(Dios Antiguo)', seed: 'legend', intervaloMedias: [88, 95] },
    'inmo': { nombre: 'INMO', titulo: '(INMO)', seed: 'inmo', intervaloMedias: [92, 99] }
  };

  const profile = defaultProfiles[targetDiff] || { nombre: 'Oponente', titulo: '(IA)', seed: 'opponent', intervaloMedias: [70, 85] };
  return {
    id: `fallback_${targetDiff}`,
    nombre: profile.nombre,
    titulo: profile.titulo,
    imagen: `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile.seed}`,
    dificultades: [targetDiff],
    intervaloMedias: profile.intervaloMedias,
    cartasObligatorias: [],
    cartasProhibidas: []
  };
}

/**
 * Resuelve la lista de poderes del entrenador rival (manual o aleatorio).
 * Admite:
 * - "aleatorio" o "random" (elige 3 poderes aleatorios distintos de la lista disponible)
 * - ["aleatorio"] o ["random"]
 * - ["reserva", "aleatorio", "aleatorio"] (mezcla de específicos y aleatorios)
 * - Array manual de poderes: ["reserva", "powerup", "nerf"], ["anulo", "intercambio"], etc.
 * - String manual: "reserva, powerup, anulo"
 * - null / undefined / omitido: por defecto ['reserva', 'powerup', 'nerf']
 */
function resolveTrainerPowers(rawPowers) {
  const ALL_POWERS = ['reserva', 'powerup', 'nerf', 'anulo', 'intercambio'];

  const getRandomPowers = (count = 3) => {
    const safeCount = Math.min(ALL_POWERS.length, Math.max(1, parseInt(count, 10) || 3));
    const shuffled = [...ALL_POWERS].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, safeCount);
  };

  const normalize = (p) => {
    if (!p) return null;
    const s = String(p).toLowerCase().trim();
    if (['swap', 'reserva', 'reserve_card', 'reserve'].includes(s)) return 'reserva';
    if (['powerup', 'power_up', 'buff'].includes(s)) return 'powerup';
    if (['nerf', 'debuff'].includes(s)) return 'nerf';
    if (['anulo', 'anular', 'cancel'].includes(s)) return 'anulo';
    if (['intercambio', 'exchange', 'swap_cards'].includes(s)) return 'intercambio';
    return s;
  };

  const isRandomKeyword = (val) => {
    if (!val) return false;
    const s = String(val).toLowerCase().trim();
    return s === 'aleatorio' || s === 'random' || /^aleatorio\(\d+\)$/.test(s) || /^random\(\d+\)$/.test(s);
  };

  // Si no se proporcionó nada (omitido, null, undefined, vacío), por defecto es ALEATORIO (3 poderes aleatorios)
  if (rawPowers === null || rawPowers === undefined || rawPowers === '') {
    return getRandomPowers(3);
  }

  // Si es un string
  if (typeof rawPowers === 'string') {
    const s = rawPowers.toLowerCase().trim();
    if (isRandomKeyword(s)) {
      const match = s.match(/(?:aleatorio|random)\((\d+)\)/);
      const count = match ? match[1] : 3;
      return getRandomPowers(count);
    }
    // Si viene separado por comas: "reserva, anulo, nerf"
    if (s.includes(',')) {
      return resolveTrainerPowers(s.split(',').map(x => x.trim()));
    }
    const norm = normalize(s);
    return norm ? [norm] : getRandomPowers(3);
  }

  // Si es un array
  if (Array.isArray(rawPowers)) {
    if (rawPowers.length === 0) {
      return getRandomPowers(3);
    }

    // Si es un array con un único elemento "aleatorio"
    if (rawPowers.length === 1 && isRandomKeyword(rawPowers[0])) {
      const s = String(rawPowers[0]).toLowerCase().trim();
      const match = s.match(/(?:aleatorio|random)\((\d+)\)/);
      const count = match ? match[1] : 3;
      return getRandomPowers(count);
    }

    const result = [];
    const used = new Set();

    // 1. Primero añadir los poderes fijos manuales
    for (const item of rawPowers) {
      if (!isRandomKeyword(item)) {
        const norm = normalize(item);
        if (norm && !used.has(norm)) {
          result.push(norm);
          used.add(norm);
        }
      }
    }

    // 2. Rellenar los slots que pidieron "aleatorio"
    const unusedPool = ALL_POWERS.filter(p => !used.has(p)).sort(() => Math.random() - 0.5);
    for (const item of rawPowers) {
      if (isRandomKeyword(item)) {
        if (unusedPool.length > 0) {
          const picked = unusedPool.pop();
          result.push(picked);
          used.add(picked);
        }
      }
    }

    return result.length > 0 ? result : getRandomPowers(3);
  }

  return getRandomPowers(3);
}

/**
 * Resuelve un trait a partir de su ID, nombre o slug para el entrenador rival
 */
function resolveTrainerTrait(traitQuery) {
  if (!traitQuery) return null;
  const qClean = (typeof traitQuery === 'object'
    ? String(traitQuery.id || traitQuery.traitId || traitQuery.name || traitQuery.nombre || '')
    : String(traitQuery)).trim().toLowerCase();
  if (!qClean) return null;
  const qNorm = qClean.replace(/[^a-z0-9]/g, '');

  const allTraits = (Array.isArray(window.battleState?.availableTraits) && window.battleState.availableTraits.length > 0)
    ? window.battleState.availableTraits
    : (Array.isArray(window.availableTraits) && window.availableTraits.length > 0
        ? window.availableTraits
        : (typeof window.getKnownTraitsList === 'function' ? window.getKnownTraitsList() : (typeof availableTraits !== 'undefined' && Array.isArray(availableTraits) ? availableTraits : [])));

  // 1. Coincidencia por getTraitById directa
  if (typeof window.getTraitById === 'function') {
    const t = window.getTraitById(qClean);
    if (t) return t;
  }

  // 2. Coincidencia por ID exacta o normalizada
  let match = allTraits.find(t => {
    if (!t) return false;
    const tid = String(t.id || '').toLowerCase().trim();
    return tid === qClean || tid.replace(/[^a-z0-9]/g, '') === qNorm;
  });
  if (match) return match;

  // 3. Coincidencia por nombre exacto o normalizado
  match = allTraits.find(t => {
    if (!t) return false;
    const tname = String(t.name || t.nombre || '').toLowerCase().trim();
    return tname === qClean || tname.replace(/[^a-z0-9]/g, '') === qNorm;
  });
  if (match) return match;

  return { id: qClean, name: qClean };
}

/**
 * Parsea y normaliza un buff personalizado de un entrenador desde trainers.json
 * Admite:
 * - trainer.buff, trainer.buffo, trainer.trainerBuff, trainer.customBuff
 * - Formato:
 *   {
 *     "nombre": "Furia del Rival",
 *     "descripcion": "+10% Ninjutsu y +5% Defensa",
 *     "icono": "⚔️",
 *     "stats": { "ninjutsu": 10, "defensa": 5 },
 *     "asignarCartas": false, // Por defecto false (afecta a todas sus cartas)
 *     "cartas": ["kurai_tenro_evoe", "ronan_hatake_evo1"] // Si se activa la opción manual
 *   }
 */
function parseTrainerBuff(rawBuff, trainer = null) {
  if (!rawBuff || typeof rawBuff !== 'object') return null;

  // 1. Nombre
  const name = String(rawBuff.nombre || rawBuff.name || rawBuff.titulo || rawBuff.title || 'Buff de Entrenador').trim();

  // 2. Icono
  const icon = String(rawBuff.icono || rawBuff.icon || '⚔️').trim();

  // 3. Stats y porcentajes individuales por stat
  const rawStats = rawBuff.stats || rawBuff.efecto || rawBuff.statsBoost || rawBuff.boosts || rawBuff.buffs || {};
  const defaultPercentage = Number(rawBuff.porcentaje || rawBuff.percentage || rawBuff.valor || rawBuff.value) || 0;

  const normalizedStats = {};

  const normalizeStatKey = (key) => {
    const k = String(key || '').toLowerCase().trim();
    if (k === 'nin' || k === 'ninjutsu') return 'ninjutsu';
    if (k === 'tai' || k === 'taijutsu') return 'taijutsu';
    if (k === 'res' || k === 'resistencia') return 'resistencia';
    if (k === 'vel' || k === 'velocidad') return 'velocidad';
    if (k === 'def' || k === 'defensa') return 'defensa';
    if (k === 'fis' || k === 'fisico' || k === 'físico') return 'fisico';
    if (k === 'all' || k === 'todas' || k === 'todos') return 'all';
    if (k === 'media' || k === 'overall') return 'media';
    return k;
  };

  if (Array.isArray(rawStats)) {
    rawStats.forEach(s => {
      const normKey = normalizeStatKey(s);
      if (normKey) {
        normalizedStats[normKey] = defaultPercentage;
      }
    });
  } else if (typeof rawStats === 'object' && rawStats !== null) {
    for (const [sKey, sVal] of Object.entries(rawStats)) {
      const normKey = normalizeStatKey(sKey);
      const valNum = Number(sVal);
      if (normKey && !isNaN(valNum)) {
        normalizedStats[normKey] = valNum;
      } else if (normKey) {
        normalizedStats[normKey] = defaultPercentage;
      }
    }
  }

  // Si no se especificaron stats pero sí porcentaje general:
  if (Object.keys(normalizedStats).length === 0 && defaultPercentage > 0) {
    normalizedStats.all = defaultPercentage;
  }

  if (Object.keys(normalizedStats).length === 0) {
    return null;
  }

  // 4. Descripción (auto-generar si no se proporciona)
  let description = String(rawBuff.descripcion || rawBuff.description || rawBuff.desc || '').trim();
  if (!description) {
    const STAT_LABELS = {
      ninjutsu: 'Ninjutsu',
      taijutsu: 'Taijutsu',
      resistencia: 'Resistencia',
      velocidad: 'Velocidad',
      defensa: 'Defensa',
      fisico: 'Físico',
      all: 'todas las stats',
      media: 'Media'
    };
    const parts = Object.entries(normalizedStats).map(([sKey, sVal]) => {
      const label = STAT_LABELS[sKey] || (sKey.charAt(0).toUpperCase() + sKey.slice(1));
      return `+${sVal}% ${label}`;
    });
    description = parts.join(', ');
  }

  // 5. Modo de asignación: por defecto false (afecta a todas sus cartas)
  // "Tambien que haya una opción que por defecto este buffo afecte a todas sus cartas pero que si lo activas tengas que asignarle manualmente a que cartas lo tendrian o si no no funciona"
  const isManual = Boolean(
    rawBuff.asignarCartas === true ||
    rawBuff.manual === true ||
    rawBuff.soloAsignadas === true ||
    rawBuff.soloCartasAsignadas === true ||
    rawBuff.afectarTodas === false ||
    rawBuff.allCards === false ||
    rawBuff.todas === false
  );

  // 6. Lista de cartas asignadas manualmente
  const rawCards = rawBuff.cartas || rawBuff.cartasAsignadas || rawBuff.cards || rawBuff.cardIds || [];
  const assignedCardsList = (Array.isArray(rawCards) ? rawCards : [rawCards])
    .map(c => String(c || '').trim().toLowerCase())
    .filter(Boolean);

  // Añadir cartas que tengan marcado buff: true en cartasObligatorias del entrenador
  if (trainer) {
    const rawMandatory = trainer.cartasObligatorias || trainer.guaranteedCards || [];
    const mandList = Array.isArray(rawMandatory) ? rawMandatory : [rawMandatory];
    for (const item of mandList) {
      if (typeof item === 'object' && item !== null) {
        if (item.buff === true || item.tieneBuff === true || item.trainerBuff === true) {
          const cid = String(item.id || item.cardId || '').trim().toLowerCase();
          if (cid && !assignedCardsList.includes(cid)) {
            assignedCardsList.push(cid);
          }
        }
      } else if (typeof item === 'string') {
        if (item.includes('+buff') || item.includes(':buff')) {
          const cleanId = item.split(/[+:]/)[0].trim().toLowerCase();
          if (cleanId && !assignedCardsList.includes(cleanId)) {
            assignedCardsList.push(cleanId);
          }
        }
      }
    }
  }

  return {
    name,
    description,
    icon,
    stats: normalizedStats,
    manual: isManual,
    cardIds: assignedCardsList
  };
}
window.parseTrainerBuff = parseTrainerBuff;

/**
 * Comprueba si una carta del oponente recibe el buffo del entrenador
 */
function doesCardHaveTrainerBuff(card, trainerBuff) {
  if (!card || !trainerBuff) return false;

  // Si la opción manual NO está activada, por defecto afecta a TODAS sus cartas
  if (!trainerBuff.manual) {
    return true;
  }

  // Si la opción manual SÍ está activada:
  if (card.hasTrainerBuff === true || card.trainerBuff === true) {
    return true;
  }

  const assigned = trainerBuff.cardIds;
  if (!Array.isArray(assigned) || assigned.length === 0) {
    return false; // Se activó la opción manual pero no se asignó ninguna carta -> no funciona
  }

  const cid = String(card.id || '').toLowerCase().trim();
  const cName = String(card.name || card.nombre || '').toLowerCase().trim();
  const cNorm = cid.replace(/[^a-z0-9]/g, '');
  const cBase = cid.replace(/_(?:evo\d*|evoe|evochad|evosamurai|sbcevo|notrait.*)$/i, '');

  return assigned.some(target => {
    if (!target) return false;
    const tClean = String(target).toLowerCase().trim();
    const tNorm = tClean.replace(/[^a-z0-9]/g, '');
    const tBase = tClean.replace(/_(?:evo\d*|evoe|evochad|evosamurai|sbcevo|notrait.*)$/i, '');
    return tClean === cid ||
           tNorm === cNorm ||
           tClean === cName ||
           tBase === cBase ||
           cid.includes(tClean) ||
           tClean.includes(cid);
  });
}
window.doesCardHaveTrainerBuff = doesCardHaveTrainerBuff;

/**
 * Parsea la especificación de una carta obligatoria de trainers.json.
 * Admite:
 * - Objeto: { id: "carta_id", evo: true, trait: "fuerza_bruta" }
 * - Objeto: { cardId: "carta_id", permitirEvo: true, traitId: "impostor" }
 * - Objeto con variante evo: { id: "carta_id", evo: "evo1" }, { id: "carta_id", evo: 1 }
 * - Objeto con buff manual: { id: "carta_id", buff: true }
 * - String: "carta_id"
 * - String compacto: "carta_id:evo", "carta_id@fuerza_bruta", "carta_id:evo:fuerza_bruta", "carta_id:evo1@fuerza_bruta"
 */
function parseMandatoryCardSpec(item, trainer) {
  let cardId = '';
  let allowEvo = false;
  let explicitEvoDisabled = false;
  let evoVariant = null;
  let traitId = null;
  let hasTrainerBuff = false;

  if (typeof item === 'object' && item !== null) {
    cardId = String(item.id || item.cardId || item.cartaId || item.name || item.nombre || '').trim();

    // Soportar sintaxis "id@trait" si viene dentro del campo id del objeto (ej. { id: "kurai_tenro_evoe@especialista" })
    if (cardId.includes('@')) {
      const parts = cardId.split('@');
      cardId = parts[0].trim();
      if (!traitId && parts[1]) {
        traitId = parts[1].trim();
      }
    }

    if (item.buff === true || item.tieneBuff === true || item.trainerBuff === true) {
      hasTrainerBuff = true;
    }

    if (item.evo === false || item.permitirEvo === false || item.allowEvo === false || item.permitirEvos === false) {
      explicitEvoDisabled = true;
      allowEvo = false;
    } else {
      if (item.evo === true || item.permitirEvo === true || item.allowEvo === true || item.permitirEvos === true) {
        allowEvo = true;
      }
      if (typeof item.evo === 'string' && item.evo.trim()) {
        const s = item.evo.trim().toLowerCase();
        if (s === 'true' || s === 'si' || s === 'yes') {
          allowEvo = true;
        } else if (s === 'false' || s === 'no') {
          explicitEvoDisabled = true;
          allowEvo = false;
        } else {
          allowEvo = true;
          evoVariant = s;
        }
      } else if (typeof item.evo === 'number') {
        allowEvo = true;
        evoVariant = `evo${item.evo}`;
      }
      const q = String(item.calidad || item.quality || '').toLowerCase().trim();
      if (q === 'evo' || q === 'evolucion' || q === 'evolución') {
        allowEvo = true;
      }
    }

    const rawTrait = item.trait ?? item.traitId ?? item.assignedTrait ?? item.rasgo;
    if (rawTrait) {
      if (typeof rawTrait === 'object') {
        traitId = String(rawTrait.id || rawTrait.traitId || rawTrait.name || rawTrait.nombre || '').trim();
      } else {
        traitId = String(rawTrait).trim();
      }
    }
  } else if (typeof item === 'string') {
    let rawStr = item.trim();

    // Extraer indicador de buff manual si viene: ej. "kurai_tenro_evoe@especialista+buff"
    if (rawStr.includes('+buff') || rawStr.includes(':buff')) {
      hasTrainerBuff = true;
      rawStr = rawStr.replace(/(\+buff|:buff)/g, '').trim();
    }

    // 1. Extraer trait con '@' si viene: ej. "kurai_tenro_evoe@especialista" o "ronan_hatake@fuerza_bruta"
    if (rawStr.includes('@')) {
      const parts = rawStr.split('@');
      rawStr = parts[0].trim();
      traitId = parts[1].trim();
    }

    // 2. Extraer partes con ':'
    if (rawStr.includes(':')) {
      const parts = rawStr.split(':').map(p => p.trim());
      cardId = parts[0];
      for (let i = 1; i < parts.length; i++) {
        const p = parts[i].toLowerCase();
        if (['evo', 'permitirevo', 'allowevo', 'evolucion', 'evolución'].includes(p)) {
          allowEvo = true;
        } else if (['noevo', 'sin_evo', 'sinevo', 'base'].includes(p)) {
          explicitEvoDisabled = true;
          allowEvo = false;
        } else if (/^(?:evo\d+|evoe|evochad|evosamurai|sbcevo)$/i.test(p)) {
          allowEvo = true;
          evoVariant = p;
        } else if (p.startsWith('trait=') || p.startsWith('trait:')) {
          traitId = parts[i].split(/[=:]/)[1]?.trim() || traitId;
        } else if (!traitId) {
          traitId = parts[i];
        }
      }
    } else {
      cardId = rawStr;
    }
  }

  // 3. Detección automática de evo permitida por sufijo _evo:
  // "si por ejemplo yo le ponga kurai_tenro_evoe directamente detecte que aunque es una evo la puede sacar porque yo se lo he puesto, cualquier sufijo que empiece por _evo"
  if (!explicitEvoDisabled && !allowEvo) {
    if (/(?:_evo.*|_sbcevo.*)$/i.test(cardId) || cardId.toLowerCase().includes('_evo')) {
      allowEvo = true;
    }
  }

  // Comprobar si allowEvo viene a nivel global de entrenador (si no fue explícitamente deshabilitado para esta carta)
  if (!allowEvo && !explicitEvoDisabled) {
    if (trainer && (trainer.permitirEvo === true || trainer.allowEvo === true || trainer.permitirEvos === true)) {
      allowEvo = true;
    } else if (trainer) {
      const allowedEvosList = Array.isArray(trainer.evosPermitidas)
        ? trainer.evosPermitidas
        : (Array.isArray(trainer.permitirEvos) ? trainer.permitirEvos : []);
      if (allowedEvosList.length > 0) {
        const cleanCardId = cardId.toLowerCase();
        if (allowedEvosList.some(ae => {
          const s = String(ae || '').toLowerCase().trim();
          return s === cleanCardId || cleanCardId.startsWith(s) || s.startsWith(cleanCardId);
        })) {
          allowEvo = true;
        }
      }
    }
  }

  // Comprobar si el trait viene en el mapa de traits del entrenador (trainer.traits o trainer.traitsObligatorios)
  if (!traitId && trainer) {
    const trainerTraitsMap = trainer.traits || trainer.traitsObligatorios || trainer.cartasTraits || trainer.traitsMap || null;
    if (trainerTraitsMap && typeof trainerTraitsMap === 'object') {
      const cleanCardId = cardId.toLowerCase();
      for (const [key, tVal] of Object.entries(trainerTraitsMap)) {
        const kClean = String(key).toLowerCase().trim();
        if (kClean === cleanCardId || cleanCardId.startsWith(kClean) || kClean.startsWith(cleanCardId)) {
          traitId = typeof tVal === 'object' ? String(tVal?.id || tVal?.traitId || tVal?.name || '').trim() : String(tVal).trim();
          break;
        }
      }
    }
  }

  return { cardId, allowEvo, evoVariant, traitId, hasTrainerBuff };
}

/**
 * Construye el equipo del entrenador respetando cartas obligatorias, prohibidas e intervalo de medias.
 * Permite sacar calidad evo exclusivamente cuando está permitida explícitamente, y asignar traits obligatorios por carta.
 */
function buildTrainerDeck(trainer, allCardsPool) {
  const isEvoCard = c => {
    if (!c) return false;
    const q = String(c.calidad || c.quality || c.calidadId || '').trim().toLowerCase();
    return q === 'evo' || q === 'evolucion' || q === 'evolución';
  };

  const pool = Array.isArray(allCardsPool) ? allCardsPool : [];

  // Base limpia de cartas del catálogo SIN calidad evo (para rellenar puestos no obligatorios)
  const basePool = pool.filter(c => c && c.id && !isEvoCard(c));

  // 1. Configuración de cartas prohibidas
  const rawForbidden = trainer.cartasProhibidas || trainer.excludedCards || trainer.cartasNunca || trainer.mustExclude || [];
  const forbiddenList = (Array.isArray(rawForbidden) ? rawForbidden : [rawForbidden])
    .map(x => String(x || '').trim())
    .filter(Boolean);

  const isForbidden = card => {
    if (!card) return true;
    return forbiddenList.some(f => cardMatchesQuery(card, f));
  };

  // 2. Configuración de intervalo de medias
  // Si solo hay un número (ej. [85], 85, o {min: 85}), se interpreta como mínimo y no tiene máximo (Infinity)
  let minMedia = -Infinity;
  let maxMedia = Infinity;
  const rawInterval = trainer.intervaloMedias !== undefined 
    ? trainer.intervaloMedias 
    : (trainer.mediaRange !== undefined ? trainer.mediaRange : trainer.rangoMedias);

  if (Array.isArray(rawInterval)) {
    if (rawInterval.length === 1 || (rawInterval.length >= 2 && (rawInterval[1] === null || rawInterval[1] === undefined || rawInterval[1] === ''))) {
      const parsedMin = Number(rawInterval[0]);
      minMedia = isNaN(parsedMin) ? -Infinity : parsedMin;
      maxMedia = Infinity;
    } else if (rawInterval.length >= 2) {
      const parsedMin = Number(rawInterval[0]);
      const parsedMax = Number(rawInterval[1]);
      minMedia = isNaN(parsedMin) ? -Infinity : parsedMin;
      maxMedia = isNaN(parsedMax) ? Infinity : parsedMax;
    }
  } else if (typeof rawInterval === 'number') {
    minMedia = Number(rawInterval);
    maxMedia = Infinity;
  } else if (typeof rawInterval === 'string') {
    const trimmed = rawInterval.trim();
    if (trimmed.includes('-') || trimmed.includes(',')) {
      const parts = trimmed.split(/[-,\/]/).map(p => p.trim()).filter(Boolean);
      if (parts.length === 1) {
        const parsedMin = Number(parts[0]);
        minMedia = isNaN(parsedMin) ? -Infinity : parsedMin;
        maxMedia = Infinity;
      } else if (parts.length >= 2) {
        const parsedMin = Number(parts[0]);
        const parsedMax = Number(parts[1]);
        minMedia = isNaN(parsedMin) ? -Infinity : parsedMin;
        maxMedia = isNaN(parsedMax) ? Infinity : parsedMax;
      }
    } else {
      const parsedNum = Number(trimmed.replace(/[+]/g, ''));
      if (!isNaN(parsedNum)) {
        minMedia = parsedNum;
        maxMedia = Infinity;
      }
    }
  } else if (rawInterval && typeof rawInterval === 'object') {
    if (rawInterval.min !== undefined) {
      const parsedMin = Number(rawInterval.min);
      minMedia = isNaN(parsedMin) ? -Infinity : parsedMin;
    }
    if (rawInterval.max !== undefined) {
      const parsedMax = Number(rawInterval.max);
      maxMedia = isNaN(parsedMax) ? Infinity : parsedMax;
    }
  } else {
    if (trainer.minMedia !== undefined) {
      const parsedMin = Number(trainer.minMedia);
      minMedia = isNaN(parsedMin) ? -Infinity : parsedMin;
    }
    if (trainer.maxMedia !== undefined) {
      const parsedMax = Number(trainer.maxMedia);
      maxMedia = isNaN(parsedMax) ? Infinity : parsedMax;
    }
  }

  // Corregir si se colocaron al revés accidentalmente
  if (Number.isFinite(minMedia) && Number.isFinite(maxMedia) && minMedia > maxMedia) {
    const temp = minMedia;
    minMedia = maxMedia;
    maxMedia = temp;
  }

  const maxDisplay = maxMedia === Infinity ? '∞ (sin máximo)' : maxMedia;
  console.log(`[TRAINER-DECK] Entrenador: ${trainer.nombre || trainer.name}. Intervalo medias: [${minMedia}, ${maxDisplay}]. Prohibidas: ${forbiddenList.length}`);

  const pickedCards = [];
  const pickedIds = new Set();

  const cleanCard = (c, mandatoryTraitId = null) => {
    const cardObj = {
      ...c,
      uniqueId: undefined,
      instanceId: undefined
    };

    const targetTraitId = mandatoryTraitId || (c.hasMandatoryTrait ? c.opponentTraitId : null);
    if (targetTraitId) {
      const traitObj = resolveTrainerTrait(targetTraitId);
      cardObj.hasTrait = true;
      cardObj.opponentTraitId = traitObj?.id || targetTraitId;
      cardObj.traitId = traitObj?.id || targetTraitId;
      cardObj.assignedTrait = traitObj;
      cardObj.hasMandatoryTrait = true;
    } else {
      cardObj.hasTrait = false;
      cardObj.opponentTraitId = null;
      cardObj.traitId = null;
      cardObj.hasMandatoryTrait = false;
    }

    return cardObj;
  };

  // 3. Añadir cartas obligatorias
  const is7v1Mode = Boolean(
    trainer?.mode === '7v1' ||
    window.battleState?.is7v1Mode ||
    window.is7v1Mode ||
    (window.isSpecialEventBattle && (window.currentSpecialEvent?.mode === '7v1' || window.currentSpecialEventLevel?.mode === '7v1'))
  );

  const rawMandatory = trainer.cartasObligatorias || trainer.guaranteedCards || trainer.cartasSiempre || trainer.mustInclude || [];
  let mandatoryItems = Array.isArray(rawMandatory) ? rawMandatory : [rawMandatory];
  if (is7v1Mode && mandatoryItems.length > 1) {
    // En modo 7v1 si se definen varias opciones, se elige 1 carta aleatoria
    mandatoryItems = [mandatoryItems[Math.floor(Math.random() * mandatoryItems.length)]];
  }

  for (const item of mandatoryItems) {
    if (!item) continue;
    if (pickedCards.length >= 8) break;

    const spec = parseMandatoryCardSpec(item, trainer);
    const mQuery = spec.cardId;
    if (!mQuery) continue;

    let chosenCard = null;

    if (spec.allowEvo) {
      // =========================================================================
      // CASO A: EVO PERMITIDA EXPLÍCITAMENTE O POR ESPECIFICACIÓN DIRECTA (_evo)
      // "si por ejemplo yo le ponga kurai_tenro_evoe directamente detecte que aunque es una evo la puede sacar porque yo se lo he puesto, cualquier sufijo que empiece por _evo"
      // =========================================================================
      // 0. Coincidencia directa por ID exacto en el pool (prioridad absoluta)
      const directMatch = pool.find(c => c && c.id && String(c.id).toLowerCase() === mQuery.toLowerCase() && !isForbidden(c) && !pickedIds.has(c.id));
      if (directMatch && isEvoCard(directMatch)) {
        chosenCard = directMatch;
        console.log(`[TRAINER-DECK] 🧬 Carta EVO por ID exacto seleccionada: ${chosenCard.name || chosenCard.id} (ID: ${chosenCard.id}, Calidad: ${chosenCard.calidad}, Media: ${chosenCard.media})`);
      }

      if (!chosenCard) {
        // 1. Buscar en todo el catálogo cartas que tengan calidad 'evo' y coincidan con mQuery
        const evoMatches = pool.filter(c => {
          if (!c || !c.id || !isEvoCard(c) || isForbidden(c) || pickedIds.has(c.id)) return false;
          return cardMatchesQuery(c, mQuery) || String(c.id).toLowerCase().includes(mQuery.toLowerCase());
        });

      if (evoMatches.length > 0) {
        if (spec.evoVariant) {
          const vNorm = spec.evoVariant.toLowerCase().replace(/[^a-z0-9]/g, '');
          chosenCard = evoMatches.find(c => {
            const cid = String(c.id).toLowerCase().replace(/[^a-z0-9]/g, '');
            return cid.includes(vNorm) || cid.endsWith(vNorm);
          }) || evoMatches[0];
        } else {
          // Priorizar coincidencia exacta de ID si la hay
          chosenCard = evoMatches.find(c => String(c.id).toLowerCase() === mQuery.toLowerCase()) || evoMatches[0];
        }
        console.log(`[TRAINER-DECK] 🧬 Carta EVO permitida y seleccionada: ${chosenCard.name || chosenCard.id} (ID: ${chosenCard.id}, Calidad: ${chosenCard.calidad}, Media: ${chosenCard.media})`);
      } else {
        // 2. Si no hubo coincidencia directa por ID, buscar variante evo por prefijo base
        const baseNorm = mQuery.toLowerCase().replace(/[^a-z0-9]/g, '');
        const evoVariant = pool.find(c => {
          if (!c || !c.id || !isEvoCard(c) || isForbidden(c) || pickedIds.has(c.id)) return false;
          const cNorm = String(c.id).toLowerCase().replace(/[^a-z0-9]/g, '');
          if (spec.evoVariant) {
            const vNorm = spec.evoVariant.toLowerCase().replace(/[^a-z0-9]/g, '');
            if (!cNorm.includes(vNorm) && !cNorm.endsWith(vNorm)) return false;
          }
          return cNorm.startsWith(baseNorm) || baseNorm.startsWith(cNorm.replace(/(evo|evoe|evo\d+)$/, ''));
        });

        if (evoVariant) {
          chosenCard = evoVariant;
          console.log(`[TRAINER-DECK] 🧬 Variante EVO encontrada para '${mQuery}': ${chosenCard.name || chosenCard.id} (ID: ${chosenCard.id})`);
        }
      }
    }

      // Si no existe ninguna versión evo en el catálogo, recurrir a la carta normal
      if (!chosenCard) {
        const fallbackMatches = pool.filter(c => cardMatchesQuery(c, mQuery) && !isForbidden(c) && !pickedIds.has(c.id));
        if (fallbackMatches.length > 0) {
          chosenCard = fallbackMatches.find(c => String(c.id).toLowerCase() === mQuery.toLowerCase()) || fallbackMatches[0];
        }
      }
    } else {
      // =========================================================================
      // CASO B: EVO NO PERMITIDA (COMPORTAMIENTO POR DEFECTO ESTRICTO)
      // "le deje sacar la calidad evo exclusivamente cuando yo le ponga que tiene permitida que la saque"
      // Si la carta tiene una evo, NO puede sacar la calidad evo, debe sacar la carta base sin calidad evo!
      // =========================================================================
      const baseMatches = pool.filter(c => {
        if (!c || !c.id || isEvoCard(c) || isForbidden(c) || pickedIds.has(c.id)) return false;
        return cardMatchesQuery(c, mQuery);
      });

      if (baseMatches.length > 0) {
        chosenCard = baseMatches.find(c => String(c.id).toLowerCase() === mQuery.toLowerCase()) || baseMatches[0];
      } else {
        // Si el query incluía un sufijo evo (ej. "ronan_hatake_evo1") pero NO se permitió la evo,
        // buscar la carta base limpia sin evo
        const cleanBaseQuery = mQuery.replace(/_(?:evo\d*|evoe|evochad|evosamurai|sbcevo)$/i, '');
        if (cleanBaseQuery !== mQuery) {
          const strippedMatches = pool.filter(c => {
            if (!c || !c.id || isEvoCard(c) || isForbidden(c) || pickedIds.has(c.id)) return false;
            return cardMatchesQuery(c, cleanBaseQuery);
          });
          if (strippedMatches.length > 0) {
            chosenCard = strippedMatches.find(c => String(c.id).toLowerCase() === cleanBaseQuery.toLowerCase()) || strippedMatches[0];
            console.log(`[TRAINER-DECK] 🔒 Evo NO permitida para '${mQuery}'. Seleccionando carta base sin evo: ${chosenCard.id}`);
          }
        }
      }
    }

    if (chosenCard) {
      const cardToAdd = cleanCard(chosenCard, spec.traitId);
      if (spec.hasTrainerBuff) {
        cardToAdd.hasTrainerBuff = true;
      }
      pickedCards.push(cardToAdd);
      pickedIds.add(chosenCard.id);
      console.log(`[TRAINER-DECK] ✅ Carta obligatoria incluida: ${chosenCard.name || chosenCard.nombre} (ID: ${chosenCard.id}, Calidad: ${chosenCard.calidad || 'Normal'}, Trait: ${cardToAdd.opponentTraitId || 'Ninguno'}${cardToAdd.hasTrainerBuff ? ', Buff: Sí' : ''})`);
    } else {
      console.warn(`[TRAINER-DECK] ⚠️ Carta obligatoria '${mQuery}' no encontrada en el catálogo o está prohibida.`);
    }
  }

  // Helper para buscar trait asignado por entrenador a nivel de traits map
  const getTrainerAssignedTrait = (card) => {
    const trainerTraitsMap = trainer.traits || trainer.traitsObligatorios || trainer.cartasTraits || trainer.traitsMap || null;
    if (!trainerTraitsMap || typeof trainerTraitsMap !== 'object') return null;
    const cid = String(card.id || '').toLowerCase().trim();
    for (const [key, tVal] of Object.entries(trainerTraitsMap)) {
      const kClean = String(key).toLowerCase().trim();
      if (kClean === cid || cid.startsWith(kClean) || kClean.startsWith(cid)) {
        return String(tVal).trim();
      }
    }
    return null;
  };

  // 4. Filtrar candidatas para los puestos restantes que cumplan ESTRICTAMENTE el intervalo de medias
  const candidatePool = basePool.filter(c => {
    if (pickedIds.has(c.id)) return false;
    if (isForbidden(c)) return false;
    const m = Number(c.media || c.overall || 0);
    return m >= minMedia && (maxMedia === Infinity ? true : m <= maxMedia);
  });

  console.log(`[TRAINER-DECK] Candidatas disponibles en rango [${minMedia}, ${maxDisplay}]: ${candidatePool.length}`);

  if (is7v1Mode) {
    let singleCard = pickedCards[0];
    if (!singleCard) {
      const candidates = candidatePool.length > 0 ? candidatePool : basePool;
      if (candidates.length > 0) {
        const choice = candidates[Math.floor(Math.random() * candidates.length)];
        singleCard = cleanCard(choice, getTrainerAssignedTrait(choice));
      }
    }
    if (singleCard) {
      console.log(`[TRAINER-DECK] ⚔️ MODO 7v1 ACTIVO: Rival configurado con carta única: ${singleCard.name || singleCard.id} (Media: ${singleCard.media})`);
      return {
        activeTeam: [singleCard],
        reserveCard: null
      };
    }
  }

  // Barajar candidatas aleatoriamente
  const shuffledCandidates = [...candidatePool].sort(() => Math.random() - 0.5);

  while (pickedCards.length < 8 && shuffledCandidates.length > 0) {
    const choice = shuffledCandidates.pop();
    const assignedTrait = getTrainerAssignedTrait(choice);
    pickedCards.push(cleanCard(choice, assignedTrait));
    pickedIds.add(choice.id);
  }

  // 5. Fallback de contingencia: solo si el intervalo no tiene suficientes cartas para completar 8
  if (pickedCards.length < 8) {
    console.warn(`[TRAINER-DECK] Rango [${minMedia}, ${maxDisplay}] insuficiente para 8 cartas. Rellenando con cartas más próximas.`);
    const targetMid = (Number.isFinite(minMedia) && Number.isFinite(maxMedia)) 
      ? (minMedia + maxMedia) / 2 
      : (Number.isFinite(minMedia) ? minMedia : (Number.isFinite(maxMedia) ? maxMedia : 80));

    const remainingPool = basePool
      .filter(c => !pickedIds.has(c.id) && !isForbidden(c))
      .sort((a, b) => {
        const diffA = Math.abs(Number(a.media || 0) - targetMid);
        const diffB = Math.abs(Number(b.media || 0) - targetMid);
        return diffA - diffB;
      });

    while (pickedCards.length < 8 && remainingPool.length > 0) {
      const choice = remainingPool.shift();
      const assignedTrait = getTrainerAssignedTrait(choice);
      pickedCards.push(cleanCard(choice, assignedTrait));
      pickedIds.add(choice.id);
    }
  }

  const activeTeam = pickedCards.slice(0, 7);
  const reserveCard = pickedCards[7] || null;

  const mediasSummary = pickedCards.map(c => Number(c.media || 0));
  console.log(`[TRAINER-DECK] ✅ Mazo generado (${pickedCards.length} cartas):`, mediasSummary.join(', '));

  return { activeTeam, reserveCard };
}

/**
 * Calcula el intervalo de media [minMedia, maxMedia] para un piso dado del Modo Infinito:
 * - Piso 1 a 20: [74, 80] progresando de forma intensa hasta [84, 89] en piso 20.
 * - Pisos 21 a 50: [84, 89] progresando hasta [90, 94] en piso 50.
 * - Pisos 51 a 70: [91, Infinity]
 * - Pisos 71 a 80: [92, Infinity]
 * - Pisos 81+: [93, Infinity]
 * 
 * En pisos >= 51 se liberan las cartas de calidad 'evo', permitiendo que la IA las seleccione si su media encaja en el rango.
 */
function getInfiniteFloorMediaInterval(floorNumber) {
  const floor = Math.max(1, parseInt(floorNumber, 10) || 1);

  if (floor <= 20) {
    let min, max;
    if (floor <= 5) {
      min = 74 + Math.floor((floor - 1) / 2);
      max = 80 + Math.floor((floor - 1) / 2);
    } else if (floor <= 10) {
      min = 76 + Math.floor((floor - 5) * 3 / 5);
      max = 82 + Math.floor((floor - 5) * 3 / 5);
    } else if (floor <= 15) {
      min = 79 + Math.floor((floor - 10) * 3 / 5);
      max = 85 + Math.floor((floor - 10) * 2 / 5);
    } else {
      min = 82 + Math.floor((floor - 15) * 2 / 5);
      max = 87 + Math.floor((floor - 15) * 2 / 5);
    }
    return { min, max };
  }

  if (floor <= 50) {
    const p = floor - 20; // 1 a 30
    let min = 84 + Math.round((p * 6) / 30);
    let max = 89 + Math.round((p * 5) / 30);
    return { min: Math.min(90, min), max: Math.min(94, max) };
  }

  // Pisos 51 en adelante
  let min = 91;
  if (floor >= 81) min = 93;
  else if (floor >= 71) min = 92;
  return { min, max: Infinity };
}

window.getInfiniteFloorMediaInterval = getInfiniteFloorMediaInterval;

/**
 * Baraja un array de forma verdaderamente uniforme e imparcial usando Fisher-Yates
 */
function shuffleArray(arr) {
  if (!Array.isArray(arr)) return [];
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
window.shuffleArray = shuffleArray;

/**
 * Selecciona un trait ponderado aleatorio de la lista
 */
function selectRandomTrait(list) {
  if (!Array.isArray(list) || list.length === 0) return null;
  if (typeof calculateTraitProbabilities === 'function' && typeof rollWeightedTrait === 'function') {
    try {
      const withProbs = calculateTraitProbabilities(list);
      const rolled = rollWeightedTrait(withProbs);
      if (rolled) return rolled;
    } catch (e) {
      console.warn('[BATTLE-AI] Error en rollWeightedTrait:', e);
    }
  }
  return list[Math.floor(Math.random() * list.length)] || null;
}
window.selectRandomTrait = selectRandomTrait;

/**
 * Función principal para generar el equipo oponente
 */
async function generateOpponentTeam() {
  console.log('[BATTLE] Generando equipo oponente para dificultad:', window.battleState.difficulty);

  const infiniteContext = window.__infiniteBattleContext && window.__infiniteBattleContext.active
    ? window.__infiniteBattleContext
    : null;

  let opponentTeamBase = [];
  let opponentReserveBase = null;

  if (infiniteContext) {
    // ==================== MODO INFINITO: INTERVALOS DE MEDIA POR PISO ====================
    const floor = Math.max(1, parseInt(infiniteContext.floor, 10) || 1);
    const interval = getInfiniteFloorMediaInterval(floor);
    const minMedia = interval.min;
    const maxMedia = interval.max;

    console.log(`[INFINITE-BATTLE] Piso ${floor} -> Intervalo de Media del Rival: [${minMedia}, ${maxMedia === Infinity ? '∞' : maxMedia}]`);

    // Obtener el catálogo maestro de cartas del juego (NUNCA el inventario del jugador)
    const allCardsCatalog = await getAllAvailableCardsPool();

    // Función auxiliar para identificar cartas de calidad o tipo evolución
    const isEvoCard = c => {
      const q = String(c?.calidad || c?.quality || c?.calidadId || '').trim().toLowerCase();
      const id = String(c?.id || '').toLowerCase();
      return q === 'evo' || q === 'evolucion' || q === 'evolución' || id.endsWith('_evo') || id.includes('_evo') || id.includes('_evolution') || id.includes('_evolucion');
    };

    // Pool maestro deduplicado por ID de carta, sin traits previos ni IDs de instancia
    const seenIds = new Set();
    const uniquePool = [];
    const sourceList = (Array.isArray(allCardsCatalog) && allCardsCatalog.length > 0)
      ? allCardsCatalog
      : (Array.isArray(window.teamBuilderCards) ? window.teamBuilderCards : []);

    for (const card of sourceList) {
      if (!card || !card.id) continue;
      if (Number(card.media || card.overall || 0) <= 0) continue;
      // Las cartas de calidad evo solo se liberan a partir del piso 51
      if (floor < 51 && isEvoCard(card)) continue;
      const idLower = String(card.id).toLowerCase();
      if (seenIds.has(idLower)) continue;
      seenIds.add(idLower);
      uniquePool.push({
        ...card,
        uniqueId: undefined,
        instanceId: undefined,
        hasTrait: false,
        opponentTraitId: null
      });
    }

    // Identificar las cartas que el jugador lleva equipadas para evitar que el bot las replique
    const playerTeamCards = (Array.isArray(window.battleState?.playerTeam) && window.battleState.playerTeam.length > 0)
      ? window.battleState.playerTeam
      : (Array.isArray(window.selectedTeam) ? window.selectedTeam : []);

    const playerCardIds = new Set(
      playerTeamCards
        .map(c => String(c?.id || c?.cardId || '').toLowerCase().replace(/_notrait$/, ''))
        .filter(Boolean)
    );

    // Filtrar candidatos estrictamente en el intervalo del piso [minMedia, maxMedia]
    let candidates = uniquePool.filter(c => {
      const m = Number(c.media || c.overall || 0);
      return m >= minMedia && (maxMedia === Infinity ? true : m <= maxMedia);
    });

    // Excluir del pool del bot las cartas del mazo del jugador para garantizar rivales variados
    let eligiblePool = candidates.filter(c => !playerCardIds.has(String(c.id).toLowerCase()));

    // Si después de excluir al jugador hay suficientes cartas (>= 8), usamos eligiblePool.
    // De lo contrario, usamos candidates completo.
    if (eligiblePool.length < 8) {
      eligiblePool = candidates;
    }

    // Si aún hay menos de 8 candidatos (en caso extremo de un catálogo muy reducido),
    // ampliar progresivamente hacia abajo hasta reunir al menos 8 cartas
    let searchMin = minMedia;
    while (eligiblePool.length < 8 && searchMin > 50) {
      searchMin -= 1;
      const broadened = uniquePool.filter(c => {
        const m = Number(c.media || c.overall || 0);
        return m >= searchMin && (maxMedia === Infinity ? true : m <= maxMedia);
      });
      const nonPlayer = broadened.filter(c => !playerCardIds.has(String(c.id).toLowerCase()));
      eligiblePool = nonPlayer.length >= 8 ? nonPlayer : broadened;
    }

    // Barajar de forma verdaderamente aleatoria e imparcial usando Fisher-Yates
    const candidatePool = shuffleArray(eligiblePool);
    const picked = [];

    // Seleccionar 8 cartas aleatorias únicas dentro del rango
    for (let i = 0; i < candidatePool.length && picked.length < 8; i++) {
      picked.push({ ...candidatePool[i] });
    }

    // Fallback de ultra-seguridad si el catálogo total tuviera menos de 8 cartas
    if (picked.length < 8) {
      const fallbackPool = shuffleArray(uniquePool);
      for (const card of fallbackPool) {
        if (picked.length >= 8) break;
        if (!picked.some(p => p.id === card.id)) {
          picked.push({ ...card });
        }
      }
      while (picked.length < 8 && picked.length > 0) {
        picked.push({ ...picked[picked.length % picked.length] });
      }
    }

    // Asignar IDs únicos a cada carta del bot para evitar cualquier colisión con el jugador
    opponentTeamBase = picked.slice(0, 7).map((card, idx) => ({
      ...card,
      uniqueId: `infinite_bot_card_${card.id}_${idx}_${Date.now()}_${Math.random()}`
    }));
    opponentReserveBase = picked[7] ? {
      ...picked[7],
      uniqueId: `infinite_bot_card_${picked[7].id}_reserve_${Date.now()}_${Math.random()}`
    } : null;

    const avg = picked.reduce((sum, card) => sum + Number(card.media || 0), 0) / Math.max(1, picked.length);
    console.log(`[INFINITE-BATTLE] Rival generado para Piso ${floor} (${picked.length} cartas): Rango [${minMedia}, ${maxMedia === Infinity ? '∞' : maxMedia}], Media real: ${avg.toFixed(2)}`);
    console.log('[INFINITE-BATTLE] Cartas del rival:', picked.map(c => `${c.name} (${c.media})`).join(', '));

    window.battleState.opponentName = infiniteContext.trainerName || `Entrenador Piso ${infiniteContext.floor || 1}`;
    window.battleState.opponentTitle = `(Piso ${infiniteContext.floor || 1})`;
    window.battleState.opponentAvatar = infiniteContext.trainerImage || `https://api.dicebear.com/7.x/avataaars/svg?seed=infinite-${infiniteContext.floor || 1}`;
    window.battleState.opponentBackground = null;
    window.battleState.opponentSong = infiniteContext.battleSong || infiniteContext.opponentSong || null;
    window.battleState.selectedTrainer = null;

    // Asignar traits al rival en Modo Infinito (solo piso >= 50 puede tener legendarios y miticos)
    const rawInfiniteTraits = (Array.isArray(window.battleState?.availableTraits) && window.battleState.availableTraits.length > 0)
      ? window.battleState.availableTraits
      : (Array.isArray(window.availableTraits) && window.availableTraits.length > 0
          ? window.availableTraits
          : (typeof window.getKnownTraitsList === 'function' ? window.getKnownTraitsList() : (availableTraits || [])));
    const infiniteTraitsList = floor >= 50
      ? rawInfiniteTraits
      : rawInfiniteTraits.filter(t => t && t.rarity !== 'legendary' && t.rarity !== 'mythic');

    const activeMod = window.battleState?.infiniteModifier || window.__infiniteBattleContext?.modifier;
    const isImpostorMod = activeMod?.id === 'impostor';

    if (isImpostorMod) {
      window.battleState.opponentTeam = opponentTeamBase.map((card, idx) => ({
        ...card,
        uniqueId: `infinite_bot_impostor_${Date.now()}_${idx}`,
        opponentTraitId: 'impostor',
        traitId: 'impostor',
        hasTrait: true
      }));
      if (opponentReserveBase) {
        window.battleState.opponentReserveCard = {
          ...opponentReserveBase,
          uniqueId: `infinite_bot_impostor_res_${Date.now()}`,
          opponentTraitId: 'impostor',
          traitId: 'impostor',
          hasTrait: true
        };
      } else {
        window.battleState.opponentReserveCard = null;
      }
      console.log('[MODIFIER-IMPOSTOR] Todas las cartas de la IA configuradas con trait Impostor');
    } else {
      window.battleState.opponentTeam = opponentTeamBase.map(card => {
        if (Math.random() < 0.3 && infiniteTraitsList.length > 0) {
          const randomTrait = selectRandomTrait(infiniteTraitsList);
          if (randomTrait && randomTrait.id) {
            return {
              ...card,
              uniqueId: `infinite_bot_trait_${Date.now()}_${Math.random()}`,
              opponentTraitId: randomTrait.id,
              traitId: randomTrait.id,
              hasTrait: true
            };
          }
        }
        return { ...card, hasTrait: false, opponentTraitId: null };
      });

      if (opponentReserveBase) {
        if (Math.random() < 0.3 && infiniteTraitsList.length > 0) {
          const randomTrait = selectRandomTrait(infiniteTraitsList);
          if (randomTrait && randomTrait.id) {
            window.battleState.opponentReserveCard = {
              ...opponentReserveBase,
              uniqueId: `infinite_bot_trait_${Date.now()}_${Math.random()}`,
              opponentTraitId: randomTrait.id,
              traitId: randomTrait.id,
              hasTrait: true
            };
          } else {
            window.battleState.opponentReserveCard = { ...opponentReserveBase, hasTrait: false, opponentTraitId: null };
          }
        } else {
          window.battleState.opponentReserveCard = { ...opponentReserveBase, hasTrait: false, opponentTraitId: null };
        }
      } else {
        window.battleState.opponentReserveCard = null;
      }
    }
  } else {
    // ==================== MODO OFFLINE CLÁSICO (SISTEMA DE ENTRENADORES DINÁMICO) ====================
    const currentDiff = window.battleState.difficulty || window.selectedDifficulty || 'principiante';
    
    // Cargar entrenadores y catálogo de cartas (forzar refresh si aún no se había cargado de remoto)
    const [trainersList, allCardsPool] = await Promise.all([
      fetchRemoteTrainersDirectly(!window.trainersLoadedFromRemote),
      getAllAvailableCardsPool()
    ]);

    // Seleccionar entrenador para la dificultad
    const selectedTrainer = selectTrainerForDifficulty(currentDiff, trainersList);
    window.battleState.selectedTrainer = selectedTrainer;

    // Configurar identidad del rival y fondo personalizado
    window.battleState.opponentName = selectedTrainer.nombre || selectedTrainer.name || getOpponentName(currentDiff);
    window.battleState.opponentTitle = selectedTrainer.titulo || selectedTrainer.title || getOpponentTitle(currentDiff);
    window.battleState.opponentAvatar = selectedTrainer.imagen || selectedTrainer.avatar || selectedTrainer.image || getOpponentAvatar(currentDiff);
    window.battleState.opponentBackground = selectedTrainer.fondo || selectedTrainer.fondoBatalla || selectedTrainer.battleBackground || selectedTrainer.background || null;

    // Canción / música de batalla personalizada del entrenador (opcional en trainers.json)
    const rawSong = selectedTrainer.song || selectedTrainer.cancion || selectedTrainer.musica || selectedTrainer.battleSong || selectedTrainer.battleMusic || null;
    window.battleState.opponentSong = (typeof rawSong === 'string' && rawSong.trim()) ? rawSong.trim() : null;

    // Configurar poderes personalizados del entrenador (manual o aleatorio en trainers.json)
    const rawTrainerPowers = selectedTrainer.poderes || selectedTrainer.powers;
    window.battleState.opponentPowers = resolveTrainerPowers(rawTrainerPowers);

    // Configurar buffo personalizado del entrenador (opcional en trainers.json)
    const rawTrainerBuff = selectedTrainer.buff || selectedTrainer.buffo || selectedTrainer.trainerBuff || selectedTrainer.customBuff || null;
    const parsedTrainerBuff = parseTrainerBuff(rawTrainerBuff, selectedTrainer);
    window.battleState.trainerBuff = parsedTrainerBuff;
    selectedTrainer.parsedTrainerBuff = parsedTrainerBuff;

    console.log('[BATTLE] 🎭 Entrenador configurado:', {
      nombre: window.battleState.opponentName,
      titulo: window.battleState.opponentTitle,
      avatar: window.battleState.opponentAvatar,
      fondo: window.battleState.opponentBackground,
      cancion: window.battleState.opponentSong,
      poderes: window.battleState.opponentPowers,
      buff: parsedTrainerBuff
    });

    // Construir mazo según especificaciones del entrenador
    const deckResult = buildTrainerDeck(selectedTrainer, allCardsPool);
    opponentTeamBase = deckResult.activeTeam;
    opponentReserveBase = deckResult.reserveCard;
    if (!isInfiniteBattle && (selectedTrainer?.mode === '7v1' || window.battleState?.is7v1Mode || window.is7v1Mode)) {
      window.battleState.is7v1Mode = true;
      window.is7v1Mode = true;
    }

    // Asignar traits aleatorios a algunas cartas del oponente (30% de probabilidad)
    const rawOfflineTraits = (Array.isArray(window.battleState?.availableTraits) && window.battleState.availableTraits.length > 0)
      ? window.battleState.availableTraits
      : (Array.isArray(window.availableTraits) && window.availableTraits.length > 0
          ? window.availableTraits
          : (typeof window.getKnownTraitsList === 'function' ? window.getKnownTraitsList() : (availableTraits || [])));
    const traitsList = rawOfflineTraits;

    window.battleState.opponentTeam = opponentTeamBase.map((card, idx) => {
      // 1. Si la carta ya tiene un trait obligatorio configurado en trainers.json, conservarlo sí o sí!
      if (card.hasMandatoryTrait && (card.opponentTraitId || card.traitId)) {
        const resolvedTraitId = card.opponentTraitId || card.traitId;
        const uid = card.uniqueId || `opponent_mandatory_trait_${card.id}_${idx}_${Date.now()}_${Math.random()}`;
        console.log(`[TRAINERS] 🛡️ Conservando trait obligatorio para carta rival ${card.name || card.id}:`, resolvedTraitId);
        const cardWithTrait = {
          ...card,
          uniqueId: uid,
          opponentTraitId: resolvedTraitId,
          traitId: resolvedTraitId,
          hasTrait: true,
          hasMandatoryTrait: true
        };
        if (!window.battleState.cardTraitsMap) window.battleState.cardTraitsMap = {};
        window.battleState.cardTraitsMap[uid] = resolvedTraitId;
        window.battleState.cardTraitsMap[cardWithTrait.id] = resolvedTraitId;
        return cardWithTrait;
      }

      // 2. Si no tiene trait obligatorio, tirar el 30% de probabilidad aleatoria estándar
      if (Math.random() < 0.3 && traitsList.length > 0) {
        const randomTrait = selectRandomTrait(traitsList);
        if (randomTrait && randomTrait.id) {
          const uid = `opponent_trait_${Date.now()}_${Math.random()}`;
          return {
            ...card,
            uniqueId: uid,
            opponentTraitId: randomTrait.id,
            traitId: randomTrait.id,
            hasTrait: true
          };
        }
      }
      return {
        ...card,
        uniqueId: card.uniqueId || `opponent_card_${card.id}_${idx}_${Date.now()}_${Math.random()}`,
        hasTrait: false,
        opponentTraitId: null,
        traitId: null
      };
    });

    if (opponentReserveBase) {
      if (opponentReserveBase.hasMandatoryTrait && (opponentReserveBase.opponentTraitId || opponentReserveBase.traitId)) {
        const resTraitId = opponentReserveBase.opponentTraitId || opponentReserveBase.traitId;
        const rUid = opponentReserveBase.uniqueId || `opponent_mandatory_reserve_${opponentReserveBase.id}_${Date.now()}_${Math.random()}`;
        console.log(`[TRAINERS] 🛡️ Conservando trait obligatorio para reserva rival ${opponentReserveBase.name || opponentReserveBase.id}:`, resTraitId);
        const reserveWithTrait = {
          ...opponentReserveBase,
          uniqueId: rUid,
          opponentTraitId: resTraitId,
          traitId: resTraitId,
          hasTrait: true,
          hasMandatoryTrait: true
        };
        if (!window.battleState.cardTraitsMap) window.battleState.cardTraitsMap = {};
        window.battleState.cardTraitsMap[rUid] = resTraitId;
        window.battleState.cardTraitsMap[reserveWithTrait.id] = resTraitId;
        window.battleState.opponentReserveCard = reserveWithTrait;
      } else if (Math.random() < 0.3 && traitsList.length > 0) {
        const randomTrait = selectRandomTrait(traitsList);
        if (randomTrait && randomTrait.id) {
          window.battleState.opponentReserveCard = {
            ...opponentReserveBase,
            uniqueId: `opponent_trait_reserve_${Date.now()}_${Math.random()}`,
            opponentTraitId: randomTrait.id,
            traitId: randomTrait.id,
            hasTrait: true
          };
        } else {
          window.battleState.opponentReserveCard = {
            ...opponentReserveBase,
            uniqueId: opponentReserveBase.uniqueId || `opponent_reserve_${opponentReserveBase.id}_${Date.now()}_${Math.random()}`,
            hasTrait: false,
            opponentTraitId: null,
            traitId: null
          };
        }
      } else {
        window.battleState.opponentReserveCard = {
          ...opponentReserveBase,
          uniqueId: opponentReserveBase.uniqueId || `opponent_reserve_${opponentReserveBase.id}_${Date.now()}_${Math.random()}`,
          hasTrait: false,
          opponentTraitId: null,
          traitId: null
        };
      }
    } else {
      window.battleState.opponentReserveCard = null;
    }
  }

  console.log('[BATTLE] Oponente final preparado:', window.battleState.opponentName);

  // Calcular buffeos del oponente (SOLO procedencia, NO owner para bots)
  const opponentBuffsData = calculateBattleBuffs(window.battleState.opponentTeam);
  window.battleState.opponentBuffs = {
    buffs: opponentBuffsData.buffs.filter(buff => !buff.isOwnerBuff),
    byProcedencia: opponentBuffsData.byProcedencia,
    byOwner: {},
    trainerBuff: window.battleState.trainerBuff || null
  };
}

// Obtener nombre del oponente según dificultad
function getOpponentName(difficulty) {
  if (window.__infiniteBattleContext?.active && window.__infiniteBattleContext?.trainerName) {
    return window.__infiniteBattleContext.trainerName;
  }

  if (window.battleState?.opponentName) {
    return window.battleState.opponentName;
  }

  if (window.isEventBattle && window.currentEventBattle) {
    return window.currentEventBattle.trainerName || window.currentEventBattle.name || 'Rival de Evento';
  }

  const names = {
    'principiante': 'Novato',
    'amateur': 'Bot Amateur',
    'experimentado': 'Veterano',
    'profesional': 'Maestro',
    'dios-antiguo': 'Leyenda',
    'inmo': 'INMO'
  };
  return names[difficulty] || 'Oponente';
}

// Obtener título/nivel del oponente
function getOpponentTitle(difficulty) {
  if (window.__infiniteBattleContext?.active) {
    const floor = window.__infiniteBattleContext.floor || 1;
    return `(Piso ${floor})`;
  }

  if (window.battleState?.opponentTitle) {
    return window.battleState.opponentTitle;
  }

  if (window.isEventBattle && window.currentEventBattle) {
    return window.currentEventBattle.trainerTitle || '(Evento)';
  }

  const titles = {
    'principiante': '(Principiante)',
    'amateur': '(Amateur)',
    'experimentado': '(Experimentado)',
    'profesional': '(Profesional)',
    'dios-antiguo': '(Dios Antiguo)',
    'inmo': '(INMO)'
  };
  return titles[difficulty] || '(IA)';
}

// Obtener avatar del oponente según dificultad
function getOpponentAvatar(difficulty) {
  if (window.__infiniteBattleContext?.active && window.__infiniteBattleContext?.trainerImage) {
    return window.__infiniteBattleContext.trainerImage;
  }

  if (window.battleState?.opponentAvatar) {
    return window.battleState.opponentAvatar;
  }

  if (window.isEventBattle && window.currentEventBattle) {
    const ev = window.currentEventBattle;
    const bossCard = ev.bossCardId || ev.boss || ev.bossCard || (Array.isArray(ev.cartasObligatorias) ? ev.cartasObligatorias[0] : null);
    return ev.trainerImage || ev.image || (bossCard ? `https://raw.githubusercontent.com/hugom1307/kvrcards-catalog/main/image/${bossCard}.png` : null) || `https://api.dicebear.com/7.x/avataaars/svg?seed=${ev.id}`;
  }

  const seeds = {
    'principiante': 'rookie',
    'amateur': 'challenger',
    'experimentado': 'veteran',
    'profesional': 'master',
    'dios-antiguo': 'legend',
    'inmo': 'inmo'
  };
  return `https://api.dicebear.com/7.x/avataaars/svg?seed=${seeds[difficulty] || 'opponent'}`;
}

// Obtener fondo de batalla personalizado del oponente
function getOpponentBackground() {
  return window.battleState?.opponentBackground || null;
}

window.generateOpponentTeam = generateOpponentTeam;
window.getOpponentName = getOpponentName;
window.getOpponentTitle = getOpponentTitle;
window.getOpponentAvatar = getOpponentAvatar;
window.getOpponentBackground = getOpponentBackground;
window.resolveTrainerPowers = resolveTrainerPowers;



// ==================== NUEVO SISTEMA DE JUGABILIDAD ====================

// Iniciar la ruleta para decidir quién empieza
